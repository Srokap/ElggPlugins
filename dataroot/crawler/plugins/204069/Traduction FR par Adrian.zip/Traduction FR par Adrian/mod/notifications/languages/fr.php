<?php

	$french = array(
	
		'friends:all' => 'Tous les amis',
	
		'notifications:subscriptions:personal:description' => 'Recevoir des notifications lorsque des actions sont effectu&eacute;es sur votre contenu',
		'notifications:subscriptions:personal:title' => 'Notifications personnelles',
	
		'notifications:subscriptions:collections:title' => 'Regroupements de contacts',
		'notifications:subscriptions:collections:description' => 'Afin de param&eacute;trer la notification pour vos regroupements de contacts, utilisez les icones ci-dessous. Ces param&egrave;tres seront affect&eacute;s &agrave; chaque utilisateur du regroupement s&eacute;lectionn&eacute;. ',
		'notifications:subscriptions:collections:edit' => 'Pour modifier vos regroupements de contacts, cliquez ici.',
	
		'notifications:subscriptions:changesettings' => 'Notifications',
		'notifications:subscriptions:changesettings:groups' => 'Notifications de groupe',
		'notification:method:email' => 'Email',	
	
		'notifications:subscriptions:title' => 'Notifications par utilisateur',
		'notifications:subscriptions:description' => 'Afin de recevoir des notifications de la part de vos amis lorsqu\'ils cr&eacute;&eacute;ent du contenu, cherchez les ci-dessous et s&eacute;lectionnez la m&eacute;thode de notification que vous souhaitez utiliser.',
	
		'notifications:subscriptions:groups:description' => 'Afin de recevoir des notifications lorsque du contenu est ajout&eacute; &agrave; un groupe auquel vous appartenez, cherchez-le ci-dessous et s&eacute;lectionnez la m&eacute;thode de notification que vous souhaitez utiliser.',
	
		'notifications:subscriptions:success' => 'Vos param&egrave;tres de notification ont &eacute;t&eacute; correctement sauvegard&eacute;s.',
	
	);
					
	add_translation("fr",$french);

?>