<?php

	$french = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Entrez votre nom d\'utilisateur sur Twitter.',
		'twitter:num' => 'Nombre de tweets &agrave; afficher.',
		'twitter:visit' => 'visiter mon twitter',
		'twitter:notset' => 'Ce widget pour Twitter n\'est pas param&eacute;tr&eacute; pour le moment. Pour afficher vos derniers tweets, cliquez sur - modifier - et remplissez le formulaire',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s a ajout&eacute; le widget twitter.",
	        'twitter:river:updated' => "%s ont mis &agrave; jour leur widget twitter.",
	        'twitter:river:delete' => "%s supprim&eacute; leur widget twitter.",
	        
		
	);
					
	add_translation("fr",$french);

?>