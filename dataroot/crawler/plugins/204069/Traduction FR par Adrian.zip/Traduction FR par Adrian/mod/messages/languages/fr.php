<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Messages",
            'messages:back' => "retourner aux messages",
			'messages:user' => "Votre boîte de réception",
			'messages:sentMessages' => "Envoyer des messages",
			'messages:posttitle' => "%s's messages: %s",
			'messages:inbox' => "Boîte de réception",
			'messages:send' => "Envoyer un message",
			'messages:sent' => "Messages envoyés",
			'messages:message' => "Message",
			'messages:title' => "Titre",
			'messages:to' => "A",
            'messages:from' => "De",
			'messages:fly' => "Envoyer ",
			'messages:replying' => "Message en réponse à",
			'messages:inbox' => "Boîte de réception",
			'messages:sendmessage' => "Envoyer un message",
			'messages:compose' => "Envoyer un message",
			'messages:sentmessages' => "Messages envoyés",
			'messages:recent' => "Messages récents",
            'messages:original' => "Message d'origine",
            'messages:yours' => "Votre message",
            'messages:answer' => "Répondre",
			'messages:toggle' => 'Tout cocher/décocher',
			'messages:markread' => 'Marqué comme lu',
			
			'messages:new' => 'Nouveau message',
	
			'notification:method:site' => 'Site',
	
			'messages:error' => 'Un problème est apparu lors de la sauvegarde de votre message. Veuillez recommencer s\'il vous plait.',
	
			'item:object:messages' => 'Messages',
	
		/**
		 * Status messages
		 */
	
			'messages:posted' => "Votre message a été correctement envoyé.",
			'messages:deleted' => "Votre message a été correctement supprimé.",
			'messages:markedread' => "Vos messages ont été correctement marqués comme lus.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Vous avez un nouveau message!',
			'messages:email:body' => "Vous avez un nouveau message de la part de %s :

			
%s


Pour voir vos messages, cliquez ici:

	%s

Pour envoyer %s un message, cliquez ici:

	%s

Vous ne pouvez pas répondre à ce mail.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Désolé; vous devez écrire quelque chose dans le corps du message afin de pouvoir le sauvegarder.",
			'messages:notfound' => "Désolé; nous n'avons pu trouver le message spécifié.",
			'messages:notdeleted' => "Désolé; nous ne pouvons pas supprimer ce message.",
			'messages:nopermission' => "Vous n'avez pas la permission de modifier ce message.",
			'messages:nomessages' => "Il n'y a aucun message a afficher.",
			'messages:user:nonexist' => "Nous n'avons pu trouver le destinataire dans la base de donéees des utilisateurs.",
	
	);
					
	add_translation("fr",$french);

?>