<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "S'exprimer",
			'thewire:user' => "Messages de %s",
			'thewire:posttitle' => "%s's notes on the wire: %s",
			'thewire:everyone' => "Tous les messages",
	
			'thewire:read' => "Vos messages",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Poster un message",
		    'thewire:text' => "Un message dans le module \"S'exprimer\"",
			'thewire:reply' => "R&eacute;pondre",
			'thewire:via' => "via",
			'thewire:wired' => "Message envoy&eacute;",
			'thewire:charleft' => "caract&egrave;res restants",
			'item:object:thewire' => "Messages",
			'thewire:notedeleted' => "message supprim&eacute;",
			'thewire:doing' => "Envie de vous exprimer ? Faites le savoir :",
			'thewire:newpost' => 'Nouveau message',
			'thewire:addpost' => 'Poster un message',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s a dit",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => ".",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Ce widget affiche les derniers messages post&eacute;s sur le site via le module "S\'exprimer"',
	        'thewire:yourdesc' => 'Ce widget affiche vos derniers messages sur le site via le module "S\'exprimer"',
	        'thewire:friendsdesc' => 'Ce widget affichera les derniers messages post&eacute;s par vos contacts sur le site via le module "S\'exprimer"',
	        'thewire:friends' => 'Vos contacts dans le module "S\'exprimer"',
	        'thewire:num' => 'Nombre d\'&eacute;l&eacute;ments &agrave; afficher',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Votre message a &eacute;t&eacute; correctment post&eacute;.",
			'thewire:deleted' => "Votre message a &eacute;t&eacute; correctment supprim&eacute;.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "D&eacute;sol&eacute; ! Vous devez &eacute;crire quelque chose dans le champs texte avant de le sauvegarder.",
			'thewire:notfound' => "D&eacute;sol&eacute; ! Impossible de trouver le message demand&eacute;.",
			'thewire:notdeleted' => "D&eacute;sol&eacute; ! Impossible de supprimer ce message.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Your SMS number if different from your mobile number (mobile number must be set to public for the wire to be able to use it). All phone numbers must be in international format.",
			'thewire:channelsms' => "The number to send SMS messages to is <b>%s</b>",
			
	);
					
	add_translation("fr",$french);

?>