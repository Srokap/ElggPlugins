<?php

	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blogue",
			'blogs' => "Blogues",
			'blog:user' => "Blogue de %s",
			'blog:user:friends' => "Blogues des amis de %s",
			'blog:your' => "Vos billets de blogue",
			'blog:posttitle' => "Blogue de %s : %s",
			'blog:friends' => "Blogues d'amis",
			'blog:yourfriends' => "Les derniers blogues de vos amis",
			'blog:everyone' => "Blogues du site",
			'blog:newpost' => "Nouveau billet de blogue",
			'blog:via' => "via blogue",
			'blog:read' => "Lire ce blogue",
	
			'blog:addpost' => "Ecrire un billet",
			'blog:editpost' => "Editer un billet",
	
			'blog:text' => "Texte du blogue",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Billets du blogue',
	
			'blog:never' => 'jamais',
			'blog:preview' => 'Visualiser',
	
			'blog:draft:save' => 'Sauvegarder le brouillon',
			'blog:draft:saved' => 'Dernier brouillon sauvegard&eacute;',
			'blog:comments:allow' => 'Autoriser les commentaires',
	
			'blog:preview:description' => 'Ceci est une visualisation non sauvegardée de votre blogue.',
			'blog:preview:description:link' => 'Pour continuer d\'&eacute;diter ou sauvegarder votre billet, cliquez ici',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s a &eacute;crit",
	        'blog:river:updated' => "%s modifi&eacute;",
	        'blog:river:posted' => "%s post&eacute;",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "un nouveau billet de blogue publi&eacute;",
	        'blog:river:update' => "un billet de blogue modifi&eacute;",
	        'blog:river:annotate' => "un commentaire sur ce billet",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Votre billet de blogue a &eacute;t&eacute; correctement publi&eacute;.",
			'blog:deleted' => "Votre billet de blogue a &eacute;t&eacute; correctement supprim&eacute;.",
	
		/**
		 * Error messages
		 */
	
			'blog:error' => 'Une erreur est survenue. Veuillez r&eacute;essayer s\'il vous plait.',
			'blog:save:failure' => "Votre billet de blogue n\'a pas pu &ecirc;tre sauvegard&eacute;. Veuillez r&eacute;essayer s\'il vous plait.",
			'blog:blank' => "Vous devez saisir un titre et un corps de texte avant de pouvoir publier ce billet.",
			'blog:notfound' => "D&eacute;sol&eacute; nous ne trouvons pas le billet de blogue sp&eacute;cifi&eacute;.",
			'blog:notdeleted' => "D&eacute;sol&eacute; nous ne trouvons pas supprimer ce billet de blogue.",
	
	);
					
	add_translation("fr",$french);

?>