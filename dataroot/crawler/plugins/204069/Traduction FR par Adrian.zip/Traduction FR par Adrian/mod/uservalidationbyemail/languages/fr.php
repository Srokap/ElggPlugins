<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$french = array(
	
		'email:validate:subject' => "%s veuillez confirmer votre adresse mail!",
		'email:validate:body' => "Bonjour %s,

Veuillez confirmer votre adresse mail en cliquant sur le lien suivant:

%s
",
		'email:validate:success:subject' => "Adresse mail validée %s!",
		'email:validate:success:body' => "Bonjour %s,
			
Félicitations, vous avez validé votre adresse mail.",
	
		
		'email:confirm:success' => "Vous avez validé votre adresse mail!",
		'email:confirm:fail' => "Votre adresse mail ne peut pas être vérifiée...",
	
		'uservalidationbyemail:registerok' => "Afin d'activer votre compte, vous devez confirmer votre adresse mail en cliquant sur le lien qui vient de vous être envoyé."
	
	);
					
	add_translation("fr",$french);
?>