<?php

	$french = array(
	
			'custom:bookmarks' => "Derniers bookmarks",
			'custom:groups' => "Groupes les + r&eacute;cents",
			'custom:files' => "Fichiers les + r&eacute;cents",
			'custom:blogs' => "Derniers ajouts de blogs",
			'custom:members' => "Nouveaux membres",
			'custom:nofiles' => "Il n'y a aucun fichier pour l'instant",
			'custom:nogroups' => "Il n'y a aucun fichier pour l'instant",	
	
	);
					
	add_translation("fr",$french);

?>