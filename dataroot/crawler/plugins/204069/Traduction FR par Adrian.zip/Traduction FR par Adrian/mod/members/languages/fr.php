<?php

	$french = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Membres du site",
	    'members:online' => "Membres actuellement connectés",
	    'members:active' => "membres du site",
	    'members:searchtag' => "Recherche de membre par mot clé",
	    'members:searchname' => "Recherche de membre par nom",
	   
		
	);
					
	add_translation("fr",$french);

?>