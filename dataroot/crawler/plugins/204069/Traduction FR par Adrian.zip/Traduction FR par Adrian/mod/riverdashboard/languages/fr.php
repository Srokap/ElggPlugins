<?php

	$french = array(

		'mine' => 'Moi',
		'filter' => 'Filtre',
		'riverdashboard:useasdashboard' => "Remplacer le tableau de bord par d&eacute;faut par ce tableau des derni&egrave;res actualit&eacute;s ?",
		'activity' => 'Actualit&eacute;',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Annonces du site",
		'sitemessages:posted' => "Post&eacute;",
		'sitemessages:river:created' => "L'administrateur du site, %s,",
		'sitemessages:river:create' => "a post&eacute; une nouvelle annonce",
		'sitemessages:add' => "Ajouter une annonce globale sur le tableau de bord",
		'sitemessage:deleted' => "Annonce globale supprim&eacute;e",
		
		'river:widget:noactivity' => 'Aucune actualit&eacute; trouv&eacute;.',
		'river:widget:title' => "Actualit&eacute;",
		'river:widget:description' => "Afficher vos derni&egrave;res actualit&eacute;s.",
		'river:widget:title:friends' => "Actualit&eacute;s des ami(e)s",
		'river:widget:description:friends' => "Afficher ce que font vos ami(e)s.",
		'river:widgets:friends' => "Amis",
		'river:widgets:mine' => "Moi",
		'river:widget:label:displaynum' => "Nombres d'entr&eacute;es &agrave; afficher:",
		'river:widget:type' => "Quel type d'actualit&eacute;s souhaitez-vous afficher ? Les v&ocirc;tres ou celles de vos ami(e)s ?",
		'item:object:sitemessage' => "Messages du site",
	);
					
	add_translation("fr",$french);

?>