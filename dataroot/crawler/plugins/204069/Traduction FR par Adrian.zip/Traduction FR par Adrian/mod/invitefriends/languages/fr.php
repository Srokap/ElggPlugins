<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$french = array(

		'friends:invite' => 'Inviter des amis',
		'invitefriends:introduction' => 'Pour inviter des amis &agrave; vous rejoindre sur ce r&eacute;seau, entrez leur adresses email ci-dessous (une adresse par ligne):',
		'invitefriends:message' => 'Saisissez un message qu\'ils recevront avec leur invitation:',
		'invitefriends:subject' => 'Invitation &agrave; rejoindre %s',
	
		'invitefriends:success' => 'Vos amis ont &eacute;t&eacute; invit&eacute;s.',
		'invitefriends:failure' => 'Vos amis n\'ont pas pu &ecirc;tre invit&eacute;s.',
	
		'invitefriends:message:default' => '
Salut,

Je t\'invite &agrave; rejoindre mon r&eacute;seau social sur %s.',
		'invitefriends:email' => '
Vous avez &eacute;t&eacute; invit&eacute; a rejoindre %s par %s. Le message suivant est inclu:

%s

Pour rejoindre ce r&eacute;seau, cliquez sur le lien suivant:
	%s

Cet ami sera automatiquement ajout&eacute; en tant que contact au moment de la cr&eacute;ation de votre compte.',
	
	);
					
	add_translation("fr",$french);
?>