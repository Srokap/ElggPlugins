<?php

	/**
	 * phpBB 3 Integration Plug-in Registration action
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @link http://www.ircaserta.com/
	 */

	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	global $CONFIG;

	global $CONFIG;
	
	action_gatekeeper();

	// Get variables
		$username = get_input('username');
		$password = get_input('password');
		$password2 = get_input('password2');
		$email = get_input('email');
		$name = get_input('name');
		$friend_guid = (int) get_input('friend_guid',0);
		$invitecode = get_input('invitecode');
		
		$admin = get_input('admin');
		if (is_array($admin)) $admin = $admin[0];
		
		
		if (!$CONFIG->disable_registration)
		{
	// For now, just try and register the user
	
			try {
				if (
					(
						(trim($password)!="") &&
						(strcmp($password, $password2)==0) 
					) &&
					($guid = register_user($username, $password, $name, $email, false, $friend_guid, $invitecode))
				) {
					
					$new_user = get_entity($guid);
					if (($guid) && ($admin))
					{
						admin_gatekeeper(); // Only admins can make someone an admin
						$new_user->admin = 'yes';
					}

					// Memorizzo i dati mancanti per phpBB
					$ip = $_SERVER['REMOTE_ADDR'];
					$emailhash = (int) (crc32(strtolower($email)) . strlen($email));
					$md5password = md5($password);

					// Aggiungo l'utente su phpBB
					insert_data("INSERT into phpbb_users (user_type, group_id, user_ip, user_regdate, username, username_clean, user_password, user_passchg, user_email, user_email_hash, user_lastvisit, user_lastmark, user_inactive_reason, user_inactive_time, user_lang, user_timezone, user_dst, user_dateformat, user_style, user_actkey) values (1, 2, '$ip', UNIX_TIMESTAMP(NOW()), '$username', LOWER('$username'), '$md5password', UNIX_TIMESTAMP(NOW()), '$email', '$emailhash', 0, UNIX_TIMESTAMP(NOW()), 1, UNIX_TIMESTAMP(NOW()), 'it', '1.00', '1', '|j F Y|, G:i', 1, '')");

					$query = get_data_row("SELECT MAX(user_id) AS max_user_id FROM phpbb_users LIMIT 1");
					$maxid = $query->max_user_id;

					insert_data("INSERT INTO phpbb_user_group (group_id, user_id, group_leader, user_pending) VALUES (2, '$maxid', 0, 0)");

					// Aggiungo la relationship
					add_entity_relationship($guid, "phpbbuser", $maxid);
					
					// Send user validation request on register only
					request_user_validation($guid);
					
					if (!$new_user->admin)
						$new_user->disable('new_user');	// Now disable if not an admin
					
					system_message(sprintf(elgg_echo("registerok"),$CONFIG->sitename));
					
					forward(); // Forward on success, assume everything else is an error...
				} else {
					register_error(elgg_echo("registerbad"));
				}
			} catch (RegistrationException $r) {
				register_error($r->getMessage());
			}
		}
		else
			register_error(elgg_echo('registerdisabled'));
			
		$qs = explode('?',$_SERVER['HTTP_REFERER']);
		$qs = $qs[0];
		$qs .= "?u=" . urlencode($username) . "&e=" . urlencode($email) . "&n=" . urlencode($name) . "&friend_guid=" . $friend_guid;
		
		forward($qs);

?>