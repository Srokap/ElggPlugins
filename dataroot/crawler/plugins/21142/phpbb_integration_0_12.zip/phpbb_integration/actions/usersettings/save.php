<?php
	/**
	 * phpBB 3 Integration Plug-in Save settings action
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @link http://www.ircaserta.com/
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");
	global $CONFIG;

	gatekeeper();
	action_gatekeeper();

	$user_id = get_input('guid');
	$user = "";
	
	if (!$user_id)
		$user = $_SESSION['user'];
	else
		$user = get_entity($user_id);

	// Recupero l'id utente su phpBB
	$phpbbuserid = get_phpbb_userid($user->username);

	$password = get_input('password');
	$password2 = get_input('password2');
	$email = get_input('email');

	// Se i dati ci sono
	if (($phpbbuserid) && ($password!=""))
	{
		if (strlen($password)>=4)
		{
			if ($password == $password2) {
				
				$md5password = md5($password);

				// Aggiorno i dati sul database
				update_phpbb_password($phpbbuserid, $md5password);
			}
		}
	}
		
	if (strcmp($email,$user->email)!=0) {
	
		if (!get_user_by_email($email))	{
			
			if ($user->email != $email) {

				// Aggiorno l'email su phpbb (disattiva automaticamente l'utente)
				update_phpbb_email($phpbbuserid, $email);
			}
		}
	}

	trigger_plugin_hook('usersettings:save','user');
	
	forward($_SERVER['HTTP_REFERER']);

?>