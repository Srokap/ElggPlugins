<?php
	/**
	 * phpBB 3 Integration Plug-in
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @link http://www.ircaserta.com/
	 */

	$english = array(

		"phpbb_integration:tableprefix" => "phpBB table prefix",
		"phpbb_integration:synchusers" => "Synch phpBB users",
		"phpbb_integration:synchronize" => "Sinchronize",
		"phpbb_integration:registered" => "Registered",
	);
	
	add_translation("en",$english);

?>
