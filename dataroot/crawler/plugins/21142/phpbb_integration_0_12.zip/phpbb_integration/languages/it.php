<?php
	/**
	 * phpBB 3 Integration Plug-in
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @link http://www.ircaserta.com/
	 */

	$italian = array(

		"phpbb_integration:tableprefix" => "Prefisso tabelle phpBB",
		"phpbb_integration:synchusers" => "Sincronizza utenti phpBB",
		"phpbb_integration:synchronize" => "Sincronizza",
		"phpbb_integration:registered" => "Registrato",

	);
	
	add_translation("it",$italian);

?>
