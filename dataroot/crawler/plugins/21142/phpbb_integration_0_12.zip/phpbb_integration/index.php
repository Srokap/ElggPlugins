<?php
	/**
	 * phpBB Integration plugin.
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n
	 * @link http://www.ircaserta.com/
	 */

	// Admins only
	admin_gatekeeper();
	set_page_owner($_SESSION['guid']);
	set_context('admin');
	
	// Recupero gli utenti non sincronizzati
	$query = "SELECT {$CONFIG->dbprefix}users_entity.guid, phpbb_users.user_id ";
	$query .= "FROM {$CONFIG->dbprefix}entities LEFT JOIN {$CONFIG->dbprefix}users_entity ON ({$CONFIG->dbprefix}entities.guid = {$CONFIG->dbprefix}users_entity.guid) ";
	$query .= "LEFT JOIN phpbb_users ON (LOWER({$CONFIG->dbprefix}users_entity.username) = phpbb_users.username_clean) ";	
	$query .= "WHERE type = 'user' AND phpbb_users.user_id IS NULL";

	$result = get_data($query);
	if (count($result)) 
	{
		$access_status = access_get_show_hidden_status();
		access_show_hidden_entities(true);
		foreach ($result AS $result_guid) 
		{
			$user = get_entity(intval($result_guid->guid));
			if (($user) && ($user instanceof ElggUser))
			{
				$body .= elgg_view('phpbb_integration/synchusers', array('entity' => $user));
			}
		}
		access_show_hidden_entities($access_status);
	}
	$title = elgg_view_title(elgg_echo('phpbb_integration:synchusers'));
	// Draw the page
	page_draw(elgg_echo('phpbb_integration:synchusers'), elgg_view_layout('two_column_left_sidebar', '', $title . $body));
	
?>
