<?php
	/**
	 * phpBB 3 Integration Plug-in
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @link http://www.ircaserta.com/
	 */

	function get_phpbb_userid($username) {

		$phpbbPrefix = get_plugin_setting('tableprefix','phpbb_integration');
		
		// I get the phpbb userid from the phpbbtable seeking for the username_clean (index) because
		// i was not able to add a relationship with a table doesn't exist If you know how, please contact me
		$usernameclean = strtolower($username);
		
		$query = get_data_row("SELECT user_id FROM {$phpbbPrefix}users WHERE username_clean = '$usernameclean'");
		$phpbbuserid = $query->user_id;

		return $phpbbuserid;
	}
 
	function update_phpbb_password($phpbbuserid, $password) {

		if (($phpbbuserid) && ($password)) {

			// Recupero il prefisso delle tabelle
			$phpbbPrefix = get_plugin_setting('tableprefix','phpbb_integration');
			
			// Eseguo la query
			update_data("UPDATE {$phpbbPrefix}users SET user_password = '$password', user_passchg = UNIX_TIMESTAMP(NOW()) WHERE user_id = '$phpbbuserid'");

			return true;
		}
	}

	function update_phpbb_email($phpbbuserid, $email) {

		if (($phpbbuserid) && ($email)) {

			// Recupero il prefisso delle tabelle
			$phpbbPrefix = get_plugin_setting('tableprefix','phpbb_integration');

			// Calcolo l'email hash
			$emailhash = (int) (crc32(strtolower($email)) . strlen($email));;
			
			// Eseguo la query
			update_data("UPDATE {$phpbbPrefix}users SET user_email = '$email', user_email_hash = '$emailhash' WHERE user_id = '$phpbbuserid'");

			// Disattivo l'utente
			deactivate_phpbbuser($phpbbuserid);
		}

		return true;
	}
	
	// Funzione per l'attivazione dell'utente su phpBB
	function activate_phpbbuser($event, $object_type, $object) {

		global $CONFIG;

		$phpbbPrefix = get_plugin_setting('tableprefix','phpbb_integration');

		// I get the phpbb userid from the phpbbtable seeking for the username_clean (index) because
		// i was not able to add a relationship with a table doesn't exist If you know how, please contact me
		$usernameclean = strtolower($object->username);
		$phpbbuserid = get_phpbb_userid($object->username);

		// Eseguo la query ed aggiorno le statistiche
		update_data("UPDATE {$phpbbPrefix}users SET user_type = 0, user_inactive_time = 0 WHERE username_clean = '$usernameclean'");
		update_data("UPDATE {$phpbbPrefix}config SET config_value = '" . $object->username . "' WHERE config_name = 'newest_username'");
		update_data("UPDATE {$phpbbPrefix}config SET config_value = '" . $phpbbuserid . "' WHERE config_name = 'newest_user_id'");
		update_data("UPDATE {$phpbbPrefix}config SET config_value = config_value +1 WHERE config_name = 'num_users'");

		return true;
	}

	// Funzione per la disattivazione dell'utente su phpBB
	function deactivate_phpbbuser($phpbbuserid) {

		global $CONFIG;

		$phpbbPrefix = get_plugin_setting('tableprefix','phpbb_integration');

		// I get the phpbb userid from the phpbbtable seeking for the username_clean (index) because
		// i was not able to add a relationship with a table doesn't exist If you know how, please contact me
		$usernameclean = strtolower($username);

		// Eseguo la query
		update_data("UPDATE {$phpbbPrefix}users SET user_type = 1, user_inactive_time = UNIX_TIMESTAMP(NOW()) WHERE user_id = '$phpbbuserid'");

	}

	function phpbb_integration_init() {

		global $CONFIG;

		// Sovrascrivo l'azione di default per la registrazione
		register_action('register', true, $CONFIG->pluginspath . "phpbb_integration/actions/register.php");

		// Aggiungo le azioni per la modifica dei dati su phpbb
		register_action('usersettings/savephpbb', true, $CONFIG->pluginspath . "phpbb_integration/actions/usersettings/save.php");

		// Registro l'event handler dell'attivazione con relativa funzione
		register_elgg_event_handler('enable', 'user', 'activate_phpbbuser');

		// Se l'amministratore � loggato
		if (isadminloggedin())
		{
			register_page_handler('phpbb_integration','phpbb_integration_page_handler');
			add_submenu_item(elgg_echo('phpbb_integration:synchusers'), $CONFIG->wwwroot . 'pg/phpbb_integration/', 10000);
		}

		return true;
	}

	/**
	 * phpBB_integration Page.
	 */
	function phpbb_integration_page_handler($page) 
	{
		
		global $CONFIG;
		include($CONFIG->pluginspath . 'phpbb_integration/index.php'); 
		
	}

	// Init
	register_elgg_event_handler('init','system','phpbb_integration_init');

?>