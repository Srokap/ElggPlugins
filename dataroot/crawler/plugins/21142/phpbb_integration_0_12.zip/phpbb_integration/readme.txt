* Elgg phpBB Integration PlugIn
*
* @package ElggPhpBB
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
* @link http://www.ircaserta.com/

-----

Hi People,

This my new phpBB Forum integration plugin for Elgg 1.2.

It make possible to use a phpBB forum in conjuction with Elgg.

It is at the beginning stage, it doesn't login automatically yet,
anyway if it is possible I'll do.

Read the installation guide and post your feedbacks on the plugin
page on http://community.elgg.org.

Feedbacks and ratings are really apreciated, the only thing
I ask in exchange :)

TO-DO
-----

- Requesting password reset doesn't affect phpbb
- Unique login
- Holding the phpbb session active during Elgg navigation
- Holding the phpbb session active during phpBB navigation
- Elgg Topbar on phpBB (to have notifies, check messages etc.)
- Widgets to show last posts and forum statistics on your profile page and your dashboard


INSTALLATION
-----

- phpBB

Install your phpBB in any directory on any domain (probably
in a future version I'll force to install it on the same directory
of Elgg, in order to deal with cookies).

Go on the phpBB administration panel and:

General > User registration settings > Account activation = Disable
Posting > Private message settings > Private messaging = no (you can 
enable it if you want, but there is always the elgg messaging)
System > User Control Panel > Profile > Disable "Edit Profile" and 
"Edit account settings"

- Elgg

Copy the phpbb_integration directory in your /mod and activate it.
On the same page, click on "more info" and insert your phpBB's 
table prefix (sorry, now works just with phpbb_ prefix)

- Add-On

If you installed phpBB in some directory of your Elgg site, you
can replace your phpbb memberlist.php with the one provided in the
forum directory, in order to link phpBB usernames to their Elgg
profile Page.

IMPORTANT NOTE:

If you're upgrading this please run this query on your mysql server
selecting the elgg database:

UPDATE phpbb_users SET username_clean = LOWER(username);

Please test the draft for the user synchro tool and make me know if
does it work. It should show all unsynchronized users.
 

That's all :)

UPDATES
-----

phpBB Integration Plug-in 0.12
- Some fix
- memberlist.php for your phpBB forum
- a "draft" for the user synchro tool

phpBB Integration Plug-in 0.1
- First release


-----
Sergio De Falco aka SGr33n

www.ircaserta.com
