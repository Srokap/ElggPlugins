<?php
	/**
	 * phpBB 3 Integration Plug-in
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @link http://www.ircaserta.com/
	 */

	// Recupero i valori delle impostazioni
	$tableprefix = get_plugin_setting('tableprefix', 'phpbb_integration');

?>
<p>
	<label><?php echo elgg_echo('phpbb_integration:tableprefix'); ?> <input type="text" name="params[tableprefix]" value="<?php echo $tableprefix; ?>" />
</p>