<?php
	/**
	 * phpBB 3 Integration Plug-in
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @link http://www.ircaserta.com/
	 */

	$form_body = "<div class=\"settings_form\">" . elgg_view("usersettings/user") . "</div>";
	$form_body .= "<p>" . elgg_view('input/submit', array('value' => elgg_echo('save'))) . "</p>";

	echo elgg_view('input/form', array('action' => "{$vars['url']}action/usersettings/savephpbb", 'body' => $form_body));
?>