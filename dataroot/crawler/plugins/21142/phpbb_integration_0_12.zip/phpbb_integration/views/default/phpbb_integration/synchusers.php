<?php
	/**
	 * phpBB Integration plugin.
	 * 
	 * @package pluginPhpBBIntegration
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright 2009 Sergio De Falco aka SGr33n
	 * @link http://www.ircaserta.com/
	 */
	
	$friendlytime = friendly_time($vars['entity']->time_created);

	$info .= "<p>{$vars['entity']->username} (<a href=\"mailto:{$vars['entity']->email}\">{$vars['entity']->email}</a>)</p>";
	$info .= '<p class="owner_timestamp">' . elgg_echo('phpbb_integration:registered') . ": {$friendlytime}</p>";
	$info .= '<p style="text-align:right;">';
	$info .= "<a href=\"javascript:void(0);\" onclick=\"alert('not working yet');\">" . elgg_echo('phpbb_integration:synchronize') . '</a>';
	$info .= '</p>';
	$icon = elgg_view("graphics/icon", array('size' => 'small', 'entity' => $vars['entity']));
	echo elgg_view_listing($icon, $info);
		
?>