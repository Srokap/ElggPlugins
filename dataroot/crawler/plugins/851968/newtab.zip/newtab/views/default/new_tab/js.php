<?php 

?>

//replace yoursite.com with your actual domain name !!

$(function(){
    $('a[href^="http://"]')
        .not('[href*="yoursite.com"]')
        .attr('target','_blank');
});  
   
   