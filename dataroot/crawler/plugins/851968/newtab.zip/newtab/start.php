<?php
/**
 * Elgg Magic Topbar plugin
 *
 * @package ElggMagicTopbar
 */

elgg_register_event_handler('init', 'system', 'new_tab_init');

/**
 * Extending elgg js with a few lines of jQuery
 */
function new_tab_init() {
	elgg_extend_view('js/elgg','new_tab/js');
}