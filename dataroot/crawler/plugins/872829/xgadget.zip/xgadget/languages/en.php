<?php

$english = array(
	
/**
 *	Gadgets widget details
 */
		
	'xgadget:add:to:page' => "Add Google Gadgets to your page",
	'xgadget:code' => 'Insert your gadget code',
	'xgadget:codewhere' => 'Get gadgets from <a href="http://www.google.com/ig/directory?synd=open" target="_blank" >http://www.google.com/ig/directory?synd=open</a>.',
	'xgadget:no:iframes' => 'Iframes are not supported',
	'xgadget:google:gadgets' => "Google Gadgets",
	'xgadget:height' => 'Height (px)',
	'xgadget:none' => 'No gadgets configured',
	'xgadget:title' => 'Title',
		
/**
 * Gadgets widget river
 */
	        
	//generic terms to use
	'xgadget:river:created' => "%s added gadget.",
	'xgadget:river:updated' => "%s updated gadget.",
	'xgadget:river:delete' => "%s deleted gadget.",		
);
					
add_translation("en",$english);
