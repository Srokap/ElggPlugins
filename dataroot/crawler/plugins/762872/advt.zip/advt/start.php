<?php

	/**
	 * Elgg Ads Integration plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Thuvalpakshi
	 * @copyright Thuvalpakshi
	 * @link  http://satheesh.anushaktinagar.net
	 */

		
		function advt_init() {
			
	
		}

		register_elgg_event_handler('init','system','advt_init');
				
		
?>