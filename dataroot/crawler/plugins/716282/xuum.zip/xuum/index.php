<?php
if (isloggedin()) forward('pg/dashboard/');
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Milocker Xuum Theme</title>
	<link rel="stylesheet" href="mod/xuum/css/style.css" type="text/css" media="all" />
	
	<!--[if IE 6]>
		<link rel="stylesheet" href="mod/xuum/css/ie.css" type="text/css" media="all" />	
	<![endif]-->
	
	<script type="text/javascript" src="mod/xuum/js/jquery-1.4.2.min.js"></script>
	
	<script type="text/javascript" src="mod/xuum/js/jquery.jcarousel.js"></script>
	
	<!-- Cufon -->
	<script type="text/javascript" src="mod/xuum/js/cufon-yui.js"></script>
	
	<script type="text/javascript" src="mod/xuum/js/MyriadPro.font.js"></script>
	<script type="text/javascript" src="mod/xuum/js/ArialBold.font.js"></script>
	
	
	<script type="text/javascript" src="mod/xuum/js/jquery-func.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="mod/xuum/css/images/favicon.ico" />
</head>
<body>

	<style>
.messages {
	background:#ccffcc;
	color:#000000;
	padding:3px 10px 3px 10px;
	z-index: 8000;
	margin:0;
	position:fixed;
	top:30px;
	width:969px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border:4px solid #00CC00;
	cursor: pointer;
}
.messages_error {
	border:4px solid #D3322A;
	background:#F7DAD8;
	color:#000000;
	padding:3px 10px 3px 10px;
	z-index: 8000;
	margin:0;
	position:fixed;
	top:30px;
	width:969px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	cursor: pointer;
}
.closeMessages {
	float:right;
	margin-top:17px;
}
.closeMessages a {
	color:#666666;
	cursor: pointer;
	text-decoration: none;
	font-size: 80%;
}
.closeMessages a:hover {
	color:black;
}
</style>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
	
	

<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>

<!-- Header -->
<div id="header">
	<div class="shell">
		<!-- Logo -->
		<h1 id="logo"><a href="<?php echo $vars['url']; ?>">Milocker Xuum</a></h1>
		<!-- /Logo -->
		
		<!-- Navigation -->
		<div id="navigation">
			<ul>
				<li><a href="<?php echo $vars['url']; ?>" class="active">HOME</a></li>
				
				<li><a href="<?php echo $vars['url']; ?>pg/expages/read/Terms/">TERMS</a></li>
				<li><a href="<?php echo $vars['url']; ?>pg/expages/read/Privacy/">PRIVACY</a></li>
				<li><a href="#">ABOUT</a></li>
			</ul>
		</div>
		<!-- /Navigation -->
	</div>
</div>
<!-- /Header -->

<!-- Intro -->
<div id="intro">
	<div class="shell">
		<!-- Slider Holder -->
		<div class="slider-holder">
			<ul>
				<!-- Offer -->
				<li>
					<div class="offer-image">
						<img src="mod/xuum/css/images/offer-image-1.jpg" alt="" />
					</div>
					<div class="offer-data">
						<h3>Slide One</h3>
						
						<div class="entry">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin sed odio et ante lipsum amet dorem en lobortis. Quisque eleifend, arcu a dictum varius.</p>
							<p><strong>Lorem ipsum dolor</strong> sit amet, con- sectetuer adipiscing elit. Proin sed odio et ante adipiscing lobortis. Quisque eleif- end, arcu a <a href="#">dictum</a> varius, risus neque venenatis arcu</p>
						</div>
						
						
					</div>
				</li>
				<!-- /Offer -->
				
				<!-- Offer -->
				<li>
					<div class="offer-image">
						<img src="mod/xuum/css/images/offer-image-2.jpg" alt="" />
					</div>
					<div class="offer-data">
						<h3>Slide Two</h3>
						
						<div class="entry">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin sed odio et ante lipsum amet dorem en lobortis. Quisque eleifend, arcu a dictum varius.</p>
							<p><strong>Lorem ipsum dolor</strong> sit amet, consectetuer adipiscing elit. Proin sed odio et ante adipiscing lobortis. Quisque eleifend, arcu a <a href="#">dictum</a> varius, risus neque venenatis arcu</p>
						</div>
						
						
					</div>
				</li>
				<!-- /Offer -->
				
				<!-- Offer -->
				<li>
					<div class="offer-image">
						<img src="mod/xuum/css/images/offer-image-3.jpg" alt="" />
					</div>
					<div class="offer-data">
						<h3>Slide Three</h3>
						
						<div class="entry">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin sed odio et ante lipsum amet dorem en lobortis. Quisque eleifend, arcu a dictum varius.</p>
							<p><strong>Lorem ipsum dolor</strong> sit amet, consectetuer adipiscing elit. Proin sed odio et ante adipiscing lobortis. Quisque eleifend, arcu a <a href="#">dictum</a> varius, risus neque venenatis arcu</p>
						</div>
						
						
					</div>
				</li>
				<!-- /Offer -->
				
				<!-- Offer -->
				<li>
					<div class="offer-image">
						<img src="mod/xuum/css/images/offer-image-4.jpg" alt="" />
					</div>
					<div class="offer-data">
						<h3>Slide Four</h3>
						
						<div class="entry">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin sed odio et ante lipsum amet dorem en lobortis. Quisque eleifend, arcu a dictum varius.</p>
							<p><strong>Lorem ipsum dolor</strong> sit amet, consectetuer adipiscing elit. Proin sed odio et ante adipiscing lobortis. Quisque eleifend, arcu a <a href="#">dictum</a> varius, risus neque venenatis arcu</p>
						</div>
						
						
					</div>
				</li>
				<!-- /Offer -->
				
				<!-- Offer -->
				<li>
					<div class="offer-image">
						<img src="mod/xuum/css/images/offer-image-5.jpg" alt="" />
					</div>
					<div class="offer-data">
						<h3>Slide Five</h3>
						
						<div class="entry">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Proin sed odio et ante lipsum amet dorem en lobortis. Quisque eleifend, arcu a dictum varius.</p>
							<p><strong>Lorem ipsum dolor</strong> sit amet, consectetuer adipiscing elit. Proin sed odio et ante adipiscing lobortis. Quisque eleifend, arcu a <a href="#">dictum</a> varius, risus neque venenatis arcu</p>
						</div>
						
						
					</div>
				</li>
				<!-- /Offer -->
			</ul>
		</div>
		<!-- /Slider Holder -->
		<!-- Slider Navigation -->
		<div class="slider-navigation">
			<ul>
				<li><a href="#">1</a></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#">4</a></li>
				<li><a href="#">5</a></li>
			</ul>
		</div>
		<!-- /Slider Navigation -->
	</div>
</div>
<!-- /Intro -->

<!-- Main -->
<div id="main">
	<div class="shell">
		<!-- Box -->
		<div class="box">
		<center>
			<h2>Login</h2>
			</center>

			<div class="buttons">
				<center>
<div id="welcome-box" class="buttons">
<div id="login-box" class="buttons">
<?php
									$form_body = 
									"
										<p>
										<label>"
										.elgg_echo('username')
										."<br />"
										.elgg_view
										(
											'input/text'
											,array
											(
												'internalname' => 'username'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										"<label>"
										.elgg_echo('password')
										."<br />" 
										.elgg_view
										(
											'input/password'
											,array
											(
												'internalname' => 'password'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										elgg_view
										(
											 'input/submit'
											,array
											(
												'value' => elgg_echo('login')
											)
										)
										."</p>
									";
									echo elgg_view
									(
										'input/form'
										,array
										(
											 'body' => $form_body
											,'action' => ""
											.$vars['url']
											."action/login"
										)
									);
									?>

</center>
			</div>
			</div>
			</div>
		</div>
		<!-- /Box -->
		<!-- Box -->
		<div class="box">
		<center>
			<h2>Newest Members</h2>
			</center>
			<div class="entry">
				<!-- News -->	
				<div class="news">
					<ul>
						<li>
							          <?php
$users_max = 25;
        $onlyWithAvatar = "no";
if(empty($onlyWithAvatar) || $onlyWithAvatar == "no")
  {$users = get_entities('user','',null,null,$users_max,0);} 
else 
  {$users = get_entities_from_metadata('icontime', '', 'user', '', 0, $users_max);}
           $wallIconSize = "small";
shuffle($users);
foreach($users as $user){

echo elgg_view("profile/icon",array('entity' => $user, 'size' => 'small', 'override' => 'true'));

} ?>

						</li>
					</ul>
				</div>
				<!-- /News -->
			</div>
			
			
		</div>
		<!-- /Box -->
		<!-- Box -->
		<div class="box last-box">
		<center>
			<h2>Sign Up</h2>
			</center>
			<center>
							
								<div id="register-box">
								<?php
								////////////////////////////////////////////////////////////////
								$form_body  = "<p><label>" . elgg_echo('name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('username') . "<br />" . elgg_view('input/text' , array('internalname' => 'username', 'class' => "general-textarea", 'value' => $username)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password' , array('internalname' => 'password', 'class' => "general-textarea")) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('passwordagain') . "<br />" . elgg_view('input/password' , array('internalname' => 'password2', 'class' => "general-textarea")) . "</label><br />";
								$form_body .= elgg_view('register/extend');
								$form_body .= elgg_view('input/captcha');
								if ($admin_option) {
									$form_body .= elgg_view('input/checkboxes', array('internalname' => "admin", 'options' => array(elgg_echo('admin_option'))));
								}
								$form_body .= elgg_view('input/hidden', array('internalname' => 'friend_guid', 'value' => $vars['friend_guid']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'invitecode', 'value' => $vars['invitecode']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'register'));
								$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('register'))) . "</p>";
								?>
								<div id="register-box">
								<h2>
								<?php
								//echo elgg_echo('register');
								?>
								</h2>
								<?php
								////////////////////////////////////////////////////////////////
								echo elgg_view
								(
									'input/form'
									,array
									(
										'body' => $form_body
										,'action' => "{$vars['url']}action/register"
									)
								);
								?>
								
								
							</div><!-- div id="welcome-box" -->
							
							</center>
			
			
		</div>
		<!-- /Box --></div>
		<div class="cl">&nbsp;</div>
	
</div></div>
<!-- /Main -->

<!-- Footer -->
<div id="footer">
	<div class="shell">
		<!-- Mini Nav --> 
		<div class="footer-navigation"> 
		
					
				
			<ul> 
				<li><a href="#"><img src="mod/xuum/css/images/soc1.gif" alt="" /></a></li>
					<li><a href="#"><img src="mod/xuum/css/images/soc2.gif" alt="" /></a></li>
					<li><a href="#"><img src="mod/xuum/css/images/soc3.gif" alt="" /></a></li>
					<li><a href="#"><img src="mod/xuum/css/images/soc4.gif" alt="" /></a></li>
				<li><a href="<?php echo $vars['url']; ?>" class="active">HOME</a></li>
				
				<li><a href="<?php echo $vars['url']; ?>pg/expages/read/Terms/">TERMS</a></li>
				<li><a href="<?php echo $vars['url']; ?>pg/expages/read/Privacy/">PRIVACY</a></li>
				<li><a href="#">ABOUT</a></li>
			</ul> 
		</div> 
		<!-- /Mini Nav --> 
		
		<!-- Copyrights --> 
		<p class="right"> 
			Copyright 2010 | Sitename. Developed by <a href="http://www.milocker.com/socialweb">SocialWeb</a>
		</p> 
		<!-- /Copyrights --> 

		<div class="cl">&nbsp;</div> 
		<center><span style="width: 100%; font-family: helvetica; font-size: 10px;">Designed by <a href="http://www.milocker.com/socialweb" style="font-family: helvetica; color: gray; font-size: 11px;">SocialWeb Team</a> | </span></center>
	</div>
</div>
										 
<!-- /Footer -->
</body>
</html>