<?php

	$german = array(

			'custom:bookmarks' => "Neueste Lesezeichen",
			'custom:groups' => "Neueste Gruppen",
			'custom:files' => "Neueste Dateien",
			'custom:blogs' => "Neueste Blogs",
			'custom:members' => "Neueste Mitglieder",
			'custom:nofiles' => "Es sind noch keine Dateien verfügbar",
			'custom:nogroups' => "Es gibt noch keine Gruppen",

	);

	add_translation("de",$german);

?>