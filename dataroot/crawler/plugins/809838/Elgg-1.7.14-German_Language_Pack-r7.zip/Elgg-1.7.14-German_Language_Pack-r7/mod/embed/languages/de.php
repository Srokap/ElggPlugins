<?php

	$german = array(

		'media:insert' => 'Medien einbetten / hochladen',

		'embed:instructions' => 'Klicke eine verfügbare Datei an, um sie in Deinen Eintrag einzubetten.',

		'embed:media' => 'Medien einbetten',
		'upload:media' => 'Medien hochladen',

		'embed:file:required' => 'Das Hochladen von Dateien ist nicht möglich. Der Systemadministrator muß möglicherweise dafür das File-Plugin oder ein vergleichbares Plugin aktivieren.',

	);

	add_translation("de",$german);

?>