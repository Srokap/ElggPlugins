<?php

	$german = array(

		'members:members' => "Mitglieder",
	    'members:online' => "Derzeit angemeldete Mitglieder",
	    'members:active' => "Mitglieder der Community",
	    'members:searchtag' => "Mitgliedersuche via Tags",
	    'members:searchname' => "Mitgliedersuche via Name",

		'members:label:newest' => 'Neueste',
		'members:label:popular' => 'Beliebt',
		'members:label:active' => 'Im Moment aktiv',
		'members:search:name' => 'Benutzername',
		'members:search:tags' => 'Tags',

	);

	add_translation("de",$german);

?>