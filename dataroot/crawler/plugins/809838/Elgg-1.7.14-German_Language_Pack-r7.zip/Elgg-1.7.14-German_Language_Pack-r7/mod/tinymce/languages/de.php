<?php

	$german = array(

		/**
		 * Menu items and titles
		 */

		'tinymce:remove' => "Editor aktivieren/deaktivieren",

	);

	add_translation("de",$german);

?>