<?php

	$german = array(

		'categories' => 'Kategorien',
		'categories:settings' => 'Seiten-Kategorien einrichten',
		'categories:explanation' => 'Um einige Kategorien festzulegen, die für die gesamte Community-Seite benutzt werden, gebe sie bitte im folgenden mit Komma getrennt ein. Kompatible Tools werden die Kategorien dann anzeigen, wenn Mitglieder Einträge erzeugen oder editieren.',
		'categories:save:success' => 'Seiten-Kategorien wurden gespeichert.',
		'categories:results' => "Einträge für die Seiten-Kategorie: %s",

	);

	add_translation("de",$german);

?>