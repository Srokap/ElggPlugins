<?php
	/**
	 * Elgg diagnostics language pack.
	 *
	 * @package ElggDiagnostics
	 */

	$german = array(

		'captcha:entercaptcha' => 'Bitte den im Bild angezeigten Text eingeben',
		'captcha:captchafail' => 'Entschuldigung, der eingegebene Text stimmt nicht mit dem im Bild angezeigten Text überein.',

	);

	add_translation("de",$german);
?>