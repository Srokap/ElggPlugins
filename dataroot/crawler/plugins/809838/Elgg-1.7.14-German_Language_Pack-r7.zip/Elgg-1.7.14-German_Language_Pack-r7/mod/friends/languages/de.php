<?php

$german = array(

	/**
	 * Friends widget
	 */
	'friends:widget:description' => "Auflistung einiger Deiner Freunde.",
	'friends:num_display' => "Anzahl der anzuzeigenden Freunde",
	'friends:icon_size' => "Icon-Größe",
	'friends:tiny' => "sehr klein",
	'friends:small' => "klein",
);

add_translation("de", $german);
