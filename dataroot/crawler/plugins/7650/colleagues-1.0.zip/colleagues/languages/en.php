<?php
  $english = array(
    'friends' => "Colleagues",
    'friends:yours' => "Your colleagues",
    'friends:owned' => "%s's colleagues",
    'friend:add' => "Add colleagues",
    'friend:remove' => "Remove colleagues",
    'friends:add:successful' => "You have successfully added %s as a colleague.",
    'friends:add:failure' => "We couldn't add %s as a colleague. Please try again.",
    'friends:remove:successful' => "You have successfully removed %s from your colleagues.",
    'friends:remove:failure' => "We couldn't remove %s from your colleagues. Please try again.",
    'friends:none' => "This user hasn't added anyone as a colleague yet.",
    'friends:none:you' => "You haven't added anyone as a colleague! Search for your interests to begin finding people to follow.",
    'friends:none:found' => "No colleagues were found.",
    'friends:of:none' => "Nobody has added this user as a colleague yet.",
    'friends:of:none:you' => "Nobody has added you as a colleague yet. Start adding content and fill in your profile to let people find you!",
    'friends:of' => "Colleagues of",
    'friends:of:owned' => "People who have made %s a colleague",
    'friends:num_display' => "Number of colleagues to display",
    'friends' => "Colleagues",
    'friends:of' => "Colleagues of",
    'friends:collections' => "Collections of colleagues",
    'friends:collections:add' => "New colleagues collection",
    'friends:addfriends' => "Add colleagues",
    'friends:collectionname' => "Collection name",
    'friends:collectionfriends' => "Colleagues in collection",
    'friends:river:created' => "%s added the colleagues widget.",
    'friends:river:updated' => "%s updated their colleagues widget.",
    'friends:river:delete' => "%s removed their colleagues widget.",
    'friends:river:add' => "%s add someone as a colleague.",

    'river:relationship:friend' => "is now colleagues with",

    'friend:newfriend:subject' => "%s has made you a colleague!",
    'friend:newfriend:body' => "%s has made you a colleague!

To view their profile, click here:

%s

You cannot reply to this email.",
    );

    add_translation("en", $english);
?>
