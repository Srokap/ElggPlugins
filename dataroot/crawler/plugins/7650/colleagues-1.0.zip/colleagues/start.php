<?php	
  /**
   *  start.php
   *  Colleagues (as opposed to friends).
   */
  function colleagues_init()
  {
  	global $CONFIG;
			
  	register_translations($CONFIG->pluginspath . "colleagues/languages/");
  }
?>