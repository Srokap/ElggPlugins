<?php if (0) { ?><style><?php } ?>

div.tagsinput { border:1px solid #CCC; background: #FFF; padding:5px 5px 0 5px; width:98%; overflow-y: auto;
   border-radius: 5px; -moz-border-radius:5px; -webkit-border-radius:5px;
}
div.tagsinput span.tag { border: 1px solid #4690D6; -moz-border-radius:2px; -webkit-border-radius:2px; display: block; float: left; padding: 3px 0 3px 5px; text-decoration:none; color: #4690D6; margin-right: 5px; margin-bottom:5px;}
div.tagsinput span.tag a { font-weight: bold; color: #4690D6; text-decoration:none; position:relative; top:-1px; padding:3px 5px}
div.tagsinput input { width:17em; margin:0; border:1px solid transparent; padding:3px 0 3px; background: transparent; color: #000; outline:0;  margin-right:5px; }
div.tagsinput div { display:block; float: left; }
.tags_clear { clear: both; width: 100%; height: 0; }
.not_valid {background: #FBD8DB !important; color: #90111A !important;}

