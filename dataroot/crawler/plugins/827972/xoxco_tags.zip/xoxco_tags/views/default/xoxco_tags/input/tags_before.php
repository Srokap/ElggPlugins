<?php

elgg_load_js('elgg.tags');
