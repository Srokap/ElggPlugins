<?php
	global $CONFIG;
	
	
?>
<div class="footer_toolbar_links">
	| <a href="<?php echo $vars['url']; ?>pg/faq/"><?php echo elgg_echo('faq:shorttitle'); ?></a>&nbsp;
</div>