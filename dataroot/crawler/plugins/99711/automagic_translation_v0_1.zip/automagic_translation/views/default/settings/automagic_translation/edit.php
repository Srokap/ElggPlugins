<?php
?>
<p>
	<?php echo elgg_echo('automagic_translation:settings:detectlanguage:label'); ?>
	
	<select name="params[detectlanguage]">
		<option value="1" <?php if ($vars['entity']->detectlanguage=="1") echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="0" <?php if ($vars['entity']->detectlanguage!="1") echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
	
</p>