Automagic_translation
Copyright (C) 2009 Gabriel Monge-Franco. All rights reserved.  Todos los derechos reservados.
http://gabriel.mongefranco.com
See contributions.txt and individual change logs for contributions made by the community.

-- Introduction --
Automagic_translation is an open source (GPL3) plug-in for Elgg that automagically translates an Elgg site to the user's browser language, instead of using a default site-wide language.


-- Installation --
Copy the entire Automagic_translation directory to the mod directory on your Elgg installation.
NOTE: as of Elgg 1.5, you also need to replace the \engine\lib\languages.php file in your Elgg installation with the one provided by this plug-in.

-- Removal --
Simply disable the plug-in from the Tools Administration, or delete the plug-in directory.
NOTE: as of version 0.1 of this plug-in, you need to configure the plug-in to "No" (don't autodetect language) before disabling it.
