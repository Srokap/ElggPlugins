<?php

	$german = array(
	
		/**
		 * Configuration settings
		 */

			'automagic_translation:settings:detectlanguage:label' => 'Ermitteln Sie die Sprache, die vom Besucher gesprochen wird.',	
	);
					
	add_translation('de',$german);

?>