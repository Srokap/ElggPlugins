<?php

	$italian = array(
	
		/**
		 * Configuration settings
		 */

			'automagic_translation:settings:detectlanguage:label' => 'Rilevi la lingua parlata dall&#39;ospite.',	
	);
					
	add_translation('it',$italian);

?>