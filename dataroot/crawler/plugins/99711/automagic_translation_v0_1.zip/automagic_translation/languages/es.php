<?php

	$spanish = array(
	
		/**
		 * Configuration settings
		 */

			'automagic_translation:settings:detectlanguage:label' => 'Detectar el idioma del visitante.',	
	);
					
	add_translation('es',$spanish);

?>