<?php

	$french = array(
	
		/**
		 * Configuration settings
		 */

			'automagic_translation:settings:detectlanguage:label' => 'D&#233;tectez la langue parl�e par le visiteur.',	
	);
					
	add_translation('fr',$french);

?>