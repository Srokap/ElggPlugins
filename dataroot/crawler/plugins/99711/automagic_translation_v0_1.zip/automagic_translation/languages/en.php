<?php

	$english = array(
	
		/**
		 * Configuration settings
		 */

			'automagic_translation:settings:detectlanguage:label' => 'Detect the language spoken by the visitor.',	
	);
					
	add_translation('en',$english);

?>