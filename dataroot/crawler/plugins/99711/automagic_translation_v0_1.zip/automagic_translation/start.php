<?php
	/**
	 * automagic_translation
	 * An Elgg plug-in that automagically translates an Elgg site to the user's browser language,
	 * instead of using a default site-wide language.
	 * 
	 * @package automagic_translation
	 * @license http://www.gnu.org/licenses/gpl-3.0.html GNU Public License version 3
	 * @author Gabriel Monge-Franco <gabrielinux@mongefranco.com>
	 * @copyright Copyright (C) 2009 Gabriel Monge-Franco. All rights reserved.  Todos los derechos reservados.
	 * @link http://gabriel.mongefranco.com
	 */

	/**
	 * automagic_translation initialization
	 *
	 * These parameters are required for the event API, but we won't use them:
	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */

	
		function automagic_translation_init() {
			
			// Load system configuration
				global $CONFIG;
				
/*
				// Autodetect browser language for non-logged in users
				if (is_null(get_loggedin_user())) {
					// Attempt detection of browser language if user is not logged in
					$browser_lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
					if (isset($browser_lang)) {
						$CONFIG->language = $browser_lang;
					}
				}
*/

				if (get_plugin_setting('detectlanguage','automagic_translation') == "1") {
					if (!get_config('detectlanguage')) {
						set_config('detectlanguage', true);
					}
					if ((!isset($CONFIG->detectlanguage)) || (is_null($CONFIG->detectlanguage)) || ($CONFIG->detectlanguage==false)) {
						$CONFIG->detectlanguage = true;
					}
				} else {
					if (get_config('detectlanguage')) {
						set_config('detectlanguage', false);
					}
					if ((!isset($CONFIG->detectlanguage)) || (is_null($CONFIG->detectlanguage)) || ($CONFIG->detectlanguage==true)) {
						$CONFIG->detectlanguage = false;
					}
				}
		}
	

	// Make sure the automagic_translation initialization function is called on initialization
		register_elgg_event_handler('init','system','automagic_translation_init', 1);
	
	// Register actions
		// No actions to register

?>