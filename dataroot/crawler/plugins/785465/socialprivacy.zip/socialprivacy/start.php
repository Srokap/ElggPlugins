<?php

	/* Blackpod Elgg Theme
	* @copyright Juipo.com 2008-2010
	* @link http://juipo.com/
	*/
	
	/* Initialise the theme */
	function social_privacy_init(){
	
	}
	
	// Initialise log browser
	register_elgg_event_handler('init','system','social_privacy_init');
	
?>