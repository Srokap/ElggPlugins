<?php
	echo $vars['url'] . "mod/theme_eosx_blue_lava/graphics/user_icons/defaultlarge.gif";
?>