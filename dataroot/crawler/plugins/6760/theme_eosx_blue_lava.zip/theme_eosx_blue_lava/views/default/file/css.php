<?php
	/**
	 * File CSS extender
	 * 
	 * @package Elgg File Repository
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
?>

p.filerepo_owner {
	margin:0;
	padding:0;
}
.filerepo_owner_details {
	/* font-size: 90%; */
	margin:0;
	padding:0;
	line-height: 1.2em;
}
.filerepo_owner_details small {
	color:#666666;
}
.filerepo_owner .usericon {
	margin-right: 5px;
	float: left;
}

.filerepo_download a {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#666666;
	border:none;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	width: auto;
	height: 25px;
	padding: 2px 6px 2px 6px;
	margin:10px 0 10px 0;
	cursor: pointer;
}

.filerepo_download a:hover {
	background: #8f8d8d;
	text-decoration: none;
}

/* FILE REPRO WIDGET VIEW */
.filerepo_widget_singleitem {
	background-color: #eeeeee;
	margin:0 0 10px 0;
	min-height:60px;
	display:block;
}
.filerepo_listview_icon {
	float: left;
	margin-right: 10px;
}
.filerepo_timestamp {
	color:#666666;
	margin:0;
}
.filerepo_listview_desc {
	display:none;
	padding:0 5px 10px 0;
	line-height: 1.2em;
}
.filerepo_widget_content {
	margin-left: 70px;
}
.filerepo_title {
	margin:0;
	padding:6px 5px 0 0;
	line-height: 1.2em;
}

.collapsable_box #filerepo_widget_layout {
	margin:0;
}

/* widget gallery view */
.filerepo_widget_galleryview img {
	padding:1px;
    border:1px solid #efefef;
    margin:1px;
    cursor:pointer;
}
.filerepo_widget_galleryview img:hover {
	background:#333333;
}

/* SINGLE ITEM VIEW */
.filerepo_file {
	margin-bottom: 50px;
}
.filerepo_file .filerepo_title_owner_wrapper {
	min-height:60px;
	background-color: #eeeeee;
}
.filerepo_title_owner_wrapper .filerepo_title,
.filerepo_title_owner_wrapper .filerepo_owner {
	margin-left: 70px !important;
}
.filerepo_file .filerepo_maincontent {
	margin-left: 70px;
}
.filerepo_file .filerepo_icon {
	width: 70px;
	position: absolute;
	background-color: #eeeeee;
}
.filerepo_file .filerepo_title {
	margin:0;
	padding:1px 4px 5px 10px;
	line-height: 1.2em;
}
.filerepo_file .filerepo_owner {
	padding:0 0 0 10px;
}
.filerepo_file .filerepo_description {
	margin:10px 0 0 0;
	padding:0 0 0 10px;
}
.filerepo_download,
.filerepo_controls {
	padding:0 0 0 10px;
	margin:0;
}
.filerepo_file .filerepo_description p {
	padding:0 0 5px 0;
	margin:0;
}
.filerepo_file .filerepo_specialcontent img {
	padding:5px;
	margin:0 0 0 10px;
	border:1px dotted silver; 
	max-width:560px;
}
.filerepo_tags {
	padding:0 0 10px 10px;
	margin:0;
}

/* file repro gallery items */
.search_gallery .filerepo_controls {
	padding:0;
}
.search_gallery .filerepo_title {
	font-weight: bold;
	line-height: 1.1em;
	margin:0 0 10px 0;
}

.filerepo_gallery_item {
	margin:0;
	padding:0;
	text-align: center;
}
.filerepo_gallery_item .filerepo_controls p {
	margin-top:10px;
}
.filerepo_gallery_item .filerepo_controls a {
	color:#666666;
	padding-right:10px;
	padding-left:10px;
}
.filerepo_gallery_item .filerepo_controls a:hover {
	color:#cc3300;
}
.filerepo_gallery_item p {
	margin:0;
	padding:0;
}
.search_gallery .filerepo_comments {
	font-size:90%;
}

.filerepo_user_gallery_link {
	float:right;
	margin:5px 5px 5px 50px;
}
.filerepo_user_gallery_link a {
	padding:2px 25px 5px 0;
	background: transparent url(<?php echo $vars['url']; ?>_graphics/icon_gallery.gif) no-repeat right top;
	display:block;
}
.filerepo_user_gallery_link a:hover {
	background-position: right -40px;
}

/* Embed code */

    #actual_embed_media {
        height:100px;
        border:2px solid #efefef;
        background:#fff;
        overflow: auto;
        display:none;
    }
    #actual_embed_media p {
        color:#000;
    }
    #actual_embed_media img {
        width: 50px;
    }

	/* ------------------------------------------------------------------------
	This you can edit.
------------------------------------------------------------------------- */

	div.pictureHolder .top .left { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/tl.gif) top left no-repeat; } /* Top left corner */
	div.pictureHolder .top .middle { background: #fff; } /* Top pattern/color */
	div.pictureHolder .top .right { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/tr.gif) top left no-repeat; } /* Top right corner */
	
	div.pictureHolder .content { background-color: #fff; } /* Content background */
	div.pictureHolder .content a.next:hover { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnNext.gif) center right no-repeat; cursor: pointer; } /* Next button */
	div.pictureHolder .content a.previous:hover { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnPrevious.gif) center left no-repeat; cursor: pointer; } /* Previous button */
	div.pictureHolder .content a.expand { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnExpand.gif) top left no-repeat; cursor: pointer; } /* Expand button */
	div.pictureHolder .content a.expand:hover { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnExpand.gif) bottom left no-repeat; cursor: pointer; } /* Expand button hover */
	div.pictureHolder .content a.contract { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnContract.gif) top left no-repeat; cursor: pointer; } /* Contract button */
	div.pictureHolder .content a.contract:hover { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnContract.gif) bottom left no-repeat; cursor: pointer; } /* Contract button hover */
	div.pictureHolder .content a.close { width: 61px; height: 22px; background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnClose.gif) center left no-repeat; cursor: pointer; } /* Close button */
	
	div.pictureHolder .content .details .nav a.arrow_previous { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/arrow_previous.gif) top left no-repeat; } /* The previous arrow in the bottom nav */
	div.pictureHolder .content .details .nav a.arrow_next { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/arrow_next.gif) top left no-repeat; } /* The next arrow in the bottom nav */
	
	div.pictureHolder .bottom .left { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/bl.gif) top left no-repeat; } /* Bottom left corner */
	div.pictureHolder .bottom .middle { background: #fff; } /* Bottom pattern/color */
	div.pictureHolder .bottom .right { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/br.gif) top left no-repeat; } /* Bottom right corner */
	
	div.pictureHolder .loaderIcon { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/loader.gif) center center no-repeat; } /* Loader icon */
	
	div.prettyPhotoTitle div.prettyPhotoTitleLeft { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/ttl.gif) top left no-repeat; }
	div.prettyPhotoTitle div.prettyPhotoTitleRight { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/ttr.gif) top left no-repeat; }
	div.prettyPhotoTitle div.prettyPhotoTitleContent { background: url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/ttp.gif) top left repeat-x; }

/* ------------------------------------------------------------------------
	DO NOT CHANGE
------------------------------------------------------------------------- */

div.prettyPhotoOverlay{background:#000;position:absolute;top:0;left:0;z-index:9500;width:100%}div.pictureHolder{position:absolute;z-index:10000;width:100px}div.pictureHolder .top{position:relative;height:20px}* html div.pictureHolder .top{padding:0 20px}div.pictureHolder .top .left{position:absolute;left:0;width:20px;height:20px}div.pictureHolder .top .middle{position:absolute;left:20px;right:20px;height:20px}* html div.pictureHolder .top .middle{position:static}div.pictureHolder .top .right{position:absolute;top:0;left:auto;right:0;width:20px;height:20px}div.pictureHolder .content{position:relative;text-align:left;width:100%;height:40px}div.pictureHolder .content .details{display:none;margin:10px 15px 0 20px}div.pictureHolder .content .details p.description{display:none;float:left;margin:0}div.pictureHolder .content .details .nav{float:left;margin:4px 0 0 0}div.pictureHolder .content .details .nav p{float:left;margin:0 4px}div.pictureHolder .content .details .nav a.arrow_previous,div.pictureHolder .content .details .nav a.arrow_next{float:left;display:block;width:8px;height:9px;text-indent:-10000px;margin-top:4px}div.pictureHolder .content .details .nav a.disabled{background-position:0 -10px;cursor:default}div.pictureHolder .content div.hoverContainer{position:absolute;z-index:10000;top:0;left:0;width:100%}div.pictureHolder .content a.next{position:relative;z-index:2000;display:block;float:right;text-indent:-10000px;width:49%;height:100%;background:url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnNext.gif) 10000px 50% no-repeat}div.pictureHolder .content a.previous{cursor:pointer;display:block;text-indent:-10000px;width:49%;height:100%;background:url(<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/graphics/prettyPhoto/btnNext.gif) 10000px 50% no-repeat}div.pictureHolder .content a.expand,div.pictureHolder .content a.contract{position:absolute;z-index:20000;top:10px;right:30px;cursor:pointer;display:none;text-indent:-10000px;width:20px;height:20px}div.pictureHolder .content a.close{float:right;display:block;text-indent:-10000px}div.pictureHolder .bottom{position:relative;height:20px}* html div.pictureHolder .bottom{padding:0 20px}div.pictureHolder .bottom .left{position:absolute;left:0;width:20px;height:20px}div.pictureHolder .bottom .middle{position:absolute;left:20px;right:20px;height:20px}* html div.pictureHolder .bottom .middle{position:static}div.pictureHolder .bottom .right{position:absolute;top:0;left:auto;right:0;width:20px;height:20px}div.pictureHolder .loaderIcon{display:none;position:absolute;top:50%;left:50%;margin:-12px 0 0 -12px;width:24px;height:24px}div.pictureHolder #fullResImageContainer{width:100%;text-align:center}div.prettyPhotoTitle{display:none;position:absolute;top:0;left:0;z-index:9999;color:#fff;font-size:13px}div.prettyPhotoTitle div.prettyPhotoTitleLeft,div.prettyPhotoTitle div.prettyPhotoTitleRight{float:left;width:19px;height:23px;overflow:hidden}div.prettyPhotoTitle div.prettyPhotoTitleContent{float:left;line-height:23px}