<?php
	echo $vars['url'] . "mod/theme_eosx_blue_lava/graphics/group_icons/defaultmedium.gif";
?>