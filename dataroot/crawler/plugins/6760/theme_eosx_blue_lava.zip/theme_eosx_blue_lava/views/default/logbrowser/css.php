<?php

?>

#logbrowser_search_area {
	margin: 3px;
}
#logbrowserSearchform {
	padding: 20px;
	background-color: #dedede;
}
.log_entry {
	margin: 2px;
	width: 655px;
	font-size: 80%;
}
.log_entry td {
}
.log_entry_user {
	width: 160px;
	background-color: #eee;
}
.log_entry_time {
	width: 260px;
	background-color: #eee;
	padding:2px;
}
.log_entry_item {
	background-color: #eee;
	
}
.log_entry_action {
	width: 75px;
	background-color: #eee;
}