<?php

	/**
	 * Elgg pageshell when logged out
	 * The standard HTML header that displays across the site
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 * 
	 * @uses $vars['config'] The site configuration settings, imported
	 * @uses $vars['title'] The page title
	 * @uses $vars['body'] The main content of the page
	 * @uses $vars['messages'] A 2d array of various message registers, passed from system_messages()
	 */
	 
	 // Set title
		if (empty($vars['title'])) {
			$title = $vars['config']->sitename;
		} else if (empty($vars['config']->sitename)) {
			$title = $vars['title'];
		} else {
			$title = $vars['config']->sitename . ": " . $vars['title'];
		}
		
		global $autofeed;
		if (isset($autofeed) && $autofeed == true) {
			$url = $url2 = full_url();
			if (substr_count($url,'?')) {
				$url .= "&view=rss";
			} else {
				$url .= "?view=rss";
			}
			if (substr_count($url2,'?')) {
				$url2 .= "&view=odd";
			} else {
				$url2 .= "?view=opendd";
			}
			$feedref = <<<END
			
	<link rel="alternate" type="application/rss+xml" title="RSS" href="{$url}" />
	<link rel="alternate" type="application/odd+xml" title="OpenDD" href="{$url2}" />
			
END;
		} else {
			$feedref = "";
		}
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title><?php echo $title; ?></title>
	<!-- include links to jQuery here? -->
	<script type="text/javascript" src="<?php echo $vars['url']; ?>vendors/jquery/jquery-1.2.6.pack.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>vendors/jquery/jquery-ui-personalized-1.5.packed.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>pg/js/initialise_elgg.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/views/default/js/jquery.lavalamp.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/views/default/js/jquery.easing.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/views/default/js/jquery.prettyPhoto.js"></script>

<?php

	global $pickerinuse;
	if (isset($pickerinuse) && $pickerinuse == true) {

?>
	
	<!-- only needed on pages where we have friends collections and/or the friends picker-->
	<script type="text/javascript" src="<?php echo $vars['url']; ?>vendors/jquery/jquery-easing.1.2.pack.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>vendors/jquery/jquery-easing-compatibility.1.2.pack.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>pg/js/friendsPickerv1.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/views/default/js/jquery.lavalamp.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/views/default/js/jquery.easing.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/theme_eosx_blue_lava/views/default/js/jquery.prettyPhoto.js"></script>
<?php

	}

?>
	
	<!-- include the default css file -->
	<link rel="stylesheet" href="<?php echo $vars['url']; ?>_css/css.css" type="text/css" />
	<?php 

		echo $feedref;
		echo elgg_view('metatags',$vars); 
		
	?>

<script type="text/javascript">
	var query = new Object();
	window.location.search.replace(
	new RegExp( "([^?=&]+)(=([^&]*))?", 'g' ),
		function( $0, $1, $2, $3 ){
			query[ $1 ] = $3;
		}
	);
	easing = query['e'] || 'Circ';
	
	function loadEasing(e) {
		location.href = location.pathname+'?e='+e;
	}
	
	function setEasing(e) {
		loadLamps(e);
	}

// for dynamic easing changes		
	function loadLamps(easing) {
		$('#lavaLampBasicImage').lavaLamp({
			fx: 'easeIn'+easing,
			speed: 600
		});
	}
	
// jquery initialize:
	$(function() {
		loadLamps(easing);
		
		$('select#easing option[value='+easing+']').attr('selected','selected');
		$('.easingLabel').text(easing);
	});

</script>

<script type="text/javascript" charset="utf-8">
	$(document).ready(function(){
		$("a[rel^='prettyPhoto']").prettyPhoto();
	});
</script>
</head>

<body>

<?php echo elgg_view('page_elements/elgg_topbar', $vars); ?>
	
<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
<!-- site name -->
<div id="logo"><a href="<?php echo $vars['url']; ?>">
		<img src="<?php echo $vars['url']; ?>_graphics/spacer.gif" width="120px" height="36px" border="0" /></a>
	
	</div>

<div id="menu-osx">
<ul id="lavaLampBasicImage" class="lamp">

<!-- 
<li><a href="<?php echo $vars['url']; ?>">Home</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/messages"><?php echo elgg_echo("messages"); ?></a></li>
<li><a href="<?php echo $vars['url']; ?>pg/groups/member/"><?php echo elgg_echo("groups"); ?></a></li>
<li><a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("blog"); ?></a></li>
<li><a href="<?php echo $vars['url']; ?>pg/pages/owned/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("pages"); ?></a></li>
<li><a href="<?php echo $vars['url']; ?>pg/friends"><?php echo elgg_echo("friends"); ?></a></li>
<li><a href="<?php echo $vars['url']; ?>pg/file/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("file"); ?></a></li> -->
<?php 
	$menu = get_register('menu');
			foreach($menu as $item) {
    			
    				echo " <li> <a href=\"{$item->value}\">" . $item->name . "</a></li>";
    			
			} 
		?>
</ul>
</div>
<div class="clearfloat"></div>
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
