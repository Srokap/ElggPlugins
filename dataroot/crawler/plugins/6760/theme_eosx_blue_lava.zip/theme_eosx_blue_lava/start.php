<?php

    /**
     * eosx theme Fish Eye
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function eosxbluelava_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','eosxbluelava_init');
	
?>