<?php
	global $CONFIG;
	admin_gatekeeper();
	$group_guid = get_input('group_guid');
	$group = get_entity($group_guid);
	$group->delete();
		
	forward($vars['url'] . 'mod/vazco_moderate/admingrouplist.php');
	
?>