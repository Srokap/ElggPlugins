<?php
	global $CONFIG;
	admin_gatekeeper();
	
	$group = get_entity(get_input('group_guid'));
	$group->accepted = 'yes';
	$group->access_id = ACCESS_PUBLIC;


	forward($vars['url'] . 'mod/vazco_moderate/admingrouplist.php');
	
?>