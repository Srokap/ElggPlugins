<?php
	function moderation_init() {
		global $CONFIG;
		 
		extend_view('css','vazco_moderate/css');
		extend_view('groups/groupprofile','vazco_moderate/buttons', 1);
		
		register_elgg_event_handler('create','group','vazco_moderate_group_created_handler',501);
		register_elgg_event_handler('update','group','vazco_moderate_group_updated_handler',600);
		 
		
		register_action("vazco_moderate/accept",false, $CONFIG->pluginspath . "vazco_moderate/actions/accept.php");
		register_action("vazco_moderate/delete",false, $CONFIG->pluginspath . "vazco_moderate/actions/delete.php");
		
		
	}
	function vazco_moderate_group_updated_handler($event, $object_type, $object){
		if ($object->accepted == 'no'){
			$object->access_id = ACCESS_PRIVATE;
		}
		return true;
	}
	function vazco_moderate_check_access($entity){
		if ($entity->accepted =='no'){
			$_REQUEST['__moderate_access_fix'] = 1;
			$entity->access_id = ACCESS_PRIVATE;
			$entity->save();
		}
	}
	
	function vazco_moderate_group_created_handler($event, $object_type, $object){
		if ($object instanceof ElggGroup) {
			// if not admin - set access_id to private, otherwise - default page access 
			if (true || !isadminloggedin()) {
				$object->access_id = ACCESS_PRIVATE;
				$object->accepted = 'no';
				$object->save();
				$owner = $object->getOwnerEntity(); 
			}else{
				$object->accepted = 'yes';
			}
		}
	}
	register_elgg_event_handler('init','system','moderation_init');
	 
?>