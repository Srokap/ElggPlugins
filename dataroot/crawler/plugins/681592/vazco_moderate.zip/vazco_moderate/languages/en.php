<?php
 
  $english = array(	
		'vazco_moderate:grouplist' => 'Moderation of groups',
		'vazco_moderate:notaccepted' => 'Groups for moderation',
		'vazco_moderate:accept_group' => 'Accept group',
		'vazco_moderate:delete_group' => 'Delete group',
		'vazco_moderate:waitingformoderation' => 'This group is currently available only for you. It awaits to be accepted by a moderator',
		'vazco_moderate:notify:newgroup:title' => 'New group was created',
		'vazco_moderate:notify:newgroup:body' => 'User <a href="%s">%s</a> created a new group: <a href="%s">%s</a>. It\'s awaiting for your moderation.',
  		'vazco_moderate:notify:groupaccepted:title' => 'Group moderated succesfully',
  		'vazco_moderate:notify:groupaccepted:body' => 'Your group <a href="%s">%s</a> was accepted by administrator.',
  		'vazco_moderate:notify:grourejected:title' => 'Group rejected',
  		'vazco_moderate:notify:grourejected:body' => 'Your group %s was deleted by administrator as inappropriate.',
	);
 
  add_translation("en",$english);
 
?>