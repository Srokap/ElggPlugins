<?php
	if (isadminloggedin()) {
		global $CONFIG;
			
		/**
		 * A simple view to provide the user with group filters and the number of group on the site
		 **/
		 
		 $num_groups = $vars['count'];
		 if(!$num_groups)
		 	$num_groups = 0;
		 	
		 $filter = $vars['filter'];
		 
		 //url
		 $url = $vars['url'] . "pg/groups/world/";

?>
<div class="group_count">
	<?php
		echo $num_groups . " " . elgg_echo("groups:count");
	?>
</div>
<?php
	} 
?>