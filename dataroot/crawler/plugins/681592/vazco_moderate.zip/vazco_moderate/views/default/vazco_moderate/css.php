a.add_topic_button:hover {
	background:#0054A7 none repeat scroll 0 0;
	color:white;
	text-decoration:none;
}

a.add_topic_button {
	background:#4690D6 none repeat scroll 0 0;
	border:medium none;
	color:white;
	cursor:pointer;
	font-family:Arial,Helvetica,sans-serif;
	font-size:12px;
	font-size-adjust:none;
	font-stretch:normal;
	font-style:normal;
	font-variant:normal;
	font-weight:bold;
	height:auto;
	line-height:100%;
	margin:0;
	padding:3px 6px;
	width:auto;
}

.left{
	float: left;
}
.right{
	float: right;
}