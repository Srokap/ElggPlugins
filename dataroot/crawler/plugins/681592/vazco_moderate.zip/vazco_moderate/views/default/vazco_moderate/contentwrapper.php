<?php
	echo $vars['body'];

	
?>