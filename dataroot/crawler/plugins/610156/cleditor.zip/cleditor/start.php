<?php

        /**
         * @return void
         * @author Michael Jett
         * @email mjett@mitre.org
         *
         * Please note that this plugin requires jQuery v1.4.2 or greater!
         */

        function cleditor_init() {

            // Load system configuration
            global $CONFIG;

            // Add our CSS
            extend_view('css', 'cleditor/css');
            // Add our JS
            extend_view('js/initialise_elgg', 'cleditor/js');

        }

        // Make sure the status initialisation function is called on initialisation
        register_elgg_event_handler('init', 'system', 'cleditor_init', 9999);

?>