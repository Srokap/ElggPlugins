<?

/**
 * This appends our CLeditor JS to the elgg global JS file
 */

global $CONFIG;

// include core CLeditor js files and additional plugins
fpassthru(fopen($CONFIG->pluginspath . '/cleditor/CLEditor1_2_6/jquery.cleditor.js', 'rb'));
fpassthru(fopen($CONFIG->pluginspath . '/cleditor/CLEditor1_2_6/plugins/jquery.cleditor.pastefromword.js', 'rb'));
fpassthru(fopen($CONFIG->pluginspath . '/cleditor/CLEditor1_2_6/plugins/jquery.cleditor.icon.js', 'rb'));
fpassthru(fopen($CONFIG->pluginspath . '/cleditor/CLEditor1_2_6/plugins/jquery.cleditor.table.js', 'rb'));

?>


// cleditor js
// render hidden textbox when shown

$(function() {

    var renderCleditor = function() {

        var isiPad = navigator.userAgent.match(/iPad/i) != null;
        var isiPhone = navigator.userAgent.match(/iPhone/i) != null;

        // don't render CLEditor on iPad or iPhone
        if (!(isiPad || isiPhone)) {
            $("textarea:visible.cleditor").cleditor({
                width:        652, // width not including margins, borders or padding
                height:       250, // height not including margins, borders or padding

                colors:       // colors listed in the color popup
                        "FFFFFF FFCCCC FFCC99 FFFF99 FFFFCC 99FF99 99FFFF CCFFFF CCCCFF FFCCFF " +
                                "CCCCCC FF6666 FF9966 FFFF66 FFFF33 66FF99 33FFFF 66FFFF 9999FF FF99FF " +
                                "C0C0C0 FF0000 FF9900 FFCC66 FFFF00 33FF33 66CCCC 33CCFF 6666CC CC66CC " +
                                "999999 CC0000 FF6600 FFCC33 FFCC00 33CC00 00CCCC 3366FF 6633FF CC33CC " +
                                "666666 990000 CC6600 CC9933 999900 009900 339999 3333FF 6600CC 993399 " +
                                "333333 660000 993300 996633 666600 006600 336666 000099 333399 663366 " +
                                "000000 330000 663300 663333 333300 003300 003333 000066 330099 330033",
                fonts:        // font names listed in the font popup
                        "Arial,Arial Black,Comic Sans MS,Courier New,Narrow,Garamond," +
                                "Georgia,Impact,Sans Serif,Serif,Tahoma,Trebuchet MS,Verdana",
                sizes:        // sizes listed in the font size popup
                        "1,2,3,4,5,6,7",
                styles:       // styles listed onafterprint the style popup
                        [
                            ["Paragraph", "<p>"],
                            ["Header 1", "<h1>"],
                            ["Header 2", "<h2>"],
                            ["Header 3", "<h3>"],
                            ["Header 4","<h4>"],
                            ["Header 5","<h5>"],
                            ["Header 6","<h6>"]
                        ],
                useCSS:       false, // use CSS to style HTML when possible (not supported in ie)
                bodyStyle:    // style to assign to document body contained within the editor
                        "margin:4px; font:10pt Arial,Verdana; cursor:text"
            });
        }

    };

    $('a.collapsibleboxlink').bind('click', renderCleditor);

    renderCleditor();
});

