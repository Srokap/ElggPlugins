<?php

/**
 * Elgg long text input with the cleditor text editor intacts
 * Displays a long text input field
 *
 * @uses $vars['value'] The current value, if any
 * @uses $vars['js'] Any Javascript to enter into the input tag
 * @uses $vars['internalname'] The name of the input field
 *
 */

/**
 * Please note the additional CSS class appended to the textarea 'cleditor' this is required
 */

?>

<!-- show the textarea -->
<textarea class="input-textarea cleditor" id="<?php echo $vars['internalname']; ?>"
          name="<?php echo $vars['internalname']; ?>" <?php echo $vars['js']; ?>><?php echo htmlentities($vars['value'], null, 'UTF-8'); ?></textarea>
<div class="fieldLegend" style="margin-bottom: 15px;">remember: save early and save often to avoid losing data</div>
