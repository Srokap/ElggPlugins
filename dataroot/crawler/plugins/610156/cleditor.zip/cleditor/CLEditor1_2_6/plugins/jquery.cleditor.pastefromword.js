/**
 @author Michael Jett (mjett@mitre.org)
 @version 0.1
 */

// ==ClosureCompiler==
// @compilation_level SIMPLE_OPTIMIZATIONS
// @output_file_name jquery.cleditor.pastefromword.min.js
// ==/ClosureCompiler==

(function($) {

    // Define the table button
    $.cleditor.buttons.pastefromword = {
        name: "pastefromword",
        image: "paste_word.gif",
        title: "Paste from Word",
        command: "inserthtml",
        popupName: "pastefromword",
        popupClass: "cleditorPrompt",
        popupContent:
                "<table cellpadding=0 cellspacing=0><tr>" +
                        "<td><b>Paste from Word</b><br/>Use CTRL+V on your keyboard to paste the text into the window.<br/>" +
                        "<textarea rows=4 cols=55></textarea></td>" +
                        "</tr></table><input type=button value=Insert>",
        buttonClick: function (e, data) {

            // Wire up the submit button click event handler
            $(data.popup).children(":button")
                    .unbind("click")
                    .bind("click", function(e) {

                // Get the editor
                var editor = data.editor;

                // Get text
                var $text = $(data.popup).find("textarea");

                // Html is the textarea value
                var html = $text[0].value;

                // Restore internet explorer selection
                //editor.restoreSelection();

                // Insert the html
                if (html)
                    editor.execCommand(data.command, html, null, data.button);

                // Reset the text, hide the popup and set focus
                $text.val("");
                editor.hidePopups();
                editor.focus();

            });

        }
    };

    // Add the button to the default controls
    $.cleditor.defaultOptions.controls = $.cleditor.defaultOptions.controls
            .replace("rule ", "rule pastefromword ");



})(jQuery);