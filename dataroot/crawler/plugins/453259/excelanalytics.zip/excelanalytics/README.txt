	/**
	* Excel Analytics 
	* 
	* @package 
	* @author Miguel Angel Carralero Mart�nez
	* @copyright GTI-Learning  (interactive technologies group of Pompeu Fabra University
	* @link http://www.gti.upf.edu/
	*/

This plugin makes an .xls file in your data root. 
Inside of this .xls makes 3 colums with:

User of the session
Url that is viewing
Timestamp




Enjoyit