<?php
	/**
	* Excel Analytics startup file.
	* 
	* @package 
	* @author Miguel Angel Carralero Mart�nez
	* @copyright GTI-Learning  (interactive technologies group of Pompeu Fabra University
	* @link http://www.gti.upf.edu/
	*/

	function excelanalytics_init()	{
		global $CONFIG;
		extend_view('page_elements/footer','excelanalytics/footer', 499);
	}
	
	register_elgg_event_handler('init','system','excelanalytics_init');
	
?>
