<?php
	/**
	* Google Analytics footer extension.
	* 
	* @package analytics
	* @author ColdTrick IT Solutions
	* @copyright ColdTrick IT Solutions 2009
	* @link http://www.coldtrick.com/
	*/

	global $CONFIG;
	
	/**************************************************************************************************
					 **************************************************************************************************
					 **************************************************************************************************
					 * C�digo mio para escribir en un EXCEL 
					 **************************************************************************************************
					 **************************************************************************************************
					 **************************************************************************************************/

				 		$datos[] = $_SESSION['user']->username;    //username
						$datos[] = $_SERVER['REQUEST_URI'];//$url;
						$datos[] = 25569 + (time()/ 86400);	//timestamp;
				 
					 
					//Check if the filename was sent through the form or not
			
					// if the filename wasnt sent through the form, it will become register_data.xls, you can change the default if you want.
					$fichero = $CONFIG->dataroot."excelanalytics_data.xls";	//Set the file to save the information in
			
					// Define the tab and carriage return characters:
					$tab = "\t";	//chr(9);
					$cr = "\n";		//chr(13);
					
					//LAUREN CHANGES!!!
					
					$myheader[] = elgg_echo('excelanalytics:username');
					$myheader[] = elgg_echo('excelanalytics:url');		
					$myheader[] = elgg_echo('excelanalytics:generaldatetime');

					
					for ($i=0; $i < count($datos); $i++)
					{
						$valor = $datos[$i];
						$valor = str_replace("\n",$lbChar,$valor);
						$valor = preg_replace('/([\r\n])/e',"ord('$1')==10?'':''",$valor);
						$valor = str_replace("\\","",$valor);
						$valor = str_replace($tab, "    ", $valor);
						
						if(	is_array($valor) )
						{
							for( $j=0; $j < count($valor); $j++ )
							{
								if($j==0) 
									$sub = substr($valor[$j],1,1);
								else 
									$sub = $sub .",". substr($valor[$j],1,1);
							}
							$valor = $sub;
							empty($sub);
						}
						$dataTmp .= $valor . $tab ;
						$header .= $myheader[$i] . $tab;
					}
					$header .= $cr;
					$dataTmp .= $cr;
			
					if (file_exists($fichero)) {
						$final_data = $dataTmp;		// If the file does exist, then only write the information the user sent
					} else {
						$final_data = $header . $dataTmp;		// If file does not exist, write the header(first line in excel with titles) to the file
					}
					// open the file and write to it
					
					$fp = fopen($fichero,"a"); // $fp is now the file pointer to file $array['filename']
					
					if($fp){
						
						fwrite($fp,$final_data);	//Write information to the file
						fclose($fp);		// Close the file
						// Success
						//header("Location: $success");
						} else {
						// Error
						//header("Location: $error");
					}
					
					/**************************************************************************************************
					 **************************************************************************************************
					 **************************************************************************************************
					 * FIN 
					 **************************************************************************************************
					 **************************************************************************************************
				 *******************************************************************************************/
?>
