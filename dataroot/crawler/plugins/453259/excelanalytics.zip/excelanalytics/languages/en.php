<?php
	/**
	* Excel Analytics startup file.
	* 
	* @package 
	* @author Miguel Angel Carralero Mart�nez
	* @copyright GTI-Learning  (interactive technologies group of Pompeu Fabra University)
	* @link http://www.gti.upf.edu/
	*/
		
	$english = array(
		'excelanalytics:username' => 'Username',
		'excelanalytics:url' => 'Url',
		'excelanalytics:timestamp' => 'TimeStamp()',
		'excelanalytics:generaldatetime' => 'DateTime GeneralFormat'
	);
	
	add_translation("en", $english);
?>
