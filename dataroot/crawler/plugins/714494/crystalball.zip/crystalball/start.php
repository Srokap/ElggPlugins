<?php

	/**
	 * Elgg Crytal ball plugin
	 * This is a magic cristal ball that will answer all your yes/no questions. please use it Just for fun 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author oscar from ibantu
	 */
	 
	 global $CONFIG;
	 	 	
	// Register a page handler, so we can have nice URLs
		register_page_handler('crystalball','crystalball_page_handler');
	
	// Page handler
		function crystalball_page_handler($page) {
			global $CONFIG;
			include($CONFIG->pluginspath . "crystalball/index.php");
		}
		
	// Load menu
		if (isloggedin()) {
		add_menu(elgg_echo('crystal ball'),$CONFIG->wwwroot."pg/crystalball");
		}
	// Shares widget
		add_widget_type('crystalball',elgg_echo("crystal ball"),elgg_echo("This is a magic cristal ball that will answer all your yes/no questions."));
	
		
?>