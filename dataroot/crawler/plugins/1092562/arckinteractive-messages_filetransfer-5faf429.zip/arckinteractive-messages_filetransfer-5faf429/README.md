messages_filetransfer
=====================

Allows users to send files from the file plugin as attachments to internal messages