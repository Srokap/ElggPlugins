
.messages-filetransfer-selectwrapper {
  padding: 5px;
  border: 1px solid #cccccc;
  max-height: 120px;
  overflow: auto;
}