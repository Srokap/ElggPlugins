<?php

$english = array(
    'messages_filetransfer:label' => 'Attach a file?',
    'messages_filetransfer:error:filesave' => 'Could not send files to recipient, your message has not been sent.',
    'messages_filetransfer:attachments' => 'Attachments',
);
		
add_translation("en", $english);