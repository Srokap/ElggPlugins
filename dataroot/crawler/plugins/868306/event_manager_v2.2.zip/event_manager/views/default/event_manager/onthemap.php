<div id="event_manager_event_map">
	<div id="event_manager_onthemap_canvas"></div>
	<div id="event_manager_onthemap_legend">
		<img src="//www.google.com/intl/en_us/mapfiles/ms/micons/ylw-pushpin.png" /><?php echo elgg_echo("event_manager:list:navigation:your"); ?>
		<img src="//www.google.com/intl/en_us/mapfiles/ms/micons/blue-pushpin.png" /><?php echo elgg_echo("event_manager:list:navigation:attending"); ?>
		<img src="//www.google.com/intl/en_us/mapfiles/ms/micons/red-pushpin.png" /> <?php echo elgg_echo("event_manager:list:navigation:other"); ?>
	</div>	
</div>