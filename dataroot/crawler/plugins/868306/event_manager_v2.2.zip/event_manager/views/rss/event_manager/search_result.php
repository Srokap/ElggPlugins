<?php 

	echo elgg_view_entity_list($vars["entities"], $vars["count"], $vars["offset"], 10, false);