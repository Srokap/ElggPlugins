/**
 * Elgg delete plugin
 * Author ; Dr Sanu P Moideen @ Team Webgalli
 * http://webgalli.com
 * jQuery Plugin : jConfirmAction
 * by Hidayat Sagita
 * http://www.webstuffshare.com
 * Licensed Under GPL version 2 license.
 */
(function($){
	jQuery.fn.jConfirmAction = function (options) {
		var theOptions = jQuery.extend ({
			question: "<?php echo elgg_echo('question:areyousure');?>",
			yesAnswer: "<?php echo elgg_echo('option:yes');?>",
			cancelAnswer: "<?php echo elgg_echo('option:no');?>"
		}, options);
		return this.each (function () {
			$(this).bind('click', function(e) {
				e.preventDefault();
				thisHref	= $(this).attr('href');
				if($(this).next('.question').length <= 0)
					$(this).after('<div class="question">'+theOptions.question+'<br/> <span class="yes">'+theOptions.yesAnswer+'</span><span class="cancel">'+theOptions.cancelAnswer+'</span></div>');
				$(this).next('.question').animate({opacity: 1}, 300);
				$('.yes').bind('click', function(){
					window.location = thisHref;
				});
				$('.cancel').bind('click', function(){
					$(this).parents('.question').fadeOut(300, function() {
						$(this).remove();
					});
				});
			});
		});
	}
})(jQuery);