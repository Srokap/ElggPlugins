<script type="text/javascript">
			$(document).ready(function() {
				$('.ask').jConfirmAction();
			});
</script>