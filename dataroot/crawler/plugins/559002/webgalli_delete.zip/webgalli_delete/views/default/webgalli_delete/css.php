<?php
/**
 * Elgg delete plugin
 * Author ; Dr Sanu P Moideen @ Team Webgalli
 * http://webgalli.com
*/
?>

.question {
	position: absolute;
	display: inline;
	text-align: center;
	width: 174px;
	height: 78px;
	font-size: 13px;
	line-height: 1.5em;
	background: url('<?php echo $vars['url']; ?>mod/webgalli_delete/images/bubble.png') left top no-repeat;
	padding: 10px 0 0 0;
	text-shadow: 0px 1px 0px #fff;
	margin-left: -7em;
	margin-top: -6em;
	opacity: 0;
}

.yes, .cancel {
	margin-top: .5em;
	margin-right: .5em;
	cursor: pointer;
	display: inline-block;
	width: 63px;
	height: 21px;
	color: #fff;
	text-shadow: 0px 1px 0px #000;
	background: url('<?php echo $vars['url']; ?>mod/webgalli_delete/images/button.png') left top no-repeat;
}