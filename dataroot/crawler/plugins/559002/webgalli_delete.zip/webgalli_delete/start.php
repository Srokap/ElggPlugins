<?php
/**
 * Elgg jquery delete plugin
 * Author ; Dr Sanu P Moideen @ Team Webgalli
 * http://webgalli.com
*/
	function webgalli_delete_init(){
		elgg_extend_view('metatags','webgalli_delete/metatags');
		elgg_extend_view('css','webgalli_delete/css');
		elgg_extend_view('js/initialise_elgg','webgalli_delete/javascript');
	}
	
	register_elgg_event_handler('init','system','webgalli_delete_init');
	
?>