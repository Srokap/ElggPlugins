/**
 * Phloor Sticky Footer
 * 
 * @package phloor_sticky_footer
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 2012 by 13net
 * @link http://phloor.13net.at/
 */

/**
 * Description
 */
Creates a sticky footer on your Elgg site. 

This plugins creates a footer that will stick to the sites bottom.

Extends the elgg css view like this:
elgg_extend_view('css/elgg', 'phloor_sticky_footer/css/elgg', 501);
elgg_extend_view('css/elgg', 'phloor_sticky_footer/css/sticky_footer_color', 501);

See the file 'phloor_sticky_footer/views/default/css/sticky_footer_color' for the
css thats added. Here you can set your own 'background-color' or other attributes
of the footer (font-family, padding, maring, ...). 
!! Customize the file to fit your needs !!

(You can easily hook in afterwards or extend 'phloor_sticky_footer/css/elgg' 
to overwrite the css, or .. simply disable the plugin.)

/**
 * Languages
 */
English
German
