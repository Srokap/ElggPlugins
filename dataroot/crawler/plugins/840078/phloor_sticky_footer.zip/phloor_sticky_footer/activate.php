<?php

$notice_id      = 'phloor_sticky_footer_set_height';
$notice_message = elgg_echo('phloor_sticky_footer:admin:notice:set_height');

$settings_url  = elgg_normalize_url('admin/plugin_settings/phloor_sticky_footer');
$settings_link = elgg_view('output/url', array(
    'text' => elgg_echo('settings'),
    'href' => $settings_url,
    'is_trusted' => true,
));

// append link to settings
$notice_message .= $settings_link;

elgg_add_admin_notice($notice_id, $notice_message);