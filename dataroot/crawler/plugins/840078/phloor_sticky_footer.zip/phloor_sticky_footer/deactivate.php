<?php

$notice_id = 'phloor_sticky_footer_set_height';
if (elgg_admin_notice_exists($notice_id)) {
    elgg_delete_admin_notice($notice_id);
}