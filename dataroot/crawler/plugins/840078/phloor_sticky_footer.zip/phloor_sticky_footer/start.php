<?php
/*****************************************************************************
 * Phloor Sticky Footer                                                      *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

elgg_register_event_handler('init',  'system', 'phloor_sticky_footer_init');

/**
 *
 */
function phloor_sticky_footer_init() {
	/**
	 * CSS
	 */
	$disable_plugin = elgg_get_plugin_setting('disable_sticky_footer', 'phloor_sticky_footer');
	if(strcmp('true', $disable_plugin) != 0) {
	    // basic css to stick the footer to the bottom
		elgg_extend_view('css/elgg', 'phloor_sticky_footer/css/elgg', 501);
		// append css color settings (default is set to match with elggs orginal theme)
		$disable_default_color = elgg_get_plugin_setting('disable_default_color_css', 'phloor_sticky_footer');
	    if(strcmp('true', $disable_default_color) != 0) {
		    elgg_extend_view('css/elgg', 'phloor_sticky_footer/css/sticky_footer_color', 502);
	    }
	}
}

