<?php

/* ***************************************
	SITE FOOTER COLOR
	CHANGE TO YOUR NEEDS!
*************************************** */

?>
.elgg-page .elgg-page-footer > .elgg-inner {
	color: #FFF;
	background:#4690D6;

	border-top: 1px solid #DEDEDE;
}

.elgg-page-footer a {
	color: #FFF;
}

.elgg-page-footer a:hover {
	color: #EEE;
}

.elgg-menu-footer > li,
.elgg-menu-footer > li > a {
	color: #FFF;
}
<?php

/* ***************************************
	END - SITE FOOTER COLOR - END
*************************************** */


