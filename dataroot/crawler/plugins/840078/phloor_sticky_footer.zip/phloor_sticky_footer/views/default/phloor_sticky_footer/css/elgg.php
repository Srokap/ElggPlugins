<?php
/*****************************************************************************
 * Phloor Sticky Footer                                                      *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$height = elgg_get_plugin_setting('footer_height', 'phloor_sticky_footer');

if(!is_numeric($height)) {
    $height = 150;
}

// adjust the margin of the actual content to bottom
$main_bottom_margin = $height + 100;

?>

.elgg-page-body {
	margin-bottom:<?php echo $main_bottom_margin; ?>px;
}

.elgg-page-footer {
	position: fixed;
	margin:0px;
	left:0px;
	right:0px;
	bottom: 0px;
	width: 100%;
}

.elgg-page .elgg-page-footer > .elgg-inner {
	height: <?php echo $height; ?>px;
	width: auto;
	margin: 0 auto;
	padding: 5px 5px;

    -webkit-border-radius: 0 2px 5px 1px;
    -moz-border-radius: 0 2px 5px 1px;
    border-radius: 0 2px 5px 1px;
}

.elgg-menu-footer > li,
.elgg-menu-footer > li > a {
	display: inline-block;
}
