<?php
/*****************************************************************************
 * Phloor Sticky Footer                                                      *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$footer_height = $vars['entity']->footer_height;

if (!is_numeric($footer_height)) {
    $footer_height = 150;
}

$disable_sticky_footer     = $vars['entity']->disable_sticky_footer;
$disable_default_color_css = $vars['entity']->disable_default_color_css;

if (strcmp('true', $disable_sticky_footer) != 0) {
	$hide_elgg_release_and_version_metadata = 'false';
}
if (strcmp('true', $disable_default_color_css) != 0) {
	$disable_default_color_css = 'false';
}


?>
<?php
echo '<div style="margin:20px;">';
echo elgg_echo('phloor_sticky_footer:footer_height');
echo elgg_view('phloor_sticky_footer/input/footer-height-dropdown', array(
	'name' => 'params[footer_height]',
	'value' => $footer_height,
));
echo elgg_echo('phloor_sticky_footer:footer_height:description');
echo '</div>';

// disable sticky footer
echo '<div style="margin:30px;">';
echo elgg_view('phloor/input/vendors/prettycheckboxes/checklist', array(
	'options' => array(
    	'disable_default_color_css'  => array(
        	'name'  => 'params[disable_default_color_css]',
        	'value' => $disable_default_color_css,
            'label' => elgg_echo('phloor_sticky_footer:disable_default_color_css'),
            'description' => elgg_echo('phloor_sticky_footer:disable_default_color_css:description'),
        ),
    	'disable_sticky_footer'  => array(
        	'name'  => 'params[disable_sticky_footer]',
        	'value' => $disable_sticky_footer,
            'label' => elgg_echo('phloor_sticky_footer:disable_sticky_footer'),
            'description' => elgg_echo('phloor_sticky_footer:disable_sticky_footer:description'),
        ),
    ),
));
echo '</div>';


