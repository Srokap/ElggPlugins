<?php
/*****************************************************************************
 * Phloor Sticky Footer                                                      *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$english = array(
	"admin:plugins:category:PHLOOR" => "PHLOOR Plugins",
	'phloor_sticky_footer' => 'Sticky Footer',

	'phloor_sticky_footer:admin:notice:set_height' => 'A height for the footer has to be set in order for "Sticky Footer" to work properly. ',

	'phloor_sticky_footer:disable_default_color_css' => 'Disable Color CSS? ',
	'phloor_sticky_footer:disable_default_color_css:description' => 'Recommended when not using Elggs default theme.',

	'phloor_sticky_footer:disable_sticky_footer' => 'Temporarily disable "Sticky Footer"? ',
	'phloor_sticky_footer:disable_sticky_footer:description' => '',

	'phloor_sticky_footer:footer_height' => 'Footer height: ',
	'phloor_sticky_footer:footer_height:description' => '',
);

add_translation("en",$english);