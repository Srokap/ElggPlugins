<?php
/*****************************************************************************
 * Phloor Sticky Footer                                                      *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$german = array(
	"admin:plugins:category:PHLOOR" => "PHLOOR Plugins",
	'phloor_sticky_footer' => 'Sticky Footer',

	'phloor_sticky_footer:admin:notice:set_height' => 'Es muss eine Höhenangabe für den Footer gemacht werden, damit "Sticky Footer" ordnungsgemäß funktioniert. ',

	'phloor_sticky_footer:disable_default_color_css' => 'CSS Regeln für Farben deaktivieren? ',
	'phloor_sticky_footer:disable_default_color_css:description' => 'Nur empfohlen, falls sie nicht Elggs Standard Theme verwenden.',

	'phloor_sticky_footer:disable_sticky_footer' => '"Sticky Footer" temporär deaktivieren? ',
	'phloor_sticky_footer:disable_sticky_footer:description' => '',

	'phloor_sticky_footer:footer_height' => 'Höhe des Footers: ',
	'phloor_sticky_footer:footer_height:description' => '',
);

add_translation("de",$german);