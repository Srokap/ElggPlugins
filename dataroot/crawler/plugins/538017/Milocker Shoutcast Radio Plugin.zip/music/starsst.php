<?php

	/**
	 * Elgg twitter widget
	 * This plugin allows users to pull in their twitter feed to display on their profile
	 * 
	 * @package ElggTwitter
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
	
		function music_init() {
    		
    		//extend css if style is required
    		    extend_view('css','musica/css');
				extend_view ( "js/initialise_elgg", "widgets/music/view" );
    		//add a widget
			    add_widget_type('music',"Music","tu musica");
			
		}
		
		register_elgg_event_handler('init','system','music_init');

?>