<?php

	/**
	 * Milocker.com Shoutcast Radio Widget
	 * Developed by Milocker Development Team 
	 * Milocker LLC. All Rights Reserved
	 * For more, visit out website 
	 * Developed by Milton, hejosadi and rj california
	 */
	
		function music_init() {
    		
    		//extend css if style is required
    		    extend_view('css','musica/css');		
    		//add a widget
			    add_widget_type('music',"Music","tu musica");
			
		}
		
		register_elgg_event_handler('init','system','music_init');

?>