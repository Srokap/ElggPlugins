<?php
    
     /**
	 * Elgg twitter view page
	 *
	 * @package ElggTwitter
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
	 
	 //some required params
	 
	 
	 
?>



<div id="music_widget" align="center"><embed id="miniagmmodule.swf" width="300" height="400" align="L" src="http://o.aolcdn.com/shoutcast/widget/radio/ShoutcastV1.swf?random=1280379685595" allowscriptaccess="always" bgcolor="#ffffff" version="9,0,0,0" pluginspage="http://www.macromedia.com/go/getflashplayer"></div>