<?php

	$spanish = array(
	
		'friends:all' => 'Todos tus amigos',
	
		'notifications:subscriptions:personal:description' => 'Recibir notificaciones cuando se modifiquen tus contenidos',
		'notifications:subscriptions:personal:title' => 'Notificaciones personales',
	
		'notifications:subscriptions:collections:title' => 'Colección de amigos',
		'notifications:subscriptions:collections:description' => 'Para modificar las opciones de los miembros de tu colección de amig@s, utiliza el siguiente enlace: <br><br>',
		'notifications:subscriptions:collections:edit' => 'Modificar opciones de amig@s',
	
		'notifications:subscriptions:changesettings' => 'Notificaciones',
		'notifications:subscriptions:changesettings:groups' => 'Notificaciones de grupo',
		'notification:method:email' => 'Email',	
	
		'notifications:subscriptions:title' => 'Notificaciones por usuario',
		'notifications:subscriptions:description' => 'Para recibir noticificaciones de tus amigos cuando crean nuevo contenido, búscalos en la red y selecciona el tipo de notificación que quieres recibir',
	
		'notifications:subscriptions:groups:description' => 'Para recibir notificaciones cuando se agregue nuevo contenido a un grupo del que eres miembro, búscalo y selecciona el tipo de notificación que quieres recibir',
	
		'notifications:subscriptions:success' => 'Tu configuración de notificaciones se guardó correctamente.',
	
	);
					
	add_translation("es",$spanish);

?>
