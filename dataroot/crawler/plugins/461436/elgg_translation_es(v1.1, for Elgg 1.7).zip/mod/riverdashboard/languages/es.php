<?php

// Generado por translationbrowser 

$spanish = array( 
	 'mine'  =>  "Propias" , 
	 'filter'  =>  "Filtro" , 
	 'riverdashboard:useasdashboard'  =>  "Quieres sustituir el escritorio por defecto?" , 
	 'activity'  =>  "Actividad" , 
	 'activity:panel'  =>  "Panel de actividad." , 
	 'sitemessages:announcements'  =>  "Notificaciones rápidas!" , 
	 'sitemessages:posted'  =>  "Enviado" , 
	 'sitemessages:river:created'  =>  "%s:" , 
	 'sitemessages:river:create'  =>  "ha enviado una notificación a la red que dice" , 
	 'sitemessages:add'  =>  "Haz click en este texto para enviar una notificación -rápida- a la red .:ALD:." , 
	 'sitemessage:deleted'  =>  "Mensaje eliminado" , 
	 'river:widget:noactivity'  =>  "No hay ninguna actividad!!" , 
	 'river:widget:title'  =>  "Actividad" , 
	 'river:widget:description'  =>  "Mostrar las &uacute;ltimas actividades de la red" , 
	 'river:widget:title:friends'  =>  "Actividad de tus amig@s" , 
	 'river:widget:description:friends'  =>  "Mostrar que estan haciendo tus amig@s ahora mismo" , 
	 'river:widgets:friends'  =>  "Amig@s" , 
	 'river:widgets:mine'  =>  "Propios" , 
	 'river:widget:label:displaynum'  =>  "Número de actividades a mostrar:" , 
	 'river:widget:type'  =>  "¿Prefieres mostrar todas las actividades o solo las de tus amig@s?<br />" , 
	 'item:object:sitemessage'  =>  "Lugar para los mensajes" , 
	 'riverdashboard:recentmembers'  =>  "Últimos miembros"
); 

add_translation('es', $spanish); 

?>