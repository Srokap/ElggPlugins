<?php

	$spanish = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Mostrar algunos amigos",
	        
		
	);
					
	add_translation("es",$spanish);

?>
