<p>
<?php 
/**
 * @package :Text Captcha
 * @name : Liang
 * @ url:http://community.elgg.org/pg/profile/arsalanlee
 * @licnnce : GPL V2
 */
?>
<?php

	// set default value if user hasn't set it
	$param = $vars['entity']->tasks;
	if (!isset($param)) 
	{
		$param = "2 * 2 = ?|4\n2 * 3 = ?|6";
		$vars['entity']->tasks = $param;
	}

	echo elgg_echo('textcaptcha:tasks'); 
	
	echo '<br/>';
	
	echo elgg_view('input/longtext', array(
			'internalname' => 'params[tasks]',
			'value' => $param
		));
?>
</p>