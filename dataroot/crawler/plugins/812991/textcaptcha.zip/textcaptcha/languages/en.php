<?php 
/**
 * @package :Text Captcha
 * @name : Liang
 * @ url:http://community.elgg.org/pg/profile/arsalanlee
 * @licnnce : GPL V2
 */
?>
<?php

	$english = array(
	
		'textcaptcha:entercaptcha' => 'Answer simple question',
		'textcaptcha:entercaptcha:description' => 'Please input answer below',
		'textcaptcha:captchafail' => 'Sorry, the number that you entered wasn\'t correct.',
		'textcaptcha:tasks' => 'Disable Any Text editor and then enter questions Define additional tasks:'
	);
					
	add_translation("en",$english);
?>