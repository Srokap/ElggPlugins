<?php

	/**
	 * Elgg prayer: delete post action
	 * 
	 * @package ElggPrayer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Johno
	 */

	// Make sure we're logged in (send us to the front page if not)
	gatekeeper();

	// Get input data
	$guid = (int) get_input('prayerpost');
	
	$prayer = get_entity($guid);
	
	//check if can edit this prayer	
	$group = groupprayer_gatekeeper("group:".$prayer->container_guid);

	// Make sure we actually have permission to edit
	
	if ($prayer->getSubtype() == "groupprayer" && $prayer->canEdit()) {
	
	// Get owning user
	$owner = get_entity($prayer->getOwner());
	// Delete it!
	$rowsaffected = $prayer->delete();
	if ($rowsaffected > 0) {
		// Success message
		system_message(elgg_echo("groupprayer:deleted"));
	} else {
		register_error(elgg_echo("groupprayer:notdeleted"));
	}
	// Forward to the main prayer page
	forward("pg/groupprayer/owned/group:" . $prayer->container_guid);
		
	}
		
?>
