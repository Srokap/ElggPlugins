<?php

	/**
	 * Elgg prayer: edit post action
	 * 
	 * @package ElggPrayer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Johno
	 */

	// Make sure we're logged in (send us to the front page if not)
	gatekeeper();
    // Make sure action is secure
     action_gatekeeper();

	// Get input data
	$group_guid = get_input('group_guid');

	//check if can edit this prayer	
	$group = groupprayer_gatekeeper("group:$group_guid");

	// Get input data
	$guid = (int) get_input('prayerpost');
	$title = get_input('prayertitle');
	$body = get_input('prayerbody');
	$access = get_input('access_id');
	$tags = get_input('prayertags');
		
	// Make sure we actually have permission to edit
	$prayer = get_entity($guid);
	if ($prayer->getSubtype() == "groupprayer" && $prayer->canEdit()) {
	
	// Cache to the session
	$_SESSION['prayertitle'] = $title;
	$_SESSION['prayerbody'] = $body;
	$_SESSION['prayertags'] = $tags;
			
	// Convert string of tags into a preformatted array
	$tagarray = string_to_tag_array($tags);
			
	// Make sure the title / description aren't blank
	if (empty($title) || empty($body)) {
		register_error(elgg_echo("groupprayer:blank"));
		forward("pg/groupprayer/edit/$guid");
			
	// Otherwise, save the prayer post 
	} else {
				
		// Get owning user
		$owner = get_entity($prayer->getOwner());
		// For now, set its access to public (we'll add an access dropdown shortly)
		$prayer->access_id = $access;
		// Set its title and description appropriately
		$prayer->title = $title;
		$prayer->description = $body;
		// Before we can set metadata, we need to save the prayer post
		if (!$prayer->save()) {
			register_error(elgg_echo("groupprayer:error"));
			forward("pg/groupprayer/edit/$guid");
		}
		// Now let's add tags. We can pass an array directly to the object property! Easy.
		$prayer->clearMetadata('tags');
		if (is_array($tagarray)) {
			$prayer->tags = $tagarray;
		}
		// Success message
		system_message(elgg_echo("groupprayer:posted"));
		// Remove the prayer post cache
		unset($_SESSION['prayertitle']); unset($_SESSION['prayerbody']); unset($_SESSION['prayertags']);
		// Forward to the main prayer page
		forward("pg/groupprayer/owned/group:" . $group->getGUID());
					
		}
		
	}
		
?>
