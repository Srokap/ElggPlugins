<?php

	/**
	 * Elgg Pages
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Johno
	 */

	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// Get the specified prayer post
	
	$post = (int) get_input('prayerpost');

	// If we can get out the prayer post ...
	if ($prayerpost = get_entity($post)) {
			
		// Get any comments
		$comments = $prayerpost->getAnnotations('comments');
		
		// Set the page owner
		set_page_owner($prayerpost->getContainer());
		$page_owner = get_entity($prayerpost->getOwner());
			
		// Display it
		$area2 = elgg_view("object/groupprayer",array(
						'entity' => $prayerpost,
						'entity_owner' => $page_owner,
						'comments' => $comments,
						'full' => true
					));
											
		// Set the title appropriately
		//$title = sprintf(elgg_echo("prayer:posttitle"),$page_owner->name,$prayerpost->title);

		// Display through the correct canvas area
		$body = elgg_view_layout("two_column_left_sidebar", '', $area1 . $area2);
			
	// If we're not allowed to see the prayer post
	} else {
			
	// Display the 'post not found' page instead
		$body = elgg_view("groupprayer/notfound");
		$title = elgg_echo("groupprayer:notfound");
			
	}
		
	// Display page
	page_draw($title,$body);
	
?>
