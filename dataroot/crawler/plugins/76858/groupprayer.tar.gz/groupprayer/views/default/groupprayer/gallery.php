<?php

	/**
	 * Elgg prayer listing
	 * 
	 * @package ElggPrayer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Johno
	 */

		$owner = $vars['entity']->getOwnerEntity();
		$owner->setURL($CONFIG->wwwroot."pg/groupprayer/owned/".$owner->username);
		$group = $vars['entity']->getContainerEntity();

		$page_owner = page_owner_entity();

		
		if ($page_owner instanceof ElggGroup) {
			$icon = elgg_view(
				"profile/icon", array(
										'entity' => $owner,
										'size' => 'small',
									  )
			);

		}
		else {
			$icon = elgg_view(
				"profile/icon", array(
										'entity' => $group,
										'size' => 'small',
									  )
			);			
		}

		$friendlytime = friendly_time($vars['entity']->time_created);
		$info = "<p>" . elgg_echo('groupprayer') . ": <a href=\"{$vars['entity']->getURL()}\">{$vars['entity']->title}</a></p>";
		$info .= "<p><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</p>";

		//display
		echo "<div class=\"groupprayer_gallery\">";
		echo "<div class=\"groupprayer_gallery_icon\">" . $icon . "</div>";
		echo "<div class=\"groupprayer_gallery_content\">" . $info . "</div>";
		echo "</div>";


?>
