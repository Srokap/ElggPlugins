<div id="group_pages_widget">
<h2><?php echo elgg_echo("groupprayer:groupprofile"); ?></h2>
<?php

    $objects = list_entities("object", "groupprayer", page_owner(), 5, false);
	echo $objects;
	
?>
</div>
