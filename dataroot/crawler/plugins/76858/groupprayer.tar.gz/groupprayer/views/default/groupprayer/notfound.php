<?php

	/**
	 * Elgg prayer not found page
	 * 
	 * @package ElggPrayer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Johno
	 */

?>

	<p>
		<?php

			echo elgg_echo("groupprayer:notfound");
		
		?>
	</p>
