<?php

	/**
	 * Elgg prayer individual post view
	 * 
	 * @package ElggPrayer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Johno
	 * 
	 * @uses $vars['entity'] Optionally, the prayer post to view
	 */


		if (isset($vars['entity'])) {
			
			
			if (get_context() == "search") {
				
				//display the correct layout depending on gallery or list view
				if (get_input('search_viewtype') == "gallery") {

					//display the gallery view
            				echo elgg_view("groupprayer/gallery",$vars);

				} else {
				
					echo elgg_view("groupprayer/listing",$vars);

				}
			}
			elseif(isset($vars['full']) && $vars['full'] == true) {
?>

	<div class="groupprayer_post">
		<h3><a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo $vars['entity']->title; ?></a></h3>
		<!-- display the user icon -->
		<div class="groupprayer_post_icon">
		    <?php
		        echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'tiny'));
			?>
	    </div>
			<p class="strapline">
				<?php
	                
					echo sprintf(elgg_echo("groupprayer:strapline"),
									date("F j, Y",$vars['entity']->time_created)
					);
				
				?>
				<?php echo elgg_echo('by'); ?> <a href="<?php echo $vars['url']; ?>pg/groupprayer/owned/<?php echo $vars['entity']->getOwnerEntity()->username; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?></a> &nbsp; 
				<!-- display the comments link -->
				<?php
			        //get the number of comments
			    	$num_comments = elgg_count_comments($vars['entity']);
			    ?>
			    <a href="<?php echo $vars['entity']->getURL(); ?>"><?php echo sprintf(elgg_echo("comments")) . " (" . $num_comments . ")"; ?></a><br />
			</p>
			<!-- display tags -->
			<p class="tags">
				<?php
	
					echo elgg_view('output/tags', array('tags' => $vars['entity']->tags));
				
				?>
			</p>
			<div class="clearfloat"></div>
			<div class="groupprayer_post_body">

			<!-- display the actual prayer post -->
				<?php
			
							echo autop($vars['entity']->description);
				
				?>
			</div><div class="clearfloat"></div>			
			<!-- display edit options if it is the prayer post owner -->
			<p class="options">
			<?php
	
				if ($vars['entity']->canEdit()) {
					
				?>
					<a href="<?php echo $vars['url']; ?>pg/groupprayer/edit/<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("edit"); ?></a>  &nbsp; 
					<?php
					
						echo elgg_view("output/confirmlink", array(
																	'href' => $vars['url'] . "action/groupprayer/delete?prayerpost=" . $vars['entity']->getGUID(),
																	'text' => elgg_echo('delete'),
																	'confirm' => elgg_echo('deleteconfirm'),
																));
	
						// Allow the menu to be extended
						echo elgg_view("editmenu",array('entity' => $vars['entity']));
					
					?>
				<?php
				}
			
			?>
			</p>
		</div>

<?php

			// If we've been asked to display the full view
				echo elgg_view_comments($vars['entity']);
				
			} else {
				
				echo elgg_view("groupprayer/listing",$vars);
			}

		}

?>
