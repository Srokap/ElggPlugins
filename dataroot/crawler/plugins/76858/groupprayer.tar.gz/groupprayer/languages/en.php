<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Johno
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groupprayer' => "Group prayers",
			'groupprayers' => "Group prayers",
			'groupprayer:user' => "%s's group prayers",
			'groupprayer:your' => "Your group prayers",
			'groupprayer:group' => "%s's group prayers",
			'groupprayer:new' => "New group prayer",
			'groupprayer:groupprofile' => "Group prayers",
			'groupprayer:edit' => "Edit this prayer",
			'groupprayer:delete' => "Delete this prayer",
			'groupprayer:history' => "Prayer history",
			'groupprayer:view' => "View prayer",
			

			'groupprayer:posttitle' => "%s's prayer: %s",
			'groupprayer:everyone' => "All site group prayers",
	
			'groupprayer:read' => "Read prayer",
	
			'groupprayer:addrequest' => "Write a prayer request",
			'groupprayer:editrequest' => "Edit prayer request",
	
			'groupprayer:text' => "Prayer text",
	
			'groupprayer:strapline' => "%s",
			
			'item:object:groupprayer' => 'Group prayers',
	
			
         /**
	     * Prayer river
	     **/
	        
	        //generic terms to use
	        'groupprayer:river:created' => "%s wrote",
	        'groupprayer:river:updated' => "%s updated",
	        'groupprayer:river:posted' => "%s requested",
	        
	        //these get inserted into the river links to take the user to the entity
	        'groupprayer:river:create' => "a new prayer request.",
	        'groupprayer:river:update' => "a prayer request.",
	        'groupprayer:river:annotate:create' => "a comment on a prayer request.",
		'groupprayer:river:annotate' => "a comment about",	
	
		/**
		 * Status messages
		 */
	
			'groupprayer:posted' => "Your prayer request was successfully requested.",
			'groupprayer:deleted' => "Your prayer request was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'groupprayer:save:failure' => "Your prayer request could not be saved. Please try again.",
			'groupprayer:blank' => "Sorry; you need to fill in both the title and body before you can make a request.",
			'groupprayer:notfound' => "Sorry; we could not find the specified prayer request.",
			'groupprayer:notdeleted' => "Sorry; we could not delete this prayer request.",
			
	);
					
	add_translation("en",$english);
?>
