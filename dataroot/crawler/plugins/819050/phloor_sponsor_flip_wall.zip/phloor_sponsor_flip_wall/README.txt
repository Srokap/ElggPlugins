/**
 * Phloor Sponsor Flip Wall
 * 
 * @package phloor_sponsor_flip_wall
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 1.8-11.11.21
Requires: Elgg 1.8 or higher


/**
 * Description
 */
Enables a sponsor wall for your site.
Admin can define if a footer is shown in the footer.

In order to function properly please use short descriptions and quadratic images. 

This plugin requires the object type plugin 'Sponsor for 1.8' (phloor_sponsor) 
and Flipwall for 1.8 (phloor_flipwall) to work. 

/**
 * Languages
 */
English
German


