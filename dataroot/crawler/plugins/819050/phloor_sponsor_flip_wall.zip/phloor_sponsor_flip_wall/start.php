<?php 
/*****************************************************************************
 * Phloor Sponsor Flip Wall                                                  *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Phloor Sponsor Flip Wall
 */

elgg_register_event_handler('init', 'system', 'phloor_sponsor_flip_wall_init');

function phloor_sponsor_flip_wall_init() {	
	/**
	 * CSS
	 */
	elgg_extend_view('css/elgg', 'phloor_sponsor_flip_wall/css/elgg');	
	
	/**
	 * Page handler
	 */
	elgg_register_page_handler('sponsors', 'phloor_sponsor_flip_wall_page_handler');
	elgg_register_page_handler('phloor_sponsor_flip_wall', 'phloor_sponsor_flip_wall_page_handler');
	
	/**
	 * Plugin hooks
	 */
	if(elgg_get_plugin_setting('show_sponsor_link', 'phloor_sponsor_flip_wall') == 'true') {
		elgg_register_plugin_hook_handler('prepare', 'menu:footer', 'phloor_sponsor_footer_menu_setup');
	}
}

function phloor_sponsor_flip_wall_page_handler($page) {	
	// load the flipwall stuff
	elgg_load_js('flipwall-jquery-flip-min-js');
	elgg_load_js('flipwall-script-js');
	elgg_load_css('flipwall-css');

	$dir = elgg_get_plugins_path() . 'phloor_sponsor_flip_wall/pages/phloor_sponsor_flip_wall';
	include "$dir/sponsors.php";
	
	return true;
}

/**
 * add 'sponsor' link to the footer menu
 *
 * @param string $hook
 * @param string $type
 * @param array $return Menu array
 * @param array $params
 * @return array
 */
function phloor_sponsor_footer_menu_setup($hook, $type, $return, $params) {
	if($hook == 'prepare' && $type == 'menu:footer') {
		$options = array(
			'name' => 'sponsors',
			'text' => elgg_echo('phloor_sponsor:sponsors'),
			'href' => 'sponsors',
			'priority' => 500,
		);
		$item = ElggMenuItem::factory($options);
		$return['default'][] = $item;	
	}
	
	return $return;
}