<?php	

/*
** Colleagues (as opposed to friends)
**
** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
** @copyright Tesserae Ltd 2009
** @link http://www.c4lpt.co.uk/ElggConsultancy.html
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

function colleagues_init()
{
	global $CONFIG;
			
	register_translations($CONFIG->pluginspath . "colleagues/languages/");
}

// Initialise this plugin
register_elgg_event_handler('init','system','colleagues_init');

?>
