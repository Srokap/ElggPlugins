<?php

/*
** Colleagues (as opposed to friends)
**
** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
** @copyright Tesserae Ltd 2009
** @link http://www.c4lpt.co.uk/ElggConsultancy.html
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

$english = array(
    'friends' => "Colleagues",
    'friends:yours' => "Your colleagues",
    'friends:owned' => "%s's colleagues",
    'friends:add:successful' => "You have successfully added %s as a colleague.",
    'friends:add:failure' => "We couldn't add %s as a colleague. Please try again.",
    'friends:remove:successful' => "You have successfully removed %s from your colleagues.",
    'friends:remove:failure' => "We couldn't remove %s from your colleagues. Please try again.",
    'friends:none' => "This user hasn't added anyone as a colleague yet.",
    'friends:none:you' => "You haven't added anyone as a colleague! Search for your interests to begin finding people to follow.",
    'friends:none:found' => "No colleagues were found.",
    'friends:of:none' => "Nobody has added this user as a colleague yet.",
    'friends:of:none:you' => "Nobody has added you as a colleague yet. Start adding content and fill in your profile to let people find you!",
    'friends:of' => "Colleagues of",
    'friends:of:owned' => "People who have made %s as a colleague",
    'friends:num_display' => "Number of colleagues to display",
    'friends' => "Colleagues",
    'friends:of' => "Colleague of",
    'friends:collections' => "Collections of colleagues",
    'friends:collections:add' => "New collection of colleagues",
    'friends:addfriends' => "Add colleagues",
    'friends:collectionname' => "Collection name",
    'friends:collectionfriends' => "Colleagues in collection",
    'friends:river:created' => "%s added the colleagues widget.",
    'friends:river:updated' => "%s updated their colleagues widget.",
    'friends:river:delete' => "%s removed their colleagues widget.",
    'friends:river:add' => "%s added a new colleague",

    'river:relationship:friend' => "is now a colleague of",

    'friend:add' => "Add as a colleague",
    'friend:remove' => "Remove as a colleague",
    'friend:newfriend:subject' => "%s has added you as a colleague!",
    'friend:newfriend:body' => "%s has added you as a colleague!

To view their profile, click here:

%s

You cannot reply to this email.",

    'friends:all' => "All colleagues",

    'friends:invite' => 'Invite colleagues',
    'invitefriends:introduction' => 'To invite colleagues to join you on this network, enter their email addresses below (one per line):',
    'invitefriends:success' => 'Your colleagues were invited.',
    'invitefriends:failure' => 'Your colleagues could not be invited.',

    'file:yours:friends' => "Your colleagues' files",
    'file:friends' => "%s's colleagues' files",
    'file:friends:type:video' => "Your colleagues' videos",
    'file:friends:type:document' => "Your colleagues' documents",
    'file:friends:type:audio' => "Your colleagues' audio",
    'file:friends:type:image' => "Your colleagues' pictures",
    'file:friends:type:general' => "Your colleagues' general files",

    'access:friends:label' => "Colleagues",

    'feeds:friends' => "Colleagues feeds",
    'feeds:friendsfeeds' => 'Colleagues\' feeds',
    'feeds:friendswelcome' => "This page lets you view all of the feeds your colleagues have made available to their network. If any are available, you will see a list over on the righthand side. Click on a link to read the contents",

    'river:widget:title:friends' => "Colleagues' activity",
    'river:widget:description:friends' => "Show what your colleagues are up to.",

    'bookmarks:friends' => "Colleagues' bookmarks",

    'river:widget:title:friends' => "Colleagues' activity",
    'river:widget:description:friends' => "Show what your colleagues are up to.",
    'river:widgets:friends' => "Colleagues",

    'thewire:friendsdesc' => 'This widget will show the latest from your colleagues on the wire',
    'thewire:friends' => 'Your colleagues on the wire',

    'blog:user:friends' => "%s's colleagues' blog",
    'blog:friends' => "Colleagues' blogs",

    'elggchat:friendspicker:info' => "Colleagues online",

);

add_translation("en", $english);

?>
