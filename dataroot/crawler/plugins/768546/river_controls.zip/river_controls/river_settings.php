<?php

// include the Elgg engine
	include_once dirname(dirname(dirname(__FILE__))) . "/engine/start.php"; 

// maybe logged in users only?
	if(!isloggedin()){
	forward("pg/dashboard");
}
	$userid = get_loggedin_userid();
	set_page_owner($userid);

	$title = elgg_echo('riverdashboard:river_settings:title');
	$body = elgg_view_title($title);
	$body .= elgg_view('riverdashboard/river_settings');

	echo $body;
	
?>