<?php

	//Get The User's Guid
	$his_guid = get_input('user_id');
	$him = get_entity($his_guid);
	
	//Get My Guid
	$my_guid = get_loggedin_userid();

	$already_hidden = check_entity_relationship($my_guid, 'hide_user_on_river', $his_guid);
	if($already_hidden){
		remove_entity_relationship($my_guid, 'hide_user_on_river', $his_guid);
		system_message(elgg_echo('riverdashboard:hide:user:unhide'));
		forward($vars['url'] . "pg/dashboard");
	}else{
		add_entity_relationship($my_guid, 'hide_user_on_river', $his_guid);
		system_message(elgg_echo('riverdashboard:hide:user:hide'));
		forward($vars['url'] . "pg/dashboard");
	}
	




?>