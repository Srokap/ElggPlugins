<?php

	action_gatekeeper();
	//Get The User's Guid
	$the_item = get_input('object_guid');
	$direction = get_input('direction');
	
	if($direction == "cloak"){
	update_river_access_by_object($object_guid = $the_item,$access_id = ACCESS_PRIVATE);
	system_message(elgg_echo('riverdashboard:hide:others:cloak'));
	forward($vars['url'] . "pg/dashboard");
		
	}elseif($direction == "share"){
	update_river_access_by_object($object_guid = $the_item,$access_id = ACCESS_FRIENDS);				
	system_message(elgg_echo('riverdashboard:hide:others:share'));
	forward($vars['url'] . "pg/dashboard");

	}else{
	register_error(elgg_echo('riverdashboard:hide:others:fail'));
	forward($vars['url'] . "pg/dashboard");
		
	}
	
	




?>