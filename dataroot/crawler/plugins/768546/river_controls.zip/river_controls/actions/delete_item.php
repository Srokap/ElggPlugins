<?php

	action_gatekeeper();
	//Get The User's Guid
	$the_item = get_input('item_id');
	
	if($the_item){
	remove_from_river_by_id($the_item);
	} 
	system_message(elgg_echo('riverdashboard:hide:delete:success'));
	forward($vars['url'] . "pg/dashboard");	
	



?>