<?php

	action_gatekeeper();
	//Get The User's Guid
	$the_type = get_input('the_type');
	
	//Get My Guid
	$my_guid = get_loggedin_userid();
	$me = get_entity($my_guid);
	if($me->$the_type){
		remove_metadata($my_guid,$the_type,$value = "");		
		system_message(elgg_echo('riverdashboard:hide:type:unhide'));
		forward($vars['url'] . "pg/dashboard");
	}else{
		create_metadata($my_guid,$the_type,'hidden','text',$my_guid,$access_id = ACCESS_PRIVATE,$allow_multiple = false);
		system_message(elgg_echo('riverdashboard:hide:type:hide'));
		forward($vars['url'] . "pg/dashboard");
	}
	




?>