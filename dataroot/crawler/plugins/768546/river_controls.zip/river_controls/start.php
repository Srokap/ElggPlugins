<?php

/**
 * Elgg river dashboard plugin
 *
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider Ltd <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.org/
 */

function river_controls_init() {

	global $CONFIG;

	elgg_extend_view('css', 'river_controls/css');
}

register_elgg_event_handler('init', 'system', 'river_controls_init');


// Register actions
register_action("river_controls/hide_from_others", FALSE, $CONFIG->pluginspath . "river_controls/actions/hide_from_others.php", FALSE);
register_action("river_controls/hide_user", FALSE, $CONFIG->pluginspath . "river_controls/actions/hide_user.php", FALSE);
register_action("river_controls/hide_type", FALSE, $CONFIG->pluginspath . "river_controls/actions/hide_type.php", FALSE);
register_action("river_controls/delete_item", FALSE, $CONFIG->pluginspath . "river_controls/actions/delete_item.php", FALSE);

