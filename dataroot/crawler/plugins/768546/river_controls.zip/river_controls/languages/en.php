<?php

$english = array(
	'river_controls:river_settings:title' => "River Settings",
	'river_controls:hide:user:unhide' => "This user is now active on your river",
	'river_controls:hide:user:hide' => "This user is now hidden on your river",
	'river_controls:hide:user:link' => "Hide User",
	'river_controls:hide:type:link' => "Hide Type",
	'Reset' => "Reset",
	'river_controls:unhide:user:link' => "Show On River",
	'river_controls:unhide:type:link' => "Show On River",
	'river_controls:hide:type:hide' => "This item type is now hidden on your river",
	'river_controls:hide:type:unhide' => "This item type is now active on your river",
	'river_controls:hide:others:cloak' => "This item is now hidden from other users",
	'river_controls:hide:others:share' => "Your friends can now see this on their rivers",
	'river_controls:hide:others:fail' => "Looks like we failed to make the changes. Try again",
	'river_controls:hide:others:link' => "Cloak",
	'river_controls:hide:others:share:link' => "Share",
	'river_controls:hide:delete:link' => "Delete",
	'river_controls:hide:delete:success' => "The item was deleted from the river",
	
	
);

add_translation("en", $english);
