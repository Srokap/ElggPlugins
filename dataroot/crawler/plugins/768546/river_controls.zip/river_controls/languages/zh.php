<?php
/**
 *
 */
$chinese = array( 
	'riverdashboard:river_settings:title' => "River Settings",
	'riverdashboard:hide:user:unhide' => "This user is now active on your river",
	'riverdashboard:hide:user:hide' => "This user is now hidden on your river",
	'riverdashboard:hide:user:link' => "Hide User",
	'riverdashboard:hide:type:link' => "Hide Type",
	'Reset' => "Reset",
	'riverdashboard:unhide:user:link' => "Show On River",
	'riverdashboard:unhide:type:link' => "Show On River",
	'riverdashboard:hide:type:hide' => "This item type is now hidden on your river",
	'riverdashboard:hide:type:unhide' => "This item type is now active on your river",
	'riverdashboard:hide:others:cloak' => "This item is now hidden from other users",
	'riverdashboard:hide:others:share' => "Your friends can now see this on their rivers",
	'riverdashboard:hide:others:fail' => "Looks like we failed to make the changes. Try again",
	'riverdashboard:hide:others:link' => "Cloak",
	'riverdashboard:hide:others:share:link' => "Share",
	'riverdashboard:hide:delete:link' => "Delete",
	'riverdashboard:hide:delete:success' => "The item was deleted from the river",

); 

add_translation('zh', $chinese); 

?>