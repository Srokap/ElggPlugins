<?php
$avatar_icon = get_plugin_setting("avatar_icon","riverdashboard");
if(!$avatar_icon) {
$avatar_icon = "icon";
}
$clock = "<img style='vertical-align:text-bottom;' src='{$vars['url']}mod/river_controls/graphics/clock.jpg'>";
$hide = "<img style='vertical-align:text-bottom;float:right;' src='{$vars['url']}mod/river_controls/graphics/closelabel.png'>";
$locked = "<img style='width:13px;height:13px;' src='{$vars['url']}mod/riverdashboard/graphics/lock.png'>";

$user_id = get_loggedin_userid();
$user = get_entity($user_id);
if($avatar_icon == "icon"){
?>
<div class="river_item">
<div class="river_<?php echo $vars['item']->type; ?>">
<div class="river_<?php echo $vars['item']->subtype; ?>">
<div class="river_<?php echo $vars['item']->action_type; ?>">
<div class="river_<?php echo $vars['item']->type; ?>_<?php if($vars['item']->subtype) echo $vars['item']->subtype . "_"; ?><?php echo $vars['item']->action_type; ?>">
<p>
<?php
echo $vars['body'];
?>
<span class="river_item_time">
(<?php
echo elgg_view_friendly_time($vars['item']->posted);
?>)
</span>
</p>
</div>
</div>
</div>
</div>
</div>
 
<?php
} else {
$ts = time();
$token = generate_action_token($ts);
$the_type = $vars['item']->subtype;
?>
 
<div class="river_item" id="river_item_<?php echo $vars['item']->id;?>" >
<?php
if(($user->guid == $vars['item']->subject_guid)|| (isadminloggedin())){
?>
<div class="river_item_controls" id="river_item_controls_<?php echo $vars['item']->id;?>"><?php echo $hide; ?>
<div class="controls_box" id="controls_box_<?php echo $vars['item']->id;?>">
<?php
//Show current access setting
$access = $vars['item']->access_id;
if($access == 0){
	echo elgg_echo('Private') . " ";
}elseif($access == 1){
	echo elgg_echo('Members') . " ";
}elseif($access == -2){
	echo elgg_echo('friends') . " ";
}elseif($access == 2){
	echo elgg_echo('Public') . " ";
}
	echo $locked . "<hr>";
	
	
	if($user_id == $vars['item']->subject_guid){
		if($vars['item']->access_id == 0){
			echo "<a style='cursor:pointer;' onclick=\"compartir(".$vars['item']->object_guid.")\">Share</a><br>";
		}elseif(($vars['item']->access_id == -2) || ($vars['item']->access_id == 2) || ($vars['item']->access_id == 1)){
			echo "<a style='cursor:pointer;' onclick=\"hide(".$vars['item']->object_guid.")\">Hide</a><br>";
		}else{}
		
		echo "<a style='cursor:pointer;' href='{$vars['url']}action/river_controls/delete_item?item_id={$vars['item']->id}&__elgg_token=$token&__elgg_ts=$ts'>Delete</a><br>";
		echo "<span><a rel='facebox' href='{$vars['url']}mod/river_controls/river_settings.php'>" . elgg_echo('settings') . "</a></span>";
	}elseif(($user_id !== $vars['item']->subject_guid) && (isadminloggedin())){
		echo "<a style='cursor:pointer;' href='{$vars['url']}action/river_controls/delete_item?item_id={$vars['item']->id}&__elgg_token=$token&__elgg_ts=$ts'>Delete</a><br>";
	}else{
		echo "<span><a href='{$vars['url']}action/river_controls/hide_user?user_id={$vars['item']->subject_guid}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:user:link') . "</a></span><br>";
		echo "<span><a href='{$vars['url']}action/river_controls/hide_type?the_type={$the_type}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:type:link') . "</a></span><br>";
		echo "<span><a rel='facebox' href='{$vars['url']}mod/river_controls/river_settings.php'>" . elgg_echo('Reset') . "</a></span>";					
	}
?>
</div>
</div>
<?php 
}
?> 
<span class="river_item_useravatar">
<?php
echo elgg_view("profile/icon",array('entity' => get_entity($vars['item']->subject_guid), 'size' => 'tiny'));
?>
</span>
  <div class="river_item_body_wrapper">
        <p class="river_item_body">
            <?php
            echo $vars['body'];
            ?>
        </p>
 
        <div id="<?php echo $vars['item']->object_guid ?>" class="ecomments_item_extras_bar">
            <div class="ecomments_item_time left">
                <?php
                echo $clock . " " . friendly_time($vars['item']->posted);
                ?>
            </div>
            <?php
            	if(is_plugin_enabled('eComments')){ 
            		echo elgg_view('eComments/river/bar', $vars);
        		} 
            ?>
        </div>
 
    </div>
    <div class="clearfloat"></div>
</div>
 
<?php
 
}//Display type end
?>
 
<script>
$('#river_item_<?php echo $vars['item']->id;?>').mouseenter(function() {
if ($('#river_item_controls_<?php echo $vars['item']->id;?>').css('display','none')) {
$("#river_item_controls_<?php echo $vars['item']->id;?>").css('display','block');
}else{
$("#river_item_controls_<?php echo $vars['item']->id;?>").css('display','none');
}
});
$('#river_item_<?php echo $vars['item']->id;?>').mouseleave(function() {
$("#river_item_controls_<?php echo $vars['item']->id;?>").css('display','none');
});
$('#river_item_controls_<?php echo $vars['item']->id;?>').mouseenter(function() {
if ($('#controls_box_<?php echo $vars['item']->id;?>').css('display','none')) {
$("#controls_box_<?php echo $vars['item']->id;?>").css('display','block');
}else{
$("#controls_box_<?php echo $vars['item']->id;?>").css('display','none');
}
});
$('#river_item_controls_<?php echo $vars['item']->id;?>').mouseleave(function() {
$("#controls_box_<?php echo $vars['item']->id;?>").css('display','none');
});

function AjaxDe(id)
{
var answer = confirm("Delete the item?");
if(answer)
{
var token = "<?php echo $token; ?>";
var ts = "<?php echo $ts; ?>";
datastr = "&item_id=" + id;
datastr += "&__elgg_token=" + token;
datastr += "&__elgg_ts=" + ts;
$.ajax({
type: "POST",
url: "<?php echo $vars['url']; ?>action/river_control/delete_item",
data: datastr,
success: function(msg){
$('#river_container').load('?callback=false');
 
}
});
}
}
function hide(id)
{
var answer = confirm("Hide the item?");
if(answer)
{
var token = "<?php echo $token; ?>";
var ts = "<?php echo $ts; ?>";
datastr = "&object_guid=" + id;
datastr += "&direction=cloak";
datastr += "&__elgg_token=" + token;
datastr += "&__elgg_ts=" + ts;
$.ajax({
type: "POST",
url: "<?php echo $vars['url']; ?>action/river_controls/hide_from_others",
data: datastr,
success: function(msg){
$('#river_container').load('?callback=false');
alert("This item has been hidden from everyone");
}
});
}
}
function compartir(id)
{
var answer = confirm("Share item?");
if(answer)
{
var token = "<?php echo $token; ?>";
var ts = "<?php echo $ts; ?>";
datastr = "&object_guid=" + id;
datastr += "&direction=share";
datastr += "&__elgg_token=" + token;
datastr += "&__elgg_ts=" + ts;
$.ajax({
type: "POST",
url: "<?php echo $vars['url']; ?>action/river_controls/hide_from_others",
data: datastr,
success: function(msg){
$('#river_container').load('?callback=false');
alert("Your friends can now see this in their activity stream");
}
});
}
}
</script>