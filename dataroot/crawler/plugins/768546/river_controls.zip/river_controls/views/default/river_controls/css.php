<?php

?>

.river_item_controls {
	display:none;
	float:right;
}
.river_item:hover .river_item_controls_, .river_item.hover .river_item_controls_ { 
	display: block;
}
.controls_box {
	display:none;
	z-index: 5000;
	float:right;
	width:150px;
	border:1px solid #A6A6A6;
	background: #FFFFFF;
	-webkit-border-radius: 2px;
	-moz-border-radius: 2px;
	font-size:0.9em;
	position:absolute;
	margin-left:-75px;
	width:70px;
	padding:2px 2px 2px 4px;
}
