
<div class="contentWrapper">

<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li><a class="selected" style="cursor:pointer;" id="users_listing"><?php echo elgg_echo('people'); ?></a></li>
			<li><a style="cursor:pointer;" id="types_listing"><?php echo elgg_echo('things'); ?></a></li>

		</ul>
	</div>

<div id="river_settings_box_holder">

	<div id="users_box">
		<?php
		$ts = time();
		$token = generate_action_token($ts);
		$user_id = get_loggedin_userid();
		$user = get_entity($user_id);
		$relationships = get_entity_relationships($user_id, FALSE);
		foreach($relationships as $rel){
			if($rel->relationship =='hide_user_on_river'){
				$him = get_entity($rel->guid_two);
				$icon = "<span style='float:left;'>" . elgg_view("profile/icon",array('entity' => $him, 'size' => 'topbar')) . "</span>";
				echo "<div style='float:left;'>" . $icon . "&nbsp;" . $him->name . " | <a href='{$vars['url']}action/riverdashboard/hide_user?user_id={$rel->guid_two}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('riverdashboard:unhide:user:link') . "</a>";
				echo "</div>";
		}}
		?>
	</div>
	
	<div id="types_box" style="display:none;">
		<?php
			$objects = range(1,999);
				foreach($objects as $object){
					$name = get_subtype_from_id($object);
					if($user->$name){
						echo elgg_echo('item:object:'.$name). " | <a href='{$vars['url']}action/riverdashboard/hide_type?the_type={$name}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('riverdashboard:unhide:type:link') . "</a><br>";
					}
				}
			
		?>
	</div>

</div>

</div>

<script>
$(function(){$("#users_listing").click(function(){
	$("#types_box").hide();
	$("#users_listing").addClass("selected");
	$("#types_listing").removeClass("selected");
	$("#users_box").fadeIn();
	})});
$(function(){$("#types_listing").click(function(){
	$("#users_box").hide();
	$("#types_listing").addClass("selected");
	$("#users_listing").removeClass("selected");
	$("#types_box").fadeIn();
	
	})});
</script>