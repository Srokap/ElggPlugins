<?php
/**
 * Elgg river item wrapper.
 * Wraps all river items.
 *
 * @package Elgg
 */

//get the site admins choice avatars or action icons
$avatar_icon = get_plugin_setting("avatar_icon","riverdashboard");
if(!$avatar_icon) {
	$avatar_icon = "icon";
}
$clock = "<img style='vertical-align:text-bottom;' src='{$vars['url']}mod/river_controls/graphics/clock.jpg'>";
$hide = "<img style='vertical-align:text-bottom;float:right;' src='{$vars['url']}mod/river_controls/graphics/closelabel.png'>";

$user_id = get_loggedin_userid();
$user = get_entity($user_id);

if($avatar_icon == "icon"){

	?>
	<div class="river_item">
		<div class="river_<?php echo $vars['item']->type; ?>">
			<div class="river_<?php echo $vars['item']->subtype; ?>">
				<div class="river_<?php echo $vars['item']->action_type; ?>">
					<div class="river_<?php echo $vars['item']->type; ?>_<?php if($vars['item']->subtype) echo $vars['item']->subtype . "_"; ?><?php echo $vars['item']->action_type; ?>">
					<p>
						<?php
								echo $vars['body'];
						?>
						<span class="river_item_time">
							(<?php
								echo elgg_view_friendly_time($vars['item']->posted);
							?>)
						</span>
					</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
} else {
		$ts = time();
		$token = generate_action_token($ts);
		$the_type = $vars['item']->subtype;
	?>
	<div class="river_item" id="river_item_<?php echo $vars['item']->id;?>">
	<?php
		if(($user->guid == $vars['item']->subject_guid)|| (isadminloggedin())){
	?>
		<div class="river_item_controls" id="river_item_controls_<?php echo $vars['item']->id;?>"><?php echo $hide; ?>
		<div class="controls_box" id="controls_box_<?php echo $vars['item']->id;?>">
			<?php
				if($user_id == $vars['item']->subject_guid){
					if($vars['item']->access_id == 0){
						echo "<span><a href='{$vars['url']}action/river_controls/hide_from_others?object_guid={$vars['item']->object_guid}&direction=share&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:others:share:link') . "</a></span><br>";
					}elseif(($vars['item']->access_id == -2) || ($vars['item']->access_id == 2) || ($vars['item']->access_id == 1)){
					echo "<span><a href='{$vars['url']}action/river_controls/hide_from_others?object_guid={$vars['item']->object_guid}&direction=cloak&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:others:link') . "</a></span><br>";
					}else{}
					echo "<span><a href='{$vars['url']}action/river_controls/delete_item?item_id={$vars['item']->id}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:delete:link') . "</a></span><br>";					
					echo "<span><a rel='facebox' href='{$vars['url']}mod/river_controls/river_settings.php'>" . elgg_echo('Reset') . "</a></span>";
				}elseif(($user_id !== $vars['item']->subject_guid) && (isadminloggedin())){
					echo "<span><a href='{$vars['url']}action/river_controls/hide_user?user_id={$vars['item']->subject_guid}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:user:link') . "</a></span><br>";
					echo "<span><a href='{$vars['url']}action/river_controls/hide_type?the_type={$the_type}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:type:link') . "</a></span><br>";
					echo "<span><a href='{$vars['url']}action/river_controls/delete_item?item_id={$vars['item']->id}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:delete:link') . "</a></span><br>";					
					echo "<span><a rel='facebox' href='{$vars['url']}mod/river_controls/river_settings.php'>" . elgg_echo('Reset') . "</a></span>";
				}
				else{
					echo "<span><a href='{$vars['url']}action/river_controls/hide_user?user_id={$vars['item']->subject_guid}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:user:link') . "</a></span><br>";
					echo "<span><a href='{$vars['url']}action/river_controls/hide_type?the_type={$the_type}&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('river_controls:hide:type:link') . "</a></span><br>";
					echo "<span><a rel='facebox' href='{$vars['url']}mod/river_controls/river_settings.php'>" . elgg_echo('Reset') . "</a></span>";					
				}
			?>
			</div></div>
		<?php 
		}// If user is owner or is admin
		?> 
		<span class="river_item_useravatar">
			<?php
				echo elgg_view("profile/icon",array('entity' => get_entity($vars['item']->subject_guid), 'size' => 'tiny'));
			?>
		
		</span>
		<p class="river_item_body">
			<?php
				echo $vars['body'];
			?>
			<br>
			<span class="river_item_time">
				<?php
					echo $clock . " " . elgg_view_friendly_time($vars['item']->posted);
//					echo "<br>" . $vars['item']->type . " " . $vars['item']->subtype . " " . $vars['item']->subject_guid;
				?>
				
			</span>
		</p>
		<div class="clearfloat"></div>
	</div>
	
	<?php
}//Display type end
?>
<script>
$('#river_item_<?php echo $vars['item']->id;?>').mouseenter(function() {
	if ($('#river_item_controls_<?php echo $vars['item']->id;?>').css('display','none')) {
	$("#river_item_controls_<?php echo $vars['item']->id;?>").css('display','block');
	}else{
	$("#river_item_controls_<?php echo $vars['item']->id;?>").css('display','none');
	}
	});
$('#river_item_<?php echo $vars['item']->id;?>').mouseleave(function() {
	$("#river_item_controls_<?php echo $vars['item']->id;?>").css('display','none');
});
$('#river_item_controls_<?php echo $vars['item']->id;?>').mouseenter(function() {
	if ($('#controls_box_<?php echo $vars['item']->id;?>').css('display','none')) {
	$("#controls_box_<?php echo $vars['item']->id;?>").css('display','block');
	}else{
	$("#controls_box_<?php echo $vars['item']->id;?>").css('display','none');
	}
	});
$('#river_item_controls_<?php echo $vars['item']->id;?>').mouseleave(function() {
	$("#controls_box_<?php echo $vars['item']->id;?>").css('display','none');
});
</script>