<?php

// Generado por translationbrowser 

$spanish = array( 
	 'People_you_might_know'  =>  "Personas que quizá conozcas" , 
	 'peopleyoumightknow'  =>  "Personas que quizá conozcas" ,
	 'peopleyoumightknow:seeall' => 'Ver todo', 
); 

add_translation('es', $spanish); 

?>