<?php
	$english = array(
			'people_you_might_know' => 'People you might know',
			'peopleyoumightknow' => 'People you might know',
			'peopleyoumightknow:seeall' => 'See all',
	);
					
	add_translation("en",$english);
?>