<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package Customdash
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Boris Glumpler
	 * @copyright Boris Glumpler 2008
	 * @link /travel-junkie.com
	 */

	// Put your content below
?>
