<?php
	/**
	 * Elgg customindex plugin
	 * This plugin substitutes the frontpage with a custom one
	 * 
	 * @package Customdash
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Boris Glumpler
	 * @copyright Boris Glumpler 2008
	 * @link /travel-junkie.com
	 */
	 
	// Load Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

	// Get view
	$area1 = elgg_view('customindex/content', $vars);

	// Format
	$body = elgg_view_layout('one_column', $area1);

	// Draw page
	echo page_draw(elgg_echo('this will be the page title'), $body);

?>