<?php

	$spanish = array(

'form:formtrans:kevcontent:title' => "Formulario sin perfil",
'form:formtrans:kevcontent:description' => "Probar un formulario sin perfil, ej. publicidad clasificada.",
'form:formtrans:kevcontent:response_text' => "Gracias por proveer contenido usable!",
'form:fieldtrans:kevput2:title' => "Estación favorita",
'form:fieldtrans:kevput2:description' => "En que piensas?",
'form:fieldtrans:bio:title' => "Sobre mi",
'form:fieldtrans:bio:description' => "Diga algo breve sobre usted mismo",
'form:fieldtrans:pic:title' => "Una foto",
'form:fieldtrans:pic:description' => "Subir una foto",
'form:fieldtrans:kevcal:title' => "Calendario",
'form:fieldtrans:kevcal:description' => "Seleccione uan fecha",
'form:sdtrans:kevcontent:classified_search_general:title' => "Buscar propaganda clasificada",
'form:sdtrans:kevcontent:classified_search_general:description' => "Ingrese su criterio de busqueda a continuación.",
'form:sdtrans:kevcontent:testsearch1:title' => "Busqueda de prueba",
'form:sdtrans:kevcontent:testsearch1:description' => "Esta es solamente una forma para asegurarse que el criterio de búsqueda funciona.",
'form:sdtrans:kevcontent:search1:title' => "Ejemplo de perfil de búsqueda",
'form:sdtrans:kevcontent:search1:description' => "Ingrese los valores en los campos a continuación para encontrar gente en este sitio. Si no ingresa ningún valor, el resultado inclira personas que no tienen valor asignado en este campo.",
'form:tabtrans:Basic' => "Basico",
	);
					
	add_translation("es",$spanish);
?>
