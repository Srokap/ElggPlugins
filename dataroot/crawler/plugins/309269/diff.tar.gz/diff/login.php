<?php

    /**
	 * Elgg login action
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 */
	 
	// Safety first
	//include_once(dirname(dirname(__FILE__) . "/engine/start.php");
	
		action_gatekeeper();

    // Get username and password
    
        $username = get_input('username');
        $password = get_input("password");
        $persistent = get_input("persistent", false);
        
    // If all is present and correct, try to log in  
    	$result = false;          
        if (!empty($username) && !empty($password)) {
        	if ($user = authenticate($username,$password)) {
        		$result = login($user, $persistent);
        	}
        }
        
    // Set the system_message as appropriate
        
        if ($result) {
            system_message(elgg_echo('loginok'));
            if ($_SESSION['last_forward_from'])
            {
            	$forward_url = $_SESSION['last_forward_from'];
            	$_SESSION['last_forward_from'] = "";
            	forward($forward_url);
            }
            else
            {
            	if (
            		(isadminloggedin()) &&
            		(!datalist_get('first_admin_login'))
            	) 
            	{
            		system_message(elgg_echo('firstadminlogininstructions'));
            		
            		datalist_set('first_admin_login', time());
            		
            		forward('pg/admin/plugins');
            	} else if (get_input('returntoreferer')) {
            		forward($_SERVER['HTTP_REFERER']);
            	} else
            		//forward("pg/dashboard/");
					
					
///////////////////////////////////////////////////////////////////////////////////////////////////////////////					 
	$contestado = 0;
    $num_grupos = 0;
    $contador = 0;
    $salida = 0;
				

	//Extraigo el id del usuario

  $query = "SELECT guid FROM {$CONFIG->dbprefix}users_entity ";
  $query .= " WHERE username = '".$username."'";
  
  if ($collections = get_data($query)) {
		foreach($collections as $collection)
			   $id_usuario = $collection->guid;
	  }

//Extraigo el grupo al que pertenece

//ID verdadera
  $query = "SELECT guid_two FROM {$CONFIG->dbprefix}entity_relationships ";
  $query .= " WHERE guid_one = '".$id_usuario."'";
  
  $collections = get_data($query);
  
foreach($collections as $collection){
  $contestado = 0;
  $campos = "";		
	
  $id_grupo = $collection->guid_two;
  
  ////////////////////////////////////
  
  //Nombre del grupo
  $query2 = "SELECT name FROM {$CONFIG->dbprefix}groups_entity ";
  $query2 .= " WHERE guid = '".$id_grupo."'";
  
  if ($collections2 = get_data($query2)) {
		foreach($collections2 as $collection2)
			   $nombre_grupo ="Grupo: ".$collection2->name;
	  }


  //ID para el form
  $query3 = "SELECT id FROM {$CONFIG->dbprefix}access_collections ";
  $query3 .= " WHERE name = '".$nombre_grupo."'";
  
  if ($collections3 = get_data($query3)) {
		foreach($collections3 as $collection3)
			   $id_grupo_form = $collection3->id;
	  }

  
  
  // Si el plugin ha fallado y no ha guardado la relación, la guardo yo, para que el usuario tenga permisos para acceder al formulario
  $query4 = "SELECT user_guid, access_collection_id FROM {$CONFIG->dbprefix}access_collection_membership ";
  $query4 .= " WHERE user_guid = '".$id_usuario."' AND access_collection_id = '".$id_grupo_form."'";
  
  if ($collections4 = get_data($query4)) {
		foreach($collections4 as $collection4){
		   if (empty($collection4->user_guid) AND !empty($id_grupo_form)){  
			 $resultado_insert = insert_data("INSERT into {$CONFIG->dbprefix}access_collection_membership (user_guid,access_collection_id) VALUES($id_usuario, $id_grupo_form)");
			  
	       }
      }
   } 
   else if (!empty($id_grupo_form)) {   
	   $resultado_insert = insert_data("INSERT into {$CONFIG->dbprefix}access_collection_membership (user_guid,access_collection_id) VALUES($id_usuario, $id_grupo_form)");
	   
	 }


//Extraer el subtipo de los formularios y de los campos

  $query8 = "SELECT id FROM {$CONFIG->dbprefix}entity_subtypes ";
  $query8 .= " WHERE subtype = 'form:form'";
  
  if ($collections8 = get_data($query8)) {
		foreach($collections8 as $collection8)
			    $id_subtype_form = $collection8->id;
	  }
	  
	  
	  
  $query9 = "SELECT id FROM {$CONFIG->dbprefix}entity_subtypes ";
  $query9 .= " WHERE subtype = 'form_data'";
  
  if ($collections9 = get_data($query9)) {
		foreach($collections9 as $collection9)
			    $id_subtype_data = $collection9->id;
	  }

///////////////////


  //Extraigo la id del formulario que tiene que rellenar
  $query6 = "SELECT guid FROM {$CONFIG->dbprefix}entities ";
  $query6 .= " WHERE subtype = '".$id_subtype_form."' AND access_id = '".$id_grupo_form."'";
  
  if ($collections6 = get_data($query6)) {
		foreach($collections6 as $collection6)
			    $id_form = $collection6->guid;
	  }
	  					 
						 

  //Compruebo si el usuario ya ha rellenao el formulario anterior (Si la ID del usuario ha contestado un campo perteneciente al formulario de su grupo)

  $query7 = "SELECT guid FROM {$CONFIG->dbprefix}entities ";
  $query7 .= " WHERE subtype = '".$id_subtype_data."' AND access_id = '".$id_grupo_form."' AND owner_guid = '".$id_usuario."'";
  
  if ($collections7 = get_data($query7)) {
		foreach($collections7 as $collection7)
			    if (!empty($collection7->guid))
				  $campos = $collection7->guid;
	  }


  if (!empty($campos) OR $id_form == "" OR $id_grupo == "")
	$contestado = 1;
  
  
  $grupos[$num_grupos]['id_usuario'] = $id_usuario;
  $grupos[$num_grupos]['id_grupo'] = $id_grupo_form;
  $grupos[$num_grupos]['id_formulario'] = $id_form;
  $grupos[$num_grupos]['contestado'] = $contestado;
  
  $num_grupos++;
  
 //////////////////////////////////////
}


//Lo guardo todo en una matriz y el primer contestado = 0 es el que publico

	while ($contador < $num_grupos){

 		if ($grupos[$contador]['contestado'] == 0 AND $salida == 0){
			$ruta = "mod/form/form.php?id=".$grupos[$contador]['id_formulario']; 
			$salida = 1;
  			}
		$contador++;
		}

	
	if (isadminloggedin() OR $salida == 0) {
      forward("pg/dashboard/");
	 }
	else{		
	  forward($ruta);
	 }			

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////			 
			}
        } else {
        	$error_msg = elgg_echo('loginerror');
        	// figure out why the login failed
        	if (!empty($username) && !empty($password)) {
        		// See if it exists and is disabled
				$access_status = access_get_show_hidden_status();
				access_show_hidden_entities(true);
        		if (($user = get_user_by_username($username)) && !$user->validated) {
        			// give plugins a chance to respond
        			if (!trigger_plugin_hook('unvalidated_login_attempt','user',array('entity'=>$user))) {
        				// if plugins have not registered an action, the default action is to
        				// trigger the validation event again and assume that the validation
        				// event will display an appropriate message
						trigger_elgg_event('validate', 'user', $user);
        			}
        		} else {
        			 register_error(elgg_echo('loginerror'));
        		}
        		access_show_hidden_entities($access_status);
        	} else {
            	register_error(elgg_echo('loginerror'));
        	}
        }
      
?>
