<?php
/**
 * Activity viewer
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 *
 * /// Traduction de Qualitas � partir du fichier fr.php de elg 1.7.1 traduit par ManUtopiK � partir du fichier fr.php de elgg 1.6 traduit par Denis.Beurive
 * /// http://www.elgg.fr/pg/file/Denis.Beurive/read/17492/correction-traduction-franaise-pour-la-version-16-de-elgg
 */

$french = array(

/**
 * Sites
 */

	'item:site' => "Sites",

/**
 * Sessions
 */

	'login' => "Connexion",
	'loginok' => "Vous �tes d�sormais connect�(e).",
	'loginerror' => "Nous n'avons pas pu vous identifier. Cette erreur peut �tre due, soit, au fait que vous n'avez pas encore valid� votre compte, que les informations entr�es sont incorrectes ou que vous avez fait trop de tentatives de connexion. Assurez-vous que les informations que vous avez entr�es sont correctes et r�essayez.",

	'logout' => "D�connexion",
	'logoutok' => "Vous avez �t� d�connect�(e).",
	'logouterror' => "Nous n'avons pas pu vous connecter. Essayez de nouveau.",

	'loggedinrequired' => "Vous devez �tre connect� pour voir cette page.",
	'adminrequired' => "Vous devez �tre administrateur pour voir cette page.",
	'membershiprequired' => "Vous devez �tre membre de ce groupe pour voir cette page.",


/**
 * Errors
 */
	'exception:title' => "Bienvenue sur Elgg.",

	'InstallationException:CantCreateSite' => "Impossibilit� de cr�er le site Elgg %s � l'URL %s",

	'actionundefined' => "L'action demand�e (%s) n'est pas d�finie par le syst�me.",
	'actionloggedout' => "D�sol�, vous devez �tre connect�(e) pour ex�cuter cette action.",
	'actionunauthorized' => "Vous n'avez pas les autorisations pour faire cette action.",

	'SecurityException:Codeblock' => "Acc�s non autoris� pour la cr�ation de block.",
	'DatabaseException:WrongCredentials' => "Elgg n'a pas pu se connecter � la base de donn�es avec les informations donn�es.",
	'DatabaseException:NoConnect' => "Elgg n'a pas pu s�lectionner la base de donn�es '%s', merci de v�rifier que la base de donn�es est bien cr��e et que vous y avez acc�s.",
	'SecurityException:FunctionDenied' => "L'acc�s � la fonction privil�gi�e '%s' n'est pas accord�.",
	'DatabaseException:DBSetupIssues' => "Il y a eu plusieurs probl�mes :",
	'DatabaseException:ScriptNotFound' => "Elgg n'a pas pu trouver le script de la base de donn�es a %s.",

	'IOException:FailedToLoadGUID' => "Echec du chargement du nouveau %s avec le GUID:%d",
	'InvalidParameterException:NonElggObject' => "Types incompatibles, objet de type non-Elgg vers un constructeur d'objet Elgg !",
	'InvalidParameterException:UnrecognisedValue' => "Valeur de type non reconnu pass�e en argument.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d n'est pas valide %s",

	'PluginException:MisconfiguredPlugin' => "%s est un plugin non configur�.",

	'InvalidParameterException:NonElggUser' => "Types incompatibles, utilisateur de type non-Elgg vers un constructeur d'utilisateur Elgg !",

	'InvalidParameterException:NonElggSite' => "Types incompatibles, site de type non-Elgg vers un constructeur de site Elgg !",

	'InvalidParameterException:NonElggGroup' => "Types incompatibles, groupe de type non-Elgg vers un constructeur de groupe Elgg !",

	'IOException:UnableToSaveNew' => "Impossible de sauvegarder le nouveau %s",

	'InvalidParameterException:GUIDNotForExport' => "GUID non sp�cifi� durant l'export, ceci ne devrait pas se produire.",
	'InvalidParameterException:NonArrayReturnValue' => "La fonction de s�rialisation de l'entit� a retourn� une valeur dont le type n'est pas un tableau.",

	'ConfigurationException:NoCachePath' => "Le chemin du cache est vide !",
	'IOException:NotDirectory' => "%s n'est pas un r�pertoire.",

	'IOException:BaseEntitySaveFailed' => "Impossibilit� de sauver les informations de bases du nouvel objet !",
	'InvalidParameterException:UnexpectedODDClass' => "import() a pass� un argument qui n'est pas du type ODD class",
	'InvalidParameterException:EntityTypeNotSet' => "Le type d'entit� doit �tre renseign�.",

	'ClassException:ClassnameNotClass' => "%s n'est pas %s.",
	'ClassNotFoundException:MissingClass' => "La classe '%s' n'a pas �t� trouv�e, le plugin serait-il manquant ?",
	'InstallationException:TypeNotSupported' => "Le type %s n'est pas support�. Il y a une erreur dans votre installation, le plus souvent caus� par une mise � jour non-compl�te.",

	'ImportException:ImportFailed' => "Impossible d'importer l'�l�ment %d",
	'ImportException:ProblemSaving' => "Une erreur est survenue en sauvant %s",
	'ImportException:NoGUID' => "La nouvelle entit� a �t� cr��e mais n'a pas de GUID, ceci ne devrait pas se produire.",

	'ImportException:GUIDNotFound' => "L'entit� '%d' n'a pas �t� trouv�e.",
	'ImportException:ProblemUpdatingMeta' => "Il y a eu un probl�me lors de la mise � jour de '%s' pour l'entit� '%d'",

	'ExportException:NoSuchEntity' => "Il n'y a pas d'entit� telle que GUID:%d",

	'ImportException:NoODDElements' => "Aucun �l�ment OpenDD n'a �t� trouv� dans les donn�es import�es, l'importation a �chou�.",
	'ImportException:NotAllImported' => "Tous les �l�ments n'ont pas �t� import�s.",

	'InvalidParameterException:UnrecognisedFileMode' => "Mode de fichier non-reconnu : '%s'",
	'InvalidParameterException:MissingOwner' => "Tous les fichiers doivent avoir un propri�taire",
	'IOException:CouldNotMake' => "Impossible de faire %s",
	'IOException:MissingFileName' => "Vous devez sp�cifier un nom avant d'ouvrir un fichier.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "Fichiers stock�s non trouv�s ou classes non sauvegard�es avec le fichier !",
	'NotificationException:NoNotificationMethod' => "Aucune m�thode de notification sp�cifi�e.",
	'NotificationException:NoHandlerFound' => "Aucune fonction trouv�e pour '%s' ou elle ne peut �tre appel�e.",
	'NotificationException:ErrorNotifyingGuid' => "Une erreur s'est produite lors de la notification %d",
	'NotificationException:NoEmailAddress' => "Impossible de trouver une adresse email pour GUID:%d",
	'NotificationException:MissingParameter' => "Un argument obligatoire a �t� omis, '%s'",

	'DatabaseException:WhereSetNonQuery' => "La requ�te where ne contient pas de WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Des champs sont manquants sur la requ�te de s�lection.",
	'DatabaseException:UnspecifiedQueryType' => "Type de requ�te non-reconnue ou non-sp�cifi�e.",
	'DatabaseException:NoTablesSpecified' => "Aucune table sp�cifi�e pour la requ�te.",
	'DatabaseException:NoACL' => "Pas de liste d'acc�s fourni pour la requ�te",

	'InvalidParameterException:NoEntityFound' => "Aucune entit� trouv�e, soit elle est inexistante, soit vous n'y avez pas acc�s.",

	'InvalidParameterException:GUIDNotFound' => "GUID : %s n'a pas �t� trouv� ou vous n'y avez pas acc�s.",
	'InvalidParameterException:IdNotExistForGUID' => "D�sol�, '%s' n'existe pas pour GUID : %d",
	'InvalidParameterException:CanNotExportType' => "D�sol�, je ne sais pas comment exporter '%s'",
	'InvalidParameterException:NoDataFound' => "Aucune donn�e trouv�e.",
	'InvalidParameterException:DoesNotBelong' => "N'appartient pas � l'entit�.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "N'appartient pas ou aucune r�f�rence � l'entit�.",
	'InvalidParameterException:MissingParameter' => "Argument manquant, il faut fournir un GUID.",

	'APIException:ApiResultUnknown' => "Les r�sultats de API sont de types inconnus, ceci ne devrait pas se produire.",
	'ConfigurationException:NoSiteID' => "L'identifiant du site n'a pas �t� sp�cifi�.",
	'SecurityException:APIAccessDenied' => "D�sol�, l'acc�s API a �t� d�sactiv� par l'administrateur.",
	'SecurityException:NoAuthMethods' => "Aucune m�thode d'authentification n'a �t� trouv�e pour cette requ�te API.",
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Methode ou fonction non d�finie dans expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "Le param�tre de structure 'array' est incorrect pour appeller to expose method '%s'",
	'InvalidParameterException:UnrecognisedHttpMethod' => "http method %s pour l'api methode '%s' non reconnue",
	'APIException:MissingParameterInMethod' => "Argument %s manquant pour la m�thode %s",
	'APIException:ParameterNotArray' => "%s n'est semble t-il pas un tableau.",
	'APIException:UnrecognisedTypeCast' => "Type %s non reconnu pour la variable '%s' pour la fonction '%s'",
	'APIException:InvalidParameter' => "Param�tre invalide pour '%s' pour la fonction '%s'.",
	'APIException:FunctionParseError' => "%s(%s) a une erreur d'analyse.",
	'APIException:FunctionNoReturn' => "%s(%s) ne retourne aucune valeur.",
	'APIException:APIAuthenticationFailed' => "Echec d'authentification d'API par l'appel de m�thode",
	'APIException:UserAuthenticationFailed' => "Echec d'authentification d'utilisateur par l'appel de m�thode",
	'SecurityException:AuthTokenExpired' => "Le jeton d'authentification est manquant, invalide ou expir�.",
	'CallException:InvalidCallMethod' => "%s doit �tre appel� en utilisant '%s'",
	'APIException:MethodCallNotImplemented' => "L'appel � la m�thode '%s' n'a pas �t� impl�ment�.",
	'APIException:FunctionDoesNotExist' =>"La function pour la method '%s' n'est pas appellable",
	'APIException:AlgorithmNotSupported' => "L'algorithme '%s' n'est pas support� ou a �t� d�sactiv�.",
	'ConfigurationException:CacheDirNotSet' => "Le r�pertoire de cache 'cache_path' n'a pas �t� renseign�.",
	'APIException:NotGetOrPost' => "La m�thode de requ�te doit �tre GET ou POST",
	'APIException:MissingAPIKey' => "X-Elgg-apikey manquant dans l'ent�te HTTP",
	'APIException:BadAPIKey' => "Mauvaise cl� API",
	'APIException:MissingHmac' => "X-Elgg-hmac manquant dans l'ent�te",
	'APIException:MissingHmacAlgo' => "X-Elgg-hmac-algo manquant dans l'ent�te",
	'APIException:MissingTime' => "X-Elgg-time manquant dans l'ent�te",
	'APIException:MissingNonce' => "X-Elgg-nonce header manquant",
	'APIException:TemporalDrift' => "X-Elgg-time est trop �loign� dans le temps. Epoch a �chou�.",
	'APIException:NoQueryString' => "Aucune valeur dans la requ�te",
	'APIException:MissingPOSTHash' => "X-Elgg-posthash manquant dans l'ent�te",
	'APIException:MissingPOSTAlgo' => "X-Elgg-posthash_algo manquant dans l'ent�te",
	'APIException:MissingContentType' => "Le content-type est manquant pour les donn�es post�es",
	'SecurityException:InvalidPostHash' => "La signature des donn�es POST est invalide.%s attendu mais %s re�u.",
	'SecurityException:DupePacket' => "La signature du paquet a d�j� �t� envoy�e.",
	'SecurityException:InvalidAPIKey' => "API Key invalide ou non-reconnue.",
	'NotImplementedException:CallMethodNotImplemented' => "La m�thode '%s' n'est pas support�e actuellement.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "L'appel � la m�thode XML-RPC '%s' n'a pas �t� impl�ment�e.",
	'InvalidParameterException:UnexpectedReturnFormat' => "L'appel � la m�thode '%s' a retourn� un r�sultat inattendu.",
	'CallException:NotRPCCall' => "L'appel ne semble pas �tre un appel XML-RPC valide",

	'PluginException:NoPluginName' => "Le nom du plugin n'a pas pu �tre trouv�",

	'ConfigurationException:BadDatabaseVersion' => "La version de la base de donn�es ne correspondant pas au minimum requis par Elgg. Veuillez vous r�f�rer � la documentation de Elgg.",
	'ConfigurationException:BadPHPVersion' => "Elgg requiert au minimum PHP 5.2.",
	'configurationwarning:phpversion' => "Elgg requiert au minimum PHP 5.2, une installation est possible sur 5.1.6 au risque de perdre quelques fonctionnalit�s. A utiliser � vos risques et p�rils.",


	'InstallationException:DatarootNotWritable' => "Le r�pertoire des donn�es %s n'est pas accessible en �criture.",
	'InstallationException:DatarootUnderPath' => "Le r�pertoire des donn�es %s doit �tre en dehors de votre dossier d'installation de Elgg.",
	'InstallationException:DatarootBlank' => "Vous n'avez pas sp�cifi� de dossier pour le stockage des fichiers.",

	'SecurityException:authenticationfailed' => "Impossible d'authentifier l'utilisateur",

	'CronException:unknownperiod' => "%s n'est pas une p�riode valide.",

	'SecurityException:deletedisablecurrentsite' => "Impossible de supprimer ou d�sactiver le site en cours !",

	'RegistrationException:EmptyPassword' => 'Le champs mot de passe ne peut pas rester vide',
	'RegistrationException:PasswordMismatch' => 'Les mots de passes doivent �tre identiques',

	'memcache:notinstalled' => "Le module PHP memcache n'est pas install�. Vous devez installer php5-memcache",
	'memcache:noservers' => "Pas de serveur memcache d�fini, veuillez renseigner la variable ",
	'memcache:versiontoolow' => "Memcache n�cessite au minimum la version %s pour fonctionner, vous avez la version %s",
	'memcache:noaddserver' => "Le support de serveurs multiples est d�sactiv�, vous avez peut-�tre besoin de mettre � jour votre biblioth�que memcache PECL",

	'deprecatedfunction' => "Attention : Ce code source utilise une fonction p�rim�e '%s'. Il n'est pas compatible avec cette version de Elgg.",

	'pageownerunavailable' => "Attention : La page de l'utilisateur %d n'est pas accessible.",
	'changebookmark' => 'S.V.P. Veuillez changer vos bookmark pour cette page',
/**
 * API
 */
	'system.api.list' => "Liste tous les appels API au syst�me.",
	'auth.gettoken' => "Cet appel API permet � un utilisateur de se connecter, il retourne une clef d'authentification qui permet de rendre la tentative de connexion unique.",

/**
 * User details
 */

	'name' => "Nom � afficher",
	'email' => "Adresse mail",
	'username' => "Nom d'utilisateur",
	'password' => "Mot de passe",
	'passwordagain' => "Confirmation du mot de passe",
	'admin_option' => "D�finir cet utilisateur comme administrateur ?",

/**
 * Access
 */

	'PRIVATE' => "Priv�",
	'LOGGED_IN' => "Utilisateurs connect�s",
	'PUBLIC' => "Publique",
	'access:friends:label' => "Contacts",
	'access' => "Acc�s",

/**
 * Dashboard and widgets
 */

	'dashboard' => "Tableau de bord",
	'dashboard:configure' => "Modifier cette page",
	'dashboard:nowidgets' => "Votre tableau de bord est votre page d'accueil sur le site. Cliquez sur 'Modifier cette page' pour ajouter des widgets pour garder un oeil sur le contenu et votre activit� sur le site.",

	'widgets:add' => "Ajouter des widgets � votre page",
	'widgets:add:description' => "Choisissez les fonctionnalit�s � faire appara�tre en glissant un �l�ment de <b>la liste de Widgets</b> sur la droite, vers l'une des trois zones ci-dessous. Positionnez-les selon vos envies.

Pour retirer un widget, glissez le vers <b>la liste de Widgets</b>.",
	'widgets:position:fixed' => "(Position modifi�e sur la page)",

	'widgets' => "Widgets",
	'widget' => "Widget",
	'item:object:widget' => "Widgets",
	'layout:customise' => "Personnaliser la mise en page",
	'widgets:gallery' => "Liste des widgets",
	'widgets:leftcolumn' => "Widgets de gauche",
	'widgets:fixed' => "Position modifi�e",
	'widgets:middlecolumn' => "Widgets du milieu",
	'widgets:rightcolumn' => "Widgets de droite",
	'widgets:profilebox' => "Boite de profil",
	'widgets:panel:save:success' => "Vos widgets ont �t� sauvegard�s avec succ�s.",
	'widgets:panel:save:failure' => "Un probl�me est survenu lors de l'enregistrement de vos widgets. Veuillez recommencer.",
	'widgets:save:success' => "Le widget a �t� sauvegard� avec succ�s.",
	'widgets:save:failure' => "Un probl�me est survenu lors de l'enregistrement de votre widget. Veuillez recommencer.",
	'widgets:handlernotfound' => "Ce widget est ou bien cass�, ou alors a �t� d�sactiv� par l'administrateur du site.",

/**
 * Groups
 */

	'group' => "Groupe",
	'item:group' => "Groupes",

/**
 * Users
 */

	'user' => "Utilisateur",
	'item:user' => "Utilisateurs",

/**
 * Friends
 */

	'friends' => "Contacts",
	'friends:yours' => "Vos contacts",
	'friends:owned' => "Les contacts de %s",
	'friend:add' => "Ajouter un contact",
	'friend:remove' => "Supprimer un contact",

	'friends:add:successful' => "Vous avez ajout� %s � vos contacts.",
	'friends:add:failure' => "%s n'a pas pu �tre ajout�(e) � vos contacts. Merci de r�essayer ult�rieurement.",

	'friends:remove:successful' => "Vous avez supprim� %s de vos contacts.",
	'friends:remove:failure' => "%s n'a pas pu �tre supprim�(e) de vos contacts. Merci de r�essayer ult�rieurement.",

	'friends:none' => "Cet utilisateur n'a pas encore ajout� de contact.",
	'friends:none:you' => "Vous n'avez pas ajout� de contact ! Recherchez des personnes qui partagent vos centre d'int�r�t avec le moteur de recherche.",

	'friends:none:found' => "Aucun contact n'a �t� trouv�.",

	'friends:of:none' => "Personne n'a encore ajout� cet utilisateur comme contact.",
	'friends:of:none:you' => "Personne ne vous a encore ajout� comme contact. Commencez par remplir votre page profil et publiez du contenu pour que les gens vous trouvent !",

	'friends:of:owned' => "Les personnes qui ont %s dans leurs contacts",

	'friends:of' => "Contacts de",
	'friends:collections' => "Groupement de contacts",
	'friends:collections:add' => "Nouveau groupement de contacts",
	'friends:addfriends' => "Ajouter des contacts",
	'friends:collectionname' => "Nom du groupement",
	'friends:collectionfriends' => "Contacts dans le groupement",
	'friends:collectionedit' => "Modifier ce groupement",
	'friends:nocollections' => "Vous n'avez pas encore de groupement de contacts.",
	'friends:collectiondeleted' => "Votre groupement de contacts a �t� supprim�.",
	'friends:collectiondeletefailed' => "Le groupement de contacts n'a pas �t� supprimer. Ou bien vous n'avez pas de droits suffisants, ou un autre probl�me peut-�tre en cause.",
	'friends:collectionadded' => "Votre groupement de contact a �t� cr�� avec succ�s",
	'friends:nocollectionname' => "Vous devez nommer votre groupement de contact avant qu'il puisse �tre cr��.",
	'friends:collections:members' => "Membres du groupement",
	'friends:collections:edit' => "Modifier le groupement de contacts",

	'friends:river:add' => "%s est maintenant dans les contacts de",

	'friendspicker:chararray' => "ABCDEFGHIJKLMNOPQRSTUVWXYZ",

/**
 * Feeds
 */
	'feed:rss' => "S'abonner au fil RSS",
	'feed:odd' => "Syndication OpenDD",

/**
 * links
 **/

	'link:view' => "voir le lien",


/**
 * River
 */
	'river' => "River",
	'river:relationship:friend' => "est maintenant dans les contacts de",
	'river:noaccess' => "Vous n'avez pas la permission de voir cet �l�ment.",
	'river:posted:generic' => "%s envoy�",
	'riveritem:single:user' => "un utilisateur",
	'riveritem:plural:user' => "des utilisateurs",

/**
 * Plugins
 */
	'plugins:settings:save:ok' => "Le param�trage du plugin %s a �t� enregistr�.",
	'plugins:settings:save:fail' => "Il y a eu un probl�me lors de l'enregistrement des param�tres du plugin %s.",
	'plugins:usersettings:save:ok' => "Le param�trage du plugin a �t� enregistr� avec succ�s.",
	'plugins:usersettings:save:fail' => "Il y a eu un probl�me lors de l'enregistrement du param�trage du plugin %s.",
	'admin:plugins:label:version' => "Version",
	'item:object:plugin' => "Param�tres de configuration du plugin",

/**
 * Notifications
 */
	'notifications:usersettings' => "Configuration des messages du site",
	'notifications:methods' => "Choisissez votre mode de r�ception des messages du site.",

	'notifications:usersettings:save:ok' => "La configuration des messages du site a �t� enregistr�e avec succ�s.",
	'notifications:usersettings:save:fail' => "Il y a eu un probl�me lors de la sauvegarde des param�tres de configuration des messages du site.",

	'user.notification.get' => "Renvoie les param�tres de messages du site pour un utilisateur donn�.",
	'user.notification.set' => "D�finir les param�tres de messages du site pour un utilisateur donn�.",
/**
 * Search
 */

	'search' => "Rechercher",
	'searchtitle' => "Rechercher : %s",
	'users:searchtitle' => "Recherche des utilisateurs : %s",
	'groups:searchtitle' => "Rechercher des groupes : %s",
	'advancedsearchtitle' => "%s r�sultat(s) trouv�(s) pour %s",
	'notfound' => "Aucun r�sultat trouv�.",
	'next' => "Suivant",
	'previous' => "Pr�c�dent",

	'viewtype:change' => "Changer le type de liste",
	'viewtype:list' => "Lister les vues",
	'viewtype:gallery' => "Galerie",

	'tag:search:startblurb' => "El�ments avec le(s) mot(s)-cl� '%s' :",

	'user:search:startblurb' => "Utilisateurs avec le(s) mot(s)-cl� '%s' :",
	'user:search:finishblurb' => "Cliquez ici pour plus de r�sultats...",

	'group:search:startblurb' => "Groupes qui v�rifient le crit�re : %s",
	'group:search:finishblurb' => "Pour en savoir plus, cliquez ici.",
	'search:go' => "Rechercher",
	'userpicker:only_friends' => "Seulement les amis",

/**
 * Account
 */

	'account' => "Compte",
	'settings' => "Votre compte",
	'tools' => "Outils",
	'tools:yours' => "Vos outils",

	'register' => "S'enregistrer",
	'registerok' => "Vous vous �tes enregistr� avec succ�s sur %s.",
	'registerbad' => "Votre cr�ation de compte n'a pas fonctionn�. Le nom utilisateur existe peut-�tre d�j�, vos mots de passe ne correspondent pas, ou votre nom d'utilisateur ou votre mot de passe est peut-�tre trop court (6 caract�res min.)",
	'registerdisabled' => "La cr�ation de compte a �t� d�sactiv� par l'administrateur du site.",

	'firstadminlogininstructions' => "Votre nouveau site Elgg a �t� install� avec succ�s et votre compte administrateur a �t� cr��. Vous pouvez maintenant configurer votre site en activant les diff�rents plugins disponibles dans le panneau d'administration.",

	'registration:notemail' => "L'adresse e-mail que vous avez renseign� n'appara�t pas comme valide.",
	'registration:userexists' => "Ce nom d'utilisateur existe d�j�",
	'registration:usernametooshort' => "Le nom d'utilisateur doit faire 4 caract�res au minimum.",
	'registration:passwordtooshort' => "Le mot de passe doit faire 6 caract�res au minimum.",
	'registration:dupeemail' => "Cette adresse e-mail est d�j� utilis�e.",
	'registration:invalidchars' => "D�sol�, votre nom d'utilisateur contient des caract�res invalides.",
	'registration:emailnotvalid' => "D�sol�, l'adresse e-mail que vous avez entr� est invalide sur ce site.",
	'registration:passwordnotvalid' => "D�sol�, le mot de passe que vous avez entr� est invalide sur ce site.",
	'registration:usernamenotvalid' => "D�sol�, le nom d'utilisateur que vous avez entr� est invalide sur ce site.",

	'adduser' => "Ajouter un utilisateur",
	'adduser:ok' => "Vous avez ajout� un nouvel utilisateur avec succ�s.",
	'adduser:bad' => "Le nouvel utilisateur ne peut pas �tre cr��.",

	'item:object:reported_content' => "Abus signal�s",

	'user:set:name' => "Nom",
	'user:name:label' => "Votre nom",
	'user:name:success' => "Votre nom a �t� chang� avec succ�s.",
	'user:name:fail' => "Impossible de changer votre nom.",

	'user:set:password' => "Mot de passe",
	'user:current_password:label' => "Votre mot de passe actuel",
	'user:password:label' => "Votre nouveau mot de passe",
	'user:password2:label' => "Veuillez retaper votre nouveau mot de passe",
	'user:password:success' => "Mot de passe modifi� avec succ�s",
	'user:password:fail' => "Impossible de modifier votre mot de passe.",
	'user:password:fail:notsame' => "Les deux mots de passe ne correspondent pas !",
	'user:password:fail:tooshort' => "Le mot de passe est trop court !",
	'user:password:fail:incorrect_current_password' => 'Mot de passe incorrect.',
	'user:resetpassword:unknown_user' => "Utilisateur inconnu.",
	'user:resetpassword:reset_password_confirm' => "Apr�s r�initialisation de votre mot de passe, celui-ci sera envoy� � votre adresse e-mail.",

	'user:set:language' => "Langue",
	'user:language:label' => "Votre langue",
	'user:language:success' => "Votre param�tre de langage a �t� mis � jour.",
	'user:language:fail' => "Votre param�tre de langage n'a pas pu �tre sauvegard�.",

	'user:username:notfound' => "Nom d'utilisateur %s non trouv�.",

	'user:password:lost' => "Mot de passe perdu ?",
	'user:password:resetreq:success' => "Vous avez demand� un nouveau mot de passe, un e-mail vous a �t� envoy�",
	'user:password:resetreq:fail' => "Impossible de demander un nouveau mot de passe.",

	'user:password:text' => "Pour g�n�rer un nouveau mot de passe, entrez votre nom d'utilisateur ci-dessous. Nous vous enverrons un lien par mail. Vous devrez cliquer sur le lien du message et un nouveau mot de passe vous sera donn�.",

	'user:persistent' => "Se souvenir de moi",
/**
 * Administration
 */

	'admin:configuration:success' => "Vos param�tres ont �t� sauvegard�s.",
	'admin:configuration:fail' => "Vos param�tres n'ont pas pu �tre sauvegard�s.",

	'admin' => "Administration",
	'admin:description' => "Le panneau d'administration vous permet de contr�ler tous les aspects du syst�me d'Elgg, de la gestion des utilisateurs � la gestion des outils install�s. Choisissez une option dans le menu ci-contre pour commencer.",

	'admin:user' => "Gestion des utilisateurs",
	'admin:user:description' => "Ce menu vous permet de contr�ler les param�tres des utilisateurs sur votre site. Choisissez une option ci-dessous pour commencer.",
	'admin:user:adduser:label' => "Cliquer ici pour ajouter un nouvel utilisateur...",
	'admin:user:opt:linktext' => "Configurer les utilisateurs...",
	'admin:user:opt:description' => "Configurer les utilisateurs et les informations de compte. ",

	'admin:site' => "Gestion du site",
	'admin:site:description' => "Ce menu vous permet de d�finir les param�tres principaux de votre site. Choisissez une option ci-dessous pour commencer.",
	'admin:site:opt:linktext' => "Configurer le site...",
	'admin:site:opt:description' => "Configurer les param�tres techniques et non techniques du site. ",
	'admin:site:access:warning' => "Changer les param�tres d'acc�s n'affectera que les permissions de contenu cr��es dans le futur.",

	'admin:plugins' => "Gestion des outils",
	'admin:plugins:description' => "Ce menu vous permet de contr�ler et de configurer les outils install�s sur votre site.",
	'admin:plugins:opt:linktext' => "Configurer les outils...",
	'admin:plugins:opt:description' => "Configurer les outils install�s sur le site. ",
	'admin:plugins:label:author' => "Auteur",
	'admin:plugins:label:copyright' => "Copyright",
	'admin:plugins:label:licence' => "Licence",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => "Plus d'informations",
	'admin:plugins:label:version' => "Version",
	'admin:plugins:warning:elggversionunknown' => "Attention : Ce plugin ne sp�cifie pas une compatibilit� pour cette version de Elgg.",
	'admin:plugins:warning:elggtoolow' => "Attention : Ce plugin requiert une version ant�rieure de Elgg !",
	'admin:plugins:reorder:yes' => "Le plugin %s a �t� r�ordonn� avec succ�s.",
	'admin:plugins:reorder:no' => "Le plugin %s n'a pas pu �tre r�ordonn�.",
	'admin:plugins:disable:yes' => "Le plugin %s a �t� d�sactiv� avec succ�s.",
	'admin:plugins:disable:no' => "Le plugin %s n'a pas pu �tre d�sactiv�.",
	'admin:plugins:enable:yes' => "Le plugin %s a �t� activ� avec succ�s.",
	'admin:plugins:enable:no' => "Le plugin %s n'a pas pu �tre activ�.",

	'admin:statistics' => "Statistiques",
	'admin:statistics:description' => "Cette page est un r�sum� des statistiques de votre site. Si vous avez besoin de statistiques plus d�taill�es, une version professionnelle d'administration est disponible.",
	'admin:statistics:opt:description' => "Voir des informations statistiques sur les utilisateurs et les objets de votre site.",
	'admin:statistics:opt:linktext' => "Voir statistiques...",
	'admin:statistics:label:basic' => "Statistiques basiques du site",
	'admin:statistics:label:numentities' => "Entit�s sur le site",
	'admin:statistics:label:numusers' => "Nombre d'utilisateurs",
	'admin:statistics:label:numonline' => "Nombre d'utilisateurs en ligne",
	'admin:statistics:label:onlineusers' => "Utilisateurs en ligne actuellement",
	'admin:statistics:label:version' => "Version d'Elgg",
	'admin:statistics:label:version:release' => "Release",
	'admin:statistics:label:version:version' => "Version",

	'admin:user:label:search' => "Trouver des utilisateurs :",
	'admin:user:label:searchbutton' => "Chercher",

	'admin:user:ban:no' => "Cet utilisateur ne peut pas �tre banni",
	'admin:user:ban:yes' => "Utilisateur banni.",
	'admin:user:unban:no' => "Cet utilisateur ne peut pas �tre r�int�gr�",
	'admin:user:unban:yes' => "Utilisateur r�int�gr�.",
	'admin:user:delete:no' => "Cet utilisateur ne peut pas �tre supprim�",
	'admin:user:delete:yes' => "Utilisateur supprim�",

	'admin:user:resetpassword:yes' => "Mot de passe r�initialis�, utilisateur notifi�.",
	'admin:user:resetpassword:no' => "Le mot de passe n'a pas pu �tre r�initialis�.",

	'admin:user:makeadmin:yes' => "L'utilisateur est maintenant un administrateur.",
	'admin:user:makeadmin:no' => "Nous ne pouvons pas faire de cet utilisateur un administrateur.",

	'admin:user:removeadmin:yes' => "L'utilisateur n'est plus administrateur.",
	'admin:user:removeadmin:no' => "Nous ne pouvons pas supprimer les privil�ges d'administrateur � cet utilisateur.",

/**
 * User settings
 */
	'usersettings:description' => "Le panneau de configuration vous permet de contr�ler tous vos param�tres et vos plugins. Choisissez une option ci-dessous pour continuer.",

	'usersettings:statistics' => "Vos statistiques",
	'usersettings:statistics:opt:description' => "Visualiser les statistiques des utilisateurs et des objets sur votre espace.",
	'usersettings:statistics:opt:linktext' => "Statistiques de votre compte.",

	'usersettings:user' => "Vos param�tres",
	'usersettings:user:opt:description' => "Ceci vous permet de contr�ler vos param�tres.",
	'usersettings:user:opt:linktext' => "Changer vos param�tres",

	'usersettings:plugins' => "Outils",
	'usersettings:plugins:opt:description' => "Configurer vos param�tres (s'il y a lieu) pour activer vos outils.",
	'usersettings:plugins:opt:linktext' => "Configurer vos outils",

	'usersettings:plugins:description' => "Ce panneau de configuration vous permez de mettre � jour les options de vos outils install�s par l'administrateur.",
	'usersettings:statistics:label:numentities' => "Vos entit�s",

	'usersettings:statistics:yourdetails' => "Vos informations",
	'usersettings:statistics:label:name' => "Votre nom",
	'usersettings:statistics:label:email' => "Email",
	'usersettings:statistics:label:membersince' => "Membre depuis",
	'usersettings:statistics:label:lastlogin' => "Derni�re connexion",



/**
 * Generic action words
 */

	'save' => "Enregistrer",
	'publish' => "Publier",
	'cancel' => "Annuler",
	'saving' => "Enregistrement en cours",
	'update' => "Mettre � jour",
	'edit' => "Modifier",
	'delete' => "Supprimer",
	'accept' => "Accepter",
	'load' => "Charger",
	'upload' => "Charger",
	'ban' => "Bannir",
	'unban' => "R�int�grer",
	'enable' => "Activer",
	'disable' => "D�sactiver",
	'request' => "Requ�te",
	'complete' => "Compl�ter",
	'open' => "Ouvrir",
	'close' => "Fermer",
	'reply' => "R�pondre",
	'more' => "Plus",
	'comments' => "Commentaires",
	'import' => "Importer",
	'export' => "Exporter",
	'untitled' => "Sans titre",
	'help' => "Aide",
	'send' => "Envoyer",
	'post' => "Poster",
	'submit' => "Soumettre",
	'site' => "Site",

	'up' => "Monter",
	'down' => "Descendre",
	'top' => "Au dessus",
	'bottom' => "Au dessous",

	'invite' => "Inviter",

	'resetpassword' => "Reset password",
	'makeadmin' => "Rendre l'utilisateur administrateur",
	'removeadmin' => "Supprimer les droits administrateur de l'utilisateur",

	'option:yes' => "Oui",
	'option:no' => "Non",

	'unknown' => "Inconnu",

	'active' => "Activ�",
	'total' => "Total",

	'learnmore' => "Cliquer ici pour en apprendre plus.",

	'content' => "contenu",
	'content:latest' => "Derni�re activit�",
	'content:latest:blurb' => "Vous pouvez �galement cliquer ici pour voir les derni�res modifications effectu�es sur le site.",

	'link:text' => "voir le lien",

	'enableall' => "Tout activer",
	'disableall' => "Tout d�sactiver",

/**
 * Generic questions
 */

	'question:areyousure' => "Et�s-vous s�r ?",

/**
 * Generic data words
 */

	'title' => "Titre",
	'description' => "Description",
	'tags' => "Tags",
	'spotlight' => "Projecteur sur",
	'all' => "Tous",

	'by' => "par",

	'annotations' => "Annotations",
	'relationships' => "Relations",
	'metadata' => "Metadonn�es",

/**
 * Input / output strings
 */

	'deleteconfirm' => "Etes-vous sur de voloir supprimer cet �l�ment ?",
	'fileexists' => "Un fichier a d�j� �t� charg�. Pour le remplacer s�lectionner le ci-dessous :",

/**
 * User add
 */

	'useradd:subject' => "Compte de l'utilisateur cr��",
	'useradd:body' => "
%s,

Un compte utilisateur vous a �t� cr�� a %s. Pour vous connecter, rendez-vous :

%s

Et connectez vous avec les identifiants suivant

	Nom d'utilisateur : %s
	Mot de passe : %s

Une fois que vous vous �tes connect�(e), nous vous conseillons fortement de changer votre mot de passe.
",

/**
 * System messages
 **/

	'systemmessages:dismiss' => "Cliquer pour fermer",


/**
 * Import / export
 */
	'importsuccess' => "L'import des donn�es a �t� r�alis�e avec succ�s",
	'importfail' => "L'import OpenDD des donn�es a �chou�e.",

/**
 * Time
 */

	'friendlytime:justnow' => "� l'instant",
	'friendlytime:minutes' => "il y a %s minutes",
	'friendlytime:minutes:singular' => "il y a une minute",
	'friendlytime:hours' => "il y a %s heures",
	'friendlytime:hours:singular' => "il y a une heure",
	'friendlytime:days' => "Il y a %s jours",
	'friendlytime:days:singular' => "hier",
	'friendlytime:date_format' => "j F Y @ g:ia",		/// NON TRADUIT, � voir...

	'date:month:01' => "Janvier %s",
	'date:month:02' => "F�vrier %s",
	'date:month:03' => "Mars %s",
	'date:month:04' => "Avril %s",
	'date:month:05' => "Mai %s",
	'date:month:06' => "Juin %s",
	'date:month:07' => "Juillet %s",
	'date:month:08' => "Ao�t %s",
	'date:month:09' => "Septembre %s",
	'date:month:10' => "Octobre %s",
	'date:month:11' => "Novembre %s",
	'date:month:12' => "D�cembre %s",


/**
 * Installation and system settings
 */

	'installation:error:htaccess' => "Elgg requiert un fichier .htaccess � la racine de n'installation. L'�criture automatique du fichier par l'installeur a �chou�.

La cr�ation de ce fichier est facile. Copiez-collez le texte ci-dessous dans un fichier texte que vous nommerez .htaccess

",
	'installation:error:settings' => "Elgg requiert un fichier de configuration. Pour continuer :

1. Renommez 'engine/settings.example.php' en 'settings.php' dans le r�pertoire d'installation de Elgg.

2. Editer le fichier avec le bloc-notes et entrez les informations relatives � votre base de donn�es MySQL. Si vous ne les connaissez pas contacter votre administrateur ou le support technique.

Comme alternative nous pouvons cr�er ce fichier pour vous, entrez les informations ci-dessous...",

	'installation:error:db:title' => "Erreur de configuration de base de donn�es",
	'installation:error:db:text' => "V�rifiez, une autre fois, la configuration de votre base de donn�es parce que Elgg ne peut pas se connecter et acc�der la base de donn�es.",
	'installation:error:configuration' => "Une fois les corrections de configuration apport�es, pressez 'R�essayer'.",

	'installation' => "Installation",
	'installation:success' => "La base de donn�es a �t� cr��e avec succ�s.",
	'installation:configuration:success' => "Votre configuration initiale a �t� sauvegard�e. D�sormais enregistrer un premier utilisateur; il sera administrateur du syst�me.",

	'installation:settings' => "Configuration du syst�me",
	'installation:settings:description' => "D�sormais la base de donn�es de Elgg est install�e, entrez quelques informations suppl�mentaires relatives � votre site. Certaines de ces informations sont automatiquement renseign�es, <b>veuillez v�rifier ces d�tails.</b>",

	'installation:settings:dbwizard:prompt' => "Entrez la configuration de votre base de donn�es ci-dessous :",
	'installation:settings:dbwizard:label:user' => "Utilisateur",
	'installation:settings:dbwizard:label:pass' => "Mot de passe",
	'installation:settings:dbwizard:label:dbname' => "Nom de la base",
	'installation:settings:dbwizard:label:host' => "Serveur h�te (le plus souvent 'localhost')",
	'installation:settings:dbwizard:label:prefix' => "Pr�fixe des tables de donn�es (le plus souvent 'elgg')",

	'installation:settings:dbwizard:savefail' => "La cr�ation du fichier 'settings.php' a �chou�. Copiez-collez le texte ci-dessous dans un fichier texte 'engine/settings.php'.",

	'installation:sitename' => "Nom du site (par exemple 'Ma communaut�') :",
	'installation:sitedescription' => "Br�ve description du site (optionnel)",
	'installation:wwwroot' => "Adresse du site internet suivi de '\' :",
	'installation:path' => "Chemin physique des fichiers sur le serveur suivi de '\' :",
	'installation:dataroot' => "Chemin complet o� h�berger les fichiers upload�s par les utilisateurs suivi de '\' :",
	'installation:dataroot:warning' => "Vous devez cr�er ce r�pertoire manuellement. Il doit se situer dans un r�pertoire diff�rent de votre installation de Elgg.",
	'installation:sitepermissions' => "Les permissions d'acc�s par d�faut :",
	'installation:language' => "La langue par d�faut de votre site :",
	'installation:debug' => "Le mode de d�bogage permet de mettre en �vidence certaines erreurs de fonctionnement, cependant il ralenti l'acc�s au site, il est � utiliser uniquement en cas de probl�me :",
	'installation:debug:none' => "D�sactive le mode debug (recommand�)",
	'installation:debug:error' => "Afficher seulement les erreurs critiques",
	'installation:debug:warning' => "Afficher les erreurs et les avertissements",
	'installation:debug:notice' => "Log toutes les erreurs, les avertissements et les avis",
	'installation:httpslogin' => "Activer ceci afin que les utilisateurs puissent se connecter via le protocole https. Vous devez avoir https activ� sur votre serveur afin que cela fonctionne.",
	'installation:httpslogin:label' => "Activer la connexion HTTPS",
	'installation:view' => "Entrer le nom de la vue qui sera utilis�e automatiquement pour l'affichage du site (par exemple : 'mobile'), laissez d�fault en cas de doute :",

	'installation:siteemail' => "L'adresse email du site (Elle sera utilis�e lors d'envoi d'email par le syst�me)",

	'installation:disableapi' => "L'API RESTful API est une interface qui permet � des applications d'utiliser certaines caract�ristiques de Elgg � distance.",
	'installation:disableapi:label' => "Activer l'API RESTful",

	'installation:allow_user_default_access:description' => "Si cliqu�, les utilisateurs pourront modifier leur niveau d'acc�s par d�faut et pourront surpasser le niveau d'acc�s mis en place par d�faut dans le syst�me.",
	'installation:allow_user_default_access:label' => "Autoriser un niveau d'acc�s par d�faut pour l'utilisateur",

	'installation:simplecache:description' => "Le cache simple augmente les performances en mettant en cache du contenu statique comme des CSS et des fichiers Javascripts. Normalement vous ne devriez pas avoir besoin de l'activer.",
	'installation:simplecache:label' => "Utiliser un cache simple",

	'installation:viewpathcache:description' => "Le cache utilis� pour stocker les chemins vers les vues des greffons r�duit le temps de chargement de ces derniers.",
	'installation:viewpathcache:label' => "Utiliser le cache de stockage des chemins vers les vues des greffons (recommand�).",

	'upgrading' => "Mise � jour en cours",
	'upgrade:db' => "Votre base de donn�es a �t� mise � jour.",
	'upgrade:core' => "Votre installation de Elgg a �t� mise � jour",

/**
 * Welcome
 */

	'welcome' => "Bienvenue",
	'welcome:user' => "Bienvenue %s",
	'welcome_message' => "Bienvenue sur ce Elgg.",

/**
 * Emails
 */
	'email:settings' => "Param�tres de mail",
	'email:address:label' => "Votre adresse email",

	'email:save:success' => "Votre nouvelle adresse email a �t� enregistr�e, vous allez recevoir un email de confirmation.",
	'email:save:fail' => "Votre nouvelle adresse email n'a pas pu �tre enregistr�e.",

	'friend:newfriend:subject' => "%s vous a ajout� comme contact !",
	'friend:newfriend:body' => "%s vous a ajout� comme contact!

Pour voir son profil cliquer sur le lien ci-dessous

%s

Vous ne pouvez pas r�pondre � cet email.",


	'email:resetpassword:subject' => "R�initialisation du mot de passe !",
	'email:resetpassword:body' => "Bonjour %s,

Votre nouveau mot de passe est : %s",


	'email:resetreq:subject' => "Demander un nouveau mot de passe.",
	'email:resetreq:body' => "Bonjour %s,

Quelqu'un (avec l'adresse IP %s) a demand� un nouveau mot de passe pour son compte.

Si vous avez demand� ce changement veuillez cliquer sur le lien ci-dessous, sinon ignorez cet email.

%s
",

/**
 * user default access
 */

'default_access:settings' => "Votre niveau d'acc�s par d�faut",
'default_access:label' => "Acc�s par d�faut",
'user:default_access:success' => "Votre nouveau niveau d'acc�s par d�faut a �t� enregistr�.",
'user:default_access:failure' => "Votre nouveau niveau d'acc�s par d�faut n'a pu �tre enregistr�.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata' =>	"Donn�es d'entr�es manquantes",

/**
 * Comments
 */

	'comments:count' => "%s commentaire(s)",

	'riveraction:annotation:generic_comment' => "%s a �crit un commentaire sur %s",

	'generic_comments:add' => "Ajouter un commentaire",
	'generic_comments:text' => "Commentaire",
	'generic_comment:posted' => "Votre commentaire a �t� publi� avec succ�s.",
	'generic_comment:deleted' => "Votre commentaire a �t� supprim� avec succ�s.",
	'generic_comment:blank' => "D�sol�; vous devez remplir votre commentaire avant de pouvoir l'enregistrer.",
	'generic_comment:notfound' => "D�sol�; l'�l�ment recherch� n'a pas �t� trouv�.",
	'generic_comment:notdeleted' => "D�sol�; le commentaire n'a pu �tre supprim�.",
	'generic_comment:failure' => "Une erreur est survenue lors de l'ajout de votre commentaire.",

	'generic_comment:email:subject' => "Vous avez un nouveau commentaire !",
	'generic_comment:email:body' => "Vous avez un nouveau commentaire sur l'�l�ment '%s' de %s. Voici son contenu :


%s


Pour r�pondre ou voir le contenu de r�f�rence, suivez le lien :

	%s

Pour voir le profil de %s, suivez ce lien :

	%s

Ne r�pondez pas � ce mail.",

/**
 * Entities
 */
	'entity:default:strapline' => "Cr�� le %s par %s",
	'entity:default:missingsupport:popup' => "Cette entit� ne peut pas �tre affich�e correctement. C'est peut-�tre du � un plugin qui a �t� supprim�.",

	'entity:delete:success' => "L'entit� %s a �t� effac�e",
	'entity:delete:fail' => "L'entit� %s n'a pas pu �tre effac�e",


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => "Il manque les champs __token ou __ts dans le formulaire.",
	'actiongatekeeper:tokeninvalid' => "Une erreur est survenue. Cela veut probablement dire que la page que vous utilisiez a expir�e. Merci de r�essayer",
	'actiongatekeeper:timeerror' => "La page a expir�, rafraichissez et recommencez � nouveau.",
	'actiongatekeeper:pluginprevents' => "Une extension a emp�ch� ce formulaire d'�tre envoy�",

/**
 * Word blacklists
 */
	//'word:blacklist' => "mais, o�, et, donc, or, ni, car, le, la, les, puis, il, elle, ils, elles, son, sa, ses, mon, ma, mes, lui, un, pas, aussi, sur, maintenant, hence, cependant, encore, �galement, autrement, donc, inversement, plut�t, consequently, furthermore, n�anmoins, instead, Entre-temps, accordingly, cet, semble, quoi, qui, dont, quiconque, whomever",
	'word:blacklist' => "et, le, puis, mais, elle, son, sa, lui, un, pas, aussi, sur, maintenant, hence, cependant, encore, �galement, autrement, donc, inversement, plut�t, consequently, furthermore, n�anmoins, instead, Entre-temps, accordingly, cet, semble, quoi, qui, dont, quiconque, whomever",
	//'word:blacklist' => "and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever",

/**
 * Tag labels
 */

	'tag_names:tags' => "Tags",

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("fr",$french);

?>