<?php

	$french = array(

		'categories' => 'Cat�gories',
		'categories:settings' => 'D�finir les cat�gories du site',
		'categories:explanation' => 'Pour d�finir quelques cat�gories pr�-d�termin�es qui seront utilis�es � travers l\'ensemble du site, veuillez les saisir ci-dessous, en les s�parant par des virgules. Les outils compatibles pourront alors les afficher quand les utilisateurs cr�ent ou �ditent des contenus.',
		'categories:save:success' => 'Les cat�gories du site ont �t� correctement enregistr�es.',
		'categories:results' => "R�sultats pour la cat�gorie du site: %s",

	);

	add_translation("fr",$french);

?>