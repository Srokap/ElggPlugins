<?php
	/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(

		'media:insert' => 'Embarquer / t�l�charger un m�dia',

		'embed:instructions' => "Cliquez sur le fichier de votre choix pour l'embarquer dans votre contenu.",

		'embed:media' => 'Fichier embarqu�',
		'upload:media' => 'T�l�charger un fichier',

		'embed:file:required' => "Aucun service de t�l�chargement de fichier n'a �t� trouv�. L'administrateur du site pourrait avoir besoin d'installer le plugin de gestion des fichiers.",

	);

	add_translation("fr",$french);

?>