<?php
	/**
	* Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(

		/**
		 * Menu items and titles
		 */

			'expages' => "Pages externes",
			'expages:frontpage' => "Page de garde",
			'expages:about' => "A propos",
			'expages:terms' => "Mentions l�gales",
			'expages:privacy' => "Informations personnelles",
			'expages:analytics' => "Statistiques",
			'expages:contact' => "Contact",
			'expages:nopreview' => "Aucun aper�u disponible pour le moment",
			'expages:preview' => "Aper�u",
			'expages:notset' => "Cette page n'a pas �t� d�finie pour le moment.",
			'expages:lefthand' => "Le panneau d'information lat�ral gauche",
			'expages:righthand' => "Le panneau d'information lat�ral droit",
			'expages:addcontent' => "Vous pouvez ajouter du contenu ici via vos outils d'administration. Regardez les pages externes sous la partie admin.",
			'item:object:front' => 'El�ments de la page de garde',

		/**
		 * Status messages
		 */

			'expages:posted' => "Votre message de page a bien �t� post�.",
			'expages:deleted' => "Votre message de page a bien �t� supprim�.",

		/**
		 * Error messages
		 */

			'expages:deleteerror' => "Un probl�me est survenu lors de la suppression de l'ancienne page",
			'expages:error' => "Une erreur est survenue, merci de r�essayer, ou de contacter l'administrateur si le probl�me persite",

	);

	add_translation("fr",$french);
?>