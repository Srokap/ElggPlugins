<?php
	/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

$french = array(
	'email:validate:subject' => "%s, veuillez confirmer votre adresse de courriel !",
	'email:validate:body' => "Bonjour %s,

Pour commencer � utiliser %s, vous devez confirmer votre adresse email.

Veuillez confirmer votre adresse email en cliquant sur le lien suivant :

%s

Si vous ne pouvez pas cliquer sur le lien, faites un copier/coller dans votre navigateur manuellement.

%s
%s
",

	'email:validate:success:subject' => "Adresse email valid�e %s !",
	'email:validate:success:body' => "Bonjour %s,

F�licitations, vous avez valid� votre adresse email.",


	'email:confirm:success' => "Vous avez valid� votre adresse email !",
	'email:confirm:fail' => "Votre adresse email n'a pu �tre v�rifi�e...",

	'uservalidationbyemail:registerok' => "Pour activer votre compte, veuillez confirmer votre adresse email en cliquant sur le lien qui vient de vous �tre envoy� (si vous ne recevez rien, veuillez v�rifier votre dossier Spam).",

	'uservalidationbyemail:admin:no_unvalidated_users' => 'Aucun utilisateur d�sactiv�.',

	'uservalidationbyemail:admin:unvalidated' => 'Utilisateurs d�sactiv�s',
	'uservalidationbyemail:admin:user_created' => '%s enregistr�',
	'uservalidationbyemail:admin:resend_validation' => 'Renvoyer validation',
	'uservalidationbyemail:admin:validate' => 'Valider',
	'uservalidationbyemail:admin:delete' => 'Supprimer',
	'uservalidationbyemail:confirm_validate_user' => 'Valider %s ?',
	'uservalidationbyemail:confirm_resend_validation' => 'Renvoyer le mail de validation � %s ?',
	'uservalidationbyemail:confirm_delete' => 'Supprimer %s ?',
	'uservalidationbyemail:confirm_validate_checked' => 'Valider les utilisateurs s�lectionn�s ?',
	'uservalidationbyemail:confirm_resend_validation_checked' => 'Renvoyer le mail de validation aux utilisateurs s�lectionn�s ?',
	'uservalidationbyemail:confirm_delete_checked' => 'Supprimer utilisateurs s�lectionn�s ?',
	'uservalidationbyemail:check_all' => 'Tous',

	'uservalidationbyemail:errors:unknown_users' => 'Utilisateurs inconnus',
	'uservalidationbyemail:errors:could_not_validate_user' => 'Impossible de valider l\'utilisateur.',
	'uservalidationbyemail:errors:could_not_validate_users' => 'Impossible de valider les utilisateurs s�lectionn�s.',
	'uservalidationbyemail:errors:could_not_delete_user' => 'Impossible de supprimer l\'utilisateur.',
	'uservalidationbyemail:errors:could_not_delete_users' => 'Impossible de supprimer les utilisateurs s�lectionn�s.',
	'uservalidationbyemail:errors:could_not_resend_validation' => 'Impossible de renvoyer le mail de validation.',
	'uservalidationbyemail:errors:could_not_resend_validations' => 'Impossible de renvoyer le mail de validation aux utilisateurs s�lectionn�s.',

	'uservalidationbyemail:messages:validated_user' => 'Utilisateur activ�.',
	'uservalidationbyemail:messages:validated_users' => 'Utilisateurs s�lectionn�s activ�s.',
	'uservalidationbyemail:messages:deleted_user' => 'Utilisateur supprim�.',
	'uservalidationbyemail:messages:deleted_users' => 'Utilisateurs s�lectionn�s activ�s.',
	'uservalidationbyemail:messages:resent_validation' => 'Mail de validation renvoy�.',
	'uservalidationbyemail:messages:resent_validations' => 'Mail de validation renvoy� aux utilisateurs s�lectionn�s.'

);

add_translation("fr",$french);
?>