<?php
/**
 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
        * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
 */
$french = array(

	/**
	 * Menu items and titles
	 */

	'messageboard:board' => "Forum",
	'messageboard:messageboard' => "forum",
	'messageboard:viewall' => "Voir tout",
	'messageboard:postit' => "Envoyer",
	'messageboard:history:title' => "historique",
	'messageboard:none' => "Il n'y a encore rien dans le forum",
	'messageboard:num_display' => "Nombre de messages � afficher",
	'messageboard:desc' => "Ceci est un forum que vous pouvez ajouter sur votre profil, et o� les autres utilisateurs peuvent laisse un message.",

	'messageboard:user' => "Forum de %s",

	'messageboard:replyon' => 'R�ponse sur',
	'messageboard:history' => "Historique",

	/**
	* Message board widget river
	**/

	'messageboard:river:annotate' => "%s a re�u un nouveau commentaire sur son forum.",
	'messageboard:river:create' => "%s a ajout� le widget Forum.",
	'messageboard:river:update' => "%s ont mis � jour leur widget Forum.",
	'messageboard:river:added' => "%s a �crit sur",
	'messageboard:river:messageboard' => "forum",


	/**
	 * Status messages
	 */

	'messageboard:posted' => "Votre message a bien �t� envoy� sur le forum.",
	'messageboard:deleted' => "Votre message a bien �t� supprim�.",

	/**
	 * Email messages
	 */

	'messageboard:email:subject' => 'Vous avez un nouveau message sur le forum !',
	'messageboard:email:body' => "Vous avez re�u un nouveau message de %s sur votre forum. Il est �crit :


%s


Pour voir vos messages de forum, cliquez sur :

	%s

Pour voir le profil de %s, cliquez sur :

	%s

Vous ne pouvez pas r�pondre � cet email.",

	/**
	 * Error messages
	 */

	'messageboard:blank' => "D�sol�, vous devez �crire quelque chose dans le corps du message avant de pouvoir l'enregistrer.",
	'messageboard:notfound' => "D�sol�, l'�l�ment sp�cifi� n'a pu �tre trouv�.",
	'messageboard:notdeleted' => "D�sol�, le message n'a pu �tre supprim�.",
	'messageboard:somethingwentwrong' => "Quelque chose a tourn� court lors de l'enregistrement de votre message, veuillez v�rifier que vous avez bien �crit un message.",

	'messageboard:failure' => "Une erreur impr�vue s'est produite lors de l'ajout de votre message. Veuillez r�eessayer.",

);

add_translation("fr",$french);
?>