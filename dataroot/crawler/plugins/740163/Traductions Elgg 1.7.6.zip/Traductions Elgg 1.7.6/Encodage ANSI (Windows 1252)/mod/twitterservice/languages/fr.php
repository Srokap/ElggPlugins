<?php
/**
 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
        * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
 */

$french = array(
	'twitterservice' => 'Service Twitter',

	'twitterservice:consumer_key' => 'Cl� Client',
	'twitterservice:consumer_secret' => 'Question Secr�te Client',

	'twitterservice:usersettings:description' => "Lier votre comtpe {$CONFIG->site->name} avec Twitter.",
	'twitterservice:usersettings:request' => "Vous devez d'abord <a href=\"%s\">autoriser</a> {$CONFIG->site->name} � acc�der � votre compte Twitter.",
	'twitterservice:authorize:error' => "Impossible d'autoriser Twitter.",
	'twitterservice:authorize:success' => 'Twitter a �t� autoris�.',

	'twitterservice:usersettings:authorized' => "Vous avez autoris� {$CONFIG->site->name} � acc�der � votre compte Twitter : @%s. Si les Tweets n'apparaissent pas, vous pourriez avoir � r�-autoriser. Cliquez ci-dessous pour r�voquer, puis allez sur <a href=\"http://twitter.com/settings/connections\">Configurations de Connection Twitter</a> et r�voquez l'acc�s pour %s.  Puis revenez sur cette page et autorisez un nouvelle fois.",
	'twitterservice:usersettings:revoke' => 'Cliquez <a href="%s">here</a> pour r�voquer l\'acc�ss.',
	'twitterservice:revoke:success' => 'L\'acc�s Twitter a �t� r�voqu�.',

	'twitterservice:usersettings:allowed_plugins' => 'Plugins Autoris�s',
);

add_translation("fr",$french);

?>