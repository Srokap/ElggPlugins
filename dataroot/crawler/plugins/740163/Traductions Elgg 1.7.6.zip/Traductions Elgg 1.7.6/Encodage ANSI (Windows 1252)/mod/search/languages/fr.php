<?php

$english = array(
	'search:enter_term' => 'Entrez votre recherche :',
	'search:no_results' => 'Aucun r�sultats.',
	'search:matched' => 'Matched: ',
	'search:results' => 'Resultats pour %s',
	'search:no_query' => 'Merci d\'entrer votre recherche.',
	'search:search_error' => 'Erreur',

	'search:more' => '+%s plus %s',

	'search_types:tags' => 'Tags',

	'search_types:comments' => 'Commentaires',
	'search:comment_on' => 'Commenter "%s"',
	'search:comment_by' => 'par',
	'search:unavailable_entity' => 'Indisponible',
);

add_translation('fr', $french);

?>