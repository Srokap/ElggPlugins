<?php
	/**
	* Traduction Fran�aise pour la 1.7 Christophe Goddon chgoddon@gmail.com
	*/
	$french = array(

		/**
		 * Menu items and titles
		 */

		'tinymce:remove' => "Ajouter/Enlever l'�diteur",

	);

	add_translation("fr",$french);

?>