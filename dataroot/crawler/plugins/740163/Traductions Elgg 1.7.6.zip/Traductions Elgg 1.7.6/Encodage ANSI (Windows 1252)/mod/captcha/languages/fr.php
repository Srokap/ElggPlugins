<?php
	/**
	 * Traduction Fran�aise pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		'captcha:entercaptcha' => "Entrer le texte de l'image",
		'captcha:captchafail' => "D�sol�, le texte que vous avez entr� ne correspond pas au texte de l'image.",

	);

	add_translation("fr",$french);
?>