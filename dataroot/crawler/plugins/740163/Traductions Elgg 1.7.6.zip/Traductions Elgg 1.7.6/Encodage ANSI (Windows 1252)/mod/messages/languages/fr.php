<?php
	/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(

		/**
		 * Menu items and titles
		 */

			'messages' => "Messages",
			'messages:back' => "Retour aux messages",
			'messages:user' => "Votre bo�te de r�ception",
			'messages:sentMessages' => "Messages envoy�s",
			'messages:posttitle' => "Messages de %s : %s",
			'messages:inbox' => "Bo�te de r�ception",
			'messages:send' => "Envoyer une message",
			'messages:sent' => "Messages envoy�s",
			'messages:message' => "Message",
			'messages:title' => "Titre",
			'messages:to' => "Pour",
			'messages:from' => "De",
			'messages:fly' => "Envoyer",
			'messages:replying' => "Message en r�ponse �",
			'messages:inbox' => "Bo�te de r�ception",
			'messages:sendmessage' => "Envoyer un message",
			'messages:compose' => "Ecrire un message",
			'messages:sentmessages' => "Messages envoy�s",
			'messages:recent' => "Messages re�us",
            'messages:original' => "Message d'origine",
            'messages:yours' => "Votre message",
            'messages:answer' => "R�pondre",
			'messages:toggle' => 'Tout basculer',
			'messages:markread' => 'Marquer comme lu',

			'messages:new' => 'Nouveau message',

			'notification:method:site' => 'Site',

			'messages:error' => "Un probl�me est survenu lors de l'enregistrement de votre message. Veuillez r�essayer.",

			'item:object:messages' => 'Messages',

		/**
		 * Status messages
		 */

			'messages:posted' => "Votre message a bien �t� envoy�.",
			'messages:deleted' => "Votre message a bien �t� effac�.",
			'messages:markedread' => "Vos messages ont bien �t� marqu�s comme lus.",

		/**
		 * Email messages
		 */

			'messages:email:subject' => 'Vous avez re�u un nouveau message !',
			'messages:email:body' => "Vous avez un nouveau message de %s. Il est �crit :


%s


Pour voir vos messages, cliquez sur :

	%s

Pour envoyer un message, cliquez sur :

	%s

Vous ne pouvez pas r�pondre � cet email.",

		/**
		 * Error messages
		 */

			'messages:blank' => "D�sol�, vous devez �crire quelque chose dans votre message avant de pouvoir l'enregistrer.",
			'messages:notfound' => "D�sol�, le message sp�cifi� n'a pu �tre trouv�.",
			'messages:notdeleted' => "D�sol�, ce message n'a pu �tre effac�.",
			'messages:nopermission' => "Vous n'avez pas l'autorisation de modifier ce message.",
			'messages:nomessages' => "Il n'y a aucun message � afficher.",
			'messages:user:nonexist' => "Le destinataire n'a pu �tre trouv� dans la base de donn�es des utilisateurs.",
			'messages:user:blank' => "Vous n'avez s�lectionn� personne � qui envoyer ce message.",

	);

	add_translation("fr",$french);

?>