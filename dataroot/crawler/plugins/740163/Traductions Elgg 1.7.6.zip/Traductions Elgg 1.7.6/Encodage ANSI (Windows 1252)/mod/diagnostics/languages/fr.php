<?php
	/**
	* Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

			'diagnostics' => 'Diagnostics du syst�me',
			'diagnostics:unittester' => 'Tests d\'unit�s',

			'diagnostics:description' => "Le rapport de diagnostic suivant est utile pour diagnostiquer tout probl�me avec Elgg, et devrait �tre inclus dans tout rapport d'erreur que vous rapportez.",
			'diagnostics:unittester:description' => 'Les tests de diagnostic suivants sont enregistr�s par les plugins afin de les am�liorer, ainsi que la structure de Elgg.',

			'diagnostics:unittester:description' => 'Les tests d\'unit�s contr�lent le Core de Elgg en cas d\'APIs cass�s ou d�fectueux.',
			'diagnostics:unittester:debug' => 'Le site doit �tre en mode debug pour lancer les tests d\'unit�s.',
			'diagnostics:unittester:warning' => 'ATTENTION: ces tests peuvent endommager votre base de donn�es. NE PAS UTILISER SUR UN SITE EN PRODUCTION!',

			'diagnostics:test:executetest' => 'Ex�cuter le test',
			'diagnostics:test:executeall' => 'Tout ex�cuter',
			'diagnostics:unittester:notests' => 'D�sol�, il n\'y a pas de module d\'unit� de test install� actuellement.',
			'diagnostics:unittester:testnotfound' => 'D�sol�, le rapport ne peut �tre g�n�r�, le test correspondant n\'a pas �t� trouv�',

			'diagnostics:unittester:testresult:nottestclass' => 'ECHEC - le r�sultat n\'est pas une classe de test',
			'diagnostics:unittester:testresult:fail' => 'ECHEC',
			'diagnostics:unittester:testresult:success' => 'SUCCES',

			'diagnostics:unittest:example' => 'Exemple de test d\'unit�, seulement disponible en mode debug.',

			'diagnostics:unittester:report' => 'Rapport de test pour %s',

			'diagnostics:download' => 'T�l�charger .txt',


			'diagnostics:header' => '========================================================================
Elgg Diagnostic Report
G�n�r� %s par %s
========================================================================

',
			'diagnostics:report:basic' => '
Elgg Release %s, version %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Plugins install�s et d�tails:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Fichiers install�s et checksums:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Variables globales:

%s
------------------------------------------------------------------------',

	);

	add_translation("fr",$french);
?>