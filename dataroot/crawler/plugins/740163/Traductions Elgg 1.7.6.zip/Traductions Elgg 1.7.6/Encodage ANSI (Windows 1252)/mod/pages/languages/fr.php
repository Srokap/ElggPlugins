<?php
	/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'pages' => "Pages",
			'pages:yours' => "Vos pages",
			'pages:user' => "Accueil des pages",
			'pages:group' => "Pages du groupe",
			'pages:all' => "Toutes les pages du site",
			'pages:new' => "Nouvelle page",
			'pages:groupprofile' => "Pages du groupe",
			'pages:edit' => "Editer cette page",
			'pages:delete' => "Effacer cette page",
			'pages:history' => "Historique de la page",
			'pages:view' => "Voir la page",
			'pages:welcome' => "Editer votre message d'accueil",
			'pages:welcomemessage' => "Bienvenue sur l'outil pages de %s. Cet outil vous permet de cr�er des pages sur tous les sujets et de s�lectionner qui peut les voir et les �diter.",
			'pages:welcomeerror' => "Un probl�me est survenu lors de l'enregistrement de votre message d'accueil",
			'pages:welcomeposted' => "Votre message d'accueil a bien �t� post�",
			'pages:navigation' => "Navigation de la page",
	        'pages:via' => "via les pages",
			'item:object:page_top' => 'Page de plus haut niveau',
			'item:object:page' => 'Pages',
			'item:object:pages_welcome' => "Blocs des pages d'accueil",
			'pages:nogroup' => 'Ce groupe ne comporte encore aucune page',
			'pages:more' => 'Plus de pages',

		/**
		* River
		**/

		    'pages:river:annotate' => "un commentaire sur cette page",
		    'pages:river:created' => "%s a �crit",
	        'pages:river:updated' => "%s mis � jour",
	        'pages:river:posted' => "%s post�",
			'pages:river:create' => "une nouvelle page intitul�e",
	        'pages:river:update' => "une page intitul�e",
	        'page:river:annotate' => "un commentaire sur cette page",
	        'page_top:river:annotate' => "un commentaire sur cette page",

		/**
		 * Form fields
		 */

			'pages:title' => 'Titre des pages',
			'pages:description' => 'Votre entr�e pour la page',
			'pages:tags' => 'Tags',
			'pages:access_id' => 'Acc�s',
			'pages:write_access_id' => 'Acc�s en �criture',

		/**
		 * Status and error messages
		 */
			'pages:noaccess' => "Pas d'acc�s � cette page",
			'pages:cantedit' => 'Vous ne pouvez pas �diter cette page',
			'pages:saved' => 'Pages enregistr�es',
			'pages:notsaved' => "La page n'a pu �tre enregistr�e",
			'pages:notitle' => 'Vous devez sp�cifier un titre pour cette page.',
			'pages:delete:success' => 'Votre page a bien �t� effac�e.',
			'pages:delete:failure' => "Votre page n'a pu �tre effac�e.",

		/**
		 * Page
		 */
			'pages:strapline' => 'Derni�re mise � jour le %s par %s',

		/**
		 * History
		 */
			'pages:revision' => 'R�vision cr��e le %s par %s',

		/**
		 * Widget
		 **/

		    'pages:num' => 'Nombre de pages � afficher',
			'pages:widget:description' => "Voici la liste des vos pages.",

		/**
		 * Submenu items
		 */
			'pages:label:view' => "Voir la page",
			'pages:label:edit' => "Editer la page",
			'pages:label:history' => "Historique de la page",

		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Cette page",
			'pages:sidebar:children' => "Sous-pages",
			'pages:sidebar:parent' => "Parent",

			'pages:newchild' => "Cr�er une sous-page",
			'pages:backtoparent' => "Retour � '%s'",
	);

	add_translation("fr",$french);
?>