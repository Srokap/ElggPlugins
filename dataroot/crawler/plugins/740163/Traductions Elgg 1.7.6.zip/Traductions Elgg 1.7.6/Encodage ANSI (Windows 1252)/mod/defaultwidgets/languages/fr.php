<?php
	/**
	  * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
$french = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Param�tre des widgets par d�faut',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Widgets par d�faut du profil',
    'defaultwidgets:menu:dashboard' => 'Widgets par d�faut du tableau de bord',

    'defaultwidgets:admin:error' => "Erreur: Vous n'�tes pas identifi� comme administrateur",
	'defaultwidgets:admin:notfound' => 'Erreur: Page non trouv�e',
	'defaultwidgets:admin:loginfailure' => "Attention: Vous n'�tes pas identifi� comme administrateur",

	'defaultwidgets:update:success' => 'Vos param�tres des widgets ont bien �t� enregistr�s',
	'defaultwidgets:update:failed' => "Erreur: les param�tres n'ont pu �tre enregistr�s",
	'defaultwidgets:update:noparams' => 'Erreur: param�tres du formulaire incorrects',

	'defaultwidgets:profile:title' => 'D�finir les widgets par d�faut pour les profils des nouveaux utilisateurs',
	'defaultwidgets:dashboard:title' => 'D�finir les widgets par d�faut pour les tableaux de bord des nouveaux utilisateurs',
);

add_translation ( "fr", $french );
?>