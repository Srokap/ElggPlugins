<?php
	/**
	* Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(

		/**
		 * Menu items and titles
		 */

			'thewire' => "Le Fil",
			'thewire:user' => "Le Fil de %s",
			'thewire:posttitle' => "Notes de %s sur le fil: %s",
			'thewire:everyone' => "Tous les messages du fil",
			'thewire:friends:title' => "Amis de %s sur le fil",
			'thewire:friends' => "Messages d'amis sur le fil",

			'thewire:yours' => "Vos message sur le fil",
			'thewire:theirs' => "Messages de %s sur le fil",

			'thewire:strapline' => "%s",

			'thewire:add' => "Poster vers le fil",
			'thewire:text' => "Une note sur le fil",
			'thewire:reply' => "R�pondre",
			'thewire:via_method' => "via",
			'thewire:wired' => "Post� sur le fil",
			'thewire:charleft' => "caract�res restant",
			'item:object:thewire' => "Messages du Fil",
			'thewire:notedeleted' => "note effac�e",
			'thewire:doing' => "Que faites-vous ? Dites-le � tout le monde sur le Fil :",
			'thewire:newpost' => 'Nouveau message sur le Fil',
			'thewire:addpost' => 'Poster sur le fil',
			'thewire:by' => "Message du fil par %s",
			'thewire:update' => 'Mise � jour',


        /**
	     * The wire river
	     **/

	        //generic terms to use
	        'thewire:river:created' => "%s a �crit",

	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "sur le fil.",

	    /**
	     * Wire widget
	     **/

	        'thewire:sitedesc' => 'Ce widget affiche les messages les plus r�cents du site post�s sur le fil',
	        'thewire:yourdesc' => 'Ce widget affiche vos messages les plus r�cents post�s sur le fil',
	        'thewire:friendsdesc' => 'Ce widget affiche les messages les plus r�cents de vos contacts sur le fil',
	        'thewire:num' => "Nombre d'�l�ments � afficher",
	        'thewire:moreposts' => 'Plus de messages du fil',


		/**
		 * Status messages
		 */

			'thewire:posted' => "Votre message a bien �t� post� sur le fil.",
			'thewire:deleted' => "Votre note a bien �t� supprim�e.",

		/**
		 * Error messages
		 */

			'thewire:blank' => "D�sol�, vous devez d'abord �crire un message avant de l'enregistrer.",
			'thewire:notfound' => "D�sol�, la note sp�cifi�e n'a pu �tre trouv�e.",
			'thewire:notdeleted' => "D�sol�, ce message n'a pu �tre effac�.",


		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Votre num�ro SMS s'il est diff�rent de celui de votre t�l�phone portable (le num�ro de t�l�phone doit �tre 'Public' pour que le Fil puisse l'utiliser). Tous les num�ros de t�l�phone doivent �tre �crits au format international.",
			'thewire:channelsms' => "Le num�ro auquel envoyer des SMS est le <b>%s</b>",

		// twitter
			'thewire:twitterservice:desc' => 'Tweets all posts made to The Wire.',

	);

	add_translation("fr",$french);

?>