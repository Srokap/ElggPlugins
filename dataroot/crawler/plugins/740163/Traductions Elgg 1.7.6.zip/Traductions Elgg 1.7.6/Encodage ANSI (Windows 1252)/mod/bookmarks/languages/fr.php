<?php
	/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'bookmarks' => "Signets",
			'bookmarks:add' => "Mettre quelque chose en signet",
			'bookmarks:read' => "El�ments enregistr�s comme signets",
			'bookmarks:friends' => "Signets des contacts",
			'bookmarks:everyone' => "Tous les signets du site",
			'bookmarks:this' => "Mettre en signet",
			'bookmarks:this:group' => "Mettre en signet dans %s",
			'bookmarks:bookmarklet' => "R�cup�rer le 'bookmarklet'",
			'bookmarks:bookmarklet:group' => "R�cup�rer le 'bookmarklet' du groupe",
			'bookmarks:inbox' => "Bo�te de r�ception des signets",
			'bookmarks:morebookmarks' => "Plus de signets",
			'bookmarks:more' => "Plus",
			'bookmarks:shareditem' => "El�ment mis en signet",
			'bookmarks:with' => "Partager avec",
			'bookmarks:new' => "Un nouvel �l�ment mis en signet",
			'bookmarks:via' => "via les signets",
			'bookmarks:address' => "Adresse de la ressource � ajouter � vos signets",

			'bookmarks:delete:confirm' => "Etes-vous s�r(e) de vouloir supprimer cette ressource ?",

			'bookmarks:numbertodisplay' => 'Nombre de signets � afficher',

			'bookmarks:shared' => "Mis en signet",
			'bookmarks:visit' => "Voir la ressource",
			'bookmarks:recent' => "Signets r�cents",

			'bookmarks:river:created' => '%s a mis en signet',
			'bookmarks:river:annotate' => 'a post� un commentaire sur cet �l�ment mis en signet',
			'bookmarks:river:item' => 'un �l�ment',

			'item:object:bookmarks' => 'El�ments mis en signets',

			'bookmarks:group' => 'Signets du groupe',
			'groups:enablebookmarks' => 'Autoriser les signets pour un groupe',
			'bookmarks:nogroup' => "Ce groupe n'a pas encore de signets",
			'bookmarks:more' => 'Plus de signets',


		/**
		 * More text
		 */

		    'bookmarks:widget:description' =>
		            "Ce widget est con�u pour votre tableau de bord, et vous pr�sentera les �l�ments les plus r�cents de votre bo�te de r�ception des signets.",

			'bookmarks:bookmarklet:description' =>
					"Le 'bookmarklet' des signets vous permet de partager toute ressource que vous trouvez sur le web avec vos contacts, ou � la conserver pour vous-m�me. Pour l'utiliser, faites glisser cet icone dans la barre de liens de votre navigateur:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Si vous utilisez Internet Explorer, faites un clic droit sur l'icone du bookmarklet, s�lectionnez 'ajouter aux favoris', puis choisissez la barre de liens.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Vous pouvez enregistrer toute page que vous visitez en cliquant dessus � tout moment.",

			'bookmarks:no_title' => 'Aucun titre',

		/**
		 * Status messages
		 */

			'bookmarks:save:success' => "Votre �l�ment a bien �t� mis en signet.",
			'bookmarks:delete:success' => "Votre signet a bien �t� supprim�.",

		/**
		 * Error messages
		 */

			'bookmarks:save:failed' => "Votre �l�ment n'a pu �tre correctement mis en signet. Merci de r�essayer.",
			'bookmarks:delete:failed' => "Votre signet n'a pu �tre supprim�. Merci de r�essayer.",


	);

	add_translation("fr",$french);

?>