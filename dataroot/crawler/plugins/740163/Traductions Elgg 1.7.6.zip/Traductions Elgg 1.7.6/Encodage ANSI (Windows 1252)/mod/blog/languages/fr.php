<?php

	/**
	 * Traduction Fran�aise 1.5 Florian Daniel http://id.facyla.net/
	 * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'blog' => "Blog",
			'blogs' => "Blogs",
			'blog:user' => "Le blog de %s",
			'blog:user:friends' => "Le blog des contacts de %s",
			'blog:your' => "Votre blog",
			'blog:posttitle' => "Le blog de %s: %s",
			'blog:friends' => "Blogs des contacts",
			'blog:yourfriends' => "Les blogs les plus r�cents de vos contacts",
			'blog:everyone' => "Tous les blogs du site",
			'blog:newpost' => "Nouvel article de blog",
			'blog:via' => "via le blog",
			'blog:read' => "Lire le blog",

			'blog:addpost' => "Ecrire un article de blog",
			'blog:editpost' => "Editer un article de blog",

			'blog:text' => "Texte du blog",

			'blog:strapline' => "%s",

			'item:object:blog' => 'Articles du blog',

			'blog:never' => 'jamais',
			'blog:preview' => 'Aper�u',

			'blog:draft:save' => 'Enregistrer le brouillon',
			'blog:draft:saved' => 'Dernier brouillon enregistr�',
			'blog:comments:allow' => 'Autoriser les commentaires',
			'blog:conversation' => 'Conversation',

			'blog:preview:description' => 'Ceci est un aper�u non enregistr� de votre article de blog.',
			'blog:preview:description:link' => "Cliquez ici pour continuer l'�dition ou enregistrer votre article.",

			'groups:enableblog' => 'Autoriser les blogs de groupe',
			'blog:group' => 'Blog de groupe',
			'blog:nogroup' => "Ce groupe n'a pas encore de messages de blog",
			'blog:more' => 'Plus de messages de blog',

			'blog:read_more' => "Lire le message complet",

		/**
		 * Blog widget
		 */
		'blog:widget:description' => 'Ce widget affiche votre dernier article de blog.',
		'blog:moreblogs' => 'Plus d\'articles du blog',
		'blog:numbertodisplay' => 'Nombre d\'articles du blog � afficher',

         /**
	     * Blog river
	     **/

	        //generic terms to use
	        'blog:river:created' => "a �crit %s",
	        'blog:river:updated' => "a mis � jour %s",
	        'blog:river:posted' => "a ajout� %s",

	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "un nouvel article intitul�",
	        'blog:river:update' => "un article intitul�",
	        'blog:river:annotate' => "un commentaire sur cet article de blog",


		/**
		 * Status messages
		 */

			'blog:posted' => "Votre article de blog a bien �t� ajout�.",
			'blog:deleted' => "Votre article de blog a bien �t� supprim�.",

		/**
		 * Error messages
		 */

			'blog:error' => "Une erreur s'est produite. Veuillez r�essayer.",
			'blog:save:failure' => "Votre article n'a pas pu �tre enregistr�, merci de r�essayer.",
			'blog:blank' => "D�sol�, vous devez compl�ter le titre et le corps de l'article avant de pouvoir publier.",
			'blog:notfound' => "D�sol�, l'article de blog sp�cifi� n'a pu �tre trouv�.",
			'blog:notdeleted' => "D�sol�, cet article de blog n'a pu �tre supprim�.",

	);

	add_translation("fr",$french);

?>