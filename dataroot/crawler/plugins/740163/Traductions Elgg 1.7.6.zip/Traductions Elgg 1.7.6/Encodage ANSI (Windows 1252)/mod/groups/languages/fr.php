<?php
	/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'groups' => "Groupes",
			'groups:owned' => "Les groupes que vous possedez",
			'groups:yours' => "Vos groupes",
			'groups:user' => "Les groupes de %s",
			'groups:all' => "Tous les groupes du site",
			'groups:new' => "Cr�er un nouveau groupe",
			'groups:edit' => "Modifier le groupe",
			'groups:delete' => 'Supprimer le groupe',
			'groups:membershiprequests' => 'G�rer les membres souhaitant se joindre au groupe',
			'groups:invitations' => 'Invitations du groupe',

			'groups:icon' => "Icone du groupe (ne rien inscrire pour laisser inchang�)",
			'groups:name' => 'Nom du groupe',
			'groups:username' => "Nom court du goupe (Qui s'affichera dans l'URL : en caract�res alphanum�riques)",
			'groups:description' => 'Description',
			'groups:briefdescription' => 'Br�ve description',
			'groups:interests' => 'Int�r�ts',
			'groups:website' => 'Site web',
			'groups:members' => 'Membres du groupe',
			'groups:membership' => "Permissions d'acc�s au groupe",
			'groups:access' => "Permissions d'acc�s",
			'groups:owner' => "Propri�taire",
	        'groups:widget:num_display' => 'Nombre de groupes � afficher',
	        'groups:widget:membership' => 'Adh�sion au groupe',
	        'groups:widgets:description' => 'Afficher les groupes dont vous �tes membre dans votre profil',
			'groups:noaccess' => "Vous n'avez pas acc�s au groupe",
			'groups:cantedit' => 'Vous ne pouvez pas modifier ce groupe',
			'groups:saved' => 'Groupe enregistr�',
			'groups:featured' => 'Les groupes � la une',
			'groups:makeunfeatured' => 'Enlever de la une',
			'groups:makefeatured' => 'Mettre en une',
			'groups:featuredon' => 'Vous avez mis ce groupe � la une.',
			'groups:unfeature' => "Ce groupe n'est plus � la une",
			'groups:joinrequest' => 'Demander une adh�sion au groupe',
			'groups:join' => 'Rejoindre le groupe',
			'groups:leave' => 'Quitter le groupe',
			'groups:invite' => 'Inviter des contacts',
			'groups:inviteto' => "Inviter des contacts au groupe '%s'",
			'groups:nofriends' => "Vous n'avez plus de contacts � inviter � ce groupe.",
			'groups:viagroups' => "Via les groupes",
			'groups:group' => "Groupe",
			'groups:search:tags' => "Tag",

			'groups:memberlist' => "Membres du groupe",
			'groups:membersof' => "Membres de %s",
			'groups:members:more' => "Afficher plus de membres",

			'groups:notfound' => "Le groupe n'a pas �t� trouv�",
			'groups:notfound:details' => "Le groupe que vous recherchez n'existe pas, ou alors vous n'avez pas la permission d'y acc�der",

			'groups:requests:none' => "Il n'y a pas de membre demandant de rejoindre le groupe en ce moment.",

			'groups:invitations:none' => 'Il n\'y a pas d\'invitations en attente.',

			'item:object:groupforumtopic' => "Sujets de discussion",

			'groupforumtopic:new' => "Une nouvelle discussion a �t� publi�e",

			'groups:count' => "groupe cr��",
			'groups:open' => "groupe ouvert",
			'groups:closed' => "groupe ferm�",
			'groups:member' => "membres",
			'groups:searchtag' => "Rechercher des groupes par des mots-cl�",


			/*
			 * Access
			 */
			'groups:access:private' => 'Ferm� - Les utilisateurs doivent �tre invit�s',
			'groups:access:public' => "Ouvert - N'importe quel utilisateur peut rejoindre le groupe",
			'groups:closedgroup' => 'Ce groupe est en adh�sion priv�e.',
			'groups:closedgroup:request' => 'Pour le rejoindre cliquez sur le lien "Demander une adh�sion au groupe".',
			'groups:visibility' => 'Qui peut voir ce groupe?',

			/*
			Group tools
			*/
			'groups:enablepages' => 'Activer le module "page" du groupe',
			'groups:enableforum' => 'Activer le module "discussion" du groupe',
			'groups:enablefiles' => 'Activer le module "fichier" du groupe',
			'groups:yes' => 'oui',
			'groups:no' => 'non',

			'group:created' => 'Cr�� %s avec %d publications',
			'groups:lastupdated' => 'Derni�re mise � jour %s par %s',
			'groups:lastcomment' => 'Dernier commentaire %s par %s',
			'groups:pages' => 'Les pages du groupe',
			'groups:files' => 'Les fichiers du groupe',

			/*
			Group forum strings
			*/

			'group:replies' => 'R�ponses',
			'groups:forum' => 'Forum du groupe',
			'groups:addtopic' => 'Ajouter un sujet',
			'groups:forumlatest' => 'Derni�re discussion',
			'groups:latestdiscussion' => 'Derni�re discussion',
			'groups:newest' => 'R�cents',
			'groups:popular' => 'Populaires',
			'groupspost:success' => 'Votre commentaire a �t� publi� avec succ�s',
			'groups:alldiscussion' => 'Derni�re discussion',
			'groups:edittopic' => 'Modifier le sujet',
			'groups:topicmessage' => 'Message du sujet',
			'groups:topicstatus' => 'Statut du sujet',
			'groups:reply' => 'Publier un commentaire',
			'groups:topic' => 'Sujets',
			'groups:posts' => 'Posts',
			'groups:lastperson' => 'Derni�re personne',
			'groups:when' => 'Quand',
			'grouptopic:notcreated' => "Aucun sujet n'a �t� cr��.",
			'groups:topicopen' => 'Ouvert',
			'groups:topicclosed' => 'Ferm�',
			'groups:topicresolved' => 'R�solu',
			'grouptopic:created' => 'Votre sujet a �t� cr��.',
			'groupstopic:deleted' => 'Le sujet a �t� supprim�.',
			'groups:topicsticky' => 'Sticky',
			'groups:topicisclosed' => 'Ce sujet est ferm�.',
			'groups:topiccloseddesc' => "Ce sujet a �t� ferm� et n'accepte plus de nouveaux commentaires.",
			'grouptopic:error' => "Votre sujet n'a pas pu �tre cr��. Merci d'essayer plus tard ou de contacter un administrateur du syst�me.",
			'groups:forumpost:edited' => "Vous avez modifi� ce billet avec succ�s.",
			'groups:forumpost:error' => "Il y a eu un probl�me lors de la modification du billet.",
			'groups:privategroup' => 'Ce groupe est priv�. Il est n�cessaire de demander une adh�sion.',
			'groups:notitle' => 'Les groupes doivent avoir un titre',
			'groups:cantjoin' => "N'a pas pu rejoindre le groupe",
			'groups:cantleave' => "N'a pas pu quitter le groupe",
			'groups:addedtogroup' => "A ajout� avec succ�s l'utilisateur au groupe",
			'groups:joinrequestnotmade' => "La demande d'adh�sion n'a pas pu �tre r�alis�e",
			'groups:joinrequestmade' => "La demande d'adh�sion s'est d�roul�e avec succ�s",
			'groups:joined' => 'Vous avez rejoint le groupe avec succ�s !',
			'groups:left' => 'Vous avez quitter le groupe avec succ�s',
			'groups:notowner' => "D�sol�, vous n'�tes pas le propri�taire du groupe.",
			'groups:notmember' => 'D�sol�, vous n\'�tes pas membre de ce groupe.',
			'groups:alreadymember' => "Vous �tes d�j� membre de ce groupe !",
			'groups:userinvited' => "L'utilisateur a �t� invit�.",
			'groups:usernotinvited' => "L'utilisateur n'a pas pu �tre invit�",
			'groups:useralreadyinvited' => "L\'utilisateur a d�j� �t� invit�",
			'groups:updated' => "Dernier commentaire",
			'groups:invite:subject' => "%s vous avez �t� invit�(e) � rejoindre %s!",
			'groups:started' => "D�marr� par",
			'groups:joinrequest:remove:check' => "Etes-vous s�r de vouloir supprimer cette demande d'adh�sion ?",
			'groups:invite:remove:check' => 'Etes-vous s�r de vouloir supprimer cette invitation?',
			'groups:invite:body' => "Bonjour %s,

Vous avez �t� invit�(e) � rejoindre le groupe '%s' cliquez sur le lien ci-dessous pour confirmer:

%s",

			'groups:welcome:subject' => "Bienvenue dans le groupe %s !",
			'groups:welcome:body' => "Bonjour %s!

Vous �tes maintenant membre du groupe '%s' ! Cliquez le lien ci-dessous pour commencer � participer !

%s",

			'groups:request:subject' => "%s a demand� une adh�sion � %s",
			'groups:request:body' => "Bonjour %s,

%s a demand� � rejoindre le groupe '%s', cliquez le lien ci-dessous pour voir son profil :

%s

ou cliquez le lien ci-dessous pour confirmer son adh�sion :

%s",

            /*
				Forum river items
			*/

			'groups:river:member' => '%s est maintenant membre de',
			'groups:river:create' => '%s a cr�� le groupe',
			'groupforum:river:updated' => '%s a mis � jour',
			'groupforum:river:update' => 'ce sujet de discussion',
			'groupforum:river:created' => '%s a cr��',
			'groupforum:river:create' => 'un nouveau sujet de discussion intitul�',
			'groupforum:river:posted' => '%s a publi� un nouveau commentaire',
			'groupforum:river:annotate:create' => 'sur ce sujet de discussion',
			'groupforum:river:postedtopic' => '%s a d�marr� un nouveau sujet de discussion intitul�',
			'groups:river:togroup' => 'pour le groupe',

			'groups:nowidgets' => "Aucun widget n'ont �t� d�fini pour ce groupe.",


			'groups:widgets:members:title' => 'Membres du groupe',
			'groups:widgets:members:description' => "Lister les membres d'un groupe.",
			'groups:widgets:members:label:displaynum' => "Lister les membres d'un groupe.",
			'groups:widgets:members:label:pleaseedit' => 'Merci de configurer ce widget.',

			'groups:widgets:entities:title' => "Objets dans le groupe",
			'groups:widgets:entities:description' => "Lister les objets enregistr� dans ce groupe",
			'groups:widgets:entities:label:displaynum' => "Lister les objets d'un groupe.",
			'groups:widgets:entities:label:pleaseedit' => 'Merci de configurer ce widget.',

			'groups:forumtopic:edited' => 'Sujet du forum modifi� avec succ�s.',

			'groups:allowhiddengroups' => 'Voulez-vous permettre les groupes priv�s (invisibles)?',

			/**
			 * Action messages
			 */
			'group:deleted' => 'Contenus du groupe et groupe supprim�s',
			'group:notdeleted' => "Le groupe n'a pas pu �tre supprim�",

			'grouppost:deleted' => "La publication dans le groupe a �t� effac�e",
			'grouppost:notdeleted' => "La publication dans le groupe n'a pas pu �tre effac�e",
			'groupstopic:deleted' => 'Sujet supprim�',
			'groupstopic:notdeleted' => "Le sujet n'a pas pu �tre supprim�",
			'grouptopic:blank' => 'Pas de sujet',
			'grouptopic:notfound' => 'Le sujet n\'a pu �tre trouv�',
			'grouppost:nopost' => 'Pas d\'articles',
			'groups:deletewarning' => "Etes-vous sur de vouloir supprimer ce groupe ? Cette action est irr�versible !",

			'groups:invitekilled' => "L'invitation a �t� supprim�e.",
			'groups:joinrequestkilled' => "La demande d'adh�sion a �t� supprim�e.",
	);

	add_translation("fr",$french);
?>