<?php
	/**
	* Traduction Fran�aise pour la 1.5 Dumitru Popescu http://www.enseignement-augmente.fr/
	* Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	*/

	$french = array(

	/**
	 * Profile
	 */

		'profile' => "Profil",
		'profile:edit:default' => 'Remplacez les champs de profil',
		'profile:preview' => 'Pr�visualiser',

	/**
	 * Profile menu items and titles
	 */

		'profile:yours' => "Votre profil",
		'profile:user' => "Profil de %s ",

		'profile:edit' => "Modifiez le profil",
		'profile:profilepictureinstructions' => "La photo de profil est l'image qui s'affiche sur votre page de profil. <br /> Vous pouvez la changer aussi souvent que vous le souhaitez. (Les formats de fichiers accept�s : GIF, JPG ou PNG)",
		'profile:icon' => "Photo de profil",
		'profile:createicon' => "Cr�ez votre avatar",
		'profile:currentavatar' => "L'avatar actuel",
		'profile:createicon:header' => "Photo de profil",
		'profile:profilepicturecroppingtool' => "Outil pour recadrer la photo de profil",
		'profile:createicon:instructions' => "Cliquez et faites glisser un carr� ci-dessous pour correspondre � la fa�on dont vous voulez que votre image soit coup�e. Un aper�u de votre image coup�e appara�tra dans la case de droite. Lorsque vous �tes satisfait de l'aper�u, cliquez sur 'Cr�er votre avatar'. Cette image rogn�e sera utilis�e sur le site comme votre avatar.",

		'profile:editdetails' => "Modifiez les d�tails",
		'profile:editicon' => "Modifiez l'ic�ne de profil",

		'profile:aboutme' => "A propos de moi",
		'profile:description' => "A propos de moi",
		'profile:briefdescription' => "Courte description",
		'profile:location' => "Localisation",
		'profile:skills' => "Comp�tences",
		'profile:interests' => "Int�r�ts",
		'profile:contactemail' => "Email de contact",
		'profile:phone' => "T�l�phone",
		'profile:mobile' => "Portable",
		'profile:website' => "Site web",

		'profile:banned' => 'Ce compte a �t� suspendu.',
		'profile:deleteduser' => 'Utilisateur supprim�',

		'profile:river:update' => "%s � mis � jour son profil",
		'profile:river:iconupdate' => "%s � mis � jour son ic�ne du profil",

		'profile:label' => "Etiquette de profil",
		'profile:type' => "Type de profil",

		'profile:editdefault:fail' => 'Le profil par d�faut n\'a pas pu �tre sauv�',
		'profile:editdefault:success' => '�l�ment ajout� avec succ�s au profil par d�faut.',


		'profile:editdefault:delete:fail' => 'Suppression de l\'�l�ment du champ de profil par d�faut �chou�e.',
		'profile:editdefault:delete:success' => '�l�ment par d�faut du profil supprim�!',

		'profile:defaultprofile:reset' => 'R�initialisation du profil par d�faut du syst�me',

		'profile:resetdefault' => 'R�initialisez le profil par d�faut',
		'profile:explainchangefields' => 'Vous pouvez remplacer les champs de profil existant avec vos champs personnalis�s en utilisant le formulaire ci-dessous. D\'abord vous donnez une �tiquette au nouveau champ de profil, par exemple \'Equipe pr�f�r�e\'. Ensuite, vous devez s�lectionner le type de champ, par exemple, tags, url, texte et ainsi de suite. A tout moment vous pouvez revenir au profil par d�faut mis en place.',


	/**
		* Profile status messages
		*/

		'profile:saved' => "Votre profil a �t� correctement enregistr�.",
		'profile:icon:uploaded' => "Votre photo de profil a �t� t�l�charg�e avec succ�s.",

	/**
		* Profile error messages
		*/

		'profile:noaccess' => "Vous n'avez pas la permission de modifier ce profil.",
		'profile:notfound' => "D�sol�, nous n'avons pas pu trouver le profil sp�cifi�.",
		'profile:icon:notfound' => "D�sol�, il y a un probl�me pour la mise � jour de votre photo de profil.",
		'profile:icon:noaccess' => 'Vous ne pouvez pas changer cette ic�ne de profil',
		'profile:field_too_long' => 'Impossible d\'enregistrer vos informations de profil parce que l\'article de "%s" est trop long.',

	);

	add_translation("fr",$french);

?>