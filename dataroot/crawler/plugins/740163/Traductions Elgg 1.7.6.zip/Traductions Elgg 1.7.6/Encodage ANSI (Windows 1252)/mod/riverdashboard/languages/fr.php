<?php
/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
$french = array(

	'mine' => 'Moi',
	'filter' => 'Filtre',
	'riverdashboard:useasdashboard' => "Remplacer le tableau de bord par d�faut avec ce flux d'activit� ?",
	'activity' => 'Activit�',
	'riverdashboard:recentmembers' => 'Membres r�cents',

    /**
     * Site messages
          **/

	'sitemessages:announcements' => "Annonces du site",
	'sitemessages:posted' => "Post�",
	'sitemessages:river:created' => "Administrateur du site, %s,",
	'sitemessages:river:create' => "a post� un nouveau message pour l'ensemble du site",
	'sitemessages:add' => "Ajouter un message pour l'ensemble du site sur le flux d'activit�",
	'sitemessage:deleted' => "Message du site effac�",
	'sitemessage:error' => "Impossible de sauvegarder ce message.",
	'sitemessages:blank' => "Impossible de poster un message vide.",

	'river:widget:noactivity' => "Aucune activit� trouv�e.",
	'river:widget:title' => "Activit�",
	'river:widget:description' => "Montrer vos activit�s les plus r�centes.",
	'river:widgets:friends' => "Contacts",
	'river:widgets:mine' => "Moi",
	'river:widget:label:displaynum' => "Nombre d'entr�es � afficher:",
	'river:widget:type' => "Quel flux d'activit� souhaitez-vous afficher ? Celui qui montre votre activit�, ou celui qui montre celle de vos contacts ?",
	'item:object:sitemessage' => "Messages du site",
	'riverdashboard:avataricon' => "Voulez-vous utiliser les ic�nes ou avatars de vos contacts dans le flux d'activit�s ?",
	'option:icon' => 'Ic�nes',
	'option:avatar' => 'Avatars',
);

	add_translation("fr",$french);

?>