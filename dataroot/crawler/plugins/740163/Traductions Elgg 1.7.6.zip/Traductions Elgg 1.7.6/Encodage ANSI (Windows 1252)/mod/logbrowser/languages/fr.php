<?php
	/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'logbrowser' => 'Visualiseur de journal',
			'logbrowser:browse' => 'Visualiser les journaux syst�me',
			'logbrowser:search' => 'Affiner les r�sultats',
			'logbrowser:user' => "Rechercher par nom d'utilisateur",
			'logbrowser:starttime' => 'Heure de d�but (par exemple "dernier lundi", "il y a une heure")',
			'logbrowser:endtime' => 'Heure de fin',

			'logbrowser:explore' => 'Explorer le journal',

	);

	add_translation("fr",$french);
?>