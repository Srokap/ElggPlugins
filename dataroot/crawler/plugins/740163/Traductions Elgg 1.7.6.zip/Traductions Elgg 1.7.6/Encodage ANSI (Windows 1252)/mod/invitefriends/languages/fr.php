<?php

/**
	 * Traduction Fran�aise pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

$french = array(

	'friends:invite' => 'Inviter des contacts',
	'invitefriends:introduction' => 'Pour inviter des contacts � vous rejoindre sur ce r�seau, entrez leurs adresses mail ci-dessous (une par ligne) :',
	'invitefriends:message' => "Ecrivez un message qu'ils vont recevoir avec votre invitation :",
	'invitefriends:subject' => 'Invitation � rejoindre %s',

	'invitefriends:success' => 'Vos contacts ont �t� invit�s.',
	'invitefriends:invitations_sent' => "Invitation envoy�e : %s. Il ya eu les probl�mes suivants :",
	'invitefriends:email_error' => "Les adresses suivantes sont invalides : %s",
	'invitefriends:already_members' => "Les personnes suivantes sont d�j� membres : %s",
	'invitefriends:noemails' => "Aucune adresse mail n'a �t� entr�e.",

	'invitefriends:message:default' => '
Bonjour,

Je souhaiterais vous inviter � rejoindre mon r�seau sur %s.',

	'invitefriends:email' => '
Vous avez �t� invit� � rejoindre %s par %s, qui a ajout� le message suivant :

%s

Pour vous inscrire, cliquez sur le lien suivant :

	%s

Ils seront automatiquement ajout�s � vos contacts quand vous aurez cr�� votre compte.',

	);

	add_translation("fr",$french);
?>