<?php
	/**
	* Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
        * patch pour ajouter traduction aux onglets
         * in mod/members/views/default/members/members_sort_menu.php

<div id="elgg_horizontal_tabbed_nav">
	<ul>
	<li <?php if($filter == "newest") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=newest"><?php echo elgg_echo('members:newest'); ?></a></li>
	<li <?php if($filter == "pop") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=pop"><?php echo elgg_echo('members:popular'); ?></a></li>
	<li <?php if($filter == "active") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=active"><?php echo elgg_echo('members:active'); ?></a></li>
	</ul>
</div>
	 */
	$french = array(

		'members:members' => "Membres du site",
		'members:online' => "Membres actifs en ce moment",
		'members:active' => "Membres du site",
		'members:searchtag' => "Recherche de membre par tag",
		'members:searchname' => "Recherche de membre par nom",

		'members:label:newest' => "Nouveaux",
		'members:label:popular' => "Populaires",
		'members:label:active' => "Actifs",
		'members:search:name' => 'Nom du membre',
		'members:search:tags' => 'Tags',

	);

	add_translation("fr",$french);

?>