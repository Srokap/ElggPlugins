<?php
	/**
	* Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "Pages externes",
			'expages:frontpage' => "Page de garde",
			'expages:about' => "A propos",
			'expages:terms' => "Mentions légales",
			'expages:privacy' => "Informations personnelles",
			'expages:analytics' => "Statistiques",
			'expages:contact' => "Contact",
			'expages:nopreview' => "Aucun aperçu disponible pour le moment",
			'expages:preview' => "Aperçu",
			'expages:notset' => "Cette page n'a pas été définie pour le moment.",
			'expages:lefthand' => "Le panneau d'information latéral gauche",
			'expages:righthand' => "Le panneau d'information latéral droit",
			'expages:addcontent' => "Vous pouvez ajouter du contenu ici via vos outils d'administration. Regardez les pages externes sous la partie admin.",
			'item:object:front' => 'Eléments de la page de garde',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Votre message de page a bien été posté.",
			'expages:deleted' => "Votre message de page a bien été supprimé.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "Un problème est survenu lors de la suppression de l'ancienne page",
			'expages:error' => "Une erreur est survenue, merci de réessayer, ou de contacter l'administrateur si le problème persite",
	
	);
					
	add_translation("fr",$french);
?>
