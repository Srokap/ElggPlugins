<?php
	/**
	 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

	$french = array(

		/**
		 * Menu items and titles
		 */

			'pages' => "Pages",
			'pages:yours' => "Vos pages",
			'pages:user' => "Accueil des pages",
			'pages:group' => "Pages du groupe",
			'pages:all' => "Toutes les pages du site",
			'pages:new' => "Nouvelle page",
			'pages:groupprofile' => "Pages du groupe",
			'pages:edit' => "Editer cette page",
			'pages:delete' => "Effacer cette page",
			'pages:history' => "Historique de la page",
			'pages:view' => "Voir la page",
			'pages:welcome' => "Editer votre message d'accueil",
			'pages:welcomemessage' => "Bienvenue sur l'outil pages de %s. Cet outil vous permet de créer des pages sur tous les sujets et de sélectionner qui peut les voir et les éditer.",
			'pages:welcomeerror' => "Un problème est survenu lors de l'enregistrement de votre message d'accueil",
			'pages:welcomeposted' => "Votre message d'accueil a bien été posté",
			'pages:navigation' => "Navigation de la page",
	        'pages:via' => "via les pages",
			'item:object:page_top' => 'Page de plus haut niveau',
			'item:object:page' => 'Pages',
			'item:object:pages_welcome' => "Blocs des pages d'accueil",
			'pages:nogroup' => 'Ce groupe ne comporte encore aucune page',
			'pages:more' => 'Plus de pages',

		/**
		* River
		**/

		    'pages:river:annotate' => "un commentaire sur cette page",
		    'pages:river:created' => "%s a écrit",
	        'pages:river:updated' => "%s mis à jour",
	        'pages:river:posted' => "%s posté",
			'pages:river:create' => "une nouvelle page intitulée",
	        'pages:river:update' => "une page intitulée",
	        'page:river:annotate' => "un commentaire sur cette page",
	        'page_top:river:annotate' => "un commentaire sur cette page",

		/**
		 * Form fields
		 */

			'pages:title' => 'Titre des pages',
			'pages:description' => 'Votre entrée pour la page',
			'pages:tags' => 'Tags',
			'pages:access_id' => 'Accès',
			'pages:write_access_id' => 'Accès en écriture',

		/**
		 * Status and error messages
		 */
			'pages:noaccess' => "Pas d'accès à cette page",
			'pages:cantedit' => 'Vous ne pouvez pas éditer cette page',
			'pages:saved' => 'Pages enregistrées',
			'pages:notsaved' => "La page n'a pu être enregistrée",
			'pages:notitle' => 'Vous devez spécifier un titre pour cette page.',
			'pages:delete:success' => 'Votre page a bien été effacée.',
			'pages:delete:failure' => "Votre page n'a pu être effacée.",

		/**
		 * Page
		 */
			'pages:strapline' => 'Dernière mise à jour le %s par %s',

		/**
		 * History
		 */
			'pages:revision' => 'Révision créée le %s par %s',

		/**
		 * Widget
		 **/

		    'pages:num' => 'Nombre de pages à afficher',
			'pages:widget:description' => "Voici la liste des vos pages.",

		/**
		 * Submenu items
		 */
			'pages:label:view' => "Voir la page",
			'pages:label:edit' => "Editer la page",
			'pages:label:history' => "Historique de la page",

		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Cette page",
			'pages:sidebar:children' => "Sous-pages",
			'pages:sidebar:parent' => "Parent",

			'pages:newchild' => "Créer une sous-page",
			'pages:backtoparent' => "Retour à '%s'",
	);

	add_translation("fr",$french);
?>