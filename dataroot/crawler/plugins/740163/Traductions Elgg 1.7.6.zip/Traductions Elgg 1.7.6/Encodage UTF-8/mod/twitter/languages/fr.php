<?php
	/**
	 * Elgg twitter plugin language pack
	 * 
	 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => "Votre nom d'utilisateur Twitter.",
		'twitter:num' => 'Nombre de tweets à afficher.',
		'twitter:visit' => 'visitez mon compte',
		'twitter:notset' => "Ce module Twitter n'est pas encore configuré. Pour afficher vos derniers tweets, cliquez sur - éditer - et complétez les informations demandées",
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s a ajouté le widget twitter.",
	        'twitter:river:updated' => "%s a mis à jour son widget twitter.",
	        'twitter:river:delete' => "%s a supprimé son widget twitter.",
	        
		
	);
					
	add_translation("fr",$french);

?>
