<?php
/**
 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
        * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
 */
$french = array(

	'friends:all' => 'Tous les contacts',

	'notifications:subscriptions:personal:description' => 'Recevoir des notifications quand des actions concernent vos contenus',
	'notifications:subscriptions:personal:title' => 'Notifications personnelles',

	'notifications:subscriptions:collections:title' => 'Activer les groupes de contacts',
	'notifications:subscriptions:collections:description' => 'Pour activer les groupes de contacts pour les utilisateurs du site, utilisez les icones ci-dessous. Cela va affecter les utilisateurs correspondants dans la fenêtre principale de notification en bas de page. ',
	'notifications:subscriptions:collections:edit' => 'Pour modifier vos groupes de contacts, cliquez ici.',

	'notifications:subscriptions:changesettings' => 'Notifications',
	'notifications:subscriptions:changesettings:groups' => 'Notifications pour les groupes',
	'notification:method:email' => 'Email',

	'notifications:subscriptions:title' => 'Notifications par utilisateur',
	'notifications:subscriptions:description' => 'Pour recevoir des notifications de vos contacts quand ils créent de nouveaux contenus, sélectionnez-les ci-dessous, et choisissez le mode de notifications que vous souhaitez utiliser.',

	'notifications:subscriptions:groups:description' => 'Pour recevoir des notifications lorsque de nouveaux contenus sont ajoutés à un groupe auquel vous appartenez, sélectionnez-les ci-dessous, et choisissez le mode de notifications que vous souhaitez utiliser.',

	'notifications:subscriptions:success' => 'Vos paramètres de notifications ont bien été enregistrés.',

);

add_translation("fr",$french);
?>