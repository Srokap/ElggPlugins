<?php
	/**
	* Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
	$french = array(
	
			'custom:bookmarks' => "Signets les plus récents",
			'custom:groups' => "Groupes les plus récents",
			'custom:files' => "Fichiers les plus récents",
			'custom:blogs' => "Articles de blog les plus récents",
			'custom:members' => "Nouveaux membres",
			'custom:nofiles' => "Il n'y a pas encore de fichier",
			'custom:nogroups' => "Il n'y a pas encore de groupe",	
	
	);
					
	add_translation("fr",$french);
?>
