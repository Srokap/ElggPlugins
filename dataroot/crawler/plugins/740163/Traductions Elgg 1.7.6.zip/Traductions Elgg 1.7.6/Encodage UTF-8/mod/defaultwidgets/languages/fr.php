<?php
	/**
	  * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */
$french = array (

	/**
	 * Nice name for the entity (shown in admin panel)
	 */
	'item:object:moddefaultwidgets' => 'Paramètre des widgets par défaut',

	/**
	 * Menu items
	 */
	'defaultwidgets:menu:profile' => 'Widgets par défaut du profil',
    'defaultwidgets:menu:dashboard' => 'Widgets par défaut du tableau de bord',

    'defaultwidgets:admin:error' => "Erreur: Vous n'êtes pas identifié comme administrateur",
	'defaultwidgets:admin:notfound' => 'Erreur: Page non trouvée',
	'defaultwidgets:admin:loginfailure' => "Attention: Vous n'êtes pas identifié comme administrateur",

	'defaultwidgets:update:success' => 'Vos paramètres des widgets ont bien été enregistrés',
	'defaultwidgets:update:failed' => "Erreur: les paramètres n'ont pu être enregistrés",
	'defaultwidgets:update:noparams' => 'Erreur: paramètres du formulaire incorrects',

	'defaultwidgets:profile:title' => 'Définir les widgets par défaut pour les profils des nouveaux utilisateurs',
	'defaultwidgets:dashboard:title' => 'Définir les widgets par défaut pour les tableaux de bord des nouveaux utilisateurs',
);

add_translation ( "fr", $french );
?>