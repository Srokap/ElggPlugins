<?php

/**
	 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
         * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	 */

$french = array(

	'friends:invite' => 'Inviter des contacts',
	'invitefriends:introduction' => 'Pour inviter des contacts à vous rejoindre sur ce réseau, entrez leurs adresses mail ci-dessous (une par ligne) :',
	'invitefriends:message' => "Ecrivez un message qu'ils vont recevoir avec votre invitation :",
	'invitefriends:subject' => 'Invitation à rejoindre %s',

	'invitefriends:success' => 'Vos contacts ont été invités.',
	'invitefriends:invitations_sent' => "Invitation envoyée : %s. Il ya eu les problèmes suivants :",
	'invitefriends:email_error' => "Les adresses suivantes sont invalides : %s",
	'invitefriends:already_members' => "Les personnes suivantes sont déjà membres : %s",
	'invitefriends:noemails' => "Aucune adresse mail n'a été entrée.",

	'invitefriends:message:default' => '
Bonjour,

Je souhaiterais vous inviter à rejoindre mon réseau sur %s.',

	'invitefriends:email' => '
Vous avez été invité à rejoindre %s par %s, qui a ajouté le message suivant :

%s

Pour vous inscrire, cliquez sur le lien suivant :

	%s

Ils seront automatiquement ajoutés à vos contacts quand vous aurez créé votre compte.',

	);

	add_translation("fr",$french);
?>