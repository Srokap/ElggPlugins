<?php
/**
 * Traduction Française pour la 1.5 Florian Daniel http://id.facyla.net/
        * Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
 */

$french = array(
	'twitterservice' => 'Service Twitter',

	'twitterservice:consumer_key' => 'Clé Client',
	'twitterservice:consumer_secret' => 'Question Secrète Client',

	'twitterservice:usersettings:description' => "Lier votre comtpe {$CONFIG->site->name} avec Twitter.",
	'twitterservice:usersettings:request' => "Vous devez d'abord <a href=\"%s\">autoriser</a> {$CONFIG->site->name} à accéder à votre compte Twitter.",
	'twitterservice:authorize:error' => "Impossible d'autoriser Twitter.",
	'twitterservice:authorize:success' => 'Twitter a été autorisé.',

	'twitterservice:usersettings:authorized' => "Vous avez autorisé {$CONFIG->site->name} à accéder à votre compte Twitter : @%s. Si les Tweets n'apparaissent pas, vous pourriez avoir à ré-autoriser. Cliquez ci-dessous pour révoquer, puis allez sur <a href=\"http://twitter.com/settings/connections\">Configurations de Connection Twitter</a> et révoquez l'accès pour %s.  Puis revenez sur cette page et autorisez un nouvelle fois.",
	'twitterservice:usersettings:revoke' => 'Cliquez <a href="%s">here</a> pour révoquer l\'accèss.',
	'twitterservice:revoke:success' => 'L\'accès Twitter a été révoqué.',

	'twitterservice:usersettings:allowed_plugins' => 'Plugins Autorisés',
);

add_translation("fr",$french);

?>