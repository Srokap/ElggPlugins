<?php
	/**
	* Traduction Française pour la 1.5 Dumitru Popescu http://www.enseignement-augmente.fr/
	* Ajout/modification pour la 1.7 Christophe Goddon chgoddon@gmail.com
	*/

	$french = array(

	/**
	 * Profile
	 */

		'profile' => "Profil",
		'profile:edit:default' => 'Remplacez les champs de profil',
		'profile:preview' => 'Prévisualiser',

	/**
	 * Profile menu items and titles
	 */

		'profile:yours' => "Votre profil",
		'profile:user' => "Profil de %s ",

		'profile:edit' => "Modifiez le profil",
		'profile:profilepictureinstructions' => "La photo de profil est l'image qui s'affiche sur votre page de profil. <br /> Vous pouvez la changer aussi souvent que vous le souhaitez. (Les formats de fichiers acceptés : GIF, JPG ou PNG)",
		'profile:icon' => "Photo de profil",
		'profile:createicon' => "Créez votre avatar",
		'profile:currentavatar' => "L'avatar actuel",
		'profile:createicon:header' => "Photo de profil",
		'profile:profilepicturecroppingtool' => "Outil pour recadrer la photo de profil",
		'profile:createicon:instructions' => "Cliquez et faites glisser un carré ci-dessous pour correspondre à la façon dont vous voulez que votre image soit coupée. Un aperçu de votre image coupée apparaîtra dans la case de droite. Lorsque vous êtes satisfait de l'aperçu, cliquez sur 'Créer votre avatar'. Cette image rognée sera utilisée sur le site comme votre avatar.",

		'profile:editdetails' => "Modifiez les détails",
		'profile:editicon' => "Modifiez l'icône de profil",

		'profile:aboutme' => "A propos de moi",
		'profile:description' => "A propos de moi",
		'profile:briefdescription' => "Courte description",
		'profile:location' => "Localisation",
		'profile:skills' => "Compétences",
		'profile:interests' => "Intérêts",
		'profile:contactemail' => "Email de contact",
		'profile:phone' => "Téléphone",
		'profile:mobile' => "Portable",
		'profile:website' => "Site web",

		'profile:banned' => 'Ce compte a été suspendu.',
		'profile:deleteduser' => 'Utilisateur supprimé',

		'profile:river:update' => "%s à mis à jour son profil",
		'profile:river:iconupdate' => "%s à mis à jour son icône du profil",

		'profile:label' => "Etiquette de profil",
		'profile:type' => "Type de profil",

		'profile:editdefault:fail' => 'Le profil par défaut n\'a pas pu être sauvé',
		'profile:editdefault:success' => 'Élément ajouté avec succès au profil par défaut.',


		'profile:editdefault:delete:fail' => 'Suppression de l\'élément du champ de profil par défaut échouée.',
		'profile:editdefault:delete:success' => 'Élément par défaut du profil supprimé!',

		'profile:defaultprofile:reset' => 'Réinitialisation du profil par défaut du système',

		'profile:resetdefault' => 'Réinitialisez le profil par défaut',
		'profile:explainchangefields' => 'Vous pouvez remplacer les champs de profil existant avec vos champs personnalisés en utilisant le formulaire ci-dessous. D\'abord vous donnez une étiquette au nouveau champ de profil, par exemple \'Equipe préférée\'. Ensuite, vous devez sélectionner le type de champ, par exemple, tags, url, texte et ainsi de suite. A tout moment vous pouvez revenir au profil par défaut mis en place.',


	/**
		* Profile status messages
		*/

		'profile:saved' => "Votre profil a été correctement enregistré.",
		'profile:icon:uploaded' => "Votre photo de profil a été téléchargée avec succès.",

	/**
		* Profile error messages
		*/

		'profile:noaccess' => "Vous n'avez pas la permission de modifier ce profil.",
		'profile:notfound' => "Désolé, nous n'avons pas pu trouver le profil spécifié.",
		'profile:icon:notfound' => "Désolé, il y a un problème pour la mise à jour de votre photo de profil.",
		'profile:icon:noaccess' => 'Vous ne pouvez pas changer cette icône de profil',
		'profile:field_too_long' => 'Impossible d\'enregistrer vos informations de profil parce que l\'article de "%s" est trop long.',

	);

	add_translation("fr",$french);

?>