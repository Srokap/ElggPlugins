<?php

	/**
	 * Elgg Webgalli_audio post page
	 * @package Webgalli Audio
	 * @license Commercial
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

		gatekeeper();
        action_gatekeeper();
		$guid = (int) get_input('webgalli_audiopost');
		$title = get_input('webgalli_audiotitle');
		$body = get_input('webgalli_audiobody');
		$audiourl = get_input('webgalli_audiourl');
		$access = get_input('access_id');
		$tags = get_input('webgalli_audiotags');
		$comments_on = get_input('comments_select','Off');
		$webgalli_audio = get_entity($guid);
		if ($webgalli_audio->getSubtype() == "webgalli_audio" && $webgalli_audio->canEdit()) {
			$_SESSION['user']->webgalli_audiotitle = $title;
			$_SESSION['user']->webgalli_audiobody = $body;
			$_SESSION['user']->webgalli_audiourl = $audiourl;
			$_SESSION['user']->webgalli_audiotags = $tags;
			$tagarray = string_to_tag_array($tags);
			if (empty($title) || empty($audiourl)) {
				register_error(elgg_echo("webgalli_audio:blank"));
				forward("mod/webgalli_audio/add.php");
			} else {
				$owner = get_entity($webgalli_audio->getOwner());
				$webgalli_audio->access_id = $access;
				$webgalli_audio->title = $title;
				$webgalli_audio->description = $body;
				$webgalli_audio->audiourl = $audiourl;
				if (!$webgalli_audio->save()) {
					register_error(elgg_echo("webgalli_audio:error"));
					forward("mod/webgalli_audio/edit.php?webgalli_audiopost=" . $guid);
				}
				$webgalli_audio->clearMetadata('tags');
				if (is_array($tagarray)) {
					$webgalli_audio->tags = $tagarray;
				}
				$webgalli_audio->comments_on = $comments_on;
				system_message(elgg_echo("webgalli_audio:posted"));
				add_to_river('river/object/webgalli_audio/update','update',$_SESSION['user']->guid,$webgalli_audio->guid);
				remove_metadata($_SESSION['user']->guid,'webgalli_audiotitle');
				remove_metadata($_SESSION['user']->guid,'webgalli_audiobody');
				remove_metadata($_SESSION['user']->guid,'webgalli_audiourl');
				remove_metadata($_SESSION['user']->guid,'webgalli_audiotags');
			$page_owner = get_entity($webgalli_audio->container_guid);
			if ($page_owner instanceof ElggUser)
				$username = $page_owner->username;
			else if ($page_owner instanceof ElggGroup)
				$username = "group:" . $page_owner->guid;
			forward("pg/webgalli_audio/$username");
			}
		}
?>
