<?php

	/**
	 * Elgg webgalli_audio plugin
	 * @package: Audio playlist Pluggin GPL Version
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

		gatekeeper();
		$guid = (int) get_input('webgalli_audiopost');
		$webgalli_audio = get_entity($guid);
		if ($webgalli_audio->getSubtype() == "webgalli_audio" && $webgalli_audio->canEdit()) {
				$owner = get_entity($webgalli_audio->getOwner());
				$rowsaffected = $webgalli_audio->delete();
				if ($rowsaffected > 0) {
					system_message(elgg_echo("webgalli_audio:deleted"));
				} else {
					register_error(elgg_echo("webgalli_audio:notdeleted"));
				}
				forward("mod/webgalli_audio/?username=" . $owner->username);
		}
?>