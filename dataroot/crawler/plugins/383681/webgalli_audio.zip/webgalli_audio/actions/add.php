<?php

	/**
	 * Elgg webgalli_audio plugin
	 * @package: Audio playlist Pluggin GPL Version
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */
		gatekeeper();
        action_gatekeeper();
		$title = get_input('webgalli_audiotitle');
		$body = get_input('webgalli_audiobody');
		$audiourl = get_input('webgalli_audiourl');
		$tags = get_input('webgalli_audiotags');
		$access = get_input('access_id');
		$comments_on = get_input('comments_select','Off');
		$_SESSION['user']->webgalli_audiotitle = $title;
		$_SESSION['user']->webgalli_audiobody = $body;
		$_SESSION['user']->webgalli_audiourl = $audiourl;
		$_SESSION['user']->webgalli_audiotags = $tags;
		$tagarray = string_to_tag_array($tags);
		if (empty($title) || empty($audiourl)) {
			register_error(elgg_echo("webgalli_audio:blank"));
			forward($_SERVER['HTTP_REFERER']);
		} else {
			$webgalli_audio = new ElggObject();
			$webgalli_audio->subtype = "webgalli_audio";
			$webgalli_audio->owner_guid = $_SESSION['user']->getGUID();
			$webgalli_audio->container_guid = (int)get_input('container_guid', $_SESSION['user']->getGUID());
			$webgalli_audio->access_id = $access;
			$webgalli_audio->title = $title;
			$webgalli_audio->description = $body;
			$webgalli_audio->audiourl = $audiourl;
			if (!$webgalli_audio->save()) {
				register_error(elgg_echo("webgalli_audio:error"));
				forward($_SERVER['HTTP_REFERER']);
			}
			if (is_array($tagarray)) {
				$webgalli_audio->tags = $tagarray;
			}
			$webgalli_audio->comments_on = $comments_on; 
			system_message(elgg_echo("webgalli_audio:posted"));
	        add_to_river('river/object/webgalli_audio/create','create',$_SESSION['user']->guid,$webgalli_audio->guid);
			remove_metadata($_SESSION['user']->guid,'webgalli_audiotitle');
			remove_metadata($_SESSION['user']->guid,'webgalli_audiobody');
			remove_metadata($_SESSION['user']->guid,'webgalli_audiourl');
			remove_metadata($_SESSION['user']->guid,'webgalli_audiotags');
			$page_owner = get_entity($webgalli_audio->container_guid);
			if ($page_owner instanceof ElggUser)
				$username = $page_owner->username;
			else if ($page_owner instanceof ElggGroup)
				$username = "group:" . $page_owner->guid;
			forward("pg/webgalli_audio/$username");
				
		}
		
?>
