<?php

	/**
	 * Elgg webgalli_audio plugin
	 * @package: Audio playlist Pluggin GPL Version
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

		if (isset($vars['entity'])) {
			
			//display comments link?
			if ($vars['entity']->comments_on == 'Off') {
				$comments_on = false;
			} else {
				$comments_on = true;
			}
			
			if (get_context() == "search" && $vars['entity'] instanceof ElggObject) {
				
				//display the correct layout depending on gallery or list view
				if (get_input('search_viewtype') == "gallery") {

					//display the gallery view
            				echo elgg_view("webgalli_audio/gallery",$vars);

				} else {
				
					echo elgg_view("webgalli_audio/listing",$vars);

				}

				
			} else {
			
				if ($vars['entity'] instanceof ElggObject) {
					
					$url = $vars['entity']->getURL();
					$owner = $vars['entity']->getOwnerEntity();
					$canedit = $vars['entity']->canEdit();
					
				} else {
					
					$url = 'javascript:history.go(-1);';
					$owner = $vars['user'];
					$canedit = false;
					
				}
?>

	<div class="contentWrapper singleview">
	
	<div class="webgalli_audio_post">
		<h3><a href="<?php echo $url; ?>"><?php echo $vars['entity']->title; ?></a></h3>
		<!-- display the user icon -->
		<div class="webgalli_audio_post_icon">
		    <?php
		        echo elgg_view("profile/icon",array('entity' => $owner, 'size' => 'tiny'));
			?>
	    </div>
			<p class="strapline">
				<?php
	                
					echo sprintf(elgg_echo("webgalli_audio:strapline"),
									date("F j, Y",$vars['entity']->time_created)
					);
				
				?>
				<?php echo elgg_echo('by'); ?> <a href="<?php echo $vars['url']; ?>pg/webgalli_audio/<?php echo $owner->username; ?>"><?php echo $owner->name; ?></a> &nbsp; 
				<!-- display the comments link -->
				<?php
					if($comments_on && $vars['entity'] instanceof ElggObject){
			        //get the number of comments
			    		$num_comments = elgg_count_comments($vars['entity']);
			    ?>
			    	<a href="<?php echo $url; ?>"><?php echo sprintf(elgg_echo("comments")) . " (" . $num_comments . ")"; ?></a><br />
			    <?php
		    		}
		    	?>
			</p>
			<!-- display tags -->
				<?php
	
					$tags = elgg_view('output/tags', array('tags' => $vars['entity']->tags));
					if (!empty($tags)) {
						echo '<p class="tags">' . $tags . '</p>';
					}
				
					$categories = elgg_view('categories/view', $vars);
					if (!empty($categories)) {
						echo '<p class="categories">' . $categories . '</p>';
					}
				
				?>
			<div class="clearfloat"></div>
<?php echo $vars['entity']->audiourl; ?>
			<div class="webgalli_audio_post_body">
			<!-- display the actual webgalli_audio post -->
				<?php
			
							echo elgg_view('output/longtext',array('value' => $vars['entity']->description));
				
				?>
			</div><div class="clearfloat"></div>			
			<!-- display edit options if it is the webgalli_audio post owner -->
			<p class="options">
			<?php
	
				if ($canedit) {
					
				?>
					<a href="<?php echo $vars['url']; ?>mod/webgalli_audio/edit.php?webgalli_audiopost=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("edit"); ?></a>  &nbsp; 
					<?php
					
						echo elgg_view("output/confirmlink", array(
																	'href' => $vars['url'] . "action/webgalli_audio/delete?webgalli_audiopost=" . $vars['entity']->getGUID(),
																	'text' => elgg_echo('delete'),
																	'confirm' => elgg_echo('deleteconfirm'),
																));
	
						// Allow the menu to be extended
						echo elgg_view("editmenu",array('entity' => $vars['entity']));
					
					?>
				<?php
				}
			
			?>
			</p>
		</div>
		</div>

<?php

			// If we've been asked to display the full view 
			// Now handled by annotation framework
				/*if (isset($vars['full']) && $vars['full'] == true && $comments_on == 'on' && $vars['entity'] instanceof ElggEntity) {
					echo elgg_view_comments($vars['entity']);
				}*/
				
			}

		}

?>