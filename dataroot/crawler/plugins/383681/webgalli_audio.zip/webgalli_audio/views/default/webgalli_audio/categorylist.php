<?php
	$list = elgg_view('categories/list',$vars);
	if (!empty($list)) {
?>

	<div class="webgalli_audio_categories">
		<?php echo $list; ?>
	</div>

<?php

	}

?>