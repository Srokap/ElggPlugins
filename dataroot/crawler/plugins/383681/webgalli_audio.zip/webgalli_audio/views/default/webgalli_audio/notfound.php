<?php

	/**
	 * Elgg webgalli_audio plugin
	 * @package: Audio playlist Pluggin GPL Version
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */
?>

	<p>
		<?php

			echo elgg_echo("webgalli_audio:notfound");
		
		?>
	</p>