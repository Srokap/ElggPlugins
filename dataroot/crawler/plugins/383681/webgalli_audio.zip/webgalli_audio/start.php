<?php

	/**
	 * Elgg webgalli_audio plugin
	 * @package: Audio playlist Pluggin GPL Version
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */


		function webgalli_audio_init() {
			
				global $CONFIG;
				
				if (isloggedin()) {
    				
					add_menu(elgg_echo('webgalli_audios'), $CONFIG->wwwroot . "pg/webgalli_audio/" . $_SESSION['user']->username);
					
				} else {
					add_menu(elgg_echo('webgalli_audio'), $CONFIG->wwwroot . "mod/webgalli_audio/everyone.php",array(
					));
				}
				
				extend_view('css','webgalli_audio/css');
				
				extend_view('profile/menu/links','webgalli_audio/menu');
				
				register_page_handler('webgalli_audio','webgalli_audio_page_handler');
				
				register_entity_url_handler('webgalli_audio_url','object','webgalli_audio');
				
				register_plugin_hook('pingback:object:subtypes', 'object', 'webgalli_audio_pingback_subtypes');

			if (is_callable('register_notification_object'))
				register_notification_object('object', 'webgalli_audio', elgg_echo('webgalli_audio:newpost'));

			register_plugin_hook('notify:entity:message', 'object', 'webgalli_audio_notify_message');

				
				register_elgg_event_handler('create', 'object', 'webgalli_audio_incoming_ping');
				
				register_entity_type('object','webgalli_audio');
				
				register_plugin_hook('entity:annotate', 'object', 'webgalli_audio_annotate_comments');
				
				add_group_tool_option('webgalli_audio',elgg_echo('webgalli_audio:enablewebgalli_audio'),true);
		}
		
		function webgalli_audio_pagesetup() {
			
			global $CONFIG;

				if (get_context() == "webgalli_audio") {
					$page_owner = page_owner_entity();
						
					if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
						add_submenu_item(elgg_echo('webgalli_audio:your'),$CONFIG->wwwroot."pg/webgalli_audio/" . $_SESSION['user']->username);
						add_submenu_item(elgg_echo('webgalli_audio:friends'),$CONFIG->wwwroot."pg/webgalli_audio/" . $_SESSION['user']->username . "/friends/");
						add_submenu_item(elgg_echo('webgalli_audio:everyone'),$CONFIG->wwwroot."mod/webgalli_audio/everyone.php");
						
					} else if (page_owner()) {
						add_submenu_item(sprintf(elgg_echo('webgalli_audio:user'),$page_owner->name),$CONFIG->wwwroot."pg/webgalli_audio/" . $page_owner->username);
						if ($page_owner instanceof ElggUser) { // Sorry groups, this isn't for you.
							add_submenu_item(sprintf(elgg_echo('webgalli_audio:user:friends'),$page_owner->name),$CONFIG->wwwroot."pg/webgalli_audio/" . $page_owner->username . "/friends/");
						}
						add_submenu_item(elgg_echo('webgalli_audio:everyone'),$CONFIG->wwwroot."mod/webgalli_audio/everyone.php");
					} else {
						add_submenu_item(elgg_echo('webgalli_audio:everyone'),$CONFIG->wwwroot."mod/webgalli_audio/everyone.php");
					}
					
					if (can_write_to_container(0, page_owner()))
						add_submenu_item(elgg_echo('webgalli_audio:addpost'),$CONFIG->wwwroot."pg/webgalli_audio/{$page_owner->username}/new/");
						
					if (!defined('everyonewebgalli_audio') && page_owner()) {
						
						if ($dates = get_entity_dates('object','webgalli_audio',page_owner())) {
							foreach($dates as $date) {
								$timestamplow = mktime(0,0,0,substr($date,4,2),1,substr($date,0,4));
								$timestamphigh = mktime(0,0,0,((int) substr($date,4,2)) + 1,1,substr($date,0,4));
								if (!isset($page_owner)) $page_owner = page_owner_entity();
							}								
						}
						
					}
					
				}
				
				$page_owner = page_owner_entity();
				
				if ($page_owner instanceof ElggGroup && get_context() == 'groups') {
	    			if($page_owner->webgalli_audio_enable != "no"){
					    add_submenu_item(sprintf(elgg_echo("webgalli_audio:group"),$page_owner->name), $CONFIG->wwwroot . "pg/webgalli_audio/" . $page_owner->username );
				    }
				}
		}
		
		function webgalli_audio_page_handler($page) {
			
			if (isset($page[0])) {
				set_input('username',$page[0]);
			}
			
			if (isset($page[2])) {
				set_input('param2',$page[2]);
			}
			if (isset($page[3])) {
				set_input('param3',$page[3]);
			}
			
			if (isset($page[1])) {
				switch($page[1]) {
					case "read":		set_input('webgalli_audiopost',$page[2]);
										include(dirname(__FILE__) . "/read.php"); return true;
										break;
					case "archive":		include(dirname(__FILE__) . "/archive.php"); return true;
										break;
					case "friends":		include(dirname(__FILE__) . "/friends.php"); return true;
										break;
					case "new":			include(dirname(__FILE__) . "/add.php"); return true;
										break;
					
				}
			} else {
				@include(dirname(__FILE__) . "/index.php");
				return true;
			}
			
			return false;
			
		}
		
		function webgalli_audio_annotate_comments($hook, $entity_type, $returnvalue, $params)
		{
			$entity = $params['entity'];
			$full = $params['full'];
			
			if (
				($entity instanceof ElggEntity) &&	// Is the right type 
				($entity->getSubtype() == 'webgalli_audio') &&  // Is the right subtype
				($entity->comments_on!='Off') && // Comments are enabled
				($full) // This is the full view
			)
			{
				// Display comments
				return elgg_view_comments($entity);
			}
			
		}

		function webgalli_audio_notify_message($hook, $entity_type, $returnvalue, $params)
		{
			$entity = $params['entity'];
			$to_entity = $params['to_entity'];
			$method = $params['method'];
			if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'webgalli_audio'))
			{
				$descr = $entity->description;
				$title = $entity->title;
				if ($method == 'sms') {
					$owner = $entity->getOwnerEntity();
					return $owner->username . ' via webgalli_audio: ' . $title;
				}
				if ($method == 'email') {
					$owner = $entity->getOwnerEntity();
					return $owner->username . ' via webgalli_audio: ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
				}
			}
			return null;
		}


		function webgalli_audio_url($webgalli_audiopost) {
			
			global $CONFIG;
			$title = $webgalli_audiopost->title;
			$title = friendly_title($title);
			return $CONFIG->url . "pg/webgalli_audio/" . $webgalli_audiopost->getOwnerEntity()->username . "/read/" . $webgalli_audiopost->getGUID() . "/" . $title;
			
		}
		
		function webgalli_audio_pingback_subtypes($hook, $entity_type, $returnvalue, $params)
		{
			$returnvalue[] = 'webgalli_audio';
			
			return $returnvalue;
		}
		
		function webgalli_audio_incoming_ping($event, $object_type, $object)
		{
		}
		
		register_elgg_event_handler('init','system','webgalli_audio_init');
		register_elgg_event_handler('pagesetup','system','webgalli_audio_pagesetup');
		
		global $CONFIG;
		register_action("webgalli_audio/add",false,$CONFIG->pluginspath . "webgalli_audio/actions/add.php");
		register_action("webgalli_audio/edit",false,$CONFIG->pluginspath . "webgalli_audio/actions/edit.php");
		register_action("webgalli_audio/delete",false,$CONFIG->pluginspath . "webgalli_audio/actions/delete.php");
		
?>