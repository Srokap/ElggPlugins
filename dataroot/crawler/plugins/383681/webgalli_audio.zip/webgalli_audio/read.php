<?php

	/**
	 * Elgg webgalli_audio plugin
	 * @package: Audio playlist Pluggin GPL Version
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// Get the specified webgalli_audio post
		$post = (int) get_input('webgalli_audiopost');

	// If we can get out the webgalli_audio post ...
		if ($webgalli_audiopost = get_entity($post)) {
			
	// Get any comments
			//$comments = $webgalli_audiopost->getAnnotations('comments');
		
	// Set the page owner
			set_page_owner($webgalli_audiopost->getOwner());
			$page_owner = get_entity($webgalli_audiopost->getOwner());
			
	// Display it
			$area2 = elgg_view_entity($webgalli_audiopost, true);
			/*$area2 = elgg_view("object/webgalli_audio",array(
											'entity' => $webgalli_audiopost,
											'entity_owner' => $page_owner,
											'comments' => $comments,
											'full' => true
											));
			*/								
	// Set the title appropriately
		$title = sprintf(elgg_echo("webgalli_audio:posttitle"),$page_owner->name,$webgalli_audiopost->title);

	// Display through the correct canvas area
		$body = elgg_view_layout("two_column_left_sidebar", '', $area1 . $area2);
			
	// If we're not allowed to see the webgalli_audio post
		} else {
			
	// Display the 'post not found' page instead
			$body = elgg_view("webgalli_audio/notfound");
			$title = elgg_echo("webgalli_audio:notfound");
			
		}
		
	// Display page
		page_draw($title,$body);
		
?>