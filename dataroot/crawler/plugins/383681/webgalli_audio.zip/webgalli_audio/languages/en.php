<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'webgalli_audio' => "Audio",
			'webgalli_audios' => "Audios",
			'webgalli_audio:user' => "%s's audio",
			'webgalli_audio:user:friends' => "%s's friends' audio",
			'webgalli_audio:your' => "Your audio",
			'webgalli_audio:posttitle' => "%s's audio: %s",
			'webgalli_audio:friends' => "Friends' audios",
			'webgalli_audio:yourfriends' => "Your friends' latest audios",
			'webgalli_audio:everyone' => "All site audios",
			'webgalli_audio:newpost' => "New audio post",
			'webgalli_audio:via' => "via audio",
			'webgalli_audio:read' => "Read audio",
			'webgalli_audio:addpost' => "Create a audio",
			'webgalli_audio:editpost' => "Edit audio post",
			'webgalli_audio:text' => "Want to describe about your audio?",
			'webgalli_audio:url' => "Audio embed code*",
			'webgalli_audio:strapline' => "%s",
			'item:object:webgalli_audio' => 'audio posts',
			'webgalli_audio:comments:allow' => 'Allow comments',
			'webgalli_audio:enablewebgalli_audio' => 'Enable group audio',
			'webgalli_audio:group' => 'Group audio',
			
         /**
	     * webgalli_audio river
	     **/
	        
	        //generic terms to use
	        'webgalli_audio:river:created' => "%s create",
	        'webgalli_audio:river:updated' => "%s updated",
	        'webgalli_audio:river:posted' => "%s posted",
	        
	        //these get inserted into the river links to take the user to the entity
	        'webgalli_audio:river:create' => "a new audio titled",
	        'webgalli_audio:river:update' => "an audio post titled",
	        'webgalli_audio:river:annotate' => "a comment on this audio post",
			
	
		/**
		 * Status messages
		 */
	
			'webgalli_audio:posted' => "Your audio post was successfully posted.",
			'webgalli_audio:deleted' => "Your audio post was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'webgalli_audio:error' => 'Something went wrong. Please try again.',
			'webgalli_audio:save:failure' => "Your audio post could not be saved. Please try again.",
			'webgalli_audio:blank' => "Sorry; you need to fill in both the title and body before you can make a post.",
			'webgalli_audio:notfound' => "Sorry; we could not find the specified audio post.",
			'webgalli_audio:notdeleted' => "Sorry; we could not delete this audio post.",
	
	);
					
	add_translation("en",$english);

?>