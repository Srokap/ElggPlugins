<?php

	/**
	 * Elgg webgalli_audio plugin
	 * @package: Audio playlist Pluggin GPL Version
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Load Elgg engine
		define('everyonewebgalli_audio','true');
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}
	//set webgalli_audio title
		if($page_owner == $_SESSION['user']){
			$area2 = elgg_view_title(elgg_echo('webgalli_audio:everyone'));
		}else{
			//$area1 = elgg_view_title($page_owner->username . "'s " . elgg_echo('webgalli_audio'));
		}
					set_context('search');		
		//$area2 = elgg_view_title(elgg_echo('webgalli_audio:everyone'));

		$area2 .= list_entities('object','webgalli_audio',0,10,false);

		// get tagcloud
		// $area3 = "This will be a tagcloud for all webgalli_audio posts";

		// Get categories, if they're installed
		//global $CONFIG;
		//$area3 = elgg_view('webgalli_audio/categorylist',array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=webgalli_audio&tagtype=universal_categories&tag=','subtype' => 'webgalli_audio'));

		$body = elgg_view_layout("two_column_left_sidebar", '', $area2);
		
	// Display page
		page_draw(elgg_echo('webgalli_audio:everyone'),$body);
		
?>