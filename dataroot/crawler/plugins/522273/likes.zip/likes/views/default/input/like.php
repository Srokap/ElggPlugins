<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @author Benjamin Graham
	* @license GNU General Public License (GPL) version 2
	*/

	echo elgg_view('likes/likes', array_merge(array('action_name' => 'like'), $vars));
