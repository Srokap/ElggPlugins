<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @author Benjamin Graham
	* @license GNU General Public License (GPL) version 2
	*/

	if (!isset($vars['entity']->autodetect_items)) {
		$vars['entity']->autodetect_items = 'yes';
	}
	if (!isset($vars['entity']->enable_ajaxsupport)) {
		$vars['entity']->enable_ajaxsupport = 'yes';
	}
	if (!isset($vars['entity']->allowdislike)) {
		$vars['entity']->allowdislike = 'no';
	}
?>
<p>
	<?php echo elgg_echo('like:autodetect_items'); ?>
	<select name="params[autodetect_items]">
		<option value="yes" <?php if ($vars['entity']->autodetect_items == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->autodetect_items != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:enable_ajaxsupport'); ?>
	<select name="params[enable_ajaxsupport]">
		<option value="yes" <?php if ($vars['entity']->enable_ajaxsupport == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->enable_ajaxsupport != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:allowdislike'); ?>
	<select name="params[allowdislike]">
		<option value="yes" <?php if ($vars['entity']->allowdislike == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->allowdislike != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	if ($vars['entity']->autodetect_items != 'no') {
		return false;
	}
?>
	<br />
	<h3><?php echo elgg_echo('likes:admin:subtitle') ?></h3>
	<br />
<p>
	<?php echo elgg_echo('like:show:thewire'); ?>
	<select name="params[show_thewire]">
		<option value="yes" <?php if ($vars['entity']->show_thewire == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_thewire != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:show:messageboard'); ?>
	<select name="params[show_messageboard]">
		<option value="yes" <?php if ($vars['entity']->show_messageboard == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_messageboard != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:show:bookmarks'); ?>
	<select name="params[show_bookmarks]">
		<option value="yes" <?php if ($vars['entity']->show_bookmarks == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_bookmarks != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:show:file'); ?>
	<select name="params[show_file]">
		<option value="yes" <?php if ($vars['entity']->show_file == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_file != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:show:blog'); ?>
	<select name="params[show_blog]">
		<option value="yes" <?php if ($vars['entity']->show_blog == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_blog != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:show:page'); ?>
	<select name="params[show_page]">
		<option value="yes" <?php if ($vars['entity']->show_page == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_page != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:show:topic'); ?>
	<select name="params[show_topic]">
		<option value="yes" <?php if ($vars['entity']->show_topic == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_topic != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	if (is_plugin_enabled('tidypics')) {
?>
<p>
	<?php echo elgg_echo('like:show:tidypics_image'); ?>
	<select name="params[show_tidypics_image]">
		<option value="yes" <?php if ($vars['entity']->show_tidypics_image == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_tidypics_image != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('like:show:tidypics_album'); ?>
	<select name="params[show_tidypics_album]">
		<option value="yes" <?php if ($vars['entity']->show_tidypics_album == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_tidypics_album != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('izap_videos')) {
?>
<p>
	<?php echo elgg_echo('like:show:izap_videos'); ?>
	<select name="params[show_izap_videos]">
		<option value="yes" <?php if ($vars['entity']->show_izap_videos == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_izap_videos != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('event_calendar')) {
?>
<p>
	<?php echo elgg_echo('like:show:event_calendar'); ?>
	<select name="params[show_event_calendar]">
		<option value="yes" <?php if ($vars['entity']->show_event_calendar == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_event_calendars != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('profile')) {
?>
<p>
	<?php echo elgg_echo('like:show:profile'); ?>
	<select name="params[show_profile]">
		<option value="yes" <?php if ($vars['entity']->show_profile == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_profile != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('customstyle')) {
?>
<p>
	<?php echo elgg_echo('like:show:customstyle'); ?>
	<select name="params[show_customstyle]">
		<option value="yes" <?php if ($vars['entity']->show_customstyle == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_customstyle != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('quotes')) {
?>
<p>
	<?php echo elgg_echo('like:show:quotes'); ?>
	<select name="params[show_quotes]">
		<option value="yes" <?php if ($vars['entity']->show_quotes == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_quotes != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('mood')) {
?>
<p>
	<?php echo elgg_echo('like:show:mood'); ?>
	<select name="params[show_mood]">
		<option value="yes" <?php if ($vars['entity']->show_mood == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_mood != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('media')) {
?>
<p>
	<?php echo elgg_echo('like:show:media'); ?>
	<select name="params[show_media]">
		<option value="yes" <?php if ($vars['entity']->show_media == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_media != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
	if (is_plugin_enabled('donation')) {
?>
<p>
	<?php echo elgg_echo('like:show:donate'); ?>
	<select name="params[show_donate]">
		<option value="yes" <?php if ($vars['entity']->show_donate == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_donate != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<?php
	}
?>
