<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @author Benjamin Graham
	* @license GNU General Public License (GPL) version 2
	*/
	if (!isloggedin()) {
		return false;
	}
	$entity = get_entity($vars['item']->object_guid);
	if ($entity && $vars['item']) {
		$content = elgg_view('input/like', array('entity' => $entity, 'item' => $vars['item']));
		echo elgg_view('likes/wrapper', array('body' => $content));
		if (get_plugin_setting('allowdislike', 'likes') == 'yes') {
			$content = elgg_view('input/dislike', array('entity' => $entity, 'item' => $vars['item']));
			echo elgg_view('likes/wrapper', array('body' => $content));
		}
	}
