<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @author Benjamin Graham
	* @license GNU General Public License (GPL) version 2
	*/
?>

<script type="text/javascript">
	$(document).ready(function(){
		lkPrepareItems();
	})
	function lkPrepareItems(){
		//Execute the action
		$('.likes a.action').unbind('click')
		$('.likes a.action').click(function(e) {
			e.stopPropagation();
			readyToAnnotate(this);
			return false;
		});

		//Show a lightbox
		$('.likes a.who_else').unbind('click');
		$('.likes a.who_else').click(function(e) {
			e.stopPropagation();
			showWhoElse(this);
			return false;
		});
	}

	function readyToAnnotate(oObject) {
		oContainer = $(oObject).parents('.likes');
		sUrl = "<?php echo $vars['url'] ?>mod/likes/endpoint/ping.php";
		sCallBack = lkPrepareItems;
		executeAction(oObject, oContainer, sUrl, sCallBack);
	}

	function showWhoElse(oObject){
		oContainer = $('.lb .lightbox-content');
		//add special Class.
		$(oContainer).addClass('likes-content');
		sUrl = "<?php echo $vars['url'] ?>pg/likes/who/";
		sCallBack = showLB('.lbHome');
		executeAction(oObject, oContainer, sUrl, sCallBack);
	}

	function executeAction(oObject, oContainer, sUrl, sCallBack) {
		oObject = $(oObject);
		var linkElement = oObject.attr('href');
		var queryString = '';
		var queryStringAux = linkElement.split('?');
		if (typeof queryStringAux[1] != 'undefined') {
			queryString = '?' + queryStringAux[1] + '&callback=true';
		}
		var actionFile = '';
		if (typeof queryStringAux[0] != 'undefined') {
			var actionAux = queryStringAux[0];
			actionAux = actionAux.split('/');
			if (actionAux.length > 0) {
				actionAux = actionAux[actionAux.length-1];
				actionFile = "&action_file=" + actionAux;
			}
		}
		oContainer.load(sUrl + queryString + actionFile, sCallBack);
	}

</script>
