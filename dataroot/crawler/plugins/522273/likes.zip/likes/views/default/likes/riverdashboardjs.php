<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @author Benjamin Graham
	* @license GNU General Public License (GPL) version 2
	*/
?>
	<script type="text/javascript">
		$(document).ready(function(){
			lkPrepareItems();
		})
	</script>
