<?php
	// Load Elgg engine will not include plugins
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

	//Get the data
	$item_id = get_input('river_item');
	$item = new StdClass();
	$item->id = $item_id;
	$action_name = get_input('action_name');
	$action_file = get_input('action_file');
	$entity_guid = get_input('guid');
	$entity = get_entity($entity_guid);
	$callback = true;

	//Add the action
	require_once(dirname(dirname(__FILE__)) . "/actions/$action_file.php");
	echo elgg_view("input/$action_name", array('entity' => $entity, 'item' => $item, 'callback' => $callback));
