<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @author Benjamin Graham
	* @license GNU General Public License (GPL) version 2
	*/

	// YYYYMMDD = river_comments date
	// XX = Interim incrementer
	$version = 2010063001;

	// Human-friendly version name
	$release = '0.3.3';
