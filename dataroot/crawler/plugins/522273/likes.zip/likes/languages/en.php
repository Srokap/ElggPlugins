<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @author Benjamin Graham
	* @license GNU General Public License (GPL) version 2
	*/

	$english = array(
			'likes:admin' => 'Like Settings',
			'likes:admin:subtitle' => 'Do you like show the "like this" button for...',
			'like:autodetect_items' => 'Autodetect river items to extend?',
			'like:enable_ajaxsupport' => 'Enable Ajax Support (Disable if you have a problem)',
			'like:allowdislike' => 'Enable the "dislike" functionality?',
			'like:show:thewire' => 'the wire on the river?',
			'like:show:messageboard' => 'messageboard on the river?',
			'like:show:bookmarks' => 'bookmarks on the river?',
			'like:show:blog' => 'blog on the river?',
			'like:show:file' => 'file on the river?',
			'like:show:page' => 'page on the river?',
			'like:show:topic' => 'discussion topic on the river?',

			/*
			 * Third party mods Like
			*/
			'like:show:tidypics_image'  => 'tidypics image on the river?',
			'like:show:tidypics_album'  => 'tidypics album on the river?',
			'like:show:izap_videos'  => 'izap videos on the river?',
			'like:show:event_calendar'  => 'event calendar page on the river?',
			'like:show:media'  => 'media on the river?',
			'like:show:mood'  => 'mood on the river?',
			'like:show:profile'  => 'profile changes on the river?',
			'like:show:customstyle'  => 'customstyle changes on the river?',
			'like:show:quotes'  => 'quotes on the river?',
			'like:show:donate'  => 'donation on the river?',

			/*Like*/
			'like' => 'Like',
			'unlike' => 'Unlike',
			'like:youlikethis' => 'You like this.',
			'like:otherlikesthis' => '%s likes this.',
			'like:otherandyoulikethis' => 'You and %s like this.',
			'like:others2likethis' => '%s and %s like this.',
			'like:others' => '%s others',
			'like:lotofpeoplelikethis' => '%s people like this.',
			'like:youandalotofpeoplelikethis' => 'You and %s like this.',

			/*DisLike*/
			'dislike' => 'Dislike',
			'undislike' => 'Undislike',
			'dislike:youdislikethis' => 'You dislike this.',
			'dislike:otherdislikesthis' => '%s dislikes this.',
			'dislike:otherandyoudislikethis' => 'You and %s dislike this.',
			'dislike:others2dislikethis' => '%s and %s dislike this.',
			'dislike:others' => '%s others',
			'dislike:lotofpeopledislikethis' => '%s people dislike this.',
			'dislike:youandalotofpeopledislikethis' => 'You and %s dislike this.',

			/*Actions*/
			'like:posted' => 'Your "like" was successfully posted.',
			'like:failure' => 'An unexpected error occurred when adding your "like". Please try again.',
			'like:deleted' => 'Your "like" was successfully deleted.',
			'like:notdeleted' => 'Sorry, we could not delete this "like".',
			'dislike:posted' => 'Your "dislike" was successfully posted.',
			'dislike:failure' => 'An unexpected error occurred when adding your "dislike". Please try again.',
			'dislike:deleted' => 'Your "dislike" was successfully deleted.',
			'dislike:notdeleted' => 'Sorry, we could not delete this "dislike".',
	);

	add_translation("en",$english);
?>
