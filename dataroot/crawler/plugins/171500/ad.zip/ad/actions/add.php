<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();
		
	// Get input data
		$title = get_input('adtitle');
		$body = get_input('adbody');
		$price = get_input('adprice');
		$tags = get_input('adtags');
		$access = get_input('access_id');
        $tipo = get_input('tipo');
        $homepage = get_input('homepage'); 
		
	// Cache to the session
		$_SESSION['adtitle'] = $title;
		$_SESSION['adbody'] = $body;
		$_SESSION['adprice'] = $price;
		$_SESSION['adtags'] = $tags;
        $_SESSION['tipo'] = $tipo;
		
	// Convert string of tags into a preformatted array
		$tagarray = string_to_tag_array($tags);
		
	// Make sure the title / description aren't blank
		if (empty($title) || empty($body) ) {
			register_error(elgg_echo("ad:blank"));
			forward("mod/ad/add.php");
			
	// Start Saving the Post
		} else {
		
	/** Lets deal with creating the post
	------------------------------------------------------------
	*/
	// Initialise a new ElggObject
			$ad = new ElggObject();
			
	// Tell the system it's an ad post
			$ad->subtype = "ad";
			
	// Set its owner to the current user
			$ad->owner_guid = $_SESSION['user']->getGUID();
			
	// Set its access_id
			$ad->access_id = $access;
			
	// Set its title and description appropriately
			$ad->title = $title;
			$ad->description = $body;
			$ad->price = $price;
            $ad->tipo = $tipo;
            $ad->homepage= $homepage;
			
	// Before we can set metadata, we need to save the ad post
			if (!$ad->save()) {
				register_error(elgg_echo("ad:error"));
				forward("mod/ad/add.php");
			}
			
	// Now let's add tags
			if (is_array($tagarray)) {
				$ad->tags = $tagarray;
			}
			
	/** Now lets deal with our uploaded image
	------------------------------------------------------------
	*/
	// Create a user adfolder based on GUID, if it doen't have one
			if (!is_dir( $CONFIG->path . '/ad/' . $_SESSION['user']->getGUID())){
					mkdir($CONFIG->path . '/ad/' . $_SESSION['user']->getGUID(), 0777, true);
			}
			
	if (!empty( $_FILES['upload']['type'])) {
	
	// Check the file size			
			if ($_FILES['upload']['size'] > 1048576) {
			register_error(elgg_echo("ad:tobig"));
			forward("mod/ad/add.php");
			} else {
	// Check the file type			
			if ( $_FILES['upload']['type'] != 'image/jpeg' and $_FILES['upload']['type'] != 'image/pjpeg') {
			register_error(elgg_echo("ad:notjpg"));
			forward("mod/ad/add.php");
			} else {
	// Create a unique but logical filename based on title and time
			$filename = strtolower($title);
			$filename = str_replace(' ', '_', $filename);
			$filename = preg_replace('/[^a-z0-9_]/i', '', $filename);
			$filename = $filename . '_' . md5(uniqid(mt_rand()));
			
	// Copy the uploaded image to the user folder
			copy($_FILES['upload']['tmp_name'], $CONFIG->path . '/ad/' . $_SESSION['user']->getGUID() . '/' . $filename . '.jpg');
			
	// Adding the filelocation to the ad post
			$ad->annotate('adlocation', 'ad/' . $_SESSION['user']->getGUID() . '/' . $filename, $access, $_SESSION['user']->getGUID(), "string");
			
	// Create a small thumbnail	
			$img = $CONFIG->path . '/ad/' . $_SESSION['user']->getGUID() . '/' . $filename . '.jpg';
			$canvas_width  = 153;
			$canvas_height = 153;
			list($img_width, $img_height) = getimagesize($img);
			$original = imagecreatefromjpeg($img);
					if ($img_width > $canvas_width or $img_height > $canvas_height){
					$ratio_orig = $img_width / $img_height;
					if ($canvas_width / $canvas_height > $ratio_orig){
		  					$canvas_width = $canvas_height * $ratio_orig;	
						} else {
							$canvas_height = $canvas_width / $ratio_orig;
						}
					$canvaslarge = imagecreatetruecolor($canvas_width, $canvas_height);
     				imagecopyresampled($canvaslarge, $original, 0, 0, 0, 0, $canvas_width, $canvas_height, $img_width, $img_height);
					imagejpeg($canvaslarge, $CONFIG->path . '/ad/' . $_SESSION['user']->getGUID() . '/' . $filename . '_thumblarge.jpg', 100);
				} else {
					copy($img, $CONFIG->path . '/ad/' . $_SESSION['user']->getGUID() . '/' . $filename . '_thumblarge.jpg');
				}
				
	// Delete the original image	
			unlink($img);
			} 
		}
	}
	// If no image is uploaded, we need to create one, else the thumbnail for listing and widgets will appear as blank.
	else {
	
	// Adding the filelocation to the ad post
			$ad->annotate('adlocation', 'ad/' . $_SESSION['user']->getGUID() . '/' . $filename, $access, $_SESSION['user']->getGUID(), "string");
			
	// Create a thumbnail	
			$img = $CONFIG->path . '/mod/ad/graphics/' . noimage . '.jpg';
			copy($img, $CONFIG->path . '/ad/' . $_SESSION['user']->getGUID() . '/' . $filename . '_thumblarge.jpg');
		}
	// Success message
			system_message(elgg_echo("ad:posted"));
			
	// Add to river
	        add_to_river('river/object/ad/create','create',$_SESSION['user']->guid,$ad->guid);
			
	// Remove the ad post cache
			unset($_SESSION['adtitle']); unset($_SESSION['adbody']); unset($_SESSION['adprice']); unset($_SESSION['adtags']);
            unset($_SESSION['tipo']);
			remove_metadata($_SESSION['user']->guid,'adtitle');
			remove_metadata($_SESSION['user']->guid,'adbody');
			remove_metadata($_SESSION['user']->guid,'adtags');
			remove_metadata($_SESSION['user']->guid,'adprice');
            remove_metadata($_SESSION['user']->guid,'tipo');
	// Forward to the main ad page
			//forward("mod/ad/?username=" . $owner->username);
			forward($ad->getURL());
		}
?>