<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) forward();

	// Get input data
		$guid = (int) get_input('adpost');
		$title = get_input('adtitle');
		$price = get_input('adprice');
		$body = get_input('adbody');
		$access = get_input('access_id');
		$tags = get_input('adtags');
        $tipo = get_input('tipo');
        $homepage = get_input('homepage');
		
	// Make sure we actually have permission to edit
		$ad = get_entity($guid);
		if ($ad->getSubtype() == "ad" && $ad->canEdit()) {
	
		// Cache to the session
			$_SESSION['adtitle'] = $title;
			$_SESSION['adbody'] = $body;
			$_SESSION['adprice'] = $price;
			$_SESSION['adtags'] = $tags;
			$_SESSION['adcategory'] = $category;
            $_SESSION['tipo'] = $tipo;
		// Convert string of tags into a preformatted array
			$tagarray = string_to_tag_array($tags);
			
		// Make sure the title / description aren't blank
			if (empty($title) || empty($body)) {
				register_error(elgg_echo("ad:blank"));
				forward("mod/ad/add.php");
				
		// Otherwise, save the ad post 
			} else {
				
		// Get owning user
				$owner = get_entity($ad->getOwner());
		// For now, set its access to public (we'll add an access dropdown shortly)
				$ad->access_id = $access;
		// Set its title and description appropriately
				$ad->title = $title;
				$ad->description = $body;
				$ad->price = $price;
                $ad->tipo = $tipo;
                $ad->homepage= $homepage;
		// Before we can set metadata, we need to save the ad post
				if (!$ad->save()) {
					register_error(elgg_echo("ad:error"));
					forward("mod/ad/edit.php?adpost=" . $guid);
				}
		// Now let's add tags. We can pass an array directly to the object property! Easy.
				$ad->clearMetadata('tags');
				if (is_array($tagarray)) {
					$ad->tags = $tagarray;
					
				}
				
		// Success message
				system_message(elgg_echo("ad:posted"));
		// add to river
				add_to_river('river/object/ad/update','update',$_SESSION['user']->guid,$ad->guid);
		// Remove the ad post cache
			unset($_SESSION['adtitle']); unset($_SESSION['adbody']); unset($_SESSION['adprice']); unset($_SESSION['adtags']);
            unset($_SESSION['adtipo']);
			remove_metadata($_SESSION['user']->guid,'adtitle');
			remove_metadata($_SESSION['user']->guid,'adbody');
			remove_metadata($_SESSION['user']->guid,'adtags');
			remove_metadata($_SESSION['user']->guid,'adprice');
            remove_metadata($_SESSION['user']->guid,'adtipo');
		// Forward to the main ad page
				//forward("mod/ad/?username=" . $owner->username);
				forward($ad->getURL());
			}
		
		}
		
?>