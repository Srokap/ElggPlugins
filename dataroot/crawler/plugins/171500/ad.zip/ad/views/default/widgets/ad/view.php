<?php
	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	//the page owner
	$owner = get_user($vars['entity']->owner_guid);
	$friendlytime = friendly_time($vars['entity']->time_created);

    //the number of files to display
	$num = (int) $vars['entity']->num_display;
	if (!$num)
		$num = 8;
		
	//get the correct size
	$size = (int) $vars['entity']->icon_size;
		
    // Get the users friends
	$ads = get_user_objects($vars['entity']->owner_guid, "ad", $num, 0);
		
	// display the posts, if there are any
	if (is_array($ads) && sizeof($ads) > 0) {

		echo "<div id=\"contentWrapper\">";
		
		if (!$size || $size == 1){
			foreach($ads as $ad) {
				// Images and links
				$annotations = $ad->getAnnotations('adlocation', 1);
			foreach ($annotations as $annotation){
				$icon = "<p><a href=\"{$ad->getURL()}\"><img src=\"" . $CONFIG->wwwroot . $annotation['value'] . '_thumblarge.jpg' . "\" width=\"40\" height=\"40\" /></a></p>";
				}
				$info = "<p><a href=\"{$ad->getURL()}\">{$ad->title}</a></p>";
				$info .= "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</p>";
				echo elgg_view_listing($icon,$info);				
			}
			
		}
		echo "<div class=\"contentWrapper\"><a href=\"" . $CONFIG->wwwroot . "pg/ad/" . $owner->username . "\">" . elgg_echo("ad:widget:viewall") . "</a></div>";

		echo "<div class=\"clearfloat\"></div>";
					
		echo "</div>";
			
    }
	
?>