<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

		if (isset($vars['entity'])) {
			
			if (get_context() == "search"||get_context() == "ad2"||get_context() == "admin") {
				
				//display the correct layout depending on gallery or list view
				if (get_input('search_viewtype') == "gallery") {

					//display the gallery view
            				echo elgg_view("ad/gallery",$vars);

				} else {
				
					echo elgg_view("ad/listing",$vars);

				}
				
			} else {
?>
		<div class="contentWrapper singleview">

    	<!-- displaying header -->
		<div class="ad_title_owner_wrapper"> 
    	<?php
				//get the user and a link to their gallery
				$user_gallery = $CONFIG->wwwroot . "mod/ad/" . $vars['entity']->getOwnerEntity()->username . "/search_viewtype=list";
		?>
		<div class="ad_gallery_link"><a href="<?php echo $user_gallery; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?>: <?php echo elgg_echo("ad"); ?></a></div>
		<div class="ad_title"><h2><?php echo $vars['entity']->title; ?></h2>
   		</div>
			<div class="ad_details_holder">
					<?php echo elgg_view("profile/icon",array('entity' => $vars['entity']->getOwnerEntity(), 'size' => 'tiny')); ?>
					<p class="strapline">
				<?php echo sprintf(elgg_echo("ad:strapline"), date("F j, Y",$vars['entity']->time_created)); ?>
				<?php echo elgg_echo('ad:by'); ?> <a href="<?php echo $vars['url']; ?>pg/ad/<?php echo $vars['entity']->getOwnerEntity()->username; ?>"><?php echo $vars['entity']->getOwnerEntity()->name; ?></a>
		<!-- display the comments link -->
				<?php
			    //get the number of comments
			    $num_comments = elgg_count_comments($vars['entity']);
			    ?>
			    <?php echo "(" . $num_comments . " " . sprintf(elgg_echo("ad:replies")) . ")"; ?> <BR>
		<!-- display tags -->
			<div>
        <p class="tags"><strong><?php echo elgg_echo('ad:tags'); ?>:</strong><?php echo elgg_view('output/tags', array('tags' => $vars['entity']->tags)); ?></p>
      </div>
			</div>
			</div>
 					<?php
					$adcategories = elgg_view('adcategories/view', $vars);
					if (!empty($adcategories)) {
					?>
					<strong><?php echo elgg_echo('ad:categoria'); ?>:</strong>
					<?php
					echo '<p class="adcategories">' . $adcategories . '</p>';
					}				
					?>
		<!-- displaying the images -->            
            <div class="ad_post_body">
				<?php
						$annotations = $vars['entity']->getAnnotations('adlocation');
						foreach ($annotations as $annotation){ 
				?>
			
    <div class="ad-largethumb"> 
      <div align="center"><img src= "<?php echo ($CONFIG->wwwroot . $annotation['value'] . '_thumblarge.jpg'); ?>" width="153" height="153" /> 
        <br>
      </div>
    </div>	
				<?php		
                        }		
				?>
			</div>
            <div class="clearfloat"></div>
		<!-- display the actual ad post -->
        <!-- displaying the body -->
  			<div class="ad_post_body">
            <?php echo autop($vars['entity']->tipo); ?>
 
    		<?php echo autop($vars['entity']->description); ?>
    		<strong><?php echo elgg_echo('ad:price'); ?>:</strong> <?php echo (autop($vars['entity']->price)); ?>
  			</div>
		<!-- display edit options if it is the ad post owner -->
			<p class="options">
			<?php
				if ($vars['entity']->canEdit()) {
			?>
                <a href="<?php echo $vars['url']; ?>mod/ad/edit.php?adpost=<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo("edit"); ?></a>  &nbsp; 
				<?php echo elgg_view("output/confirmlink", array(
															'href' => $vars['url'] . "action/ad/delete?adpost=" . $vars['entity']->getGUID(),
															'text' => elgg_echo('delete'),
															'confirm' => elgg_echo('deleteconfirm'),
																));
		// Allow the menu to be extended
				echo elgg_view("editmenu",array('entity' => $vars['entity'])); ?>
				<?php
				}
				?>
			</p>
			</div>
<?php
		// If we've been asked to display the full view
				if (isset($vars['full']) && $vars['full'] == true) {
					echo elgg_view_comments($vars['entity']);
				}
			}
		}
?>