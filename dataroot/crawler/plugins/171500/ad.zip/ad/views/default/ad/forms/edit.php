<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */

	// Set title, form destination
		if (isset($vars['entity'])) {
			$title = sprintf(elgg_echo("ad:editpost"),$object->title);
			$action = "ad/edit";
			$title = $vars['entity']->title;
			$body = $vars['entity']->description;
            $homepage = $vars['entity']->homepage;
			$price = $vars['entity']->price;
			$tags = $vars['entity']->tags;
			$access_id = $vars['entity']->access_id;
            $tipo=$vars['entity']->tipo;
		} else  {
			$title = elgg_echo("ad:addpost");
			$action = "ad/add";
			$tags = "";
			$title = "";
			$description = "";
			$access_id = 0;
            $tipo="";
            $homepage = "No";
		}

	// Just in case we have some cached details
		if (isset($vars['adtitle'])) {
			$title = $vars['adtitle'];
			$body = $vars['adbody'];
			$price = $vars['adprice'];
			$tags = $vars['adtags'];
            $tipo = $vars['tipo'];
		}

//$adtype= array('offro','cerco', 'scambio');
$adtype[]=sprintf(elgg_echo('ad:offer'));
$adtype[]=sprintf(elgg_echo('ad:sell'));
$adtype[]=sprintf(elgg_echo('ad:change'));

$i=(int)0;
foreach ($adtype as $adt){
    $adti[$adt]=$adt;
    $i=$i+1;
}

?>
<div class="contentWrapper">

	<form action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" enctype="multipart/form-data" method="post">
  <p> 
    <label><?php echo elgg_echo("title"); ?><br />
    <?php

				echo elgg_view("input/text", array(
									"internalname" => "adtitle",
									"value" => $title,
													));
			
			?>
    </label>
  </p>

  
		<p>
			<label><?php echo elgg_echo("ad:text"); ?><br />
			<?php

				echo elgg_view("input/longtext",array(
									"internalname" => "adbody",
									"value" => $body,
													));
			?>
			</label>
		</p>


        <p>
			<label><?php echo elgg_echo("ad:type"); ?><br />
			<?php

				echo elgg_view("input/pulldown",array('internalname' =>"tipo", 'options_values' =>$adti
													));
			?>
			</label>
		</p>

		
		
		    <p> 
    <label><?php echo elgg_echo("ad:price"); ?><br />
    <?php

				echo elgg_view("input/text", array(
									"internalname" => "adprice",
									"value" => $price,
													));
			
			?>
    </label>
  </p>
  

				<p>
			<label><?php echo elgg_echo("ad:tags"); ?><br />
    <?php

				echo elgg_view("input/tags", array(
									"internalname" => "adtags",
									"value" => $tags,
													));
			
			?>
			 </label>
  </p>
    <?php

		$adcategories = elgg_view('adcategories',$vars);
		if (!empty($adcategories)) {
?>
    <p>
			<?php echo $adcategories; ?>
		</p>

<?php
		}

?>	
		

        <!-- display upload if action is edit -->
        		<?php
				if ($action == "ad/add") {	
				?>
        				<p>
   					     	<label><?php echo elgg_echo("ad:uploadimages"); ?><br />
   				     		   <?php echo elgg_echo("ad:imagelimitation"); ?><br />
							<?php
									echo elgg_view("input/file",array('internalname' => 'upload'));
					
							?>
 				           </label>
 				        </p>
 		        <?php
					}
				?>
         <!-- display upload if action is edit end -->
		<p>
			<label>
				<?php echo elgg_echo('access'); ?><br />
				<?php echo elgg_view('input/access', array('internalname' => 'access_id','value' => $access_id=2)); ?>
			</label>
		</p>
        <?php echo elgg_view('input/hidden', array('internalname' => 'homepage','value' => "No")); ?>
		<p>
			<?php

				if (isset($vars['entity'])) {
					?><input type="hidden" name="adpost" value="<?php echo $vars['entity']->getGUID(); ?>" /><?php
				}
			
			?>
			<input type="submit" name="submit" value="<?php echo elgg_echo('save'); ?>" />
		</p>
	
	</form></div>