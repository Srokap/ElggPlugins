<?php

	/**
	 * Elgg Classifieds Pluggin V2
	 * @package Classifieds Pluggin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dr Sanu P Moideen for Team Webgalli
	 * @copyright Team Webgalli
	 * @link www.Webgalli.com, www.m4medicine.com
	 */
		$owner = $vars['entity']->getOwnerEntity();
   
		$friendlytime = friendly_time($vars['entity']->time_created);
			$annotations = $vars['entity']->getAnnotations('adlocation',1);
			foreach ($annotations as $annotation){
				$icon = "<p><a href=\"{$vars['entity']->getURL()}\"><img src=\"" . $CONFIG->wwwroot . $annotation['value'] . '_thumblarge.jpg'  . "\" width=\"35\" height=\"35\" /></a></p>";
				}
		$info .= "<p><a href=\"{$CONFIG->wwwroot}"."mod/ad/read.php?adpost=".$vars['entity']->guid." \">{$vars['entity']->title}</a></p>";
        $info .= sprintf(elgg_echo('ad:type')).": ".sprintf($vars['entity']->tipo);
        $info .="<br />";
        $info .=sprintf(elgg_echo('ad:description')).": ";
        $description=$vars['entity']->description;
    (int)$numcar=30;
                if(strlen($description)<$numcar){
                    $info .=sprintf($description);
                }
                else{
                    $description=explode(" ",substr($description,0,$numcar));
                    array_pop($description); //toglie l'ultima parola (monca)
                    $description=(implode(" ",$description));
                    $info .=sprintf(strip_tags($description)).sprintf(' ...');
                    $info .=sprintf("<br \>");
                }
                  $adcategories = elgg_view('adcategories/view', $vars);

					if (!empty($adcategories)) {
					$info .=sprintf(elgg_echo('ad:categoria')).": " .sprintf($adcategories)."\n";
                    $info .=sprintf("<br \>");
					}
   
		$info .= "<p class=\"owner_timestamp\"><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</p>";
      
		echo elgg_view_listing($icon,$info);
?>