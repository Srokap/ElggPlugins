Modified Classifieds Pluggin for Elgg 1.5
by Vinsoft di Erminia Naccarato www.vinsoft.it
----------------------------------
----------------------------------



INSTALLATION

----------------------------------
----------------------------------


1. Drop the folders ad and adcategories in "/mod"

2. Create a folder called "ad" in your ELGG-INSTALL FOLDER with read-write access (chmod 777)

3. Activate both the plugins in the administration panel

4. Create some classifieds categories under the admin panel

5. To change any of the dialog words and sentences, edit 'mod/ad/languages/en.php'


----------------------------------
----------------------------------
CHANGE LOG V1.0b2
----------------------------------
----------------------------------

Fixed some english translations


----------------------------------
----------------------------------
CHANGE LOG V1.0b1
----------------------------------
----------------------------------

Added new features:

    * added field "Sell, Offer, Change"
    * fixed search by categories
    * improved Ads listing
    * Fixed menu bug

WARNING

This is a BETA version for testing purposes only, not production. It works well in our testing environment but unsolved bugs have been reported. 


----------------------------------
----------------------------------
CHANGE LOG V2
----------------------------------
----------------------------------


1. Its now easy to create the ad categories under the admin panel, no need for any code editing

2. The image upload is now optional

3. Fixed the language file

4. Cleaned up the code

5. River support for new elgg

6. And many more...

----------------------------------
----------------------------------
Features
----------------------------------
----------------------------------

*Unlimited number of classifieds.

*Classifieds are seen as a whole (search, tags...) not as seperate images.

*Classifieds are categorised for easy finding

*View friends Classifieds

*Comments on Classifieds

*Image upload optional


----------------------------------
----------------------------------


----------------------------------
----------------------------------


Programmed by Dr Sanu P Moideen for Team Webgalli (www.webgalli.com)

drsanupmoideen@gmail.com

----------------------------------

----------------------------------

