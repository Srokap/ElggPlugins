<?php
		/**
	 * Elgg Cinema plugin
	 *
	 * @package ElggCinema
	 * @author VinSoft di Erminia Naccarato
	 * @copyright VinSoft 2009
	 * @link http://vinsoft.it
	 *
	 */


	
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

    set_context('ad');
    
	$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}

	//$area1 = elgg_view_title(elgg_echo("ad"));
	$area2 = elgg_view_title(elgg_echo("ad"));

    $area2.=list_entities("object", "ad");
    //$area2 .= elgg_view('ad/categorylist',array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=ad&owner_guid='.$page_owner->guid.'&tagtype=universal_adcategories&tag=','subtype' => 'ad', 'owner_guid' => $page_owner->guid));
    $area3 = elgg_view('ad/categorylist',array('baseurl' => $CONFIG->wwwroot . 'search/?subtype=ad&owner_guid='.$page_owner->guid.'&tagtype=universal_adcategories&tag=','subtype' => 'ad', 'owner_guid' => $page_owner->guid));

	$body = elgg_view_layout("two_column_left_sidebar", '', $area1 . $area2, $area3);

	// Display page
		page_draw(elgg_echo('ad:everyone'),$body);
	?>