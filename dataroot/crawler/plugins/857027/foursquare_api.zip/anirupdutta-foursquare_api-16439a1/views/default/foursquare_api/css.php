<?php
/**
 * Elgg Google+ API CSS
 */
?>

#foursquare_api_site_settings .text_input {
	width: 350px;
}
#login_with_foursquare {
	padding: 10px 0 0 0;
}