/**
 * Open the chat in a popup window
 */
function chat_open(url) {
  window.open(url, "Chat", "width=580,height=630,resizable=yes");
  //return false;
}
