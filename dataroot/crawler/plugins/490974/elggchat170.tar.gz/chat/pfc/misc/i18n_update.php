<?php

require_once(dirname(__FILE__)."/../src/pfci18n.class.php");
pfcI18N::UpdateMessageRessources();

?>