<?php
 /**
  * Elgg Chat plugin - common js include
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggchat
  * @see http://www.phpfreechat.net/
  */
?>

<script type="text/javascript" src="<?php echo $CONFIG->wwwroot ?>mod/chat/chat.js"></script>
