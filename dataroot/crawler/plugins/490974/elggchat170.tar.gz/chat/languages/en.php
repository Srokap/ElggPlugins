<?php

	$english = array(
        /**
         * Misc
         */
            'chat:open' => 'Open chat'
	
	);
					
	add_translation("en", $english);

?>
