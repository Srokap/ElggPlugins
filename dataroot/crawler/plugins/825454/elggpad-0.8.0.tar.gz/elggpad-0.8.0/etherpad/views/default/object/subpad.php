<?php
/**
 * Subpad view
 *
 * @package ElggPad
 */

echo elgg_view('object/etherpad', $vars);
