<?php
	/*******************************************************************
	/****************** Traduction pluggin OpenID **********************
	/*******************************************************************
	/****************** Auteur: Adrian Urso       **********************
	/****************** Date: 31/07/2009	      **********************
	/****************** Pour: Société i-com	      **********************
	/****************** Elgg: 1.5	      		  **********************
	/*******************************************************************
	/*******************************************************************/
	
	$french = array(	
			
		'openid_client_login_title'                     => "Connexion avec OpenID",
		'openid_client_login_service'                   => "Service",
		'openid_client_logon'                           => "Logon",
		'openid_client_go'                              => "Connexion",
		'openid_client_remember_login'                  => "Se souvenir de moi",
		'openid_client:already_loggedin'                => "Vous &ecirc;tes d&eacute;j&agrave; connect&eacute;.",
		'openid_client:login_success'                   => "Connexion r&eacute;ussie.",
		'openid_client:login_failure'                   => "Nom d'utilisateur non sp&eacute;cifi&eacute;. Connexion impossible.",
		'openid_client:disallowed'                      => "Ce site n'accepte pas l'OpenId que vous avez saisi. "
		        ."Merci d'essayer avec un autre OpenID ou contactez l'administrateur du site pour plus d'informations.",
		'openid_client:redirect_error'                  => "Redirection impossible vers le serveur: %s",
		'openid_client:authentication_failure'          => "Authentication OpenID &eacute;chou&eacute;e: %s n'est pas une URL OpenID valide.",
		'openid_client:authentication_cancelled'        => "Authentication OpenID annul&eacute;e.",
		'openid_client:authentication_failed'           => "Authentication OpenID &eacute;chou&eacute;e (statut: %s, message: %s )",
		'openid_client:banned'                          => "Vous avez &eacute;t&eacute; banni du syst&egrave;me!",
		'openid_client:email_in_use'                    => "Impossible de changer votre adressse mail en %s car elle semble d&eacute;j&agrave; utilis&eacute;e.",
		'openid_client:email_updated'                   => "Votre adressse mail a &eacute;t&eacute; modifi&eacute;e en %s",
		'openid_client:information_title'               => "Informations OpenID ",
		'openid_client:activate_confirmation'           => "Un message de confirmation a &eacute;t&eacute; envoy&eacute; a %s ."
		        ." Merci de cliquer sur le lien contenu dans celui-ci afin d'activer votre compte."
		        ." Vous pourrez ensuite vous authentifier &agrave; l'aide de votre OpenID.",
        'openid_client:change_confirmation'             => "Votre adresse mail a chang&eacute;. Un message de confirmation vient d'&ecirc;tre envoy&eacute; a"
                ." %s . Merci de cliquer sur le lien contenu dans celui-ci  pour valider cette nouvelle adresse. ",
        'openid_client:activate_confirmation_subject'   => "v&eacute;rification du compte %s ",
        'openid_client:activate_confirmation_body'      => "Chers %s,\n\nMerci de vous &ecirc;tre enregistr&eacute; avec %s.\n\n"
            ."Pour terminer votre inscription, suivez ce lien:\n\n\t%s\n\ndans les septs jours.\n\nCordialement,\n\nl'&eacute;quipe de %s.",
        'openid_client:change_confirmation_subject'     => "Adresse mail de %s chang&eacute;e",
        'openid_client:change_confirmation_body'        => "Chers %s,\n\nNous avons re&ccedil;u une demande de changement de votre adresse mail"
            ." enregistr&eacute;e avec %s.\n\nAfin de changer votre adresse mail en {%s}, suivant ce lien:\n\n\t%s\n\ndans les septs jours."
            ."Cordialement,\n\nl'&eacute;quipe de %s.",				
	    'openid_client:email_label'                     => "Email:",
	    'openid_client:name_label'                      => "Nom:",
	    'openid_client:submit_label'                    => "Soumettre",
	    'openid_client:cancel_label'                    => "Annuler",
	    'openid_client:nosync_label'                    => "Ne plus me notifier de nouveau si les donn&eacute;es sur ce syst&egrave;me ne sont pas les m&ecirc;mes"
	        ." que celles de mon serveur OpenID.",
	    'openid_client:sync_instructions'               => "Les informations sur votre serveur OpenID ne sont pas les m&ecirc;mes que sur ce syst&egrave;me."
	        ." Cochez les cases &agrave; cocher &agrave; c&ocirc;t&eacute; des informations que vous souhaitez mettre &agrave; jour (le cas &eacute;ch&eacute;ant) et cliquez sur soumettre.",
	    'openid_client:missing_title'					=> "Merci de remplir les informations manquantes",
	    'openid_client:sync_title'						=> "Synchroniser vos informations",
	    'openid_client:missing_email'                   => "une adresse mail valide",
	    'openid_client:missing_name'                    => "votre nom complet",
	    'openid_client:and'                             => "et",
	    'openid_client:missing_info_instructions'       => "Afin de cr&eacute;er un compte sur ce site, vous devez fournir %s."
	        ." Merci de bien vouloir saisir ces informations ci-dessous.",
	    'openid_client:create_email_in_use'             => "Impossible de cr&eacute;er un compte avec l'adresse mail %s car elle est d&eacute;j&agrave; en cours d'utilisation.",
	    'openid_client:missing_name_error'              => "Vous devez saisir un nom.",
	    'openid_client:invalid_email_error'             => "Vous devez saisir une adresse mail valide.",
	    'openid_client:invalid_code_error'              => "Votre code de validation semble être invalide. Ce code reste valide seulement pour les 7 derniers jours;"
	        ." il est possible que le v&ocirc;tre soit plus vieux.",
	    'openid_client:user_creation_failed'            => "Impossible de cr&eacute;er le compte OpenID.",
	    'openid_client:created_openid_account'          => "Comptes OpenID cr&eacute;&eacute;s, mail tranfer&eacute;s %s et nom %s du serveur OpenID.",
	    'openid_client:name_updated'                    => "Votre nom a &eacute;t&eacute; modifi&eacute; en %s.",
	    'openid_client:missing_confirmation_code'       => "Votre code de confirmation semble &ecirc;tre manquant. Merci de v&eacute;rifier votre lien et essayez de nouveau.",
	    'openid_client:at_least_13'                     => "Vous devez indiquer que vous avez au moins 13 ans afin d'acceder &agrave;.",
	    'openid_client:account_created'                 => "Votre compte a &eacute;t&eacute; cr&eacute;&eacute;! Vous pouvez maintenant vous connecter en utilisant l'OpenID (%s) que vous avez fourni.",
	    'openid_client:email_changed'                   => "Votre adressse mail a &eacute;t&eacute; modifi&eacute;e en {%s} . "
		    ."Vous pouvez maintenant vous connecter en utilisant votre OpenID si vous n'&ecirc;tes pas d&eacute;j&agrave; connect&eacute;.",
		'openid_client:thankyou'                        => "Merci de vous &ecirc;tre inscrit pour un compte avec %s!"
	        ." L'inscription est entierement gratuite, mais avant de confirmer vos informations,"
	        ." merci de prendre un moment pour lire les documents suivants:",
	    'openid_client:terms'                           => "Termes et conditions",
	    'openid_client:privacy'                         => "Politique de confidentialit&eacute;",
	    'openid_client:acceptance'                      => "Soumettre le formulaire ci-dessous indique l'acceptation de ces termes. "
	        ."Merci de noter qu'&agrave; l'heure actuelle, vous devez &ecirc;tre &acirc;g&eacute; d'au moins de 13 ans pour rejoindre le site.",
	    'openid_client:correct_age'                     => "J'ai au moins treize ans.",
	    'openid_client:join_button_label'               => "Rejoindre",
	    'openid_client:confirmation_title'              => "Confirmation OpenID",
	    'openid_client:admin_title'                     => "Configuration Client OpenID",
	    'openid_client:default_server_title'             => "Serveur par d&eacute;faut",
	    'openid_client:default_server_instructions1'     => "Vous pouvez simplifier la connexion ou l'utilisation de OpenID en sp&eacute;cifiant un serveur OpenID par d&eacute;faut."
            ." Les utilisateurs qui entrent un simple nom de compte (par exemple \"susan\") au cours d'une connexion OpenID pourront avoir un OpenID complet"
	        ." 	si vous fournissez un serveur par d&eacute;faut ici. Mettez \"%s \" o&ugrave; vous souhaitez ajouter le nom du compte. Par exemple, tapez"
	        ." \"http://openidserver.com/%s/\" si vous voulez que l'OpenID devienne \"http://openidserver.com/susan/\" ou"
	        ." \"http://%s.openidserver.com/\" si vous voulez que l'OpenID devienne \"http://susan.openidserver.com/\"",
	    'openid_client:default_server_instructions2'    => "La présence de points (\". \") est utilis&eacute;e pour distinguer l'url OpenID d'une simple URL "
	        ." de nom de compte, de sorte que vous ne puissiez utiliser cette fonctionnalit&eacute; par d&eacute;faut pour les serveurs qui n'acceptent pas de points dans les noms de compte simple.",
	    'openid_client:server_sync_title'               => "Synchronisation de server ",
	    'openid_client:server_sync_instructions'        => "Cochez cette case si vous souhaitez mettre &agrave; jour automatiquement ce site si un"
	        ." utilisateur se connecte et que son adresse email ou son nom est diff&eacute;rent de celui sur leur serveur OpenID. Laissez cette case non-coch&eacute;e"
	        ." si vous souhaitez permettre &agrave; vos utilisateurs d'avoir un autre nom ou adresse mail sur ce syst&egrave;me",
	    'openid_client:server_sync_label'               => "Mise à jour automatique du serveur OpenID.",
	    'openid_client:lists_title'                     => "Listes OpenID",
	    'openid_client:lists_instruction1'              => "Vous pouvez indiquer une liste verte, jaune ou rouge des OpenIDs que ce module va accepter.",
	    'openid_client:lists_instruction2'              => "La liste verte contient les OpenIDs qui seront accept&eacute;s pour l'identification"
	        ." et qui peuvent fournir une adresse mail de confiance.",
	    'openid_client:lists_instruction3'              => "La liste jaune contient les OpenIDs qui seront accept&eacute;s pour l'identification seulement."
	        ." S'ils fournissent une adresse mail, un message sera envoy&eacute; &agrave; cette adresse pour confirmation avant enregistrement.",
	    'openid_client:lists_instruction4'              => "La liste rouge conteint les OpenIDs qui seront rejet&eacute;s.",
	    'openid_client:lists_instruction5'              => "Si vous ne fournissez pas de liste verte, jaune ou rouge, par d&eacute;faut, tous les OpenIDs"
	        ." obtiendront un statut vert (ils seront accept&eacute;s pour l'identification et les adresses mail seront"
	        ." accept&eacute;es sans confirmation).",
	    'openid_client:lists_instruction6'              => "Entrez un OpenID par ligne. Vous pouvez utiliser \"*\" comme caract&egrave;re sp&eacute;cial"
	        ." pour faire correspondre un certain nombre d'OpenIDs ou de serveurs OpenID. Chaque OpenID doit commencer par http:// ou https:// et se terminer par un"
	        ." slash (\"/\") - par exemple http://*.myopenid.com/",
	    'openid_client:green_list_title'                => "Liste verte",
	    'openid_client:yellow_list_title'               => "Liste jaune",
	    'openid_client:red_list_title'                  => "Liste rouge",
	    'openid_client:ok_button_label'                 => "OK",
	    'openid_client:admin_response'                  => "Configuration OpenID sauvegard&eacute;e."
	    
	);
					
	add_translation("fr",$french);

?>