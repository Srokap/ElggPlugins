<?PHP

	/**
	 * User Contact List - Plugin
	 * 
	 * @package User Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michael T Jones
	 * @copyright Michael T Jones 2008
	 * @link http://www.facebake.com/
	 */

global $CONFIG;

admin_gatekeeper();

$query = "SELECT name, username, email FROM {$CONFIG->dbprefix}users_entity"; 
$result = get_data($query);

//Page Navigation
{
	$user_per_page = 30;  //users diplayed per page
	
	$total_users = count($result);
	echo "<br /><b>".elgg_echo("userclist:totalpages")."</b> ".$total_users."<br /><br />";
	$page = get_input("page");
	if($page=="")
		$page = 1;
	$total_pages = ceil(floatval($total_users)/floatval($user_per_page));
	if($page > 1)
		echo "<a href=\"".$vars['url']."pg/user_contact_list/page/".($page - 1)."\">".elgg_echo("userclist:lastpage")."</a>";
	echo " | ".elgg_echo("userclist:onpage1")." ".$page." ".elgg_echo("userclist:onpage2")." ".$total_pages." ".elgg_echo("userclist:onpage3")." | ";
	if(($total_pages - $page) > 0)
		echo "<a href=\"".$vars['url']."pg/user_contact_list/page/".($page + 1)."\">".elgg_echo("userclist:nextpage")."</a>";
	echo "<br />";
}

echo "<table class=\"uv_list\"><tr><td><b>Nickname</b></td><td><b>Username</b></td><td><b>Email</b></td></tr>";

$offset = ($page-1)*$user_per_page;

for($i=$offset;$i<$offset+$user_per_page;$i++)
{
	$row = $result[$i];
	echo "<tr>";
	echo "<td><a href=\"{$CONFIG->wwwroot}pg/profile/{$row->username}\">".$row->name."</a></td>";
	echo "<td>".$row->username."</td>";
	echo "<td>".$row->email."</td>";
	echo "</tr>";
}

echo "</table>";


?>