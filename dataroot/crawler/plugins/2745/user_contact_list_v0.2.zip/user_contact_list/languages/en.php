<?php
	/**
	 * User Contact List - Plugin
	 * 
	 * @package User Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michael T Jones
	 * @copyright Michael T Jones 2008
	 * @link http://www.facebake.com/
	 */

$english = array(
		'userclist:title' => 'User Contact List',
		'userclist:lastpage' => '<< Last Page',
		'userclist:nextpage' => 'Next Page >>',
		'userclist:totalpages' => 'Total Users:',
		'userclist:onpage1' => 'displaying page',
		'userclist:onpage2' => 'of',
		'userclist:onpage3' => 'total pages',
		);

add_translation("en",$english);
?>