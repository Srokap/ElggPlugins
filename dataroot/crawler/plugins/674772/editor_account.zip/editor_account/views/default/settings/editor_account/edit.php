<?php

$editor_name = $vars['entity']->editor_name;
	
?>

<p>
<?php 

echo elgg_echo('editor_account:param_label'); 

echo elgg_view('input/text',array('internalname' => 'params[editor_name]','value' => $editor_name));

?>
</p>
