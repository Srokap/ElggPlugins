<?php

$english = array(

	'editor_account:param_label'	=> 'Enter the username of the account you want to be the editor\'s account.',
	'editor_account:info'			=> '<span style="color:red;">This user account is for site administration.</span>',

);

add_translation("en", $english);

?>