<?php

$danish = array(

	'editor_account:param_label'	=> 'Indtast brugernavnet på den konto, du ønsker skal være redaktør konto.',
	'editor_account:info'			=> '<span style="color:red;">Denne brugerkonto er til administration af webstedet.</span>',
	
);

add_translation("da",$danish);

?>