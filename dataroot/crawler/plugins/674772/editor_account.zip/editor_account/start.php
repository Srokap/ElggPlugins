<?php
/**
 * editor_account
 *
 * @author Per Jensen
 */

function editor_account_init() {
	global $CONFIG;

	register_page_handler('profile', 'editor_account_page_handler');
			
}

function editor_account_page_handler($page) {

	global $CONFIG;

	$editor_name = get_plugin_setting('editor_name', 'editor_account');	

	// The username should be the file we're getting
	if (isset($page[0])) {
		set_input('username',$page[0]);
	}
	// Any sub pages?
	if (isset($page[1])) {

		switch ($page[1])
		{
			case 'edit' : include($CONFIG->pluginspath . "profile/edit.php"); break;
			case 'editicon' : include($CONFIG->pluginspath . "profile/editicon.php"); break;

		}
	}
	else
	{
		$username = get_input('username');
		$user = get_user_by_username($username);
		
		if ($user->username == $editor_name) {
			forward(REFERER);
		} else {
		// Include the standard profile index
		include($CONFIG->pluginspath . "profile/index.php");
		}
	}

}	
register_elgg_event_handler('init', 'system', 'editor_account_init');
