Warning:

Add the line
trigger_plugin_hook('access', 'group', array('group' => $group));

in file elgg_root_dir/mod/groups/actions/edit.php after the line 100 with the contents

$group->save();

This is part of the solution for the problem of viewing permission for groups not yet approved.

If you use previous versions (1.0, 1.0.1 or 1.0.2) or have groups created in your site before the installation of the plugin groupaccess, then execute the script http://your.elgg.com/mod/groupaccess/migrate.php



Bug fix:
version 1.0.2
Permission of visualization of groups when they are waiting to be activated.
Version 1.2.0
Parameter wrong in calling the function test.
Version 1.2.2
Enable moderation on the first time that the plugin is installed.

Changes:
Version 1.1.0
Logic forces admin to notify user before deleting a group.
Better design.
Version 1.2.0
The script migrate.php handles all groups created before the installation of the plugin groupaccess or groups of previous versions.