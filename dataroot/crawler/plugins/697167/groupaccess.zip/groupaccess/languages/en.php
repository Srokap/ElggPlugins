<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

$english = array(
                'groupaccess:title' => 'Group Access',
                'groupaccess:admin:groupname:error' => 'Group name already exists',
                'groupaccess:admin:groupname' => 'Group Name',
                'groupaccess:admin:groupdescription' => 'Group Description',
                'groupaccess:admin:groupownerusername' => 'Group Owner Username',
                'groupaccess:admin:groupownername' => 'Group Owner Name',
                'groupaccess:admin:groupdate' => 'Group Created On',
		'groupaccess:admin:links' => 'Activate',
		'groupaccess:admin:menu' => 'Group Access Menu',
                'groupaccess:waitmoderate' => 'This group is waiting to be accepted by a moderator. It is currently available only for you.',
		'groupaccess:admin:group_created:success' => 'Group was successfully created! Wait admin activate.',
		'groupaccess:admin:group_created:error' => 'Failed to create group',
                'groupaccess:admin:notify_user:error' => 'Failed to notify user',
                'groupaccess:admin:group_delete:error' => 'Failed to delete group',
                'groupaccess:admin:group_disable:error' => 'Failed to disable group',
                'groupaccess:admin:group_activated' => 'Group has activated',
                'groupaccess:admin:group_deleted' => 'Group has deleted',
                'groupaccess:admin:group_disable' => 'Group has disabled',
                'groupaccess:list:group_templates' => 'Email Templates',
		'groupaccess:list:group_created' => 'Groups waiting activation',
		'groupaccess:list:group_activated' => 'Groups activated',
                'groupaccess:list:group_disabled' => 'Groups disabled',
                'groupaccess:email:default' => 'Revert to Default',
                'groupaccess:email:valid:macros' => 'Possible Email Macros',
                'groupaccess:email:disable:success' => 'Email reverted successfully!',
                'groupaccess:email:disable:fail' => 'Failed to revert email!',
                'groupaccess:email:update:success' => 'Email updated successfully!',
                'groupaccess:email:update:fail' => 'Failed to update email!',
                'groupaccess:email:label:subject' => 'Subject:',
                'groupaccess:email:label:content' => 'Content:',
                'groupaccess:email:label:notify_admin' => 'Notify Admin Email',
                'groupaccess:email:label:notify_create' => 'Notify user Group Created email',
                'groupaccess:email:label:notify_activate' => 'Notify user Group Activated email',
                'groupaccess:email:label:notify_disable' => 'Notify user Group Disabled email',
                'groupaccess:notify_disable:subject' => '[%site_name%] Your group  %groupname% was disabled.',
                'groupaccess:notify_disable:content' => 'Hi %name%,
                    
Your group "%groupname%" was disabled by administrator as inappropriate. Contact the administrator to more information.',
		'groupaccess:email:notify_admin:subject' => '[%site_name%] Admin groups waiting to be activated %username%!',
                'groupaccess:email:notify_admin:content' => 'Hi %name%,

You have groups in your queue waiting to be activated.

%admin_url%',
		'groupaccess:email:notify_create:subject' => '[%site_name%] %username% ,please, wait group %groupname% activation!',
                'groupaccess:email:notify_create:content' => 'Hi %name%,

Please, wait group "%groupname%" activation.
This site requires that the Administrator authorizes your group!

',
                'groupaccess:email:notify_activate:subject' => '[%site_name%] Your group %groupname% was activated %username%!',
                'groupaccess:email:notify_activate:content' => 'Hi %name%,

Congratulations, you have successfully activated your group "%groupname%".

%site_url%',
		'groupaccess:authorize' => 'This site requires that the Administrator authorizes your group!',
                
		'groupaccess:notify' => 'Enter username to notify of new groups in the activation queue?',
		'groupaccess:hourly' => 'hourly',
		'groupaccess:daily' => 'daily',
		'groupaccess:weekly' => 'weekly',
		'groupaccess:monthly' => 'monthly',
                'groupaccess:river:groupcreate' => '%s created group %s',
		'groupaccess:useriver' => 'Send "Group Created Events" to River Dashboard?',
		'groupaccess:moderateoncreate'  =>  "Moderate group when they are created: " ,
                'groupaccess:notify:options' => 'Notification Options',
                'groupaccess:group_created:found' => 'Groups created found',
                'groupaccess:group_activated:found' => 'Groups activated found',
                'groupaccess:group_disabled:found' => 'Groups disabled found',
		'groupaccess:reg:options' => 'Create Group Options',
                'Disable' => 'Disable',

);

add_translation("en",$english);
?>