<?php
// Generate By translationbrowser. 

$portugues_brasileiro = array( 
	 'groupaccess:title'  =>  "Acesso dos Grupos" , 
	 'groupaccess:admin:groupname:error'  =>  "Nome do grupo já existe" , 
	 'groupaccess:admin:groupname'  =>  "Nome do grupo" , 
	 'groupaccess:admin:groupdescription'  =>  "Descrição do grupo" , 
	 'groupaccess:admin:groupownerusername'  =>  "Nome de usuário do proprietário do grupo" , 
	 'groupaccess:admin:groupownername'  =>  "Nome do proprietário do grupo" , 
	 'groupaccess:admin:groupdate'  =>  "Grupo criado em" , 
	 'groupaccess:admin:links'  =>  "Ativado" , 
	 'groupaccess:admin:menu'  =>  "Menu de acesso ao grupo" ,
	 'groupaccess:waitmoderate'  =>  "Este grupo está aguardando aprovação por um administrador. Por enquanto ele está disponível apenas para você." , 
	 'groupaccess:admin:group_created:success'  =>  "Grupo criado com sucesso! Aguarde a ativação por um administrador." , 
	 'groupaccess:admin:group_created:error'  =>  "O grupo não pôde ser criado" , 
	 'groupaccess:admin:notify_user:error'  =>  "Erro ao notificar usuário" , 
	 'groupaccess:admin:group_disable:error'  =>  "Erro ao desabilitar grupo" , 
	 'groupaccess:admin:group_delete:error'  =>  "O grupo não pôde ser apagado" , 
	 'groupaccess:admin:group_disable'  =>  "Grupo foi desabilitado" , 
	 'groupaccess:admin:group_activated'  =>  "Grupo ativado com sucesso" , 
	 'groupaccess:admin:group_deleted'  =>  "Grupo apagado com sucesso" , 
	 'groupaccess:list:group_templates'  =>  "Padrões de Email" , 
	 'groupaccess:list:group_created'  =>  "Grupos aguardando ativação" , 
	 'groupaccess:list:group_activated'  =>  "Grupos ativados" , 
	 'groupaccess:list:group_disabled'  =>  "Grupos desativados" , 
	 'groupaccess:email:default'  =>  "Reverter para configurações padrão" , 
	 'groupaccess:email:valid:macros'  =>  "Possíveis macros de email" , 
	 'groupaccess:email:disable:success'  =>  "Email revertido com sucesso!" ,
	 'groupaccess:email:disable:fail'  =>  "O email não pôde ser revertido!" ,
	 'groupaccess:email:update:success'  =>  "Email atualizado com sucesso!" , 
	 'groupaccess:email:update:fail'  =>  "O email não pôde ser atualizado!" , 
	 'groupaccess:email:label:subject'  =>  "Assunto:" , 
	 'groupaccess:email:label:content'  =>  "Conteúdo:" , 
	 'groupaccess:email:label:notify_admin'  =>  "Email de notificação ao administrador" , 
	 'groupaccess:email:label:notify_create'  =>  "Email de notificação ao usuário sobre grupo criado" , 
	 'groupaccess:email:label:notify_activate'  =>  "Email de notificação ao usuário sobre grupo ativado" , 
	 'groupaccess:email:label:notify_disable'  =>  "Email de notificação ao usuário sobre grupo apagado" , 
	 'groupaccess:notify_disable:subject'  =>  '[%site_name%] Seu grupo %groupname% foi desativado.' ,
	 'groupaccess:notify_disable:content'  =>  'Olá %name%,

Seu grupo "%groupname%" foi desativado por um administrador por ter sido considerado inapropriado. Entre em contato com o administrador.' ,
	 'groupaccess:email:notify_admin:subject'  =>  "[%site_name%] Grupos aguardando para serem ativados %username%!" , 
	 'groupaccess:email:notify_admin:content'  =>  "Olá %name%,

Há grupos aguardando sua aprovação para serem ativados.

%admin_url%" , 
	 'groupaccess:email:notify_create:subject'  =>  '[%site_name%] %username% ,por favor, aguarde a ativação do grupo %groupname%!' ,
	 'groupaccess:email:notify_create:content'  =>  'Olá %name%,

Por favor, aguarde a ativação do grupo "%groupname%".
Esta comunidade necessita que o administrador autorize seu grupo!

' ,
	 'groupaccess:email:notify_activate:subject'  =>  '[%site_name%] Seu grupo %groupname% foi ativado %username%!' ,
	 'groupaccess:email:notify_activate:content'  =>  'Olá %name%,

Parabéns, seu grupo "%groupname%" foi ativado com sucesso.

%site_url%' ,
	 'groupaccess:authorize'  =>  "Esta comunidade necessita que o administrador autorize seu grupo!" , 

    'groupaccess:notify'  =>  "Digitar o nome de usuário a ser notificado sobre novos grupos na lista de ativação?" ,
	 'groupaccess:hourly'  =>  "de hora em hora" , 
	 'groupaccess:daily'  =>  "diariamente" , 
	 'groupaccess:weekly'  =>  "semanalmente" , 
	 'groupaccess:monthly'  =>  "mensalmente" , 
	 'groupaccess:river:groupcreate'  =>  "%s criou o grupo %s" , 
	 'groupaccess:useriver'  =>  "Enviar eventos sobre criação de grupos para o Mural?" , 
	 'groupaccess:moderateoncreate'  =>  "Moderar grupos quando criados: " ,
	 'groupaccess:notify:options'  =>  "Opções de Notificação" , 
	 'groupaccess:group_created:found'  =>  "Grupos criados encontrados" , 
	 'groupaccess:group_activated:found'  =>  "Grupos ativados encontrados" , 
	 'groupaccess:group_disabled:found'  =>  "Grupos desativados encontrados" , 
	 'groupaccess:reg:options'  =>  "Opções de criação de grupo",
         'Disable' => 'Desativar',
    
); 

add_translation('pt_br', $portugues_brasileiro); 

?>