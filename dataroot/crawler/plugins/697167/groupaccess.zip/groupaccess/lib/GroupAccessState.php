<?php

define('GROUP_STATE', 'group_state');
define('GROUP_CREATED', 'group_created');
define('GROUP_ACTIVATED', 'group_activated');
define('GROUP_DESACTIVATED', 'group_desactivated');
define('GROUP_VISIBILITY', 'group_visibility');

/**
 * The IGroupAccessState interface allows to model te state of a group.
 *
 * @author leofdecarvalho
 */
interface IGroupAccessState {

    /**
    * @return a group
    */
    function getGroup();

    /**
    * @return the current access(private, public, connected users or members) of a group
    */
    function getCurrentAccess();

    /**
    * update the access(private, public, connected users or members) of a group
    */
    function updateAccess();

    /**
    * @return the state (created, activated or desactivated) of a group
    */
    function getState();

    /**
    * @return a bool - true if a group is in state activated or false otherwise
    */
    function isAccepted();

}

/**
 * Implements IGroupAccessState
 *
 * @author leofdecarvalho
 */
abstract class GroupAccessState  implements IGroupAccessState{

    protected $group;

    public function __construct($groupGuid) {

            $this->group = get_entity($groupGuid);
    }

    public function getGroup() {
        
        return $this->group;
    }

    public function getCurrentAccess() {
        return $this->group->access_id;
    }

    public static function getGroups($meta_name, $meta_value, $limit = 10, $offset = 0)
    {
        $access_status = access_get_show_hidden_status ();
        access_show_hidden_entities ( true );

        if(isset($meta_name) && isset($meta_value)) {

                $entities = elgg_get_entities_from_metadata(array('metadata_name' => $meta_name, 'metadata_value' => $meta_value, 'types' => 'group', 'subtypes' => '', 'owner_guid' => 0, 'limit' => $limit, 'offset' => $offset, 'count' => FALSE));

        }
        access_show_hidden_entities ( $access_status );
        return $entities;
    }

    public static function countGroups($meta_name, $meta_value)
    {
        $access_status = access_get_show_hidden_status ();
        access_show_hidden_entities ( true );

        if(isset($meta_name) && isset($meta_value))
        {
                $count = elgg_get_entities_from_metadata(array('metadata_name' => $meta_name, 'metadata_value' => $meta_value, 'types' => 'group', 'subtypes' => '', 'owner_guid' => 0, 'limit' => 0, 'offset' => 0, 'count' => TRUE));
        }

        access_show_hidden_entities ( $access_status );
        return $count;
    }
}

?>
