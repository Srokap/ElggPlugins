<?php

require_once("GroupAccessState.php");

/**
 * The Created interface allows a client put a group in the state of awaiting moderation.
 *
 * @author leofdecarvalho
 */
class Created extends GroupAccessState {

   public function  __construct($groupGuid) {

        parent::__construct($groupGuid);    
    }

    public function updateAccess() {

        create_metadata($this->group->guid, GROUP_STATE, GROUP_CREATED, '', 0, ACCESS_PUBLIC);

        create_metadata($this->group->guid, GROUP_VISIBILITY,  $this->group->access_id, '', 0, ACCESS_PUBLIC);
        $this->group->access_id = ACCESS_PRIVATE;
        
        $this->group->save();
    }

    public function getState() {
        
        return GROUP_CREATED;
    }

    public function isAccepted() {

        return false;
    }
}
?>
