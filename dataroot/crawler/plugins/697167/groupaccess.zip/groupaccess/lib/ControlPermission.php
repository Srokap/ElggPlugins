<?php

require_once("GroupAccessState.php");
require_once("Desactivated.php");
require_once("Activated.php");

/**
 * The ControlPermission allows change the groupaccess's state.
 *
 * @author leofdecarvalho
 */
class ControlPermission {

    private $groupAccess;

    public function  __construct($groupAccess) {
        
        $this->groupAccess = $groupAccess;
    }

    public function disable() {

        $state = $this->groupAccess->getState();
        if($state == GROUP_CREATED || $state == GROUP_ACTIVATED) {

            $this->groupAccess = new Desactivated($this->groupAccess->getGroup()->guid);
            $this->groupAccess->updateAccess();

            $group = $this->groupAccess->getGroup();

            $owner = $group->getOwnerEntity();
            $user = get_user_by_username($owner->username);

            $notification = new Notification($user, GROUP_DESACTIVATED, $group->name);
            $notification->userNotification();
            
            return true;

        } else
            return false;
    }

    public function accept() {

        $state = $this->groupAccess->getState();
        if($state== GROUP_CREATED || $state== GROUP_DESACTIVATED) {


            $this->groupAccess = new Activated($this->groupAccess->getGroup()->guid);
            $this->groupAccess->updateAccess();

            $group = $this->groupAccess->getGroup();

            $owner = $group->getOwnerEntity();
            $user = get_user_by_username($owner->username);

            $notification = new Notification($user, GROUP_ACTIVATED, $group->name);
            $notification->userNotification();

            return true;
            
        } else
            return false;
    }

    public function getCurrentState() {
        
        return $this->groupAccess;
    }
}
?>
