<?php

require_once("GroupAccessState.php");

/**
 * The  Activated interface allows a client to active a group.
 *
 * @author leofdecarvalho
 */
class Activated extends GroupAccessState {

    public function  __construct($groupGuid) {

        parent::__construct($groupGuid);
    }

    public function updateAccess() {

        create_metadata($this->group->guid, GROUP_STATE, GROUP_ACTIVATED, '', 0, ACCESS_PUBLIC);
        
        $access_metadata = get_metadata_byname($this->group->guid, GROUP_VISIBILITY);
        $this->group->access_id = $access_metadata->value;

        $this->group->save();
    }

    public function getState() {
        
        return GROUP_ACTIVATED;
    }

    public function isAccepted() {

        return true;
    }
}
?>
