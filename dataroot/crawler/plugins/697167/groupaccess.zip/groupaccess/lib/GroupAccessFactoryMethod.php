<?php

require_once("GroupAccessState.php");
require_once("Activated.php");
require_once("Desactivated.php");
require_once("Created.php");

/**
 * The GroupAccessFactoryMethod interface allows create GroupAccess instances.
 *
 * @author leofdecarvalho
 */
class GroupAccessFactoryMethod {


   static function makeGroupAcess($groupGuid) {

       $settings  = GroupAccessFactoryMethod::isEnableModeration();
       $state_metadata = get_metadata_byname($groupGuid,  GROUP_STATE);

       if ($settings) {
           switch ($state_metadata->value) {

              case GROUP_ACTIVATED:
                return new Activated($groupGuid);

              case GROUP_DESACTIVATED:
                return new Desactivated($groupGuid);

             default: //GROUP_CREATED
                return new Created($groupGuid);
           }
       } else {
            switch ($state_metadata->value) {

              case GROUP_DESACTIVATED:
                return new Desactivated($groupGuid);
              
             default:  //GROUP_ACTIVATED
                return new Activated($groupGuid);
           }
       }
   }

   public static function isEnableModeration() {

        $enabled = get_plugin_setting('moderate', 'groupaccess');
        return (!$enabled || $enabled == "yes") ? true : false;

   }

}
?>
