<?php

/**
 * The Notification interface allows to notify users with email.
 *
 * @author leofdecarvalho
 */
class Notification {

        private $user;
        private $type;
        private $groupname;

        public function  __construct($user, $type, $groupname = '') {

            $this->user = $user;
            $this->type = $type;
            $this->groupname = $groupname;
        }

        public function setAtributtes($user, $type, $groupname = '') {
            $this->user = $user;
            $this->type = $type;
            $this->groupname = $groupname;
        }
        
        public function userNotification()
        {
            global $CONFIG;
            if (($this->user) && ($this->user instanceof ElggUser))
            {
                if ($email = $this->get_email())
                {
                    $subject = $this->parser($email->title);
                    $content = $this->parser($email->description);
                    $result = notify_user(
                        $this->user->guid,
                        $CONFIG->site->guid,
                        $subject,
                        $content, NULL, 'email');
                    return $result;
                }
            }

            return false;
        }

        private function new_email($subject, $content)
        {
            $subject = sanitise_string($subject);

            if ($subject && $content)
            {
                $email = new ElggObject();
                $email->subtype = 'groupaccess_email';
                $email->owner_guid = $CONFIG->site->guid;
                $email->access_id = ACCESS_PUBLIC;
                $email->title = $subject;
                $email->description = $content;

                return $email;
            }

            return false;
        }

        public  function get_email()
        {
            $update = false;
            switch ($this->type) {

                case 'notify_admin':
                    $setting = 'notify_admin_email';
                    $email_guid = get_plugin_setting($setting, 'groupaccess');
                    $subject = elgg_echo('groupaccess:email:notify_admin:subject');
                    $content = elgg_echo('groupaccess:email:notify_admin:content');
                    break;
                case GROUP_CREATED:
                    $setting = 'notify_create_email';
                    $email_guid = get_plugin_setting($setting, 'groupaccess');
                    $subject = elgg_echo('groupaccess:email:notify_create:subject');
                    $content = elgg_echo('groupaccess:email:notify_create:content');
                    break;
                case GROUP_ACTIVATED:
                    $setting = 'notify_activate_email';
                    $email_guid = get_plugin_setting($setting, 'groupaccess');
                    $subject = elgg_echo('groupaccess:email:notify_activate:subject');
                    $content = elgg_echo('groupaccess:email:notify_activate:content');
                    break;
                case GROUP_DESACTIVATED:
                    $setting = 'notify_disable_email';
                    $email_guid = get_plugin_setting($setting, 'groupaccess');
                    $subject = elgg_echo('groupaccess:notify_disable:subject');
                    $content = elgg_echo('groupaccess:notify_disable:content');
                    break;
            }

            if ($email_guid)
            {
                $email = get_entity($email_guid);
                if (!$email)
                {
                    $update = true;
                    $email = $this->new_email($subject, $content);
                }
            } else if ($setting) { // if setting is set then a valid optino was selected create email

                $update = true;
                $email = $this->new_email($subject, $content);
            }

            if ($update && $email && isadminloggedin())
            {
                $email->save();
                set_plugin_setting($setting, $email->guid, 'groupaccess');
            }

            if ($email)
            {
                return $email;
            }

            return false;

        }

        private function generate_code($user_guid, $email_address)
        {
            global $CONFIG;
            //$date = date("W");
            return md5($user_guid . $email_address . $CONFIG->site->url . get_site_secret());
        }

        public function parser($str)
        {
            global $CONFIG;
            if (($this->user) && ($this->user instanceof ElggUser))
            {

                $confirm_url = $CONFIG->wwwroot . "pg/groupaccess/confirm?u=$this->user->guid&c=" . $this->generate_code($this->user->guid, $this->user->email);
                $admin_url = $CONFIG->wwwroot . 'pg/groupaccess/index';
                $patterns = array('/%site_name%/', '/%site_url%/', '/%username%/', '/%name%/', '/%confirm_url%/', '/%admin_url%/', '/%groupname%/');
                $replace = array($CONFIG->site->name, $CONFIG->site->url, $this->user->username, $this->user->name, $confirm_url, $admin_url, $this->groupname);

                return preg_replace($patterns, $replace, $str);
            }

            return false;
        }
}
?>
