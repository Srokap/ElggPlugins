<?php

require_once("GroupAccessState.php");

/**
 * The  Desactivated interface allows a client to desactive a group.
 *
 * @author leofdecarvalho
 */
class Desactivated extends GroupAccessState {

    public function  __construct($groupGuid) {

        parent::__construct($groupGuid);
    }

    public function updateAccess() {

        $access = get_metadata_byname($this->group->guid, GROUP_VISIBILITY);
        $this->group->access_id = $access->value;

        create_metadata($this->group->guid, GROUP_STATE, GROUP_DESACTIVATED, '', 0, ACCESS_PUBLIC);

        create_metadata($this->group->guid, GROUP_VISIBILITY,  $access->value, '', 0, ACCESS_PUBLIC);
        
        $this->group->access_id = ACCESS_PRIVATE;

        $this->group->save();
    }

    public function getState() {

        return GROUP_DESACTIVATED;
    }

    public function isAccepted() {

        return false;
    }
}
?>
