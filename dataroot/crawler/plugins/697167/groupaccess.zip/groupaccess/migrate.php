<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

global $CONFIG;
admin_gatekeeper();

$groups = elgg_get_entities(array('type' => 'group'));
foreach ($groups as $group) {
    $meta_created = get_metadata_byname($group->guid, 'group_created');
    $meta_activated = get_metadata_byname($group->guid, 'group_activated');
    $meta_disabled = get_metadata_byname($group->guid, 'group_disabled');
    $meta_state = get_metadata_byname($group->guid, GROUP_STATE);

    if (!$meta_created && !$meta_activated && !$meta_disabled && !$meta_state) {
        create_metadata($group->guid, GROUP_STATE, GROUP_ACTIVATED, '', 0, ACCESS_PUBLIC);
        create_metadata($group->guid, GROUP_VISIBILITY, $group->access_id, '', 0, ACCESS_PUBLIC);
        echo sprintf('update group: "%s" is active', $group->name). "</p>";
    }
}

$groups = GroupAccessState::getGroups('group_created', '');
foreach ($groups as $group) {
    create_metadata($group->guid, GROUP_STATE, GROUP_CREATED, '', 0, ACCESS_PUBLIC);
    create_metadata($group->guid, GROUP_VISIBILITY, $group->access_id, '', 0, ACCESS_PUBLIC );
    echo sprintf('update group: "%s" to state: "%s"', $group->name, GROUP_CREATED). "</p>";
}

$groups = GroupAccessState::getGroups('group_activated', '');
foreach ($groups as $group) {
    create_metadata($group->guid, GROUP_STATE, GROUP_ACTIVATED, '', 0,  ACCESS_PUBLIC);
    create_metadata($group->guid, GROUP_VISIBILITY, $group->access_id, '', 0,  ACCESS_PUBLIC );
    echo sprintf('update group: "%s" to state: "%s"', $group->name, GROUP_ACTIVATED). "</p>";
}

$groups = GroupAccessState::getGroups('group_disabled', '');
foreach ($groups as $group) {
    create_metadata($group->guid, GROUP_STATE, GROUP_DESACTIVATED, '', 0,  ACCESS_PUBLIC);
    create_metadata($group->guid, GROUP_VISIBILITY, $group->access_id, '', 0,  ACCESS_PUBLIC);
    echo sprintf('update group: "%s" to state: "%s"', $group->name, GROUP_DESACTIVATED). "</p>";
}

?>
