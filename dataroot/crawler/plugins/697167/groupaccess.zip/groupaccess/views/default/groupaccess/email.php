<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

    $ts = time();
    $token = generate_action_token($ts);

    $email = $vars['email'];
    $form = '';
    $form .= "<p>" . elgg_echo('groupaccess:email:label:subject') . "</p>";
    $form .= elgg_view('input/text', array('internalname' => 'subject', 'value' => $email->title));
    $form .= "<p>" . elgg_echo('groupaccess:email:label:content') . "</p>";
    $form .= elgg_view('groupaccess/input/longtext', array('internalname' => "content", 'value' => $email->description));

    $form .= elgg_view('input/hidden', array('internalname' => 'guid', 'value' => $email->guid));
    $form .= elgg_view('input/submit', array('internalname' => 'save', 'value' => elgg_echo('save')));
    $form .= " " . elgg_view('output/confirmlink', array('text' => elgg_echo('groupaccess:email:default'), 'href' => elgg_add_action_tokens_to_url($vars['url'] . 'action/groupaccess/deleteEmail?guid=' . $email->guid)));
    echo $form;
?>
