.groupaccess_entity {
    float:left;
}

.groupaccess_links {
    text-align:right;
    margin:0;
    padding:0px;
}
.waitingForModeration {
     background:#DD8888;
}
.groupaccess_feature {
    text-align:right;
    margin:0;
    padding:0px;
}

.groupaccess_links a {
    color:red;
    padding: 1px 5px;
    margin-right:20px;
}

.groupaccess_links a:hover {
    text-decoration:none;
    color:white !important;
    background:red !important;
}

.groupaccess .search_listing {
        border:2px solid #cccccc;
        margin:0 0 5px 0;
}
.groupaccess .search_listing:hover {
        background:#dedede;
}
.groupaccess .group_count {
        font-weight: bold;
        color: #666666;
        margin:0 0 5px 4px;
}
.groupaccess .search_listing_info {
        color:#666666;
}

.groupaccess .profile_status {
        -webkit-border-radius: 4px;
        -moz-border-radius: 4px;
        background:#bbdaf7;
        line-height:1.2em;
        padding:2px 4px;
}
.groupaccess .profile_status span {
        font-size:90%;
        color:#666666;
}
.groupaccess  p.owner_timestamp {
        padding-left:3px;
}
.groupaccess .pagination {
        border:2px solid #cccccc;
        margin:5px 0 5px 0;
}


.groupaccess .email_details {

}

.groupaccess_macros td {
    padding: 0 10px 0 0;
}

<?php
    global $CONFIG;

    $css = ".river_group_create {\n"
         . "background: url($CONFIG->url/mod/groupaccess/graphics/river_icons/river_group_create.gif) no-repeat left -1px;}\n"
         . "";

    echo $css;
?>
