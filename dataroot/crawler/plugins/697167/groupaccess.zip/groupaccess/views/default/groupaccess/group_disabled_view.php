<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

        $entity = $vars['entity'];

	$owner = get_entity($entity->owner_guid);

	$icon = elgg_view(
			"groups/icon", array(
									'entity' => $entity,
									'size' => 'small',
								  )
		);

	$info .= "<div class=\"contentWrapper\"><p>";
	$info .= "<b>".elgg_echo('groupaccess:admin:groupname')."</b>: ".$entity->name."<br/>";
	$info .= "<b>".elgg_echo('groupaccess:admin:groupdescription')."</b>: ".$entity->description."<br/>";
	$info .= "<b>".elgg_echo('groupaccess:admin:groupownerusername')."</b>: <a href='".$owner->getURL()."' />".$owner->username."</a><br/>";
	$info .= "<b>".elgg_echo('groupaccess:admin:groupownername')."</b>: ".$owner->name."<br/>";
	$info .= "<b>".elgg_echo('groupaccess:admin:groupdate')."</b>: ".friendly_time($entity->time_created)."<br/>";

        $info .= "<div class=\"groupaccess_links\">";

        $info .= elgg_view('output/confirmlink', array('text' => elgg_echo('active'), 'href' => elgg_add_action_tokens_to_url($vars['url'] . 'action/groupaccess/acceptGroup?guid=' . $vars['entity']->guid)));
        $info .= elgg_view('output/confirmlink', array('text' => elgg_echo('delete'), 'href' => elgg_add_action_tokens_to_url($vars['url'] . "action/groupaccess/deleteGroup?guid=" . $vars['entity']->guid))). "</div>";

	$info .= "</p></div>";

	echo elgg_view_listing($icon, $info);
?>
