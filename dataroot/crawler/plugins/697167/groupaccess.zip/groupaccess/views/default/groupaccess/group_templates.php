<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

    $notification = new Notification($_SESSION['user'], 'notify_admin');
    echo '<p><b>' . elgg_echo('groupaccess:email:valid:macros') . '</b><br />';
    echo '<table class="groupaccess_macros"><tr><td>%site_name%</td><td>' .  $notification->parser('%site_name%') . '</td></tr>';
    echo '<tr><td>%site_url%</td><td>' .$notification->parser('%site_url%')  . '</td></tr>';
    echo '<tr><td>%username%</td><td>' . 'admin or owner group username' . '</td></tr>';
    echo '<tr><td>%name%</td><td>' . 'admin or owner group name' . '</td></tr>';
    echo '<tr><td>%groupname%</td><td>' . 'group name' . '</td></tr>';
    echo '<tr><td>%admin_url%</td><td>' . $notification->parser('%admin_url%') . '</td></tr>';
    echo '</table></p>';
?>
<hr />
<div class="email_details"> 
<p><a class="collapsibleboxlink">[<?php echo elgg_echo('groupaccess:email:label:notify_admin'); ?>]</a></p>
<div class="collapsible_box">
    <?php 
        $email = $notification->get_email();
        $form_body = elgg_view('groupaccess/email', array('email' => $email));
        echo elgg_view('input/form', array('action' => "{$vars['url']}action/groupaccess/saveEmail", 'body' => $form_body));
    ?>    
</div>
</div>

<div class="email_details">
<p><a class="collapsibleboxlink">[<?php echo elgg_echo('groupaccess:email:label:notify_create'); ?>]</a></p>
<div class="collapsible_box">
    <?php
        $notification->setAtributtes($_SESSION['user'], GROUP_CREATED);
        $email = $notification->get_email();
        $form_body = elgg_view('groupaccess/email', array('email' => $email));
        echo elgg_view('input/form', array('action' => "{$vars['url']}action/groupaccess/saveEmail", 'body' => $form_body));
    ?>
</div>
</div>

<div class="email_details">
<p><a class="collapsibleboxlink">[<?php echo elgg_echo('groupaccess:email:label:notify_activate'); ?>]</a></p>
<div class="collapsible_box">
    <?php
        $notification->setAtributtes($_SESSION['user'], GROUP_ACTIVATED);
        $email = $notification->get_email();
        $form_body = elgg_view('groupaccess/email', array('email' => $email));
        echo elgg_view('input/form', array('action' => "{$vars['url']}action/groupaccess/saveEmail", 'body' => $form_body));
    ?>
</div>
</div>

<div class="email_details">
<p><a class="collapsibleboxlink">[<?php echo elgg_echo('groupaccess:email:label:notify_disable'); ?>]</a></p>
<div class="collapsible_box">
    <?php
        $notification->setAtributtes($_SESSION['user'], GROUP_DESACTIVATED);
        $email = $notification->get_email();
        $form_body = elgg_view('groupaccess/email', array('email' => $email));
        echo elgg_view('input/form', array('action' => "{$vars['url']}action/groupaccess/saveEmail", 'body' => $form_body));
    ?>
</div>
</div>
