<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

    $show = $vars['show'];
    $url = $vars['url'] . 'pg/groupaccess/';
    $count = $vars['count'];
    if (!$count)
        $count = 0;
        
?>
<div id="elgg_horizontal_tabbed_nav">
<ul>
    <li <?php if($show == 'group_created') echo "class = 'selected'"; ?>><a href="<?php echo $url; ?>group_created"><?php echo elgg_echo('groupaccess:list:group_created'); ?></a></li>
    <li <?php if($show == 'group_activated') echo "class = 'selected'"; ?>><a href="<?php echo $url; ?>group_activated"><?php echo elgg_echo('groupaccess:list:group_activated'); ?></a></li>
    <li <?php if($show == 'group_disabled') echo "class = 'selected'"; ?>><a href="<?php echo $url; ?>group_disabled"><?php echo elgg_echo('groupaccess:list:group_disabled'); ?></a></li>
    <li <?php if($show == 'group_templates') echo "class = 'selected'"; ?>><a href="<?php echo $url; ?>group_templates"><?php echo elgg_echo('groupaccess:list:group_templates'); ?></a></li>
</ul>
</div>

<div class="group_count"> 
    <?php if ($show == 'group_created') echo $count . " " . elgg_echo('groupaccess:group_created:found'); ?>
</div>
<div class="group_count">
    <?php if ($show == 'group_activated') echo $count . " " . elgg_echo('groupaccess:group_activated:found'); ?>
</div>
<div class="group_count">
    <?php if ($show == 'group_disabled') echo $count . " " . elgg_echo('groupaccess:group_disabled:found'); ?>
</div>