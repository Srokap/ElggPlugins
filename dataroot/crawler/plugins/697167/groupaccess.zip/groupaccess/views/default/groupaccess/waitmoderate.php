<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

        $group = $vars['entity'];
        $groupAccess = GroupAccessFactoryMethod::makeGroupAcess($group->guid);

 
        if (!$groupAccess->isAccepted()){ ?>
            <div class="contentWrapper waitingForModeration">
                <?php
                    echo elgg_echo('groupaccess:waitmoderate');
                ?>
            </div>
<?php } ?>