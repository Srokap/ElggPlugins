<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

    if ($vars['entity']) {
        $period = $vars['entity']->period;
        if (!$period) $period = 'weekly';

        if (!$vars['entity']->useriver) {
	    $vars['entity']->useriver = "yes";
        }

        if (!$vars['entity']->moderate) {
	    $vars['entity']->moderate = "yes";
        }
    }
?>

<b><?php echo elgg_echo('groupaccess:reg:options'); ?></b>
<p>
    <?php echo elgg_echo('groupaccess:useriver'); ?>
    <select name="params[useriver]">
        <option value="yes" <?php if ($vars['entity']->useriver != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
        <option value="no" <?php if ($vars['entity']->useriver == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
    </select>
</p>

<p>
    <?php echo elgg_echo('groupaccess:moderateoncreate'); ?>
    <select name="params[moderate]">
        <option value="yes" <?php if ($vars['entity']->moderate != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
        <option value="no" <?php if ($vars['entity']->moderate == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
    </select>
</p>

<hr />
<b><?php echo elgg_echo('groupaccess:notify:options'); ?></b>
<p>
    <?php
        echo elgg_echo('groupaccess:notify');
	echo elgg_view('input/pulldown', array(
                        'internalname' => 'params[period]',
                        'options_values' => array(
                                'hourly' => elgg_echo('hourly'),
                                'daily' => elgg_echo('daily'),
                                'weekly' => elgg_echo('weekly'),
				'monthly' => elgg_echo('monthly'),
                        ),
                        'value' => $period
                ));
        echo elgg_view('input/text', array('internalname' => "params[notify]", 'value' => $vars['entity']->notify));
    ?>
</p>
<hr /> 



