<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

        global $CONFIG;

        // block non-admin users
        admin_gatekeeper ();
        action_gatekeeper ();

        $guid = get_input ( 'guid' );
        $obj = get_entity ( $guid );

        if (($obj instanceof ElggGroup) && ($obj->canEdit ())) {

                $groupAccess = GroupAccessFactoryMethod::makeGroupAcess($obj->guid);
                $permission = new ControlPermission($groupAccess);
                $permission->disable();                
        } else {
            register_error ( elgg_echo ('groupaccess:admin:group_desactive:error') );
        }        

	forward ( $_SERVER ['HTTP_REFERER'] );

?>