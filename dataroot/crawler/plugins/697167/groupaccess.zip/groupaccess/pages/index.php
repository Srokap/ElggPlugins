<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/

	// include the Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

        admin_gatekeeper();
        set_context('admin');

        set_page_owner($_SESSION['guid']);

        $offset = get_input('offset');
        $limit = 10;
        $context = get_context();

        $show = get_input('show');

        switch($show) {
            case 'group_created':
                $meta_name = GROUP_STATE;
                $meta_value = GROUP_CREATED;
            break;
            case 'group_activated':
                $meta_name = GROUP_STATE;
                $meta_value = GROUP_ACTIVATED;
            break;
            case 'group_disabled':
                $meta_name = GROUP_STATE;
                $meta_value = GROUP_DESACTIVATED;
            break;

        }

	$title = elgg_view_title(elgg_echo('groupaccess:admin:menu'));

        $html = "";

        $count = GroupAccessState::countGroups($meta_name, $meta_value);
        $entities = GroupAccessState::getGroups($meta_name, $meta_value, $limit, $offset);
        $html .= elgg_view('groupaccess/menu', array('count' => $count, 'show' => $show));

        if ($show == 'group_templates') 
        {
            $html .= elgg_view('groupaccess/group_templates');
            
        } elseif ($show == 'group_created') {

            $html .= elgg_view('groupaccess/group_created_list',
                array(
                    'entities' => $entities,
                    'count' => $count,
                    'offset' => $offset,
                    'limit' => $limit,
                    'baseurl' => $_SERVER['REQUEST_URI'],
                    'context' => $context,
                    'pagination' => true,
                    ));
        } elseif ($show == 'group_activated') {

            $html .= elgg_view('groupaccess/group_activated_list',
                array(
                    'entities' => $entities,
                    'count' => $count,
                    'offset' => $offset,
                    'limit' => $limit,
                    'baseurl' => $_SERVER['REQUEST_URI'],
                    'context' => $context,
                    'pagination' => true,
                    ));
        } else { // $show == 'group_disabled'

            $html .= elgg_view('groupaccess/group_disabled_list',
                array(
                    'entities' => $entities,
                    'count' => $count,
                    'offset' => $offset,
                    'limit' => $limit,
                    'baseurl' => $_SERVER['REQUEST_URI'],
                    'context' => $context,
                    'pagination' => true,
                    ));
        }

        $body = elgg_view('page_elements/contentwrapper', array('body' => $html, 'subclass' => 'groupaccess'));

        page_draw(elgg_echo('Group Access Admin Menu'),elgg_view_layout("two_column_left_sidebar", '', $title . $body));
?>