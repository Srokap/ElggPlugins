<?php
/*******************************************************************************
 * groupaccess
 *
 * @author Leo de Carvalho
 ******************************************************************************/


        require_once(dirname(__FILE__) . "/lib/Activated.php");
        require_once(dirname(__FILE__) . "/lib/Created.php");
        require_once(dirname(__FILE__) . "/lib/Desactivated.php");
        require_once(dirname(__FILE__) . "/lib/ControlPermission.php");
        require_once(dirname(__FILE__) . "/lib/GroupAccessFactoryMethod.php");
        require_once(dirname(__FILE__) . "/lib/Notification.php");
        require_once(dirname(__FILE__) . "/lib/GroupAccessState.php");

	function groupaccess_init()
	{
		global $CONFIG;

		extend_view('css','groupaccess/css');
                extend_view('groups/groupprofile','groupaccess/waitmoderate', 1);

                register_page_handler('groupaccess','groupaccess_page_handler');

                $period = get_plugin_setting('period','groupaccess');
                switch ($period)
                {
                        case 'hourly':
                        case 'daily' :
                        case 'weekly' :
			case 'monthly' :
                        break;
                        default: $period = 'hourly';
                }
                
                register_plugin_hook('cron', $period, 'groupaccess_cron_hook');

		register_elgg_event_handler('pagesetup','system','groupaccess_submenus');

                if (isadminloggedin())
                {
                        register_action('groupaccess/featured', false, $CONFIG->pluginspath . "/groupaccess/actions/featured.php", true);
                        register_action('groupaccess/disableGroup', false, $CONFIG->pluginspath . "/groupaccess/actions/disableGroup.php", true);
                        register_action('groupaccess/acceptGroup', false, $CONFIG->pluginspath . "/groupaccess/actions/acceptGroup.php", true);
                        register_action('groupaccess/deleteGroup', false, $CONFIG->pluginspath . "/groupaccess/actions/deleteGroup.php", true);
                        register_action('groupaccess/saveEmail', false, $CONFIG->pluginspath . "/groupaccess/actions/saveEmail.php", true);
                        register_action('groupaccess/deleteEmail', false, $CONFIG->pluginspath . "/groupaccess/actions/deleteEmail.php", true);
                }

                register_elgg_event_handler('create','group','groupaccess_group_created_handler');

                register_plugin_hook('access', 'group', 'groupaccess_acces_hook');

            return true;
	}

	function groupaccess_page_handler($page)
	{

                global $CONFIG;

                if (isset($page[0]))
                {
                    set_input('show', $page[0]);
                }

                include($CONFIG->pluginspath . 'groupaccess/pages/index.php');
	}


	function groupaccess_submenus()
	{
		global $CONFIG;

		
		if (get_context() == 'admin'&& isadminloggedin())
		{
			add_submenu_item(elgg_echo('groupaccess:title'), $CONFIG->wwwroot . 'pg/groupaccess/group_created');
		}
		
	}

        function groupaccess_group_created_handler($event, $object_type, $object)
        {
                global $CONFIG;

                $settings  = GroupAccessFactoryMethod::isEnableModeration();

                if ($settings) {
                    $owner = $object->getOwnerEntity();
                    $user = get_user_by_username($owner->username);

                    $notification = new Notification($user, GROUP_CREATED, $object->name);
                    $notification->userNotification();
                }
	}

        //hook
        function groupaccess_acces_hook($hook_name, $entity_type, $return_value, $parameters) {

            global $CONFIG;
            $group = $parameters['group'];

            $groupAccess = GroupAccessFactoryMethod::makeGroupAcess($group->guid);
            $groupAccess->updateAccess();
        }

        function groupaccess_river_enabled()
        {
            $enabled = get_plugin_setting('useriver', 'groupaccess');
            return (!$enabled || $enabled == "yes") ? true : false;
        }

        function groupaccess_cron_hook($hook, $entity_type, $returnvalue, $params)
        {
            global $CONFIG;

            $username = get_plugin_setting('notify', 'groupaccess');
            if ($username)
            {
                $count = GroupAccessState::countGroups(GROUP_STATE, GROUP_CREATED);
                if ($count > 0)
                {
                    $user = get_user_by_username($username);
                    if ($user)
                    {
                        $notification = new Notification($user, 'notify_admin', $object->name);
                        $notification->userNotification();
                    }
                }
            }
        }

        function groupaccess_add_to_river($group, $type)
        {
            if (groupaccess_river_enabled())
            {
                $owner = $group->getOwnerEntity();
                $user = get_user_by_username($owner->username);

                switch ($type)
                {
                    case 'create':
                        add_to_river('river/group/create','create', $user->guid, $group->guid);
                        break;
                }
            }
        }

        register_elgg_event_handler('init', 'system', 'groupaccess_init');
?>