<?php
/**
 * Action for adding a wire post
 * 
 */

// Make sure we're logged in (send us to the front page if not)
if (!isloggedin()) {
	forward();
}

// Get input data
$body = get_input('body', '', false); // don't filter since we strip and filter escapes some characters
$access_id = ACCESS_PUBLIC;
$method = 'site';
$parent_guid = (int) get_input('parent_guid');

// make sure the post isn't blank
if (empty($body)) {
	register_error(elgg_echo("thewire:blank"));
	forward(REFERER);
}

$guid = thewire_save_post($body, get_loggedin_userid(), $access_id, $parent_guid, $method);
if (!$guid) {
	register_error(elgg_echo("thewire:error"));
	forward(REFERER);
}

// Send response to original poster if not already registered to receive notification
if ($parent_guid) {
	thewire_send_response_notification($guid, $parent_guid, $user);
}

system_message(elgg_echo("thewire:posted"));
forward(REFERER);
