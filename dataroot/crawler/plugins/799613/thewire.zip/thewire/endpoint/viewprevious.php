<?php
/**
 * Send back the parent wire post
 */

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

$guid = (int) get_input('guid');

$parent = thewire_get_parent($guid);
if ($parent) {
	echo elgg_view_entity($parent);
}
