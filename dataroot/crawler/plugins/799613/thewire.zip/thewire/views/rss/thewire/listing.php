<?php 
/**
 * RSS view for listing posts
 */

if (is_array($vars['posts'])) {
	foreach ($vars['posts'] as $post) {
		echo elgg_view_entity($post);
	}
}
