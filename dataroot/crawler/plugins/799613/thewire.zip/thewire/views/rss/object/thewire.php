<?php
/**
 * RSS view for a wire post
 */

$wire_post = $vars['entity'];
$author = get_entity($wire_post->owner_guid);

$description = $wire_post->description;
if ($wire_post->reply) {
	$parent = thewire_get_parent($wire_post->guid);
	if ($parent) {
		$parent_owner = $parent->getOwnerEntity();
		$reply_text = ucfirst(elgg_echo('thewire:inreplyto'));
		$description = "$reply_text $parent_owner->name: " . $description;
	}
}
?>
<item>
	<title><![CDATA[<?php echo sprintf(elgg_echo('thewire:post:title'), $author->name); ?>]]></title>
	<link><?php echo $wire_post->getURL(); ?></link>
	<description><![CDATA[<?php echo $description; ?>]]></description>
	<pubDate><?php echo date("r", $wire_post->time_created); ?></pubDate>
	<author><?php echo $author->email . " ($author->name)"; ?></author>
</item>
