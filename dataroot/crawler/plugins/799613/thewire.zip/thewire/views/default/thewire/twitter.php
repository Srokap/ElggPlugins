<?php
/**
 * Twitter sidebar box
 */
?>
<div class="sidebarBox">
	<div class="contentWrapper">
		<h3><?php echo elgg_echo('thewire:twitter:title'); ?></h3>
		<p>
			<small><?php echo elgg_echo('thewire:twitter:text'); ?></small>
		</p>
	</div>
</div>