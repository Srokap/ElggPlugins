<?php
/**
 * Wire river view
 */
$performed_by = get_entity($vars['item']->subject_guid);
$object = get_entity($vars['item']->object_guid);
$url = $object->getURL();

$text = elgg_echo('thewire:river:create');
$string = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a> $text";
if ($object->reply) {
	$parent = thewire_get_parent($object->guid);
	$parent_poster = $parent->getOwnerEntity();
	$text = elgg_echo('thewire:inreplyto');
	$string .= " $text <a href=\"{$parent_poster->getURL()}\">{$parent_poster->name}</a>";
}

$post_text = thewire_filter($object->description);
$string .= ': ' . $post_text;

$text = elgg_echo('thewire:river:reply');
$string .= " (<a href=\"{$vars['url']}pg/thewire/reply/$object->guid\" class=\"reply\">$text</a>)";

echo $string; 
