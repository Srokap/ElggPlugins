<?php
/**
 * Sidebar box of those a user is following
 */

$user = get_user($vars['user_guid']);
if (!$user) {
	return true;
}

?>
<div class="sidebarBox">
	<div class="contentWrapper">
		<h3><?php echo elgg_echo('thewire:following'); ?></h3>
<?php

// Get the user's friends
$following = $user->getFriends('', 8);
		
if (is_array($following) && count($following) > 0) {

	foreach($following as $person) {
		echo "<div class=\"wire_following_icon\" >";
		echo "<a href=\"{$vars['url']}pg/thewire/owner/{$person->username}\">";
		echo elgg_view("profile/icon", array(
			'entity' => get_user($person->guid),
			'size' => 'tiny',
			'override' => true,
		));
		echo "</a>";
		echo "</div>";
	}
}
?>
		<div class="clearfloat"></div>
	</div>
</div>