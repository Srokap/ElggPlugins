<?php
/**
 * List wire posts
 */
?>
<div class="thewire_container">
	<div id="thewire_new_posts"></div>
<?php 
	
$full_view = true;
if (isset($vars['full']) && $vars['full'] == false) {
	$full_view = false;
}

if (is_array($vars['posts'])) {
	foreach ($vars['posts'] as $post) {
		echo elgg_view_entity($post, $full_view);
	}

	// page type must be set for auto update and more
	if (isset($vars['page_type'])) {
		// do we include the more button
		if (count($vars['posts']) == 20) {
			$oldest_post = end($vars['posts']);
			echo '<div id="thewire_old_posts"></div>';
			echo '<a class="thewire_more" href="" >' . elgg_echo('thewire:more') . '</a>';
			echo elgg_view('thewire/js/morebutton', array(
				'oldest_guid' => $oldest_post->guid,
				'more_type' => $vars['page_type'],
				'more_param' => $vars['page_param'],
			));
		}

		// make sure jquery color is loaded in the html header
		elgg_extend_view('metatags', 'thewire/js/jquery-color');

		// include the autoupdate script
		echo elgg_view('thewire/js/autoupdate', array(
			'latest_guid' => thewire_latest_guid(),
			'update_type' => $vars['page_type'],
			'update_param' => $vars['page_param'],
		));

		// view previous script
		echo elgg_view('thewire/js/viewprevious');
	}
} else {
	echo elgg_echo('thewire:none');
}

?>
</div>