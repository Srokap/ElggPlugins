<?php
/**
 * All wire posts
 * 
 */

set_page_owner(get_loggedin_userid());

$sidebar = elgg_view("thewire/sidebar_links", array('all' => 'yes'));

$content = elgg_view_title(elgg_echo("thewire:everyone"));

$sidebar_ext = elgg_view("thewire/twitter");

// add form
if (isloggedin ()) {
	$content .= elgg_view("thewire/forms/add");
	$sidebar_ext .= elgg_view("thewire/following", array('user_guid' => get_loggedin_userid()));
}

$wire_posts = elgg_get_entities(array(
	'type' => 'object',
	'subtype' => 'thewire',
	'limit' => 20,
));
$content .= elgg_view('thewire/listing', array(
	'posts' => $wire_posts,
	'page_type' => 'world',
	'page_param' => 0,
));

$body = elgg_view_layout("sidebar_boxes", $sidebar, $content, $sidebar_ext);

page_draw(elgg_echo('thewire:everyone'), $body);
