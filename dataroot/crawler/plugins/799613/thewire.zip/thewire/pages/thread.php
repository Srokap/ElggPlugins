<?php
/**
 * View conversation thread
 */

$post_guid = get_input('wire_post');
if (!$post_guid) {
	forward('pg/thewire/');
}

set_page_owner(get_loggedin_userid());

$sidebar = elgg_view("thewire/sidebar_links", array('thread' => 'yes'));

$title = elgg_echo('thewire:conversation:title');
$content = elgg_view_title($title);

// limit to 30 posts right now
$post = get_entity($post_guid);
if ($post) {
	// compatible with posts created with original Curverider plugin
	$thread_id = $post->wire_thread;
	if (!$thread_id) {
		$post->wire_thread = $post->guid;
	}
	$discussion = elgg_get_entities_from_metadata(array(
		"metadata_name" => "wire_thread",
		"metadata_value" => $post->wire_thread,
		"type" => "object",
		"subtype" => "thewire",
		"limit" => 30,
	));
}

$content .= elgg_view('thewire/listing', array(
	'posts' => $discussion,
	'full' => false,
));

$sidebar_ext = elgg_view("thewire/twitter");

$body = elgg_view_layout("sidebar_boxes", $sidebar, $content, $sidebar_ext);

page_draw($title, $body);
