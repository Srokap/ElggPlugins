<?php
/**
 * Wire posts tagged with <tag>
 */

$tag = get_input('tag');
if (!$tag) {
	forward('pg/thewire');
}

// remove # from tag
$tag = trim($tag, '# ');

set_page_owner(get_loggedin_userid());

$sidebar = elgg_view("thewire/sidebar_links");

$title = sprintf(elgg_echo('thewire:tags'), $tag);
$content = elgg_view_title($title);

$sidebar_ext = elgg_view("thewire/twitter");

$wire_posts = elgg_get_entities_from_metadata(array(
	'metadata_name' => 'tags',
	'metadata_value' => $tag,
	'metadata_case_sensitive' => false,
	'type' => 'object',
	'subtype' => 'thewire',
	'limit' => 20,
));
$content .= elgg_view('thewire/listing', array(
	'posts' => $wire_posts,
	'page_type' => 'world',
	'page_param' => 0,
));

$body = elgg_view_layout("sidebar_boxes", $sidebar, $content, $sidebar_ext);

page_draw($title, $body);
