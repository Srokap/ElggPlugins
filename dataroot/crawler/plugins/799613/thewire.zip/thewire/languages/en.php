<?php
/**
 * English language file for the wire
 */

$english = array(
	/**
	 * Menu items and titles
	 */
	'thewire' => "The wire",
	'thewire:user:title' => "%s's wire posts",
	'thewire:yours:title' => "Your wire posts",
	'thewire:user' => "%s's posts",
	'thewire:yours' => "Your posts",
	'thewire:posttitle' => "%s's posts on the wire: %s",
	'thewire:everyone' => "The wire",
	'thewire:following:menu' => "Following posts",
	'thewire:following:title' => "Following wire posts",
	'thewire:following' => "Following",
	'thewire:readwire' => "Read the wire",
	'thewire:strapline' => "%s",
	'thewire:add' => "Post to the wire",
	'thewire:text' => "A post on the wire",
	'thewire:reply' => "Reply",
	'thewire:wired' => "Posted to the wire",
	'item:object:thewire' => "Wire posts",
	'thewire:postdeleted' => "post deleted",
	'thewire:doing' => "What are you working on? Tell everyone on the wire:",
	'thewire:newpost' => 'New wire post',
	'thewire:addpost' => 'Post to the wire',
	'thewire:latest' => 'Latest',
	'thewire:conversation_thread' => 'Conversation thread',
	'thewire:conversation:title' => 'Wire conversation',
	'thewire:post:title' => 'Wire post by %s',
	'thewire:tags' => 'Wire posts tagged with %s',

	'thewire:none' => 'No wire posts.',
	'thewire:more' => 'more',
	'thewire:nomore' => 'no more',
	'thewire:view:previous' => 'view previous',
	'thewire:hide:previous' => 'hide previous',
	'thewire:view:thread' => 'view thread',
	'thewire:delete' => 'delete',
	'thewire:reply:small' => 'reply',
	'thewire:method:site' => 'site',
	'thewire:inreplyto' => 'in reply to',
	'thewire:replying' => 'Replying to',
	'thewire:who_wrote' => 'who wrote',
	'thewire:via' => "via",
	'thewire:charleft' => "characters left",

	/**
	 * Sidebar
	 */
	'thewire:twitter:title' => 'What is the wire?',
	'thewire:twitter:text' => 'The wire is a microblogging platform (very similar to Twitter). Use it to keep people up-to-date on what you\'re working on, ask questions, and share important information.',

	/**
	 * Notifications
	 */
	'thewire:notify:subject' => 'New wire post',
	'thewire:notify:reply' => '%s responded to %s on the wire:',
	'thewire:notify:post' => '%s posted on the wire:',

	/**
	 * The wire river
	 */
	'thewire:river:created' => "%s posted",
	'thewire:river:create' => "on the wire",
	'thewire:river:reply' => 'Reply on wire',
	
	/**
	 * Wire widget
	 */
	'thewire:widget:desc' => 'Display the latest wire posts',
	'thewire:num' => 'Number of items to display',
	'thewire:widget:content_type' => 'All wire posts, your wire posts, or posts of people you\'re following',
	'thewire:widget:site' => 'All',
	'thewire:widget:following' => 'Following',
	'thewire:widget:mine' => 'Mine',
	'thewire:moreposts' => 'More wire posts',

	/**
	 * Status messages
	 */
	'thewire:posted' => "You successfully posted to the wire.",
	'thewire:deleted' => "Your wire post was successfully deleted.",
	
	/**
	 * Error messages
	 */
	'thewire:blank' => "Sorry; you need to actually put something in the textbox before we can save it.",
	'thewire:notfound' => "Sorry; we could not find the specified wire post.",
	'thewire:notdeleted' => "Sorry; we could not delete this wire post.",
);

add_translation("en", $english);
