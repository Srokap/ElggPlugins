
.notification_subjects_settings {
  border: 1px solid #cccccc;
}

.notification_subjects_settings td {
  padding: 4px 10px;
}

.notification_subjects_settings .notification_subjects_headings td{
  font-weight: bold;
}

.notification_subjects_settings tr.odd {
  background-color: #fcfcfc;
}

.notification_subjects_settings tr.even {
  background-color: #cccccc;
}