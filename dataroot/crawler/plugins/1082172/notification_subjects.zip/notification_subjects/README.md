Notification-Subjects
=====================

Makes the subjects of object notifications a little more descriptive

Plugin should reside in mod/notification_subjects