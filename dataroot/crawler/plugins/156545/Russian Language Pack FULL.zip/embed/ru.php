<?php

// Generate By translationbrowser. 

$russian = array( 
	 'media:insert'  =>  "Добавить медиа" , 
	 'embed:instructions'  =>  "Нажмите на любой файл для добавления." , 
	 'embed:media'  =>  "Вставить медиа" , 
	 'upload:media'  =>  "Загрузить медиа" , 
	 'embed:file:required'  =>  "Нет возможности загрузить файлы. Ваш администратор должен активировать файловый плагин."
); 

add_translation('ru', $russian); 

?>