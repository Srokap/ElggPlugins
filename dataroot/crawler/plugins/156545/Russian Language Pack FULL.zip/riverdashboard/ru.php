<?php

	$russian = array(
	
		'mine' => 'Я',
		'filter' => 'Фильтр',
		'riverdashboard:useasdashboard' => "Заменить Dashboard плагином River?",
		'activity' => 'Активность',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Сообщения сайта",
		'sitemessages:posted' => "написано",
		'sitemessages:river:created' => "Администратор, %s,",
		'sitemessages:river:create' => "написал(а) новое сообщение всему сайту",
		'sitemessages:add' => "Добавить сообщение всему сайту на страницу активности",
		'sitemessage:deleted' => "Сообщение сайта удалено.",
		
		'river:widget:noactivity' => 'Активность не обнаружена.',
		'river:widget:title' => "Активность",
		'river:widget:description' => "Показать последнюю активность",
		'river:widget:title:friends' => "Активность друзей",
		'river:widget:description:friends' => "Показать, что же там делали друзья",
		'river:widgets:friends' => "Друзья",
		'river:widgets:mine' => "Я",
		'river:widget:label:displaynum' => "Число записей для отображения:",
		'river:widget:type' => "Какую активность предпочитаете изучать? Вашу или Ваших друзей?",
		'item:object:sitemessage' => "Сообщения сайта",
	
	);
					
	add_translation("ru",$russian);

?>