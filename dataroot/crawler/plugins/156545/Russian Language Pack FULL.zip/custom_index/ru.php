<?php

$russian = array( 
	 'custom:bookmarks'  =>  "Новые закладки" , 
	 'custom:groups'  =>  "Новые группы" , 
	 'custom:files'  =>  "Новые файлы" , 
	 'custom:blogs'  =>  "Новые записи блогов" , 
	 'custom:members'  =>  "Новые пользователи" , 
	 'custom:nofiles'  =>  "Файлов пока нет" , 
	 'custom:nogroups'  =>  "Групп пока нет"
); 

add_translation('ru', $russian); 

?>