<?php

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Блог",
			'blogs' => "Блоги",
			'blog:user' => "Блог пользователя %s",
			'blog:user:friends' => "Блог друзей пользователя %s",
			'blog:your' => "Ваш блог",
			'blog:posttitle' => "Блог %s: %s",
			'blog:friends' => "Блоги друзей",
			'blog:yourfriends' => "Последние блоги Ваших друзей",
			'blog:everyone' => "Все блоги",
			'blog:newpost' => "Новая запись в блоге",
			'blog:via' => "через блог",
			'blog:read' => "Читать блог",
	
			'blog:addpost' => "Написать сообщение в блог",
			'blog:editpost' => "Редактировать сообщение",
	
			'blog:text' => "Текст блога",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Сообщения',
			
			'blog:never' => 'никогда',
			'blog:preview' => 'Предпросмотр',
	
			'blog:draft:save' => 'Сохранить черновик',
			'blog:draft:saved' => 'Последний сохраненный черновик',
			'blog:comments:allow' => 'Разрешить комментировать',
	
			'blog:preview:description' => 'Этот предпросмотр записи не сохранен.',
			'blog:preview:description:link' => 'Для продолжения редактирования или сохранения записи, нажмите здесь.',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s написал(а) ",
	        'blog:river:updated' => "%s обновил(а) ",
	        'blog:river:posted' => "%s написал(а) ",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "новое сообщение.",
	        'blog:river:update' => "блог.",
	        'blog:river:annotate:create' => "комментарий.",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Ваше сообщение размещено.",
			'blog:deleted' => "Ваше сообщение удалено.",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "Простите, сообщение не может быть размещено. Попробуйте снова.",
			'blog:blank' => "Простите, но Вы должны заполнить все поля.",
			'blog:notfound' => "Простите, по запросу ничего не найдено.",
			'blog:notdeleted' => "Простите, удаление невозможно.",
	
	);
					
	add_translation("ru",$russian);

?>