<?php
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Журнал логов',
			'logbrowser:browse' => 'Смотреть системные логи',
			'logbrowser:search' => 'Обновить',
			'logbrowser:user' => 'Поиск пользователя',
			'logbrowser:starttime' => 'Временной период (например, "прошлый понедельник", "1 час назад")',
			'logbrowser:endtime' => 'End time',
	
			'logbrowser:explore' => 'Просмотреть лог',
	
	);
					
	add_translation("ru",$russian);
?>