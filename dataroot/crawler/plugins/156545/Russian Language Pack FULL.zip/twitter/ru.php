<?php

$russian = array( 
	 'twitter:username'  =>  "Введите Ваше имя в Twitter." , 
	 'twitter:num'  =>  "Количество отображаемых записей" , 
	 'twitter:visit'  =>  "зайти в Twitter" , 
	 'twitter:notset'  =>  "Этот элемент необходимо настроить. Для этого нажмите на надпись 'Настроить'." , 
	 'twitter:river:created'  =>  "%s добавил(а) Twitter-элемент." , 
	 'twitter:river:updated'  =>  "%s обновил(а) Twitter-элемент." , 
	 'twitter:river:delete'  =>  "%s удалил(а) Twitter-элемент."
); 

add_translation('ru', $russian); 

?>