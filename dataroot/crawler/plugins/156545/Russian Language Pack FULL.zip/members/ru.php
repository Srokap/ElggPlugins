<?php

$russian = array( 
	'members:members'  =>  "Люди сайта" , 
	'members:online'  =>  "Онлайн" , 
	'members:active'  =>  "активно" , 
	'members:searchtag'  =>  "Поиск по интересам" , 
	'members:searchname'  =>  "Поиск по имени",
	'members:newest'  =>  "Новые лица" , 
	'members:popular'  =>  "Популярные" ,
	'members:go' => "Искать",
	'members:name' => "Имя",
	'members:tags' => "Тэги",
	 
); 

add_translation('ru', $russian); 

?>