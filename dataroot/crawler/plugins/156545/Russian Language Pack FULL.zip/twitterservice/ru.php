<?php

$russian = array( 
	 'twitterservice'  =>  "Сервис Twitter" , 
	 'twitterservice:postwire'  =>  "Вы хотите публиковать записи из своего Микроблога в Twitter?" , 
	 'twitterservice:twittername'  =>  "Ваше имя в Twitter" , 
	 'twitterservice:twitterpass'  =>  "Ваш пароль в Twitter"
); 

add_translation('ru', $russian); 

?>