<?php
/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "Документы",
			'pages:yours' => "Мои документы",
			'pages:user' => "Документы",
			'pages:group' => "%s's документы",
			'pages:all' => "Все документы сайта",
			'pages:new' => "Новый документ",
			'pages:groupprofile' => "Документы группы",
			'pages:edit' => "Редактировать этот документ",
			'pages:delete' => "Удалить этот документ",
			'pages:history' => "История документов",
			'pages:view' => "Просмотр документов",
			'pages:welcome' => "Редактировать приветственное сообщение",
			'pages:welcomeerror' => "Простите, произошла ошибка при сохранении приветственного сообщения.",
			'pages:welcomeposted' => "Ваше сообщение приветствия успешно опубликовано",
			'pages:navigation' => "Навигация по документам",
			'pages:via' => "через документы",
			'item:object:page_top' => 'Top-level pages',
			'item:object:page' => 'Страницы',
			'item:object:pages_welcome' => 'Вступление',
			'pages:nogroup' => 'У этой группы пока нет документов...',
			'pages:more' => 'Еще',
			
		/**
		* River
		**/
  
			'pages:river:annotate' => "комментарий на странице",
			'pages:river:created' => "%s написал(а)",
			'pages:river:updated' => "%s обновил()а",
			'pages:river:posted' => "%s создал(а)",
			'pages:river:create' => "новую страницу под названием",
			'pages:river:update' => "страницу под названием",
			'page:river:annotate' => "комментарий на странице",
			'page_top:river:annotate' => "комментарий на странице",
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'Заголовок документа',
			'pages:description' => 'Содержимое документа',
			'pages:tags' => 'Теги',	
			'pages:access_id' => 'Доступ',
			'pages:write_access_id' => 'Доступ на запись',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Нет доступа к документу.',
			'pages:cantedit' => 'Вы не можете редактировать этот документ.',
			'pages:saved' => 'Документ сохранен.',
			'pages:notsaved' => 'Документ не может быть сохранен.',
			'pages:notitle' => 'Вы должны указать название документа.',
			'pages:delete:success' => 'Ваш документ успешно удален.',
			'pages:delete:failure' => 'Этот документ не может быть удален.',
	
		/**
		 * Page
		 */
			'pages:strapline' => 'Последнее обновление %s от пользователя %s',
	
		/**
		 * History
		 */
			'pages:revision' => 'Версия создана %s пользователем %s',
			
		/**
		 * Widget
		 **/
		 
		    'pages:num' => 'Число отображаемых документов',
			'pages:widget:description' => "Это список Ваших документов.",
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Просмотр",
			'pages:label:edit' => "Редактировать",
			'pages:label:history' => "История",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Этот документ",
			'pages:sidebar:children' => "Дочерний документ",
			'pages:sidebar:parent' => "Создатель",
	
			'pages:newchild' => "Создать дочерний документ",
			'pages:backtoparent' => "Назад к '%s'",
	);
					
	add_translation("ru",$russian);
?>