<?php
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groups' => "Группы",
			'groups:owned' => "Ваши собственные группы",
			'groups:yours' => "Группы, в которых состоите",
			'groups:user' => "Группы %s",
			'groups:all' => "Все группы на сайте",
			'groups:new' => "Создать группу",
			'groups:edit' => "Редактировать группу",
			'groups:delete' => 'Удалить группу',
			'groups:membershiprequests' => 'Управление запросами приглашения',
	
			'groups:icon' => 'Иконка группы',
			'groups:name' => 'Название группы',
			'groups:username' => 'Краткое название группы',
			'groups:description' => 'Описание',
			'groups:briefdescription' => 'Краткое описание',
			'groups:interests' => 'Интересы',
			'groups:website' => 'Сайт',
			'groups:members' => 'Члены группы',
			'groups:membership' => "Ограничения в членстве",
			'groups:access' => "Доступ к группе",
			'groups:owner' => "Владелец",
	        'groups:widget:num_display' => 'Число отображаемых групп',
	        'groups:widget:membership' => 'Членство',
	        'groups:widgets:description' => 'Число отображаемых групп',
			'groups:noaccess' => 'Нет доступа к группе',
			'groups:cantedit' => 'Вы не можете редактировать эту группу',
			'groups:saved' => 'Сохранено',
			
			'groups:featured' => 'Избранные группы',
			'groups:makeunfeatured' => 'Убрать из избранного',
			'groups:makefeatured' => 'Добавить в избранные',
			'groups:featuredon' => 'Сделано.',
			'groups:unfeature' => 'Убрано.',
			'groups:viagroups' => "в группе",
						
			'groups:notfound' => "Группа не найдена",
			'groups:notfound:details' => "Запрашиваемая группа или не существует, или у Вас нет доступа к ней",
				
			'groups:joinrequest' => 'Попросить членство',
			'groups:join' => 'Вступить в группу',
			'groups:leave' => 'Покинуть группу',
			'groups:invite' => 'Пригласить в группу',
			'groups:inviteto' => "Пригласить в '%s'",
			'groups:nofriends' => "Все друзья приглашены.",
	
			'groups:group' => "Группа",
			
			'item:object:groupforumtopic' => "Темы форума",
			
			'groupforumtopic:new' => "Новое сообщение для обсуждения",
			
			'groups:count' => "групп создано",
			'groups:open' => "открытая группа",
			'groups:closed' => "закрытая группа",
			'groups:member' => "членов",
			'groups:searchtag' => "Поиск групп по тегам",
	
			/*
			 * Access
			 */
			'groups:access:private' => 'Закрыто - только по приглашениям',
			'groups:access:public' => 'Открыто - заходи, честной народ!',
			'groups:closedgroup' => 'В этой групп вход толкьо по приглашениям. Чтобы получить доступ, нажмите "Попросить членство" в ссылках меню.',
	
			/*
			   Group tools
			*/
			'groups:enablepages' => 'Включить страницы группы',
			'groups:enableforum' => 'Включить форум группы',
			'groups:enablefiles' => 'Включить файлы группы',
			'groups:yes' => 'да',
			'groups:no' => 'нет',
	
			'group:created' => 'Создано пользователем %s, %d сообщений',
			'groups:lastupdated' => 'Последнее обновление %s от %s',
			'groups:pages' => 'Страницы группы',
			'groups:files' => 'Файлы группы',
	
			/*
			  Group forum strings
			*/
			'group:replies' => 'Сообщений',
			'groups:forum' => 'Форум группы',
			'groups:addtopic' => 'Создать тему',
			'groups:forumlatest' => 'Последнее на форуме',
			'groups:latestdiscussion' => 'Последние дискуссии',
			'groups:newest' => 'Новые',
			'groups:popular' => 'Популярные',
			'groupspost:success' => 'Ваш комментарий успешно размещен.',
			'groups:alldiscussion' => 'Последние дискуссии',
			'groups:edittopic' => 'Редактировать тему',
			'groups:topicmessage' => 'Сообщение',
			'groups:topicstatus' => 'Статус темы',
			'groups:reply' => 'Комментировать',
			'groups:topic' => 'Тема',
			'groups:posts' => 'Ответы',
			'groups:lastperson' => 'Последний',
			'groups:when' => 'Когда',
			'grouptopic:notcreated' => 'Темы не созданы.',
			'groups:topicopen' => 'Открыта для обсуждения',
			'groups:topicclosed' => 'Закрыта для обсуждения',
			'groups:topicresolved' => 'Обсуждена',
			'grouptopic:created' => 'Ваша тема создана.',
			'groupstopic:deleted' => 'Ваша тема удалена.',
			'groups:topicsticky' => 'Требует нового обсуждения',
			'groups:topicisclosed' => 'Тема закрыта.',
			'groups:topiccloseddesc' => 'Тема закрыта.',
			'grouptopic:error' => 'Простите, тема не может быть создана. Попробуйте снова.',
			'groups:forumpost:edited' => "Сообщение успешно отредактировано.",
			'groups:forumpost:error' => "Простите, произошла ошибка при редактировании.",
			'groups:privategroup' => 'Это личная группа, для просмотра требуется членство.',
			'groups:notitle' => 'Группы должны иметь заглавие.',
			'groups:cantjoin' => 'Простите, невозможно вступить в группу.',
			'groups:cantleave' => 'Простите, невозможно покинуть группу.',
			'groups:addedtogroup' => 'Пользователь добавлен в группу.',
			'groups:joinrequestnotmade' => 'Простите, запрос не может быть осуществлен.',
			'groups:joinrequestmade' => 'Запрос осуществлен.',
			'groups:joined' => 'Вы вступили в группу.',
			'groups:left' => 'Вы покинули группу.',
			'groups:notowner' => 'Простите, но вы не вледелец этой группы.',
			'groups:alreadymember' => 'Вы уже член этой группы.',
			'groups:userinvited' => 'Пользователь приглашен.',
			'groups:usernotinvited' => 'Простите, пользователь не может быть приглашен.',
			'groups:useralreadyinvited' => 'Пользователь уже был приглашен',
			'groups:updated' => "Последнее сообщение",
			'groups:started' => "Начато пользователем",
			'groups:joinrequest:remove:check' => 'Удалить запрос приглашения?',
			'groups:invite:subject' => "%s, Вас пригласили вступить в группу %s!",
			'groups:invite:body' => "Здравствуйте, %s!

Вас пригласили вступить в группу '%s', кликните для подтверждения:

%s",

			'groups:welcome:subject' => "Добро пожаловать в группу %s!",
			'groups:welcome:body' => "Здравствуйте, %s!
		
Вы член группы '%s'! Кликните для начала деятельности.

%s",
	
			'groups:request:subject' => "%s попросил вступить в группу %s",
			'groups:request:body' => "Здравствуйте, %s!

%s попросил вступить в группу '%s', кликните для просмотра профиля:

%s

или нажмите для подтверждения запроса:

%s",
	
			'groups:river:member' => 'член группы ',
	
			'groups:nowidgets' => 'У группы не определены вижеты.',
	
	
			'groups:widgets:members:title' => 'Члены группы',
			'groups:widgets:members:description' => 'Список членов группы',
			'groups:widgets:members:label:displaynum' => 'Список членов группы',
			'groups:widgets:members:label:pleaseedit' => 'Пожалуйста, настройте этот виджет.',
	
			'groups:widgets:entities:title' => "Объекты в группе",
			'groups:widgets:entities:description' => "Список объектов группы",
			'groups:widgets:entities:label:displaynum' => 'Список объектов группы.',
			'groups:widgets:entities:label:pleaseedit' => 'Пожалуйста, настройте этот виджет.',
		
			'groups:forumtopic:edited' => 'Тема форума отредактирована.',
			
			/**
			 * Action messages
			 */
			'group:deleted' => 'Группа и все содержимое удалено',
			'group:notdeleted' => 'Удаление невозможно',
	
			'grouppost:deleted' => 'Сообщения группы удалены',
			'grouppost:notdeleted' => 'Удаление невозможно',
			'groupstopic:deleted' => 'Тема удалена',
			'groupstopic:notdeleted' => 'Удаление невозможно',
			'grouptopic:blank' => 'Тем нет',
			'groups:deletewarning' => "Вы уверены, что хотите удалить эту группу? Возврата не будет!",
	
			'groups:joinrequestkilled' => 'Запрос приглашения отклонен.',
	);
					
	add_translation("ru",$russian);
?>