<?php

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "Микроблог",
			'thewire:user' => "Микроблог пользователя %s",
			'thewire:posttitle' => "%s писал(а) в своем микроблоге: %s",
			'thewire:everyone' => "Все записи микроблога",
	
			'thewire:read' => "Микроблог",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "В микроблог",
		    'thewire:text' => "Запись в микроблоге",
			'thewire:reply' => "Ответить",
			'thewire:via' => "через",
			'thewire:wired' => "Записано в микроблоге",
			'thewire:charleft' => "символов осталось",
			'item:object:thewire' => "Записи микроблога",
			'thewire:notedeleted' => "запись удалена",
			'thewire:doing' => "Что нового? Излейте душу в микроблоге:",
			'thewire:newpost' => 'Новые записи в микроблоге',
			'thewire:addpost' => 'Записать в микроблог',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s сделал(а) запись",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "в микроблоге",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Этот элемент показывает последние записи в микроблогах пользователей сайта',
	        'thewire:yourdesc' => 'Этот элемент показывает Ваши последние записи в микроблоге',
	        'thewire:friendsdesc' => 'Этот элемент показывает последние записи в микроблогах Ваших друзей',
	        'thewire:friends' => 'Микроблоги Ваших друзей',
	        'thewire:num' => 'Число отображаемых записей',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Записано!",
			'thewire:deleted' => "Удалено",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Простите, но необходимо заполнить текстовое поле.",
			'thewire:notfound' => "Простите, данная запись не найдена.",
			'thewire:notdeleted' => "Простите, удаление невозможно.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "Номер для SMS. Номер должен быть в международном формате.",
			'thewire:channelsms' => "Номер рассылки SMS-сообщений <b>%s</b>",
			
	);
					
	add_translation("ru",$russian);

?>