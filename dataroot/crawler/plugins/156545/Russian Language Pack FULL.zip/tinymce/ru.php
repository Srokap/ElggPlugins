<?php

	$russian = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Добавить/Убрать редактор",
	
	);
					
	add_translation("ru",$russian);

?>