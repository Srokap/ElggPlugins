<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$russian = array(
	
		'email:validate:subject' => "%s, пожалуйста, подтвердите ваш электронный адрес.",
		'email:validate:body' => "Здравствуйте, %s!

Пожалуйста, подтвердите Ваш электронный адрес, нажав сюда:

%s
",
		'email:validate:success:subject' => "%s, спасибо, электронный адрес подтвержден.",
		'email:validate:success:body' => "Здравствуйте, %s!
			
Спасибо, Ваш электронный адрес подтвержден.",
	
		'uservalidationbyemail:registerok' => "Для активации аккаунта подтвердите Ваш электронный адрес, нажав на ссылку."
	
	);
					
	add_translation("ru",$russian);
?>