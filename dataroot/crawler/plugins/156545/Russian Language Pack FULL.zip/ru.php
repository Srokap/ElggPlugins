<?php

	$russian = array(

		/**
		 * Sites
		 */
	
			'item:site' => "Сайты",
	
		/**
		 * Sessions
		 */
			
			'login' => "Войти",
			'loginok' => "Добро пожаловать!",
			'loginerror' => "Пароль или имя не найдены. Вход невозможен.",
			'logout' => "Выйти",
			'logoutok' => "Вы вышли.",
			'logouterror' => "Не удалось выйти. Пожалуйста повторите попытку.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Здравствуйте",
	
			'InstallationException:CantCreateSite' => "Не удается создать с данными Имя: %s, Url: %s",
		
			'actionundefined' => "Запрошенное действие (%s) не определено.",
			'actionloggedout' => "Извините, но Вы не можете выполнить это действие, необходим вход.",
	
			'notfound' => "Запрошенный ресурс не найден, или у Вас нет к нему доступа.",
			
			'SecurityException:Codeblock' => "Запрещен доступ к выполнению привилегированного блока кода",
			'DatabaseException:WrongCredentials' => "Elgg не может соединится с базой данной, используя данные %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Elgg не может найти базу данных '%s', пожалуйста проверте что база создана и у Вас есть к ней доступ.",
			'SecurityException:FunctionDenied' => "Доступ к привилегированной функции '%s' запрещен.",
			'DatabaseException:DBSetupIssues' => "Возникли следующие проблемы: ",
			'DatabaseException:ScriptNotFound' => "Elgg не может найти запрошенный скрипт базы данных %s.",
			
			'IOException:FailedToLoadGUID' => "Не удалось загрузить новый %s с GUID:%d",
			'InvalidParameterException:NonElggObject' => "Передан не объект Elgg в конструктор объектов Elgg!",
			'InvalidParameterException:UnrecognisedValue' => "Неопознанное значение передано в конструктор.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d не является правильным %s",
			
			'PluginException:MisconfiguredPlugin' => "%s неверно заданный плагин.",
			
			'InvalidParameterException:NonElggUser' => "В конструктор ElggUser передан пользователь, не принадлежащий Elgg!",
			
			'InvalidParameterException:NonElggSite' => "В конструктор ElggSite передан сайт, не принадлежащий Elgg!",
			
			'InvalidParameterException:NonElggGroup' => "В конструктор Передан ElggGroup передана группа, не принадлежащая Elgg!",
	
			'IOException:UnableToSaveNew' => "Не удается сохранить новый %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID не был указан во время экспорта, это не должно никогда случаться.",
			'InvalidParameterException:NonArrayReturnValue' => "Обьект переданный функцией сериализации не является параметром массива",
			
			'ConfigurationException:NoCachePath' => "Не установлен путь к кешу!",
			'IOException:NotDirectory' => "%s не является папкой.",
			
			'IOException:BaseEntitySaveFailed' => "Не удается сохранить данные нового объекта!",
			'InvalidParameterException:UnexpectedODDClass' => "import() передал неожиданный ODD клас",
			'InvalidParameterException:EntityTypeNotSet' => "Вы должны заполнить тип обьекта.",
			
			'ClassException:ClassnameNotClass' => "%s не является %s.",
			'ClassNotFoundException:MissingClass' => "класс '%s' не найден, отсутствует плагин?",
			'InstallationException:TypeNotSupported' => "Тип %s не поддерживается. Это вызывает ошибку в Вашей установке, причиной может быть неполное обновление системы.",

			'ImportException:ImportFailed' => "Не удается импортировать элемент %d",
			'ImportException:ProblemSaving' => "Возникла проблема при сохранении %s",
			'ImportException:NoGUID' => "Новый объект создан, но ему не назначен GUID, этого не должно случатся.",
			
			'ImportException:GUIDNotFound' => "Обьект '%d' не найден.",
			'ImportException:ProblemUpdatingMeta' => "Возникла проблема при обновлении '%s' в объекте '%d'",
			
			'ExportException:NoSuchEntity' => "Нет такого обьекта с GUID:%d", 
			
			'ImportException:NoODDElements' => "Не найдены элементы OpenDD в данных для импорта, импорт отменен.",
			'ImportException:NotAllImported' => "Не все элементы были импортированы.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Неопознанный режим файла '%s'",
			'InvalidParameterException:MissingOwner' => "Все файлы должны иметь владельца!",
			'IOException:CouldNotMake' => "Не удается сделать %s",
			'IOException:MissingFileName' => "Вы должны ввести имя перед открытием файла.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Файловый архив не найден или класс не сохранен с файлом!",
			'NotificationException:NoNotificationMethod' => "Не определен метод уведомления.",
			'NotificationException:NoHandlerFound' => "Не найден обработчик для '%s' или он не был запущен.",
			'NotificationException:ErrorNotifyingGuid' => "Возникла ошибка во время уведомления %d",
			'NotificationException:NoEmailAddress' => "Не удается получить email адрес к GUID:%d",
			'NotificationException:MissingParameter' => "Не найден обязательный параметр, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where-условие содержит не WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Не найдены поля в запрое смены стиля",
			'DatabaseException:UnspecifiedQueryType' => "Неопознанный или неопределенный тип запроса.",
			'DatabaseException:NoTablesSpecified' => "Не указаны таблицы для запроса.",
			'DatabaseException:NoACL' => "В запросе не указан контроль доступа",
			
			'InvalidParameterException:NoEntityFound' => "Объект не найден, он не существует или у Вас нет к нему доступа.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s не найден, или у Вас нет к нему доступа.",
			'InvalidParameterException:IdNotExistForGUID' => "Извините, '%s' не существует для guid:%d",
			'InvalidParameterException:CanNotExportType' => "Извините, система не знает как экспортировать '%s'",
			'InvalidParameterException:NoDataFound' => "Данные не найдены.",
			'InvalidParameterException:DoesNotBelong' => "Не принадлежит объекту.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Не принадлежит объекту или не ссылается на объект.",
			'InvalidParameterException:MissingParameter' => "Не найден параметр, Вы должны указать GUID.",
			
			'SecurityException:APIAccessDenied' => "Извините, API доступ отключен администратором.",
			'SecurityException:NoAuthMethods' => "Не найдены методы проверки которые могли бы проверить API запрос.",
			'APIException:ApiResultUnknown' => "Результат API - неопределенного типа, этого не должно случатся.", 
			
			'ConfigurationException:NoSiteID' => "Не указан ID сайта.",
			'InvalidParameterException:UnrecognisedMethod' => "Неопознанный метод вызова '%s'",
			'APIException:MissingParameterInMethod' => "Не найден параметр %s в методе %s",
			'APIException:ParameterNotArray' => "%s не является массивом.",
			'APIException:UnrecognisedTypeCast' => "Неопознанный тип при передаче %s для переменной '%s' в метод '%s'",
			'APIException:InvalidParameter' => "Найден неверный параметр для '%s' в методе '%s'.",
			'APIException:FunctionParseError' => "%s(%s) имеет ошибку синтаксиса.",
			'APIException:FunctionNoReturn' => "%s(%s) не вернула значение.",
			'SecurityException:AuthTokenExpired' => "Значение Аутентификация не найдено, неверное или истекло.",
			'CallException:InvalidCallMethod' => "%s должен вызываться используя '%s'",
			'APIException:MethodCallNotImplemented' => "Вызов метода '%s' не выполнен.",
			'APIException:AlgorithmNotSupported' => "Алгоритм '%s' не поддерживается или отключен.",
			'ConfigurationException:CacheDirNotSet' => "Папка кэша 'cache_path' не указана.",
			'APIException:NotGetOrPost' => "Метод запроса должен быть GET или POST",
			'APIException:MissingAPIKey' => "Отсутствует X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Отсутствует X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Отсутствует X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Отсутствует X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time слишком далеко в прошлом или будущем. Ошибка периода.",
			'APIException:NoQueryString' => "Нет данных в строке запроса",
			'APIException:MissingPOSTHash' => "Отсутствует X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Отсутствует X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Отсутствует тип содержимого для POST данных",
			'SecurityException:InvalidPostHash' => "Хеш данных POST неверный - Ожидалось %s но получили %s.",
			'SecurityException:DupePacket' => "Повторная подпись пакета.",
			'SecurityException:InvalidAPIKey' => "Неверный или отсутствует API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Метод вызова '%s' на данный момент не поддерживается.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC метод вызова '%s' не реализован.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Вызов метода '%s' вернул неожиданный результат.",
			'CallException:NotRPCCall' => "Вызов не является правильным вызовом XML-RPC",
	
			'PluginException:NoPluginName' => "Имя плагина не найдено",
	
			'ConfigurationException:BadDatabaseVersion' => "Установленная база данных не удовлетворяет минимальным требованиям для запуска Elgg. Пожалуйста прочитайте документацию.",
			'ConfigurationException:BadPHPVersion' => "Вам как минимум нужна версия PHP - 5.2 для запуска Elgg.",
			'configurationwarning:phpversion' => "Elgg требует как минимум PHP 5.2, вы можете установить на 5.1.6, но полная работоспособность не гарантируется. Используйте на свой страх и риск.",
		
			'InstallationException:DatarootNotWritable' => "Нет прав на запись в папку %s.",
			'InstallationException:DatarootUnderPath' => "Ваша папка данных %s должна быть вне пути инсталяции.",
			'InstallationException:DatarootBlank' => "Вы не указали папку данных.",
			
			'SecurityException:authenticationfailed' => "Пользователь не может быть идентифицирован",
	
			'CronException:unknownperiod' => '%s - неизвестный период.',
	
			'SecurityException:deletedisablecurrentsite' => 'Вы не можете удалить или заблокировать сайт, который сейчас просматриваете.',
	
			'memcache:notinstalled' => 'Модуль PHP memcache не установлен, для начала Вы должны установить php5-memcache',
			'memcache:noservers' => 'Нет memcache-серверов, определите их в переменной $CONFIG->memcache_servers',
			'memcache:versiontoolow' => 'Memcache требует как минимум версию %s для работы, у Вас же - %s',
			'memcache:noaddserver' => 'Поддержка множества серверов не разрешена, Вам может потребоваться обновление библиотеки PECL memcache',
	
			'deprecatedfunction' => 'Внимание: этот код использует устаревшую функцию \'%s\' и несовместим с этой версией Elgg',
	
		/**
		 * API
		 */
			'system.api.list' => "Список всех доступных вызовов API в системе.",
			'auth.gettoken' => "Этот вызов API позволяет пользователю входить, возвращая авторизующий токен, который может быть использован вместо имени/пароля для идентификации будущих вызовов.",
		
	
		/**
		 * User details
		 */

			'name' => "Имя и фамилия",
			'email' => "Электронный адрес",
			'username' => "Логин",
			'password' => "Пароль",
			'passwordagain' => "Пароль (повтор для проверки)",
			'admin_option' => "Сделать этого пользователя администратором?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "Только себе",
			'LOGGED_IN' => "Зарегистрированным",
			'PUBLIC' => "Всем",
			'access:friends:label' => "Друзьям",
			'access' => "Доступ",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Главная",
			'dashboard:configure' => "НАСТРОИТЬ ВИД ПРОФИЛЯ",
			'dashboard:nowidgets' => "Ваша информационная панель - шлюз к сайту. Нажмите 'Редактировать страницу' для добавления новых элементов, чтобы Вы были в курсе всего происходимого на сайте.",

			'widgets:add' => 'Добавить новые элементы на Вашу страницу',
			'widgets:add:description' => "Тяните элементы, которые Вы хотите добавить на Вашу страницу, из <b>Галереи элементов</b> туда, где хотели бы их видеть. 
Для удаления элемента перетяните его обратно в <b>Галерею элементов</b>.
Кстати, менять элементы можно хоть каждый день.",
			'widgets:position:fixed' => '(увы, никак не передвинуть)',
	
			'widgets' => "Элементы",
			'widget' => "Элемент",
			'item:object:widget' => "Элементы",
			'layout:customise' => "Сменить положение",
			'widgets:gallery' => "Галерея элементов",
			'widgets:leftcolumn' => "Элементы слева",
			'widgets:fixed' => "Фиксированная позиция",
			'widgets:middlecolumn' => "Элементы в центре",
			'widgets:rightcolumn' => "Элементы справа",
			'widgets:profilebox' => "Блок профиля",
			'widgets:panel:save:success' => "Элементы Вашей страницы успешно сохранены.",
			'widgets:panel:save:failure' => "Ошибка при сохранении элементов. Попытайтесь снова.",
			'widgets:save:success' => "Элемент успешно сохранен.",
			'widgets:save:failure' => "Ошибка сохранения элемента. Попытайтесь снова.",
			'widgets:handlernotfound' => 'Элемент или сломан, или отключен администратором сайта.',
	
		/**
		 * Groups
		 */
	
			'group' => "Группа", 
			'item:group' => "Группы",
	
		/**
		 * Profile
		 */
	
			'profile' => "Профиль",
			'profile:edit:default' => 'Переместить поля профиля',
			'user' => "Пользователь",
			'item:user' => "Пользователи",
			'riveritem:single:user' => 'один пользователь',
			'riveritem:plural:user' => 'несколько пользователей',

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Ваш профиль",
			'profile:user' => "Профиль %s",
	
			'profile:edit' => "Редактировать профиль",
			'profile:editicon' => "Загрузить новый аватар",
			'profile:profilepictureinstructions' => "Ваша фотография будет отображаться на странице Вашего профиля. <br /> Вы можете менять её сколько угодно. (Разрешенные форматы файлов: GIF, JPG или PNG)",
			'profile:icon' => "Изображение профиля",
			'profile:createicon' => "Сохранить",
			'profile:currentavatar' => "Текущее",
			'profile:createicon:header' => "Ваша фотография",
			'profile:profilepicturecroppingtool' => "Создание аватара",
			'profile:createicon:instructions' => "Щёлкните по изображению и нарисуйте квадрат. Область в квадрате будет Вашим аватаром; можете растягивать ее как Вам угодно. Затем нажмите 'Создать Ваш аватар'. Это обрезанное изображение будет использоваться как Ваш аватар на сайте. ",
	
			'profile:editdetails' => "Редактировать данные",
			'profile:editicon' => "Редактировать Вашу фотографию",
	
			'profile:aboutme' => "Я", 
			'profile:description' => "Я",
			'profile:briefdescription' => "Слово миру",
			'profile:location' => "Местонахождение",
			'profile:skills' => "Умения",  
			'profile:interests' => "Интересы", 
			'profile:contactemail' => "Электронный адрес",
			'profile:phone' => "Домашний телефон",
			'profile:mobile' => "Мобильный телефон",
			'profile:website' => "Сайт",
			
			'profile:banned' => 'Действия пользователь заблокированы.',

			'profile:river:update' => "%s обновил(а) свой профиль",
			'profile:river:iconupdate' => "%s обновил(а) свою фотографию",
	
			'profile:label' => "Название профиля",
			'profile:type' => "Тип профиля",
	
			'profile:editdefault:fail' => 'Простите, сохранение невозможно',
			'profile:editdefault:success' => 'Сохранено',
	
			
			'profile:editdefault:delete:fail' => 'Простите, удаление элемента невозможно.',
			'profile:editdefault:delete:success' => 'Элемент профиля по-умолчанию удален.',
	
			'profile:defaultprofile:reset' => 'Сброс системного профиля по-умолчанию',
	
			'profile:resetdefault' => 'Сброс профиля по-умолчанию',

		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Ваш профиль успешно сохранен.",
			'profile:icon:uploaded' => "Аватар успешно загружен.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "У Вас нет доступа к редактированию этого профиля.",
			'profile:notfound' => "Извините, не удается найти указанный профиль.",
			'profile:cantedit' => "Извините, у Вас нет доступа к редактированию этого профиля.",
			'profile:icon:notfound' => "Извините, возникли проблемы при загрузке изображения Вашего профиля.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Друзья",
			'friends:yours' => "Ваши друзья",
			'friends:owned' => "Друзья пользователя %s",
			'friend:add' => "Добавить в друзья",
			'friend:remove' => "Убрать из друзей",
	
			'friends:add:successful' => "Вы успешно добавили пользователя %s в друзья.",
			'friends:add:failure' => "Не удается добавить пользователя %s в друзья. Пожалуйста повторите попытку.",
	
			'friends:remove:successful' => "Вы успешно удалили пользователя %s с Ваших друзей.",
			'friends:remove:failure' => "Не удается удалить пользователя %s с Ваших друзей. Пожалуйста, повторите попытку.",
	
			'friends:none' => "Этот пользователь еще никого не добавил в друзья.",
			'friends:none:you' => "Вы еще никого не добавили в друзья. Ищите пользователей с интересами, подобными Вашим, чтобы добавить их в друзья.",
	
			'friends:none:found' => "Друзей не найдено.",
	
			'friends:of:none' => "Никто еще не добавил этого пользователя в друзья.",
			'friends:of:none:you' => "Никто еще не добавил Вас в друзья. Добавляйте информацию, заполните Ваш профиль, чтобы другие пользователи нашли Вас.",
	
			'friends:of' => "Друзья пользователя %s",
			'friends:of:owned' => "Чей друг",

			 'friends:num_display' => "Показывать количество друзей",
			 'friends:icon_size' => "Размер изображения",
			 'friends:tiny' => "очень маленькое",
			 'friends:small' => "маленькое",
			 'friends' => "Друзья",
			 'friends:of' => "Чей друг",
			 'friends:collections' => "Группы друзей",
			 'friends:collections:add' => "Создать группу друзей",
			 'friends:addfriends' => "Добавить друзей",
			 'friends:collectionname' => "Название группы",
			 'friends:collectionfriends' => "Друзей в группе",
			 'friends:collectionedit' => "Редактировать эту группу",
			 'friends:nocollections' => "У Вас еще нет групп.",
			 'friends:collectiondeleted' => "Ваша группа удалена.",
			 'friends:collectiondeletefailed' => "Не удается удалить группу. У Вас не прав доступа, или возникла другая ошибка.",
			 'friends:collectionadded' => "Ваша группа успешно создана",
			 'friends:nocollectionname' => "Вы должны назвать группу перед ее созданием.",
			 'friends:collections:members' => "Пользователи в группе",
			 'friends:collections:edit' => "Редактировать группу",
		
	        'friends:river:created' => "%s добавил элемент, отображающий друзей.",
	        'friends:river:updated' => "%s обновил элемент, отображающий друзей.",
	        'friends:river:delete' => "%s удалил элемент, отображающий друзей.",
	        'friends:river:add' => "%s добавил кого-то как друга .",
			'friendspicker:chararray' => 'АБФГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЭЮЯ',
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Подписаться на канал',
			'feed:odd' => 'Syndicate OpenDD',
		
		/**
		/* links
		 */
		 	'link:view' => 'ссылка',
	
		/**
		 * River
		 */
			'river' => "Активность",			
			'river:relationship:friend' => 'теперь друзья с',
			'river:noaccess' => 'У вас нет прав для просмотра этого элемента.',
			'river:posted:generic' => '%s написал(а)',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Настройки плагина %s успешно сохранены.",
			'plugins:settings:save:fail' => "Возникла ошибка при сохранении настроек плагина %s.",
			'plugins:usersettings:save:ok' => "Пользовательские настройки плагина %s успешно сохранены.",
			'plugins:usersettings:save:fail' => "Возникла ошибка при сохранении пользовательских настроек плагина %s.",
			'admin:plugins:label:version' => "версия",
			'item:object:plugin' => 'Настройки конфигурации плагинов',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Настройки уведомления",
			'notifications:methods' => "Вы хотите получать уведомления на Ваш электронный адрес?",
	
			'notifications:usersettings:save:ok' => "Настройки уведомления успешно сохранены.",
			'notifications:usersettings:save:fail' => "Возникла ошибка при сохранении настроек уведомления.",
			
			'user.notification.get' => 'Возврат к настройкам уведомлений для данного пользователя',
			'user.notification.set' => 'Установка настроек уведомлений для данного паользователя',
		/**
		 * Search
		 */
	
			'search' => "Поиск",
			'searchtitle' => "Поиск: %s",
			'users:searchtitle' => "Поиск пользователей: %s",
			'advancedsearchtitle' => "%s результатов совпадает с %s",
			'notfound' => "Ничего не найдено.",
			'next' => "Вперед",
			'previous' => "Назад",
	
			'viewtype:change' => "Изменить вид вывода",
			'viewtype:list' => "Список",
			'viewtype:gallery' => "Галерея",
	
			'tag:search:startblurb' => "Записи, совпадающие с '%s':",

			'user:search:startblurb' => "Пользователи, совпадающие с '%s:",
			'user:search:finishblurb' => "Подробнее",
	
		/**
		 * Account
		 */
	
			'account' => "Аккаунт",
			'settings' => "Настройки",
			'tools' => "Приложения",
            'tools:yours' => "Ваши приложения",
	
			'register' => "РЕГИСТРАЦИЯ",
			'registerok' => "Вы успешно зарегистрировались на %s. Для активации аккаунта, пожалуйста, потвердите Ваш электронный адрес, нажав на ссылке в письме, которое мы Вам отправили.",
			'registerbad' => "Ваша регистрация приостановлена. Логин уже существует, Ваши пароли не совпадают, или логин или пароль слишком краткие.",
			'registerdisabled' => "Регистрация отключена администратором",
	
			'firstadminlogininstructions' => 'Ваш новый Elgg-сайт успешно установлен и аккаунт администратора создан. Вы можете продолжить настройку сайта, активируя установленные плагины.',
	
	
			'registration:notemail' => 'Указанный Вами электронный адрес является неправильным.',
			'registration:userexists' => 'Этот логин уще существует',
			'registration:usernametooshort' => 'Ваш логин должен состоять как минимум с 4 символов.',
			'registration:passwordtooshort' => 'Пароль должен быть как минимум 6 символов.',
			'registration:dupeemail' => 'Такой электронный адрес уже зарегистрирован.',
			'registration:invalidchars' => 'Простите, имя пользователя содержит запрещенные символы.',
			'registration:emailnotvalid' => 'Простите, введенный Вами электронный адрес неверен.',
			'registration:passwordnotvalid' => 'Простите, введенный Вами пароль не подходит.',
			'registration:usernamenotvalid' => 'Простите, введенный Вами логин не подходит.',
	
			'adduser' => "Добавить пользователя",
			'adduser:ok' => "Вы успешно добавили нового пользователя.",
			'adduser:bad' => "Не удается создать нового пользователя.",
			
			'item:object:reported_content' => "Жалобы",
	
			'user:set:name' => "Настройки аккаунта",
			'user:name:label' => "Имя и фамилия",
			'user:name:success' => "Имя и фамилия изменены.",
			'user:name:fail' => "Не удается изменить имя в системе.",
	
			'user:set:password' => "Пароль аккаунта",
			'user:password:label' => "Ваш новый пароль",
			'user:password2:label' => "Повтор нового пароля",
			'user:password:success' => "Пароль изменен",
			'user:password:fail' => "Не удается изменить пароль в системе.",
			'user:password:fail:notsame' => "Пароли не совпадают!",
			'user:password:fail:tooshort' => "Пароль должен быть длиннее.",
	
			'user:set:language' => "Настройки языка",
			'user:language:label' => "Язык интерфейса",
			'user:language:success' => "Настройки языка обновлены.",
			'user:language:fail' => "Ошибка сохранения смены языка.",
	
			'user:username:notfound' => 'Логин %s не найден.',
	
			'user:password:lost' => 'Потеряли пароль?',
			'user:password:resetreq:success' => 'Успешный запрос нового пароля, письмо на Ваш электронный адрес отправлено',
			'user:password:resetreq:fail' => 'Ошибка запроса нового пароля.',
	
			'user:password:text' => 'Для генерации нового пароля, введите Ваш логин ниже. Мы вышлем Вам письмо на Ваш электронный адрес.',
			
			'user:persistent' => 'Запомнить меня',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Ваши настройки сохранены.",
			'admin:configuration:fail' => "Ошибка при сохранении настроек.",
	
			'admin' => "Админ",
			'admin:description' => "Панель администрирования помогает контролировать все возможности системы, от управления пользователями до настроек плагинов. Нажмите ниже чтобы начать.",
			
			'admin:user' => "Управление пользователями",
			'admin:user:description' => "Эта панель управление позволяет управлять настройками пользователей на Вашем сайте. Выберите опцию ниже чтобы начать.",
			'admin:user:adduser:label' => "Нажмите здесь чтобы добавить нового пользователя...",
			'admin:user:opt:linktext' => "Управление пользователями...",
			'admin:user:opt:description' => "Управление пользователями и данными аккаунтов. ",
			
			'admin:site' => "Администрирование сайта",
			'admin:site:description' => "Эта панель управления позволяет управлять глобальными настройками Вашего сайта. Выберите опцию ниже чтобы начать.",
			'admin:site:opt:linktext' => "Управление сайтом...",
			'admin:site:opt:description' => "Управление техническими и нетехническими настройками сайта. ",
			'admin:site:access:warning' => "Изменение настроек доступа повлияет только на свежесозданный контент.", 
			
			'admin:plugins' => "Администрирование плагинов",
			'admin:plugins:description' => "Эта панель управления позволяет управлять и настраивать плагины, установленные на Вашем сайте.",
			'admin:plugins:opt:linktext' => "Управление плагинами...",
			'admin:plugins:opt:description' => "Настройка плагинов, установленных в Вашей системе. ",
			'admin:plugins:label:author' => "Автор",
			'admin:plugins:label:copyright' => "Копирайт",
			'admin:plugins:label:licence' => "Лицензия",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:disable:yes' => "Плагин %s успешно отключен.",
			'admin:plugins:disable:no' => "Плагин %s невозможно отключить.",
			'admin:plugins:enable:yes' => "Плагин %s успешно включен.",
			'admin:plugins:enable:no' => "Плагин %s невозможно включить.",
	
			'admin:statistics' => "Статистика",
			'admin:statistics:description' => "Это обзор статистики Вашего сайта. Если Вам нужна более детальная статистика, эта опция доступна.",
			'admin:statistics:opt:description' => "Просмотр статистической информации о пользователях и обьектах на Вашем сайте.",
			'admin:statistics:opt:linktext' => "Просмотр статистики...",
			'admin:statistics:label:basic' => "Простая статистика сайта",
			'admin:statistics:label:numentities' => "Объектов на сайте",
			'admin:statistics:label:numusers' => "Количество пользователей",
			'admin:statistics:label:numonline' => "Количество пользователей онлайн",
			'admin:statistics:label:onlineusers' => "Пользователей онлайн сейчас",
			'admin:statistics:label:version' => "Версия Elgg",
			'admin:statistics:label:version:release' => "Релиз",
			'admin:statistics:label:version:version' => "Версия",
	
			'admin:user:label:search' => "Поиск пользователей:",
			'admin:user:label:seachbutton' => "Поиск", 
	
			'admin:user:ban:no' => "Не удалось заблокировать пользователя",
			'admin:user:ban:yes' => "Пользователь заблокирован.",
			'admin:user:unban:no' => "Не удается разблокировать пользователя",
			'admin:user:unban:yes' => "Пользователь  разблокирован.",
			'admin:user:delete:no' => "Не удается удалить пользователя",
			'admin:user:delete:yes' => "Пользователь удален",
	
			'admin:user:resetpassword:yes' => "Пароль изменен, пользователь уведомлен.",
			'admin:user:resetpassword:no' => "Не удается изменить пароль.",
	
			'admin:user:makeadmin:yes' => "Пользователь стал администратором.",
			'admin:user:makeadmin:no' => "Не удается сделать этого пользователя администратором.",
			
			'admin:user:removeadmin:yes' => "Пользователь больше не администратор.",
			'admin:user:removeadmin:no' => "Невозможно удалить права администратора у данного пользователя.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "Панель пользователя позволяет управлять всеми Вашими персональными настройками, от управления пользователем до отображения плагинов. Выберите опцию ниже чтобы начать.",
	
			'usersettings:statistics' => "Ваша статистика",
			'usersettings:statistics:opt:description' => "Просмотр статистической информации о пользователях и обьектах на Вашем сайте.",
			'usersettings:statistics:opt:linktext' => "Статистика аккаунта",
	
			'usersettings:user' => "Ваши настройки",
			'usersettings:user:opt:description' => "Управление настройками пользователя.",
			'usersettings:user:opt:linktext' => "Изменить Ваши настройки",
	
			'usersettings:plugins' => "Плагины",
			'usersettings:plugins:opt:description' => "Управление настройками активных плагинов.",
			'usersettings:plugins:opt:linktext' => "Настройка плагинов...",
	
			'usersettings:plugins:description' => "Эта панель позволяет управлять и настраивать персональными настройками плагинов, установленных системным администратором.",
			'usersettings:statistics:label:numentities' => "Ваши объекты",
	
			'usersettings:statistics:yourdetails' => "Ваши данные",
			'usersettings:statistics:label:name' => "Полное имя и фамилия",
			'usersettings:statistics:label:email' => "Электронный адрес",
			'usersettings:statistics:label:membersince' => "Пользователь с",
			'usersettings:statistics:label:lastlogin' => "Последний раз был на сайте",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Сохранить",
			'publish' => "Опубликовать",
			'cancel' => "Отмена",
			'saving' => "Сохранение ...",
			'update' => "Обновить",
			'edit' => "Редактировать",
			'delete' => "Удалить",
			'accept' => "Принять",
			'load' => "Скачать",
			'upload' => "Загрузить",
			'ban' => "Заблокировать",
			'unban' => "Разблокировать",
			'enable' => "Включить",
			'disable' => "Выключить",
			'request' => "Запрос",
			'complete' => "завершено",
			'open' => 'Открыть',
			'close' => 'Закрыть',
			'reply' => "Ответить",
			'more' => 'Еще',
			'comments' => 'Комментарии',
			'import' => 'Импорт',
			'export' => 'Экспорт',
	
			'up' => 'Вверх',
			'down' => 'Вниз',
			'top' => 'В самый верх',
			'bottom' => 'В середину',
	
			'invite' => "Пригласить",
	
			'resetpassword' => "Сбросить пароль",
			'makeadmin' => "Сделать администратором",
			'removeadmin' => "Удалить администратора",
	
			'option:yes' => "Да",
			'option:no' => "Нет",
	
			'unknown' => 'Неизвестно',
	
			'active' => 'активно',
			'total' => 'всего',
	
			'learnmore' => "Нажмите сюда для продолжения",
	
			'content' => "содержимое",
			'content:latest' => 'Последняя активность',
			'content:latest:blurb' => 'Или нажмите сюда для просмотра новой информации, добавленной на сайт',
	
			'link:text' => 'ссылка',
	
			'enableall' => 'Включить все',
			'disableall' => 'Выключить все',
			
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'Вы уверены?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Название",
			'description' => "Описание",
			'tags' => "Теги",
			'spotlight' => "А также...",
			'all' => "Все",
	
			'by' => 'от',
	
			'annotations' => "Примечания",
			'relationships' => "Связи",
			'metadata' => "Метаданные",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Вы уверены что хотите удалить этот элемент?",
			'fileexists' => "Файл уже загружен. Чтобы заменить его, выберите его ниже:",
			
		/**
		 * User add
		 */

			'useradd:subject' => 'Вы успешно зарегистрировались',
			'useradd:body' => '
%s,

Вы зарегистрировались на %s. Для входа нажмите сюда:

	%s

Ваши регистрационные реквизиты:

	Логин: %s
	Пароль: %s
	
',
	
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "закрыть",
			
			
		/**
		 * Import / export
		 */
			'importsuccess' => "Данные импортированы успешно",
			'importfail' => "Ошибка OpenDD импорта данных.",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "только что",
			'friendlytime:minutes' => "%s минут назад",
			'friendlytime:minutes:singular' => "минуту назад",
			'friendlytime:hours' => "%s часов назад",
			'friendlytime:hours:singular' => "час назад",
			'friendlytime:days' => "%s дней назад",
			'friendlytime:days:singular' => "вчера",
			
			'date:month:01' => '%s января',
			'date:month:02' => '%s февраля',
			'date:month:03' => '%s марта',
			'date:month:04' => '%s апреля',
			'date:month:05' => '%s мая',
			'date:month:06' => '%s июня',
			'date:month:07' => '%s июля',
			'date:month:08' => '%s августа',
			'date:month:09' => '%s сентября',
			'date:month:10' => '%s октября',
			'date:month:11' => '%s ноября',
			'date:month:12' => '%s декабря',
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Для инсталляции Elgg нужно чтобы файл .htaccess был размещен в главной папке. Система пыталась его создать, но Elgg не имеет прав на запись в этой папке. 

Создать этот файл легко. Скопируйте содержимое текстового блока в текстовый редактор и сохраните его как .htaccess

",
			'installation:error:settings' => "Elgg не может найти файл настроек. Большинство настроек Elgg будут доступны Вам, но Вы должны указать данные соединения с базой данных. Для этого:

1. Переименуйте engine/settings.example.php на settings.php.

2. Откройте его в текстовом редакторе и впишите данные базы данных MySQL. Если Вы не знаете как это сделать, попросите помощи у Вашего администратора или технической поддержки хостинга.
Так же, Вы можете ввести настройки базы данных ниже и система попробует записать их в файл...",
	
			'installation:error:configuration' => "Если Вы исправили ошибки в настройках, пожалуйста обновите страницу для продолжения установки.",
	
			'installation' => "Установка",
			'installation:success' => "База данных Elgg установлена успешно.",
			'installation:configuration:success' => "Ваши настройки сохранены. Теперь зарегистрируйте пользователя, он будет системным администратором.",
	
			'installation:settings' => "Настройки системы",
			'installation:settings:description' => "Теперь, после того как база данных Elgg успешно установлена, Вы должны заполнить некоторые данные о сайте.",
	
			'installation:settings:dbwizard:prompt' => "Введите ниже настройки базы данных и нажмите сохранить:",
			'installation:settings:dbwizard:label:user' => "Пользователь базы данных",
			'installation:settings:dbwizard:label:pass' => "Пароль базы данных",
			'installation:settings:dbwizard:label:dbname' => "База данных Elgg",
			'installation:settings:dbwizard:label:host' => "Сервер базы данных (в большинстве случаев  'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Префикс таблиц базы данных (в основном 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Ошибка при сохранении нового settings.php. Пожалуйста сохраните этот файл как engine/settings.php используя текстовый редактор.",
	
			'installation:sitename' => "Название Вашего сайта (Пример \"Мой социальный сайт\"):",
			'installation:sitedescription' => "Краткое описание Вашего сайта (не обязательно)",
			'installation:wwwroot' => "URL сайта, должен заканчиваться слешем:",
			'installation:path' => "Полный путь к корню сайта, должен заканчиваться слешем:",
			'installation:dataroot' => "Полный путь к папке где будут сохраняться загруженные файлы, должен заканчиваться слешем:",
			'installation:dataroot:warning' => "Вы должны создать эту папку вручную. Она должна размещаться в папке, которая не входит в путь установки Elgg.",
			'installation:sitepermissions' => "Права доступа по-умолчанию:",
			'installation:language' => "Язык по умолчанию для Вашего сайта:",
			'installation:debug' => "Debug-режим показывает дополнительную информацию, которую можна использовать для проверки ошибок, но этот режим замедлит работу системы, поэтому рекомендуем его использовать только в случае возникновения ошибок:",
			'installation:debug:label' => "Включить debug-режим",
			'installation:httpslogin' => "Пользователи могут входить по HTTPS. Для этого Вам нужно будет настроить HTTPS на сервере." , 
			'installation:httpslogin:label'  =>  "Разрешить вход по HTTPS" , 
			'installation:usage' => "Эта опция позволяет Elgg отправлять анонимную статистику использования на Curverider.",
			'installation:usage:label' => "Отправка анонимной информации использования",
			'installation:view' => "Введите режим просмотра, который будет использоваться у Вас на сайте, или оставьте пустим для использования режима просмотра по умолчанию (если не уверены, оставьте пустым):",
			
			'installation:siteemail' => "Электронный адрес сайта (будет использоваться для рассылки системных сообщений)",
	
			'installation:disableapi' => "Elgg предоставляет гибкое и расширяемое API, которое позволяет приложениям удаленно использовать некоторые возможности системы .",
			'installation:disableapi:label' => "Включить RESTful API",
			
			'installation:allow_user_default_access:description' => "Пользователи могут настраивать собственный уровень доступа, который будет иметь учитываться аналогичными настройками системы.",
			'installation:allow_user_default_access:label' => "Разрешить пользователям настраивать уровень доступа",
	
			'installation:simplecache:description' => "Простой кэш увеличивает производительность, кэшируя элементы вроде CSS и JavaScript. Рекомендуем включить данную опцию.",
			'installation:simplecache:label' => "Использовать простой кэш",
	
			'upgrading' => 'Обновление',
			'upgrade:db' => 'Ваша база данных обновлена.',
			'upgrade:core' => 'Ваш дистрибутив Elgg обновлен',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Здравствуйте,",
			'welcome_message' => "Приветствуем Вас в установке Elgg.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Настройки электронного адреса",
			'email:address:label' => "Ваш электронный адрес",
			
			'email:save:success' => "Новый электронный адрес сохранен, отправлен запрос проверки реальности адреса.",
			'email:save:fail' => "Ваш новый электронный адрес не сохранен.",
	
			'email:confirm:success' => "Вы подтвердили Ваш электронный адрес.",
			'email:confirm:fail' => "Ваш электронный адрес не проверен...",
	
			'friend:newfriend:subject' => "%s добавил(а) Вас в друзья.",
			'friend:newfriend:body' => "%s добавил(а) Вас в друзья.

Для просмотра профиля пользователя нажмите здесь:

	%s

Не отвечайте на это письмо.",
	
	
			'email:validate:subject' => "%s, добро пожаловать!.",
			'email:validate:body' => "Здравствуйте, %s!

Пожалуйста, подтвердите Ваш электронный адрес, нажав ссылку ниже:

%s
",
			'email:validate:success:subject' => "Электронный адрес проверен.",
			'email:validate:success:body' => "Здравствуйте, %s!
			
Поздравляем, Вы успешно подтвердили Ваш электронный адрес.",
	
	
			'email:resetpassword:subject' => "Пароль изменен.",
			'email:resetpassword:body' => "Здравствуйте, %s!
			
Ваш пароль изменен на: %s",
	
	
			'email:resetreq:subject' => "Запрос нового пароля.",
			'email:resetreq:body' => "Здравствуйте, %s!
			
Кто-то (с IP-адреса %s) запросил новый пароль для этого аккаунта.

Если запрос сделали Вы, нажмите ссылку ниже, если не Вы - проигнорируйте это письмо.

%s
",

		/**
		 * user default access
		 */
	
			'default_access:settings' => "Ваш уровень доступа по-умолчанию",
			'default_access:label' => "Доступ по-умолчанию",
			'user:default_access:success' => "Ваш уровень доступа по-умолчанию сохранен.",
			'user:default_access:failure' => "YВаш уровень доступа по-умолчанию не может быть.",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Не найдены входящие данные",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s комментариев",
			
			'riveraction:annotation:generic_comment' => '%s откомментировал(а) %s',
			
			'generic_comments:add' => "Добавить комментарий",
			'generic_comments:text' => "Комментарий",
			'generic_comment:posted' => "Ваш комментарий успешно добавлен.",
			'generic_comment:deleted' => "Ваш комментарий успешно удален.",
			'generic_comment:blank' => "Извините, Вам нужно написать что-то в комментарии перед тем как его сохраненить.",
			'generic_comment:notfound' => "Извините, не найден указанный элемент.",
			'generic_comment:notdeleted' => "Извините, ошибка при удалении комментария.",
			'generic_comment:failure' => "Неожиданная ошибка возникла при добавлении комментария. Пожалуйста повторите еще раз.",
	
			'generic_comment:email:subject' => 'У Вас новый комментарий.',
			'generic_comment:email:body' => "Добавлен новый комментарий к Вашему элементу \"%s\" от %s. Он написал:

			
%s


Для ответа или просмотра элемента, нажмите здесь:

	%s

Для просмотра профиля %s, нажмите здесь:

	%s

Не отвечайте на этот email.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Создан в %s %s',
			'entity:default:missingsupport:popup' => 'Этот объект не удается корректно отобразить. Возможно ему нужен плагин, который уже удален.',

			'entity:delete:success' => 'Объект %s удален',
			'entity:delete:fail' => 'Ошибка удаления объекта %s',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'В форме не найдены поля __token или __ts',
			'actiongatekeeper:tokeninvalid' => 'Значение переданное формой не совпадает со значением сгенерированным сервером.',
			'actiongatekeeper:timeerror' => 'Время формы истекло, пожалуйста обновите страницу и попробуйте снова.',
			'actiongatekeeper:pluginprevents' => 'Компонент воспрепятствовал отправке этой формы.',
			
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'и, затем, но, она, его, её, его, one, не, также, о, сайчас, следовательно, тем не менее, все ещё, подобно, иначе, следовательно, наоборот, довольно, следовательно, кроме того, тем не менее, взамен, тем временем, соответственно, это, кажется, что, кто, чье, кто бы ни, кому либо',
	
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Spanish",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Русский",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Украинский",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
			
			
	);
	
	add_translation("ru",$russian);

?>