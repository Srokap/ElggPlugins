<?php

	$russian = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Отображение некоторых Ваших друзей.",
	        
		
	);
					
	add_translation("ru",$russian);

?>