<?php

$russian = array( 
	 'expages'  =>  "Внешние страницы" , 
	 'expages:frontpage'  =>  "Главная страница" , 
	 'expages:about'  =>  "О сайте" , 
	 'expages:terms'  =>  "Правила" , 
	 'expages:privacy'  =>  "Конфиденциальность" , 
	 'expages:analytics'  =>  "Аналитика" , 
	 'expages:contact'  =>  "Контакты" , 
	 'expages:nopreview'  =>  "Просмотр пока недоступен" , 
	 'expages:preview'  =>  "Просмотр" , 
	 'expages:notset'  =>  "Эта страница пока недоступна." , 
	 'expages:lefthand'  =>  "Панель слева" , 
	 'expages:righthand'  =>  "Панель справа" , 
	 'expages:addcontent'  =>  "Вы можете добавить сюда содержимое через инструменты администрирования." , 
	 'item:object:front'  =>  "Элементы главной страницы" , 
	 'expages:posted'  =>  "Страница успешно сохранена." , 
	 'expages:deleted'  =>  "Страница успешно удалена." , 
	 'expages:deleteerror'  =>  "Возникла проблема при удалении старой страницы" , 
	 'expages:error'  =>  "Простите, возникла ошибка, попробуйте снова."
); 

add_translation('ru', $russian); 

?>