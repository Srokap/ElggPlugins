<?php

$russian = array( 
	 'friends:all'  =>  "Все друзья" , 
	 
	 'notifications:subscriptions:personal:description'  =>  "Получать уведомления при изменениях в Вашем контенте" , 
	 'notifications:subscriptions:personal:title'  =>  "Личные уведомления" , 
	 
	 'notifications:subscriptions:collections:title'  =>  "Выбрать группы друзей" , 
	 'notifications:subscriptions:collections:description'  =>  "Чтобы выбрать настройки членов групп Ваших друзей, воспользуйтесь данными значками. Пользователи будут оповещены." , 
	 'notifications:subscriptions:collections:edit'  =>  "Чтобы редактировать группы друзей, нажмите здесь." , 
	 
	 'notifications:subscriptions:changesettings'  =>  "Уведомления" , 
	 'notifications:subscriptions:changesettings:groups'  =>  "Уведомления групп" , 
	 'notification:method:email'  =>  "электронный адрес" , 
	 
	 'notifications:subscriptions:title'  =>  "Уведомления каждого пользователя" , 
	 'notifications:subscriptions:description'  =>  "Чтобы получать уведомления о действиях Ваших друзей, выберите их ниже и укажите способ получения уведомлений." , 
	 
	 'notifications:subscriptions:groups:description'  =>  "Чтобы получать уведомления о информации, оставленных Вашими друзьями, выберите ее ниже и укажите способ получения уведомлений." , 
	 
	 'notifications:subscriptions:success'  =>  "Сохранено."
); 

add_translation('ru', $russian); 

?>