<?php


$russian = array( 
	 'item:object:moddefaultwidgets'  =>  "Настройки элементов по-умолчанию" , 
	 'defaultwidgets:menu:profile'  =>  "Элементы профиля по-умолчанию" , 
	 'defaultwidgets:menu:dashboard'  =>  "Элементы панели инструментов по-умолчанию" , 
	 'defaultwidgets:admin:error'  =>  "Ошибка: у Вас нет прав администратора" , 
	 'defaultwidgets:admin:notfound'  =>  "Ошибка: страница не найдена" , 
	 'defaultwidgets:admin:loginfailure'  =>  "Внимание: у Вас нет прав администратора" , 
	 'defaultwidgets:update:success'  =>  "Настройки элементов по-умолчанию" , 
	 'defaultwidgets:update:failed'  =>  "Ошибка: невозможно сохранить настройки" , 
	 'defaultwidgets:update:noparams'  =>  "Ошибка: параметры неверны" , 
	 'defaultwidgets:profile:title'  =>  "Установить элементы по-умолчанию для всех новых профилей пользователей" , 
	 'defaultwidgets:dashboard:title'  =>  "Установить элементы по-умолчанию для всех новых панелей инструментов"
); 

add_translation('ru', $russian); 

?>