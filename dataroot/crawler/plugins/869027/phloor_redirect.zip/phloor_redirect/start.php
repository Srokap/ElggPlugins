<?php
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Phloor Redirect
 */

elgg_register_event_handler('init', 'system', 'phloor_redirect_init',                 2);
// immediately afterwards start the check for real redirects
elgg_register_event_handler('init', 'system', 'phloor_redirect_check_real_redirects', 3);


function phloor_redirect_init() {
    global $CONFIG;
	/**
	 * Plugin hooks
	 * */
	// replace default patterns like %wwwroot% and %username%
	elgg_register_plugin_hook_handler('phloor_redirect_replace_special_pattern', 'all', 'phloor_redirect_replace_default_sepcial_pattern_hook', 999);

	/**
	 * Site Menu Item (just for admins)
	 * */
	if(elgg_is_admin_logged_in()) {
		$item = new ElggMenuItem('redirect', elgg_echo('phloor_redirect:redirects'), 'phloor_redirect/all');
		elgg_register_menu_item('site', $item);
	}

	/**
	 * Url handler
	 * */
	elgg_register_entity_url_handler('object', 'phloor_redirect', 'phloor_redirect_url_handler');

	/**
	 * CSS
	 * for the background icons mostly
	 * */
	elgg_extend_view('css/admin', 'phloor_redirect/css/admin');
	elgg_extend_view('css/elgg',  'phloor_redirect/css/elgg', 501);

	/**
	 * Admin menu
	 * */
	elgg_register_admin_menu_item('configure', 'phloor_redirect', 'appearance');

	/**
	 * Entity menu
	 * */
	elgg_register_plugin_hook_handler('register', 'menu:entity', 'phloor_redirect_register_entity_menu_setup');
	// unregister likes and likes_count for redirects object entity menu
	elgg_register_plugin_hook_handler('prepare',  'menu:entity', 'phloor_redirect_prepare_entity_menu_setup');

	/**
	 * Actions
	 * */
	$action_path = elgg_get_plugins_path() . 'phloor_redirect/actions/phloor_redirect';
	elgg_register_action('phloor_redirect/save',   "$action_path/save.php",   'admin');
	elgg_register_action('phloor_redirect/delete', "$action_path/delete.php", 'admin');

	/**
	 * Page handler
	 * */
	elgg_register_page_handler('phloor_redirect', 'phloor_redirect_page_handler');

	//(attribute_name => input_view)
	elgg_set_config('phloor_redirect', array(
	    'from'         => 'input/url',
	    'to'           => 'input/url',
	    'reason'       => 'input/text',
	    'walledgarden' => 'phloor/input/enable',
		'access_id'    => 'input/access',
		'description'  => 'input/longtext',
	));

	/**
	 * Hooks
	 * */
	// publics pages hook for circumventing the walled garden (if active)
	elgg_register_plugin_hook_handler('public_pages', 'walled_garden', 'phloor_redirect_public_pages');

	// route hook for "redirecting" by switching the page handler
	elgg_register_plugin_hook_handler('route', 'all', 'phloor_redirect_route_hook', 1);


}

function phloor_redirect_public_pages($hook, $handler, $return, $params) {
    // get redirect where walled garden is set to "true"
    $redirects   = phloor_redirect_get_redirect_entities(array(
		'metadata_names'  => array('walledgarden'),
		'metadata_values' => array('true'),
	));

	$pages = array();
	// append an walled garden exception for each redirect
	foreach($redirects as $redirect) {
	    $pages[] = $redirect->getFrom(true); // push url to pages array
	}

	return array_merge($pages, $return);
}

function phloor_redirect_check_real_redirects() {
	/***************************
	 * CHECK FOR REDIRECT RULES
	 * (actual redirect => CODE 302 Temporarily moved)
	 *
	 * temporarily fetch all with real_redirect == true
	 * and match them (as not many objects are expected)
	 */
	$current_url = full_url();
	$redirects   = phloor_redirect_get_redirect_entities(array(
		'metadata_names'  => array('real_redirect'),
		'metadata_values' => array('true'),
	));
	foreach($redirects as $redirect) {
        $source = elgg_normalize_url($redirect->getFrom(true));
//         if(!elgg_http_url_is_identical($current_page_url, $source)) {
		$pattern = "`^{$source}/*$`i";
		if (preg_match($pattern, $current_url)) {
		    $forward_url = elgg_normalize_url($redirect->getTo(true));
		    forward($forward_url, $redirect->getReason());
			exit();
		}
//         }
	}
}

function phloor_redirect_route_hook($hook, $handler, $return, $params) {
	$handler = $return['handler'];
	$page    = $return['segments'];

    $implode_page = implode("/", $page);

    $site_url    = elgg_get_site_url();
	$current_url = phloor_get_current_page_url();
	/***************************
	 * CHECK FOR RECROUTING RULES
	 * (no redirect => just switching the pagehandler)
	 */
	$redirects   = phloor_redirect_get_redirect_entities(array(
		//'metadata_names'  => array('handler_from'),
		//'metadata_values' => array($handler),
		'metadata_names'  => array('real_redirect'),
		'metadata_values' => array('false'),
		//'metadata_names'  => array('real_redirect','handler_from'),
		//'metadata_values' => array('false', $handler),
	    //'metadata_name_value_pairs_operator' => 'OR',
	));
	foreach($redirects as $redirect) {
	    $switch_page_handler = false; // by default false

        $current_handler = $redirect->handler_from;
	    $source          = $redirect->getFrom(true);

	    // when handler is exactly the same...
		if(strcmp($handler, $current_handler) == 0) {
		    $current_page_from = $redirect->getPageFrom(true);
		    //.. switch page handler if page form is also the same..
            if(strcmp($implode_page, $current_page_from) == 0) {
                $switch_page_handler = true; // pages match => switch handler
            } else {
                //... or the regular expression matches..
        		$pattern = "`^{$current_page_from}/*$`i";
        		if (preg_match($pattern, $implode_page)) {
        		     $switch_page_handler = true;
        		}
            }
        }
	    else {
	        // or switch page handler when source matches current url (regex)
    		$pattern = "`^{$site_url}{$source}/*$`i";
    		if (preg_match($pattern, $current_url)) {
    		     $switch_page_handler = true; // pages match => switch handler
    		}
	    }

        // redirect is active switch the pages handler
        if($switch_page_handler) {
            $reason = $redirect->getReason();

            $return['handler']  = $redirect->handler_to;
            $return['segments'] = explode("/", $redirect->getPageTo(true));

            // let user know why he/she was redirected
            if (!empty($reason)) {
                system_message($reason);
            }

            return $return;
        }
	}

	return $return;
}

function phloor_redirect_page_handler($page) {
    admin_gatekeeper();

	// push 'all' redirects breadcrumb
	elgg_push_breadcrumb(elgg_echo('phloor_redirect:redirects'), "phloor_redirect/all");

	if (!isset($page[0])) {
		$page[0] = 'all';
	}
	
	$page_type = $page[0];
	switch ($page_type) {
		case 'owner':
			$user = get_user_by_username($page[1]);
			$params = phloor_redirect_get_page_content_list($user->guid, $options);
			break;
		case 'view':
			$params = phloor_redirect_get_page_content_read($page[1]);
			break;
		case 'add':
			$params = phloor_redirect_get_page_content_edit($page_type, $page[1]);
			break;
		case 'edit':
			$params = phloor_redirect_get_page_content_edit($page_type, $page[1]);
			break;
		case 'all':
		default:
			$params = phloor_redirect_get_page_content_list();
	}

	// disable filter
	$params['filter'] = false;


	$params['page_type'] = $page[0];
	$sidebar = elgg_view('phloor_redirect/sidebar', $params);
	if (isset($params['sidebar'])) {
		$params['sidebar'] .= $sidebar;
	} else {
        $params['sidebar'] = $sidebar;
	}
	
	$layout = elgg_extract('layout', $params, 'content');

	$body = elgg_view_layout($layout, $params);

	echo elgg_view_page($params['title'], $body);

	return true;
}

/**
 * Add/remove particular phloor_redirect links/info to entity menu
 */
function phloor_redirect_register_entity_menu_setup($hook, $type, $return, $params) {
	$redirect = $params['entity'];
	$handler = elgg_extract('handler', $params, false);
	// break up if wrong handler or entity is not of class PhloorRedirect
	if(!phloor_redirect_instanceof($redirect)) {
	    return $return;
	}

	// registers "Circumvents Walled Garden"
	if($redirect->circumventWalledGarden()) {
    	$walled_garden_item = ElggMenuItem::factory(array(
    		'name'     => 'walledgarden',
    		'href'     => false,
    		'text'     => elgg_echo('phloor_redirect:menu:entity:circumvents_walled_garden'),
    		'priority' => 1,
    	));
    	$return[] = $walled_garden_item;
	}

	// registers "Real Redirect" or "Switch Page Handler"
	if($redirect->isRealRedirect()) {
    	$real_redirect_item = ElggMenuItem::factory(array(
    		'name'     => 'real_redirect',
    		'href'     => false,
    		'text'     => elgg_echo('phloor_redirect:menu:entity:real_redirect'),
    		'priority' => 2,
    	));
    	$return[] = $real_redirect_item;
	}
	else {
	    $switch_page_handler_item = ElggMenuItem::factory(array(
    		'name'     => 'switch_page_handler',
    		'href'     => false,
    		'text'     => elgg_echo('phloor_redirect:menu:entity:switch_page_handler'),
    		'priority' => 3,
    	));
    	$return[] = $switch_page_handler_item;
	}


	return $return;
}

/**
 * prepare Redirect object entity menu
 *
 * remove likes and likes_count
 *
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_redirect_prepare_entity_menu_setup($hook, $type, $return, $params) {
	$redirect = elgg_extract('entity', $params, false);
	$handler = elgg_extract('handler', $params, false);
	// break up if wrong handler or entity is not of class PhloorRedirect
	if(!phloor_redirect_instanceof($redirect) ||
	   $handler != 'phloor_redirect') {
		return $return;
	}
	/**
	 * UNregister items
	 * unregister like and likes_count
	 */
	$unregister_items = array(
		'likes', 'likes_count',
	);

	foreach ($return as $index => $section) {
		if(is_array($section)) {
			foreach($section as $key => $item) {
				if(in_array($item->getName(), $unregister_items)) {
					unset($return[$index][$key]);
				}
			}
		}
	}

	return $return;
}

/**
 * Format and return the URL for redirects.
 *
 * @param PhloorRedirect $entity redirect object
 * @return string URL of redirect.
 */
function phloor_redirect_url_handler($entity) {
	if (!$entity->getOwnerEntity()) {
		// default to a standard view if no owner.
		return FALSE;
	}

	$friendly_title = elgg_get_friendly_title($entity->title);
	return "phloor_redirect/view/{$entity->guid}/$friendly_title";
}


/**
 *
 * Replaces the special patterns..
 * has standard patterns and can be extended via
 * the trigger:
 *
 * @param unknown_type $string
 * @param unknown_type $site_guid
 */
function phloor_redirect_replace_sepcial_pattern($string, $type = 'all', $site_guid = 0) {
	if(!empty($string)) {
		$params = array(
			'site_guid' => $site_guid,
			'original_string' => $string,
		);
		$string = elgg_trigger_plugin_hook('phloor_redirect_replace_special_pattern', $type, $params, $string);
	}

	return $string;
}

/**
 *
 * Replaces the special patterns..
 * has standard patterns and can be extended via
 * the trigger:
 *
 * @param unknown_type $string
 * @param unknown_type $site_guid
 */
function phloor_redirect_replace_default_sepcial_pattern_hook($hook, $type, $return, $params) {
	if($hook == 'phloor_redirect_replace_special_pattern') {
		$wwwroot = elgg_get_site_url($params['site_guid']);
		$return = str_replace('%wwwroot%', $wwwroot, $return);

		// only if user is logged in replace the username pattern
		if(elgg_is_logged_in()) {
			$username = elgg_get_logged_in_user_entity()->username;
			$return = str_replace('%username%', $username, $return);
		}
	}

	return $return;
}


/** PHLOOR REDIRECT LIB ********************************************************/


/**
 * Default attributes
 *
 * @return array with default values
 */
function phloor_redirect_default_vars() {
	$defaults = array(
		'from'           => '%wwwroot%',
	    'to'             => '%wwwroot%',
	    'reason'         => '',
	    'handler_from'   => '',
	    'page_from'      => '',
	    'handler_to'     => '',
	    'page_to'        => '',
	    'real_redirect'  => 'false', // just switching pagehandler by default
	    'walledgarden'   => 'false', // cirecumvent walled garden?
	    'description'    => '',
		'access_id'      => ACCESS_DEFAULT,
		'container_guid' => NULL,
		'guid'           => NULL,
	);

	return $defaults;
}


function phloor_redirect_instanceof($redirect) {
	return elgg_instanceof($redirect, 'object', 'phloor_redirect', 'PhloorRedirect');
}


/**
 * Load vars from post or get requests and returns them as array
 *
 * @return array with values from the request
 */
function phloor_redirect_get_input_vars() {
	// set defaults and required values
	$values = phloor_redirect_default_vars();
	$values['container_guid'] = (int)get_input('container_guid', '');

	$user = elgg_get_logged_in_user_entity();
	// load from redirect and do sanity and access checking
	foreach ($values as $name => $default) {
		$value = get_input($name, $default);
		switch ($name) {
			case 'container_guid':
				// this can't be empty or saving the base entity fails
				if (!empty($value)) {
					if (can_write_to_container($user->getGUID(), $value)) {
						$values['container_guid'] = $value;
					}
				}
				break;
				// don't try to set the guid
			case 'guid':
				unset($values['guid']);
				break;
			default:
				$values[$name] = $value;
				break;
		}
	}

	return $values;
}

/**
 * Load vars from given site into and returns them as array
 *
 * @return array with stored values
 */
function phloor_redirect_save_vars(PhloorRedirect $redirect, $params) {
	// get default params
	$defaults = phloor_redirect_default_vars();

	// merge with given params
	$vars = array_merge($defaults, $params);

	// check variables
	if(!phloor_redirect_check_vars($vars)) {
		return false;
	}

	// adopt variables
	foreach($vars as $key => $value) {
		$redirect->$key = $value;
	}

	// save and return status
	return $redirect->save();
}

/**
 * Check variables, manipulate them
 *
 * @param unknown_type $params
 */
function phloor_redirect_check_vars(&$params) {
	// fail if a required entity isn't set
	$required = array('from', 'to');

	// load from redirect and do sanity and access checking
	foreach ($required as $name) {
		if (!isset($params[$name]) || empty($params[$name])) {
			register_error(elgg_echo("phloor_redirect:error:missing:$name"));
			return false;
		}
	}

	$from = $params['from'];
	$to   = $params['to'];

	if(strcmp($from, $to) == 0) {
	    register_error(elgg_echo("phloor_redirect:error:source_equals_destination"));
	    return false;
	}

	if(phloor_str_starts_with($from, "%wwwroot%") ||
	   phloor_str_starts_with($to,   "%wwwroot%") ||
	   phloor_str_starts_with($from, "http://") ||
	   phloor_str_starts_with($to,   "http://")) {

	   // set real redirect to true
	   // this will force a real redirect (=> forward())
	   // instead of just switching page handlers
	   $params['real_redirect'] = 'true';
	   // cannot be a walled garden circumvention
	   $params['walledgarden']  = 'false';
	}
	else {
    	// extract pagehandler params from FROM input
    	$from_array= explode('/', $from);
    	if ($from_array[count($from_array) - 1] === '') {
    		array_pop($from_array);
    	}

    	if(!empty($from_array)) {
    	    // save page handler as "handler_from" metadata
    	    $params['handler_from'] = array_shift($from_array);
    	    // rest of the url as string "page_from" seperated with "/"
    	    $params['page_from']    = implode("/", $from_array);
    	}

    	// extract pagehandler and params from TO input
    	$to_array= explode('/', $to);
    	if ($to_array[count($to_array) - 1] === '') {
    		array_pop($to_array);
    	}

    	if(!empty($to_array)) {
    	    // save page handler as "handler_to" metadata
    	    $params['handler_to'] = array_shift($to_array);
    	    // rest of the url as string "page_to" seperated with "/"
    	    $params['page_to']    = implode("/", $to_array);
    	}
	}

	// if walled garden is not true, its false
	if(!phloor_str_is_true($params['walledgarden'])) {
	    $params['walledgarden'] = 'false';
	}
	// if walled garden is not true, its false
	if(!phloor_str_is_true($params['real_redirect'])) {
	    $params['real_redirect'] = 'false';
	}

	return true;
}

/**
 * Get page components to view a redirect.
 *
 * @param int $guid GUID of a redirect entity.
 * @return array
 */
function phloor_redirect_get_page_content_read($guid = NULL) {
	$return = array();

	$redirect = get_entity($guid);

	// no header or tabs for viewing an individual redirect
	$return['filter'] = '';

	if (!phloor_redirect_instanceof($redirect)) {
		$return['content'] = elgg_echo('phloor_redirect:error:redirect_not_found');
		return $return;
	}

	$container = $redirect->getContainerEntity();
	$crumbs_title = $container->name;
	if (elgg_instanceof($container, 'group')) {
		elgg_push_breadcrumb($crumbs_title, "phloor_redirect/group/$container->guid/all");
	} else {
		elgg_push_breadcrumb($crumbs_title, "phloor_redirect/owner/$container->username");
	}

	elgg_push_breadcrumb($redirect->guid);

	$return['title']   = htmlspecialchars($redirect->title);
	$return['content'] = elgg_view_entity($redirect, array('full_view' => true));

    $return['entity'] = $redirect;

	return $return;
}

/**
 * Get page components to list a user's or all redirects.
 *
 * @param int $owner_guid The GUID of the page owner or NULL for all redirects
 * @return array
 */
function phloor_redirect_get_page_content_list($container_guid = NULL, $params = array()) {
	$return = array();

	$return['filter_context'] = ($container_guid == elgg_get_logged_in_user_guid()) ?
	        'mine' : 'all';

	$options = array(
		'full_view' => FALSE,
		'offset' => (int) max(get_input('offset', 0), 0),
		'limit' => (int) max(get_input('limit', 10), 0),
		'list_type_toggle' => TRUE,
		'pagination' => TRUE,
	);

	if ($container_guid) {
		// access check for closed groups
		group_gatekeeper();

		$options['container_guid'] = $container_guid;
		$container = get_entity($container_guid);
		if (!$container) {

		}
		$return['title'] = elgg_echo('phloor_redirect:title:user_phloor_redirects', array($container->name));

		$crumbs_title = $container->name;
		elgg_push_breadcrumb($crumbs_title);

		if (elgg_instanceof($container, 'group')) {
			$return['filter'] = false;
		}
	} else {
		$return['title'] = elgg_echo('phloor_redirect:title:all_phloor_redirects');
		elgg_pop_breadcrumb();
		elgg_push_breadcrumb(elgg_echo('phloor_redirect:phloor_redirects'));
	}

	// dont show button if were in admin mode.. looks stupid
	// and there is a form anyway
	if(!elgg_in_context('admin')) {
		elgg_register_title_button();
	}

	$redirects = phloor_redirect_get_redirect_entities($options);

	$list = elgg_view_entity_list($redirects, $options);

	if (!$list) {
		$return['content'] = elgg_echo('phloor_redirect:none');
	} else {
		$return['content'] = $list;
	}

	return $return;
}



/**
 * Get page components to edit/create a redirect
 *
 * @param string  $page     'edit' or 'new'
 * @param int     $guid     GUID of phloor_redirect or container
 * @return array
 */
function phloor_redirect_get_page_content_edit($page, $guid = 0) {

	$return = array(
		'filter' => '',
	);

	$vars = array();
	$vars['id'] = 'phloor_redirect-post-edit';
	$vars['name'] = 'phloor_redirect_post';
	$vars['class'] = 'elgg-form-alt';

	if ($page == 'edit') {
		$redirect = get_entity((int)$guid);

		$title = elgg_echo('phloor_redirect:edit');
		if (phloor_redirect_instanceof($redirect) && $redirect->canEdit()) {
			$vars['entity'] = $redirect;

			elgg_push_breadcrumb($redirect->guid, $redirect->getURL());
			elgg_push_breadcrumb(elgg_echo('edit'));

			$form_vars = array();
			$body_vars = phloor_redirect_prepare_form_vars($redirect);

			$title .= ": {$redirect->title}";
			$content = elgg_view_form('phloor_redirect/save', $form_vars, $body_vars);
			$sidebar = '';

			$return['entity'] = $redirect;
		} else {
			$content = elgg_echo('phloor_redirect:error:cannot_edit_redirect');
			$sidebar = '';
		}
	} else {
		elgg_push_breadcrumb(elgg_echo('phloor_redirect:add'));

		$form_vars = array();
		$body_vars = phloor_redirect_prepare_form_vars(null);

		$content = elgg_view_form('phloor_redirect/save', $form_vars, $body_vars);
		$title = elgg_echo('phloor_redirect:add');
		$sidebar = '';
	}

	$return['title'] = $title;
	$return['content'] = $content;
	$return['sidebar'] = $sidebar;
	$return['layout']  = 'one_column';
	return $return;
}

/**
 * Pull together redirect variables for the save form
 *
 * @param PhloorRedirect       $redirect
 * @return array
 */
function phloor_redirect_prepare_form_vars($redirect = null) {
	$defaults = phloor_redirect_default_vars();

	// input names => defaults
	$params = array(
		'entity' => $redirect,
	);

	$values = array_merge($defaults, $params);

	if ($redirect) {
		foreach (array_keys($values) as $field) {
			if (isset($redirect->$field)) {
				$values[$field] = $redirect->$field;
			}
		}
	}

	if (elgg_is_sticky_form('phloor_redirect')) {
		$sticky_values = elgg_get_sticky_values('phloor_redirect');
		foreach ($sticky_values as $key => $value) {
			$values[$key] = $value;
		}
	}

	elgg_clear_sticky_form('phloor_redirect');

	return $values;
}

/**
 *
 * Enter description here ...
 * @param unknown_type $params
 */
function phloor_redirect_get_redirect_entities($params = array()) {
	$return = array();

	$default = array(
		'type'    => 'object',
		'subtype' => 'phloor_redirect',
		'offset'  => 0,
		'limit'   => 0,
	);

	$options = array_merge($default, $params);

	$return = elgg_get_entities_from_metadata($options);

	return $return;
}
