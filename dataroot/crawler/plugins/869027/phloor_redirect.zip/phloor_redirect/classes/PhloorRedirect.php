<?php
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

/**
 *
 */
class PhloorRedirect extends ElggObject {

	public function __construct($guid = null) {
		parent::__construct($guid);
	}

	/**
	 * Set subtype to phloor_redirect.
	 */
	protected function initializeAttributes() {
		parent::initializeAttributes();

		$this->attributes['subtype'] = "phloor_redirect";
		$this->attributes['comments_on'] = 'Off';
	}

	public function save() {
	    if(empty($this->title)) {
	        $this->title = elgg_echo('item:object:phloor_redirect') . uniqid(' #');
	    }

	    return parent::save();
	}


	/**
	 * get the url for the icon
	 */
	public function getIconURL($size = 'tiny') {
		$guid = $this->getGUID();

		$sizes = array('topbar' , 'tiny', 'small', 'medium');
		if(!in_array($size, $sizes)) {
			$size = 'tiny';
		}

		$image_url = "mod/phloor_redirect/graphics/icons/default/$size.png";
		return elgg_normalize_url($image_url);
	}

	function circumventWalledGarden() {
	    return phloor_str_is_true($this->walledgarden);
	}

	function isRealRedirect() {
	    return phloor_str_is_true($this->real_redirect);
	}

	public function getReason() {
		return $this->reason;
	}

	public function setReason($reason) {
		$this->reason = $reason;
	}

	/**
	 * from
	 */
	public function getFrom($replace_special_pattern = false) {
		if($replace_special_pattern) {
			return $this->getModifiedFrom();
		}
		return $this->from;
	}
	public function setFrom($from) {
		$this->from = $from;
	}

	public function getModifiedFrom() {
		return phloor_redirect_replace_sepcial_pattern($this->from, 'from', $this->site_guid);
	}

	/**
	 * to
	 */
	public function getTo($replace_special_pattern = false) {
		if($replace_special_pattern) {
			return $this->getModifiedTo();
		}
		return $this->to;
	}
	public function setTo($to) {
		$this->to = $to;
	}
	public function getModifiedTo() {
		return phloor_redirect_replace_sepcial_pattern($this->to, 'to', $this->site_guid);
	}


	/**
	 * page_from
	 */
	public function getPageFrom($replace_special_pattern = false) {
		if($replace_special_pattern) {
			return $this->getModifiedPageFrom();
		}
		return $this->page_from;
	}
	public function setPageFrom($from) {
		$this->page_from = $from;
	}

	// maybe need to replace %username%
	public function getModifiedPageFrom() {
		return phloor_redirect_replace_sepcial_pattern($this->page_from, 'page_from', $this->site_guid);
	}

	/**
	 * page_to
	 */
	public function getPageTo($replace_special_pattern = false) {
		if($replace_special_pattern) {
			return $this->getModifiedPageTo();
		}
		return $this->page_to;
	}
	public function setPageTo($to) {
		$this->page_to = $to;
	}

	// maybe need to replace %username%
	public function getModifiedPageTo() {
		return phloor_redirect_replace_sepcial_pattern($this->page_to, 'page_to', $this->site_guid);
	}

}