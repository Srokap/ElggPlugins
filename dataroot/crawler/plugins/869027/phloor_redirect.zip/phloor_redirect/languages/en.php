<?php
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$english = array(
    'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
	'admin:appearance:phloor_redirect' => 'Redirects',

	'phloor_redirect' => 'Redirects',
	'phloor_redirect:redirect' => 'Redirect',
	'phloor_redirect:redirects' => 'Redirects',
	'phloor_redirect:phloor_redirect' => 'Redirect',
	'phloor_redirect:phloor_redirects' => 'Redirects',

	'item:object:phloor_redirect' => 'Redirect',

	'phloor_redirect:target:_self'  => 'Open in same tab',
	'phloor_redirect:target:_blank' => 'Open in new tab',

	'phloor_redirect:admin:appearance:title' => "Redirect overview page",
	'phloor_redirect:admin:appearance:description' => "Here you can manage the menus and redirects of your site. ",
	'phloor_redirect:admin:appearance:entity_count' => "Redirect count: %s ",
	'phloor_redirect:admin:appearance:new_redirect:title' => 'Create new redirect',

	'phloor_redirect:from'         => 'Source',
	'phloor_redirect:to'           => 'Destination',
	'phloor_redirect:reason'       => 'Reason',
	'phloor_redirect:access_id'    => 'Read access',
	'phloor_redirect:walledgarden' => 'Circumvent walled garden? ',
	'phloor_redirect:description'  => 'Description',

	'phloor_redirect:form:from'         => 'Source*',
	'phloor_redirect:form:to'           => 'Destination*',
	'phloor_redirect:form:reason'       => 'Reason',
	'phloor_redirect:form:access_id'    => 'Read access',
	'phloor_redirect:form:walledgarden' => 'Circumvent walled garden? ',
	'phloor_redirect:form:description'  => 'Description',

	'phloor_redirect:from:description'         => 'Enter the source url (this may also be a regex). Special patterns: %username%, %wwwroot%',
	'phloor_redirect:to:description'           => 'Enter target url. Special patterns: %username%, %wwwroot%',
	'phloor_redirect:reason:description'       => '(optional) Enter the reason why the user was redirected - this message will be visible to the user.',
	'phloor_redirect:walledgarden:description' => '(optional) If you this this box the walled garden will be circumvented - activate only if you have restricted the site the logged in users. You must not use "%wwwroot%" or "http://" at the beginning of the source or the destination. ',
	'phloor_redirect:access_id:description'    => ' ',
	'phloor_redirect:description:description'  => '(optional) Append a description for other admins. This message may the idea behind the redirect or other related information. This message will not be shown to the user. ',

	'phloor_redirect:message:saved' => 'Redirect as been successfully created. ',
	'phloor_redirect:message:deleted_redirect' => 'Redirect has been successfully deleted. ',
	'phloor_redirect:error:cannot_save' => 'Redirect can not be saved. ',
	'phloor_redirect:error:cannot_edit_redirect' => 'Redirect can not be edited. ',
	'phloor_redirect:error:cannot_delete_redirect' => 'Redirect can not be deleted. ',

	'phloor_redirect:error:redirect_not_found' => 'Redirect not found. ',
	'phloor_redirect:error:missing:from' => 'Please insert a source url. ',
	'phloor_redirect:error:missing:to' => 'Please insert a target url. ',
	'phloor_redirect:error:source_equals_destination' => 'Invalid values - source cannot be equal to the destination! ',

	'phloor_redirect:menu:entity:circumvents_walled_garden' => 'Circumvents Walled Garden',
	'phloor_redirect:menu:entity:real_redirect' => 'Real Redirect',
	'phloor_redirect:menu:entity:switch_page_handler' => 'Switch Page Handler',

	'phloor_redirect:entity:message:circumvents_walled_garden' => 'This redirect object circumvents the walled garden settings. ',
	'phloor_redirect:entity:message:real_redirect' => 'This redirect object will answer any matching request with the status code "302 Moved Temporarily". ',
	'phloor_redirect:entity:message:switch_page_handler' => 'This redirect object will switch the page handler according to the values. ',

	'phloor_redirect:entity:messages:title' => 'Notice',

	'phloor_redirect:title:all_phloor_redirects' => 'All redirects',
	'phloor_redirect:title:all_phloor_redirect'  => 'All redirects',
	'phloor_redirect:title:friends' => 'Friends redirects',
	'phloor_redirect:title:user_phloor_redirect'  => 'Your redirects',
	'phloor_redirect:title:user_phloor_redirects' => 'Your redirects',

	'phloor_redirect:edit' => 'Edit',
	'phloor_redirect:add' => 'Add redirect',
	'phloor_redirect:none' => 'No redirects found. ',

	'phloor_redirect:usage:information' => 'If the prefix "%wwwroot%" is used in the source or destination field the redirect will send "302 Temporarily Moved"-Headers. If you on the other hand just write the page handler or a regex',
	'phloor_redirect:usage:information:specialpatternusage' => 'The pattern %wwwroot% will be replaced with the site url, the pattern %username% will be replaced with the current logged in users username. If you use the pattern %username% you have to restrict the read access to logged in users. ',
);

add_translation("en", $english);
