<?php
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

// only admins can delete redirect entities
admin_gatekeeper();

$redirect_guid = get_input('guid');
$redirect = get_entity($redirect_guid);

$url = elgg_get_site_url() . phloor_redirect_url_handler($redirect);

if (phloor_redirect_instanceof($redirect) && $redirect->canEdit()) {
	$container = get_entity($redirect->container_guid);

	if ($redirect->delete()) {
		system_message(elgg_echo('phloor_redirect:message:deleted_redirect'));

		// if DID NOT came from object site.. refere him back..
		if(strpos($url, REFERER) === 0) {
			forward(REFERER);
		}

		$context = get_input('context', elgg_get_context());
		// if context was admin.. redirect to the REFERER
		if(elgg_is_admin_logged_in() && $context == 'admin') {
			forward($_SERVER['HTTP_REFERER']);
		}

		/*
		if (elgg_instanceof($container, 'group')) {
			forward("phloor_redirect/group/$container->guid/all");
		} else {
			forward("phloor_redirect/owner/$container->username");
		}*/
		forward("phloor_redirect/all");

		exit();
	} else {
		register_error(elgg_echo('phloor_redirect:error:cannot_delete_redirect'));
	}
} else {
	register_error(elgg_echo('phloor_redirect:error:redirect_not_found'));
}

forward(REFERER);