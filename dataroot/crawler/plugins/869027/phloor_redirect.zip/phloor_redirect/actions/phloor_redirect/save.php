<?php
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2012 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

// only admins are allowed to use this action
admin_gatekeeper();

// store errors to pass along
$error = FALSE;
$error_forward_url = REFERER;

$redirect = NULL;
$new_redirect = TRUE;

// edit or create a new entity
$guid = get_input('guid');
if ($guid) {
	$redirect = get_entity($guid);

	//register_error($entity->subtype . ' - ' . $entity->type);
	if (!phloor_redirect_instanceof($redirect) || !$redirect->canEdit()) {
		register_error(elgg_echo('phloor_redirect:error:redirect_not_found'));
		forward(get_input('forward', REFERER));
		exit;
	}

	$new_redirect = FALSE;
} else {
	$redirect = new PhloorRedirect();
	$new_redirect = TRUE;
}

// get form inputs from POST var
$params = phloor_redirect_get_input_vars();

// save settings and display success message
if (phloor_redirect_save_vars($redirect, $params)) {
	// remove sticky form entries
	elgg_clear_sticky_form('phloor_redirect');
	system_message(elgg_echo('phloor_redirect:message:saved'));

	$context = get_input('context', elgg_get_context());
	// if context was admin.. redirect to the REFERER
	if(elgg_is_admin_logged_in() && $context == 'admin') {
		forward($_SERVER['HTTP_REFERER']);
	}
	else {
		forward($redirect->getURL());
	}
}
// ... or display an error message on failures.
else {
	register_error(elgg_echo('phloor_redirect:error:cannot_save'));
	forward($_SERVER['HTTP_REFERER']);
}
