<?php

if (get_subtype_id('object', 'phloor_redirect')) {
	update_subtype('object', 'phloor_redirect', 'PhloorRedirect');
} else {
	add_subtype('object', 'phloor_redirect', 'PhloorRedirect');
}