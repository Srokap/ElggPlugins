<?php 
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>

.phloor-redirect-unmodified {
    color: #555555;
}

.elgg-page-admin .elgg-form-phloor-redirect-save {
/*	border:1px solid black; */
}

.phloor-redirect-admin-new-redirect {
padding: 20px 0 0 10px;
}


.elgg-menu-filter {
    border-bottom-color: #CCCCCC;
    border-bottom-style: solid;
    border-bottom-width: 2px;
    display: table;
    margin-bottom: 5px;
    width: 100%;
}
.elgg-menu-filter > li {
    -moz-border-bottom-colors: none;
    -moz-border-image: none;
    -moz-border-left-colors: none;
    -moz-border-right-colors: none;
    -moz-border-top-colors: none;
    background-attachment: scroll;
    background-clip: border-box;
    background-color: #EEEEEE;
    background-image: none;
    background-origin: padding-box;
    background-position: 0 0;
    background-repeat: repeat;
    background-size: auto auto;
    border-bottom-color: -moz-use-text-color;
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
    border-bottom-style: none;
    border-bottom-width: 0;
    border-left-color-ltr-source: physical;
    border-left-color-rtl-source: physical;
    border-left-color-value: #CCCCCC;
    border-left-style-ltr-source: physical;
    border-left-style-rtl-source: physical;
    border-left-style-value: solid;
    border-left-width-ltr-source: physical;
    border-left-width-rtl-source: physical;
    border-left-width-value: 2px;
    border-right-color-ltr-source: physical;
    border-right-color-rtl-source: physical;
    border-right-color-value: #CCCCCC;
    border-right-style-ltr-source: physical;
    border-right-style-rtl-source: physical;
    border-right-style-value: solid;
    border-right-width-ltr-source: physical;
    border-right-width-rtl-source: physical;
    border-right-width-value: 2px;
    border-top-color: #CCCCCC;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    border-top-style: solid;
    border-top-width: 2px;
    float: left;
    margin-bottom: 0;
    margin-left: 10px;
    margin-right: 0;
    margin-top: 0;
}
.elgg-menu-filter > li:hover {
    background-attachment: scroll;
    background-clip: border-box;
    background-color: #DEDEDE;
    background-image: none;
    background-origin: padding-box;
    background-position: 0 0;
    background-repeat: repeat;
    background-size: auto auto;
}
.elgg-menu-filter > li > a {
    color: #999999;
    display: block;
    height: 21px;
    padding-bottom: 0;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 3px;
    text-align: center;
    text-decoration: none;
}
.elgg-menu-filter > li > a:hover {
    background-attachment: scroll;
    background-clip: border-box;
    background-color: #DEDEDE;
    background-image: none;
    background-origin: padding-box;
    background-position: 0 0;
    background-repeat: repeat;
    background-size: auto auto;
    color: #4690D6;
}
.elgg-menu-filter > .elgg-state-selected {
    background-attachment: scroll;
    background-clip: border-box;
    background-color: white;
    background-image: none;
    background-origin: padding-box;
    background-position: 0 0;
    background-repeat: repeat;
    background-size: auto auto;
    border-bottom-color: #CCCCCC;
    border-left-color-ltr-source: physical;
    border-left-color-rtl-source: physical;
    border-left-color-value: #CCCCCC;
    border-right-color-ltr-source: physical;
    border-right-color-rtl-source: physical;
    border-right-color-value: #CCCCCC;
    border-top-color: #CCCCCC;
}
.elgg-menu-filter > .elgg-state-selected > a {
    background-attachment: scroll;
    background-clip: border-box;
    background-color: white;
    background-image: none;
    background-origin: padding-box;
    background-position: 0 0;
    background-repeat: repeat;
    background-size: auto auto;
    position: relative;
    top: 2px;
}