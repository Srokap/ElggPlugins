<?php
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * View for phloor_redirect objects
 *
 */

$redirect = elgg_extract('entity', $vars, FALSE);
if (!phloor_redirect_instanceof($redirect)) {
	return TRUE;
}

$metadata = $vars['metadata'];
$subtitle =	$vars['subtitle'];

$variable_output = '';

// source url
$from_label          = elgg_echo("phloor_redirect:from");
$from_value          = $redirect->getFrom(false);
$modified_from_value = $redirect->getFrom(true);

// add modified url value if it differs from the value
if(strcmp($modified_from_value,$from_value) != 0) {
	$modified_from_value .= <<<HTML
		<span class="phloor-redirect-unmodified" name="phloor-redirect-{$redirect->guid}-unmodified-from">
			($from_value)
		</span>
HTML;
}

// target url
$to_label          = elgg_echo("phloor_redirect:to");
$to_value          = $redirect->getTo(false);
$modified_to_value = $redirect->getTo(true);

// add modified url value if it differs from the value
if(strcmp($modified_to_value,$to_value) != 0) {
	$modified_to_value .= <<<HTML
		<span class="phloor-redirect-unmodified" name="phloor-redirect-{$redirect->guid}-unmodified-to">
			($to_value)
		</span>
HTML;
}

$reason_module = "";
$description_module = "";
if (!empty($redirect->reason)) {
    $reason_module .= elgg_view_module('popup', elgg_echo('phloor_redirect:reason'), $redirect->reason);
}
if (!empty($redirect->description)) {
    $description_module .= elgg_view_module('popup', elgg_echo('phloor_redirect:description'), $redirect->description);
}

$variable_output .= <<<HTML
	<div name="phloor-redirect-entity-container" class="phloor-redirect-content">
		<div><label for="phloor-redirect-{$redirect->guid}-from">$from_label</label>:
		<span name="phloor-redirect-{$redirect->guid}-from">$modified_from_value</span></div>

		<div><label for="phloor-redirect-{$redirect->guid}-to">$to_label</label>:
		<span name="phloor-redirect-{$redirect->guid}-to">$modified_to_value</span></div>
	</div>

    <div class="phloor-redirect-entity-reason-container">$reason_module</div>
    <div class="phloor-redirect-entity-description-container">$description_module</div>
HTML;

//$body = $image . $variables_output;
$body = $variable_output;

$params = array(
		'entity' => $redirect,
		'title' => false,
		'metadata' => $metadata,
		'subtitle' => $subtitle,
);

$params = $params + $vars;

$summary = elgg_view('object/elements/summary', $params);

// display element full
echo elgg_view('object/elements/full', array(
		'summary' => $summary,
		'body' => $body,
		'icon' => elgg_view_entity_icon($redirect, 'small'),
));
