<?php 
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php 
// check for admin
admin_gatekeeper();

$title = elgg_view_title(elgg_echo('phloor_redirect:admin:appearance:title')); 
$description = elgg_echo('phloor_redirect:admin:appearance:description'); 

$count = phloor_redirect_get_redirect_entities(array('count' => true));
$entity_count = elgg_echo('phloor_redirect:admin:appearance:entity_count', array($count)); 

// get page content list (just like in normal view)
$menu_name = get_input('menu_name', 'all', true);
$content_list = phloor_redirect_get_page_content_list(null, array(
	'menu_name' => $menu_name,
));

$redirect_list = $content_list['content'];
$filter        = $content_list['filter'];

if(isset($content_list['filter_override'])) {
	$filter  = $content_list['filter_override'];
}

$new_redirect_title = elgg_view_title(elgg_echo('phloor_redirect:admin:appearance:new_redirect:title'));

// view form
$body_vars = phloor_redirect_prepare_form_vars();
// overwrite the menu_name of the form to the currently viewed menu..
// default back to site menu if 'all' entities are viewed
$body_vars['menu_name'] = (strcmp($menu_name, 'all') == 0) ? 'site' : $menu_name;

$vars['enctype'] = 'multipart/form-data';
$new_redirect_form = elgg_view_form('phloor_redirect/save', $vars, $body_vars);
unset($vars['enctype']);

echo <<<___HTML
{$title}
<p>{$description}</p>
<div>
{$filter}
{$redirect_list}
<p>{$entity_count}</p>
</div>
<div class="phloor-redirect-admin-new-redirect">
<p>{$new_redirect_title}</p>
{$new_redirect_form}
</div>
___HTML;

?>