<?php
/*****************************************************************************
 * Phloor Redirect                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

$guid = elgg_extract('guid', $vars, false);
$redirect = get_entity($guid);

$general_information = elgg_echo('phloor_redirect:usage:information');
$special_pattern_usage_information = elgg_echo('phloor_redirect:usage:information:specialpatternusage');

$action_buttons = '';
$delete_link = '';

if ($guid && phloor_redirect_instanceof($redirect)) {
	// add a delete button if editing
	$delete_url = "action/phloor_redirect/delete?guid={$guid}";
	$delete_link = elgg_view('output/confirmlink', array(
		'href' => $delete_url,
		'text' => elgg_echo('delete'),
		'class' => 'elgg-button elgg-button-delete elgg-state-disabled float-alt'
	));
}


$save_button = elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'save',
));
$action_buttons = $save_button . $delete_link;

$form_content = '';
$variables = elgg_get_config('phloor_redirect');
foreach ($variables as $name => $input_view) {
	if(!elgg_view_exists($input_view)) {
		// this should really never happen as the input_views are stored in the
		// config datastructure and its defined when the plugin is activated (start.php - run_once..)
		//
		register_error(elgg_echo('phloor:error:view:not_found', array($input_view)));
		continue;
	}

	// dont show "circumvent walled garden"
    // if walled garden is not activated!
	if(strcmp("walledgarden", $name) == 0) {
        global $CONFIG;

		if (!$CONFIG->walled_garden) {
		    continue;
		}
	}

	// get label
	$label = elgg_echo("phloor_redirect:form:$name");
	$input = elgg_view($input_view, array(
		'name' => $name,
		'value' => $vars[$name],
	));
	$description = elgg_echo("phloor_redirect:$name:description");

	// append to form content
	$form_content .= <<<HTML
	<div>
		<label for="$name">$label</label>: $input
		$description
	</div>
HTML;
}

$categories_input = elgg_view('input/categories', $vars);

// hidden inputs
$container_guid_input = elgg_view('input/hidden', array('name' => 'container_guid', 'value' => elgg_get_page_owner_guid()));
$guid_input = elgg_view('input/hidden', array('name' => 'guid', 'value' => $guid));
$context_input = elgg_view('input/hidden', array('name' => 'context', 'value' => elgg_get_context()));



// create the content content
// constists of
// -> special pattern information
// -> form content
// -> (hidden) form foot
$content = <<<___HTML
	$special_pattern_usage_information
	$form_content
	$categories_input

	<div class="elgg-foot">
		$context_input
		$guid_input
		$container_guid_input

		$action_buttons
	</div>
___HTML;


// output form content
echo $content;

