/**
 * Phloor Redirect
 * 
 * @package phloor_redirect
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 2012 by 13net
 * @link http://www.13net.at
 */

/**
 * Description
 */
Redirect management for your Elgg site.

This plugin enables rerouting of URLs. Administrators are able to 
create and manage 'Redirect' entities. This is a beta plugin.
	
One can define a source and a destination url. If the source url
matches with one of the entities a user will be redirected to the 
destination url accordingly. You ca also use a regular 
expression (regex) or some special patterns for the source url.

Special Patterns are:
- %wwwroot% => will be replaced with Elggs domain
- %username% => will be replaced with the current logged in username

If you use full qualified url (e.g. "%wwwroot%XYZ" or "http://example.com/XYZ") 
the request will actually be forwarded with status code 
"302 - Moved Temporarily". Otherwise (e.g. "pages/view/.*/.*" => "activity") 
only the page handler is switched.

What you can do:
- create real redirects
- reroute requests (switch page handler)
- Use regular expressions in source url
- different read acces levels (e.g. for logged in users only)
- circumvent walled garden for specific page

What you can NOT do:
- transfer parameters from source to destination
 (thus no automated circumvention of walled garden) 



/**
 * Examples
 */
1)
Source:      %wwwroot%REDIRECT_TO_GOOGLE
Destination: http://www.google.com

2)
Source:      %wwwroot%REAL_REDIRECT
Destination: %wwwroot%activity

3)
Source:      SWITCH_PAGE_HANDLER
Destination: activity

4)
4)

Example problem. You want to change the index page of your site quickly. 
Question. How can that be solved with this plugin? Answer. You have to create 2 redirect objects!

The first is a real redirect with:
    Source:      %wwwroot%
    Destination: %wwwroot%/welcome

The second one is with:
    Source:      welcome
    Destination: pages/view/34828/welcome-to-our-website

This will route "www.yourdomain.com" to "www.yourdomain.com/pages/view/34828/welcome-to-our-website" - 
in the address bar the url will be "www.yourdomain.com/welcome".

/**
 * Languages
 */
English
German (coming soon!)


