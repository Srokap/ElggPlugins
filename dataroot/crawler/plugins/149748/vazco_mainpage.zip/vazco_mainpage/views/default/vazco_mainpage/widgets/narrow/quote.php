<div class="index_box">
	<h2><?php echo elgg_echo('custom:quote');?></h2>
	<div class="search_listing">
	<?php 
		echo elgg_echo('vazco_mainpage:notside');
	?>
	</div>
</div>