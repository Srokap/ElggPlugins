<div class="index_box">
	<h2><?php echo elgg_echo('custom:groups:latestdiscussion');?></h2>
	<div class="search_listing">
	<?php 
		echo elgg_echo('vazco_mainpage:fullversion');
	?>
	</div>
</div>