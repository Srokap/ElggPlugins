How to use the plugin:

1. Disable the custom_index plugin
2. Enable, and go to 'mainpage widgets' option on the submenu of Administration page.
3. In case you want to use the background for the main page, make sure the mod/vazco_mainpage/graphics/bckg directory has write access (best, 777).