<?php
	/**
	 * Translators
	 * Olga Ivannikova
	 * Pillgrim
	 * 
	 */

	$russian = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Сайты',
	
		/**
		 * Sessions
		 */
			
			'login' => "Войти",
			'loginok' => "Вы вошли.",
			'loginerror' => "Пароль или имя не найдены. Система не может авторизовать вас.",
	
			'logout' => "Выйти",
			'logoutok' => "Вы вышли из системы.",
			'logouterror' => "Ошибка при выходе. Пожалуйста попробуйте еще раз.",
	
		/**
		 * Errors
		 */
			'exception:title' => "Добро пожаловать в Elgg.",
	
			'InstallationException:CantCreateSite' => "Не удалось создать ElggSite по умолчанию со следующими настройками Имя:%s, Url: %s",
		
			'actionundefined' => "Указанное действие (%s) не зарегистрировано в системе.",
			'actionloggedout' => "Извините, что бы сделать это необходимо войти в систему.",
	
			'notfound' => "Указанный объект не найден, или у вас нет прав на доступ к нему.",
			
			'SecurityException:Codeblock' => "Доступ на выполнение привилегированного участка кода запрещён",
			'DatabaseException:WrongCredentials' => "Невозможно установить соединение с базой данных %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Невозможно выбрать базу данных '%s', убедитесь что она существует и у вас есть к ней доступ.",
			'SecurityException:FunctionDenied' => "Доступ к привилегированной функции '%s' запрещён.",
			'DatabaseException:DBSetupIssues' => "Произошли следующие проблемы: ",
			'DatabaseException:ScriptNotFound' => "Невозможно найти запрошенный скрипт в %s.",
			
			'IOException:FailedToLoadGUID' => "Не удалось загрузить %s из GUID:%d",
			'InvalidParameterException:NonElggObject' => "Передан не-ElggObject в конструктор ElggObject!",
			'InvalidParameterException:UnrecognisedValue' => "Неизвестное значение предано в конструктор.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d недействителен %s",
			
			'PluginException:MisconfiguredPlugin' => "Приложение %s установленно некорректно.",
			
			'InvalidParameterException:NonElggUser' => "Передан не-ElggUser в конструктор ElggUser!",
			
			'InvalidParameterException:NonElggSite' => "Передан не-ElggSite в конструктор ElggSite!",
			
			'InvalidParameterException:NonElggGroup' => "Передан не--ElggGroup в конструктор ElggGroup!",
	
			'IOException:UnableToSaveNew' => "Невозможно сохранить новый %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID не был указан во врему экспорта, этого никогда не должно было произойти.",
			'InvalidParameterException:NonArrayReturnValue' => "В функцию сериализации Сущность передан параметр returnvalue не являющийся массивом",
			
			'ConfigurationException:NoCachePath' => "Путь к кэшу пуст!",
			'IOException:NotDirectory' => "%s не является директорией.",
			
			'IOException:BaseEntitySaveFailed' => "Невозможно сохранить базовую информацию об новой сущности!",
			'InvalidParameterException:UnexpectedODDClass' => "import() передал неожиданный класс ODD",
			'InvalidParameterException:EntityTypeNotSet' => "Тип сущности должен быть установлен.",
			
			'ClassException:ClassnameNotClass' => "%s не %s.",
			'ClassNotFoundException:MissingClass' => "Класс '%s' не найден, возможно не установлен нужны плагин?",
			'InstallationException:TypeNotSupported' => "Тип %s не поддерживается. Это указывает на проблемы в вашей копии Elgg, скорее всего после неудачного обновления.",

			'ImportException:ImportFailed' => "Невозможно импортировать элемент %d",
			'ImportException:ProblemSaving' => "При сохранении %s случилась ошибка",
			'ImportException:NoGUID' => "Создана новая сущность без GUID, этого не должно никогда случаться.",
			
			'ImportException:GUIDNotFound' => "Сущность '%d' не найдена.",
			'ImportException:ProblemUpdatingMeta' => "При обновлении свойства '%s' сущности '%d' произошла ошибка",
			
			'ExportException:NoSuchEntity' => "Нет такой сущности GUID:%d", 
			
			'ImportException:NoODDElements' => "Не найдены OpenDD элементы в импортированных данных, import не удался.",
			'ImportException:NotAllImported' => "Не все элементы были импортированы.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Неизвестный режим файла  '%s'",
			'InvalidParameterException:MissingOwner' => "Все файлы должны иметь владельца!",
			'IOException:CouldNotMake' => "Невозможно создать %s",
			'IOException:MissingFileName' => "Необходимо указать имя перед открытием файла.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore не найден или имя класса не сохранёно с файлом!",
			'NotificationException:NoNotificationMethod' => "Не указан метод уведомления.",
			'NotificationException:NoHandlerFound' => "Нет обработчика для '%s', или его не возможно вызвать.",
			'NotificationException:ErrorNotifyingGuid' => "Случилась ошибка при уведомлении %d",
			'NotificationException:NoEmailAddress' => "Невозможно получить email адрес для GUID:%d",
			'NotificationException:MissingParameter' => "Не хватает обязательного параметра '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where часть запроса содержит несовместимые с WhereQueryComponent компоненты",
			'DatabaseException:SelectFieldsMissing' => "Нет полей в SELECT запросе",
			'DatabaseException:UnspecifiedQueryType' => "В запросе не указан тип запроса.",
			'DatabaseException:NoTablesSpecified' => "В запросе не указаны таблицы.",
			'DatabaseException:NoACL' => "В запросе не указаны настройки доступа",
			
			'InvalidParameterException:NoEntityFound' => "Сущность не найдена, она либо не существует, либо у вас нет доступа к ней.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s не найден, либо у вас нет доступа к нему.",
			'InvalidParameterException:IdNotExistForGUID' => "Извините, '%s' не существует для guid:%d",
			'InvalidParameterException:CanNotExportType' => "Извините, не знаю как экспортировать '%s'",
			'InvalidParameterException:NoDataFound' => "Данные не найдены.",
			'InvalidParameterException:DoesNotBelong' => "Не принадлежит сущности.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Не принадлежит сущности и не указывает на сущность.",
			'InvalidParameterException:MissingParameter' => "Не хватает параметра, необходимо указать GUID.",
			
			'SecurityException:APIAccessDenied' => "Извините, доступ к API был отключен администратором.",
			'SecurityException:NoAuthMethods' => "Не удалось найти подходящего метода для авторизации данного API запроса.",
			'APIException:ApiResultUnknown' => "Тип результата API запроса неопределён, этого не должно было никогда случиться.", 
			
			'ConfigurationException:NoSiteID' => "Не указан ID сайта.",
			'InvalidParameterException:UnrecognisedMethod' => "Неизвестный метод '%s'",
			'APIException:MissingParameterInMethod' => "Не хватает параметра %s в методе %s",
			'APIException:ParameterNotArray' => "%s не является массивом.",
			'APIException:UnrecognisedTypeCast' => "Неизвестный тип при касте %s переменной '%s' в методе '%s'",
			'APIException:InvalidParameter' => "Невалидный параметр найден для '%s' в методе '%s'.",
			'APIException:FunctionParseError' => "Ошибка парсинга %s(%s).",
			'APIException:FunctionNoReturn' => "%s(%s) не вернул значения.",
			'SecurityException:AuthTokenExpired' => "Авторизационный token не передан, не валиден или просрочен.",
			'CallException:InvalidCallMethod' => "%s должен вызываться при помощи '%s'",
			'APIException:MethodCallNotImplemented' => "Метод '%s' не существует.",
			'APIException:AlgorithmNotSupported' => "Алгоритм '%s' не поддерживается или выключен.",
			'ConfigurationException:CacheDirNotSet' => "Директория для кэша 'cache_path' не установлена.",
			'APIException:NotGetOrPost' => "Метод должен быть GET или POST",
			'APIException:MissingAPIKey' => "Не хватает X-Elgg-apikey HTTP заголовка",
			'APIException:MissingHmac' => "Не хватает X-Elgg-hmac заголовка",
			'APIException:MissingHmacAlgo' => "Не хватает X-Elgg-hmac-algo заголовка",
			'APIException:MissingTime' => "Не хватает X-Elgg-time заголовка",
			'APIException:TemporalDrift' => "X-Elgg-time в слишком отдалённом будущем.",
			'APIException:NoQueryString' => "Нет данных в строке запроса",
			'APIException:MissingPOSTHash' => "Не хватает X-Elgg-posthash заголовка",
			'APIException:MissingPOSTAlgo' => "Не хватает X-Elgg-posthash_algo заголовка",
			'APIException:MissingContentType' => "Не указан тип содержимого для POST запроса",
			'SecurityException:InvalidPostHash' => "Hash для POST данных не валиден - ождался %s, а получен %s.",
			'SecurityException:DupePacket' => "Подпись пакета повторяется.",
			'SecurityException:InvalidAPIKey' => "Не валидный или пустой API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Вызов метода '%s' пока не поддерживается.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC вызов метода '%s' не поддерживается.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Метод '%s' вернул неожиданный результат.",
			'CallException:NotRPCCall' => "Вызов не похож на валидный XML-RPC запрос",
	
			'PluginException:NoPluginName' => "Приложение не найдено",
	
			'ConfigurationException:BadDatabaseVersion' => "База данных не соответствует требованиям Elgg. Пожалуйста, проконсультируйтесь с документацией.",
			'ConfigurationException:BadPHPVersion' => "Необходим PHP версии не менее 5.2 что бы запустить Elgg.",
			'configurationwarning:phpversion' => "Elgg нуждается по крайней мере в PHP версии 5.2, возможно будет работать с ограничениями на 5.1.6. Используйте на ваш страх и риск.",
			
	
			'InstallationException:DatarootNotWritable' => "Директория для данных %s не имеет прав на запись.",
			'InstallationException:DatarootUnderPath' => "Директория для данных %s должна находится вне пути, в котором находится Elgg.",
			'InstallationException:DatarootBlank' => "Директория для данных не указана.",

			'SecurityException:authenticationfailed' => "Пользователь не может быть авторизован",
			'CronException:unknownperiod' => '%s не является правильным периодом.',
			
			'system.api.list' => "Выводит список всех доступных API вызовов в системе.",
			'auth.gettoken' => "Этот вызов API позволяет пользователю войти в систему, возвращая token авторизации, который может быть использован вместо имени пользователя и пароля",

	
		/**
		 * User details
		 */
			'name' => "Отображаемое имя",
			'email' => "Адрес электронной почты",
			'username' => "Логин",
			'password' => "Пароль",
			'passwordagain' => "Пароль (повтор для проверки)",
			'admin_option' => "Сделать этого пользователя администратором?",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "Только себе",
			'ACCESS_LOGGED_IN' => "Зарегистрированным пользователям",
			'ACCESS_PUBLIC' => "Всем",
			'PRIVATE' => "Только себе",
			'LOGGED_IN' => "Зарегистрированным пользователям",
			'PUBLIC' => "Всем",
			'access' => "Доступ",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Главная",
			'dashboard:configure' => "Настроить вид",
			'dashboard:nowidgets' => "Это Ваша главная страница. Нажмите 'Редактировать' что бы добавить виджеты, позволяющие следить за происходящим в системе.",

			'widgets:add' => 'Добавить виджеты на вашу страницу',
			'widgets:add:description' => "Выбирите интересующие вас виджеты перетащив их мышью из <b>Галлереи</b> в правой части страницы в любую из 3-х колонок ниже, и расположите в том порядке, в котором они должны отображаться.

Чтобы удалить виджет, переместите его обратно в <b>Галлерею</b>.",
			'widgets:position:fixed' => '(Фиксированная позиция на странице)',
	
			'widgets' => "Виджеты",
			'widget' => "Виджет",
			'item:object:widget' => "Виджеты",
			'layout:customise' => "Настроить расположение",
			'widgets:gallery' => "Галлерея",
			'widgets:leftcolumn' => "Левая колонка",
			'widgets:fixed' => "Фиксированная позиция",
			'widgets:middlecolumn' => "Средняя колонка",
			'widgets:rightcolumn' => "Правая колонка",
			'widgets:profilebox' => "Блок личных данных",
			'widgets:panel:save:success' => "Настройки виджетов успешно сохранены.",
			'widgets:panel:save:failure' => "При сохранении виджетов, произошла какая-то ошибка. Попробуйте ещё раз.",
			'widgets:save:success' => "Виджет успешно сохранён.",
			'widgets:save:failure' => "Невозможно сохранить виджет, попробуйте ещё раз.",
			
	
		/**
		 * Groups
		 */
	
			'group' => "Группы", 
			'item:group' => "Группы",
	
		/**
		 * Profile
		 */
	
			'profile' => "Личная страница",
			'profile:edit:default' => 'Настроить поля личной страницы',
			'user' => "Пользователь",
			'item:user' => "Пользователи",

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Мои личные данные",
			'profile:user' => "Личные данные пользователя %s",
	
			'profile:edit' => "Редактировать личные данные",
			'profile:editicon' => "Закачать новое фото",
			'profile:profilepictureinstructions' => "Моё фото - это картинка, которая будет показываться на странице вашего профайла. <br /> Вы можете её менять так часто, как пожелаете. (Разрешённые форматы: GIF, JPG или PNG)",
			'profile:icon' => "Моё фото",
			'profile:createicon' => "Сохранить",
			'profile:currentavatar' => "Текущее",
			'profile:createicon:header' => "Моё фото",
			'profile:profilepicturecroppingtool' => "Выбор границ",
			'profile:createicon:instructions' => "Нажмите и, удерживая кнопку мыши, укажите область, которую вы хотите обрезать на вашей картинке. Предварительный просмотр вашей обрезанной картинки появится справа.  Когда вы будете удовлетворены картинкой в предварительном просмотре, нажмите <b>'Сохранить'</b>. Это обрезанное изображение будет использоваться как ваше фото во всех разделах сайта.",
	
			'profile:editdetails' => "Редактировать",
			'profile:editicon' => "Моё фото",
	
			'profile:aboutme' => "Обо мне", 
			'profile:description' => "Обо мне",
			'profile:briefdescription' => "Коротко о себе",
			'profile:location' => "Город, Страна",
			'profile:skills' => "Навыки",  
			'profile:interests' => "Интересы", 
			'profile:contactemail' => "Контактный имэйл",
			'profile:phone' => "Номер телефона",
			'profile:mobile' => "Мобильныйтелефон",
			'profile:website' => "Веб-сайт",
			
			'profile:label' => "Имя поля",
			'profile:type' => "Тип поля",

			'profile:editdefault:fail' => 'Не удалось сохранить настройки личных данных',
			'profile:editdefault:success' => 'Поля успешно добавлены в настройки личных данных',

			'profile:editdefault:delete:fail' => 'Removed default profile item field failed',
			'profile:editdefault:delete:success' => 'Default profile item deleted!',

			'profile:defaultprofile:reset' => 'Настройки личных данных сброшены',

			'profile:resetdefault' => 'Сбросить настройки',

			'name' => "Отображаемое имя",
			'email' => "Адрес электронной почты",
			'username' => "Логин",
			'password' => "Пароль",
			'passwordagain' => "Пароль (повтор для проверки)",
			'admin_option' => "Сделать этого пользователя администратором?",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "Только себе",
			'ACCESS_LOGGED_IN' => "Зарегистрированным пользователям",
			'ACCESS_PUBLIC' => "Всем",
			'PRIVATE' => "Только себе",
			'LOGGED_IN' => "Зарегистрированным пользователям",
			'PUBLIC' => "Всем",
			'access' => "Доступ",
	
		/**
		 * Groups
		 */
	
			'group' => "Группы", 
			'item:group' => "Группы",
		/**
		 * Profile status messages
		 */
			'profile:river:update' => "%s обновил свои личные данные",
			'profile:river:iconupdate' => "%s обновил своё фото",
	
			'profile:saved' => "Ваши данные успешно сохранены.",
			'profile:icon:uploaded' => "Ваше фото успешно сохранено.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "У вас нет прав на редактирование данных этого пользователя.",
			'profile:notfound' => "Извините, мы не можем найти данные указанного пользователя.",
			'profile:cantedit' => "Извините, у вас нет прав на редактирование данных этого пользователя.",
			'profile:icon:notfound' => "Извините, не удалось сохранить ваше фото.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Друзья",
			'friends:yours' => "Ваши друзья",
			'friends:owned' => "Друзья пользователя %s",
			'friend:add' => "Добавить в друзей",
			'friend:remove' => "Убрать из друзей",
	
			'friends:add:successful' => "Вы успешно добавили %s в друзья.",
			'friends:add:failure' => "Невозможно добавить %s в друзья. Попробуйте ещё раз.",
	
			'friends:remove:successful' => "Выуспешно убрали %s из друзей.",
			'friends:remove:failure' => "Мы не смогли удалить пользователя %s из списка ваших друзей. Попробуйте ещё раз.",
	
			'friends:none' => "У этого пользователя пока нет друзей.",
			'friends:none:you' => "У вас пока нет друзей! Воспользуйтесь поиском что бы найти ваших старых друзей или найти новых друзей по интересам.",
	
			'friends:none:found' => "Нет друзей.",
	
			'friends:of:none' => "Никто не добавил данного пользователя как своего друга.",
			'friends:of:none:you' => "Никто вас не добавил как своего друга. Заполните свои личные данные что бы вас было легче найти!",
	
			'friends:of' => "Friends of",
			'friends:of:owned' => "Люди, которые добавили %s в друзья",

			 'friends:num_display' => "Количество друзей на одной странице",
			 'friends:icon_size' => "Размер фото",
			 'friends:tiny' => "крошечный",
			 'friends:small' => "маленький",
			 'friends' => "Друзья",
			 'friends:of' => "Чей друг",
			 'friends:collections' => "Группы друзей",
			 'friends:collections:add' => "Создать группу друзей",
			 'friends:addfriends' => "Добавить друзей",
			 'friends:collectionname' => "Название группы",
			 'friends:collectionfriends' => "Друзья в группе",
			 'friends:collectionedit' => "Редактировать эту группу",
			 'friends:nocollections' => "У вас нет групп друзей.",
			 'friends:collectiondeleted' => "Группа была удалена.",
			 'friends:collectiondeletefailed' => "Мы не смогли удалить группу. Либо у вас нет прав, либо случилась какая-то другая ошибка.",
			 'friends:collectionadded' => "Ваша группа была успешно создана",
			 'friends:nocollectionname' => "Необходимо указать название группы что бы её создать.",
		
	        'friends:river:created' => "%s добавил себе виджет 'Друзья'.",
	        'friends:river:updated' => "%s обновил виджет 'Друзья'.",
	        'friends:river:delete' => "%s удалил виджет 'Друзья'.",
	        'friends:river:add' => "%s добавил себе друга.",
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Подписаться на ленту',
			'feed:odd' => 'Синхронизировать через OpenDD',
	
		/**
		 * River
		 */
			'river' => "River",			
			'river:relationship:friend' => 'теперь друг пользователя',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Настройки для приложения %s успешно сохранены.",
			'plugins:settings:save:fail' => "Настройки для приложения %s не сохранены.",
			'plugins:usersettings:save:ok' => "Пользовательские настройки для приложения %s успешно сохранены.",
			'plugins:usersettings:save:fail' => "Пользовательский настройки для приложения %s не сохранены.",
			
			'item:object:plugin' => 'Настройки приложения',
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Настройки оповещения",
			'notifications:methods' => "Пожалуйста укажите методы оповещания.",
	
			'notifications:usersettings:save:ok' => "Настройки оповещения были успешно сохранены.",
			'notifications:usersettings:save:fail' => "Не удалось сохранить изменения настроек оповещения.",
	
			'user.notification.get' => 'Вернуться с настройкам оповещения данного пользователя.',
			'user.notification.set' => 'Устанавливает настройки уведомлений для указанного пользователя.',
		/**
		 * Search
		 */
	
			'search' => "Поиск",
			'searchtitle' => "Поиск: %s",
			'users:searchtitle' => "Поиск пользователей: %s",
			'advancedsearchtitle' => "%s среди результатов, подходящих под %s",
			'notfound' => "Ваш запрос не дал результатов.",
			'next' => "Дальше",
			'previous' => "Назад",
	
			'viewtype:change' => "Изменить вид",
			'viewtype:list' => "Список",
			'viewtype:gallery' => "Галлерея",
	
			'tag:search:startblurb' => "Записи, отвечающие запросу '%s':",

			'user:search:startblurb' => "Пользователи, отвечающие запросу '%s':",
			'user:search:finishblurb' => "Нажмите сюда, что бы увидеть больше.",
	
		/**
		 * Account
		 */
	
			'account' => "Учётная запись",
			'settings' => "Настройки",
            'tools' => "Приложения",
            'tools:yours' => "Мои приложения",
	
			'register' => "Регистрация",
			'registerok' => "Вы успешно зарегистрировались в %s. Чтобы активировать аккаунт, пожалуйста подтвердите email адрес перейдя по ссылке, которую мы вам выслали.",
			'registerbad' => "Регистрация не возможна. Имя пользователя уже занято, либо пароли не совпадают, либо имя пользователя или пароль слишком короткие.",
			'registerdisabled' => "Регистрация новых пользователей отключена администратором.",
	
			'registration:notemail' => 'Адрес электронной почты, указанный вами, не корректен.',
			'registration:userexists' => 'Такой пользователь уже зарегистрирован в системе',
			'registration:usernametooshort' => 'Имя пользователя должно быть длиной не менее 4 символов.',
			'registration:passwordtooshort' => 'Пароль должен быть длиной не менее 6 символов.',
			'registration:dupeemail' => 'Этот адрес электронной почты уже используется в системе.',
			'registration:invalidchars' => 'Имя пользователя содержит недопустимые символы.',
			'registration:emailnotvalid' => 'Такой адрес электронной почты недопустим',
			'registration:passwordnotvalid' => 'Такой пароль недопустим',
			'registration:usernamenotvalid' => 'Такое имя пользователя не допустимо',
	
			'adduser' => "Добавить пользователя",
			'adduser:ok' => "Вы успешно добавили нового пользователя.",
			'adduser:bad' => "Новый пользователь не может быть создан.",
			
			'item:object:reported_content' => "Нарушения",
	
			'user:set:name' => "Имя пользователя",
			'user:name:label' => "Ваше имя",
			'user:name:success' => "Ваше имя успешно изменено.",
			'user:name:fail' => "Не удалось изменить ваше имя.",
	
			'user:set:password' => "Пароль",
			'user:password:label' => "Новый пароль",
			'user:password2:label' => "Повторите новый пароль",
			'user:password:success' => "Пароль изменён",
			'user:password:fail' => "Невозможно изменить пароль.",
			'user:password:fail:notsame' => "Пароли не совпадают!",
			'user:password:fail:tooshort' => "Пароль слишком короткий!",
	
			'user:set:language' => "Языковые настройки",
			'user:language:label' => "Ваш язык",
			'user:language:success' => "Ваши языковые настройки успешно сохранены.",
			'user:language:fail' => "Не удалось сохранить ваши языковые настройки.",
	
			'user:username:notfound' => 'Пользователь %s не найден.',
	
			'user:password:lost' => 'Забыл пароль',
			'user:password:resetreq:success' => 'Новый пароль успешно установлен, инструкции высланы по почте',
			'user:password:resetreq:fail' => 'Не возможно сбросить пароль.',
	
			'user:password:text' => 'Что бы сбросить пароль, введите ваш логин ниже. Мы вышлем вам уникальный адрес страницы, на который вам надо будет зайти, что бы получить новый пароль.',
			'user:persistent' => 'Запомнить меня',
	
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Изменения были сохранены.",
			'admin:configuration:fail' => "Изменения не были сохранены.",
	
			'admin' => "Администрирование",
			'admin:description' => "Административная панель позволяет вам управлять всеми аспектами системы, от управления пользователями до поведения приложений.",
			
			'admin:user' => "Управление пользователями",
			'admin:user:description' => "Эта страница позволяет менять настройки вашего сайта.",
			'admin:user:adduser:label' => "Кликнуть тут что бы добавить нового пользователя...",
			'admin:user:opt:linktext' => "Настроить пользователей...",
			'admin:user:opt:description' => "Настроить пользователей и информацию об аккаунтах. ",
			
			'admin:site' => "Управление сайтом",
			'admin:site:description' => "Эта страница позволяет вам управлять глобальными настройками вашего сайта.",
			'admin:site:opt:linktext' => "Настроить сайт...",
			'admin:site:opt:description' => "Установить технические и нетехнические настройки. ",
			
			'admin:plugins' => "Управление приложениями",
			'admin:plugins:description' => "Эта страница позволяет вам управлять приложениями, установленными на вашем сайте.",
			'admin:plugins:opt:linktext' => "Настроить приложения...",
			'admin:plugins:opt:description' => "Настроить установленные на сайте приложения. ",
			'admin:plugins:label:author' => "Автор",
			'admin:plugins:label:copyright' => "Копирайт",
			'admin:plugins:label:licence' => "Лицензия",
			'admin:plugins:label:website' => "URL",
			'admin:plugins:disable:yes' => "Приложение %s было успешно выключено.",
			'admin:plugins:disable:no' => "Не удалось выключить приложение %s.",
			'admin:plugins:enable:yes' => "Приложение %s было успешно включено.",
			'admin:plugins:enable:no' => "Не удалось включить приложение %s.",
	
			'admin:statistics' => "Статистика",
			'admin:statistics:description' => "Это обзорная статистика вашего сайта. Если вам нужна более детальная статистика, вы можете воспользоваться профессиональными услугами.",
			'admin:statistics:opt:description' => "Просмотреть статистику о пользователях и объектах на вашем сайте.",
			'admin:statistics:opt:linktext' => "Посмотреть статистику...",
			'admin:statistics:label:basic' => "Статистика сайта",
			'admin:statistics:label:numentities' => "Объекты",
			'admin:statistics:label:numusers' => "Количество ползователей",
			'admin:statistics:label:numonline' => "Количество пользователей в сети",
			'admin:statistics:label:onlineusers' => "Пользователей в сети",
			'admin:statistics:label:version' => "Версия Elgg",
			'admin:statistics:label:version:release' => "Релиз",
			'admin:statistics:label:version:version' => "Версия",
	
			'admin:user:label:search' => "Найти пользователей:",
			'admin:user:label:seachbutton' => "Поиск", 
	
			'admin:user:ban:no' => "Невозможно забанить пользователя",
			'admin:user:ban:yes' => "Пользователь забанен.",
			'admin:user:unban:no' => "Невозможно разбанить пользователя",
			'admin:user:unban:yes' => "Пользователь разбанен.",
			'admin:user:delete:no' => "Невозможно удалить пользователя",
			'admin:user:delete:yes' => "Пользователь удалён",
	
			'admin:user:resetpassword:yes' => "Пароль сброшен, пользователь уведомлён.",
			'admin:user:resetpassword:no' => "Не удалось сбросить пароль.",
	
			'admin:user:makeadmin:yes' => "Пользователю даны права администратора.",
			'admin:user:makeadmin:no' => "Не удалось дать пользователю права администратора.",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "Страница управления пользовательскими настройками позволяет вам контролировать все ваши персональные настройки, от управления пользователями до поведения приложений.",
	
			'usersettings:statistics' => "Ваша статистика",
			'usersettings:statistics:opt:description' => "Просмотр статистической информации о пользователях и объетах вашего сайта.",
			'usersettings:statistics:opt:linktext' => "Моя статистика",
	
			'usersettings:user' => "Мои настройки",
			'usersettings:user:opt:description' => "Это позволяет менять пользовательские настройки.",
			'usersettings:user:opt:linktext' => "Мои настройки",
	
			'usersettings:plugins' => "Приложения",
			'usersettings:plugins:opt:description' => "Настроить активные приложения.",
			'usersettings:plugins:opt:linktext' => "Настроить активные приложения...",
	
			'usersettings:plugins:description' => "Эта страница позволяет вам контролировать и настраивать установленные в системе приложения.",
			'usersettings:statistics:label:numentities' => "Мои объекты",
	
			'usersettings:statistics:yourdetails' => "Мои детали",
			'usersettings:statistics:label:name' => "Полное имя",
			'usersettings:statistics:label:email' => "Адрес эл. почты",
			'usersettings:statistics:label:membersince' => "Дата создания",
			'usersettings:statistics:label:lastlogin' => "Последний раз в сети",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Сохранить",
			'cancel' => "Отменить",
			'saving' => "Сохранение ...",
			'update' => "Обновить",
			'edit' => "Редактировать",
			'delete' => "Удалить",
			'load' => "Загрузить",
			'upload' => "Закачать",
			'ban' => "Забанить",
			'unban' => "Разбанить",
			'enable' => "Включить",
			'disable' => "Выключить",
			'request' => "Запросить",
			'complete' => "Завершить",
			'close' => "Закрыть",
			'reply' => "Ответить",

			'up' => 'Выше',
			'down' => 'Ниже',
			'top' => 'Первый',
			'bottom' => 'Поcледний',

			'invite' => "Пригласить",
	
			'resetpassword' => "Изменить пароли",
			'makeadmin' => "Сделать администратором",
	
			'option:yes' => "Да",
			'option:no' => "Нет",
	
			'unknown' => 'Неизвестный',
	
			'active' => 'Активный',
			'total' => 'Общий',
	
			'learnmore' => "Нажмите здесь, что бы узнать больше.",
	
			'content' => "содержимое",
			'content:latest' => 'Последние события',
			'content:latest:blurb' => 'Нажмите сюда, что бы посмотреть последние события со всего сайта.',
			
			'link:text' => 'ссылка &raquo;',
			'more' => 'больше &raquo;',
			'created' => 'добавлено',
	
		/**
		 * Generic data words
		 */
	
			'title' => "Название",
			'description' => "Описание",
			'tags' => "Тэги",
			'spotlight' => "Важная информация",
			'all' => "Все",
	
			'by' => 'от',
	
			'annotations' => "Аннотации",
			'relationships' => "Связи",
			'metadata' => "Метаданные",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Вы уверены, что хотите удалить этот объект?",
			'fileexists' => "Файл уже отправлен на сервер. Что бы заменить его, выберите его ниже:",
			
		/**
         * System messages
         **/
            'systemmessages:dismiss' => "закрыть",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "Импорт данных завершился успешно",
			'importfail' => "OpenDD импорт данных .",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "только что",
			'friendlytime:minutes' => "%s минут назад",
			'friendlytime:minutes:other' => "%s минуты назад",
			'friendlytime:minutes:singular' => "минуту назад",
			'friendlytime:hours' => "%s часов назад",
			'friendlytime:hours:other' => "%s часа назад",
			'friendlytime:hours:singular' => "час назад",
			'friendlytime:days' => "%s дней назад",
			'friendlytime:days:other' => "%s дня назад",
			'friendlytime:days:singular' => "вчера",
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory. 

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
			'installation:error:configuration' => "После исправления всех проблем конфигурации, обновите страницу что бы попытаться ещё раз.",
	
			'installation' => "Инсталляция",
			'installation:success' => "База данных Elgg успешно установлена.",
			'installation:configuration:success' => "Ваши настройки сохранены. Теперь зарегистрируйте первого пользователя, который будет являться администратором.",
	
			'installation:settings' => "Системные настройки",
			'installation:settings:description' => "Теперь, когда база данных была успешно установлена, необходимо настроить остальные аспекты сайта. Мы попробовали автоматически определить настройки, но <b>вам следует их перепроверить.</b>",
	
			'installation:settings:dbwizard:prompt' => "Настройте доступ к базе данных и нажмите 'Сохранить':",
			'installation:settings:dbwizard:label:user' => "Пользователь",
			'installation:settings:dbwizard:label:pass' => "Пароль",
			'installation:settings:dbwizard:label:dbname' => "База данных",
			'installation:settings:dbwizard:label:host' => "Хост (обычно 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Префикс таблиц (обычно 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Не удалось сохранить settings.php. Пожалуйста, сохраните следующую информацию в файл engine/settings.php используя текстовый редактор.",
	
			'installation:sitename' => "Название вашего сайта (например \"Моя социальная сеть\"):",
			'installation:sitedescription' => "Краткое описание вашего сайта (не обязательно)",
			'installation:wwwroot' => "URL вашего сайта, заканчивающийся на /:",
			'installation:path' => "Полный путь к корневой директории сайта на сервере, заканчивающийся на /:",
			'installation:dataroot' => "Полный путь к директории, в которой будут храниться закачанные на сайт файлы, заканчивающийся на /:",
			'installation:dataroot:warning' => "Вам придётся создать её самостоятельно. Она должна находится вне директории в которую установлен Elgg.",
			'installation:language' => "Язык сайта по умолчанию:",
			'installation:debug' => "Режим отладки предоставляет дополнительную инофрмацию для диагностики ошибок, но это может замедлить системы, поэтому режим должен быть использован только для отладки:",
			'installation:debug:label' => "Включить режим отладки",
			'installation:usage' => "Это позволит Elgg посылать анонимную статистику использования разработчикам Elgg.",
			'installation:usage:label' => "Отсылать анонимную статистику использования",
			'installation:view' => "Укажите, какой view должен быть использован по умолчанию для сайта, или оставьте пустым, что бы использовался default:",

			'installation:disableapi' => "Elgg предоставляет гибкое и расширяемое API, которое позволяет приложениям использовать некоторые возможности Elgg удалённо",
			'installation:disableapi:label' => "Включить RESTful API",
			
			'installation:siteemail' => "Обратный адрес электронной почты, который будет использоваться для посылки системных писем",
			
			'upgrade:db' => 'База данных была обновлена.',
			'upgrade:core' => 'Ваша копия Elgg была обновлена.',

	
		/**
		 * Welcome
		 */
	
			'welcome' => "Привет %s",
			'welcome_message' => "Рады привествовать вас в свежеустановленной системе.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Настройки имэйл адреса",
			'email:address:label' => "Ваш адрес электронной почты",
			
			'email:save:success' => "Новый имэйл сохранён,подтверждение запрошено.",
			'email:save:fail' => "Новый имэйл не был сохранён",
	
			'email:confirm:success' => "Вы подтвердили ваш новый имэйл!",
			'email:confirm:fail' => "Адрес вашей электронной почты не был изменён...",
	
			'friend:newfriend:subject' => "%s добавил вас в друзья!",
			'friend:newfriend:body' => "%s добавил вас в друзья!

Что бы посмотреть его профайл, нажмите сюда:

	%s

Не надо отвечать на это письмо.",
	
	
			'email:validate:subject' => "%s, пожалуйста, подтвердите адрес!",
			'email:validate:body' => "Привет %s,

Пожалуйста, подтвердите ваш адрес электронной почты нажав на ссылку ниже:

%s
",
			'email:validate:success:subject' => "Адрес электронной почты проверен!",
			'email:validate:success:body' => "Привет, %s,
			
Поздравляем, ваш адрес электронной почты успешно проверен.",
	
	
			'email:resetpassword:subject' => "Пароль сброшен!",
			'email:resetpassword:body' => "Привет %s,
			
Ваш пароль был сброшен, новый пароль: %s",
	
	
			'email:resetreq:subject' => "Запрос нового пароля.",
			'email:resetreq:body' => "Привет %s,
			
Кто-то (IP адрес %s) запросил новый пароль для вашего аккаунта.

Если это были вы, нажмите на ссылку ниже, иначе просто проигнорируйте это сообщение.

%s
",

	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Отсутствуют входные данные",
	
		/**
		 * Comments
		 */
			'comments' => "комментарии",
			'comments:count' => "%s комментарии",
			'generic_comments:add' => "Добавить комментарий",
			'generic_comments:text' => "Комментарий",
			'generic_comment:posted' => "Ваш комментарий успешно добавлен.",
			'generic_comment:deleted' => "Ваш комментарий успешно удалён.",
			'generic_comment:blank' => "Извините, нельзя добавить пустой комментарий.",
			'generic_comment:notfound' => "Извините, мы не можем найти указанный объект.",
			'generic_comment:notdeleted' => "Извините, мы не можем удалить этот комментарий.",
			'generic_comment:failure' => "Не удалоcь добавить ваш комментарий. Попробуйте ещё раз.",
	
			'generic_comment:email:subject' => 'Вы получили новый комментарий!',
			'generic_comment:email:body' => "Вы получили новый комментарий на ваше \"%s\" от %s:

			
%s


Что бы ответить или просто посмотреть оригинальный объект, перейдите по ссылке:

	%s

Что бы посмотреть профайл пользователя %s, перейдите по ссылке:

	%s

Не надо отвечать на это письмо.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Добавлено %s пользователем %s',
			'entity:default:missingsupport:popup' => 'Этот объект не может быть корректно отображён. Возможно, это случилось потому, что был удалёно приложение, которое умеет его отображать.',
	
			'entity:delete:success' => 'Объект %s успешно удалён',
			'entity:delete:fail' => 'Объект %s не может быть удалён',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'В форме не хватает полей __token или __ts',
			'actiongatekeeper:tokeninvalid' => 'Токен в  форме не соответствует токену, сгенерированному на сервере.',
			'actiongatekeeper:timeerror' => 'Форма потеряла актуальность, пожалуйста обновите страницу и попробуйте ещё раз.',
			'actiongatekeeper:pluginprevents' => 'Какое-то браузерное расширение не позволило отправить эту форму.',
		/**
		 * Extras
		 */
	        'more info' => 'больше &raquo;',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Афарский",
			"ab" => "Абхазский",
			"af" => "Африкаанс",
			"am" => "Амхарский",
			"ar" => "Арабский",
			"as" => "Ассаамский",
			"ay" => "Аймара",
			"az" => "Азербайнджанский",
			"ba" => "Башкирский",
			"be" => "Белорусский",
			"bg" => "Болгарский",
			"bh" => "Бихари",
			"bi" => "Бислама",
			"bn" => "Бенгальский,",
			"bo" => "Тибетский",
			"br" => "Бретонский",
			"ca" => "Каталанский",
			"co" => "Корсиканский",
			"cs" => "Чешский",
			"cy" => "Уэльский",
			"da" => "Датский",
			"de" => "Немецкий",
			"dz" => "Бхутани",
			"el" => "Греческий",
			"en" => "Английский",
			"eo" => "Эсперанто",
			"es" => "Испанский",
			"et" => "Эстонский",
			"eu" => "Баскский язык",
			"fa" => "Персидский",
			"fi" => "Финский",
			"fj" => "Фиджийский",
			"fo" => "Фарерский",
			"fr" => "Французский",
			"fy" => "Фарерский",
			"ga" => "Ирландский",
			"gd" => "Шотландский(гальский)",
			"gl" => "Galician",
			"gn" => "Гуарани",
			"gu" => "Гуджаратский",
			"he" => "Иврит",
			"ha" => "Хауса",
			"hi" => "Хинди",
			"hr" => "Хорватский",
			"hu" => "Венгерский",
			"hy" => "Армянский",
			"ia" => "Интерлингва",
			"id" => "Индонезейский",
			"ie" => "Окйиденталь",
			"ik" => "Инупиак",
			//"in" => "Индонезийский",
			"is" => "Исландский",
			"it" => "Итальянский",
			"iu" => "Инуктитут",
			"iw" => "Иврит",
			"ja" => "Японский",
			"ji" => "Йдиш",
			"jw" => "Яванский",
			"ka" => "Грузинский",
			"kk" => "Казахский",
			"kl" => "Гренландский",
			"km" => "Кхмерский",
			"kn" => "Kанада",
			"ko" => "Корейский",
			"ks" => "Кашмири",
			"ku" => "Курдский",
			"ky" => "Киргизский",
			"la" => "Латинский",
			"ln" => "Лингала",
			"lo" => "Лаосский",
			"lt" => "Латышский",
			"lv" => "Литовский",
			"mg" => "Малагасийский",
			"mi" => "Маори",
			"mk" => "Mакедонский",
			"ml" => "Малаялам",
			"mn" => "Монгольский",
			"mo" => "Молдавский",
			"mr" => "Маратхи",
			"ms" => "Малагасийский",
			"mt" => "Мальтийский",
			"my" => "Бирманский",
			"na" => "Науранский",
			"ne" => "Непальский",
			"nl" => "Датский",
			"no" => "Норвежский",
			"oc" => "Окситанский",
			"om" => "Афан Оромо",
			"or" => "Ория",
			"pa" => "Панджаби",
			"pl" => "Польский",
			"ps" => "Пашто",
			"pt" => "Португальский",
			"qu" => "Кечуа",
			"rm" => "Рето-романский",
			"rn" => "Рунди",
			"ro" => "Румынский",
			"ru" => "Русский",
			"rw" => "Руанда",
			"sa" => "Санскрит",
			"sd" => "Синдхи",
			"sg" => "Сангхо",
			"sh" => "Сербохорватский",
			"si" => "Сингальский",
			"sk" => "Словацкий",
			"sl" => "Словенский",
			"sm" => "Самоанский",
			"sn" => "Шона",
			"so" => "Сомали",
			"sq" => "Албанский",
			"sr" => "Сербский",
			"ss" => "Свати",
			"st" => "Сеперди",
			"su" => "Сунданский",
			"sv" => "Шведский",
			"sw" => "Суахили",
			"ta" => "Тамильский",
			"te" => "Телугу",
			"tg" => "Таджикский",
			"th" => "Тайский",
			"ti" => "Семитский",
			"tk" => "Туркменский",
			"tl" => "Тагальский",
			"tn" => "Тсвана",
			"to" => "Tонганский",
			"tr" => "Турецкий",
			"ts" => "Тсонга",
			"tt" => "Татарский",
			"tw" => "Тви",
			"ug" => "Уйгурский",
			"uk" => "Украинский",
			"ur" => "Урду",
			"uz" => "Узбекский",
			"vi" => "Вьетнамский",
			"vo" => "Волапюк",
			"wo" => "Волоф",
			"xh" => "Коса",
			//"y" => "Yiddish",
			"yi" => "Идиш",
			"yo" => "Йоруба",
			"za" => "Чжуанский",
			"zh" => "Китайский",
			"zu" => "Зулусский",

	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggLogBrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		/**
		 * Menu items and titles
		 */
	
			'logbrowser' => 'Логи',
			'logbrowser:browse' => 'Системный лог',
			'logbrowser:search' => 'Фильтровать результат',
			'logbrowser:user' => 'Искать по имени пользователя',
			'logbrowser:starttime' => 'От (к примеру "last monday", "1 hour ago")',
			'logbrowser:endtime' => 'До',
	
			'logbrowser:explore' => 'Просмотреть логи',
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'Нет никакой активности.',
		'river:widget:title' => "Мои действия",
		'river:widget:description' => "Показать ваши последние действия.",
		'river:widget:title:friends' => "Действия друзей",
		'river:widget:description:friends' => "Показать, чем занимаются ваши друзья прямо сейчас.",
	
		'river:widget:label:displaynum' => "Количество действий на странице:",

	/**
	 * Update client language pack.
	 * 
	 * @package ElggUpdateClient
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */	

		'updateclient:label:core' => 'Ядро',
		'updateclient:label:plugins' => 'Приложения',
	
		'updateclient:settings:days' => 'Проверять на наличие обновлений каждые',
		'updateclient:days' => 'дней',
	
		'updateclient:settings:server' => 'Обновить сервер',
	
		'updateclient:message:title' => 'Вышла новая версия Elgg!',
		'updateclient:message:body' => 'Вышла новая верся Elgg (%s %s) под кодовым названием "%s"!
		
Скачать её можно здесь: %s

Или прочитайте аннотацию к новой версии:

%s',
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'Управление API',
	
	
			'apiadmin:keyrevoked' => 'Ключ API отозван',
			'apiadmin:keynotrevoked' => 'Ключ API не может быть отозван',
			'apiadmin:generated' => 'Ключ API успешно сгенерирован',
	
			'apiadmin:yourref' => 'Наименование',
			'apiadmin:generate' => 'Сгенерировать новую пару ключей',
	
			'apiadmin:noreference' => 'Необходимо указать наименование для вашего нового ключа.',
			'apiadmin:generationfail' => 'При генерации ключей случилась ошибка',
			'apiadmin:generated' => 'Новая пара ключей API успешно сгенерирована',
	
			'apiadmin:revoke' => 'Отозвать ключ',
			'apiadmin:public' => 'Публичный',
			'apiadmin:private' => 'Приватный',

	
			'item:object:api_key' => 'Ключи API',
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'Жалобы',
			'reportedcontent' => 'Жалобы',
			'reportedcontent:report' => 'Пожаловаться',
			'reportedcontent:this' => 'Пожаловаться',
			'reportedcontent:none' => 'Жалоб нет',
			'reportedcontent:report' => 'Пожаловаться',
			'reportedcontent:title' => 'Название страницы',
			'reportedcontent:deleted' => 'Жалоба успешно удалена',
			'reportedcontent:notdeleted' => 'Не удалось удалить жалобу',
			'reportedcontent:delete' => 'Удалить',
			'reportedcontent:areyousure' => 'Вы уверены что хотите удалить?',
			'reportedcontent:archive' => 'В архив',
			'reportedcontent:archived' => 'Жалоба заархивирована',
			'reportedcontent:visit' => 'Просмотреть',
			'reportedcontent:by' => 'Кем',
			'reportedcontent:objecttitle' => 'Название объекта',
			'reportedcontent:objecturl' => 'Ссылка на страницу',
			'reportedcontent:reason' => 'Причина жалобы',
			'reportedcontent:description' => 'Причина жалобы',
			'reportedcontent:address' => 'Ссылка на страницу',
			'reportedcontent:success' => 'Ваша жалоба отправлена администрации',
			'reportedcontent:failing' => 'Ваша жалоба не может быть отправлена',
			'reportedcontent:report' => 'Пожаловаться', 
	
			'reportedcontent:failed' => 'Извините, попытка пожаловаться не удалась.',

	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		/**
		 * Menu items and titles
		 */
			
			'groups' => 'Группы',
			'groups:owned' => 'Мои группы',
			'groups:yours' => 'Участвую в группах',
			'groups:user' => 'Группы %s',
			'groups:all' => 'Группы всего сайта',
			'groups:new' => 'Создать новую группу',
			'groups:edit' => 'Редактировать группу',

			'groups:icon' => 'Иконка группы (оставьте пустым чтобы не менять)',
			'groups:name' => 'Имя группы',
			'groups:username' => 'Краткое имя группы (отображается в URL, цифро-буквы только)',
			'groups:description' => 'Описание',
			'groups:briefdescription' => 'Краткое описание',
			'groups:interests' => 'Интересы',
			'groups:website' => 'Веб сайт',
			'groups:members' => 'Пользователи группы',
			'groups:membership' => 'Присоединиться можно',
			'groups:access' => 'Доступ на чтение',
			'groups:owner' => 'Владелец',
			'groups:widget:num_display' => 'Число групп для отображения',
			'groups:widget:membership' => 'Состою в группах',
			'groups:widgets:description' => 'Отображать ли твои группы на твоей странице',
			'groups:noaccess' => 'Нет доступа в группу',
			'groups:cantedit' => 'Вы не можете редактировать эту группу',
			'groups:saved' => 'Группа сохранена',
	
			'groups:joinrequest' => 'Присоединиться к группе',
			'groups:join' => 'Присоединиться к группе',
			'groups:leave' => 'Покинуть группу',
			'groups:invite' => 'Пригласить друзей',
			'groups:inviteto' => "Пригласить друзей в группу '%s'",
			'groups:nofriends' => 'У Вас не осталось друзей, не приглашённых в эту группу.',

			'groups:group' => 'Группа',
			
			'item:object:groupforumtopic' => 'Темы форума',
	
			/*
			  Group forum strings
			*/
			
			'groups:forum' => 'Форум группы',
			'groups:addtopic' => 'Добавить тему',
			'groups:forumlatest' => 'Последние форумы',
			'groups:latestdiscussion' => 'Последние обсуждения',
			'groupspost:success' => 'Ваш комментарий успешно отослан',
			'groups:alldiscussion' => 'Последние обсуждения',
			'groups:edittopic' => 'Редактировать тему',

			'groups:topicmessage' => 'Сообщение',
			'groups:topicstatus' => 'Статус темы',
			'groups:reply' => 'Отослать комментарий',
			'groups:topic' => 'Тема',
			'groups:posts' => 'Сообщения',
			'groups:lastperson' => 'Последний подключившийся',
			'groups:when' => 'Когда',
			'grouptopic:notcreated' => 'Нет тем.',
			'groups:topicopen' => 'Открытые',
			'groups:topicclosed' => 'Закрытые',
			'groups:topicresolved' => 'Решенные',
			'grouptopic:created' => 'Тема создана.',
			'groupstopic:deleted' => 'Тема удалена.',
			'groups:topicsticky' => 'Прилепленная',
			'groups:topicisclosed' => 'Эта тема закрыта.',
			'groups:topiccloseddesc' => 'Эта тема закрыта и в неё больше нельзя писать.',
	
			'groups:privategroup' => 'Эта группа приватная, просим разрешения присоединиться.',
			'groups:notitle' => 'Группы должны иметь заголовок.',
			'groups:cantjoin' => 'Не могу присоединиться к группе',
			'groups:cantleave' => 'Не могу покинуть группу',
			'groups:addedtogroup' => 'Успешно добавлен пользователь в группу',
			'groups:joinrequestnotmade' => 'Запрос на присоединение не может быть сделан',
			'groups:joinrequestmade' => 'Запрос на присоединение к группе успешно сделан',
			'groups:joined' => 'Успешно присоединились к группе!',
			'groups:left' => 'Успешно покинули группу',
			'groups:notowner' => 'Простите, но Вы не владелец этой группы.',
			'groups:alreadymember' => 'Вы уже состоите в этой группе!',
			'groups:userinvited' => 'Пользователь приглашен.',
			'groups:usernotinvited' => 'Пользователь не может быть приглашен.',
	
			'groups:invite:subject' => '%s был приглашен присоединиться к %s!',
			'groups:invite:body' => "Здравствуйте %s,

Вы были приглашены присоединиться к группе '%s', для подтверждения, перейдите по ссылке:

%s",

			'groups:welcome:subject' => 'Добро пожаловать в группу %s!',
			'groups:welcome:body' => "Привет %s!
		
Теперь Вы состоите в группе '%s'! Кликните по ссылке чтобы начать писать!

%s",



	
			'groups:request:subject' => '%s попросил(а) присоединиться к %s',//"%s has requested to join %s",
			'groups:request:body' => "Привет %s,

%s попросил(а) присоединиться к группе '%s', кликните ниже для просмотра его (её) личных данных:

%s

или кликните по ссылке для подтверждения запроса:

%s",
	
			'groups:river:member' => 'подключился к группе',
	
			'groups:nowidgets' => 'Виджеты для данной группы не определены.',
	
			'groups:widgets:members:title' => 'Ползователи группы',
			'groups:widgets:members:description' => 'Список пользователей группы.',
			'groups:widgets:members:label:displaynum' => 'Список пользователей группы.',
			'groups:widgets:members:label:pleaseedit' => 'Пожалуйста, настройте этот виджет.',
	
			'groups:widgets:entities:title' => 'Объекты в группе',
			'groups:widgets:entities:description' => 'Список объектов, сохраненных в этой группе',
			'groups:widgets:entities:label:displaynum' => 'Список объектов группы.',
			'groups:widgets:entities:label:pleaseedit' => 'Пожалуйста, настройте этот виджет.',
		
			'groups:forumtopic:edited' => 'Тема форума была успешно отредактирована.',
	
		'activity:all' => 'Все действия',
		'activity:your' => 'Мои действия',
		'activity:friends' => 'Действия моих друзей',
		'activity:person' => 'Действия пользователя %s',
		'activity:person:friends' => 'Действия друзей пользователя %s',
	
		'activity:useasdashboard' => 'Вы хотите использовать список действий в качестве главной страницы?',
	
		'activity:noactivity' => 'Извините, но действий, удовлетворяющих критерию поиска, не найдено',
	
		'activity:usernotfound' => 'Пользователь не найден',
		'activity:nofriendactivity' => 'Нет действий, возможно вам нужно больше друзей?',

	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		'email:validate:subject' => "%s, пожалуйста, подтвердите ваш адрес электронной почты!",
		'email:validate:body' => "Привет %s,

Пожалуйста, подтвердите ваш адрес электронной почты нажав на следующую ссылку:

%s
",
		'email:validate:success:subject' => "Адрес электронной почты подтверждён %s!",
		'email:validate:success:body' => "Привет %s,
			
Поздравляем, вы успешно подтвердили ваш адрес электронной почты.",
	
		'uservalidationbyemail:registerok' => "Чтобы активировать ваш аккаунт, пожалуйста подтвердите ваш адрес электронной почты нажатием на ссылку, которую мы вам выслали.",
	
	/**
	 * Elgg GUID Tool
	 * 
	 * @package ElggGUIDTool
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		/**
		 * Menu items and titles
		 */
	
			'guidtool' => 'Управление GUID',
			'guidtool:browse' => 'Навигация по GUIDs',
			'guidtool:import' => 'Импорт',
			'guidtool:import:desc' => 'Вставтье данные, которые вы хотите импортировать в окно ниже, они должны быть в формате "%s".',
	
			'guidtool:pickformat' => 'Пожалуйста, выберите формат в котором вы хотите импортировать или экспортировать.',
	
			'guidbrowser:export' => 'Экспорт',

	/**
	 * Elgg tidypics plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		// Menu items and titles
			 
			'image' => "Изображение",
			'images' => "Изображения",
			'caption' => "Описание",		
			'photos' => "Фотоальбомы",
			'images:upload' => "Добавить фотографии",
			'album' => "Альбом",
			'albums' => "Альбомы",
			'album:yours' => "Мои фотоальбомы",
			'album:yours:friends' => "Фотоальбомы моих друзей",
			'album:user' => "Фотоальбомы пользователя %s",
			'album:friends' => "Фотоальбомы друзей пользователя %s",
			'album:all' => "Все фотоальбомы",
			'album:group' => "Фотоальбомы группы %s",
	
		//actions
		
			'album:create' => "Создать новый альбом",
			'album:add' => "Добавить альбом",
			'album:addpix' => "Добавить фотографии",		
			'album:edit' => "Редактировать альбом",			
			'album:delete' => "Удалить альбом",		

			'image:edit' => "Редактировать фотографии",
			'image:delete' => "Удалить фотографию",
		
		//forms
		
			'album:title' => "Название",
			'album:desc' => "Описание",
			'album:tags' => "Теги",
			'album:cover' => "Сделать обложкой?",
			'image:access:note' => "(права доступа наследуются от прав альбома)",
			
		//views 
		
			'image:total' => "Фотографий в альбоме:",
			'image:by' => "Фотография добавлена пользователем",
			'album:by' => "Альбом создан пользователем",
			'image:none' => "Пуст.",
			'image:back' => "Предыдущая",
			'image:next' => "Следующая",
		
		//widgets
		
			'album:widget' => "Фотоальбомы",
			'album:more' => "Просмотреть все альбомы",
			'album:widget:description' => "Ваши последние фотоальбомы",
			'album:display:number' => "Количество видимых альбомов",
			'album:num_albums' => "Количество видимых альбомов",
			
		//  river
		
			//images
			'image:river:created' => "%s добавил",
			'image:river:item' => "фотографию",
			'image:river:annotate' => "%s оставил комментарий к фотографии",
		
			//albums
			'album:river:created' => "%s добавил",
			'album:river:item' => "альбом",
			'album:river:annotate' => "%s оставил комментарий к альбому",
				
		//  Status messages
			
			'image:saved' => "Фотография успешно добавлена.",
			'images:saved' => "Все фотографии успешно добавлены.",
			'image:deleted' => "Фотография успешно удалена.",
			'image:delete:confirm' => "Вы уверены, что хотите удалить эту фотографию?",
			
			'images:edited' => "Фотографии успешно обновлены.",
			'album:edited' => "Альбом успешно обновлён.",
			'album:saved' => "Альбом успешно сохранён.",
			'album:deleted' => "Альбом успешно удалён.",
			'album:delete:confirm' => "Вы уверены, что хотите удалить этот альбом?",
				
		//Error messages
				 
			'image:none' => "Нет фотографий.",
			'image:uploadfailed' => "Не удалось закачать следующие файлы:",
			'image:deletefailed' => "Не удалось удалить фотографию.",
			
			'image:notimage' => 'Разрешено добавлять только фотографии в форматах jpeg, gif, или png.',
			'images:notedited' => 'Не все фотографии были успешно обновлены',
		 
			'album:none' => "Нет альбомов.",
			'album:uploadfailed' => "Извините, не удалось сохранить ваш альбом.",
			'album:deletefailed' => "Извините, Не удалось удалить ваш альбом.",
			'item:object:album'  => "Альбомы",
			'item:object:image'  => "Фотографии",

	'friendrequest' => "Дружить",
	'friendrequests' => "Предложения дружбы",
	'friendrequests:title' => "Предложения дружбы пользователя %s",
	'newfriendrequests' => "Новое предложение дружбы!",
	'friendrequest:add:exists' => "Вы уже сделали предложение дружбы пользователю %s.",
	'friendrequest:add:failure' => "Извините, произошла какая-то ошибка, попробуйте повторить запрос.",
	'friendrequest:add:successful' => "Вы послали предложение дружбы пользователю %s. Он должен одобрить ваш запрос прежде чем вы появитесь в списке его друзей.",
	'friendrequest:newfriend:subject' => "%s хочет быть вашим другом!",
	'friendrequest:newfriend:body' => "%s хочет быть вашим другом! Но ждёт вашего разрешения...войдите сейчас, что бы одобрить этот запрос!

Вы можете просмотреть ваши текущие предложения здесь:

	%s

(Не надо отвечать на это письмо.)",

	'friendrequest:successful' => "Вы теперь друг пользователя %s!",
	'friendrequest:remove:success' => "Запрос успешно удалён.",
	'friendrequest:remove:fail' => "Не удалось удалить запрос.",
	'friendrequest:approvefail' => "Неизвестная ошибка при попытке добавить пользователя %s в друзья!",
	
	'friendrequest:approve' => "Одобрить",
	'friendrequest:deny' => "Отказать",
				
	/**
	 * Elgg languages language pack.
	 * 
	 * @package ElggLanguages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

			'languages' => 'Переводы',
			'languages:missing' => "Отсутствует перевод в  %s",
	
		/**
		 * Manifest
		 */
		
	
		'opensocial:compliance_widget:title' => 'Соответствие',
		'opensocial:compliance_widget:description' => "Протестировать соответствие OpenSocial",
		'opensocial:gadget:title' => 'Гаджет OpenSocial',
		'opensocial:gadget:description' => "Показывать OpenSocial гаджеты как Elgg виджеты",
		'opensocial:edittext' => "Путь к гаджету (имя XML файли или URL): ",
	

        /**
         * Menu items and titles
         */
    
            'blog' => "Блог",
            'blogs' => "Блоги",
            'blog:user' => 'Блог %s', //"%s's blog",
            'blog:user:friends' => "Блоги друзей %s", //"%s's friends' blog",
            'blog:your' => "Мой блог",
            'blog:posttitle' => "Блог %s: %s", //"%s's blog: %s",
            'blog:friends' => "Блоги друзей", // Friend's blogs
            'blog:yourfriends' => "Последние блоги Ваших друзей", //"Your friends' latest blogs",
            'blog:everyone' => "Все блоги", // All site blogs
    
            'blog:read' => "Читать", //"Read blog",
    
            'blog:addpost' => "Написать сообщение", //"Write a blog post",
            'blog:editpost' => "Редактировать сообщение", //"Edit blog post",
    
            'blog:text' => "Текст сообщения", //"Blog text",
    
            'blog:strapline' => "%s",
            
            'item:object:blog' => "Сообщения", //'Blog posts',
    
            
         /**
         * Blog river
         **/
            
            //generic terms to use
            'blog:river:created' => "%s создал", //"%s wrote",
            'blog:river:updated' => "%s обновил",
            'blog:river:posted' => "%s добавил",
            
            //these get inserted into the river links to take the user to the entity
            'blog:river:create' => "новую запись в блоге.",
            'blog:river:update' => "запись в блоге.",
            'blog:river:annotate:create' => "комментарий к посту", //"a comment on a blog post.",
            
    
        /**
         * Status messages
         */
    
            'blog:posted' => "Ваше сообщение успешно добавлено.", //"Your blog post was successfully posted.",
            'blog:deleted' => "Ваше сообщение успешно удалено.", //"Your blog post was successfully deleted.",
    
        /**
         * Error messages
         */
    
            'blog:save:failure' => "Ваше сообщение не может быть сохранено. Пожалуйста попробуйте еще раз.", //"Your blog post could not be saved. Please try again.",
            'blog:blank' => "Вы должны заполнить заголовок и текст сообщения.", //"Sorry; you need to fill in both the title and body before you can make a post.",
            'blog:notfound' => "Извините. невозможно найти указнное сообщение.", //"Sorry; we could not find the specified blog post.",
            'blog:notdeleted' => "Извините, невозможно удалить это сообщение.", //"Sorry; we could not delete this blog post.",
    
  /**
   * Elgg file plugin language pack
   * 
   * @package ElggFile
   * @author Curverider Ltd
   * @copyright Curverider Ltd 2008
   * @link http://elgg.com/
   */

                 /**
                  * Menu items and titles
                  */
    
                 'file' => 'Файлы',
                 'files' => 'Файлы',
                 'file:yours' => 'Ваши файлы',
                 'file:yours:friends' => 'Файлы Ваших друзей',
                 'file:user' => 'Файлы пользователя %s',
                 'file:friends' => 'Файлы друзей пользователя %s',
                 'file:all' => 'Файлы всего сайта',
                 'file:more' => 'все &raquo;',
                 'file:list' => 'Просмотреть списком',
                 'file:group' => 'Файлы группы %s',
                 'file:gallery' => 'Просмотреть как галерею',
                 'file:gallery_list' => 'Просмотреть как галерею или списком',
                 'file:num_files' => 'Число файлов для отображения',
    
                 'file:upload' => 'Закачать файл',
            
                 'file:file' => 'Файл',
                 'file:title' => 'Название',
                 'file:desc' => 'Описание',
                 'file:tags' => 'Теги',
    
                 'file:types' => 'Типы закачанных файлов',
    
                 'file:type:all' => 'Все файлы',
                 'file:type:video' => 'Видео',
                 'file:type:document' => 'Документы',
                 'file:type:audio' => 'Аудио',
                 'file:type:image' => 'Изображения',
                 'file:type:general' => 'Неизвестные',
    
                 'file:user:type:video' => 'Видео пользователя %s',
                 'file:user:type:document' => 'Документы пользователя %s',
                 'file:user:type:audio' => 'Аудио пользователя %s',
                 'file:user:type:image' => 'Изображения пользователя %s',
                 'file:user:type:general' => 'Остальные файлы пользователя %s',
    
                 'file:friends:type:video' => 'Видео Ваших друзей',
                 'file:friends:type:document' => 'Документы Ваших друзей',
                 'file:friends:type:audio' => 'Аудио Ваших друзей',
                 'file:friends:type:image' => 'Изображения Ваших друзей',
                 'file:friends:type:general' => 'Остальные Ваших друзей',
    
                 'file:widget' => 'Мои файлы',
                 'file:widget:description' => "Показывает ваши последние файлы",
    
                 'file:download' => 'Скачать',
    
                 'file:delete:confirm' => 'Вы уверены что хотите удалить этот файл?',
            
                 'file:tagcloud' => 'Облако тэгов',
    
                 'file:display:number' => 'Число файлов для отображения',
    
                 'file:river:created' => '%s закачал',
                 'file:river:item' => 'файл',
                 'file:river:annotate' => '%s прокомментировал ',

                 'item:object:file' => 'Файлы',

                 /**
                  * Embed media
                  **/

                 'file:embed' => "Вставить файл",
                 'file:embedall' => "Все",
                 
    
                 /**
                  * Status messages
                  */
    
                 'file:saved' => 'Ваш файл успешно сохранен.',
                 'file:deleted' => 'Ваш файл успешно удален.',
    
                 /**
                  * Error messages
                  */
    
                 'file:none' => 'Нет файлов.',
                 'file:uploadfailed' => 'Простите, но мы не можем сохранить Ваш файл.',
                 'file:downloadfailed' => 'Простите, но этот файл в данный момент не доступен.',
                 'file:deletefailed' => 'Ваш файл в данный момент не может быть удален.',
    

                 /**
                  * Menu items and titles
                  */
	
                 'messages' => "Сообщения", // "Messages",
                 'messages:back' => "назад к сообщениям",
                 'messages:user' => "Ваш почтовый ящик",
                 'messages:sentMessages' => "Отправленные сообщения", // "Sent messages"
                 'messages:posttitle' => "Сообщения пользователя %s': %s",
                 'messages:inbox' => 'Входящие сообщения', // "Inbox",
                 'messages:send' => "Написать сообщение", // "Send a messages"
                 'messages:sent' => "Отправленные сообщения", // "Sent messages",
                 'messages:message' => "Сообщение" , // "Message",
                 'messages:title' => "Заголовок", // "Title",
                 'messages:to' => 'Кому', // "To",
                 'messages:from' => "От",
                 'messages:fly' => 'Отправить', // "Let it fly",
                 'messages:replying' => 'Сообщение в ответ на', // "Message replying to",
                 'messages:inbox' => 'Входящие сообщения', // "Inbox", // почтовый ящик
                 'messages:sendmessage' => "Написать сообщение", // "Send a message",
                 'messages:compose' => "Написать сообщение", // "Send a message",
                 'messages:sentmessages' => "Отправленные сообщения", // "Sent messages",
                 'messages:recent' => 'Недавние сообщения', // "Recent messages",
                 'messages:original' => "Исходное сообщение",
                 'messages:yours' => "Ваше сообщение",
                 'messages:answer' => "Ответ",
                 
			
                 'item:object:messages' => "Сообщения", // 'Messages',
	
                 /**
                  * Status messages
                  */
	
                 'messages:posted' => 'Ваше сообщение успешно отправлено.', // "Your message was successfully sent.",
                 'messages:deleted' => 'Ваше сообщение успешно удалено.', // "Your message was successfully deleted.",
	
                 /**
                  * Email messages
                  */
	
                 'messages:email:subject' => 'У вас новое сообщение!', 
                 'messages:email:body' => "У вас новое сообщение от %s:

			
%s


Чтобы просмотреть сообщение, перейдите по ссылке:

	%s

Для отправки сообщния %s, перейдите по ссылке:

	%s
",

                 /**
                  * Error messages
                  */

                 'messages:blank' => "Простите, но Вам надо хоть что-нибудь написать в теле сообщения чтобы мы смогли отправить его.",
                 'messages:notfound' => "Простите, но мы не можем найти указанное сообщение.",
                 'messages:notdeleted' => "Простите, но мы не можем удалить это сообщение.",
                 'messages:nopermission' => "У Вас недостаточно привилегий чтобы удалить это сообщение.",
                 'messages:nomessages' => "Здесь сообщений нет.",
                 'messages:user:nonexist' => "Мы не можем найти адресата в базе пользователей.",

	/**
	 * Elgg coppa language pack
	 * 
	 * @package ElggCOPPA
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		'coppa:text' => 'Мне больше 13 лет',
		'coppa:fail' => 'Необходимо быть старше 13 лет что бы зарегистрироваться на этом сайте',
					
		/**
		 * Feeds widget details
		 */
		
	    'feeds' => "Ленты", //"Feeds",
	    'feeds:addfeed' => "Добавить ленту", //"Add feed",
	    'feeds:title' => "Заголовок", //"Title",
	    'feeds:read' => "Ваши ленты", //"Your feeds",
	    'feeds:friends' => "Ленты друзей", //"Friends feeds",
	    'feeds:everyone' => "Ленты сайта", //"Site feeds",
		'feeds:url' => "URL ленты", //'Feed URL',
		'feeds:list' => "Список лент", //'Feed list',
		'feeds:yourfeeds' => "Ваши ленты", //'Your feeds',
		'feeds:friendsfeeds' => "Ленты друзей", //'Friends\' feeds',
		'feeds:sitefeeds' => "Ленты сайта", //'Site feeds',
		'feeds:deleted' => "Удаленные ленты", //'Feed deleted',
		'feeds:notdeleted' => "Ваша лента не была удалена", //'Your feed was not deleted',
		'feeds:nofeeds' => "Нет лент для просмотра", //"There are no feeds to display",
		'feeds:allfeeds' => "Все ленты сайта", //"All site feeds",
		'feeds:suredelete' => "Вы уверены что хотите удалить эту ленту?", //"Are you sure you want to delete this feed?",
		
		 /**
	     * Feeds widget river
	     **/
	        
	        //generic terms to use
	        'feeds:river:created' => "%s добавил виджет для чтения лент", //"%s added the feeds widget.",
	        'feeds:river:updated' => "%s обновил виджет для чтения лент", //"%s updated their feeds widget.",
	        'feeds:river:delete' => "%s удалил свой виджет для чтения лент", //"%s removed their feeds widget.",
	        
	    /**
	    * Feed actions
	    **/
	    
	        'feeds:added' => "Ваша лента была добавлена", //"Your feed has been added.",
	        
	    /**
	    * Feed errors
	    **/
	    
	        'feeds:error' => "Невозможно сохранить ленту", //"There was a problem saving your feed.",
	        'feeds:blank' => "Невозможно сохранить ленту", //"There was no feed to save.",
	        
	    /**
	    * Welcome messages
	    **/
	    
	        'feeds:welcome' => "Добро пожаловать в Ваш простой просмотрщик лент. Здесь Вы можете подписаться на любые RSS ленты и следить за их активностью. Для начала нажмите на кнопку слева.", //"Welcome to your simple feed reader, here you can subscribe to RSS feeds from around the web and then view the latest activity here. To get started, click on the add button over on the left hand side",
	        'feeds:friendswelcome' => "Эта страница позволит Вам видеть все ленты Ваших друзей. Список доступных лент Вы видите справа. Нажмите на ссылку для чтения содержимого.", //"This page lets you view all of the feeds your friends have made available to their network. If any are available, you will see a list over on the righthand side. Click on a link to read the contents",
	        'feeds:sitewelcome' => "Здесь Вы можете видеть все ленты, на которые подписаны пользователи нашего сайта. Для чтения содержимого выберите ленту в списке слева.", //"Here you can see all the feeds that have been subscribed to by people on the site. To read the latest feeds, click on the links over on the left hand side",

	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		/**
		 * Menu items and titles
		 */
			
			'pages' => "Страницы", //"Pages",
			'pages:yours' => "Ваши страницы", //"Your pages",
			'pages:user' => "Начало", //"Pages home",
			'pages:group' => "Страницы %s", //"%s's pages",
			'pages:all' => "Все страницы сайта", //"All site pages",
			'pages:new' => "Добавить страницу", //"New page",
			'pages:groupprofile' => "Страницы групп", //"Group pages",
			'pages:edit' => "Редактировать страницу", //"Edit this page",
			'pages:delete' => "Удалить эту страницу", //"Delete this page",
			'pages:history' => "История страницы", //"Page history",
			'pages:view' => "Открыть страницу", //"View page",
			'pages:welcome' => "Изменить приветствие", //"Edit welcome message",
			'pages:welcomeerror' => "Невозможно сохранить Ваше приветствие", //"There was a problem saving your welcome message",
			'pages:welcomeposted' => "Ваше привествие сохранено", //"Your welcome message has been posted",
			'pages:navigation' => "Навигация", //"Page navigation",
	
			'item:object:page_top' => "Страницы первого уровня", //'Top-level pages',
			'item:object:page' => "Страницы", //'Pages',
			'item:object:pages_welcome' => "Блоки привествия", //'Pages welcome blocks',
	
	
		/**
		 * Form fields
		 */
	
			'pages:title' => "Заголовок", //'Pages Title',
			'pages:description' => "Описание", //'Your page entry',
			'pages:tags' => "Тэги", //'Tags',	
			'pages:access_id' => "Доступ", //'Access',
			'pages:write_access_id' => "Доступ для записи", //'Write access',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => "Нет доступа к странице", //'No access to page',
			'pages:cantedit' => "Вы не можете изменять эту страницу", //'You can not edit this page',
			'pages:saved' => "Страница сохранена", //'Pages saved',
			'pages:notsaved' => "Страница не может быть сохранена", //'Page could not be saved',
			'pages:notitle' => "Вы должны указать заголовок статьи", //'You must specify a title for your page.',
			'pages:delete:success' => "Ваша страница удалена", //'Your page was successfully deleted.',
			'pages:delete:failure' => "Эта страница не может быть удалена", //'The page could not be deleted.',
	
		/**
		 * Page
		 */
			'pages:strapline' => "Последнее исправление %s %s", //'Last updated %s by %s',
	
		/**
		 * History
		 */
			'pages:revision' => "Создано %s %s", //'Revision created %s by %s',
			
		/**
		 * Widget
		 */
			'pages:num' => 'Количество страниц на одной странице',
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Смотреть", //"View page",
			'pages:label:edit' => "Редактировать", //"Edit page",
			'pages:label:history' => "История", //"Page history",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Эта страница", //"This page",
			'pages:sidebar:children' => "Разделы", //"Sub-pages",
			'pages:sidebar:parent' => "Родитель", //"Parent",
	
			'pages:newchild' => "Создать раздел", //"Create a sub-page",
			'pages:backtoparent' => "Вернуться к '%s'", //"Back to '%s'",

			
		'openid_client_login_title'                     => "Войти при помощи OpenID",
		'openid_client_login_service'                   => "Сервис",
		'openid_client_logon'                           => "Вход",
		'openid_client_go'                              => "Вход",
		'openid_client_remember_login'                  => "Запомнить вход",
		'openid_client:already_loggedin'                => "Вы уже вошли.",
		'openid_client:login_success'                   => "Вы успешно авторизовались.",
		'openid_client:login_failure'                   => "Имя пользователя не указано. Система не может вас авторизовать.",
		'openid_client:disallowed'                      => "Этот сайт не позволяет OpenID который вы ввели. "
		        ."Попробуйте другой OpenID или обратитесь к администрации для получения дополнительной информации.",
		'openid_client:redirect_error'                  => "Не удалось перенаправить на сервер: %s",
		'openid_client:authentication_failure'          => "OpenID ошибка авторизации: %s некорректный OpenID URL.",
		'openid_client:authentication_cancelled'        => "OpenID авторизация прервана.",
		'openid_client:authentication_failed'           => "OpenID ошибка авторизации (статус: %s, сообщение: %s )",
		'openid_client:banned'                          => "Вы забанены в системе!",
		'openid_client:email_in_use'                    => "Невозможно изменить ваш адрес электронной почты %s, поскольку он уже зарегистрирован в системе.",
		'openid_client:email_updated'                   => "Ваш адрес электронной почты изменён на %s",
		'openid_client:information_title'               => "Информация OpenID",
		'openid_client:activate_confirmation'           => "Сообщение с подтверждением отправлено на %s ."
		        ." Перейдите по ссылке в этом сообщении что бы активировать вашу учётную запись."
		        ." Вы сможете входить в систему используя указанный вами OpenID.",
        'openid_client:change_confirmation'             => "Ваш адрес электронной почты изменился. Сообщение с подтверждением было выслано на"
                ." ваш новый адрес %s . Пожалуйста, перейдите по ссылке в этом сообщении что бы подтвердить ваш новый адрес электронной почты. ",
        'openid_client:activate_confirmation_subject'   => "Проверка пользователя %s",
        'openid_client:activate_confirmation_body'      => "Уважаемый(-ая) %s,\n\nСпасибо за регистрацию в %s.\n\n"
            ."Что бы завершить регистрацию, перейдите по следующей ссылке:\n\n\t%s\n\nwithin seven days.\n\nRegards,\n\nThe %s team.",
        'openid_client:change_confirmation_subject'     => "Изменение адреса электронной почты пользователя %s",
        'openid_client:change_confirmation_body'        => "Уважаемый(-ая) %s,\n\nМы получили запрос на изменение вашего адреса электронной почты"
            ." зарегистрированного на %s.\n\nЧто бы подвердить изменение адреса на {%s}, перейдите по ссылке :\n\n\t%s\n\nв течении 7 дней."
            ."\n\nС уважением,\n\nКомманда %s.",				
	    'openid_client:email_label'                     => "Адрес электронной почты:",
	    'openid_client:name_label'                      => "Имя:",
	    'openid_client:submit_label'                    => "Обновить",
	    'openid_client:cancel_label'                    => "Отменить",
	    'openid_client:nosync_label'                    => "Не уведомлять меня снова если информация в этой системе не совпадает"
	        ." с информацией на моём OpenID сервере.",
	    'openid_client:sync_instructions'               => "Информация в нашей системе отлична от информации на вашем OpenID сервере."
	        ." Поставьте галочку напротив тех данных, которые вы хотели бы обновить (если такие есть) и нажмите 'Обновить'.",
	    'openid_client:missing_title'					=> "Пожалуйста, укажите недостающую информацию",
	    'openid_client:sync_title'						=> "Синхронизировать ваши данные",
	    'openid_client:missing_email'                   => "корректный адрес электронной почты",
	    'openid_client:missing_name'                    => "ваше полное имя",
	    'openid_client:and'                             => "и",
	    'openid_client:missing_info_instructions'       => "Что бы создать учётную запись на данном сайте, необходимо указать %s."
	        ." Пожалуйста, введите эту информацию ниже.",
	    'openid_client:create_email_in_use'             => "Невозможно создать учётную запись с таким адресом электронной почты, поскольку он уже используется в системе.",
	    'openid_client:missing_name_error'              => "Необходимо указать имя.",
	    'openid_client:invalid_email_error'             => "Необходимо указать корректный адрес электронной почты.",
	    'openid_client:invalid_code_error'              => "Ваша форма содержит некорректные данные. Коды хранятся только 7 дней,"
	        ." возможно ваши уже устарели.",
	    'openid_client:user_creation_failed'            => "Не удалось создать учётную запись OpenID.",
	    'openid_client:created_openid_account'          => "Учётная запись OpenID создана, адрес электронной почты %s и имя %s получены с сервера OpenID.",
	    'openid_client:name_updated'                    => "Ваше имя изменено на %s.",
	    'openid_client:missing_confirmation_code'       => "Ваш код подверждения отсутствует. Проверьте ссылку и попробуйте ещё раз.",
	    'openid_client:at_least_13'                     => "Вы обязаны указать, что вам больше 13 лет что бы зарегистрироваться.",
	    'openid_client:account_created'                 => "Ваша учётная запись создана! Теперь вы можете войти используя OpenID (%s), который указали.",
	    'openid_client:email_changed'                   => "Ваш адрес электронной почты изменён на {%s} . "
		    ."Теперь вы можете войти используя ваш OpenID, если вы ещё этого не сделали.",
		'openid_client:thankyou'                        => "Спасибо за регистрацию в %s!"
	        ." Регистрация абсолютно бесплатна, но прежде чем вы подтвердите ваши данные,"
	        ." пожалуйста ознакомьтесь со следующими документами:",
	    'openid_client:terms'                           => "Условия использования",
	    'openid_client:privacy'                         => "Приватность",
	    'openid_client:acceptance'                      => "Отправка формы означает ваше согласие с этими условиями. "
	        ."Обратите внимание, что вы должны быть старше 13 лет что бы зарегистрироваться на нашем сайте.",
	    'openid_client:correct_age'                     => "Мне больше тринадцати лет.",
	    'openid_client:join_button_label'               => "Присоединиться",
	    'openid_client:confirmation_title'              => "Подтверждение OpenID",
	    'openid_client:admin_title'                     => "Настроить клиента OpenID",
	    'openid_client:default_server_title'             => "Сервер по умолчанию",
	    'openid_client:default_server_instructions1'     => "Вы можете облегчить вход используя OpenID, указав OpenID сервер по умолчанию."
            ." Для пользователей, которые указывают простой логин (например \"susan\"), можно развернуть их логин в полноценный OpenID"
	        ." если вы укажете здесь сервер по умолчанию. Укажите \"%s\" в месте, где должно располагаться имя пользователя. Например, укажите"
	        ." \"http://openidserver.com/%s/\" если вы хотите что бы OpenID стал \"http://openidserver.com/susan/\" or"
	        ." \"http://%s.openidserver.com/\" если вы хотите что бы OpenID стал \"http://susan.openidserver.com/\"",
	    'openid_client:default_server_instructions2'    => "Наличие точек (\".\") используюется для разделения URL-ов OpenID от обычных"
	        ." логинов, и значит вы можете использовать данную возможность только для серверов, которые не позволяют использование точек в именах пользователей.",
	    'openid_client:server_sync_title'               => "Синхронизация",
	    'openid_client:server_sync_instructions'        => "Включите данную опцию если вы хотите автоматически обновлять данные клиента, если они отличаются"
	        ." от его данных на OpenID сервере. Не включайте данную опцию"
	        ." если вы хотите дать пользователям возможность иметь имя или адрес электронной почты на вашем сайте"
	        ." отличные от имени и адреса на OpenID cервере.",
	    'openid_client:server_sync_label'               => "Автоматически обновлять данные с OpenID сервера.",
	    'openid_client:lists_title'                     => "Списки OpenID",
	    'openid_client:lists_instruction1'              => "Вы можете настроить зелёный, жёлтый и красный списки OpenID, которые этот клиент будет принимать.",
	    'openid_client:lists_instruction2'              => "Зелёный список содержит OpenID сервера, которые будут приниматься без проверки адреса электронной почты",
	    'openid_client:lists_instruction3'              => "Желтый список содержит OpenID сервера, которые могут только авторизоваться."
	        ." Если они предоставляют адрес электронной почты, он будет проверен посылкой на него сообщения, прежде чем будет разрешена регистрация.",
	    'openid_client:lists_instruction4'              => "Красный список содержит OpenID сервера, которые запрещены.",
	    'openid_client:lists_instruction5'              => "Если вы не укажете зелёный, желтый или красный список, по умолчанию все OpenID сервера"
	        ." будут иметь зелёный статус (и адреса электронной почты будут регистрироваться в системе без дополнительной проверки",
	    'openid_client:lists_instruction6'              => "По одному OpenID серверу в каждой строке. Можно использовать \"*\" что бы"
	        ." заменить любую последовательность символов в имени сервера. Каждая запись должна начинаться с http:// или https:// и заканчиваться"
	        ." слешем (\"/\") - например http://*.myopenid.com/",
	    'openid_client:green_list_title'                => "Зелёный список",
	    'openid_client:yellow_list_title'               => "Желтый список",
	    'openid_client:red_list_title'                  => "Красный список",
	    'openid_client:ok_button_label'                 => "Сохранить",
	    'openid_client:admin_response'                  => "Настройки клиента OpenID сохранены.",


		'friends:invite' => 'Пригласить друзей',
		'invitefriends:introduction' => 'Что бы пригласить друзей подключиться к нашей сети, введите их адреса электронной почты (по одному в строке):',
		'invitefriends:message' => 'Введите сообщение, которое они получат с вашим приглашением:',
		'invitefriends:subject' => 'Присоединяйся к %s',
	
		'invitefriends:success' => 'Сообщение отправлено вашим друзьям.',
		'invitefriends:failure' => 'Не удалось отправить сообщение.',
	
		'invitefriends:message:default' => '
Привет,

Я хочу пригласить тебя в социальную сеть %s.',
		'invitefriends:email' => '
Вас пригласил присоединиться к социальной сети %s пользователь %s. Он передаёт следующее сообщение:

%s

Что бы присоединиться к нам, перейдите по этой ссылке:

	%s

Вы автоматически станете друзьями, когда зарегистрируетесь в системе.',

		'friends:invite' => 'Пригласить друзей',
		'invitefriends:introduction' => 'Что бы пригласить друзей подключиться к нашей сети, введите их адреса электронной почты (по одному в строке):',
		'invitefriends:message' => 'Введите сообщение, которое они получат с вашим приглашением:',
		'invitefriends:subject' => 'Присоединяйся к %s',
	
		'invitefriends:success' => 'Сообщение отправлено вашим друзьям.',
		'invitefriends:failure' => 'Не удалось отправить сообщение.',
	
		'invitefriends:message:default' => '
Привет,

Я хочу пригласить тебя в социальную сеть %s.',
		'invitefriends:email' => '
Вас пригласил присоединиться к социальной сети %s пользователь %s. Он передаёт следующее сообщение:

%s

Что бы присоединиться к нам, перейдите по этой ссылке:

	%s

Вы автоматически станете друзьями, когда зарегистрируетесь в системе.',
	

		/**
		 * Site info details
		 */
		
		'siteinfo' => "О сайте",
	    'siteinfo:members' => "Пользователей",
	    'siteinfo:online' => "Сейчас на сайте",
	   

		'openid_server:trust_title'                     => "Уровень доверия",	
		'openid_server:trust_question'                  => "Вы хотите подтвердить ваш OpenID(<code>%s</code>) с помощью <code>%s</code>?",
		'openid_server:remember_trust'                  => "Запомнить это решение",
		'openid_server:confirm_trust'                   => "Да",
		'openid_server:reject_trust'                    => "Нет",
		'openid_server:not_logged_in'                   => "Вы должны войти в систему, что бы разрешить этот запрос.",
		'openid_server:loggedin_as_wrong_user'          => "Вы должны войти в систему как %s, что бы разрешить этот запрос."
		    ." Однако вы вошли в систему как %s.",
		'openid_server:trust_root'                      => "Доверительный ключ",
		'openid_server:trust_site'                      => "Доверительный сайт",
		'openid_server:autologin_url'                   => "URL для автовхода:",
		'openid_server:autologout_url'                  => "URL для автовыхода:",
		'openid_server:iframe_width'                    => "Ширина Iframe (в пикселях)",
		'openid_server:iframe_height'                   => "Высота Iframe (в пикселях)",
		'openid_server:change_button'                   => "Изменить",
		'openid_server:add_button'                      => "Добавить",
		'openid_server:admin_explanation'               => "You can use this page to set default trust roots for your OpenID server."
		    ." These are OpenID client applications that are automatically trusted by people using OpenIDs provided by your server and are"
		    ." useful only if you are using OpenID to integrate a federation of trusted applications. (You need do nothing here if you have no"
		    ." trusted applications.) You can also set autologin and autologout URLs for some or all of your trusted applications if you"
		    ." want your users to be automatically logged in or logged out of these applications when they login and logout of your"
		    ." OpenID server. Normally the autologin and autologout takes place in invisible iframes. If you are debugging this and want"
		    ." the iframes to be visible, you can set the width and height below.",
		'openid_server:trust_root_updated'              => "Доверительный ключ обновлён",
		'openid_server:trust_root_added'                => "Доверительный ключ добавлен",
		'openid_server:trust_root_deleted'              => "Доверительный ключ удалён",
		'openid_server:edit_trust_root_title'           => "Редактировать доверительные ключи",
		'openid_server:manage_trust_root_title'         => "Управление доверительными ключами",
		'openid_server:trust_root_title'                => "Доверительные ключи по умолчанию",
		'openid_server:edit_option'                     => "Редактировать",
		'openid_server:delete_option'                   => "Удалить",
		'openid_server:add_trust_root_title'            => "Добавить доверительный ключ по умолчанию",
		'openid_server:autologin_title'                 => "Происходит вход",
		'openid_server:autologin_body'                  => "Происходит вход ... пожалуйста подождите",
		'openid_server:autologout_title'                => "Происходит выход",
		'openid_server:autologout_body'                 => "Происходит выход ... пожалуйста подождите",		
	    
	/**
	 * Elgg log browser plugin language pack
	 * 
	 * @package ElggPingBack
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		/**
		 * Error messages
		 */
	
			'pingback:error:missingparams' => 'Нехватает параметров для Pingback запроса',
			'pingback:error:targetnotme' => 'Целевой URL не указывает на мой cайт',
			'pingback:error:targetnotfoundinsource' => 'Цель не найдена в источнике, или источник недоступен',
	
			'pingback:success' => 'Получен Pingback',

	
		/**
		 * Flickr widget details
		 */
		
	
		'flickr:id' => 'Укажите ваш Flickr ID.',
		'flickr:whatisid' => 'Если вы не знаете, каков ваш Flickr ID, вы можете использовать следующий сервис <a href="http://idgettr.com/" target="_blank" >http://idgettr.com/</a>, что бы определить его.',
		
		 /**
	     * Flickr widget river
	     **/
	        
	        //generic terms to use
	        'flickr:river:created' => "%s добавил flickr виджет.",
	        'flickr:river:updated' => "%s обновил flickr виджет.",
	        'flickr:river:delete' => "%s удалил flickr виджет.",
	        
		
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Показывает некоторых ваших друзей.",
	        
		
	/**
	 * Elgg groups plugin language pack
	 * 
	 * @package ElggGroups
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

		/**
		 * Menu items and titles
		 */
	
			'opendd' => "OpenDD",
			'opendd:your' => "Моя активность",
			'opendd:feeds' => "Мои подписки",
			'opendd:manage' => "Управлять подписками",
			'opendd:edit' => "Редактировать подписку",

			'opendd:feedurl' => "URL ленты",
	
			'opendd:notobject' => "Сущность не является объектом, этого не должно было случиться.",
			'opendd:feednotok' => "Невозможно редактировать ваши OpenDD ленты.",
			'opendd:feedok' => "Успешно подписались на ленту.",
	
			'opendd:deleted' => "Подписка на ленту удалена.",
			'opendd:notdeleted' => "Не удалось удалить подписку на ленту.",
	
			'opendd:noopenddfound' => "Не найдены элементы OpenDD в потоке.",
	
			'opendd:metadata:uuid' => "UUID метаданных",
			'opendd:metadata:entityuuid' => "Ссылается на UUID",
			'opendd:metadata:owneruuid' => "Владелец",
			'opendd:metadata:key' => "Ключ",
			'opendd:metadata:value' => "Значение",
	
			'opendd:entity:uuid' => "UUID (универсальный идентификатор)",
			'opendd:entity:class' => "Класс",
			'opendd:entity:subclass' => "Субкласс",
	
			'opendd:published' => "Опубликовано",
	
			'opendd:nodata' => "Не удалось получить ленту, ответ: %s",
			'opendd:noriver' => "Нет данных.",
	
			'opendd:widgets:elsewhere:title' => "Друзья на других сайтах",
			'opendd:widgets:elsewhere:description' => "Этот виджет использует OpenDD что бы показать ваших друзей на других сайтах.",

		/**
		 * Menu items and titles
		 */
	
			'status' => "Статус",
			'status:user' => "Статус пользователя %s",
			'status:current'=> "Текущий статус",
			'status:desc'=> "Этот виджет показывает ваш последний статус.",
			'status:posttitle' => "Статус пользователя %s: %s",
			'status:everyone' => "Все статусы сайта",
			'status:strapline' => "%s",
			'status:addstatus' => "Установить статус",
		    'status:messages' => "История изменения статуса",
			'status:text' => "Статус:",
			'status:set' => "установлен ",
			'status:clear' => "очистить статус",
			'status:delete' => "удалить статус",
			'status:nostatus' => "Статус не установлен.",
			'status:viewhistory' => "предыдущие",
	
			'item:object:status' => 'Сообщения о статусе',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "%s обновил",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "свой статус.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Ваш новый статус успешно установлен.",
			'status:deleted' => "Ваш новый статус успешно удалён.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Извините; вам необходимо указать статус прежде, чем его сохранять.",
			'status:notfound' => "Извините, мы не можем найти указанное сообщение о статусе.",
			'status:notdeleted' => "Извините, мы не можем удалить указанное сообщение о статусе.",
			'status:notsaved' => "Произошла ошибка при сохранении, попробуйте ещё раз или свяжитесь с администрацией.",
			'status:problem' => "Произошла ошибка, похоже что вы не можете отредактировать этот статус.",
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Закладки",
			'bookmarks:add' => "Добавить закладку",
			'bookmarks:read' => "Закладки",
			'bookmarks:friends' => "Закладки друзей",
			'bookmarks:everyone' => "Все закладки сайта",
			'bookmarks:this' => "Добавить в закладки",
			'bookmarks:bookmarklet' => "Получить bookmarklet",
			'bookmarks:inbox' => "Входящие закладки",
			'bookmarks:more' => "Больше закладок",
			'bookmarks:shareditem' => "Закладка",
			'bookmarks:with' => "Поделиться с",
	
			'bookmarks:address' => "Адрес ресурса",
	
			'bookmarks:delete:confirm' => "Вы уверены что хотите удалить эту закладку ?",
	
			'bookmarks:shared' => "Закладка",
			'bookmarks:visit' => "Перейти к ресурсу",
			'bookmarks:recent' => "Мои закладки",
	
			'bookmarks:river:created' => '%s добавил в закладки',
			'bookmarks:river:annotate' => '%s оставил комментарий к',
			'bookmarks:river:item' => 'ссылку',
	
			'item:object:bookmarks' => 'Закладки',
	
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Этот виджет создан для вашей панели инструментов. В нём будут показаны последние входящие закладки.",
	
			'bookmarks:bookmarklet:description' =>
					"Этот инструмент позволить вам поделиться любой ссылкой которую вы найдёте в сети с вашими друзьями, или просто оставить её у себя в закладках. Что бы установить этот bookmarklet просто перетяните кнопку на панель инструментов вашего браузера:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Если вы пользуетесь браузером Internet Explorer, для установки bookmarklet-а вам необходимо нажать правой кнопкой мыши на кнопке bookmarklet-а, выбрать 'Добавить в избранное', и потом выбрать папку 'Избранное' -> 'Ссылки'.",+
			'bookmarks:bookmarklet:description:conclusion' =>
					"После этого вы сможете добавить себе в закладки на сайте и поделиться с друзьями страницей, которую вы посещаете, просто нажав на закладку в любое время.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Закладка успешно добавлена.",
			'bookmarks:delete:success' => "Закладка успешно удалена.",
	
		/**
		 * Error messages
		 */
	
			'bookmarks:save:failed' => "Не удалось сохранить закладку, попробуйте ещё раз.",
			'bookmarks:delete:failed' => "Не удалось удалить закладку, попробуйте ещё раз.",
	

                 /**
                  * Menu items and titles
                  */

                 'messageboard:board' => 'Доска сообщений',//"Message board",
                 'messageboard:messageboard' => 'доска сообщений', // "message board",
                 'messageboard:viewall' => 'Просмотреть все', // "View all",
                 'messageboard:postit' => 'Написать',//"Post it",
                 'messageboard:history' => 'история', // "history",
                 'messageboard:none' => 'На этой доске сообщений пока пусто',
                 'messageboard:num_display' => 'Число сообщений для отображения',
                 'messageboard:desc' => 'Это доска сообщений, которую Вы можете разместить в своем профиле, и другие пользователи могут комментировать.',
			
                 /**
                  * Message board widget river
                  **/
	        
                 'messageboard:river:annotate' => '%s оставил новый комментарий на сообщение на своей доске',
                 'messageboard:river:posted' => '%s оставил сообщение на доске пользователя %s',
                 'messageboard:river:create' => '%s добавил себе доску сообщений.',
                 'messageboard:river:update' => '%s обновил свою доску сообщений.',
			
                 /**
                  * Status messages
                  */
	
                 'messageboard:posted' => 'Вы успешно написали на доске сообщений.',
                 'messageboard:deleted' => 'Вы успешно удалили сообщение.',
	
                 /**
                  * Email messages
                  */
	
                 'messageboard:email:subject' => 'У Вас новый комментарий на доске сообщений!',
                 'messageboard:email:body' => "У Вас новый комментарий на доске сообщений от %s. It reads:',

			
%s


Для просмотра комменатрия на доске сообщений, нажмите здесь:

	%s

Для просмотра профиля %s, нажмите здесь:

	%s

Вы не можете ответить на это сообщенией.",
	
	
                 /**
                  * Error messages
                  */
	
                 'messageboard:blank' => "Простите, но Вам надо хоть что-нибудь написать в теле сообщения чтобы мы смогли отправить его.",
                 //"Sorry; you need to actually put something in the message area before we can save it.",
                 'messageboard:notfound' => "Простите, но мы не можем найти указанное сообщение.",
                 //"Sorry; we could not find the specified item.",
                 'messageboard:notdeleted' => "Простите, но мы не можем удалить это сообщение.",
                 //"Sorry; we could not delete this message.",
	     
                 'messageboard:failure' => "Возникла непредвиденная ошибка при добавлении Вашего сообщения. Пожалуйста, попробуйте еще раз.",
                 //"An unexpected error occurred when adding your message. Please try again.",

		'friendfeed' => 'FriendFeed',
	
		'friendfeed:username' => 'Имя пользователя для FriendFeed',
		'friendfeed:apikey' => 'Ключ API FriendFeed',
		'friendfeed:apikeyfind' => 'найти ваш ключ',
		'friendfeed:num_display' => 'Количество показываемых записей',
	
	
		'friendfeed:favorited' => "Добавили в избранное: ",
	
		'friendfeed:nouser' => 'Этот виджет ещё не настроен.',
		'friendfeed:nonefound' => 'Нет информации.',
		'friendfeed:epicfail' => 'Не удалось соединиться с FriendFeed данного пользователя.',
			

    /**
	 * Elgg LDAP authentication
	 * 
	 * @package ElggLDAPAuth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Misja Hoebe <misja@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com
	 */

        'ldap_auth:settings:label:host' => "Хост",
        'ldap_auth:settings:label:connection_search' => "Настройки LDAP",
        'ldap_auth:settings:label:hostname' => "Имя хоста",
        'ldap_auth:settings:help:hostname' => "Введите каноническое имя хоста, например <i>ldap.yourcompany.com</i>",
        'ldap_auth:settings:label:port' => "Порт LDAP сервера",
    	'ldap_auth:settings:help:port' => "Порт LDAP сервера, по умолчанию 389, большинство серверов используют именно его.",
        'ldap_auth:settings:label:version' => "Версия LDAP протокола",
        'ldap_auth:settings:help:version' => "Версия LDAP протокола. По умолчанию 3, большинство серверов используют именно его.",
        'ldap_auth:settings:label:ldap_bind_dn' => "DN для соединения с LDAP",
        'ldap_auth:settings:help:ldap_bind_dn' => "Какой использовать DN для не-анонимного соединения, например <i>cn=admin,dc=yourcompany,dc=com</i>",
        'ldap_auth:settings:label:ldap_bind_pwd' => "Пароль для соединения с LDAP",
        'ldap_auth:settings:help:ldap_bind_pwd' => "Какой использовать пароль для не-анонимного соединения.",
        'ldap_auth:settings:label:basedn' => "Базовый DN",
        'ldap_auth:settings:help:basedn' => "Базовый DN. Используйте двоеточие (:) что бы ввести несколько DN, например <i>dc=yourcompany,dc=com : dc=othercompany,dc=com</i>",
        'ldap_auth:settings:label:filter_attr' => "В каком аттрибуте содержится Username",
        'ldap_auth:settings:help:filter_attr' => "В каком аттрибуте содержится username, обычно это <i>cn</i>, <i>uid</i> или <i>sAMAccountName</i>.",
        'ldap_auth:settings:label:search_attr' => "Аттрибуты для поиска",
        'ldap_auth:settings:help:search_attr' => "Введите аттрибуты для поиска как пары ключ:значение, где ключ является аттрибутом в Elgg, а значение - его эквивалентом в LDAP .
         Ключи <i>firstname</i>, <i>lastname</i> and <i>mail</i> используются для создания пользователя в Elgg. Следующий пример будет работать для ActiveDirectory:<br/>
         <blockquote><i>firstname:givenname, lastname:sn, mail:mail</i></blockquote>",
        'ldap_auth:settings:label:user_create' => "Создать пользователя",
        'ldap_auth:settings:help:user_create' => "Создавать пользователя в Elgg если удалось его авторизовать в LDAP.",
        'ldap_auth:no_account' => "Ваши имя пользователя и пароль корректны, но ваш аккаунт не найден - пожалуйста, свяжитесь с администрацией",
        'ldap_auth:no_register' => 'Не удалось создать для вас аккаунт - пожалуйста, свяжитесь с администрацией.',
    );
    
    add_translation('ru', $russian);
?>
