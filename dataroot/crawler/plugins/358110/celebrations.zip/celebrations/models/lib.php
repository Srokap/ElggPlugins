<?php

//calcular los días que faltan
function check_days($datecelebration){
	$today = gmstrftime("%Y/%m/%d");
	//system_message(sprintf('hoy es'.$today));
	$numdaysuntil = round((strtotime($datecelebration)-strtotime($today))/(24*60*60),0);
	return $numdaysuntil;
}
//convertir las fechas
function convert_date($fecha,$feast){
	if ($feast == 1){
		list($dia, $mes) = explode("-", $fecha);
		$celebration = gmstrftime("%Y").'/'.$mes.'/'.$dia;
	} else {
		$celebration = gmstrftime("%Y").'/'.gmstrftime("%m",$fecha).'/'.gmstrftime("%d",$fecha);
	}
	return $celebration;
}
//date order
function printcelebrationsdate($type,$date){
	// I use this function because setlocale don't work properly in all servers
	$date_type = get_plugin_setting("date_type","celebrations");
	if(!$date_type) $date_type = 1;
	if (!type) $type = 1; //by default short date
	if (!isset($date)){
		$date = time();
	}
	if ($date_type == 1){
		if ($type == 1){
			$transformdate = gmstrftime("%e/%m/%Y",$date);
		} else {
			$transformdate = gmstrftime("%e %B %Y", $date);
		}		
	} else {		
		if ($type == 1){
			$transformdate = gmstrftime("%m/%d/%Y",$date);
		} else {
			$transformdate = gmstrftime("%B %e, %Y", $date);
		}		
	}
	
	return $transformdate;
}

//busca si las fechas corresponden a los proximos dias
function comprobarsiguientesdias($fecha,$feast,$num,$type){
	global $month;
	
	if ($fecha){
		$celebration = convert_date($fecha,$feast);		
		if ($type == 'month'){
			$mes = explode("/", $celebration);
			if ($mes[1] == $month){
				return true;
			} else {
				return false;
			}
		} elseif ($type == 'next'){
			$until = check_days($celebration);
			if (($until >= 0) && ($until <= $num)){
				$until++;
				return $until;
			} else {
				return false;
			}
		}
		
	} else {
		return false; //print 'error no date';
	}
	
}


//funcion para ordenar celebraciones
function orderdate($x, $y){
 if ( $x['rest'] == $y['rest'] )
  return 0;
 else if ( $x['rest'] < $y['rest'] )
  return -1;
 else
  return 1;
}



function user_celebrations($num, $checkdaystype, $filter){
global $CONFIG;
	if (!$filter) $filter = 0;
	if($filter < 0){
		$users = get_user_friends(get_loggedin_user()->guid,"",1000000);
	} elseif ($filter >= 1){
		if (is_group_member($filter, get_loggedin_user()->guid)){
			$users = get_group_members($filter, $limit=1000000, $offset=0, $site_guid=0, $count=false);
		}
	} else {
		$users = get_entities('user','',null,null,0,0); //el cuarto valor es order_by aqui se puede añadir name
	}
	
	//$users = get_data("select a.guid from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes'  order by a.name ASC");
	
	
	//check the profile fields for this plugin. This let us to grow up easily the number of fields
	$celebrationfields = array();
	$prefix = $CONFIG->profile_celebrations_prefix;
	if (is_array($CONFIG->profile) && sizeof($CONFIG->profile) > 0){
		foreach($CONFIG->profile as $shortname => $valtype) {
			$match = '/^'.$prefix.'.*$/';
			if (preg_match($match, $shortname)){
				$varcelebration = $shortname;
				$celebrationfields[$varcelebration] = $valtype;
			}
		}
	}
			
		foreach($users as $allusers){
			$user = get_user($allusers->guid);
			$fullname = htmlentities($user->name, ENT_QUOTES, 'UTF-8')." ".$user->lastname." ".$user->secondlastname;
			
			foreach($celebrationfields as $key => $valtype){
				$celebrationday = $user->$key;
				$key = mb_substr ($key, strlen($prefix), strlen($key));
				if (($valtype == 'day_anniversary') && ($rest = comprobarsiguientesdias($celebrationday,0,$num,$checkdaystype))){
					$rest = $rest-1;
					$row[] = array('name' => $user->name, 'fullname' => $fullname, 'id' => $user->guid, 'type' => $key, 'date' => $celebrationday, 'url' => $user->getURL(), 'icon' => $user->getIcon('topbar'), 'format' => $valtype, 'rest' => $rest);
				} elseif (($valtype == 'yearly') && ($rest = comprobarsiguientesdias($celebrationday,1,$num,$checkdaystype))){
					$rest = $rest-1;
					list($dia, $mes) = explode("-", $celebrationday);
					$feastday = strtotime(date("Y").'/'.$mes.'/'.$dia);
					$row[] = array('name' => $user->name, 'fullname' => $fullname, 'id' => $user->guid, 'type' => $key, 'date' => $feastday, 'url' => $user->getURL(), 'icon' => $user->getIcon('topbar'), 'format' => $valtype, 'rest' => $rest);
				}
			}
		}	
		
	uasort($row, 'orderdate'); //sort by celebration
	return $row;
}

function filterlist($user_guid){
	$user_guid = $vars['user_guid'];
	if (!$user_guid) $user_guid = get_loggedin_user()->guid;
	$mygroups = get_users_membership($user_guid);
	 
	$filteroptions = array();
	$filteroptions = array('0'=>elgg_echo('celebrations:option_all'),'-1'=>elgg_echo('celebrations:option_friends'));
	foreach ($mygroups as $mygroup){
		$mygroup_guid = $mygroup['guid'];
		$filteroptions[$mygroup_guid] = $mygroup['name'];
	}
	return $filteroptions;
}
function showage($birthday){
	//fist test
	/*$dob = gmstrftime("%Y-%m-%d",$birthday);
	$age = date('Y') - date('Y', strtotime($dob));
	if (date('md') < date('md', strtotime($dob))) {
	    $age--;
	}*/
  // Parse Birthday Input Into Local Variables
  // Assumes Input In Form: YYYYMMDD
  $yIn=gmstrftime("%Y",$birthday);
  $mIn=gmstrftime("%m",$birthday);
  $dIn=gmstrftime("%d",$birthday);

  // Calculate Differences Between Birthday And Now
  // By Subtracting Birthday From Current Date
  $ddiff = gmstrftime("%d") - $dIn;
  $mdiff = gmstrftime("%m") - $mIn;
  $ydiff = gmstrftime("%Y") - $yIn;

  // Check If Birthday Month Has Been Reached
	if ($mdiff < 0){
    	// Birthday Month Not Reached
    	// Subtract 1 Year From Age
    	$ydiff--;
	} elseif ($mdiff==0){
    	// Birthday Month Currently
    	// Check If BirthdayDay Passed
		if ($ddiff < 0){
			//Birthday Not Reached
			// Subtract 1 Year From Age
			$ydiff--;
		}
	}
	return $ydiff;
}
?>