<?php

	/**
	 * Elgg Celebrations Plugin 1.2
	 * 
	 * @package Celebrations
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells - ferg
	 * @copyright Fernando Graells 2009
	 * @link
	 * 
	 */
	
		function celebrations_init() {
		global $CONFIG;
		
		if (get_plugin_setting("ViewReminder","celebrations") == 'yes'){
			register_elgg_event_handler('login','user','show_next_celebrations');
		}
	
		if (get_input('filterid')){
			$filterid = get_input('filterid');
		} else {
			$filterid = 0;
		}
		add_menu(elgg_echo('celebrations:shorttitle') , $CONFIG->wwwroot . "mod/celebrations");
		//add submenu options
				if (get_context() == "celebrations") {
					for($i = 1; $i <= 12; $i += 1){
						add_submenu_item(elgg_echo("month:{$i}"), $CONFIG->wwwroot . "mod/celebrations/index.php?month=".$i."&filterid=".$filterid);
					}
				}
				
		// Extend system CSS with our own styles, which are defined in the shouts/css view
				extend_view('css','celebrations/css');
				
				extend_view('celebrations/list_celebrations','celebrations/javascript');

				
		// Register a page handler, so we can have nice URLs
		register_page_handler('celebrations','celebrations_page_handler');
		
		register_translations($CONFIG->pluginspath . "celebrations/languages/");
		
		//extend form fields
		//require_once(dirname(__FILE__) . "/models/field_types_extended.php");
		
   		//add a widget
			add_widget_type('today_celebrations',elgg_echo("today_celebrations:title"),elgg_echo("today_celebrations:description"));
			add_widget_type('next_celebrations',elgg_echo("next_celebrations:title"),elgg_echo("next_celebrations:description"));
		}
		
		function celebrations_page_handler($page){
			global $CONFIG;
			include($CONFIG->pluginspath . "celebrations/index.php"); 
		}
		
		function show_next_celebrations(){
			global $CONFIG;
			include($CONFIG->pluginspath . "celebrations/models/lib.php");
			
			$ViewReminder = get_plugin_setting("ViewReminder","celebrations");
			if(!$ViewReminder) $ViewReminder = "no";
			
			if ($ViewReminder = "yes"){
				$nextdaysCelebrations = get_plugin_setting("nextdaysCelebrations","celebrations");
				if(!$nextdaysCelebrations) $nextdaysCelebrations = 7;
				
				//$celebrations = next_user_celebrations($nextdaysCelebrations);
				$celebrations = user_celebrations($nextdaysCelebrations, 'next');
				
				//draw celebrations
				if ($celebrations){
					foreach($celebrations as $key => $val) {
						if ($val['rest'] == 0){
							$days = elgg_echo('next_celebrations:today');
						} elseif ($val['rest'] == 1){
							$days = elgg_echo('next_celebrations:in').' 1 '.elgg_echo('next_celebrations:dayleft');
						} else {
							$days = elgg_echo('next_celebrations:in').' '.$val['rest'].' '.elgg_echo('next_celebrations:daysleft');
						}
						
						system_message(sprintf($val['fullname'].elgg_echo('next_celebrations:celebrate').elgg_echo('today_celebrations:'.$val['type']).' '.$days));
					}
				}
			}
			return true;
		}
		
		function celebrations_profile_fields_setup(){
			global $CONFIG;
			
			// add celebrations fields to the core profile
			if((get_plugin_setting("lastname_field","celebrations") == 'yes') && (!isset($CONFIG->profile['lastname']))){
				$CONFIG->profile['lastname'] = 'text'; //optional
			}
			if((get_plugin_setting("secondlastname_field","celebrations") == 'yes') && (!isset($CONFIG->profile['secondlastname']))){
				$CONFIG->profile['secondlastname'] = 'text';//optional
			}
			if ((get_plugin_setting("celebrations_birthdate_field","celebrations") == 'yes') && (!isset($CONFIG->profile['celebrations_birthdate']))){
				$CONFIG->profile['celebrations_birthdate'] = 'day_anniversary';
			}
			if ((get_plugin_setting("celebrations_dieday_field","celebrations") == 'yes') && (!isset($CONFIG->profile['celebrations_dieday']))){
				$CONFIG->profile['celebrations_dieday'] = 'day_anniversary';
			}
			//aquest es la condicio si es fa servir checkboxes
			//veure el plugin phpmailer
			//if ((get_plugin_setting("celebrations_feastdate_field","celebrations") != 'disabled') && (!isset($CONFIG->profile['celebrations_feastdate']))){
			if ((get_plugin_setting("celebrations_feastdate_field","celebrations") == 'yes') && (!isset($CONFIG->profile['celebrations_feastdate']))){
				$CONFIG->profile['celebrations_feastdate'] = 'yearly';
			}
			if ((get_plugin_setting("celebrations_weddingdate_field","celebrations") == 'yes') && (!isset($CONFIG->profile['celebrations_weddingdate']))){
				$CONFIG->profile['celebrations_weddingdate'] = 'day_anniversary';
			}
			$CONFIG->profile_celebrations_prefix = 'celebrations_';
		}
		
		register_elgg_event_handler('init','system','celebrations_profile_fields_setup',10000); // Ensure this runs after other plugins
		register_elgg_event_handler('init','system','celebrations_init');

?>