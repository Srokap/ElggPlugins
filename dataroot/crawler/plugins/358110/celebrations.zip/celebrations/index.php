<?php
	global $CONFIG;
	// Start engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	//require function
	require_once(dirname(__FILE__) . "/models/lib.php");
	
	gatekeeper();
	
	
	if (get_input('filterid')){
		$filterid = get_input('filterid');
	} else {
		$filterid = 0;
	}
	if (get_input('month')){
		$month = get_input('month');
	} else {
		$month = date("n");
		forward($CONFIG->wwwroot . "mod/celebrations/index.php?month=".$month."&filterid=".$filterid);
	}
	
	$user_guid = get_loggedin_user()->guid;
	$js = "onChange=\"MM_jumpMenu('parent',this)\"";
	$divbox = '<div class="sidebarBox"><h3>'.elgg_echo('celebrations:filterby').'</h3>';
	//$users_max = 300;
	//$users = get_entities('user','',null,null,$users_max,0);//didn't use to avoid the limit for max users
	//$users = get_data("select a.guid from {$CONFIG->dbprefix}users_entity as a,{$CONFIG->dbprefix}entities as b  where a.guid =b.guid and b.enabled = 'yes'  order by a.name ASC");
	
	$title = elgg_view_title(elgg_echo('celebrations:title').' '.elgg_echo('next_celebrations:in').' '.elgg_echo("month:{$month}"));
	
	// Format page
	$area2 = $title . elgg_view('celebrations/list_celebrations',array('filterid' => $filterid));
	//$area3 = elgg_view('celebrations/filters', array('user_guid' => $user_guid, 'filterid' => $filterid, 'js' => $js));
	$area3 = $divbox.elgg_view('input/pulldown',array('internalname' => 'input_filterid', 'options_values'=>filterlist($user_guid),'value'=>$filterid,'js'=>$js)).'</div>';
	$body = elgg_view_layout('two_column_left_sidebar', '',$area2,$area3);
	
	// Draw it
	echo page_draw(elgg_echo('celebrations:title'),$body);

?>