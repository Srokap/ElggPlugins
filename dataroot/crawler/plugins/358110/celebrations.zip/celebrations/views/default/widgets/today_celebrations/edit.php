<?php
	/**
	 * Elgg Celebrations Plugin
	 * 
	 * @package Celebrations
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells
	 * @copyright Fernando Graells 2009
	 * @link 
	 * 
	 */
	 //require function
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/models/lib.php");
?>
<p>&nbsp;</p>
<p>
<?php echo elgg_echo('celebrations:filterby').":<br/>";
$user_guid = get_loggedin_user()->guid;
echo elgg_view('input/pulldown',array('internalname' => 'params[todayfilterid]', 'options_values'=>filterlist($user_guid),'value'=>$vars['entity']->filterid));
?>
</p>
	