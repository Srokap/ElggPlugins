a.privatemessages {
	background:transparent url(../mod/celebrations/graphics/messages_icon.gif) no-repeat left 2px;
	padding:0 0 4px 25px;
	margin:0 24px 0 5px;
	cursor:pointer;
}