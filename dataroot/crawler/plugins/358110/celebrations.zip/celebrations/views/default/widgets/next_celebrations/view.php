<?php
 	/**
	 * Elgg Celebrations plugin 1.3
	 * 
	 * @package celebrations, widget next celebrations
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells
	 * @copyright Fernando Graells 2009
	 * @link 
	 * 
	 */

	// Start engine
	require_once(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/engine/start.php");
	//require function
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/models/lib.php");
	
	
	//the number of days to review
	$num = (int) $vars['entity']->nextdaysCelebrations;
	if (!$num){	$num = 7;	}
	
	//filtered users
	$filterid = (int) $vars['entity']->nextfilterid;
	if (!$filterid){	$filterid = 0;	}
	
	print '<div class="contentWrapper user_settings"><p style="text-align:right">'.elgg_echo('today_celebrations:today').' <strong>'.printcelebrationsdate(1).'</strong></p>';
	
	$row_celebrations = user_celebrations($num, 'next', $filterid);
	
// widget settings
/*$date_type = (int) $vars['entity']->date_type;
if (!$date_type){	$date_type = 1;	}*/

$show_today = (int) $vars['entity']->show_today;
if (!$show_today){	$show_today = 0;}


//draw celebrations
if ($row_celebrations){
	print '<table width="100%">';
	
	foreach($row_celebrations as $key => $val) {
		if (($show_today == 1) || ($val['rest'] >= 1)){
			$even_odd = ( 'F3F3F3' != $even_odd ) ? 'F3F3F3' : 'FFFFFF';
			echo "<tr bgcolor=\"#{$even_odd}\">";
		
			//$celebrations_date = printcelebrationsdate($val['date']);
			if ($val['rest'] == 0){
				$daysleftshow = elgg_echo('next_celebrations:today');
			} else if ($val['rest'] == 1){
				$daysleftshow = '<abbr title="'.printcelebrationsdate(1,$val['date']).'">('.$val['rest'].' '.elgg_echo('next_celebrations:dayleft').')</abbr>';
			} else {
				$daysleftshow = '<abbr title="'.printcelebrationsdate(1,$val['date']).'">('.$val['rest'].' '.elgg_echo('next_celebrations:daysleft').')</abbr>';
			}
			
			
			print '<td><img class="user_mini_avatar" src="'.$val['icon'].'"> <a href="'.$val['url'].'" title="'.$val['fullname'].'">'.$val['name'].'</a></td><td align="right">'.elgg_echo('today_celebrations:'.$val['type']).'</td><td>'.$daysleftshow.'</td></tr>';
		}
	}
	print '</table>';
} else {
	print "<p>".sprintf(elgg_echo('next_celebrations:nocelebrations'),$num)."</p>";
}
print '</div>';

?>


