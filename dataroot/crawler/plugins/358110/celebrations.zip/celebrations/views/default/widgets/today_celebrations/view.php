<?php
 	/**
	 * Celebrations Plugin 1.3
	 * 
	 * @package celebrations, widget today celebrations
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells
	 * @copyright Fernando Graells 2009
	 * @link 
	 * 
	 */

	// Start engine
	require_once(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/engine/start.php");
	//require function
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/models/lib.php");
	
	//filtered users
	$filterid = (int) $vars['entity']->todayfilterid;
	if (!$filterid){	$filterid = 0;	}
	
	print '<div class="contentWrapper user_settings"><p style="text-align:right">'.elgg_echo('today_celebrations:today').' <strong>'.printcelebrationsdate(1).'</strong></p>';

	$row_celebrations = user_celebrations(0,'next', $filterid);		

// lista de celebraciones

if ($row_celebrations){
	print '<table width="100%">';
	
	foreach($row_celebrations as $key => $val) {
		if (($val['type'] == 'dieday') || ($val['id'] == get_loggedin_user()->guid)){
			$sendcelebrationsmessage = '';
		} else {
			$sendcelebrationsmessage = '<a href="'.$CONFIG->wwwroot.'mod/messages/send.php?send_to='.$val['id'].'" class="privatemessages" >&nbsp;</a>';
		}
		if ((get_plugin_setting("replaceage","celebrations") == 'yes') && ($val['type'] == 'birthdate')){
			$age = showage($val['date']).' '.elgg_echo('celebrations:age');
		} else {
			$age = '';
		}
		$even_odd = ( 'FFFFFF' != $even_odd ) ? 'FFFFFF' : 'F3F3F3';
		echo "<tr bgcolor=\"#{$even_odd}\">";
		print '<td><img class="user_mini_avatar" src="'.$val['icon'].'"> <a href="'.$val['url'].'" title="'.$val['fullname'].'">'.$val['name'].'</a></td><td align="right">'.elgg_echo('today_celebrations:'.$val['type']).'</td><td>'.$age.'</td><td>'.$sendcelebrationsmessage.'</td></tr>';
	}
	print '</table>';
} else {
	print "<p>".elgg_echo('today_celebrations:nocelebrations')."</p>";
}
print '</div>';

?>




