<?php
	/**
	 * Elgg Celebrations Plugin
	 * 
	 * @package Celebrations
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells
	 * @copyright Fernando Graells 2009
	 * @link 
	 * 
	 */
	 
	 //require function
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/models/lib.php");
?>
<p><?php echo elgg_echo("celebrations:numberdays"); ?>&nbsp;<input type="text" name="params[nextdaysCelebrations]" value="<?php if(!empty($vars['entity']->nextdaysCelebrations)){ echo $vars['entity']->nextdaysCelebrations; } else { echo "7"; }?>" size="2"/></p>
<p><?php echo elgg_echo("celebrations:show_today"); ?>
		<select name="params[show_today]">
			<option value="0" <?php if($vars['entity']->show_today == 0) echo "SELECTED"; ?>>No</option>
			<option value="1" <?php if($vars['entity']->show_today == 1) echo "SELECTED"; ?>>Yes</option>
        </select>
</p>
<p>
<?php echo elgg_echo('celebrations:filterby').":<br/>";
$user_guid = get_loggedin_user()->guid;
echo elgg_view('input/pulldown',array('internalname' => 'params[nextfilterid]', 'options_values'=>filterlist($user_guid),'value'=>$vars['entity']->filterid));
?>
</p>
	