<?php
	/**
	* Celebrations 1.2- Admin settings
	* 
	* @package Celebrations
	* @author Fernando Graells
	* @copyright Fernando Graells 2009
	* @link 
	*/
	

/*<p>
	<?php echo elgg_echo("celebrations:filterusers");?>&nbsp;
	<select name="params[filterusers]">
		<option value="all" <?php if ($vars['entity']->filterusers == 'all' || empty($vars['entity']->filterusers)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('celebrations:option_all'); ?></option>
		<option value="friends" <?php if ($vars['entity']->filterusers == 'friends') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('celebrations:option_friends'); ?></option>
	</select>
<br />&nbsp;</p>
*/
?>
<p>
	<?php echo elgg_echo('celebrations:replaceage');?>&nbsp;
	<select name="params[replaceage]">
		<option value="no" <?php if ($vars['entity']->replaceage == 'no' || empty($vars['entity']->replaceage)) echo " selected=\"no\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		<option value="yes" <?php if ($vars['entity']->replaceage == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
	</select>
<br />&nbsp;</p>
<p>
	<?php echo elgg_echo("celebrations:viewreminder");?>&nbsp;
	<select name="params[ViewReminder]">
		<option value="yes" <?php if ($vars['entity']->ViewReminder == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->ViewReminder == 'no' || empty($vars['entity']->ViewReminder)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p><?php echo elgg_echo("celebrations:numberdays"); ?>&nbsp;
	<input type="text" name="params[nextdaysCelebrations]" value="<?php if(!empty($vars['entity']->nextdaysCelebrations)){ echo $vars['entity']->nextdaysCelebrations; } else { echo "7"; }?>" size="2"/>
<br />&nbsp;
</p>
<p><?php echo elgg_echo("celebrations:date_type"); ?>
		<select name="params[date_type]">
			<option value="1" <?php if($vars['entity']->date_type == 1) echo "SELECTED"; ?>>d/m/Y</option>
			<option value="2" <?php if($vars['entity']->date_type == 2) echo "SELECTED"; ?>>m/d/Y</option>
        </select>
<br />&nbsp;
</p>
<p><?php echo elgg_echo("celebrations:fieldsused");?><br />
<ul>
	<li><?php echo elgg_echo("profile:lastname"); ?>
		<select name="params[lastname_field]">
			<option value="yes" <?php if($vars['entity']->lastname_field == "yes") echo "SELECTED"; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if($vars['entity']->lastname_field == "no") echo "SELECTED"; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
     </li>
     <li><?php echo elgg_echo("profile:secondlastname"); ?>
		<select name="params[secondlastname_field]">
			<option value="yes" <?php if($vars['entity']->secondlastname_field == "yes") echo "SELECTED"; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if($vars['entity']->secondlastname_field == "no") echo "SELECTED"; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
     </li>
     <li><?php echo elgg_echo("profile:celebrations_birthdate"); ?>
		<select name="params[celebrations_birthdate_field]">
			<option value="yes" <?php if($vars['entity']->celebrations_birthdate_field == "yes") echo "SELECTED"; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if($vars['entity']->celebrations_birthdate_field == "no") echo "SELECTED"; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
     </li>
     <li><?php echo elgg_echo("profile:celebrations_dieday"); ?>
		<select name="params[celebrations_dieday_field]">
			<option value="yes" <?php if($vars['entity']->celebrations_dieday_field == "yes") echo "SELECTED"; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if($vars['entity']->celebrations_dieday_field == "no") echo "SELECTED"; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
     </li>
     <li><?php echo elgg_echo("profile:celebrations_feastdate"); ?>
		<select name="params[celebrations_feastdate_field]">
			<option value="yes" <?php if($vars['entity']->celebrations_feastdate_field == "yes") echo "SELECTED"; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if($vars['entity']->celebrations_feastdate_field == "no") echo "SELECTED"; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
     </li>
     <li><?php echo elgg_echo("profile:celebrations_weddingdate"); ?>
		<select name="params[celebrations_weddingdate_field]">
			<option value="yes" <?php if($vars['entity']->celebrations_weddingdate_field == "yes") echo "SELECTED"; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if($vars['entity']->celebrations_weddingdate_field == "no") echo "SELECTED"; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
     </li>
  </ul>
</p>
