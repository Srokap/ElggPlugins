<?php
	/**
	 * Filters in Celebrations lists
	 * 
	 * @package Celebrations plugin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fernando Graells
	 * @copyright Fernando Graells 2009
	 * @link 
	 */
?>

<div class="sidebarBox">	 
<h3><?php echo elgg_echo('celebrations:filterby'); ?></h3>

<?php

	 $user_guid = $vars['user_guid'];
	 if (!$user_guid) $user_guid = get_loggedin_user()->guid;
	 $mygroups = get_users_membership($user_guid);
	 
	 $filter = $vars['filterid'];
	 if (!$filter) $filter = 0;
	 $internalname = $vars['internalname'];
	 if (!$internalname) $internalname = 'input_filterid';

	$filteroptions = array();
	$filteroptions = array('0'=>elgg_echo('celebrations:option_all'),'-1'=>elgg_echo('celebrations:option_friends'));
	foreach ($mygroups as $mygroup){
		$mygroup_guid = $mygroup['guid'];
		$filteroptions[$mygroup_guid] = $mygroup['name'];
	}
	echo elgg_view('input/pulldown',array('internalname' => $internalname, 'options_values'=>$filteroptions,'value'=>$vars['filterid'],'js'=>$vars['js']));

?>
  
</div>