<div class='contentWrapper' align='center'>
<table border=0 width=100%>

<?php

global $CONFIG;
/*if (get_input('month',1)){
		$month = get_input('month',1);
	} else {
		$month = 1;
	}*/
	$filterid = $vars['filterid'];
	
	
// comprueba si la gente individual celebra hoy alguna cosa
$row = user_celebrations(1,'month',$filterid);

	
	// start the draw of celebrations
$row2 = array();	
	if ($row){
		//we calculate the day to order the array
		foreach($row as $key => $val) {
			$celebrations_day = strftime("%d", $val['date']);
			$val['rest'] = $celebrations_day;
			$row2[$key] = $val;
		}
		uasort($row2, 'orderdate'); //sort by day
		foreach($row2 as $key => $val) {
			$even_odd = ( 'FFFFFF' != $even_odd ) ? 'FFFFFF' : 'F3F3F3';
			
			// Let's call it for individual lines so we can add extra info like mariages, children, links etc.
			$celebrations_day = gmstrftime("%d", $val['date']);
			//$celebrations_day = date("d", $val['date']);
			$celebrations_date = printcelebrationsdate(2,$val['date']);
			//$celebrations_date = date("F j, Y", $val['date']);
				

				//Now display a single line
				
		
			echo "<tr bgcolor=\"#{$even_odd}\">";
			echo '<td>'.$val['day'].elgg_echo('celebrations:day').': '.$val['rest'].'</td><td>';
			echo '<img class="user_mini_avatar" src="'.$val['icon'].'"> <a href="'.$val['url'].'">'.$val['fullname'].'</a>';
			echo '</td>';
		
			// show type of celebration
			echo '<td>'.elgg_echo('today_celebrations:'.$val['type']).'</td>';
		
			if ($val['format'] == 'day_anniversary'){
				if ((get_plugin_setting("replaceage","celebrations") == 'yes') && ($val['type'] == 'birthdate')){
					echo "<td>".showage($val['date']).' '.elgg_echo('celebrations:age')."</td>";
				} else {
					echo "<td>".$celebrations_date."</td>";
				}
			} else {
				echo "<td>&nbsp;</td>";
			}
			
			echo "</tr>\n";
		}
		
	
	} else {
		print elgg_echo('today_celebrations:nocelebrations');
	}
?>
</table>
</div>

