<?php
	$spanish = array(
		/**
		 * My HTML details
		 */

		//Profile labels
			'profile:celebrations_birthdate' => "Fecha de nacimiento",
			'profile:celebrations_dieday' => "Fecha de defunción",
			'profile:celebrations_feastdate' => "Día del santo",
			'profile:lastname' => "Apellido",
			'profile:secondlastname' => "Segundo apellido",
			'profile:celebrations_dayofmonth' => "de",
			'profile:celebrations_weddingdate' => "Fecha de la boda",
		
		
		//filter
			'celebrations:filterusers' => "Qué celebraciones quieres mostrar?",
			'celebrations:option_all' => "Todos",
			'celebrations:option_friends' => "Amigos",
			'celebrations:filterby' => "Mostrar usuarios",
		
		// setting
			'celebrations:viewreminder' => "Mostrar recordatorio al conectarse?",
			'celebrations:numberdays' => "Cuántos días quieres ver en el recordatorio?",
			'celebrations:show_today' => "Mostrar celebraciones de hoy?",
			'celebrations:date_type' => "tipo de fecha",
			'celebrations:fieldsused' => "Qué campos quieres utilizar?",
			'celebrations:replaceage' => "Quieres reemplazar el aniversario por la edad?",
		
		// pagina
			'celebrations:title' => "Nuestras celebraciones",
			'celebrations:shorttitle' => "Celebraciones",
			'celebrations:day' => "Día",
			'celebrations:age' => "años",
		
		// widget today celebrations
	        'today_celebrations:title' => "Celebraciones de hoy",
	        'today_celebrations:today' => "Hoy es",
	        'today_celebrations:description' => "Aniversarios, bodas,...", 
	        'today_celebrations:birthdate' => "Aniversario",
	        'today_celebrations:feastdate' => "Santo",
	        'today_celebrations:dieday' => "Defunción",
	        'today_celebrations:weddingdate' => "Boda",
			'today_celebrations:nocelebrations' => "No hay celebraciones, pero puedes avisarnos de alguna",
		
		// widget next celebrations
	        'next_celebrations:title' => "Próximas celebraciones",
	        'next_celebrations:today' => "Hoy es",
	        'next_celebrations:description' => "Próximos aniversarios, bodas,...",
			'next_celebrations:nocelebrations' => "No hay celebraciones en los próximos %s días",
			
		//login reminder
			'next_celebrations:today' => "hoy",
			'next_celebrations:daysleft' => "días",
			'next_celebrations:dayleft' => "día",
			'next_celebrations:celebrate' => " celebra el ",
			'next_celebrations:in' => "en",
			
			/* Form fields */
	        'today_celebrations:profile_birthdate_label' => "Fecha (dd/mm/aaaa)",
	        'today_celebrations:profile_feastdate_label' => "Fecha del santo (dd/mm)",
			
			
			/* Month name */
			"month:1" => "Enero",
			"month:2" => "Febrero",
			"month:3" => "Marzo",
			"month:4" => "Abril",
			"month:5" => "Mayo",
			"month:6" => "Junio",
			"month:7" => "Julio",
			"month:8" => "Agosto",
			"month:9" => "Septiembre",
			"month:10" => "Octubre",
			"month:11" => "Noviembre",
			"month:12" => "Diciembre"
			
			
			
	);
	add_translation("es",$spanish);



?>
