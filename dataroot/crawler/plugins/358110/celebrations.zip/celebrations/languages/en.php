<?php
global $CONFIG;
	$english = array(
		/**
		 * My HTML details
		 */

		//Profile labels
			'profile:celebrations_birthdate' => "Birthdate",
			'profile:celebrations_dieday' => "Date of death",
			'profile:celebrations_feastdate' => "Feastday",
			'profile:lastname' => "Surname",
			'profile:secondlastname' => "Second surname",
			'profile:celebrations_dayofmonth' => "of",
			'profile:celebrations_weddingdate' => "Wedding date",
		
		
		//filter
			'celebrations:filterusers' => "What celebrations do you want to show?",
			'celebrations:option_all' => "All",
			'celebrations:option_friends' => "Friends",
			'celebrations:filterby' => "Show users?",
		
		// setting
			'celebrations:viewreminder' => "View reminder on log in?",
			'celebrations:numberdays' => "How days do you want to see in reminder?",
			'celebrations:show_today' => "Show today celebrations?",
			'celebrations:date_type' => "date type",
			'celebrations:fieldsused' => "Which fields do you want to use?",
			'celebrations:replaceage' => "Dou you want to replace birthday by age?",
		
		// pagina
			'celebrations:title' => "Our celebrations",
			'celebrations:shorttitle' => "View celebrations",
			'celebrations:day' => "Day",
			'celebrations:age' => "years old",
		
		// widget today celebrations
	        'today_celebrations:title' => "Today celebrations",
	        'today_celebrations:today' => "Today is",
	        'today_celebrations:description' => "Anniversaries, weddings,...",
	        'today_celebrations:birthdate' => "Birthday",
	        'today_celebrations:feastdate' => "Feast Day",
	        'today_celebrations:dieday' => "Dieday",
	        'today_celebrations:weddingdate' => "Wedding Day",
			'today_celebrations:nocelebrations' => "There aren't celebrations, but you can suggest yours",
		
		// widget next celebrations
	        'next_celebrations:title' => "Next celebrations",
	        'next_celebrations:today' => "Today is",
	        'next_celebrations:description' => "Next Anniversaries, weddings,...",
			'next_celebrations:nocelebrations' => "There aren't celebrations in the next %s days",
			
		//login reminder
			'next_celebrations:today' => "today",
			'next_celebrations:daysleft' => "days",
			'next_celebrations:dayleft' => "day",
			'next_celebrations:celebrate' => " celebrate the ",
			'next_celebrations:in' => "in",
			
			/* Form fields */
	        'today_celebrations:profile_birthdate_label' => "Date (dd/mm/yyyy)",
	        'today_celebrations:profile_feastdate_label' => "Date of feast (dd/mm)",
			
			
			/* Month name */
			"month:1" => "January",
			"month:2" => "February",
			"month:3" => "March",
			"month:4" => "April",
			"month:5" => "May",
			"month:6" => "June",
			"month:7" => "July",
			"month:8" => "August",
			"month:9" => "September",
			"month:10" => "October",
			"month:11" => "November",
			"month:12" => "December"
			
			
			
	);
	add_translation("en",$english);



?>