<?php
	$catalan = array(
		/**
		 * My HTML details
		 */

		//Profile labels
			'profile:celebrations_birthdate' => "Data de naixement",
			'profile:celebrations_dieday' => "Data de defunció",
			'profile:celebrations_feastdate' => "Dia del sant",
			'profile:lastname' => "Cognom",
			'profile:secondlastname' => "Segon cognom",
			'profile:celebrations_dayofmonth' => "de",
			'profile:celebrations_weddingdate' => "data de casament",
		
		
		//filter
			'celebrations:filterusers' => "Quines celebracions vols veure?",
			'celebrations:option_all' => "Tots",
			'celebrations:option_friends' => "Amics",
			'celebrations:filterby' => "Mostrar usuaris",
		
		// setting
			'celebrations:viewreminder' => "Veure recordatoris en connectar-se?",
			'celebrations:numberdays' => "Quants dies vols veure al recordatori?",
			'celebrations:show_today' => "Veure celebracions d'avui?",
			'celebrations:date_type' => "tipus de data",
			'celebrations:fieldsused' => "Quins camps vols fer servir?",
			'celebrations:replaceage' => "Vols canviar l'anniversari per l'edat?",
		
		// pagina
			'celebrations:title' => "Les nostres celebracions",
			'celebrations:shorttitle' => "Celebracions",
			'celebrations:day' => "Dia",
			'celebrations:age' => "anys",
		
		// widget today celebrations
	        'today_celebrations:title' => "Celebracions d'avui",
	        'today_celebrations:today' => "Avui es",
	        'today_celebrations:description' => "Aniversaris, casaments,...",
	        'today_celebrations:birthdate' => "Aniversari",
	        'today_celebrations:feastdate' => "Sant",
	        'today_celebrations:dieday' => "Defunció",
	        'today_celebrations:weddingdate' => "Casament",
			'today_celebrations:nocelebrations' => "No hi ha celebracions, però pots avisar-nos d\'alguna",
		
		// widget next celebrations
	        'next_celebrations:title' => "Properes celebracions",
	        'next_celebrations:today' => "Avui es",
	        'next_celebrations:description' => "Propers Aniversaris, casaments,...",
			'next_celebrations:nocelebrations' => "No hi ha celebracions als propers %s dies",
			
		//login reminder
			'next_celebrations:today' => "avui",
			'next_celebrations:daysleft' => "dies",
			'next_celebrations:dayleft' => "dia",
			'next_celebrations:celebrate' => " celebra el ",
			'next_celebrations:in' => "en",
			
			/* Form fields */
	        'today_celebrations:profile_birthdate_label' => "Data (dd/mm/aaaa)",
	        'today_celebrations:profile_feastdate_label' => "Data del sant (dd/mm)",
			
			
			/* Month name */
			"month:1" => "Gener",
			"month:2" => "Febrer",
			"month:3" => "Març",
			"month:4" => "Abril",
			"month:5" => "Maig",
			"month:6" => "Juny",
			"month:7" => "Juliol",
			"month:8" => "Agost",
			"month:9" => "Septembre",
			"month:10" => "Octubre",
			"month:11" => "Novembre",
			"month:12" => "Decembre"
			
			
			
	);
	add_translation("ca",$catalan);



?>
