List user celebrations like birthday and others (1.3)

Licence: GNU General Public License (GPL) version 2
Elgg version: 1.6
@package celebrations
@author Fernando Graells
@copyright Fernando Graells 2009
	


NOTE: Use in production sites at your own risk. it could have security holes.

This plugin is to see the users celebrations like birthdays, anniversaries,....

This version runs under elgg v1.6 and don't need another plugins to work. (new in this version)
It use the core profile fields (not the core custom profile fields), and add automatically the necessary fields. You can see it in start.php

You can select, in plugin configuration, the fields that you want to use.

At the moment I have defined the field type:

- "day_anniversary" with three pulldowns for the day, month and year to avoid the use of calendar input for old dates.
This is used for the specific dates that has celebrations every year, like birthday, wedding day, etc...
- "yearly" a particular date with two pulldowns with day and month (in some countries like spain you celebrate the date of your name's saint). This is use for celebrations that repeat yearly, but not have an origin or specific date

Then the system create the next profile fields like "celebrations_birthdate", "celebrations_dieday" and "celebrations_feastdate".
I have added the prefix "celebrations_" to avoid confusions with the original core fields.
If you want to add some field, you must use the prefix (with underscore) before the field name, and use the defined types of field.

At the moment you can add fields in the file start.php (is easy but you need to copy some code) and in edit.php under settings folder

In your "tools" menu appears a "view celebrations" option where you select the month, then you obtain a list with all the celebrations for this month

Added one filter. You can see two type of celebrations. "All" celebrations or only "friends" celebrations

You can put the two widgets in your profile page with:

   1. celebrations of the day
   2. next celebrations

I haven't defined css specific styles for this plugin, you can see it with your theme and improve it. I apreciates if you send me css examples.

I'm not a code generator, I'm a user with certain php knowledge. This plugin works for me but maybe it's not the best code.

Any suggestions, bugs, improvements and comments are welcome.


Installation: (It's more easy and simple in this version)

1. install the folder celebrations inside mod directory
2. IMPORTANT: enable the plugin below the core profile plugin
3. config plugin settings in "tools administration" (you can define if you want a reminder in login with next celebrations, the date type, the fields to use, the celebrations filter)
4. use the widget "today_celebrations" (optional)
5. use the widget "next_celebrations" (optional)
6. edit settings in "next_celebrations" widget (the days left, and if you want to see today celebrations inside this plugin)

NOTE: Test this plugin in development servers if you are using another profiles plugins (change the order between them, but you must put this one below the core profile plugin)

Todo list

- Test this plugin together with another profile plugins
- Email reminders for the next celebrations

Changes for release 1.3

- Change strftime for gmstrftime to solve problems with dates between differents gmt places (test by chombian, thanks)
- corrected bug with image path in css to display the sendtomessage image in "today celebrations" widget
- corrected a bug with friends filter

Changes for release 1.2

- Add selects in settings because We had problems with checkboxes in plugins settings

Changes for release 1.1

- Correct some date type to strftime
- Added "friends filter"
- Now you can select fields to add from the plugin default

Changes for release 1.0

- Full code rewrite to improve the files and let it to grow up
- Now is very easy (with a few code) to add new fields types (as periodical events) and profile fields
- Tested in elgg v1.6
- Independent from other profile plugins (in this version you don't need the flexprofile plugin)
- Added a field for the wedding date

Changes for release 0.4

- problem in date dropdown with firefox fixed
- Added two languages files (spanish and catalan)

Changes for release 0.3

- Added a new widget to see the next celebrations (you can edit the widget setting in the edit button on the widget)
- Added a reminder when you login with the next celebrations (you can edit teh settings in the admin plugin settings)
- Added the possibility to send a message in the today celebrations widget

Changes for release 0.2

- Change date by gmdate
- Correct some errors with feast celebrations
- Improve user experience with less screens
- Submenu added with the month's list
- Corrected some language errors
- Added icon and profile link for every user
- Corrected a double closed of select tag