<?php

	$english = array(
	
		/**
		 * PasseLiens widget details
		 */
		
	
		'claroline:userUnknown' => 'You are not register to Elgg',
		'claroline:couldNotConnect' => 'Could not connect to Elgg',
		'claroline:publishIntheFollowingCourses' => 'Publish in the following courses : ',
		'claroline:filePublished' => 'File published',
		'claroline:publishFile' => 'Publish',
		'claroline:unpublish' => 'Unpublish',
		'claroline:publishElement:explanation' => 'Please, choose the location you where you want to publish this element',
		'claroline:platformSettings'  =>  "Remote service settings",
   		'claroline:platformList'  =>  "Publishing services list",
   		'claroline:noPlatformSet'  =>  "No publishing service is set",
   		'claroline:platformListExample'  =>  'Expeted data : JSON object {"platforms" : [
     {"platformId" : "Claro1",
     	"name" : "MyClaroline",
      "url" : "http://myClaroline",
      "webserviceUrl" : "http://myClaroline/webservice.php"
     },
     {"platformId" : "Claro2",
     	"name" : "MyClaroline2",
      "url" : "http://myClaroline2",
      "webserviceUrl" : "http://myClaroline2/webservice.php"
     }
]}<br><strong>Warning : once set, do not edit the platformId value</strong>'	,
		'claroline:unknownPlatform'  =>  "This service is not registered",
		'claroline:adminAccount' => "Account with admin priviledges used to access ressources",
		'claroline:sureToDelete' => "This document is published on a remote location"
	
	);
					
	add_translation("en",$english);

?>