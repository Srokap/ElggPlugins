<?php

	$french = array(
		'claroline:userUnknown' => 'Vous n\'avez pas de compte dans Elgg',
		'claroline:couldNotConnect' => 'Impossible de se connecter à Elgg',
		'claroline:publishIntheFollowingCourses' => 'Publier dans les cours suivants : ',
		'claroline:publishedFile' => 'Fichier publié',
		'claroline:publish' => 'Publier',
		'claroline:unpublish' => 'Dépublier',
		'claroline:publishElement:explanation' => 'Veuillez choisir la plateforme dans laquelle vous souhaitez publier cet élément,',
   		'claroline:platformSettings'  =>  "Paramètres plateformes pédagogiques",
   		'claroline:platformList'  =>  "Liste des plateformes",
   		'claroline:noPlatformSet'  =>  "Aucune plateforme définie",
   		'claroline:platformListExample'  =>  'Format attendu : tableau JSON {"platforms" : [
     {"platformId" : "Claro1",
     	"name" : "MyClaroline",
      "url" : "http://myClaroline",
      "webserviceUrl" : "http://myClaroline/webservice.php"
     },
     {"platformId" : "Claro2",
     	"name" : "MyClaroline2",
      "url" : "http://myClaroline2",
      "webserviceUrl" : "http://myClaroline2/webservice.php"
     }
]}<br><strong>Attention : ne jamais modifier le platformId une fois défini</strong>'	,
		'claroline:unknownPlatform'  =>  "Cette plateforme n'a pas été enregistrée",
		'claroline:adminAccount' => "Compte administrateur permettant de faire les accès aux ressources",
		'claroline:sureToDelete' => "Ce document est publié dans une plateforme"
	);
					
	add_translation("fr",$french);

?>