<?php

    /**
     *Claroline plugin
     **/
  
    function claroline_init() {
			
	    // Load system configuration
		    global $CONFIG;
		    
		    register_translations($CONFIG->pluginspath . "claroline/languages/");
		    
		    extend_view('css', 'claroline/css');
     }
     
     // Make sure the status initialisation function is called on initialisation
		register_elgg_event_handler('init','system','claroline_init');
		
		function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
            else return FALSE;
    }
?>