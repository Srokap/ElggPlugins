<p>
    <fieldset style="border: 1px solid; padding: 15px; margin: 0 10px 0 10px">
        <legend><?php echo elgg_echo('claroline:platformSettings');?></legend>

        <label for="params[platforms]"><?php echo elgg_echo('claroline:platformList');?></label><br/>
        <div class="example"><?php echo elgg_echo('claroline:platformListExample');?></div>
        <textarea name="params[platforms]" cols="60" rows="6"><?php echo $vars['entity']->platforms;?></textarea><br/>
     		<br />
     		<label for="params[adminAccount]"><?php echo elgg_echo('claroline:adminAccount');?></label><br/>
    	  <input type="text" name="params[adminAccount]" value="<?php echo $vars['entity']->adminAccount;?>">
     </fieldset>
</p>