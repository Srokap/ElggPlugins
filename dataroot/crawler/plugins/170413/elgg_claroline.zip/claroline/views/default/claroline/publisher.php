<?php
					if (isset($file->publication))
					$publishLink = elgg_echo("claroline:publishedFile");
					else
					$publishLink = elgg_echo("claroline:publishFile");
					?>
					&nbsp; <a href="javascript:;" id="publishLink"><?php	echo $publishLink;  ?></a>

<script language="text/javascript">
	$(function() {
		alert('jkjk');
		$('#publishLink').click(
			function()
			{
				$("#publisher").show('fast');
			}
		);
	});

</script>

	<div class="contentWrapper" id="publisher">
		<p>
			<?php 
			echo elgg_echo('claroline:publishElement:explanation'); ?>
		</p>
	
<?php 
// Get configuration settings
$config = find_plugin_settings('claroline');
$platforms = json_decode($config->platforms, true);
		
if (!$platforms)
{
	echo elgg_echo('claroline:noPlatformSet');
}
else
{
	?>
	<ul>
	<?php
	foreach ($platforms['platforms'] as $platform)
	{
		unset($style);
		
		if (isset($vars['element']->publication))
		{
			$publication = json_decode($vars['element']->publication,true);
			
			if (is_array($publication[$platform['platformId']]))
			$style="style='font-weight:bold;'";
		}
		?>
		<li <?php echo $style; ?>><?php 
			echo $platform['name'];?></li>
		<?php
		if (!$contenu)
		{
			$contenu = file_get_contents($platform['webserviceUrl']."?action=courseList&username=".$_SESSION['user']['username']);
			
			if ($contenu)
			{
				$json = json_decode($contenu,true);
				?>
				<ul class="coursesList">
				<?php
				echo elgg_echo("claroline:publishIntheFollowingCourses");
				
				foreach ($json as $category=>$courses)
				{
					
					// Courses
					foreach($courses as $course)
					{
						if (in_array($course['code'],$publication[$platform['platformId']]))
						{
							$liClass = "unpublish";
							$linkContent = '<a href="javascript:;">'.elgg_echo("claroline:unpublish").'</a>';
						}
						else
						{
							$liClass = "publish";
							$linkContent = '<a href="'.$vars['url'].'mod/claroline/actions/publish.php?guid='.$vars['element']->guid.'&platformId='.$platform['platformId'].'&code='.$course['code'].'">'.elgg_echo("claroline:publish").'</a>';
						}
						
						?>
						<li alt="<?php echo $course['code']; ?>" class="<?php echo $liClass; ?>"><?php echo $category.' > '.$course['name']; 
								?>
								&nbsp;<?php echo $linkContent; ?>
						</li>
						<?php
					}
				}
				?>
			</ul>
				<?php
			}
			else
			echo elgg_echo("claroline:couldNotConnect");
			
		}
	}
	?>
	</ul>
	<?php
}
?>

<?php

?>

</div>