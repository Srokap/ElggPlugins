<?php

	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

	global $CONFIG;

	gatekeeper();
	
	// Get variables
	$guid = get_input("guid");
	$platformId = get_input("platformId");
	$code = get_input("code");
	
	// CHeck if the user is allowed to modify this element
		if (!$entity = get_entity($guid)) {
		register_error(elgg_echo("claroline:publishingFailed"));
		forward($CONFIG->wwwroot . "pg/file/" . $_SESSION['user']->username);
		exit;
	}
	
	if ($entity->canEdit())
	{
		// Contact remote service
		$config = find_plugin_settings('claroline');
		$platforms = json_decode($config->platforms, true);
		
		foreach ($platforms['platforms'] as $platform)
		{
			//print_r($platform);
			if ($platform['platformId'] == $platformId)
			{
				$pfInfos = $platform;
				break;
			}
		}
		
		if ($pfInfos)
		{
			$service = file_get_contents($pfInfos['webserviceUrl'].'?action=createLink&code='.$code);
			print $service;
		}
	}
?>