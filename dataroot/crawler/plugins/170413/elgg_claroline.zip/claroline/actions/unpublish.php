<?php
// Load Elgg engine
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

gatekeeper();

$config = find_plugin_settings('claroline');
$platforms = json_decode($config->platforms, true);


$guid = get_input('guid');
$callBackUrl = get_input('callBackUrl');

$element = get_entity($guid);

if ($element->publication)
{
	$publicationList = 	json_decode($element->publication, true);
	
	foreach ($platforms['platforms'] as $platform)
	{
		$platformId = $platform['platformId'];
		
		if (isset($publicationList[$platform['platformId']]))
		{
			foreach ($publicationList[$platform['platformId']] as $code)
			{
				// Call the remote service
				$ws = curl_get_file_contents($platform['webserviceUrl'].'?action=rmLink&code='.$code.'&guid='.$guid);
				
				if ($ws != false)
				{
					register_error(elgg_echo("claroline:couldNotConnect"));
				}
				else
				{
					if ($ws)
					{
						register_error(elgg_echo($ws));
					}
					
					$objet = get_entity($guid);
					$temp = json_decode($objet->publication,true);
					
					$key = array_search($code, $temp[$platformId]);
					
					if (isset($key))
					{
						$temp[$platformId[$key]] = "";
						rsort($temp[$platformId]);
						array_pop($temp[$platformId]);
					}
					
					$objet->publication = json_encode($temp);
				}
				
			}
		}
	}
}

forward($callBackUrl);

?>