<?php
/*************************************************
 * 
 * Webservice relation Claroline / Elgg
 * 
 * Chercher dans le r�pertoire de l'utilisateur
 * 
 ************************************************/

// CONF
$typeObjets = array('file','blog','bookmarks','page_top');


require_once("../../engine/start.php");

register_translations($CONFIG->pluginspath . "claroline/languages/");

// Get configuration settings
$config = find_plugin_settings('claroline');
$platforms = json_decode($config->platforms, true);


// Get parameters
$referer = get_input('referer');
$reqUser = get_input('user');
$action  = get_input('action');
$listeLiens = get_input('listeLiens');
$codeCours = get_input('cours');




// R�cup�rer le platformId correspondant au referer
foreach ($platforms['platforms'] as $pf)
{	
	if ($referer == $pf['url'])
	{
		$platformId = $pf['platformId'];
		break;
	}
}	

if (!isset($platformId))
{
	$tableauFinal['error'][] = elgg_echo("claroline:unknownPlatform");
	$output = json_encode($tableauFinal);
	print $output;
	exit;
}
		



/********************************************************

	Export JSON de la liste des objets dont l'utilisateur est propri�taire
	
********************************************************/
if ($action == 'listeObjetsUser')
{	
	// Connexion en tant que cet user
	$user = get_user_by_username($reqUser);
	
	if (!$user)
	$tableauFinal['error'][] = elgg_echo("claroline:userUnknown").' - <a href="'.$CONFIG->wwwroot.'account/register.php" target="_blank">'.elgg_echo("register").'</a>';
	elseif ($reqUser == $_SESSION['user']['username'])
	$loggedIn = true;
	else
	$loggedIn = login($user);

	if ($loggedIn == true)
	{
		elgg_set_viewtype('json');
		set_context('search');
		
		// Liste des objets
		foreach ($typeObjets as $type)
		{
			$json = list_entities("object",$type,$user->guid,1000,false);
			$output = elgg_view('pageshells/pageshell', array('title' => 'fileList','body' => $json,'sidebar' => "",'sysmessages' => system_messages(null,"")));
			$objet = json_decode($output);
		}
		
		$tableauFinal = array();
		
		foreach ($typeObjets as $type)
		{
			$tableauFinal[$type] = array();
			if ($objet->object->$type)
			{	
				foreach ($objet->object->$type as $obj)
				{
					// On cache les objets d�j� utilis�s dans le cours
					$objPublication = get_entity($obj->guid);
					
					//$objPublication->publication = "";
					
					if ($objPublication->publication)
					{				
						$temp = json_decode($objPublication->publication,true);

						if (in_array($codeCours,$temp[$platformId]))
						continue;
					}
					
					$tableauFinal[$type][] = array('guid'=>$obj->guid,'title'=>$obj->title);
				}
			}
		}
	}
	else
	$tableauFinal['error'][] = elgg_echo("claroline:couldNotConnect");
	


	$output = json_encode($tableauFinal);
	print $output;
	exit;
}

/********************************************************

		Suppression d'un tag avec plateforme + cours sur l'objet partag�
	
********************************************************/
if ($action == 'supprimerLiensObjetPlateformeCours')
{
		// Connexion en tant que cet user
		$user = get_user_by_username($reqUser);
		$loggedIn = login($user);
		
		if ($loggedIn == true)
		{
			$json = json_decode($listeLiens,true);	
			
			// On met un tag sur chaque element
			foreach ($json['objets'] as $guid)
			{	
				$objet = get_entity($guid);
				
				$temp = json_decode($objet->publication,true);
				
				$key = array_search($json['cours'], $temp[$platformId]);
				
				//print $key;
				
				if (isset($key))
				{
					$temp[$platformId[$key]] = "";
					rsort($temp[$platformId]);
					array_pop($temp[$platformId]);
				}
				
				$objet->publication = json_encode($temp);
			}
		}
}


/********************************************************

	Ajout d'un tag avec plateforme + cours sur l'objet partag�
	R�cup�ration d'un objet JSON
	
********************************************************/

if ($action == 'lienObjetPlateformeCours')
{
	$user = get_user_by_username($reqUser);
	$loggedIn = login($user);
	
	if ($loggedIn == true)
	{
		$json = json_decode($listeLiens,true);
		
		// On met un tag sur chaque element
		foreach ($json['objets'] as $guid)
		{	
			$objet = get_entity($guid);
			if ($objet->publication)
			{
				$temp = json_decode($objet->publication,true);
				
				if (!in_array($guid,$temp[$platformId]))
				$temp[$platformId][] = $json['cours'];
				
				$objet->publication = json_encode($temp);
			}
			else
			{
				$temp = array($platformId=>array($json['cours']));
				$objet->publication = json_encode($temp);
			}
		}
	}
	else
	$tableauFinal['error'][] = elgg_echo("claroline:couldNotConnect");
	
	$output = json_encode($tableauFinal);
	print $output;
	exit;
	
}




/*********************************

	Reader des documents
	
*********************************/
if ($action == 'read')
{
	$guid = get_input('file_guid');
	
	if (isset($guid))
	{
		$user = get_user_by_username($config->adminAccount);
		$loggedIn = login($user);
		

		// Rechargement obligatoire de la page pour que le syst�me prenne les droits
		if (!$_GET['reload'])
		forward(current_page_url()."&reload=true");
		
		$objet = get_entity($guid);
		
		$accesObjet = json_decode($objet->publication,true);
		

		if (in_array($codeCours,$accesObjet[$platformId]))
		{	
			switch($objet->getSubtype())
			{
				// Envoi d'un fichier
				case "file" :
					include_once('actions/download.php');
					break;
					
				default:
					forward($CONFIG->wwwroot."mod/claroline/read.php?guid=".$guid);
				break;
			}
		}
		else
		print "Access denied";
	}
}
?>