<?php

$german = array(
    'menu:site:header:default' => 'Navigation',
    'menu:site:header:more' => 'Mehr',
    
    'glee:loading' => 'Inhalt wird geladen...',
    
    'glee:settings:layout:enable_bootstrap_css:label'  => 'Bootstrap style via CSS laden? ',
    'glee:settings:layout:enable_bootstrap_css:description' => ' ',
    
    'glee:settings:layout:enable_bootstrap_less:label' => 'Bootstrap style via LESS laden? ',
    'glee:settings:layout:enable_bootstrap_less:description' => 'Javascript muss aktiviert sein! ',
    
	'glee:form:link_color:description' => 'Diese Farbe wird für Hyperlinks/Hintergründe/etc. verwendet.',
    'glee:form:link_color:label'       => 'Link Farbe',
    

	'glee:form:theme:description' => 'Erscheinungsbild der Website',
    'glee:form:theme:label'       => 'Theme',
);

add_translation("de", $german);