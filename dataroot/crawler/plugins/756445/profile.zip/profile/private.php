<?php

        /**
         * Elgg profile private
         *
         * @package ElggProfile
         */

        // Get the Elgg engine
                require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

        // Get the username
                $username = get_input('username');

                $body = "";
                $title = '';

        // Try and get the user from the username and set the page body accordingly
                if ($user = get_user_by_username($username)) {

                        if ($user->isBanned() && !isadminloggedin()) {
                                forward(); exit;
                        }

                        $title = $user->name;

                        $body = '<div id="elgg_horizontal_tabbed_nav">
                                <ul>
                                        <li><a href="' . $CONFIG->wwwroot . 'pg/profile/' . $user->username . '">Public</a></li>
                                        <li class="selected"_><a href="' . $CONFIG->wwwroot . 'pg/profile/' . $user->username . '/private">Private</a></li>
                                </ul>
                        </div>';

                        $body .= elgg_view_entity($user, true);

                        $body = elgg_view_layout('widgets', $body);

                } else {

                        $body = elgg_echo("profile:notfound");
                        $title = elgg_echo("profile");
                }

                page_draw($title, $body);



