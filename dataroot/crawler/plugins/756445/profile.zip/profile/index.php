<?php

	/**
	 * Elgg profile index
	 * 
	 * @package ElggProfile
	 */

	global $CONFIG;

	// Get the Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	// Get the username
		$username = get_input('username');
		$user = get_user_by_username($username);		

		$body = "";
		$title = '';
		
	// Try and get the user from the username and set the page body accordingly
		if ($user) {
			
			if ($user->isBanned() && !isadminloggedin()) {
				forward(); exit;
			}

			$title = $user->name;

			$tab = get_input('profile_type') ? get_input('profile_type') : 'public';
			
			if(!($user->isFriend() || get_loggedin_userid() == page_owner())) {
				$tab = 'public';
				set_context($tab . '_profile');
                		__set_access(); 
				$body .= elgg_view_entity($user, true);
   	                        $body = elgg_view_layout('widgets', $body);
			}else {

				$private_selected;
				$public_selected;
				switch($tab) {
					case 'private':
						$private_selected = 'class="selected"';
						break;
					case 'public':
						$public_selected = 'class="selected"';
						break;
				}
				set_context($tab . '_profile');
                		__set_access();
				create_metadata($user->guid, 'profile_type', $tab, 'text', $user->guid, '0');
				$user->save();

				$body = '<div id="elgg_horizontal_tabbed_nav">
					<ul>
						<li ' . $public_selected . '><a href="' . $CONFIG->wwwroot . 'pg/profile/' . $user->username . '"><b>Public</b></a></li>
						<li ' . $private_selected . '><a href="' . $CONFIG->wwwroot . 'pg/profile/' . $user->username . '/private"><b>Private</b></a></li>
					</ul>
				</div>';

				switch($tab) {
					case 'private':
						$body .= elgg_view_entity($user, true);
						$body = elgg_view_layout('widgets', $body);
						break;
					case 'public':
						$body .= elgg_view_entity($user, true);
						$body = elgg_view_layout('widgets', $body);
						break;
				}
			}
		} else {
			
			$body = elgg_echo("profile:notfound");
			$title = elgg_echo("profile");
		}

		page_draw($title, $body);
        

// set the access id for all of the widgets for the given context
function __set_access() {
    $context = get_context();
    $widgets = get_widgets($user->guid, $context, 1);
    $widgets2 = get_widgets($user->guid, $context, 2);
    $widgets3 = get_widgets($user->guid, $context, 3);
    $widgets = array_merge($widgets, $widgets2);
    $widgets = array_merge($widgets, $widgets3);
    foreach ($widgets as $widget) {
        $value = 1;
        if (strcmp($context, 'private_profile') == 0) {
            $value = -2;
        } elseif (strcmp($context, 'public_profile') == 0) {
            $value = 2;
        }
        save_widget_info($widget->guid, array('access_id' => $value));
    }
}
