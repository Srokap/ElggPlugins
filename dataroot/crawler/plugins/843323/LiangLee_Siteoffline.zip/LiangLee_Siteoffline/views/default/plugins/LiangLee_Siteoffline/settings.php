<?php
/* LiangLee Site Offline
 * FrameWork for Liang Lee Plugins
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework( LEFW )
 * @subpackage LiangLee Site Offline
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File settings.php
 */
 ?>
<?php
/**
* Liang Lee Plugin Path
**/
$path = elgg_get_plugins_path();
$LiangLee_Siteoffline_url = "LiangLee_Siteoffline";
/**
* Load Vesrion
**/
$Lianglee_soffline_ver = $path. $LiangLee_Siteoffline_url . "/version.php";
include $Lianglee_soffline_ver;
/**
* Load Language
**/
$liang_lee_siteoffline_label2 = elgg_echo('llee:siteoffline:1');
$liang_lee_siteoffline_label3 = elgg_echo('llee:siteoffline:2');
$liang_lee_siteoffline_label4 = elgg_echo('llee:siteoffline:3');
$liang_lee_siteoffline_label5 = elgg_echo('llee:siteoffline:4');
$title = elgg_echo('llee:siteoffline:copy');
$lleesettings = elgg_echo('llee:siteoffline:5');
$liang_lee_siteoffline_label = elgg_echo('llee:siteoffline:6');
/**
* Configure Settings
**/
$liang_lee_siteoffline = elgg_view('input/dropdown', array(
    'name' => 'params[liang_lee_siteoffline]',
    'value' => $vars['entity']->liang_lee_siteoffline,
    'options_values' => array('offline' => elgg_echo('llee:siteoffline:offline'), 'no' => elgg_echo('llee:siteoffline:noffline'))
        ));
$liang_lee_siteOffline_2 = elgg_view("input/text", array(
"name" => "params[LiangLee_sitoffline_call]", 
"value" => $vars['entity']->LiangLee_sitoffline_call));

$liang_lee_siteOffline_3 = elgg_view("input/text", array(
"name" => "params[LiangLee_sitoffline_email]", 
"value" => $vars['entity']->LiangLee_sitoffline_email));

$liang_lee_siteOffline_4 = elgg_view("input/text", array(
"name" => "params[LiangLee_sitoffline_msg]", 
"value" => $vars['entity']->LiangLee_sitoffline_msg));	

$liang_lee_siteOffline_5 = elgg_view("input/text", array(
"name" => "params[LiangLee_sitoffline_logo]", 
"value" => $vars['entity']->LiangLee_sitoffline_logo));			
				
/**
* Setting Page
**/
$settings = <<<__HTML

    <h3>$lleesettings</h3>
    <div>
	<p></p>
        <p><i>$liang_lee_siteoffline_label</i><br>$liang_lee_siteoffline</p>
		<p><i>$liang_lee_siteoffline_label2</i>
		<br>$liang_lee_siteOffline_2</p>
	    <p><i>$liang_lee_siteoffline_label3</i>
		<br>$liang_lee_siteOffline_3</p>
	    <p><i>$liang_lee_siteoffline_label4</i>
		<br>$liang_lee_siteOffline_4</p>
	    <p><i>$liang_lee_siteoffline_label5</i>
		<br>$liang_lee_siteOffline_5</p>

		<hr>
		<p><i>$liang_lee_mainpage_copytights</i>
		<p>Release:$LiangLee_siteoffline_release</p>
		<p>Version:$LiangLee_siteoffline_version</p>
    </div>
    
</div>
__HTML;
/**
* End of Setting Page
**/
echo $settings, $title;