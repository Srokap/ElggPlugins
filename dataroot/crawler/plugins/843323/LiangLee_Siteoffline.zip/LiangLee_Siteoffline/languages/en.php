<?php
/* LiangLee Site Offline
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Framework
 * @subpackage LiangLee Site Offline.
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File en.php 
 */

$english = array(
	'llee:siteoffline:1' => 'In Emergency Contact: What is Your Call Number Example: xxxx-xxxxx.',
	'llee:siteoffline:2' => 'In Emergency Contact: What is your Support Email? Example: support@mywebsite.com.',
	'llee:siteoffline:3' => 'Enter your Website Offline Message Here:',
	'llee:siteoffline:4' => 'What is your website Logo url?  Example: http://mywebsite/logo.jpg.',
	'llee:siteoffline:copy' => 'All right reserved Liang Lee 2012..',
	'llee:siteoffline:5' => 'Liang Lee Site Offline Settings Page!.',
	'llee:siteoffline:6' => 'Your Website is Offline Or Not?.',
	'llee:siteoffline:offline' => 'Site Offline Mode.',
	'llee:siteoffline:noffline' => 'Not Offline Mode.',
	'llee:siteoffline' => 'Web Site is currently Under Construction.',
	'llee:siteoffline:login' => 'If you are Administrator Please Login Here:',
	'llee:siteoffline:emergency' => 'If in Emergency Contact:',
	'llee:siteoffline:un' => 'Username or email',
	'llee:siteoffline:pwd' => ' password',



);

add_translation('en', $english);
