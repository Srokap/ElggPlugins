<?php
/* LiangLee Site Offline
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Framework
 * @subpackage LiangLee Site Offline.
 * @author Liang Lee
 * @File de.php German Language by Nudeler2 http://community.elgg.org/pg/profile/Nudeler2
 * @File en.php 
 */

$german = array(
	'llee:siteoffline:1' => 'In dringenden Fällen: Gib hier eine Telefonnummer ein unter der Du erreichbar bist : xxxx-xxxxx.',
	'llee:siteoffline:2' => 'In dringenden Fällen, Support-Kontakt: Gib hier eine Emailadresse für Support ein: support@mywebsite.com.',
	'llee:siteoffline:3' => 'Gib den Grund für die Nichterreichbarkeit hier ein:',
	'llee:siteoffline:4' => 'Die URL des Logos deiner Webseite: http://mywebsite/logo.jpg.',
	'llee:siteoffline:copy' => 'All rights reserved by Liang Lee 2012..',
	'llee:siteoffline:5' => 'Liang Lee Site Offline Settings Page!.',
	'llee:siteoffline:6' => 'Ist Deine Webseite offline oder online?.',
	'llee:siteoffline:offline' => 'Offline Modus.',
	'llee:siteoffline:noffline' => 'Online Modus.',
	'llee:siteoffline' => 'Die Webseite befindet sich gerade in Bearbeitung.',
	'llee:siteoffline:login' => 'Wenn Du Administrator bist kannst Du Dich hier anmelden:',
	'llee:siteoffline:emergency' => 'In dringenden Fällen, Kontakt:',
	'llee:siteoffline:un' => 'Benutzername oder Emailadresse',
	'llee:siteoffline:pwd' => ' Passwort',



);

add_translation('de', $german);
