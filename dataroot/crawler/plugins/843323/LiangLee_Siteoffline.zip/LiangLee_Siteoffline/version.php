<?php
/* LiangLee Site Offline
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @Package Liang Lee Site Offline
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File Version.php
 */
$LiangLee_siteoffline_version = '20120205';
$LiangLee_siteoffline_release = '1.0.1';
?>
