<?php
/* LiangLee FrameWork
 * FrameWork for Liang Lee Plugins
 * @package LiangLeeFramework( LEFW )
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @subpackage LiangLeeFramework( LEFW )
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @file login.php
 */
 	global $CONFIG;
    $LiangLee_Getform.= elgg_echo('llee:siteoffline:un');
	$LiangLee_Getform.= elgg_view('input/text', array('name' => 'username','class' => 'elgg-autofocus',));
	$LiangLee_Getform.= elgg_echo('llee:siteoffline:pwd');
	$LiangLee_Getform.= elgg_view('input/password', array('name' => 'password'));
	$LiangLee_Getform .= elgg_view('input/submit', array('value' => elgg_echo('login')));
	$login_url = $vars['url'];
	if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
    $login_url = str_replace("http", "https", $vars['url']);
	?>