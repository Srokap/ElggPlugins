<?php
/* LiangLee Site Offline
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Site Offline
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File LiangLeeSO.php 
 */
if($LiangLee_siteoffline_call = elgg_get_plugin_setting("LiangLee_sitoffline_call", "LiangLee_Siteoffline")){
	$Le_call =$LiangLee_siteoffline_call;
}
if($LiangLee_siteoffline_email = elgg_get_plugin_setting("LiangLee_sitoffline_email", "LiangLee_Siteoffline")){
	$Le_email =$LiangLee_siteoffline_email;
}
if($LiangLee_siteoffline_msg = elgg_get_plugin_setting("LiangLee_sitoffline_msg", "LiangLee_Siteoffline")){
	$Le_msg =$LiangLee_siteoffline_msg;
}
if($LiangLee_sitoffline_logo = elgg_get_plugin_setting("LiangLee_sitoffline_logo", "LiangLee_Siteoffline")){
	$Le_logo =$LiangLee_sitoffline_logo;
}