<?php
/* LiangLee Site Offline
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Site Offline
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File index.php
 */	
 /**
* If Admin is Login Forword to activity you can cange /activity to /youurl
**/
if (elgg_is_admin_logged_in()) {
	forward('/activity');
}
 /**
* Configure Path
**/
$path = elgg_get_plugins_path();
 /**
* Configure Path
**/
$liang_lee_siteoffline_url = "LiangLee_Siteoffline";
$LiangFramework_url = "LiangleeFramework";
 /**
* Load Login Form
**/
$Lianglee_load_form = $path. $liang_lee_siteoffline_url . "/lib/login.php";
include $Lianglee_load_form;
 /**
* Load Settings
**/
$Lianglee_get_content = $path. $liang_lee_siteoffline_url . "/lib/LiangLeeSO.php";
include $Lianglee_get_content;
 /**
* Page
**/
echo "<html>\n"; 
echo "	<head>\n"; 
echo "	<title>\n";
 /**
* Load Titile
**/

echo elgg_echo('llee:siteoffline');
echo "</title></head>\n"; 
echo "	<body>\n"; 
echo "<div align=\"center\">\n"; 
echo "	  <table width=\"734\" height=\"212\" border=\"0\">\n"; 
echo "        <tr>\n"; 
echo "<td width=\"717\"><div align=\"center\"><img src=\"\n";
 /**
* Load Logo Url
**/
echo $Le_logo ?><?php

echo "\">\n";
echo "</div></td>\n"; 
echo "          <td width=\"10\" height=\"82\">&nbsp;</td>\n"; 
echo "        </tr>\n"; 
echo "\n"; 
echo "        <tr>\n"; 
echo "          <td> <p align=\"center\"><strong>\n";
 /**
* Load Offline Message
**/

echo $Le_msg?><?php
echo "</strong></p>\n"; 
echo "          <p align=\"center\"><strong>\n";
 /**
* Load Language
**/

echo elgg_echo('llee:siteoffline:emergency');
echo "<br>\n"; 
echo "           Email :&nbsp;\n";
 /**
* Load Email
**/

echo $Le_email ?><?php
echo "<br>\n"; 
echo "          Call us:&nbsp;\n";
 /**
* Load Call Number
**/

echo $Le_call?><?php
echo "</strong></p>\n"; 
echo "          <p align=\"left\"><strong>\n";
 /**
* Load SLanguage
**/
echo elgg_echo('llee:siteoffline:login');
echo "</strong></p>\n";
/**
* Inlcude Login Form
**/
echo elgg_view('input/form', array('body' => $LiangLee_Getform, 'action' => "{$login_url}action/login"));

echo "	</ul>\n"; 
echo "</div>\n"; 
echo "   </td>\n"; 
echo "          <td>&nbsp;</td>\n"; 
echo "	    </tr>\n"; 
echo "    </table>\n"; 
echo "    </div>\n"; 
echo "	</body>\n"; 
echo "</html>\n";
 /**
* Register Errors
* Load Errors
**/
$LiangLee_FrameWork_errors = $path. $LiangFramework_url . "/lib/LiangLeeFrameWord-Error.php";
include $LiangLee_FrameWork_errors;
?>
<!-- Web Site Offline Page/Plugin By Liang Lee http://community.elgg.org/pg/profile/arsalanlee/ !-->
