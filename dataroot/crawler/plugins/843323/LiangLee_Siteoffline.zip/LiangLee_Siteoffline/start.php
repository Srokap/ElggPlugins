<?php
/* LiangLee Site Offline
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package Liang Lee Site Offline
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File start.php 
 */
elgg_register_event_handler('init', 'system', 'LiangLee_Siteoffline_init');

function LiangLee_Siteoffline_init() {
/**
* Check Plugin Settings
**/
if (elgg_get_plugin_setting('liang_lee_siteoffline', 'LiangLee_Siteoffline') == 'offline' && !elgg_is_admin_logged_in()){
/**
* Register LiangLee_siteoffline Function
**/

elgg_register_plugin_hook_handler('index', 'system', 'LiangLee_Siteoffline');

/**
* Global &CONFIG;
**/
global $CONFIG;
/**
* Set Login Url
**/

$get_url = parse_url($CONFIG->wwwroot, PHP_URL_PATH);
/**
* Set Login Url
* @ REQUEST_URI: The path component of the requested URL
**/
	if($_SERVER["REQUEST_URI"] != $get_url && $_SERVER["REQUEST_URI"] != "${get_url}action/login"){
/**
* Get Admin Access
**/					
admin_gatekeeper();

	  }
    }	
}
/**
* @Function  LiangLee_Siteoffline
**/
function LiangLee_Siteoffline($hook, $type, $return, $params) {
/**
* Global Config
**/
	global $CONFIG;
	if ($return == true) {
		return $return;
	}
/**
* inlcude index.php for override default main page
**/
	if (!include_once(dirname(__FILE__) . "/index.php")) {
		return false;
	}
	return true;
}
?>
