<?php
	echo $vars['url'] . "mod/theme_simpleneutral/graphics/file_icons/pages.gif";
?>