<?php
	echo $vars['url'] . "mod/theme_simpleneutral/graphics/user_icons/defaulttopbar.gif";
?>