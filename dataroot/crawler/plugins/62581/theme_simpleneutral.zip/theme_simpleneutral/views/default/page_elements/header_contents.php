
<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
<!-- site name -->
	<div id="site_name"><h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1></div>
	
	<div id="menu">
		<div id="menu_inner">
		<a href="<?php echo $vars['url']; ?>" title="Home"><span>HOME</span></a>
		<a href="<?php echo $vars['url']; ?>mod/riverdashboard/" title="Latest Activity"><span>ACTIVITY</span></a>
		<a href="<?php echo $vars['url']; ?>mod/thewire/everyone.php" title="The Wire"><span>THE WIRE</span></a>
		<a href="<?php echo $vars['url']; ?>mod/blog/everyone.php" title="Blog"><span>BLOG</span></a>
		<a href="<?php echo $vars['url']; ?>mod/bookmarks/everyone.php" title="Bookmarks"><span>BOOKMARKS</span></a>
		<a href="<?php echo $vars['url']; ?>pg/groups/world/" title="Groups"><span>GROUPS</span></a>
		<a href="<?php echo $vars['url']; ?>mod/pages/world.php" title="Pages"><span>PAGES</span></a>
		<a href="<?php echo $vars['url']; ?>mod/file/world.php" title="Files"><span>FILES</span></a>
		</div>
	</div>

<div class="clearfloat"></div>
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
