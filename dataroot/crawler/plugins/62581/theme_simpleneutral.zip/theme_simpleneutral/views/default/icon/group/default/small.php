<?php
	echo $vars['url'] . "mod/theme_simpleneutral/graphics/group_icons/defaultsmall.gif";
?>