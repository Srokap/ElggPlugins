<?php

add_translation("en", array(
	'akismet:noapikey' => 'API key not defined, please configure Akismet in your admin tools',
	'akismet:api_key' => 'API key',
	'akismet:spam' => 'Sorry, you message could not be posted as Akismet thinks that it is spam!',
	'akismet:ham' => 'Message passed Akismet spam check',
));
