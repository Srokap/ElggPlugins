Eliminates spam using Akismet.

Thanks to Marcus Povey for initial work (www.marcus-povey.co.uk).