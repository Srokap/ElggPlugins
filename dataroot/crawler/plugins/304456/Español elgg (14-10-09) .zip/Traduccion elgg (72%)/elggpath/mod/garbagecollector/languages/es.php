<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @author Curverider Ltd
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'garbagecollector:period' => 'Con qu&eacute; frecuencia deber&iacute;a de activarse el recolector de basura',
	
			'garbagecollector:weekly' => 'Una vez a la semana',
			'garbagecollector:monthly' => 'Una vez al mes',
			'garbagecollector:yearly' => 'Una vez al a&ntilde;o',
	
			'garbagecollector' => "RECOLECTOR DE BASURA\n",
			'garbagecollector:done' => "HECHO\n",
			'garbagecollector:optimize' => "Optimizando %s ",
	
			'garbagecollector:error' => "ERROR",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Eliminando palabras clave sin asociaci&oacute;n: ',
	
	);
					
	add_translation("es",$spanish);
?>