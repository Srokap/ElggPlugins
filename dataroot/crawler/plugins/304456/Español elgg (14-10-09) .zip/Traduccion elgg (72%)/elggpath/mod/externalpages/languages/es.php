<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "P&aacute;ginas externas",
			'expages:frontpage' => "P&aacute;gina principal",
			'expages:about' => "Acerca de",
			'expages:terms' => "T&eacute;rminos",
			'expages:privacy' => "Privacidad",
			'expages:analytics' => "An&aacute;lisis",
			'expages:contact' => "Contacto",
			'expages:nopreview' => "No est&aacute; disponible la previsualizaci&oacute;n",
			'expages:preview' => "Previsualizar",
			'expages:notset' => "Esta p&aacute;gina no ha sido iniciada.",
			'expages:lefthand' => "Informaci&oacute;n del panel izquierdo",
			'expages:righthand' => "Informaci&oacute;n del panel derecho",
			'expages:addcontent' => "Puede a&ntilde;adir contenido a trav&eacute;s de la administraci&oacute;n de plugins. Busque el link de p&aacute;ginas externas.",
			'item:object:front' => 'Items de la p&aacute;gina principal',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Su p&aacute;gina ha sido enviado correctamente.",
			'expages:deleted' => "Su p&aacute;gina ha sido borrada correctamente.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "Hay problemas en el borrado de antiguas p&aacute;ginas",
			'expages:error' => "Hay un error, por favor intente de nuevo o en su caso contacte con el administrador",
	
	);
					
	add_translation("es",$spanish);

?>
