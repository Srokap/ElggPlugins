<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'thewire' => "La red",
			'thewire:user' => "Red de %s",
			'thewire:posttitle' => "Notas de %s en la red: %s",
			'thewire:everyone' => "Todos los post de la red",
	
			'thewire:read' => "Mensajes de la red",
			
			'thewire:strapline' => "%s",
	
			'thewire:add' => "Enviar a la red",
		    'thewire:text' => "Una nota en la red",
			'thewire:reply' => "Responder",
			'thewire:via' => "Via",
			'thewire:wired' => "Enviado a la red",
			'thewire:charleft' => "Caracteres restantes",
			'item:object:thewire' => "Mensajes de la red",
			'thewire:notedeleted' => "Nota borrada",
			'thewire:doing' => "&#191;Qu&eacute; est&aacute;s haciendo? &#161;D&iacute;selo a cualquiera de la red!",
			'thewire:newpost' => 'Nuevo mensaje en la red',
			'thewire:addpost' => 'Enviar a la red',

	
        /**
	     * The wire river
	     **/
	        
	        //generic terms to use
	        'thewire:river:created' => "%s enviados",
	        
	        //these get inserted into the river links to take the user to the entity
	        'thewire:river:create' => "En la red.",
	        
	    /**
	     * Wire widget
	     **/
	     
	        'thewire:sitedesc' => 'Este componente muestra las &uacute;ltimas notas enviadas a la red',
	        'thewire:yourdesc' => 'Este componente muestra las &uacute;ltimas notas enviadas a la red',
	        'thewire:friendsdesc' => 'Este componente mostrar&aacute; las &uacute;ltimas noticias de sus amigos en la red',
	        'thewire:friends' => 'Sus amigos en la red',
	        'thewire:num' => 'N&uacute;mero de items a mostrar',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'thewire:posted' => "Su mensaje ha sido enviado a la red.",
			'thewire:deleted' => "Su nota ha sido borrada.",
	
		/**
		 * Error messages
		 */
	
			'thewire:blank' => "Lo lamento; necesita escribir algo para poder guardarlo.",
			'thewire:notfound' => "Lo lamento; no se puede encontrar la nota especificada.",
			'thewire:notdeleted' => "Lo lamento; no se puede borrar esta nota.",
	
	
		/**
		 * Settings
		 */
			'thewire:smsnumber' => "El n&uacute;mero del SMS es diferente de tu n&uacute;mero de m&oacute;vil (El n&uacute;mero debe ser p&uacute;blico en la red para poder usar esto). Todos los n&uacute;meros de tel&eacute;fono deben estar en formato internacional (Espan&ntilde: +34666000000)",
			'thewire:channelsms' => "El n&uacute;mero para enviar los SMS es <b>%s</b>",
			
	);
					
	add_translation("es",$spanish);

?>
