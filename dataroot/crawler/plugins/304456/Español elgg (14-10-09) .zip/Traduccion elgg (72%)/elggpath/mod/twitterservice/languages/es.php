<?php
	$spanish = array(
		'twitterservice' => 'Servicio Twitter',
		'twitterservice:postwire' => '&#191;Quieres publicar tus mensajes p&uacute;blicos de la red a Twitter?',
		'twitterservice:twittername' => 'Usuario Twitter',
		'twitterservice:twitterpass' => 'Contrase&ntilde;a Twitter',
	);
					
	add_translation("es",$spanish);
?>
