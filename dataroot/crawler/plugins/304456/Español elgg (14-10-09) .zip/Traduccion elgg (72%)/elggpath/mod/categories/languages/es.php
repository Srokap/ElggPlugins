<?php

	$spanish = array(
	
		'categories' => 'Categorias',
		'categories:settings' => 'Establece las categor&iacute;as',	
		'categories:explanation' => 'Establecer las categorias que van a ser usadas por el sistema.',	
		'categories:save:success' => 'Guardado.',
	
	);
					
	add_translation("es",$spanish);

?>
