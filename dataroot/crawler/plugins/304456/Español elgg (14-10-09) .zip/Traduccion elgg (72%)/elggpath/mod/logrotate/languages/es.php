<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$english = array(
		'logrotate:period' => 'Con que&acute; frecuencia deber&iacute;a guardar el sistema el registro',
	
		'logrotate:weekly' => 'Una vez a la semana',
		'logrotate:monthly' => 'Una vez al mes',
		'logrotate:yearly' => 'Una vez al a&ntilde;o',
	
		'logrotate:logrotated' => "Registro rotado\n",
		'logrotate:lognotrotated' => "Error en el rotado del registro\n",
	);
					
	add_translation("es",$spanish);
?>
