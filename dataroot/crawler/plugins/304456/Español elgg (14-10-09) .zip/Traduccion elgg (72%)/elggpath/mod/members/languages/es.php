<?php

	$spanish = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Miembros",
	    'members:online' => "Miembros activos ahora",
	    'members:active' => "Zona de los miembros",
	    'members:searchtag' => "B&uacute;squeda de miembros por palabras clave",
	    'members:searchname' => "B&uacute;squeda de miembros por su nombre",
	    'go' => "Buscar",
	    'Members' => "Miembros",
	);
					
	add_translation("es",$spanish);

?>
