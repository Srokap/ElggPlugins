<?php

	$spanish = array(
	
		/**
		 * twitter widget details
		 */
		
	
		'twitter:username' => 'Introduzca el usuario twitter.',
		'twitter:num' => 'N&uacute;mero de tweets a mostrar.',
		'twitter:visit' => 'Visitar mi twitter',
		'twitter:notset' => 'Este componente no esta listo para funcionar. Para mostrar los &uacute;ltimos tweets, pulse -editar- y rellene los datos',
		
		
		 /**
	     * twitter widget river
	     **/
	        
	        //generic terms to use
	        'twitter:river:created' => "%s a&ntilde;adido al componente twitter.",
	        'twitter:river:updated' => "%s actualizado al componente twitter.",
	        'twitter:river:delete' => "%s eliminados al componente twitter.",
	        
		
	);
					
	add_translation("es",$spanish);

?>
