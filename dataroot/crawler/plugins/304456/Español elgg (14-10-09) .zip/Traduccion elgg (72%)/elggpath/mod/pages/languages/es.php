<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
			
			'pages' => "P&aacute;ginas",
			'pages:yours' => "Sus p&aacute;ginas",
			'pages:user' => "P&aacute;ginas de Inicio",
			'pages:group' => "P&aacute;gina de %s",
			'pages:all' => "Todas las p&aacute;ginas",
			'pages:new' => "Nueva p&aacute;gina",
			'pages:groupprofile' => "P&aacute;ginas del grupo",
			'pages:edit' => "Editar esta p&aacute;gina",
			'pages:delete' => "Eliminar esta p&aacute;gina",
			'pages:history' => "Historial de p&aacute;ginas",
			'pages:view' => "Vista de p&aacute;ginas",
			'pages:welcome' => "Editar un mensaje de bienvenida",
			'pages:welcomeerror' => "Hubo un problema al guardar el mensaje de bienvenida",
			'pages:welcomeposted' => "Su mensaje de bienvenida ha sido enviado",
			'pages:navigation' => "Navegaci&oacute;n de p&aacute;ginas",
	
			'item:object:page_top' => 'Primera p&aacute;gina',
			'item:object:page' => 'P&aacute;ginas',
			'item:object:pages_welcome' => 'Mensajes de bienvenida de las p&aacute;ginas',
			
			'pages:nogroup' => 'Este grupo no tiene todavia ninguna p&aacute;gina',
			
		/**
		* River
		**/
		
		    'pages:river:annotate' => "un comentario en esta p&aacute;gina",
		    'pages:river:created' => "%s ha escrito",
	        'pages:river:updated' => "%s ha actualizado",
	        'pages:river:posted' => "%s ha escrito",
			'pages:river:create' => "una nueva p&aacute;gina titulada",
	        'pages:river:update' => "una p&aactue;gina titulada",
	        'page:river:annotate' => "un comentario en esta p&aacute;gina",
	        'page_top:river:annotate' => "un comentario en esta p&aacute;gina",
		
	
		/**
		 * Form fields
		 */
	
			'pages:title' => 'T&iacute;tulo de p&aacute;gina',
			'pages:description' => 'Entrada de su p&aacute;gina',
			'pages:tags' => 'Etiquetas',	
			'pages:access_id' => 'Acceso de lectura',
			'pages:write_access_id' => 'Acceso de escritura',
		
		/**
		 * Status and error messages
		 */
			'pages:noaccess' => 'Sin acceso a esta p&aacute;gina',
			'pages:cantedit' => 'No puede editar esta p&aacute;gina',
			'pages:saved' => 'P&aacute;gina guardada',
			'pages:notsaved' => 'La p&aacute;gina no puede ser guardada',
			'pages:notitle' => 'Debe especificar un t&iacute;tulo para su p&aacute;gina.',
			'pages:delete:success' => 'Su p&aacute;gina fue eliminada correctamente.',
			'pages:delete:failure' => 'La p&aacute;gina no puede eliminarse.',
	
		/**
		 * Page
		 */
			'pages:strapline' => 'Actualizaciones %s de %s',
	
		/**
		 * History
		 */
			'pages:revision' => 'Revision creada %s por %s',
			
		/**
		 * Wdiget
		 **/
		 
		    'pages:num' => 'N&uacute;mero de p&aacute;ginas a mostrar',
	
		/**
		 * Submenu items
		 */
			'pages:label:view' => "Ver la p&aacute;gina",
			'pages:label:edit' => "Editar la p&aacute;gina",
			'pages:label:history' => "Historial de la p&aacute;gina",
	
		/**
		 * Sidebar items
		 */
			'pages:sidebar:this' => "Esta p&aacute;gina",
			'pages:sidebar:children' => "Sub-p&aacute;ginas",
			'pages:sidebar:parent' => "Principal",
	
			'pages:newchild' => "Crear una sub-p&aacute;gina",
			'pages:backtoparent' => "Volver a '%s'",
	);
	
	
	add_translation("es",$spanish);
?>
