<?php

	/**
	 * Elgg invite page
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://elgg.org/
	 */

	$spanish = array(

		'friends:invite' => 'Invitar amigas',
		'invitefriends:introduction' => 'Para invitar amigos a unirse a esta red, debe introducir el correo electr&oacute;nico de sus amigos m&aacute;s abajo (uno por l&iacute;nea):',
		'invitefriends:message' => 'Introduzca el mensaje que recibira/n su/s amigo/s:',
		'invitefriends:subject' => 'Invitaci&oacute;n a unirse a %s',
	
		'invitefriends:success' => 'Su/s amigo/s ha/n sido invitado/s.',
		'invitefriends:failure' => 'Su/s amigo/s no puede/n ser invitado/s.',
	
		'invitefriends:message:default' => '
Hola,

Quiero invitarle a unirse a una red social en %s.',
		'invitefriends:email' => '
Ha sido invitado a unirse a %s por %s. Incluyendo el siguiente mensaje:

%s

Para unirse, debe pulsar el siguiente link:

	%s

Será adminitido automáticamente como un amigo cuando haya creado una cuenta.',
	
	);
					
	add_translation("es",$spanish);
?>
