<?php



	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Bandeja de mensajes",
			'messageboard:messageboard' => "Bandeja de mensajes",
			'messageboard:viewall' => "Ver todos",
			'messageboard:postit' => "Enviar",
			'messageboard:history' => "Historial",
			'messageboard:none' => "No hay ning&uacute;n mensaje en la bandeja",
			'messageboard:num_display' => "N$uacute;mero de mensajes a mostrar",
			'messageboard:desc' => "Esta es la bandeja de mensajes que puede poner en su perfil para que otros usuari@s puedan comentarlos.",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s ha tenido un nuevo comentario en su bandeja de mensajes.",
	        'messageboard:river:create' => "%s a&ntilde;adido componente de la bandeja de mensajes.",
	        'messageboard:river:update' => "%s actualizado el componente de la bandeja de mensajes.",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Ha enviado el mensaje a la bandeja correctamente.",
			'messageboard:deleted' => "Ha eliminado el mensaje correctamente.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Tiene nuevos mensajes en su bandeja!',
			'messageboard:email:body' => "Tiene un nuevo mensaje en su bandeja, comentado por %s:

			
%s


Para ver el mensaje de la bandeja, pulse aqu&iacute;:

	%s

Para ver el perfil de %s, pulse aqu&iacute;:

	%s

Por favor no responda a este correo.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Lo siento, necesitas escribir algo en el mensaje antes de mandarlo.",
			'messageboard:notfound' => "Lo siento, no podemos encontrar el item especificado.",
			'messageboard:notdeleted' => "Lo siento, no podemos eliminar este mensaje.",
	     
			'messageboard:failure' => "Ha ocurrido un erro inesperado mientras a&ntilde;adiamos tu mensaje, por favor, int&eacute;ntalo de nuevo.",
	
	);

	add_translation("es",$spanish);

?>
