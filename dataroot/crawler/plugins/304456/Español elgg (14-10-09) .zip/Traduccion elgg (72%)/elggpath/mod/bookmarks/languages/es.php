<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'bookmarks' => "Favoritos",
			'bookmarks:add' => "Favorito a�adido",
			'bookmarks:read' => "Art&iacute;culos favoritos",
			'bookmarks:friends' => "Amigos favoritos",
			'bookmarks:everyone' => "Todos los favoritos",
			'bookmarks:this' => "Hacer favorito",
			'bookmarks:this:group' => "Hacer favorito en %s",
			'bookmarks:bookmarklet' => "Obtener favoritos",
			'bookmarks:bookmarklet:group' => "Obtener favoritos del grupo",
			'bookmarks:inbox' => "Entradas de favoritos",
			'bookmarks:more' => "M&aacute;s favoritos",
			'bookmarks:shareditem' => "Art&iacute;culos favoritos",
			'bookmarks:with' => "Compartir esto",
	
			'bookmarks:address' => "Direcci&oacute;n de los recursos a los favoritos",
	
			'bookmarks:delete:confirm' => "Est&aacute; seguro que quiere eliminar este recurso?",
	
			'bookmarks:shared' => "A&ntilde;adido a favoritos",
			'bookmarks:visit' => "Visitar el recurso",
			'bookmarks:recent' => "Favoritos recientes",
	
			'bookmarks:river:created' => '%s favoritos',
			'bookmarks:river:annotate' => '%s comentados en',
			'bookmarks:river:item' => 'un art&iacute;culo',
			
			'bookmarks:group' => 'Favoritos del grupo',
			'item:object:bookmarks' => 'Art&iacute;culos favoritos',
			'bookmarks:enablebookmarks' => 'Habilitar favoritos para el grupo',
	
		/**
		 * More text
		 */
		    
		    'bookmarks:widget:description' => 
		            "Este componente est&aacute; dise�ado para mostrar&aacute; sus entradas a los art&iacute;culos favoritos.",
	
			'bookmarks:bookmarklet:description' =>
					"Los favoritos permiten compartir cualquier web en internet con sus amigos. Para usarlos, arrastre el icono de abajo a la lista de accesos r&aacute;pidos de su navegador web:",

	        'bookmarks:bookmarklet:descriptionie' =>
					"Si est&aacute; usando Internet Explorer, necesitar&aacute; pulsar el bot&oacute;n derecho de rat&oacute;n, seleccione 'a&ntilde;adir a favoritos'' e indicar el link.",

			'bookmarks:bookmarklet:description:conclusion' =>
					"Pude guardar cualquier p&aacute;gina que visite pulsando el bot&oacute;n a&ntilde;dido en cualquier momento.",
	
		/**
		 * Status messages
		 */
	
			'bookmarks:save:success' => "Su art&iacute;culo ha sido a�adido a favoritos correctamente.",
			'bookmarks:delete:success' => "Su art&iacute;culo ha sido eliminado correctamente.",
	
		/**
		 * Error messages
		 */
	 
			'bookmarks:save:failed' => "Su art&iacute;culo no puede guardarse en favoritos, int&eacute;ntelo de nuevo.",
			'bookmarks:delete:failed' => "Su art&iacute;culo no puede ser eliminado, int&eacute;ntelo de nuevo.",
	
	
	);
					
	add_translation("es",$spanish);

?>
