<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */
	$spanish = array(
	
		'email:validate:subject' => "Por favor confirme su email %s!",
		'email:validate:body' => "Hola %s,

Por favor confirme su email pulsando el link de abajo:

%s�

",
		'email:validate:success:subject' => "Email validado a %s!",
		'email:validate:success:body' => "Hola %s,
			
Felicidades, ha validado su correo electr&oacute;nico.",
	
		'uservalidationbyemail:registerok' => "Para activar su cuenta, deber&iacute;a confirmar su email pulsando en el link que le env&iacute;amos"
		
	);

	add_translation("es",$spanish);
?>
