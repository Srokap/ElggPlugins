<?php

	$spanish = array(

		'mine' => 'Todas',
		'filter' => 'Filtro',
		'riverdashboard:useasdashboard' => "Sustituir el escritorio por defecto por el flujo de actividades de la red social",
		'activity' => 'Actividad',
		'riverdashboard:recentmembers' => '&Uacute;ltimos miembros',	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Anuncios de la red social",
		'sitemessages:posted' => "Enviados",
		'sitemessages:river:created' => "Zona del administrador, %s,",
		'sitemessages:river:create' => "Se ha enviado a la red",
		'sitemessages:add' => "A&ntilde;adir un mensaje al las p&aacute;ginas",
		'sitemessage:deleted' => "Zona de mensajes eliminados",
		
		'river:widget:noactivity' => 'No podemos detectar ninguna actividad.',
		'river:widget:title' => "Actividad",
		'river:widget:description' => "Mostrar la &uacute;ltima actividad.",
		'river:widget:title:friends' => "Actividad de los amigos",
		'river:widget:description:friends' => "Mostrar lo que tu amigos hacen.",
		'river:widgets:friends' => "Amigos",
		'river:widgets:mine' => "Todos",
		'river:widget:label:displaynum' => "N&uacute;meor de entradas a mostrar:",
		'river:widget:type' => "Indique si desea mostrar su actividad o la actividad de sus amigos",
		'item:object:sitemessage' => "Zona de mensajes",
	);
					
	add_translation("es",$spanish);

?>
