<?php

	$spanish = array(
	
		'media:insert' => 'Insertar / subir archivos multimedia',
	
		'embed:instructions' => 'Cliquea cualquier archivo para a&ntilde;adirlo a tu contenido.',
	
		'embed:media' => 'Insertar archivos multimedia',
		'upload:media' => 'Subir archivos multimedia',
	
		'embed:file:required' => 'No se puede subir el archivo. El administrador del sistema tiene que instalar el plugin necesario.',
	
	);
					
	add_translation("es",$spanish);

?>