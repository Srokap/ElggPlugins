<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		'captcha:entercaptcha' => 'Introduce el texto de la imagen',
		'captcha:captchafail' => 'Lo siento, el texto introducido no se corresponde con el de la imagen.',
	
	);
					
	add_translation("es",$spanish);
?>