<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'blog' => "Blog",
			'blogs' => "Blogs",
			'blog:user' => "Blog de %s",
			'blog:user:friends' => "Blogs de los amigos de %s",
			'blog:your' => "Su blog",
			'blog:posttitle' => "Blog de %s: %s",
			'blog:friends' => "Blogs de amigos",
			'blog:yourfriends' => "Blogs m&aacute;s recientes de sus amigos",
			'blog:everyone' => "Todos los blogs",
	
			'blog:read' => "Leer blog",
	
			'blog:addpost' => "Crear noticia en el blog",
			'blog:editpost' => "Editar una respuesta de un blog",
	
			'blog:text' => "Texto del blog",
	
			'blog:strapline' => "%s",
			
			'item:object:blog' => 'Comentarios del blog',
                        'blog:never' => 'nunca',
                        'blog:preview' => 'Previsualizar',
                        'blog:draft:save' => 'Guardar borrador',
                        'blog:draft:saved' => '&Uacute;ltimo borrador',
                        'blog:comments:allow' => 'Permitir comentarios',
                        'blog:preview:description' => 'Esta es una previsualizaci&oacute;n de su env&iacute;o.',
                        'blog:preview:description:link' => 'Continuar editando o guardar su env&iacute;o, pulseme.',


			'blog:enableblog' => 'Habilitar blog de grupo',
	
			'blog:group' => 'Blog del grupo',

			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'blog:river:created' => "%s ha escrito",
	        'blog:river:updated' => "%s ha actualizado",
	        'blog:river:posted' => "%s ha enviado",
	        
	        //these get inserted into the river links to take the user to the entity
	        'blog:river:create' => "un nuevo mensaje al blog",
	        'blog:river:update' => "una actualizaci&oacute;n de un blog",
	        'blog:river:annotate' => "un comentario en un blog",
			
	
		/**
		 * Status messages
		 */
	
			'blog:posted' => "Su noticia ha sido subida al blog.",
			'blog:deleted' => "Su noticia ha sido eliminada.",
	
		/**
		 * Error messages
		 */
	
			'blog:save:failure' => "Su blog no puede ser guardado, int&eacute;ntelo de nuevo.",
			'blog:blank' => "Lo lamento; necesita rellenar tanto el t&iacute;tulo como el cuerpo antes de enviar.",
			'blog:notfound' => "Lo lamento, no podemos encontrar env&iacute;os a ese blog.",
			'blog:notdeleted' => "Lo lamento, no podemos borrar este env&iacute;o.",
	
	);

					
	add_translation("es",$spanish);

?>
