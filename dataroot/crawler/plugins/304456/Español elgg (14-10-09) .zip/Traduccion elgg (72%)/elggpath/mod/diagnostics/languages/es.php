<?php
	/**
	 * Elgg diagnostics language pack.
	 * 
	 * @package ElggDiagnostics
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$spanish= array(
	
			'diagnostics' => 'Diagnostico del sistema',
			'diagnostics:unittester' => 'Tests unitarios',
	
			'diagnostics:description' => 'Esta herramienta es &uacute;til para diagnosticar alg&uacute;n problema con Elgg. Debe descargar un fichero de texto con el resultado.',
			'diagnostics:unittester:description' => 'Este plugin realiza pruebas de diagn&oacute;stico que son registradas por los plugins con el fin de depurar las partes del framework Elgg.',
			
			
			'diagnostics:test:executetest' => 'Realizar test',
			'diagnostics:test:executeall' => 'Realizar todos los tests',
			'diagnostics:unittester:notests' => 'Lo siento, no hay m&oacute;dulos de tests unitarios instalados.',
			'diagnostics:unittester:testnotfound' => 'Lo siento, el informe no se ha podido generar porque ese test no se ha encontrado.',
	
			'diagnostics:unittester:testresult:nottestclass' => 'ERROR - El resultado no es una clase test',
			'diagnostics:unittester:testresult:fail' => 'ERROR',
			'diagnostics:unittester:testresult:success' => '&Eacute;XITO',
	
			'diagnostics:unittest:example' => 'El ejemplo de test unitario, solo esta disponible en el modo de depuraci&oacute;n.',
	
			'diagnostics:unittester:report' => 'Informe del test de %s',
			
			
			'diagnostics:download' => 'Descarga .txt',
	
	
			'diagnostics:header' => '========================================================================
Resultado del diagn&oacute;stico Elgg
Generado %s por %s
========================================================================
			
',
			'diagnostics:report:basic' => '
Elgg libre %s, version %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
Informaci&oacute;n PHP:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Plugins instalados y detalles:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Archivos instaladados y suma de comprobaci&oacute;n:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Variables globales:

%s
------------------------------------------------------------------------',
	
	);
					
	add_translation("es",$spanish);
?>