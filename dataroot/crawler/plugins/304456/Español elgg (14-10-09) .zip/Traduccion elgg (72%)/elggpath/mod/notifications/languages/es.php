<?php

	$spanish = array(
	
		'friends:all' => 'Todos los amigos',
	
		'notifications:subscriptions:personal:description' => 'Recibir una notificaci&oacute;n cuando la acci&oacute;n se haya contrastado con el contenido',
		'notifications:subscriptions:personal:title' => 'Notificaciones personales',
	
		'notifications:subscriptions:collections:title' => 'Listas de amigos',
		'notifications:subscriptions:collections:description' => 'Use los iconos que siguen para la configuraci&oacute;n de las notificaciones de los miembros de sus listas de amigos. Afectar&aacute; a los usuarios en el panel de notificaci&oacute;n al final de la p&aacute;gina. ',
		'notifications:subscriptions:collections:edit' => 'Para editar sus listas de amigos, pulse aqu&iacute;.',
	
		'notifications:subscriptions:changesettings' => 'Notificaciones',
		'notifications:subscriptions:changesettings:groups' => 'Notificaciones de grupos',
		'notification:method:email' => 'Email',	
	
		'notifications:subscriptions:title' => 'Notificaciones por usuarios',
		'notifications:subscriptions:description' => 'Seleccione el m&eacute;todo de notificaci&oacute;n que desear&iacute;a para recibir notificaciones de sus amigos cuando hayan creado nuevos contenidos, .',
		'notifications:subscriptions:groups:description' => 'Seleccione el m&eacute;todo que desar&iacute;a usar para recibir notificaciones cuando haya un nuevo contenido de un grupo.',
	
		'notifications:subscriptions:success' => 'La configuraci&oacute;n de sus notificaciones ha sido guardada.',
	
	);
					
	add_translation("es",$spanish);

?>
