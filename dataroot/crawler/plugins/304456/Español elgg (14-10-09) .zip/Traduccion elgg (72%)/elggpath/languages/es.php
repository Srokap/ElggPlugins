<?php
	$spanish = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'Lugares',
	
		/**
		 * Sessions
		 */
			
			'login' => 'Entrar',
			'loginok' => 'Ha entrado en nuestro espacio.',
			'loginerror' => 'No puede loguearse. Esto ocurre porque no tiene todavia su cuenta activada o los detalles suministrados son incorrectos. Garantice que los datos son v&aacute;lidos e int&eacute;ntelo de nuevo.',
			'logout' => 'Salir',
			'logoutok' => 'Acaba de salir de la red, muchas gracias',
			'logouterror' => 'No podemos efectuar la salida, por favor int&eacute;ntelo de nuevo.',
		/**
		 * Errors
		 */
			'exception:title' => "Bienvenido a Elgg",
	
			'InstallationException:CantCreateSite' => "Imposible crear un nuevo sitio Elgg con los credenciales Name:%s, Url: %s",
		
			'actionundefined' => "La accion solicitada (%s) no ha sido definida en el sistema",
			'actionloggedout' => "Lo lamento, no puede realizar esta acci&oacute;n mientras no se haya conectado",
	
			'notfound' => "El recurso solicitado no se encuentra o no tiene acceso al mismo.",
			
			'SecurityException:Codeblock' => "Acceso denegado para ejecutar un bloque con privilegios",
			'DatabaseException:WrongCredentials' => "No se puede conectar a la base de datos con los credenciales establecidos %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "No se puede conectar con la base de datos '%s', por favor, comprueba que la base de datos est&aacute; creada y tienes acceso a ella",
			'SecurityException:FunctionDenied' => "El acceso a la función con privilegios '%s' ha sido denegado",
			'DatabaseException:DBSetupIssues' => "Hab&iacute;a un n&uacute;mero de cuestiones: ",
			'DatabaseException:ScriptNotFound' => "No se puede encontrar el script solicitado en: %s.",
			
			'IOException:FailedToLoadGUID' => "Fallo al cargar el nuevo %s de GUID:%d",
			'InvalidParameterException:NonElggObject' => "Ha pasado una entidad que no es un objeto Elgg a un constructor de objetos Elgg!",
			'InvalidParameterException:UnrecognisedValue' => "Valor no reconocido pasado al constructor",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",
			
			'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Unable to save new %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'IOException:NotDirectory' => "%s is not a directory.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			
			'ClassException:ClassnameNotClass' => "%s is not a %s.",
			'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
			'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

			'ImportException:ImportFailed' => "Could not import element %d",
			'ImportException:ProblemSaving' => "There was a problem saving %s",
			'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
			'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",
			
			'ExportException:NoSuchEntity' => "No such entity GUID:%d", 
			
			'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
			'ImportException:NotAllImported' => "Not all elements were imported.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "All files must have an owner!",
			'IOException:CouldNotMake' => "Could not make %s",
			'IOException:MissingFileName' => "You must specify a name before opening a file.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
			'NotificationException:NoNotificationMethod' => "No notification method specified.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
			'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
			'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
			'InvalidParameterException:UnrecognisedMethod' => "Unrecognised call method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
			'SecurityException:authenticationfailed' => "User could not be authenticated",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',
		/**
		 * API
		 */
			'system.api.list' => "List all available API calls on the system.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

			'name' => "Nombre",
			'email' => "Correo electronico",
			'username' => "Usuari@",
			'password' => "Contrase&ntilde;a",
			'passwordagain' => "Confirme la contrase&ntilde;a", 
			'admin_option' => "Establecer usuari@ como administrador",
	
		/**
		 * Access
		 */
	
			'ACCESS_PRIVATE' => "Privado",
			'ACCESS_LOGGED_IN' => "Usuari@s logueados",
			'ACCESS_PUBLIC' => "P&uacute;blico",
			'PRIVATE' => "Privado",
			'LOGGED_IN' => "Usuari@s logueados",
			'PUBLIC' => "Público",
			'access' => "Acceso",
			'access:friends:label' => "Amig@s",

		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "Escritorio",
            'dashboard:configure' => "Editar la p&aacute;gina",
			'dashboard:nowidgets' => "Pulse 'Editar la p&aacute;gina' para a&ntilde;adir plugins y personalizar su escritorio.",

			'widgets:add' => 'A&ntilde;adir componentes a su p&aacute;gina',
			'widgets:add:description' => "Seleccione los componentes que quiere a&ntilde;adir a su p&aacute;gina arrastrandolos desde la <b>galer&iacute;a de componentes</b> de la derecha, a cualquier &aacute;rea de abajo posicion&aacute;ndolos en el lugar que desee.

Para elminar el componente arrastelo a la <b>galer&iacute;a de componentes</b>.",
			'widgets:position:fixed' => '(Posici&oacute;n fija en la p&aacute;gina)',
	
			'widgets' => "Componentes",
			'widget' => "Componente",
			'item:object:widget' => "Componentes",
			'layout:customise' => "Personalice las capas",
			'widgets:gallery' => "Galer&iacute;a de componentes",
			'widgets:leftcolumn' => "Componentes izquierdos",
			'widgets:fixed' => "Posici&oacute;n fijada",
			'widgets:middlecolumn' => "Componentes centrales",
			'widgets:rightcolumn' => "Componentes derechos",
			'widgets:profilebox' => "Cuadro de perfiles",
			'widgets:panel:save:success' => "Sus componentes han sido guardados con &eacute;xito.",
			'widgets:panel:save:failure' => "Error al grabar los componentes. Por favor, int&eacute;ntelo de nuevo.",
			'widgets:save:success' => "El componente ha sido guardado con &eacute;xito.",
			'widgets:save:failure' => "No podemos guardar sus componentes. Por favor int&eacute;telo de nuevo.",
			'widgets:handlernotfound' => 'Este componente esta estropeado o ha sido deshabilitado por el administrador.',

	
		/**
		 * Groups
		 */
	
			'group' => "Grupo", 
			'item:group' => "Grupos",
	
		/**
		 * Profile
		 */
	
			'profile' => "Perfil",
			'profile:edit:default' => 'Sustituir campos del perfil',
			'user' => "Usuari@",
			'item:user' => "Ususari@s",
			'riveritem:single:user' => 'Un usuari@',
			'riveritem:plural:user' => 'Algunos usuari@s',

		/**
		 * Profile menu items and titles
		 */
	
			'profile:yours' => "Su perfil",
			'profile:user' => "Perfil de %s",
	
			'profile:edit' => "Editar su perfil",
			'profile:profilepictureinstructions' => "La imagen del perfil no se puede mostrar en su p&aacute;gina. <br/> Puede cambiarlo cuando desee. (El formato del fichero s&oacute;lo acepta: GIF, JPG o PNG)",
			'profile:icon' => "Imagen del perfil",
			'profile:createicon' => "Crear su avatar",
			'profile:currentavatar' => "Avatar actual",
			'profile:createicon:header' => "Imagen del perfil",
			'profile:profilepicturecroppingtool' => "Herramienta para el ajuste de la imagen de su perfil",
			'profile:createicon:instructions' => "Arraste al cuadro de abajo para encajar la imagen al marco. Ver&aacute; una vista previa en la caja de la derecha. Cuando est&eacute; satisfecho con el resultado, pulse 'Crear su avatar'. La imagen ser&aacute mostrada. ",
	
			'profile:editdetails' => "Editar detalles",
			'profile:editicon' => "Editar el icono de su perfil",
	
			'profile:aboutme' => "Acerca de m&iacute;", 
			'profile:description' => "Acerca de m&iacute;",
			'profile:briefdescription' => "Breve descripci&oacute;n",
			'profile:location' => "Ubicaci&oacute;n",
			'profile:skills' => "Temas",  
			'profile:interests' => "Intereses", 
			'profile:contactemail' => "Email de contacto",
			'profile:phone' => "Tel&eacute;fono",
			'profile:mobile' => "M&oacute;vil",
			'profile:website' => "Sitio web",

			'profile:banned' => 'Este usuari@ ha sido baneado.',

			'profile:river:update' => "%s ha actualizado su perfil",
			'profile:river:iconupdate' => "%s ha actualizado el icono de su perfil",
	
			'profile:label' => "Etiqueta del campo",
			'profile:type' => "Tipo del campo",
	
			'profile:editdefault:fail' => 'El perfil por defecto no puede ser guardado',
			'profile:editdefault:success' => 'Art&iacute;culo a&ntilde;adido con &eacute;xito en su perfil por defecto',
	
			
			'profile:editdefault:delete:fail' => 'Error al eliminar el art&iacute;culo del perfil por defecto',
			'profile:editdefault:delete:success' => 'Item del perfil por defecto eliminado!',
	
			'profile:defaultprofile:reset' => 'Perfil por defecto del sistema',
	
			'profile:resetdefault' => 'Resetear al perfil por defecto',
			'profile:explainchangefields' => 'Puedes cambiar los cmapos del perfil con los tuyos propios usando el formulario m&aacute;s abajo. Primero escribe la etiqueta nuevo campo del perfil, por ejemplo \'Equipo de f&uacute;tbol favorito\'. Despu&eacute;s selecciona el tipo de campo, por ejemplo, palabra clave, url, texto y acepta. En cualquier momento puedes volver a restablecer el perfil por defecto.',
	
		/**
		 * Profile status messages
		 */
	
			'profile:saved' => "Su perfil ha sido guardado correctamente.",
			'profile:icon:uploaded' => "Su imagen ha sido actualizada correctamente.",
	
		/**
		 * Profile error messages
		 */
	
			'profile:noaccess' => "No tiene permiso para editar este perfil.",
			'profile:notfound' => "Lo lamento, no se puede encontrar el perfil especificado.",
			'profile:cantedit' => "Lo lamento, no tiene permisos para editar este perfil.",
			'profile:icon:notfound' => "Lo lamento, hay problemas al subir la imagen.",
	
		/**
		 * Friends
		 */
	
			'friends' => "Amigos",
			'friends:yours' => "Sus amigos",
			'friends:owned' => "Mis %s amigos",
			'friend:add' => "A&ntilde;adir amigo",
			'friend:remove' => "Eliminar amigo",	
			'friends:add:successful' => "Ha a&ntilde;adido %s amigos.",
			'friends:add:failure' => "No podemos a&ntilde;adir los %s amigos. Por favor int&eacute;ntelo de nuevo.",
	
			'friends:remove:successful' => "Ha eliminado %s amigos.",
			'friends:remove:failure' => "No podemos elminar %s emigos. Por favor int&eacute;ntelo de nuevo.",
	
			'friends:none' => "Este usuari@ no ha sido a&ntilde;adido a ningo de sus amigos.",
			'friends:none:you' => "No ha a&ntilde;adido a nadie como amigo, busque gente que tenga sus mismos intereses y a&ntilde;adalos como amigos.",
	
			'friends:none:found' => "No se han encontrado amigos.",
	
			'friends:of:none' => "Nadie ha a&ntilde;adido este usuari@ como amigo.",
			'friends:of:none:you' => "Nadie le ha a&ntilde;adido como amigo todavia. Comience con a&ntilde;adir contenido y rellenar su perfil para que la gente le encuentre.",
	
			'friends:of' => "Amigo de...",
			'friends:of:owned' => "Gente que ha hecho %s amigos",

			 'friends:num_display' => "N&uacute;mero de amigos a mostrar",
			 'friends:icon_size' => "Tama&ntilde;o del icono",
			 'friends:tiny' => "Diminuto",
			 'friends:small' => "Peque&ntilde;o",
			 'friends' => "Amigos",
			 'friends:of' => "Amigos de...",
			 'friends:collections' => "Lista de amigos",
			 'friends:collections:add' => "Nueva lista de amigos",
			 'friends:addfriends' => "A&ntilde;adir amigos",
			 'friends:collectionname' => "Lista de nombres",
			 'friends:collectionfriends' => "Amigos en la lista",
			 'friends:collectionedit' => "Editar esta lista",
			 'friends:nocollections' => "No tiene ninguna lista.",
			 'friends:collectiondeleted' => "Su lista ha sido borrada.",
			 'friends:collectiondeletefailed' => "Ha sido imposible eliminar la lista. Puede que no tenga los permisos necesarios.",
			 'friends:collectionadded' => "Su colecci&oacute;n se ha creado correctamente",
			 'friends:nocollectionname' => "Necesita asignar un nombre a su lista antes crearla.",
			 'friends:collections:members' => "Lista de amigos",
			 'friends:collections:edit' => "Editar la lista de amigos",


	        'friends:river:created' => "%s Componentes de amigos a&ntilde;adidos",
		'friends:river:updated' => "%s Componentes de sus amigos actualizados.",
	        'friends:river:delete' => "%s Componentes de sus amigos eliminados.",
	        'friends:river:add' => "%s ha a&ntilde;adidos un nuevo amigo.",
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'Suscribirse al feed',
			'feed:odd' => 'Suscribirse a OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'Ver enlace',

	
		/**
		 * River
		 */
			'river' => "Relaciones",//"River",			
			'river:relationship:friend' => 'En este momento es amigo de ',
			'river:noaccess' => 'No tiene permisos para ver este item.',
			'river:posted:generic' => '%s ha enviado',



		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "Configuraciones para los %s plugins han sido guardadas satisfactoriamente.",
			'plugins:settings:save:fail' => "Ha ocurrido un problema a la hora de guardar las configuraciones de los %s plugins.",
			'plugins:usersettings:save:ok' => "La configuraci&oacute;n del usuari@ para los %s plugins han sido correctamente guardadas.",
			'plugins:usersettings:save:fail' => "Ha habido un problema al guardar la configuraci&oacute;n de los %s plugins.",
			'admin:plugins:label:version' => "Versi&oacute;n",
			'item:object:plugin' => 'Configuraci&oacute;n de los plugins',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "Configuraci&oacute;n de las notificaciones",
			'notifications:methods' => "Por favor, especifique que m&eacute;todos quiere permitir.",
	
			'notifications:usersettings:save:ok' => "La configuraci&oacute;n de  notificaciones ha sido guardada.",
			'notifications:usersettings:save:fail' => "No se ha podido guardar la configuraci&oacute;n de la notifiaci&oacute;n.",
	
			'user.notification.get' => 'Devolver la configuraci&oacute;n de la notificaci&oacute;n al usuari@.',
			'user.notification.set' => 'Conjunto de notificaciones configuradas para  el usuari@.',
		/**
		 * Search
		 */
	
			'search' => "Buscar",
			'searchtitle' => "Buscar: %s",
			'users:searchtitle' => "Buscando para usuari@s: %s",
			'advancedsearchtitle' => "%s con resultados coincidentes  %s",
			'notfound' => "No se ha encontrado resultados.",
			'next' => "Siguiente",
			'previous' => "Anterior",
	
			'viewtype:change' => "Cambiar el tipo de listado",
			'viewtype:list' => "Vista de la lista",
			'viewtype:gallery' => "Galer&iacute;a",
	
			'tag:search:startblurb' => "'%s' Art&iacute;culos encontrados con esa información:",

			'user:search:startblurb' => "Usuari@s coincidentes '%s':",
			'user:search:finishblurb' => "Para ver m&aacute;s, pulse aqu&iacute;.",
	
		/**
		 * Account
		 */
	
			'account' => "Cuenta",
			'settings' => "Configuraci&oacute;n",
            'tools' => "Herramientas",
            'tools:yours' => "Sus herramientas",
	
			'register' => "Registro",
			'registerok' => "Se ha registrado para %s exitosamente.",
			'registerbad' => "Su registro no ha sido v&aacute;lido. El usuari@ puede existir, su contrase&ntilde;a puede no coincidir o el usuari@ o contrase&ntilde;a puede ser demasiado cortos",
			'registerdisabled' => "El registro ha sido deshabilitado por el administrador de sistemas",
	
			'registration:notemail' => 'Por favor, introduzca un email v&aacute;lido.',
			'registration:userexists' => 'Ese usuari@ ya existe',
			'registration:usernametooshort' => 'Su nombre de usuari@ debe tener un m&iacute;nimo de 4 caracteres.',
			'registration:passwordtooshort' => 'La contrase&ntilde;a debe tener un m&iacute;nimo de 6 caracteres',
			'registration:dupeemail' => 'Este email est&aacute; asociado a otra cuenta.',
			'registration:invalidchars' => 'Lo lamento, el usuari@ tiene caracteres inv&aacute;lidos.',
			'registration:emailnotvalid' => 'Lo lamento, el email que ha introducido no es v&aacute;lido para el sistema',
			'registration:passwordnotvalid' => 'Lo lamento, la contrase&ntilde;a que ha introducido no es v&aacute;lido para el sistema',
			'registration:usernamenotvalid' => 'Lo lamento, el usuari@ que ha introducido no es v&aacute;lido para el sistema',
	
			'adduser' => "A&ntilde;adir usuari@",
			'adduser:ok' => "Acaba de a&ntilde;adir un nuevo usuari@.",
			'adduser:bad' => "El usuari@ no puede ser creado.",
			
			'item:object:reported_content' => "Art&iacute;culos publicados",
	
			'user:set:name' => "Configuraci&oacute;n de la cuenta",
			'user:name:label' => "Su nombre",
			'user:name:success' => "Se ha cambiado su nombre en el sistema.",
			'user:name:fail' => "No se ha podido cambiar su nombre en el sistema.",
	
			'user:set:password' => "Contrase&ntilde;a de la cuenta",
			'user:password:label' => "Su nueva contrase&ntilde;a",
			'user:password2:label' => "Confirme su contrase&ntilde;a",
			'user:password:success' => "Contrase&ntilde;a cambiada",
			'user:password:fail' => "No se a podido cambiar la contrase&ntilde;a del sistema.",
			'user:password:fail:notsame' => "Las contrase&ntilde;as no coinciden",
			'user:password:fail:tooshort' => "La contrase&ntilde;a debe tener un m&iacute;nimo de 6 caracteres",
	
			'user:set:language' => "Configuraci&oacute;n del idioma",
			'user:language:label' => "Su idioma",
			'user:language:success' => "Su idioma ha sido actualizado.",
			'user:language:fail' => "Su idioma no se ha podido guardar.",
	
			'user:username:notfound' => 'Usuari@ %s no encontrado.',
	
			'user:password:lost' => 'Olvid&eacute; mi contrase&ntilde;a',
			'user:password:resetreq:success' => 'La nueva contrase&ntilde;a ha sido enviada a su correo',
			'user:password:resetreq:fail' => 'No se puede generar una nueva contrase&ntilde;a.',
	
			'user:password:text' => 'Para generar una nueva contrase&ntilde;a, introduzca su nombre usuari@. Le enviaremos a su email una verificación &uacute;nica con informaci&oacute;n de la contrase&ntilde;a.',
	
			'user:persistent' => 'Recordarlo',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "Su configuraci&oacute;n ha sido guardada.",
			'admin:configuration:fail' => "Su configuraci&oacute;n no ha podido ser guardada.",
	
			'admin' => "Administraci&oacute;n",
			'admin:description' => "El panel de administraci&oacute;n permite el control de todos los aspectos del sistema, desde la gesti&oacute;n de usuari@s hasta como se comportan los plugins. Elija una opci&oacute;n para comenzar.",
			
			'admin:user' => "Administraci&oacute;n de usuari@s",
			'admin:user:description' => "Este panel de administraci&oacute;n permite el control de la configuraci&oacute;n de usuari@ de su red social.",
			'admin:user:adduser:label' => "Pulse aqu&iacute; para a&ntilde;adir un nuevo usuari@...",
			'admin:user:opt:linktext' => "Configure los usuari@s...",
			'admin:user:opt:description' => "Informaci&oacute; de la configuraci&oacute; de usuari@s y sus cuentas. ",
			
			'admin:site' => "Administraci&oacute;n de la red social",
			'admin:site:description' => "Este panel de administraci&oacute;n permite controlar la configuraci&oacute;n global de la red social.",
			'admin:site:opt:linktext' => "Configure el sitio...",
			'admin:site:opt:description' => "Permite confiturar las caracteristicas de la red social",
			'admin:site:access:warning' => "Cambiar la configuraci&oacute;n del acceso de  s&oacute;lo afecta a los permisos en el contenido que se cree en el futuro.", 
						
			'admin:plugins' => "Administraci&oacute;n de plugins",
			'admin:plugins:description' => "Este panel de administraci&oacute;n permite el control y configuraci&oacute;n de los plugins instalados en la red social.",
			'admin:plugins:opt:linktext' => "Configure las herramientas...",
			'admin:plugins:opt:description' => "Configure los plugins instalados en la red social. ",
			'admin:plugins:label:author' => "Autor",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licencia",
			'admin:plugins:label:website' => "URL",
			"admin:plugins:label:moreinfo" => 'm&aacute;s informaci&oacute;n',
			'admin:plugins:reorder:yes' => "Los plugins %s se han reordenado correctamente.",
			'admin:plugins:reorder:no' => "Los plugins %s no se han podido reordenar.",
			'admin:plugins:disable:yes' => "El plugin %s se ha deshabilitado correctamente.",
			'admin:plugins:disable:no' => "El plugin %s no ha podido ser deshabilitado.",
			'admin:plugins:enable:yes' => "El plugin %s se ha habilitado correctamente.",
			'admin:plugins:enable:no' => "El plugin %s no ha podido ser habilitado.",
	
			'admin:statistics' => "Estad&iacute;sticas",
			'admin:statistics:description' => "Este panel muestra las estadísticas de su red social",
			'admin:statistics:opt:description' => "Ver informaci&oacute;n estad&iacute;stica sobre los usuari@ del sistema.",
			'admin:statistics:opt:linktext' => "Ver estad&iacute;sticas...",
			'admin:statistics:label:basic' => "Estad&iacute;sticas b&aacute;sicas de la red social",
			'admin:statistics:label:numentities' => "Entidades de la red social",
			'admin:statistics:label:numusers' => "N&uacute;mero de usuari@s",
			'admin:statistics:label:numonline' => "N&uacute;mero de usuari@s on line",
			'admin:statistics:label:onlineusers' => "Usuari@s online en este momento",
			'admin:statistics:label:version' => "Versi&oacute;n elgg",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Version",
			'item:object:thewire' => "Hilos",
			'item:object:image' => 'Im&aacute;genes',
			'item:object:groupforumtopic' => "Temas de grupos de foro",
			'item:object:file' => "Archivos",
			'item:object:page_top' => "P&aacute;ginas principales",
			'item:object:page' => "P&aacute;ginas simples",
			'item:object:messages' => "Mensajes",
			'item:object:pages_welcome' => "P&aacute;ginas de bienvenida",
			'item:object:album' => "Albunes",
			
			'admin:user:label:search' => "Buscar usuari@s:",
			'admin:user:label:seachbutton' => "Buscar", 
	
			'admin:user:ban:no' => "No puede banear al usuari@",
			'admin:user:ban:yes' => "Usuari@s baneados.",
			'admin:user:unban:no' => "No puede admitir al usuari@",
			'admin:user:unban:yes' => "Usuari@ admitido.",
			'admin:user:delete:no' => "No puede eliminar usuari@",
			'admin:user:delete:yes' => "Usuari@ eliminad@",
	
			'admin:user:resetpassword:yes' => "Contrase&ntilde;a reseteada y notificado al usuari@.",
			'admin:user:resetpassword:no' => "La contrase&ntilde;a no puede ser reseteada.",
	
			'admin:user:makeadmin:yes' => "El usuari@ es ahora administrador.",
			'admin:user:makeadmin:no' => "No podemos hacer este usuari@ administrador.",
                        'admin:user:removeadmin:yes' => "El usuari@ ya no es administrador.",
			'admin:user:removeadmin:no' => "No podemos eliminar los privilegios de administraci&oacute;n de este usuari@.",
		/**
		 * User settings
		 */
			'usersettings:description' => "La configuraci&oacute;n del panel de usuari@ permite el control de su red social, desde la gesti&oacute;n de usuari@s hasta c&oacute;mo se comportan los plugins. Elija una opci&oaucte;n para comenzar.",
	
			'usersettings:statistics' => "Estad&iacute;sticas",
			'usersettings:statistics:opt:description' => "Ver la informaci&oacute;n estad&iacute;stica acerca de los usuari@s y objetos de la red social.",
			'usersettings:statistics:opt:linktext' => "Estad&iacute;sticas de la cuenta",
	
			'usersettings:user' => "Su configuraci&oacute;n",
			'usersettings:user:opt:description' => "Esto le permite controlar la configuraci&oacute;n del usuari@.",
			'usersettings:user:opt:linktext' => "Cambiar su configuraci&oacute;n",
	
			'usersettings:plugins' => "Herramientas",
			'usersettings:plugins:opt:description' => "Configure la configuraciones para sus herramientas activas.",
			'usersettings:plugins:opt:linktext' => "Configure sus herramientas",
	
			'usersettings:plugins:description' => "Este panel permite el control y configuraci&oacute;n personal para las herramientas instaladas por el administrador de sistemas.",
			'usersettings:statistics:label:numentities' => "Sus entidades",
	
			'usersettings:statistics:yourdetails' => "Sus detalles",
			'usersettings:statistics:label:name' => "Nombre y apellidos",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "Miembro desde",
			'usersettings:statistics:label:lastlogin' => "Ultimo acceso",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "Guardar",
			'publish' => "Publicar",
			'cancel' => "Cancelar",
			'saving' => "Guardando ...",
			'update' => "Actualizar",
			'edit' => "Editar",
			'delete' => "Eliminar",
			'load' => "Cargar",
			'upload' => "Subir",
			'ban' => "Banear",
			'unban' => "Admitir",
			'enable' => "Habilitar",
			'disable' => "Deshabilitar",
			'request' => "Solicitar",
			'complete' => "Completado",
			'open' => 'Abierto',
			'close' => 'Cerrado',
			'reply' => "Responder",
   			'more' => 'M&aacute;s',
			'comments' => 'Comentarios',
			'import' => 'Importar',
			'export' => 'Exportar',

			'up' => 'Arriba',
			'down' => 'Abajo',
			'top' => 'Superior',
			'bottom' => 'Inferior',
	
			'invite' => "Invitar",
	
			'resetpassword' => "Resetear contrase&ntilde;a",
			'makeadmin' => "Hacer administrador",
			'removeadmin' => "Eliminar como administrador",

			'option:yes' => "S&iacute;",
			'option:no' => "No",
	
			'unknown' => 'Desconocido',
	
			'active' => 'Activo',
			'total' => 'Total',
	
			'learnmore' => "Pulse aqu&iacute; para aprender m&aacute;s.",
	
			'content' => "Contenido",
			'content:latest' => '&Uacute;ltimas actividades',
			'content:latest:blurb' => 'Pulse aqu&iacute; para ver los &uacute;ltimos contenidos de la red social.',
	
			'link:text' => 'Ver enlace',
	
 			'enableall' => 'Habilitar todo',
			'disableall' => 'Deshabilitar todo',

                /**
			* Generic questions
                */

			'question:areyousure' => 'Est&aacute; seguro?',


		/**
		 * Generic data words
		 */
	
			'title' => "T&iacute;tulo",
			'description' => "Descripci&oacute;n",
			'tags' => "Etiquetas",
			'spotlight' => "Bienvenido",
			'all' => "Todos",
	
			'by' => 'por',
	
			'annotations' => "Anotaciones",
			'relationships' => "Relaciones",
			'metadata' => "Palabras clave",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "Seguro que quiere eliminar este art&iacute;culo?",
			'fileexists' => "El archivo ya existe. Para reemplazarlo, seleccione abajo:",
			
			
	    /**
       		  * System messages
            **/

			'systemmessages:dismiss' => "Pulse para continuar",

	
	    /**
		 * Import / export
	    */
			'importsuccess' => "Los datos se importaron correctamente.",
			'importfail' => "Ha habido un error al importar los datos.",
           /**
	         * User add
	   */
                'useradd:subject' => 'Cuenta de usuari@ creada',
                'useradd:body' => '
%s,
Se ha creado una cuenta de usuari@ en %s. Para entrar, visite:

	%s

Y para poder participar debe usar los siguientes credenciales:

	Username: %s
	Contrase&ntilde;a: %s

Una vez que se haya logueado, le recomendamos que cambie su contrase&ntilde;a.
',

		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "Justo ahora",
			'friendlytime:minutes' => "Hace %s minutos",
			'friendlytime:minutes:singular' => "Hace un minuto",
			'friendlytime:hours' => "Hace %s horas",
			'friendlytime:hours:singular' => "Hace una hora",
			'friendlytime:days' => "Hace %s dias",
			'friendlytime:days:singular' => "Ayer",
	
                        'date:month:01' => '%s Enero',
                        'date:month:02' => '%s Febrero',
                        'date:month:03' => '%s Marzo',
                        'date:month:04' => '%s Abril',
                        'date:month:05' => '%s Mayo',
                        'date:month:06' => '%s Junio',
                        'date:month:07' => '%s Julio',
                        'date:month:08' => '%s Agosto',
                        'date:month:09' => '%s Septiembre',
                        'date:month:10' => '%s Octubre',
                        'date:month:11' => '%s Noviembre',
                        'date:month:12' => '%s Diciembre',


		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg necesita un archivo llamado .htaccess para colocarlo en el directorio raiz de esta instalaci&oacute;n. Hemos intentado crearlo, pero Elgg no tiene permisos para escribir en este directorio.

Crearlo es f&aacute;cil. Copia el contenido de la caja de texto, insertalo en un editor de texto y guardalo con el nombre .htaccess
",

			'installation:error:settings' => "Elgg no puede encontrar el fichero de configuraci&oacute;n. La mayor&iacute;a las caracter&iacute;sticas de Elgg han sido instaladas, pero necesitamos los detalles de tu base de datos. Para hacer esto:

1. Renombre engine/settings.example.php a settings.php en tu directorio installation de Elgg.

2. Abrelo con el editor de texto e introduce los detalles de tu base de datos MySQL. Si no los conoces, pregunta al administrador del sistema.

De forma alternativa, puedes introducir la configuraci&oacute;n de tu base de datos e intentaremos hacer esto por ti.",
	
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Installation",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
	
			'installation:settings' => "Configuraci&oacute;n del sistema",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
	
			'installation:settings:dbwizard:prompt' => "Introduce la configuraci&oacute;n de tu base de datos y pulsa guardar:",
			'installation:settings:dbwizard:label:user' => "Usuario de la base de datos",
			'installation:settings:dbwizard:label:pass' => "Contrase&ntilde;a de la base de datos",
			'installation:settings:dbwizard:label:dbname' => "Base de datos para Elgg",
			'installation:settings:dbwizard:label:host' => "Hostname de la base de datos(normalmente 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Prefijo para las tablas(normalmente 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
	
			'installation:sitename' => "El nombre de tu red social (ej \"Mi red social\"):",
			'installation:sitedescription' => "Breve descripci&oacute;n de tu red social (opcional)",
			'installation:wwwroot' => "La URL de la red social, seguida por una barra diagonal (/):",
			'installation:path' => "La ruta completa a la raíz de su red social en el disco, seguida por una barra diagonal (/):",
			'installation:dataroot' => "La ruta completa del directorio en el que se guardarán los archivos subidos, seguida por una barra diagonal (/):",
			'installation:dataroot:warning' => "Debes crear este directorio manualmente. Debería encontrarse en un lugar diferente al directorio de instalaci&oactue;n de Elgg.",
			'installation:sitepermissions' => "Los permisos de acceso por defecto:",
			'installation:language' => "El idioma por defecto de tu red social:",
			'installation:debug' => "El modo de depuraci&oacute;n proporciona informaci&oacute;n adicional que se puede utilizar para diagnosticar fallos, sin embargo, puede disminuir la velocidad del sistema por lo que sólo debe utilizarse si está teniendo problemas:",
			'installation:debug:label' => "Activar modo de depuraci&oacute;n",
			'installation:httpslogin' => "Activar para que los usuarios puedan tener acceso a trav&eacute;s de HTTPS. Tendr&aacute; que tener HTTPS habilitada en el servidor para que esto funcione.",
			'installation:httpslogin:label' => "Habilitar accesos HTTPS",
			'installation:usage' => "Esta opci&oacute;n permite a Elgg enviar estad&iacute;sticas an&oacute;nimas de uso.",
			'installation:usage:label' => "Enviar estad&iacute;sticas an&oacute;nimas de uso.",
			'installation:view' => "Introducir la vista que se usar&aacute; por defecto para tu red social o deja el recuadro en blanco para usar la vista por defecto (en caso de duda, escoja la vista por defecto):",

			'installation:siteemail' => "Email de la red social (usado para enviar emails del sistema)",
	
			'installation:disableapi' => "La API REST es una interfaz flexible y extensible que permite a las aplicaciones utilizar ciertas características de Elgg de forma remota.",
			'installation:disableapi:label' => "Habilitar la API REST",
			'installation:allow_user_default_access:description' => "Si se selecciona, los usuarios individuales podr&aacute;n establecer su propio nivel de acceso predeterminado que estar&aacute; por encima del sistema de nivel de acceso predeterminado.",
			'installation:allow_user_default_access:label' => "Permitir el acceso de usuarios por defecto",
	
			'installation:simplecache:description' => "El uso de cach&eacute; simple aumenta el rendimiento de almacenamiento en la cach&eacute; de contenido est&aacute;tico incluyendo algunos archivos CSS y JavaScript. Normalmente activado.",
			'installation:simplecache:label' => "Usar cach&eacute; simple (recomendado)",
	
			'installation:viewpathcache:description' => "El almacenamiento de la ruta del archivo de visualizaci&oacute;n disminuye el tiempo de carga de los plugins almacenando en cach&eacute; los archivos de visualizaci&oacute;n.",
			'installation:viewpathcache:label' => "Usar almacenamiento de la ruta del archivo de visualizaci&oacute;n (recomendado)",

			'upgrading' => 'Actualizar',
			'upgrade:db' => 'La base de datos ha sido actualizada.',
			'upgrade:core' => 'La instalaci&oacute;n de Elgg ha sido actualizada.',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "Bienvenido",
			'welcome:user' => 'Bienvenido %s',
			'welcome_message' => "Bienvenido a la instalaci&oacute;n de elgg.",
	
		/**
		 * Emails
		 */
			'email:settings' => "Configuraci&oacute;n del email",
			'email:address:label' => "Su direcci&oacute;n de email",
			
			'email:save:success' => "El nuevo email se ha guardado, verifique su petici&oacute;n.",
			'email:save:fail' => "Su nuevo email no se puede guardar.",
	
			'email:confirm:success' => "Su cuenta ha sido confirmada",
			'email:confirm:fail' => "Su correo no puede ser verificado...",
	
			'friend:newfriend:subject' => "%s es ahora amig@ suy@!",
			'friend:newfriend:body' => "%s es ahora amigo suyo

Para ver su perfil, pulse aqu&iacute;:

	%s

Por favor no conteste a este correo.",
	
	
	
			'email:resetpassword:subject' => "Contrase&ntilde;a reseteada",
			'email:resetpassword:body' => "Hola %s,
			
Su contrase&ntilde;a ha sido establecida a: %s",
	
	
			'email:resetreq:subject' => "Petici&oacute;n para una nueva contrase&ntilde;a.",
			'email:resetreq:body' => "Hola %s,
			
Alguien (desde la IP %s) ha solicitado una nueva contrase&ntilde;a para su cuenta.

Si ha sido usted quien lo ha solicitado pulse en el enlace de abajo, en otro caso ignore este email.

%s

",

                /**
	                 * user default access
	        */
                'default_access:settings' => "Su nivel de acceso por defecto",
                'default_access:label' => "Acceso por defecto",
                'user:default_access:success' => "Su nuevo nivel de acceso ha sido guardado.",
                'user:default_access:failure' => "Su nuevo nivel de acceso no puede guardarse.",

		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"Datos de entrada inv&aacute;lidos",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s Commentarios",
			
			'riveraction:annotation:generic_comment' => '%s comentados en %s',
	
			'generic_comments:add' => "A&ntilde;adir un comentario",
			'generic_comments:text' => "Comentario",
			'generic_comment:posted' => "El comentario ha sido enviado correctamente.",
			'generic_comment:deleted' => "El comentario ha sido eliminado correctamente.",
			'generic_comment:blank' => "Lo lamento, necesita escribir algo en el comentario antes de guardarlo.",
			'generic_comment:notfound' => "Lo lamento, no podemos encontrar el art&iacute;culo.",
			'generic_comment:notdeleted' => "Lo lamento; no podemos eliminar este comentario.",
			'generic_comment:failure' => "Un error inesperado ha ocurrido al a&ntilde;adir su comentario, int&eacute;ntelo de nuevo por favor.",
	
			'generic_comment:email:subject' => 'Tiene un nuevo comentario',
			'generic_comment:email:body' => "Tiene un nuevo comentario en su articulo \"%s\" desde %s. que dice:

			
%s


Para contestar o ver el mensaje original, pulse aqui:

	%s

Para ver un perfil de %s, pulse aqui:

	%s

Por favor no responda a este correo.",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'Creada %s por %s',
			'entity:default:missingsupport:popup' => 'Esta entindad no puede ser desplegada correctamente. Puede ser por que requiere soporte de un plugin que no ha sido instalado.',
	
			'entity:delete:success' => '%s entidades han sido eliminadas',
			'entity:delete:fail' => '%s entidades no han podido ser eliminadas',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'El formulario est&aacute; campo perdido __token o __ts',
			'actiongatekeeper:tokeninvalid' => "Hemos encontrado un error (token mismatch). Probablemente signifique que la p&aacute;gina que est&eacute; usando haya expirado.",
			'actiongatekeeper:timeerror' => 'La p&aacute; que solicita ha expirado. Por favor recarguela e int&eacute;ntelo de nuevo.',
			'actiongatekeeper:pluginprevents' => 'Una extensi&oacute;n ha sido retenida por este formulario.',	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'y, el, entonces, pero, ella, su, uno, un, no, acerca, ahora, sin embargo, aun, de otro modo, y, the, entonces, pero, ella, el, su, su, uno, no, tambi&eacute;n, sobre, ahora, por lo tanto, sin embargo, todavia, asimismo, de lo contrario, por tanto, a la inversa, bastante, por consiguiente, además, no obstante, en vez de, mientras tanto, en consecuencia, esto, parece, que, quien, cuya, quien, quien',
	
		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar",
			"ab" => "Abkhazian",
			"af" => "Afrikaans",
			"am" => "Amharic",
			"ar" => "Arabic",
			"as" => "Assamese",
			"ay" => "Aymara",
			"az" => "Azerbaijani",
			"ba" => "Bashkir",
			"be" => "Byelorussian",
			"bg" => "Bulgarian",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengali; Bangla",
			"bo" => "Tibetan",
			"br" => "Breton",
			"ca" => "Catalan",
			"co" => "Corsican",
			"cs" => "Czech",
			"cy" => "Welsh",
			"da" => "Danish",
			"de" => "German",
			"dz" => "Bhutani",
			"el" => "Greek",
			"en" => "English",
			"eo" => "Esperanto",
			"es" => "Español",
			"et" => "Estonian",
			"eu" => "Basque",
			"fa" => "Persian",
			"fi" => "Finnish",
			"fj" => "Fiji",
			"fo" => "Faeroese",
			"fr" => "French",
			"fy" => "Frisian",
			"ga" => "Irish",
			"gd" => "Scots / Gaelic",
			"gl" => "Galician",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Hebrew",
			"ha" => "Hausa",
			"hi" => "Hindi",
			"hr" => "Croatian",
			"hu" => "Hungarian",
			"hy" => "Armenian",
			"ia" => "Interlingua",
			"id" => "Indonesian",
			"ie" => "Interlingue",
			"ik" => "Inupiak",
			//"in" => "Indonesian",
			"is" => "Icelandic",
			"it" => "Italian",
			"iu" => "Inuktitut",
			"iw" => "Hebrew (obsolete)",
			"ja" => "Japanese",
			"ji" => "Yiddish (obsolete)",
			"jw" => "Javanese",
			"ka" => "Georgian",
			"kk" => "Kazakh",
			"kl" => "Greenlandic",
			"km" => "Cambodian",
			"kn" => "Kannada",
			"ko" => "Korean",
			"ks" => "Kashmiri",
			"ku" => "Kurdish",
			"ky" => "Kirghiz",
			"la" => "Latin",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lithuanian",
			"lv" => "Latvian/Lettish",
			"mg" => "Malagasy",
			"mi" => "Maori",
			"mk" => "Macedonian",
			"ml" => "Malayalam",
			"mn" => "Mongolian",
			"mo" => "Moldavian",
			"mr" => "Marathi",
			"ms" => "Malay",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepali",
			"nl" => "Dutch",
			"no" => "Norwegian",
			"oc" => "Occitan",
			"om" => "(Afan) Oromo",
			"or" => "Oriya",
			"pa" => "Punjabi",
			"pl" => "Polish",
			"ps" => "Pashto / Pushto",
			"pt" => "Portuguese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Romanian",
			"ru" => "Russian",
			"rw" => "Kinyarwanda",
			"sa" => "Sanskrit",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croatian",
			"si" => "Singhalese",
			"sk" => "Slovak",
			"sl" => "Slovenian",
			"sm" => "Samoan",
			"sn" => "Shona",
			"so" => "Somali",
			"sq" => "Albanian",
			"sr" => "Serbian",
			"ss" => "Siswati",
			"st" => "Sesotho",
			"su" => "Sundanese",
			"sv" => "Swedish",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Tegulu",
			"tg" => "Tajik",
			"th" => "Thai",
			"ti" => "Tigrinya",
			"tk" => "Turkmen",
			"tl" => "Tagalog",
			"tn" => "Setswana",
			"to" => "Tonga",
			"tr" => "Turkish",
			"ts" => "Tsonga",
			"tt" => "Tatar",
			"tw" => "Twi",
			"ug" => "Uigur",
			"uk" => "Ukrainian",
			"ur" => "Urdu",
			"uz" => "Uzbek",
			"vi" => "Vietnamese",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			//"y" => "Yiddish",
			"yi" => "Yiddish",
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Chinese",
			"zu" => "Zulu",
	);

////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
	add_translation("es",$spanish);
?>
