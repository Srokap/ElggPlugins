<?php
	/**
	 * API Admin language pack.
	 * 
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */


	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'apiadmin' => 'API de Administraci&oacute;n',
	
	
			'apiadmin:keyrevoked' => 'API Key revocada',
			'apiadmin:keynotrevoked' => 'API Key no puede ser revocada',
			'apiadmin:generated' => 'API Key generada correctamente',
	
			'apiadmin:yourref' => 'Sus referencias',
			'apiadmin:generate' => 'Generar un par de claves',
	
			'apiadmin:noreference' => 'Debe suministrar una referencia a la nueva clave.',
			'apiadmin:generationfail' => 'Hay un problema a la hora de generar la nuevas claves',
			'apiadmin:generated' => 'Nuevos par de claves generadas correctamente',
	
			'apiadmin:revoke' => 'Clave eliminada',
			'apiadmin:public' => 'Publica',
			'apiadmin:private' => 'Privada',

	
			'item:object:api_key' => 'API de claves',
	);
				
	add_translation("en",$spanish);
?>
