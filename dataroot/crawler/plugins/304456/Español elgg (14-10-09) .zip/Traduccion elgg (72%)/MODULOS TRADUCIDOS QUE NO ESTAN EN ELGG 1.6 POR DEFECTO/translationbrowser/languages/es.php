<?php
	/**
	 * Elgg translation browser.
	 * 
	 * @package translationbrowser
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mariusz Bulkowski
	 * @copyright  2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'translationbrowser' => 'Gestor de traducciones',
			'translationbrowser:save' => 'Guardar',
	
	);
					
	add_translation("es",$spanish);
?>
