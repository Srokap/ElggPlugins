<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'status' => "Estado",
			'status:user' => "Estado de %s",
			'status:current'=> "Estado actual",
			'status:desc'=> "Este componente muestra los &uacute;ltimos estados.",
			'status:posttitle' => "estado de %s: %s",
			'status:everyone' => "Todos los estaods",
			'status:strapline' => "%s",
			'status:addstatus' => "Estableza su estado",
		    'status:messages' => "Estado de los menajes",
			'status:text' => "Estado:",
			'status:set' => "establecer ",
			'status:clear' => "limpiar estado",
			'status:delete' => "eliminar estado",
			'status:nostatus' => "No ha definido estados.",
			'status:viewhistory' => "ver su historial",
	
			'item:object:status' => 'Estado de los mensajes',
	
	
        /**
	     * Status river
	     **/
	        
	        //generic terms to use
	        'status:river:created' => "Actualizados %s",
	        
	        //these get inserted into the river links to take the user to the entity
	        'status:river:create' => "Sus estados.",
	        
	        
	
		/**
		 * Status messages
		 */
	
			'status:posted' => "Su nuevo estado han sido enviados correctamente.",
			'status:deleted' => "Su estado ha sido eliminado correctamente.",
	
		/**
		 * Error messages
		 */
	
			'status:blank' => "Lo lamento, necesita escribir algo en el estado para guardarse.",
			'status:notfound' => "Lo lamento, no podemos encontrar el estado de los mensajes.",
			'status:notdeleted' => "Lo lamento, no podemos eliminar el estado del mensaje.",
			'status:notsaved' => "Algo ha ido mal cari&ntilde;o cuando intent&eacute; guardar, porfavor int&eacute;ntelo de nuevo.",
			'status:problem' => "Hay alg&uacute;n problema. Parece que no puedo editar el estado.",
	
	);

	add_translation("es",$spanish);				

?>
