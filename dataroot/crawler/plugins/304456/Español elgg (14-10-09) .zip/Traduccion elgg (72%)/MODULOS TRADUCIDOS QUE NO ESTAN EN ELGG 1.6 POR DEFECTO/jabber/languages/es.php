<?php

	$spanish = array(
	
		/**
		 * Administration
		 */
	
			'jabber:settings:server' => "Servidor de dominio",
            'jabber:settings:httpbase' => "HTTP Base",
			'jabber:settings:httptype' => "Tipo HTTP",
			'jabber:settings:dbmsengine' => "DBMS Engine",
            'jabber:settings:srvengine' => "Server Engine",
        /**
         * Misc
         */
            'Jabber' => 'Chat'
	
	);
					
	add_translation("es", $spanish);

?>
