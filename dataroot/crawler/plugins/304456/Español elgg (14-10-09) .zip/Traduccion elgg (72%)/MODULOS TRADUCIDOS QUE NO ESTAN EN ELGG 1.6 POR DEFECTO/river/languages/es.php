<?php

	$spanish = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'No podemos encontrar ninguna actividad.',
		'river:widget:title' => "Actividad",
		'river:widget:description' => "Mostrar las &uacute;ltimas actividades.",
		'river:widget:title:friends' => "Actividad de los amig@s",
		'river:widget:description:friends' => "Mostrar lo que los amig@s dicen.",
	
		'river:widget:label:displaynum' => "N&uacute;mero de entradas a mostrar:",
	);
	add_translation("es",$spanish);					

?>
