<?php
	/**
	 * Elgg pages plugin language pack
	 * 
	 * @package ElggPages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
			
			'groupblog' => "Blog de la comunidad",
			'groupblogs' => "Blogs comunidad",
			'groupblog:user' => "env&iacute;os de la comunidad de %s",
			'groupblog:your' => "Su env&iacute;os de la comunidad",
			'groupblog:group' => "blogs de la comunidad de %s",
			'groupblog:new' => "Nuevo env&iacute;o de la comunidad",
			'groupblog:groupprofile' => "Blogs de la comunidad",
			'groupblog:edit' => "Edita este blog",
			'groupblog:delete' => "Elimina este blog",
			'groupblog:history' => "Historial de blog",
			'groupblog:view' => "Ver blog",
			

			'groupblog:posttitle' => "blog de %s: %s",
			'groupblog:everyone' => "Todos los blogs de la comunidad",
	
			'groupblog:read' => "Leer blog",
	
			'groupblog:addpost' => "Mandar un mensaje al blog",
			'groupblog:editpost' => "Editar el mensaje del blogs",

			'groupblog:text' => "Texto",
	
			'groupblog:strapline' => "%s",
			
			'item:object:groupblog' => 'Blogs de la comunidad',
	
			
         /**
	     * Blog river
	     **/
	        
	        //generic terms to use
	        'groupblog:river:created' => "Escrito en %s",
	        'groupblog:river:updated' => "actualizado en %s",
	        'groupblog:river:posted' => "enviado a %s",
	        
	        //these get inserted into the river links to take the user to the entity
	        'groupblog:river:create' => "un nuevo envio al blogs.",
	        'groupblog:river:update' => "un env&iacute;o al blog.",
	        'groupblog:river:annotate:create' => "un comentaro en el blogs.",
			
	
		/**
		 * Status messages
		 */
	
			'groupblog:posted' => "Su env&iacute;o al blog ha sido correcto±.",
			'groupblog:deleted' => "Su env&iacute;o al blog ha sido eliminado correctamente.",
	
		/**
		 * Error messages
		 */
	
			'groupblog:save:failure' => "Su env&iacute;o al blog no hay podido guardarse. Int&eacute;ntelo de nuevo.",
			'groupblog:blank' => "Lo lamento, necesita rellenar los campos antes de enviarlo.",
			'groupblog:notfound' => "Lo lamento, no podemos encontrar el env&iacute;o de ese blog.",
			'groupblog:notdeleted' => "Lo lamento, no pudemos eliminar ese env&iacute;o del blog.",
			
	);
					
	add_translation("es",$spanish);
?>
