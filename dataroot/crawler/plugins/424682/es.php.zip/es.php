<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/gpl.html GNU Public License version 3
* @author Ivan Vergés <ivan@microstudi.net>
* @copyright Ivan Vergés 2010
* @link http://microstudi.net/elgg/
* @traslate Carlos L. Sánchez Bocanegra
**/

$spanish = array(
    'kalturavideo:label:partner_id' => "Id Partner",
    'kalturavideo:error:misconfigured' => "Componente no configurado o error en autenticación con kaltura!",
    'kalturavideo:error:notconfigured' => "El componente no ha sido configurado!",
    'kalturavideo:error:missingks' => 'Probablemente tenga un error en la configuración de la clave Administradora ("Administator Secret") o la clave de servicio web ("Web Service Secret").',
    'kalturavideo:error:partnerid' => "Este error aparece normalmente si no eres un partner de Kaltura. Por favor lea el fichero READM y la configuración del componente!",
    'kalturavideo:error:readme' => "Lea el fichero README y configure el compoente, por favor",
    'kalturavideo:label:closewindow' => "Cerrar ventana",
    'kalturavideo:label:select_size' => "Seleccione dimensió del reproductor",
    'kalturavideo:label:large' => "Grande",
    'kalturavideo:label:small' => "Pequeño",
    'kalturavideo:label:insert' => "Inserte video",
    'kalturavideo:label:edit' => "Edite video",
    'kalturavideo:label:edittitle' => "Edite título del video",
    'kalturavideo:label:miniinsert' => "Insertar",
    'kalturavideo:label:miniedit' => "Editar",
    'kalturavideo:label:cancel' => "Cancelar",
    'kalturavideo:label:gallery' => "Galería",
    'kalturavideo:label:next' => "Siguiente",
    'kalturavideo:label:prev' => "Anterior",
    'kalturavideo:label:start' => "Inicio",
    'kalturavideo:label:newvideo' => "Crear un nuevo vídeo",
    'kalturavideo:label:gotoconfig' => "Configure adecuadamente el componente Kaltura Video, por favor ",

    //title of the menu, put whatever you want, for example 'Kaltura videos'
    'kalturavideo:label:adminvideos' => "Vídeo colaborativo",
    'kalturavideo:label:myvideos' => "Mis videos",
    'kalturavideo:label:length' => "Longitud:",
    'kalturavideo:label:plays' => "Reproduciones:",
    'kalturavideo:label:created' => "Creaado:",
    'kalturavideo:label:details' => "Ver detalles",
    'kalturavideo:label:view' => "Ver video",
    'kalturavideo:label:delete' => "Borrar video",
    'kalturavideo:prompt:delete' => "¿Está seguro de borrar este vídeo?",
    'kalturavideo:action:deleteok' => "El vídeo id %ID% ha sido borrado.",
    'kalturavideo:action:deleteko' => "El vídeo id %ID% no puede ser borrado",
    'kalturavideo:action:updatedok' => "El vídeo id %ID% ha sido actualizado",
    'kalturavideo:action:updatedko' => "El vídeo id %ID% no puede ser actualizado",
    'kalturavideo:label:thumbnail' => "Url preview:",
    'kalturavideo:label:sharel' => "Código HTML para compartir (applet grande):",
    'kalturavideo:label:sharem' => "Código HTML para compartir (applet pequeño):",
    'kalturavideo:text:statusnotchanged' => "El estado de la privacidad para el vídeo %1% no puede ser cambiado",
    'kalturavideo:text:novideos' => "Lo lamento, no tiene aun vídeos",
    'kalturavideo:text:nopublicvideos' => "Lo lamento, no hay vídeos públicos",
    'kalturavideo:label:author' => "Autor:",
    'kalturavideo:text:nofriendsvideos' => "Lo lamento, no hay vídeos de amigos",
    'kalturavideo:text:nouservideos' => "Lo lamento, no hay vídeos para este usuario",
    'kalturavideo:label:showvideo' => "Mostrar el vídeo",
    'kalturavideo:show:advoptions' => "Mostrar",
    'kalturavideo:hide:advoptions' => "Ocultar",

    'kalturavideo:text:widgetdesc' => "Este componente permite mostrar automáticamente las últimas pulbicaciones desde el compomente de Kaltura.",
    'kalturavideo:error:edittitle' => "Error! Este título no puede ser cambiado",
    'kalturavideo:error:objectnotavailable' => "Objecto no disponible, por favor recarge la página.",
    'kalturavideo:label:recreateobjects' => "Volver a crear todos los videos",
    'kalturavideo:edit:notallowed' => "No puede editar este vídeo",
    'kalturavideo:river:created' => "%s creado",
    'kalturavideo:river:annotate' => "%s commentado",
    'kalturavideo:river:item' => "un vídeo",
    'kalturavideo:river:shared' => "Vídeo colaborativo",
    'kalturavideo:label:videosfrom' => "Videos por %s",
    'kalturavideo:user:showallvideos' => "Mostrar todos los vídeos para este usuario",
    'kalturavideo:strapline' => "%s",

     /**
     * kaltura_video rating system
     **/
    'kalturavideo:rating' => "Votaciones",
    'kalturavideo:yourrate' => "Tus votaciones:",
    'kalturavideo:rate' => "Vota!",
    'kalturavideo:votes' => "votos",
    'kalturavideo:ratesucces' => "Sus votos ha sido guardados.",
    'kalturavideo:rateempty' => "Por favor selecciones un valor antes de votar",
    'kalturavideo:notrated' => "Ya ha votado este artículo",

    /**
     * Groups
     **/
    'kalturavideo:groupprofile' => "Vídeos colaborativos",
    'kalturavideo:text:nogroupvideos' => "Lo lamento, no hay vídeos para este grupo",
    'kalturavideo:label:collaborative' => "Colaborativo",
    'kalturavideo:text:collaborative' => "Esto permite a otros miembors de este grupo para editar el vídeo",
    'kalturavideo:text:collaborativechanged' => "Estado de colaboración para el vídeo %1% cambiado",
    'kalturavideo:text:collaborativenotchanged' => "Estado de colaboración para el vídeo %1% no puede ser cambiado",
    'kalturavideo:text:iscollaborative' => "Esto es un vídeo colaborativo, puede editarlo",
    'kalturavideo:userprofile' => "Vídeos colaborativos",

    //New after version 1.0

    //default title for a new created video, you can put 'New video' for example
    'kalturavideo:title:video' => "Nuevo vídeo colaborativo",
    //elgg notification
    'kalturavideo:newvideo' => "Nuevo vídeo colaborativo",

    'kalturavideo:label:friendsvideos' => "Vídeos de los amigos",
    'kalturavideo:label:allgroupvideos' => "Vídeos de los grupos",
    'kalturavideo:label:allvideos' => "Todos los vídeos",
    'kalturavideo:clickifpartner' => "Pulse aquí si todavia tiene un Partner ID",
    'kalturavideo:clickifnewpartner' => "Pulse aquí si no tiene Partner ID",
    'kalturavideo:notpartner' => "Es un usuario de Kaltura?",
    'kalturavideo:forgotpassword' => "¿Olvidó su contraseña?",
    'kalturavideo:enterkmcdata' => "Por favor introduzca el correo de Kaltura Management Console (KMC) y su clave",
    'kalturavideo:label:sitename' => "Nombre del lugar",
    'kalturavideo:label:name' => "Introduzca nombre",
    'kalturavideo:label:email' => "Introduzca email",
    'kalturavideo:label:websiteurl' => "URL",
    'kalturavideo:label:description' => "Descripción",
    'kalturavideo:label:phonenumber' => "Teléfono",
    'kalturavideo:label:contenttype' => "Tipo de documento",
    'kalturavideo:label:adultcontent' => "¿Es un contenido para adultos?",
    'kalturavideo:label:iagree' => "Acepto %s",
    'kalturavideo:label:termsofuse' => "Términos y uso",
    'kalturavideo:wizard:description' => "Por favor describa para qué usara la plataforma de vídeo de Kaltura",
    'kalturavideo:wizard:phonenumber' => "Introduzca el teléfono del contacto",
    'kalturavideo:mustaggreeterms' => "Debe estar de acuerdo con los Términos y uso de Kaltura",
    'kalturavideo:mustenterfields' => "Debe completar todos los campos!",
    'kalturavideo:registeredok' => "El servidor de Kaltura se han registrado y conectado correctamente",
    'kalturavideo:error:noid' => "El objeto solicitado no está disponible",
    'kalturavideo:logintokaltura' => "%s a Kaltura Management Console (KMC) para la gestión avanzada de vídeos",
    'kalturavideo:login' => "Logarse",
    'kalturavideo:text:nogroupsvideos' => "Lo lamento, no hay vídeos para este grupo",
    'kalturavideo:label:defaultplayer' => "Reproductor de vídeo por defecto",
    'kalturavideo:editpassword' => "Pulse para cambiar la fecha",
    'kalturavideo:text:recreateobjects' => "Intente hacer esto, si está actualizado el componente Kaltura de una versión anterior a 1.0 o algunos vídeos han sido eliminados fuera de la instalación del Elgg.
     Todos los vídeos serán chequeados y vueltos a crear, esto será un proceso lento.

Note que el metadata guardado en el servidor de Kaltura será actualizado en el orde de encontrar los datos de Elgg.
Los objetos no creados con el componente de Kaltura Elgg no será conectados",
    'kalturavideo:text:statuschanged' => 'Estado de acceso para el vídeo %2% cambiado a "%1%"',
    'kalturavideo:howtoimportkaltura' => 'Puede importar un vídeo del CMS de Kaltura creado fuera de Elgg, para hacer el login en la cuenta CMS Kaltura (%URLCMS%) y ponga el tag admin en "<b>%TAG%</b> <em> elgg_username_to_import</em>". Entonces inicie "Volver a crear todos los vídeos" de nuevo.',
    'kalturavideo:num_display' => "Número de vídeos a mostrar",
    'kalturavideo:start_display' => "Iniciar con el número",
    'kalturavideo:label:addvideo' => "Incrustar vídeo",
    'kalturavideo:label:addbuttonlongtext' => "Añadir el botón %s al textarea",
    'kalturavideo:option:simple' => "Simple (un botón en lo alto de un textarea)",
    'kalturavideo:option:tinymce' => "Intentar integrarlo al tinyMCE",
    'kalturavideo:note:addbuttonlongtext' => "Si elige añadir este botón, el usuario puede poner tag html &lt;object&gt; en el text boxes. Incluso si el compomente htmlawed está habilitado.",
    'kalturavideo:enablevideo' => "Habilita el video colaborativo para este grupo",
    'kalturavideo:label:groupvideos' => "Vídeos de grupo",
    'kalturavideo:user' => "Vídeos de %s",
    'kalturavideo:user:friends' => "Vídeos de los amigos de %s",
    'kalturavideo:notfound' => "Lo lamento, no podriamos encontrar el video especificado. ",
    'kalturavideo:posttitle' => "Vídeo de %s: %s",
    'kalturavideo:label:editdetails' => "Editar el título &amp; descripción",
    'ingroup' => "en grupo",

    //new from 10-12-2009
    'item:object:kaltura_video' => "Vídeos colaborativos",
    'kalturavideo:thumbnail' => "Preview",
    'kalturavideo:comments:allow' => "Permitir comentarios",
    'kalturavideo:rating:allow' => "Permitir votos",
    //these get inserted into the river links to take the user to the entity
    'kalturavideo:river:updated' => "%s actualizados",
    'kalturavideo:river:create' => "título del nuevo vídeo",
    'kalturavideo:river:update' => "títular un vídeo",
    //the river search the translation with the object label (kaltura_video)
    'kaltura_video:river:annotate' => "comentario de este vídeo",
    'kalturavideo:river:rates' => "%s votó por este vídeo",
    //widget title label
    'kalturavideo:label:latest' => "Últimos videos",
    //widget options
    'kalturavideo:showmode' => "Modo de listado",
    'kalturavideo:showmode:thumbnail' => "Lista preview",
    'kalturavideo:showmode:embed' => "Incorporar mini-reproductor",
    'kalturavideo:label:morevideos' => "Más vídeos",
    'kalturavideo:more' => "Más",
    //donate button in tools administrations
    'kalturavideo:note:donate' => "¿Le gusta este componente? Por favor considere una donación.",
    //new from  11-21-2009
    'kalturavideo:error:curl' => "Extension CURL no está cargada\nPor favor asegúrese que está disponible esta extension para poder usar el componente\nPor favor lea el README para más información.",

    //new from version 1.1
    'kalturavideo:menu:server' => "Servidor",
    'kalturavideo:menu:custom' => "Reproductor &amp; Editor",
    'kalturavideo:menu:behavior' => "Comportamiento del componente",
    'kalturavideo:menu:advanced' => "Advanzado",
    'kalturavideo:menu:credits' => "Créditos",
    'kalturavideo:admin' => "Administración de vídeos Kaltura",
    'kalturavideo:admin:serverpart' => "Servidor de Streaming",
    'kalturavideo:admin:partnerpart' => "Configuración del ID Partner",
    'kalturavideo:admin:wizardpart' => "Registro de vídeos de la plataforma Kaltura",
    'kalturavideo:admin:player' => "Opciones del reproductor de vídeo online",
    'kalturavideo:admin:editor' => "Opciones del editor de vídeo online",
    'kalturavideo:admin:textareas' => "Integración en Textareas",
    'kalturavideo:admin:credits' => "Créditos",
    'kalturavideo:admin:suport' => "Soporte",

    'kalturavideo:server:info' => "Para usar la plataforma de kaltura, necesita tener un Id Partnet con el Servidor de Kaltura",
    'kalturavideo:server:type' => "Elija el servidor Kaltura",
    'kalturavideo:server:kalturacorp' => "Edición hospedada en Kaltura.com",
    'kalturavideo:server:kalturace' => "Edición Kaltura Community (CE)",
    'kalturavideo:server:corpinfo' => "Registrando con el editor hospedado en Kaltura.com, a través de una cuenta de prueba.
Su cuenta de prueba incluye 10GB de hosting y streaming.",
    'kalturavideo:server:ceinfo' => "Kaltura Community Edition es un hosting propio, la community soporta versiones de la plataforma de video de Kaltura Open Soruce",
    'kalturavideo:server:moreinfo' => "Encontrar más información acerca de",
    'kalturavideo:server:ceurl' => "Url del servidor Kaltura CE",
    'kalturavideo:server:alertchange' => "Precaución: cambiando los datos podría perder los vídeos!
¿Está seguro?
Probablemente quiera volver a crear los objetos después de esta acción.",
    'kalturavideo:wizard:cannot' => "No puede usar esta página con su configuración actual!",
    'kalturavideo:advanced:recreateobjects' => "Estoy de acuerdo, por favor vuelva a crear todos los vídeos ahora!",
    'kalturavideo:recreate:initiating' => "Recogiendo información del servidor de Kaltura...",
    'kalturavideo:recreate:stepof' => "Recogiendo vídeos (paso %NUM% de %TOTAL%)...",
    'kalturavideo:recreate:processedvideos' => "Vídeos procesados %NUMRANGE% de %TOTAL%...",
    'kalturavideo:recreate:done' => "Todos los vídeos correctamente procesados",
    'kalturavideo:recreate:donewitherrors' => "Vídeos procesados con errores!",
    'kalturavideo:changeplayer' => "Aquí puede cambiar el reproductor por defecto por uno nuevo creado (los antigüos vídeos no serán afectados).",
    'kalturavideo:generic' => "Genérico",
    'kalturavideo:customplayer' => "Mi reproductor personalizado",
    'kalturavideo:customkcw' => "Mi propia contribución",
    'kalturavideo:customeditor' => "Mi editor propior",
    'kalturavideo:uiconf1' => "Id de la aplicación Studio de Kaltura",
    'kalturavideo:text:uiconf1' => '% a la Kaltura Management Console (KMC) para crear tu propio reproductor.<br />
Con su propio reproductor, puede cambiar el tamaño por defecto además de muchas otras opciones.<br />
Los reproductores por personalizados están definidos en el sub-menú "Application Studio" en KMC',
    'kalturavideo:uiconf2' => "Id de Ayudante Kaltura Contribution (KCW)",
    'kalturavideo:uiconf3' => "Editor ID de Kaltura (KSE)",
    'kalturavideo:error:uiconf1' => "Error! Id reproductor erróneo .",
    'kalturavideo:error:uiconf2' => "Error! Id KCW erróneo.",
    'kalturavideo:error:uiconf3' => "Error! Id KSE erróneo.",
    'kalturavideo:uiconf:getlist' => "Conseguir una lista de ellos",
    'kalturavideo:uiconf1:notfound' => "No se han encontrado reproductores personalizados!",
    'kalturavideo:uiconf2:notfound' => "No se ha encontrado KCW personalizado!",
    'kalturavideo:uiconf3:notfound' => "No se ha encontrado KSE personalizado!",
    'kalturavideo:playerupdated' => "Opciones de reproductor &amp; editor actualizadas exitosamente.",
    'kalturavideo:label:defaulteditor' => "Editor de vídeo por defecto",
    'kalturavideo:editor:light' => "Esquema editor en color brillante",
    'kalturavideo:editor:dark' => "Esquema editor en color oscuro",
    'kalturavideo:label:defaultkcw' => "Carga por defector (Ayudante)",
    'kalturavideo:kcw:light' => "Carga de esquema en color brillante",
    'kalturavideo:kcw:dark' => "Carga de esquema en color oscuro",

    'kalturavideo:admin:videoeditor' => "Editor de vídeo",
    'kalturavideo:admin:rating' => "Votos del video",

    'kalturavideo:behavior:alloweditor' => "Permitir a los usuaros editar este vídeo",
    'kalturavideo:alloweditor:full' => "Sí, mostrar la carga y después el edotir cuando creo el vídeo",
    'kalturavideo:alloweditor:simple' => "Sí, pero no mostrar el editor cuando creo un vídeo (los usuarios puede editarlo después)",
    'kalturavideo:alloweditor:no' => "No, no permitir editar vídeos",
    'kalturavideo:alloweditor:notallowed' => "Edición de vídeos no permitida:w
!",

    'kalturavideo:behavior:enablerating' => "Hbilitar el voto de vídeo"
);

add_translation("es", $spanish);

?>