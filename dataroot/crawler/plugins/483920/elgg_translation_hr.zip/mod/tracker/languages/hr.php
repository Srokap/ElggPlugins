<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'tracker:title'  =>  "Članovi sa IP adresom:%s" , 
	 'tracker:find'  =>  "Pronađi druge s istom IP adresom" , 
	 'tracker:moreinfo'  =>  "Nabavite proširene informacije o IP adresi" , 
	 'tracker:info'  =>  "Informacija" , 
	 'tracker:searchip'  =>  "Pronađi IP adresu" , 
	 'tracker:search:info'  =>  "Proširena informacija o IP" , 
	 'tracker:adminlink'  =>  "Provjeri IP adresu" , 
	 'tracker:settings'  =>  "Postavke tragača" , 
	 'tracker:display'  =>  "Gdje će biti prikazana IP adresa?" , 
	 'tracker:display:profile'  =>  "U profilima" , 
	 'tracker:display:adminmenu'  =>  "U administracija" , 
	 'tracker:url'  =>  "URL za IP traganje" , 
	 'tracker:url:help'  =>  "URL za alternativne sajtove za traganje, koristite %s za prikaz gdje treba biti IP adresa."
); 

add_translation('hr', $croatian); 

?>