<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'twitterservice'  =>  "Twitter servis" , 
	 'twitterservice:postwire'  =>  "Postavljajući sljedeću opciju sve poruke koje postavite na status će biti poslane na Vaš twitter račun.Da li želite slati statusne poruke na twitter?" , 
	 'twitterservice:twittername'  =>  "Twitter korisničko ime" , 
	 'twitterservice:twitterpass'  =>  "Twitter lozinka"
); 

add_translation('hr', $croatian); 

?>