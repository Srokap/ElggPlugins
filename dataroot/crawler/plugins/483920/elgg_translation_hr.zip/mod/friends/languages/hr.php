<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'friends:widget:description'  =>  "Prikazuje Vaše prijatelje."
); 

add_translation('hr', $croatian); 

?>