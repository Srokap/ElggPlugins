<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'avatar_wall'  =>  "Zid avatara" , 
	 'avatar_wall:title'  =>  "Zid avatara" , 
	 'avatar_wall:shorttitle'  =>  "Zid avatara" , 
	 'avatar_wall:description'  =>  "Zid avatara prikazuje sve korisnike sa avatarima na jednoj stranici" , 
	 'avatar_wall:settings:onlywithavatar'  =>  "Prikaži samo korisnike sa prilagođenim avatarom" , 
	 'avatar_wall:settings:tiny'  =>  "Sićušno" , 
	 'avatar_wall:settings:small'  =>  "Malo" , 
	 'avatar_wall:settings:iconsize'  =>  "Odabir veličine ikone" , 
	 'avatar_wall:settings:maxicons'  =>  "Odaberite maksimalan broj ikona na zidu"
); 

add_translation('hr', $croatian); 

?>