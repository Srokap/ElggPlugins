<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'logbrowser'  =>  "Pretraživač logova" , 
	 'logbrowser:browse'  =>  "Pretraži sistemski log" , 
	 'logbrowser:explore'  =>  "Pretraži log" , 
	 'logbrowser:search'  =>  "Filtriraj rezultate" , 
	 'logbrowser:user'  =>  "Korisničko ime za pretraživanje po" , 
	 'logbrowser:starttime'  =>  "Početno vrijeme (na primjer \"zadnji ponedjeljak\", \"prije 1 sat\")" , 
	 'logbrowser:endtime'  =>  "Krajnje vrijeme"
); 

add_translation('hr', $croatian); 

?>