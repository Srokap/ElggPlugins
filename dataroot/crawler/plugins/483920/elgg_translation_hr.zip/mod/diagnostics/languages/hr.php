<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'diagnostics'  =>  "Dijagnostika sistema" , 
	 'diagnostics:unittester'  =>  "Testovi jedinica" , 
	 'diagnostics:unittester:description'  =>  "Test jedinica provjerava Elgg jezgru u potrazi za pokvarenim ili bugovitim APIjima" , 
	 'diagnostics:unittester:debug'  =>  "Sajt mora biti u debug modu za pokretanje testova jedinice." , 
	 'diagnostics:test:executetest'  =>  "Izvrši test" , 
	 'diagnostics:test:executeall'  =>  "Izvrši sve" , 
	 'diagnostics:unittester:testresult:fail'  =>  "NIJE USPJELO" , 
	 'diagnostics:unittester:testresult:success'  =>  "USPJEŠNO" , 
	 'diagnostics:download'  =>  "Skini .txt" , 
	 'diagnostics:report:globals'  =>  "Globalne varijable:

%s
------------------------------------------------------------------------
------------------------------------------------------------------------" , 
	 'diagnostics:description'  =>  "Sljedeći dijagnostički izvještaj je koristan za dijagnosticiranje problema sa Elgg-om i trebao bi biti zakačen uz svaki bug izvještaj koji napravite." , 
	 'diagnostics:unittester:warning'  =>  "UPOZORENJE:Ovi testovi mogu ostaviti objekte za otkirvanje grešaka u Vašoj bazi podataka.NE KORISTITE NA PRODUKCIJSKOM SAJTU!" , 
	 'diagnostics:unittester:notests'  =>  "Trenutno nema instaliranih test modula." , 
	 'diagnostics:unittester:testnotfound'  =>  "Izvještaj ne može biti napravljen jer test nije pronađen" , 
	 'diagnostics:unittester:testresult:nottestclass'  =>  "NIJE USPJELO - Rezultat nije test klasa" , 
	 'diagnostics:unittester:report'  =>  "Izvještaj testiranja za %s" , 
	 'diagnostics:header'  =>  "========================================================================
Elgg dijagnostički izvještaj
Generisano %s od %s
========================================================================" , 
	 'diagnostics:report:basic'  =>  "
Elgg distribucija %s, verzija %s

------------------------------------------------------------------------" , 
	 'diagnostics:report:php'  =>  "
PHP informacije:
%s
------------------------------------------------------------------------" , 
	 'diagnostics:report:plugins'  =>  "
Instalirani dodaci i detalji:

%s
----------------------------------------------------------------------------------------" , 
	 'diagnostics:report:md5'  =>  "
Instalirani fajlovi i sume provjere:

%s
------------------------------------------------------------------------" , 
	 'diagnostics:unittest:example'  =>  "Primjer testiranja jedinica, dostupan u debug modu."
); 

add_translation('hr', $croatian); 

?>