<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'bookmarks'  =>  "Oznake" , 
	 'bookmarks:add'  =>  "Dodaj oznaku" , 
	 'bookmarks:read'  =>  "%s oznake" , 
	 'bookmarks:friends'  =>  "Oznake prijatelja" , 
	 'bookmarks:everyone'  =>  "Oznake čitavog sajta" , 
	 'bookmarks:this'  =>  "Označi ovo" , 
	 'bookmarks:this:group'  =>  "Oznaka u %s" , 
	 'bookmarks:more'  =>  "Više" , 
	 'bookmarks:with'  =>  "Dijeli sa" , 
	 'bookmarks:address'  =>  "Adresa resursa koji se želi označiti" , 
	 'bookmarks:delete:confirm'  =>  "Da li ste sigurni da želite obrisati ovaj resurs?" , 
	 'bookmarks:numbertodisplay'  =>  "Broj oznaka za prikazati" , 
	 'bookmarks:shared'  =>  "Označeno" , 
	 'bookmarks:visit'  =>  "Posjeti resurs" , 
	 'bookmarks:recent'  =>  "Nedavne oznake" , 
	 'bookmarks:river:created'  =>  "%s označeno" , 
	 'bookmarks:river:annotate'  =>  "komentar na označeno" , 
	 'bookmarks:river:item'  =>  "stavka" , 
	 'item:object:bookmarks'  =>  "Označeno" , 
	 'bookmarks:group'  =>  "Grupiši oznake" , 
	 'bookmarks:enablebookmarks'  =>  "Uključi oznake grupe" , 
	 'bookmarks:inbox'  =>  "Ulazni spremnik oznaka" , 
	 'bookmarks:shareditem'  =>  "Označena stavka" , 
	 'bookmarks:new'  =>  "Nova oznaka stavke" , 
	 'bookmarks:via'  =>  "preko oznaka" , 
	 'bookmarks:widget:description'  =>  "Ovaj widget je dizajniran za Vašu nadzornu ploču i prikazati će zadnje stavke u Vašem ulaznom spremniku oznaka." , 
	 'bookmarks:bookmarklet:description'  =>  "Bookmarklet Vam omogućava da djelite bilo koji resurs koji nađete na webu sa Vašim prijateljima, ili da sačuvate za sebe.Da biste ga koristili jednostavno prevucite dugme na link bar Vašeg pretraživača:" , 
	 'bookmarks:bookmarklet:descriptionie'  =>  "Ako koristite Internet Explorer, potrebno je kliknuti desnim klikom na bookmarklet ikonu i odabrati \"dodaj u favorite\" i onda u link bar." , 
	 'bookmarks:bookmarklet:description:conclusion'  =>  "Onda možete spremiti bilo koju stranicu koju posjetite klikom na nju bilo kada." , 
	 'bookmarks:save:success'  =>  "Vaša stavka uspješno označena." , 
	 'bookmarks:delete:success'  =>  "Oznak uspješno obrisana." , 
	 'bookmarks:save:failed'  =>  "Vaša oznaka ne može biti spremljena.Pokušajte ponovo." , 
	 'bookmarks:delete:failed'  =>  "Vaša oznaka ne može biti obrisana.Pokušajte ponovo." , 
	 'bookmarks:bookmarklet'  =>  "Uzmi bookmarklet" , 
	 'bookmarks:bookmarklet:group'  =>  "Uzmi grupni bookmarklet"
); 

add_translation('hr', $croatian); 

?>