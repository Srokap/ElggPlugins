<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'custom:bookmarks'  =>  "Zadnje oznake" , 
	 'custom:groups'  =>  "Zadnje grupe" , 
	 'custom:files'  =>  "Zadnji fajlovi" , 
	 'custom:blogs'  =>  "Zadnji postovi" , 
	 'custom:members'  =>  "Najnoviji članovi" , 
	 'custom:nofiles'  =>  "Još uvijek nema fajlova" , 
	 'custom:nogroups'  =>  "Još uvijek nema fajlova"
); 

add_translation('hr', $croatian); 

?>