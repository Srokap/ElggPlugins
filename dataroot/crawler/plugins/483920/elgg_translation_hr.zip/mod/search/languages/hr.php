<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'search:enter_term'  =>  "Upišite pojam za traženje:" , 
	 'search:no_results'  =>  "Nema rezultata." , 
	 'search:matched'  =>  "Pronađeno:" , 
	 'search:results'  =>  "Rezultati za %s" , 
	 'search:no_query'  =>  "Molimo unesite upit za pretraživanje." , 
	 'search:search_error'  =>  "Greška" , 
	 'search:more'  =>  "+%s više %s" , 
	 'search_types:tags'  =>  "Oznake" , 
	 'search_types:comments'  =>  "Komentari" , 
	 'search:comment_on'  =>  "Komentari na \"%s\"" , 
	 'search:unavailable_entity'  =>  "Nedostupan entitet"
); 

add_translation('hr', $croatian); 

?>