<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'email:validate:subject'  =>  "%s molimo da potvrdite svoju email adresu!" , 
	 'email:validate:body'  =>  "Zdravo %s,

Molimo da potvrdite email adresu klikom na link ispod:

%s" , 
	 'email:confirm:success'  =>  "Potvrdili ste Vašu email adresu!" , 
	 'email:validate:success:subject'  =>  "Email potvrđen %s!" , 
	 'email:validate:success:body'  =>  "Zdravo %s,

Čestitamo, uspješno ste potvrdili svoju email adresu." , 
	 'email:confirm:fail'  =>  "Vaša email adresa ne može biti potvrđena..." , 
	 'uservalidationbyemail:registerok'  =>  "Da aktivirate svoj račun molimo da potvrdite svoju email adresu klikom na link koji smo Vam poslali."
); 

add_translation('hr', $croatian); 

?>