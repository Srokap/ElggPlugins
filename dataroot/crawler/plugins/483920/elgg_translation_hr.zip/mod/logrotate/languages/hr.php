<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'logrotate:period'  =>  "Koliko često želite arhivirati sistemski log?" , 
	 'logrotate:weekly'  =>  "Jednom sedmično" , 
	 'logrotate:monthly'  =>  "Jednom mjesečno" , 
	 'logrotate:yearly'  =>  "Jednom godišnje" , 
	 'logrotate:logrotated'  =>  "Log rotiran" , 
	 'logrotate:lognotrotated'  =>  "Greška kod rotacije loga"
); 

add_translation('hr', $croatian); 

?>