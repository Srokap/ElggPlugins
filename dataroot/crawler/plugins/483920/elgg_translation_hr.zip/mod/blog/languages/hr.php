<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'blog'  =>  "Blog" , 
	 'blogs'  =>  "Blogovi" , 
	 'blog:user'  =>  "%s blog" , 
	 'blog:your'  =>  "Vaš blog" , 
	 'blog:everyone'  =>  "Blogovi čitavog sajta" , 
	 'blog:read'  =>  "Pročitaj blog" , 
	 'blog:text'  =>  "Blog tekst" , 
	 'blog:strapline'  =>  "%s" , 
	 'blog:never'  =>  "nikad" , 
	 'blog:comments:allow'  =>  "Dopusti komentare" , 
	 'blog:group'  =>  "Blog grupe" , 
	 'blog:river:created'  =>  "%s napisao/la" , 
	 'blog:user:friends'  =>  "%s prijatelja blog" , 
	 'blog:posttitle'  =>  "%s blog: %s" , 
	 'blog:friends'  =>  "Blogovi prijatelja" , 
	 'blog:yourfriends'  =>  "Zadnji blogovi Vašeg prijatelja" , 
	 'blog:newpost'  =>  "Novi blog post" , 
	 'blog:via'  =>  "preko bloga" , 
	 'blog:addpost'  =>  "Napiši blog post" , 
	 'blog:editpost'  =>  "Uredi blog post" , 
	 'item:object:blog'  =>  "Blog postovi" , 
	 'blog:preview'  =>  "Pregled" , 
	 'blog:draft:save'  =>  "Spremi skicu" , 
	 'blog:preview:description'  =>  "Ovo je pregled bloga koji nije spremljen." , 
	 'blog:preview:description:link'  =>  "Za nstavak uređivanja ili spremanja posta kliknite ovdje." , 
	 'blog:enableblog'  =>  "Uključi grupni blog" , 
	 'blog:river:updated'  =>  "%s ažurirano" , 
	 'blog:river:posted'  =>  "%s postavljeno" , 
	 'blog:river:create'  =>  "novi blog post koji ima naslov" , 
	 'blog:river:update'  =>  "blog post naslov" , 
	 'blog:river:annotate'  =>  "komentar na ovaj blog post" , 
	 'blog:posted'  =>  "Vaš blog post uspješno objavljen." , 
	 'blog:deleted'  =>  "Vaš blog post uspješno obrisan." , 
	 'blog:error'  =>  "Nešto je krenulo po zlu.Pokušajte ponovo." , 
	 'blog:save:failure'  =>  "Vaš blog post ne može biti spremljen.Pokušajte ponovo." , 
	 'blog:blank'  =>  "Morate popuniti naslov i tijelo prije nego možete napraviti post." , 
	 'blog:notfound'  =>  "Nismo mogli pronaći blog post." , 
	 'blog:notdeleted'  =>  "Nismo mogli obrisati ovaj blog post." , 
	 'blog:draft:saved'  =>  "Skiciraj zadnje spremljeno"
); 

add_translation('hr', $croatian); 

?>