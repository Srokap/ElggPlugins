<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'messageboard:viewall'  =>  "Pogledaj sve" , 
	 'messageboard:postit'  =>  "Objavi" , 
	 'messageboard:history:title'  =>  "Historija" , 
	 'messageboard:num_display'  =>  "Broj poruka za prikazati" , 
	 'messageboard:replyon'  =>  "odgovori na" , 
	 'messageboard:history'  =>  "historija" , 
	 'messageboard:failure'  =>  "Neočekivana greška se dogodila prilikom dodavanja poruke.Pokušajte ponovo." , 
	 'messageboard:board'  =>  "Tabla za poruke" , 
	 'messageboard:messageboard'  =>  "tabla za poruke" , 
	 'messageboard:none'  =>  "Još uvijek nema ničega na tabli za poruke" , 
	 'messageboard:desc'  =>  "Ovo je tabla za poruke koju mozete postaviti na profil gdje drugi korisnici mogu komentarisati." , 
	 'messageboard:user'  =>  "%s tabla s porukama" , 
	 'messageboard:river:annotate'  =>  "%s ima novi komentar postavljen na svoju tablu za poruke." , 
	 'messageboard:river:create'  =>  "%s je dodao/la widget tabla za poruke." , 
	 'messageboard:river:update'  =>  "%s ažurirali svoj wiget tabla za poruke." , 
	 'messageboard:river:added'  =>  "%s objavio" , 
	 'messageboard:river:messageboard'  =>  "tabla za poruke" , 
	 'messageboard:posted'  =>  "Uspješno objavljeno na tabli za poruke." , 
	 'messageboard:deleted'  =>  "Uspješno ste obrisali poruku." , 
	 'messageboard:email:subject'  =>  "Imate novi komentar na tabli za poruke!" , 
	 'messageboard:email:body'  =>  "Imate novi komentar na tabli za poruke od %s.Piše:


%s

Da pogledate komentare kliknite ovdje:

%s

Da vidite %s profil kliknite ovdje:

%s

Ne možete odgovoriti na ovaj email." , 
	 'messageboard:blank'  =>  "Morate nešto napisati kako bi mogli spremiti poruku." , 
	 'messageboard:notfound'  =>  "Ne možemo pronaći zadanu stavku." , 
	 'messageboard:notdeleted'  =>  "Ne možemo obrisati ovu poruku." , 
	 'messageboard:somethingwentwrong'  =>  "Nešto je krenulo po zlu kada smo pokušali spremiti Vašu poruku, provjerite da li ste napisali poruku."
); 

add_translation('hr', $croatian); 

?>