<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'item:object:reported_content'  =>  "Prijavljeno" , 
	 'reportedcontent'  =>  "Prijavljeni sadržaj" , 
	 'reportedcontent:this'  =>  "Prijavi ovo" , 
	 'reportedcontent:none'  =>  "Nema prijavljenog sadržaja" , 
	 'reportedcontent:report'  =>  "Prijavi ovo" , 
	 'reportedcontent:title'  =>  "Naslov stranice" , 
	 'reportedcontent:deleted'  =>  "Prijavljeni sadržaj je obrisan" , 
	 'reportedcontent:notdeleted'  =>  "Nismo u mogućnosti obrisati tu prijavu" , 
	 'reportedcontent:delete'  =>  "Obriši" , 
	 'reportedcontent:areyousure'  =>  "Da li ste sigurni da želite obrisati?" , 
	 'reportedcontent:archive'  =>  "Arhiviraj" , 
	 'reportedcontent:archived'  =>  "Prijava arhivirana" , 
	 'reportedcontent:visit'  =>  "Posjeti prijavljeno" , 
	 'reportedcontent:by'  =>  "Prijavio" , 
	 'reportedcontent:objecttitle'  =>  "Naslov objekta" , 
	 'reportedcontent:objecturl'  =>  "Url objekta" , 
	 'reportedcontent:reason'  =>  "Razlog za prijavu" , 
	 'reportedcontent:description'  =>  "Zbog čega prijavljujete?" , 
	 'reportedcontent:address'  =>  "Lokacija" , 
	 'reportedcontent:success'  =>  "Vaša prijava je poslana administratoru sajta" , 
	 'reportedcontent:failing'  =>  "Vaša prijava ne može biti poslana" , 
	 'reportedcontent:moreinfo'  =>  "Više informacija" , 
	 'reportedcontent:failed'  =>  "Izvinjavamo se, pokušaj prijave ovog sadržaja nije uspio." , 
	 'reportedcontent:notarchived'  =>  "Nismo u mogućnosti arhivirati prijavu"
); 

add_translation('hr', $croatian); 

?>