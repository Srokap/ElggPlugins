<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'expages:terms'  =>  "Uslovi" , 
	 'expages:privacy'  =>  "Privatnost" , 
	 'expages:contact'  =>  "Kontakt" , 
	 'expages:nopreview'  =>  "Pregled još nije aktivan." , 
	 'expages:preview'  =>  "Pregled" , 
	 'expages:notset'  =>  "Ova stranica još uvijek nije postavljena." , 
	 'expages:addcontent'  =>  "Ovdje možete dodati sadržaj preko administratorskih alata.Pogledajte link vanjske stranice u admin." , 
	 'expages:deleteerror'  =>  "Dogodila se greška prilikom brisanja stare stranice" , 
	 'expages:error'  =>  "Dogodila se greška, pokušajte ponovo i ako se problem nastavi javljati kontaktirajte administratora" , 
	 'expages'  =>  "Vanjske stranice" , 
	 'expages:frontpage'  =>  "Prva stranica" , 
	 'expages:about'  =>  "O" , 
	 'expages:analytics'  =>  "Analitika" , 
	 'expages:lefthand'  =>  "Informacije na lijevom oknu" , 
	 'expages:righthand'  =>  "Informacije na desnom oknu" , 
	 'item:object:front'  =>  "Stavke prve stranice" , 
	 'expages:posted'  =>  "Vaš post stranice je uspješno objavljen." , 
	 'expages:deleted'  =>  "Vaš post stranice je uspješno obrisan."
); 

add_translation('hr', $croatian); 

?>