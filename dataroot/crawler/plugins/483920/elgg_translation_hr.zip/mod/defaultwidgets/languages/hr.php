<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'item:object:moddefaultwidgets'  =>  "ZadaniWidgeti postavke" , 
	 'defaultwidgets:menu:profile'  =>  "Zadani widgeti profila" , 
	 'defaultwidgets:menu:dashboard'  =>  "Zadani widgeti nadzorne ploče" , 
	 'defaultwidgets:admin:error'  =>  "Greška: Niste prijavljeni kao administrator" , 
	 'defaultwidgets:admin:notfound'  =>  "Greška: Stranica nije pronađena" , 
	 'defaultwidgets:admin:loginfailure'  =>  "Upozorenje: Trenutno niste prijavljeni kao administrator" , 
	 'defaultwidgets:update:success'  =>  "Postavke widgeta spremljene" , 
	 'defaultwidgets:update:failed'  =>  "Greška: postavke nisu spremljene" , 
	 'defaultwidgets:update:noparams'  =>  "Greška: pogrešni parametri forme" , 
	 'defaultwidgets:profile:title'  =>  "Postavi zadane widgete za stranice profila novih korisnika" , 
	 'defaultwidgets:dashboard:title'  =>  "Postavi zadane widgete nadzorne ploče za nove korisnike"
); 

add_translation('hr', $croatian); 

?>