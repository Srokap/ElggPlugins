<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'garbagecollector:period'  =>  "Koliko često treba pokretati Elgg sakupljač smeća?" , 
	 'garbagecollector:weekly'  =>  "Jednom sedmično" , 
	 'garbagecollector:monthly'  =>  "Jednom mjesečno" , 
	 'garbagecollector:yearly'  =>  "Jednom godišnje" , 
	 'garbagecollector'  =>  "SAKUPLJAČ SMEĆA" , 
	 'garbagecollector:done'  =>  "ZAVRŠENO" , 
	 'garbagecollector:optimize'  =>  "Optimiziram %s " , 
	 'garbagecollector:error'  =>  "GREŠKA" , 
	 'garbagecollector:ok'  =>  "U redu" , 
	 'garbagecollector:gc:metastrings'  =>  "Čistim nepovezane meta stringove:"
); 

add_translation('hr', $croatian); 

?>