<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'mine'  =>  "Moje" , 
	 'filter'  =>  "Filter" , 
	 'riverdashboard:useasdashboard'  =>  "Zamjenite zadanu nadzornu ploču sa ovom rijekom aktivnosti?" , 
	 'activity'  =>  "Aktivnost" , 
	 'riverdashboard:recentmembers'  =>  "Nedavni članovi" , 
	 'sitemessages:announcements'  =>  "Najave na sajtu" , 
	 'sitemessages:posted'  =>  "Objavljeno" , 
	 'sitemessages:river:created'  =>  "Administrator sajta %s" , 
	 'sitemessages:river:create'  =>  "objavio novu masovnu poruku sajta" , 
	 'sitemessages:add'  =>  "Dodaj masovnu poruku na stranicu rijeke" , 
	 'sitemessage:deleted'  =>  "Poruka sajta obrisana" , 
	 'sitemessage:error'  =>  "Ne mogu spremiti poruku sajta." , 
	 'river:widget:noactivity'  =>  "Ne možemo pronaći nijednu aktivnost." , 
	 'river:widget:title'  =>  "Aktivnost" , 
	 'river:widget:description'  =>  "Prikaži moju zadnju aktivnost." , 
	 'river:widget:title:friends'  =>  "Prijateljeva aktivnost" , 
	 'river:widget:description:friends'  =>  "Prikaži koji su Vaši prijatelji spremni." , 
	 'river:widgets:friends'  =>  "Prijatelji" , 
	 'river:widgets:mine'  =>  "Moje" , 
	 'river:widget:label:displaynum'  =>  "Broj redova za prikazati:" , 
	 'river:widget:type'  =>  "Koju rijeku aktivnosti želite prikazati? Onu koja prikazuje Vašu aktivnost ili aktivnost Vaših prijatelja?" , 
	 'item:object:sitemessage'  =>  "Poruke sajta" , 
	 'riverdashboard:avataricon'  =>  "Želite li koristiti avatare korisnika ili ikone na toku aktivnosti sajta?" , 
	 'option:icon'  =>  "Ikone" , 
	 'option:avatar'  =>  "Avatari"
); 

add_translation('hr', $croatian); 

?>