<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'friends:invite'  =>  "Pozovi prijatelje" , 
	 'invitefriends:introduction'  =>  "Za pozivanje prijatelja da se pridruže ovoj mreži upišite njihove email adrese ispod (jedna po liniji):" , 
	 'invitefriends:message'  =>  "Upišite poruku koju će dobiti sa pozivnicom:" , 
	 'invitefriends:subject'  =>  "Pozivnica za pridruživanje %s" , 
	 'invitefriends:success'  =>  "Vaši prijatelji su pozvani." , 
	 'invitefriends:email_error'  =>  "Pozivnice su poslane ali sljedeće adrese nisu ispravne: %s" , 
	 'invitefriends:failure'  =>  "Vaši prijatelji ne mogu biti pozvani." , 
	 'invitefriends:message:default'  =>  "
Zdravo,

Želim Vas pozvati da se pridružite mojoj mreži ovdje %s." , 
	 'invitefriends:email'  =>  "
Pozvani ste da se pridružite %s od %s.Poslana Vam je sljedeća poruka:

%s

Da se pridružite kliknite na sljedeći link:

%s

Automatski će biti dodani kao prijatelji kada napravite svoj račun."
); 

add_translation('hr', $croatian); 

?>