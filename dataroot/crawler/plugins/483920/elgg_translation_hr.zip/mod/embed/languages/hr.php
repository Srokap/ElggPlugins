<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'media:insert'  =>  "Postavi / Pošalji medij" , 
	 'embed:instructions'  =>  "Kliknite na bilo koji fajl da ga ugradite u svoj sadržaj." , 
	 'embed:media'  =>  "Ugrađeni medij" , 
	 'upload:media'  =>  "Pošalji medij" , 
	 'embed:file:required'  =>  "Objekti za postavljanje sadržaja nisu pronađeni.Sistemski administrator treba ponovo postaviti dodatak za fajlove."
); 

add_translation('hr', $croatian); 

?>