<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'captcha:entercaptcha'  =>  "Upišite tekst sa slike" , 
	 'captcha:captchafail'  =>  "Tekst koji ste unijeli se ne poklapa sa tekstom na slici."
); 

add_translation('hr', $croatian); 

?>