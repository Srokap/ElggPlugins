<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'members:members'  =>  "Članovi" , 
	 'members:online'  =>  "Trenutno aktivni" , 
	 'members:active'  =>  "korisnici sajta" , 
	 'members:searchtag'  =>  "Pretraga korisnika po oznaci" , 
	 'members:searchname'  =>  "Pretraga korisnika po imenu" , 
	 'members:label:newest'  =>  "Najnoviji" , 
	 'members:label:popular'  =>  "Popularni" , 
	 'members:label:active'  =>  "Aktivni" , 
	 'members:search:name'  =>  "Korisničko ime" , 
	 'members:search:tags'  =>  "Oznake"
); 

add_translation('hr', $croatian); 

?>