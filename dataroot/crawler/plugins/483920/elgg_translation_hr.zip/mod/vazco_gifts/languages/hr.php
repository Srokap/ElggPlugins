<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'vazco_gift:name'  =>  "Ime poklona" , 
	 'vazco_gift:price'  =>  "Cijena (u karma poenima)" , 
	 'vazco_gift:description'  =>  "Opis" , 
	 'vazco_gifts:menu:edit'  =>  "Lista poklona" , 
	 'vazco_gifts:title:list'  =>  "Lista poklona" , 
	 'vazco_gifts:select'  =>  "Odaberite poklon" , 
	 'vazco_gift:select:description'  =>  "Odaberite poklon" , 
	 'vazco_gift:edit:save'  =>  "Spremi postavke poklona" , 
	 'vazco_gifts:gifts'  =>  "Pokloni" , 
	 'vazco_gifts:from'  =>  "Od" , 
	 'vazco_gifts:message'  =>  "Dobili ste poklon od %s:
%s

Poklon je vidljiv na Vašem profilu." , 
	 'vazco_gifts:message:title'  =>  "Dobili ste poklon!" , 
	 'vazco_gifts:menu:upload'  =>  "Postavi nove poklone" , 
	 'vazco_gifts:upload'  =>  "Postavi nove poklone" , 
	 'vazco_gifts:settings:maxfilesize'  =>  "Maksimalna veličina fajla:" , 
	 'vazco_gifts:upload:info'  =>  "Postavite slike poklona u formatima: .jpg, .png, .gif" , 
	 'vazco_gifts:norights'  =>  "Nemate pravo" , 
	 'vazco_gift:delete'  =>  "Obriši" , 
	 'vazco_gift:hidden'  =>  "Postavi poklon kao sakriven" , 
	 'vazco_gifts:saved'  =>  "Pokloni uspješno postavljeni" , 
	 'vazco_gifts:uploadfailed'  =>  "Dogodila se greška kod postavljanja poklona" , 
	 'vazco_gifts:notimage'  =>  "Nije izabrana slika" , 
	 'vazco_gifts:limit'  =>  "Prekoračen limit poklona" , 
	 'vazco_gifts:notdeleted'  =>  "Poklon ne može biti obrisan" , 
	 'vazco_gifts:deleted'  =>  "Poklon uspješno obrisan" , 
	 'vazco_gift:delete:confirm'  =>  "Da li ste sigurni da želite obrisati ovaj poklon?" , 
	 'vazco_gifts:edit:success'  =>  "Postavke uspješno spremljene" , 
	 'vazco_gift:selected'  =>  "Poklon poslan %s" , 
	 'vazco_gift:notselected'  =>  "Ovaj poklon ne može biti poslan." , 
	 'vazco_gifts:nopoints'  =>  "Nemate dovoljno poena da kupite ovaj poklon" , 
	 'vazco_gifts:goldmade'  =>  "Poeni uspješno generisani" , 
	 'vazco_gifts:goldnotmade'  =>  "Greška kod generisanja poena" , 
	 'vazco_gifts:river:selectgift'  =>  "%s primio poklon \"%s\"" , 
	 'vazco_gift:select:clicktochose'  =>  "Kliknite na poklon za prijatelja." , 
	 'vazco_gifts:edit:description'  =>  "Ispod je lista svih dostupnih poklona za korisnike.Poklon mora imati ime i cijenu da bi bio aktivan." , 
	 'vazco_gifts:select:description'  =>  "Kliknite na poklon da ga odaberete.Određena količina karma sredstava će biti uklonjena s Vašeg računa." , 
	 'vazco_gifts:select:description2'  =>  "(Vaši karma poeni će ostati nepromjenjeni.)" , 
	 'vazco_gifts:select:price'  =>  "Cijena (u karma sredstvima):%s" , 
	 'vazco_gifts:makegold'  =>  "Generiši karma sredstva iz karma poena za sve korisnike" , 
	 'vazco_gifts:toosmall'  =>  "Slika mora biti najmanje veličine 200x200 px" , 
	 'vazco_gifts:pricenotnumeric'  =>  "Cijena barem jednog od poklona nije brojčana." , 
	 'vazco_gifts:funds'  =>  "Sredstva" , 
	 'vazco_gifts:funds:num'  =>  "Dostupna sredstva:%s"
); 

add_translation('hr', $croatian); 

?>