<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'thewire'  =>  "Status" , 
	 'thewire:user'  =>  "%s status" , 
	 'thewire:posttitle'  =>  "%s bilješke na status: %s" , 
	 'thewire:everyone'  =>  "Svi postovi statusa" , 
	 'thewire:read'  =>  "Postovi statusa" , 
	 'thewire:strapline'  =>  "%s" , 
	 'thewire:add'  =>  "Objavi na status" , 
	 'thewire:text'  =>  "Bilješka na statusu" , 
	 'thewire:reply'  =>  "Odgovori" , 
	 'thewire:via'  =>  "preko" , 
	 'thewire:wired'  =>  "Objavljeno na statusu" , 
	 'thewire:charleft'  =>  "preostalo karaktera" , 
	 'item:object:thewire'  =>  "Postovi statusa" , 
	 'thewire:notedeleted'  =>  "bilješka obrisana" , 
	 'thewire:doing'  =>  "Šta radite? Recite svima svoj status:" , 
	 'thewire:newpost'  =>  "Novi post na statusu" , 
	 'thewire:addpost'  =>  "Objavi na status" , 
	 'thewire:river:created'  =>  "%s objavio/la" , 
	 'thewire:river:create'  =>  "na statusu." , 
	 'thewire:sitedesc'  =>  "Ovaj widget prikazuje zadnje bilješke sajta objavljene na statusu" , 
	 'thewire:yourdesc'  =>  "Ovaj widget prikazuje zadnje bilješke objavljene na statusu" , 
	 'thewire:friendsdesc'  =>  "Ovaj widget prikazuje Vaše zadnje prijatelje na statusu" , 
	 'thewire:friends'  =>  "Vaši prijatelji na statusu" , 
	 'thewire:num'  =>  "Broj stavki za prikazati" , 
	 'thewire:posted'  =>  "Vaša poruka je uspješno objavljena na statusu." , 
	 'thewire:deleted'  =>  "Vaš status posta uspješno obrisan." , 
	 'thewire:blank'  =>  "Morate nešto napisati kako bismo mogli spremiti." , 
	 'thewire:notfound'  =>  "Ne možemo pronaći zadani post statusa." , 
	 'thewire:notdeleted'  =>  "Ne možemo obrisati ovaj status post." , 
	 'thewire:smsnumber'  =>  "Vaš SMS broj se razlikuje od Vašeg navedenog broja mobilnog (broj mobilnog mora biti podsen na javno, kako bi ga status koristio). Svi brojevi telefona moraju biti u medjuanrodnom formatu." , 
	 'thewire:channelsms'  =>  "Broj na koji se šalje SMS je %s"
); 

add_translation('hr', $croatian); 

?>