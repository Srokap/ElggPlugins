<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'profile_counter'  =>  "Brojač profila" , 
	 'profile_counter:title'  =>  "Brojač profila" , 
	 'profile_counter:shorttitle'  =>  "Brojač profila" , 
	 'profile_counter:stats:title'  =>  "Brojač profila" , 
	 'profile_counter:stats:currentcount'  =>  "Trenutno je Vaš profil pregledan %s puta." , 
	 'profile_counter:stats:reset'  =>  "Resetuj brojač" , 
	 'profile_counter:stats:confirm'  =>  "Da li ste sigurni da želite resetovati Vaš brojač profila?"
); 

add_translation('hr', $croatian); 

?>