<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'categories'  =>  "Kategorije" , 
	 'categories:settings'  =>  "Postavi kategorije sajta" , 
	 'categories:explanation'  =>  "Za postavljanje unaprijed definisanih kategorija na razini sajta koje će biti korištene kroz Vaš sistem, upišite ih ispod, odvojene zarezom.Kompatibilni alati će ih onda prikazati kada korisnik napravi ili uredi sadržaj. " , 
	 'categories:save:success'  =>  "Kategorije sajta uspješno spremljene."
); 

add_translation('hr', $croatian); 

?>