<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'profile'  =>  "Profil" , 
	 'profile:edit:default'  =>  "Izmjeni polja profila" , 
	 'profile:preview'  =>  "Pregled" , 
	 'profile:yours'  =>  "Vaš profil" , 
	 'profile:user'  =>  "%s profil" , 
	 'profile:edit'  =>  "Uredi profil" , 
	 'profile:profilepictureinstructions'  =>  "Slika profila se prikazuje na stranici Vašeg profila.
Možete je uvijek promjeniti.(Prihvaćeni formati:GIF,JPG ili PNG)" , 
	 'profile:icon'  =>  "Slika profila" , 
	 'profile:createicon'  =>  "Napravi svoj avatar" , 
	 'profile:currentavatar'  =>  "Trenutni avatar" , 
	 'profile:createicon:header'  =>  "Slika profila" , 
	 'profile:editdetails'  =>  "Uredi detalje" , 
	 'profile:editicon'  =>  "Uredi ikonu profila" , 
	 'profile:aboutme'  =>  "O meni" , 
	 'profile:description'  =>  "O meni" , 
	 'profile:briefdescription'  =>  "Kratki opis" , 
	 'profile:location'  =>  "Lokacija" , 
	 'profile:skills'  =>  "Vještine" , 
	 'profile:interests'  =>  "Interesovanja" , 
	 'profile:contactemail'  =>  "Kontakt e-mail" , 
	 'profile:phone'  =>  "Telefon" , 
	 'profile:mobile'  =>  "Mobilni telefon" , 
	 'profile:website'  =>  "Sajt" , 
	 'profile:banned'  =>  "Ovaj korisnički račun je suspendovan." , 
	 'profile:deleteduser'  =>  "Obrisani korisnik" , 
	 'profile:river:update'  =>  "%s ažurirao svoj profil" , 
	 'profile:river:iconupdate'  =>  "%s ažurirali svoju ikonu profila" , 
	 'profile:label'  =>  "Oznaka profila" , 
	 'profile:type'  =>  "Tip profila" , 
	 'profile:editdefault:fail'  =>  "Zadani profil nije spremljen" , 
	 'profile:editdefault:success'  =>  "Uspješno dodano na zadani profil" , 
	 'profile:editdefault:delete:success'  =>  "Predmet zadanog profila obrisan!" , 
	 'profile:defaultprofile:reset'  =>  "Reset zadanog sistemskog profila" , 
	 'profile:resetdefault'  =>  "Resetuj zadani profil" , 
	 'profile:saved'  =>  "Vaš profil je spremljen." , 
	 'profile:icon:uploaded'  =>  "Slika profila uspješno postavljena." , 
	 'profile:noaccess'  =>  "Nemate dozvole za uređivanje ovog profila." , 
	 'profile:notfound'  =>  "Nismo mogli naći zadani profil." , 
	 'profile:icon:notfound'  =>  "Dogodio se problem prilikom postavljanja slike profila." , 
	 'profile:icon:noaccess'  =>  "Ne možete promjeniti ikonu profila" , 
	 'profile:field_too_long'  =>  "Ne možemo spremiti informacije o profilu jer je \"%s\" sekcija preduga." , 
	 'profile:profilepicturecroppingtool'  =>  "Alat za obrezivanje slike profila" , 
	 'profile:editdefault:delete:fail'  =>  "Uklonjeno zadani profil stavke polja nije uspio" , 
	 'profile:explainchangefields'  =>  "Možete zamijeniti postojeća polja profila s vlastitim pomoću donjeg obrasca.Prvo dajte novom polju profila oznaku, na primjer, \"Omiljeni tim\".Zatim je potrebno odabrati tip polja, na primjer, oznake,url,tekst itd.U svakom trenutku možete vratiti na prijašnje postavke." , 
	 'profile:createicon:instructions'  =>  "Kliknite i povucite kvadrat koji će odgovarati djelu slike koji želite isjeći.Pregled isječene slike će se pojaviti u okviru desno.Kada ste zadovoljni sa pregledom kliknite \"Kreiraj avatar\".Ova isječena slika će biti korištena na sajtu kao Vaš avatar."
); 

add_translation('hr', $croatian); 

?>