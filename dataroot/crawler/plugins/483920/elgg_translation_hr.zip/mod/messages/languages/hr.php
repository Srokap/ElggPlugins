<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'messages'  =>  "Poruke" , 
	 'messages:back'  =>  "nazad na poruke" , 
	 'messages:user'  =>  "Vaš inbox" , 
	 'messages:sentMessages'  =>  "Poslane poruke" , 
	 'messages:send'  =>  "Pošalji poruku" , 
	 'messages:sent'  =>  "Poslane poruke" , 
	 'messages:message'  =>  "Poruka" , 
	 'messages:title'  =>  "Naslov" , 
	 'messages:to'  =>  "Prima" , 
	 'messages:from'  =>  "Od" , 
	 'messages:fly'  =>  "Pošalji" , 
	 'messages:sendmessage'  =>  "Pošalji poruku" , 
	 'messages:posttitle'  =>  "%s poruke: %s" , 
	 'messages:inbox'  =>  "Ulazne" , 
	 'messages:replying'  =>  "Odgovaranje na poruku" , 
	 'messages:compose'  =>  "Sastavi poruku" , 
	 'messages:sentmessages'  =>  "Poslane poruke" , 
	 'messages:recent'  =>  "Nedavne poruke" , 
	 'messages:original'  =>  "Originalna poruka" , 
	 'messages:yours'  =>  "Vaša poruka" , 
	 'messages:answer'  =>  "Odgovori" , 
	 'messages:toggle'  =>  "Mjenjaj sve" , 
	 'messages:markread'  =>  "Označi kao pročitano" , 
	 'messages:new'  =>  "Nova poruka" , 
	 'notification:method:site'  =>  "Sajt" , 
	 'messages:error'  =>  "Dogodila se greška priliko spremanja poruke.Pokušajte ponovo." , 
	 'item:object:messages'  =>  "Poruke" , 
	 'messages:posted'  =>  "Poruka uspješno poslana." , 
	 'messages:deleted'  =>  "Poruke uspješno obrisane." , 
	 'messages:markedread'  =>  "Poruke uspješno označene kao pročitane." , 
	 'messages:email:subject'  =>  "Imate novu poruku!" , 
	 'messages:email:body'  =>  "Imate novu poruku od %s.Sadržaj:

%s

Da pogledate poruku kliknite ovdje:

%s

Da pošaljete poruku kliknite ovdje:

%s

Ne možete odgovoriti na ovaj mail." , 
	 'messages:blank'  =>  "Morate nešto napisati u tijelo poruke da bi je mogli spremiti." , 
	 'messages:notfound'  =>  "Ne možemo pronaći zadanu poruku." , 
	 'messages:notdeleted'  =>  "Ne možemo obrisati ovu poruku." , 
	 'messages:nopermission'  =>  "Nemate dozvolu da promjenite poruku." , 
	 'messages:nomessages'  =>  "Nema poruka za prikazati." , 
	 'messages:user:nonexist'  =>  "Ne možemo pronaći primaoca u bazi podataka." , 
	 'messages:user:blank'  =>  "Niste nikoga odabrali kome šaljete."
); 

add_translation('hr', $croatian); 

?>