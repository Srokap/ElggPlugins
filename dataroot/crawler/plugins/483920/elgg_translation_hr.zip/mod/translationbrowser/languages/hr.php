<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'translationbrowser'  =>  "Pretraživač prevoda" , 
	 'translationbrowser:translate'  =>  "Prevedi" , 
	 'translationbrowser:exporttranslations'  =>  "Izvezi prevode" , 
	 'translationbrowser:selectlanguage'  =>  "Odaberi jezik" , 
	 'translationbrowser:selecttypeexport'  =>  "Odaberite tip izvoza" , 
	 'translationbrowser:languagebase'  =>  "Baza jezika" , 
	 'translationbrowser:yourselectedlanguage'  =>  "Vaš odabrani jezik" , 
	 'translationbrowser:youwilltranslate'  =>  "Prevodite sa" , 
	 'translationbrowser:to'  =>  "na" , 
	 'translationbrowser:languagecore'  =>  "- Sistemski jezik" , 
	 'translationbrowser:selectmodule'  =>  "Odaberite modul koji želite prevoditi i onda kliknite na dugme \"Prevedi\"." , 
	 'translationbrowser:updatefile'  =>  "Interno ažuriranje fajla" , 
	 'translationbrowser:generatefile'  =>  "Pravljenje php fajla" , 
	 'translationbrowser:highlight'  =>  "Istakni polja bez prevoda" , 
	 'translationbrowser:canyouedit'  =>  "možete uređivati vrijednost polja" , 
	 'translationbrowser:blankmodule'  =>  "Morate odabrati najmanje jedan modul" , 
	 'translationbrowser:languageerror'  =>  "Odabrani jezik je netačan.Pokušajte ponovo ili odaberite drugi jezik." , 
	 'translationbrowser:blanklang'  =>  "Morate odabrati najmanje jedan jezik" , 
	 'translationbrowser:emptyfields'  =>  "Morate završiti najmanje jedno polje" , 
	 'translationbrowser:error'  =>  "Interna greška.Pokušajte kasnije" , 
	 'translationbrowser:problem:permiss'  =>  "Dogodila se greška prilikom pristupanja folderu.Provjerite privilegije" , 
	 'translationbrowser:error:filecreate'  =>  "Dogodila se greška prilikom pravljenja fajla.Provjerite privilegije" , 
	 'translationbrowser:success'  =>  "Uspješno prevedeno" , 
	 'translationbrowser:generatedby'  =>  "Generisano sa pretraživač prevoda" , 
	 'translationbrowser:save'  =>  "Prevedi" , 
	 'translationbrowser:downloadallinzip'  =>  "Skini sve u zip" , 
	 'translationbrowser:userscanedit'  =>  "Korisnici mogu uređivati" , 
	 'translationbrowser:exportdescription'  =>  "Ako želite izvoz prevoda odaberite jezik i kliknite na dugme izvezi" , 
	 'translationbrowser:export'  =>  "Izvezi" , 
	 'translationbrowser:infotxt'  =>  "Ovaj fajl je napravljen sa Translation Browser Elgg
@autor Mariusz Bulkowski http://seo4you.pl/
@autor v2 Pedro Prez http://www.pedroprez.com.ar/"
); 

add_translation('hr', $croatian); 

?>