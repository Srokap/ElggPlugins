<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'tinymce:remove'  =>  "Dodaj/Ukloni uređivač"
); 

add_translation('hr', $croatian); 

?>