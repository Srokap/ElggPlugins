<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'izapProfileVisitor:Widget'  =>  "Posjetitelji profila" , 
	 'izapProfileVisitor:WidgetDescription'  =>  "Ovaj widget prikazuje ko je posjetio Vaš profil." , 
	 'izapProfileVisitor:NumberOfVisitors'  =>  "Posjetioce za prikazati" , 
	 'izapProfileVisitor:NoVisits'  =>  ":( Još uvijek me niko nije posjetio"
); 

add_translation('hr', $croatian); 

?>