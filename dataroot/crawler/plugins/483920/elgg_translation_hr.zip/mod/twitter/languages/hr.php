<?php

// Generate By translationbrowser. 

$croatian = array( 
	 'twitter:username'  =>  "Upišite Vaše twitter korisničko ime." , 
	 'twitter:num'  =>  "Broj tweetova za prikazati." , 
	 'twitter:visit'  =>  "posjeti moj twitter" , 
	 'twitter:river:created'  =>  "%s dodao twitter widget" , 
	 'twitter:river:updated'  =>  "%s ažurirali svoj twitter widget." , 
	 'twitter:river:delete'  =>  "%s uklonili svoj twitter widget." , 
	 'twitter:notset'  =>  "Ovaj Twitter widget nije spreman.Za prikaz zadnjih tweetova kliknite na Uredi i popunite detalje"
); 

add_translation('hr', $croatian); 

?>