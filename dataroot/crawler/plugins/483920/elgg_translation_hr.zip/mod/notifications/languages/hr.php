<?php

// Generisano sa pretraživač prevoda 

$croatian = array( 
	 'friends:all'  =>  "Svi prijatelji" , 
	 'notifications:subscriptions:personal:description'  =>  "Primi obavjesti kada su određene radnje provedene na Vašem sadržaju" , 
	 'notifications:subscriptions:personal:title'  =>  "Lične obavjesti" , 
	 'notifications:subscriptions:changesettings'  =>  "Obavjesti" , 
	 'notifications:subscriptions:changesettings:groups'  =>  "Grupne obavjesti" , 
	 'notification:method:email'  =>  "Email" , 
	 'notifications:subscriptions:title'  =>  "Obavjesti po korisniku" , 
	 'notifications:subscriptions:collections:edit'  =>  "Za uređivanje kolekcije prijatelja kliknite ovdje." , 
	 'notifications:subscriptions:description'  =>  "Za primanje obavjesti od prijatelja kada naprave novi sadržaj pronađite ih ispod i odaberite metodu obavjesti koju želite koristiti." , 
	 'notifications:subscriptions:groups:description'  =>  "Za primanje obavjesti kada je novi sadržaj dodan u grupu čiji ste član pronađite ispod i odaberite metodu obavjesti koju želite koristiti." , 
	 'notifications:subscriptions:success'  =>  "Postavke obavještavanja su spremljene." , 
	 'notifications:subscriptions:collections:title'  =>  " Promjeni kolekciju prijatelja" , 
	 'notifications:subscriptions:collections:description'  =>  "Da biste promjenili podešavanja za člana Vaše kolekcije prijatelja, koristite ikonice ispod. Ovo će utjecati na odgovarajućeg korisnika u glavnom panelu za podešavanje obavještenja na dnu stranice."
); 

add_translation('hr', $croatian); 

?>