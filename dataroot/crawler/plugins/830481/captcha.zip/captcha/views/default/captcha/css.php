
.captcha-input-image {
	text-align: center;
	margin: auto;
}

