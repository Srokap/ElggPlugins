<?php
	
	$portuguese = array(
	
		'captcha:entercaptcha' => 'Digite o texto da imagem:',
		'captcha:captchafail' => 'Desculpe, o que você digitou não é compatível com a imagem. Tente novamente!',
	
	);
					
	add_translation("pt",$portuguese);
?>