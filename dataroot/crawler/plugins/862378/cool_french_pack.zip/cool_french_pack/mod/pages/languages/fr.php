<?php
/**
 * Pages languages
 *
 * @package ElggPages
 */

$french = array(

	/**
	 * Menu items and titles
	 */

	'pages' => "Pages",
	'pages:owner' => "Pages de %s",
	'pages:friends' => "Pages de mes amis",
	'pages:all' => "Toutes les pages",
	'pages:add' => "Ajouter une page",

	'pages:group' => "Pages du groupe",
	'groups:enablepages' => 'Autoriser les pages du groupe',

	'pages:edit' => "Éditer cette page",
	'pages:delete' => "Supprimer cette page",
	'pages:history' => "Historique",
	'pages:view' => "Voir la page",
	'pages:revision' => "Révision",

	'pages:navigation' => "Navigation",
	'pages:via' => "via pages",
	'item:object:page_top' => 'Pages de haut-niveau',
	'item:object:page' => 'Pages',
	'pages:nogroup' => 'Ce groupe n\'a pas encore de pages',
	'pages:more' => 'Plus de pages',
	'pages:none' => 'Pas encore de page créée',

	/**
	* River
	**/

	'river:create:object:page' => '%s a créé la page %s',
	'river:create:object:page_top' => '%s a créée une page %s',
	'river:update:object:page' => '%s a mis à jour la page %s',
	'river:update:object:page_top' => '%s a mis à jour la page %s',
	'river:comment:object:page' => '%s a commenté la page intitulée %s',
	'river:comment:object:page_top' => '%s a commenté la page intitulée %s',

	/**
	 * Form fields
	 */

	'pages:title' => 'Titre de la page',
	'pages:description' => 'Texte de la page',
	'pages:tags' => 'Tags',
	'pages:access_id' => 'Accès de lecture',
	'pages:write_access_id' => 'Accès d\'écriture',

	/**
	 * Status and error messages
	 */
	'pages:noaccess' => 'Pas d\'accès à la page',
	'pages:cantedit' => 'Vous ne pouvez pas éditer cette page',
	'pages:saved' => 'Page sauvegardée',
	'pages:notsaved' => 'La page n\'a pas pu être sauvée',
	'pages:error:no_title' => 'Vous devez spécifier un titre pour la page.',
	'pages:delete:success' => 'La page a été supprimée.',
	'pages:delete:failure' => 'La page n\'a pas pu être supprimée.',

	/**
	 * Page
	 */
	'pages:strapline' => 'Dernière mise à jour %s par %s',

	/**
	 * History
	 */
	'pages:revision:subtitle' => 'Révision créée %s par %s',

	/**
	 * Widget
	 **/

	'pages:num' => 'Nombre de pages à afficher',
	'pages:widget:description' => "Ceci est une liste de vos pages.",

	/**
	 * Submenu items
	 */
	'pages:label:view' => "Voir la page",
	'pages:label:edit' => "Éditer la page",
	'pages:label:history' => "Historique de la page",

	/**
	 * Sidebar items
	 */
	'pages:sidebar:this' => "Cette page",
	'pages:sidebar:children' => "Sous-pages",
	'pages:sidebar:parent' => "Parent",

	'pages:newchild' => "Créer une sous-page",
	'pages:backtoparent' => "Retour à '%s'",
);

add_translation("fr", $french);