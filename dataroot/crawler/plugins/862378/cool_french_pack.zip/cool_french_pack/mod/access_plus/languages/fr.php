<?php

	$french = array(
		'access_plus' => "Accès avancé",
		'access_plus:add_user_to_metacollection:error' => "There was an issue adding a user to the metacollection",
		'access_plus:collections' => "Collections d'amis",
		'access_plus:invalid:token' => "ID invalide.",
		'access_plus:metacollection:creation:error' => "There was an issue creating the permissions, content set to private access.",
		'access_plus:toggle:disabled' => "Accès avancé désactivé.",
		'access_plus:toggle:enabled' => "àccès avancé activé.",
		'access_plus:toggle:off' => "Désactiver l'accès avancé",
		'access_plus:toggle:on' => "Activer l'accès avancé",
	);
					
	add_translation("fr",$french);

?>