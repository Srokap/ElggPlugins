<?php
/**
 * External pages English language file
 */

$french = array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Pages du site",
	'admin:appearance:expages' => "Pages du site",
	'expages:behind-the-stage/about' => "À propos",
	'expages:behind-the-stage/terms' => "Conditions d'utilisation",
	'expages:behind-the-stage/privacy' => "Confidentialité",

	'expages:notset' => "Cette page n'a pas encore été définie.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Votre page a été mise à jour.",
	'expages:error' => "Impossible de sauvegarder la page.",
);

add_translation("fr", $french);
