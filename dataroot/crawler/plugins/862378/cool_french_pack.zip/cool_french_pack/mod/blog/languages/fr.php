<?php
/**
 * Blog English language file.
 *
 */

$french = array(
	'blog' => 'Blogs',
	'blog:blogs' => 'Blogs',
	'blog:revisions' => 'Révisions',
	'blog:archives' => 'Archives',
	'blog:blog' => 'Blog',
	'item:object:blog' => 'Blogs',

	'blog:title:user_blogs' => 'Blogs de %s',
	'blog:title:all_blogs' => 'Tous les blogs du site',
	'blog:title:friends' => 'Blogs de mes amis',

	'blog:group' => 'Blog du groupe',
	'blog:enableblog' => 'Activer le blog du groupe',
	'blog:write' => 'Écrire un article de blog',

	// Editing
	'blog:add' => 'Ajouter un article de blog',
	'blog:edit' => 'Éditer un article de blog',
	'blog:excerpt' => 'Extrait',
	'blog:body' => 'Corps',
	'blog:save_status' => 'Dernière sauvegarde :',
	'blog:never' => 'Jamais',

	// Statuses
	'blog:status' => 'Statut',
	'blog:status:draft' => 'Brouillon',
	'blog:status:published' => 'Publié',
	'blog:status:unsaved_draft' => 'Brouillon non sauvegardé',

	'blog:revision' => 'Révision',
	'blog:auto_saved_revision' => 'Révision auto-enregistrée',

	// messages
	'blog:message:saved' => 'Article enregistré.',
	'blog:error:cannot_save' => 'Impossible de sauvegarder l\'article.',
	'blog:error:cannot_write_to_container' => 'Insufficient access to save blog to group.',
	'blog:error:post_not_found' => 'Cet article a été retiré, est invalide, ou vous n\'avez pas les permissionde le voir.',
	'blog:messages:warning:draft' => 'Il y a un brouillon non-sauvegardé de cet article!',
	'blog:edit_revision_notice' => '(Vieille version)',
	'blog:message:deleted_post' => 'Article supprimé.',
	'blog:error:cannot_delete_post' => 'Impossible de supprimer l\'article.',
	'blog:none' => 'Aucun article',
	'blog:error:missing:title' => 'Veuillez indiquer un titre à votre article!',
	'blog:error:missing:description' => 'Veuillez composer le corps de \'article!',
	'blog:error:cannot_edit_post' => 'Cet article n\'existe pas ou vous n\'avez pas les permissions de le modifier.',
	'blog:error:revision_not_found' => 'Impossible de trouver la révision.',

	// river
	'river:create:object:blog' => '%s a publié un article de blog %s',
	'river:comment:object:blog' => '%s a commenté le blog %s',

	// notifications
	'blog:newpost' => 'Un nouvel article de blog',

	// widget
	'blog:widget:description' => 'Afficher vos derniers articles',
	'blog:moreblogs' => 'Plus d\'articles',
	'blog:numbertodisplay' => 'Nombre d\'articles à afficher',
	'blog:noblogs' => 'Aucun article'
);

add_translation('fr', $french);
