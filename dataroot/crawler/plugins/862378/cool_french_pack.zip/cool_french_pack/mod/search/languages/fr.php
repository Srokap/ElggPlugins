<?php

$french = array(
	'search:enter_term' => 'Entrez un terme de la recherche :',
	'search:no_results' => 'Aucun résultat.',
	'search:matched' => 'matched : ',
	'search:results' => 'Résultats pour %s',
	'search:no_query' => 'Veuillez enter une requête pour chercher.',
	'search:search_error' => 'Erreur',

	'search:more' => '+%s plus %s',

	'search_types:tags' => 'Tags',

	'search_types:comments' => 'Commentaires',
	'search:comment_on' => 'Commentaire dans "%s"',
	'search:comment_by' => 'par',
	'search:unavailable_entity' => 'entité non disponible',
);

add_translation('fr', $french);
