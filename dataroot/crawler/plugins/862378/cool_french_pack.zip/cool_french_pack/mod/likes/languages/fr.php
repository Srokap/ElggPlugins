<?php
/**
 * Likes English language file
 */

$french = array(
	'likes:this' => 'liked this',
	'likes:deleted' => "Votre 'j'aime' a été retiré",
	'likes:see' => 'Voir qui aime ça',
	'likes:remove' => "Je n'aime plus",
	'likes:notdeleted' => 'There was a problem removing your like',
	'likes:likes' => 'Vous aimez cet item',
	'likes:failure' => "Il y a eu un problème pour retirer votre 'j'aime",
	'likes:alreadyliked' => 'Vous aimez déjà cet item',
	'likes:notfound' => "L'item que vous essayer d'aimer n'a pas pu être trouvé",
	'likes:likethis' => 'aiment ça',
	'likes:userlikedthis' => '%s aiment',
	'likes:userslikedthis' => '%s aime',
	'likes:river:annotate' => 'aime',

	'river:likes' => 'aime %s %s',

	// notifications. yikes.
	'likes:notifications:subject' => '%s aime votre post "%s"',
	'likes:notifications:body' =>
'Hi %1$s,

%2$s aime votre post "%3$s" dans %4$s

Pour voir le post d\'origine, cliquez ici :

%5$s

ou aller sur le profil de %2$s :

%6$s

Merci,
%4$s
',
	
);

add_translation('fr', $french);
