<?php

	$french = array(
		'extendafriend:cancel' => "Annuler",
		'extendafriend:edit:friend' => "Éditer le lien d'amitié",
		'extendafriend:form:instructions' => "Entrez des mots-clés séparés par une virgule, si une liste existe déjà avec un mot-clé l'ami sera ajouté à cette liste. Si une liste n'existe pas, elle sera créée. Si vous avez déjà des listes, elles peuvent être contrôlées en utilisant les cases appropriées.",
		'extendafriend:invalid:id' => "ID invalide",
		'extendafriend:name' => "Extendafriend",
		'extendafriend:rtags' => "Tags décrivant la relation (optionnel)",
		'extendafriend:submit' => "Envoyer",
		'extendafriend:updated' => "La liste d'amis a été sauvée.",
	);
					
	add_translation("fr",$french);

?>