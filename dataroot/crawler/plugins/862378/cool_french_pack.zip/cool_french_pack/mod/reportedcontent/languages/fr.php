<?php
/**
 * Elgg reported content plugin language pack
 *
 * @package ElggReportedContent
 */

$french = array(

	'item:object:reported_content' => 'Items signalés',
	'admin:administer_utilities:reportedcontent' => 'Contenu signalé',
	'reportedcontent' => 'Contenu signalé',
	'reportedcontent:this' => 'Signaler',
	'reportedcontent:this:tooltip' => 'Signaler cette page',
	'reportedcontent:none' => 'Il n\'y a pas de contenu signalé',
	'reportedcontent:report' => 'Rapporter à l\'admin',
	'reportedcontent:title' => 'Titre de la page',
	'reportedcontent:deleted' => 'Le contenu signalé a été supprimé',
	'reportedcontent:notdeleted' => 'Nous n\'avons pas pu supprimer ce rapport',
	'reportedcontent:delete' => 'Supprimer le rapport',
	'reportedcontent:areyousure' => 'êtes-vous sûr de vouloir supprimer?',
	'reportedcontent:archive' => 'Archiver le rapport',
	'reportedcontent:archived' => 'Le rapport a été archivé',
	'reportedcontent:visit' => 'Voir l\'item rapporté',
	'reportedcontent:by' => 'Rapporté par',
	'reportedcontent:objecttitle' => 'Titre de la page',
	'reportedcontent:objecturl' => 'URL de la page',
	'reportedcontent:reason' => 'Raison du rapport',
	'reportedcontent:description' => 'Pourquoi signalez-vous ça?',
	'reportedcontent:address' => 'Localisation de l\'item',
	'reportedcontent:success' => 'Votre rapport a été envoyé',
	'reportedcontent:failing' => 'Votre rapport n\'a pas pu être nevoyé',
	'reportedcontent:report' => 'Signaler',
	'reportedcontent:moreinfo' => 'Plus d\'infos',
	'reportedcontent:instructions' => 'Ce rapport sera envoyé aux administrateurs du site.',
	'reportedcontent:numbertodisplay' => 'Nombre de rapports à afficher',
	'reportedcontent:widget:description' => 'Afficher le contenu rapporté',
	'reportedcontent:user' => 'Signaler l\'utilisateur',

	'reportedcontent:failed' => 'Désolé, la tentative de signaler ce contenu a échoué.',
	'reportedcontent:notarchived' => 'Nous n\'étions pas en mesure d\'archiver ce rapport',
);

add_translation("fr", $french);
