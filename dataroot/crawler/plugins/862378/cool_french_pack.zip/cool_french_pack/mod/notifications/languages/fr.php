<?php

$french = array(

	'friends:all' => 'Tous mes amis',

	'notifications:subscriptions:personal:description' => 'Recevez des notifications lorsque des actions sont effectuées sur votre contenu',
	'notifications:subscriptions:personal:title' => 'Notifications personnelles',

	'notifications:subscriptions:friends:title' => 'Amis',
	'notifications:subscriptions:friends:description' => 'Ce qui suit est une liste automatique composée de vos amis. Pour recevoir les mises à jour sélectionnez les ci-dessous. Cela affectera les utilisateurs correspondants dans les paramètres du panneau principal au bas de la page. ',
	'notifications:subscriptions:collections:edit' => 'Pour modifier vos notifications partagées, cliquez ici.',

	'notifications:subscriptions:changesettings' => 'Notifications',
	'notifications:subscriptions:changesettings:groups' => 'Notifications de groupe',

	'notifications:subscriptions:title' => 'Notifications par utilisateur',
	'notifications:subscriptions:description' => 'Pour recevoir des notifications de vos amis (sur une base individuelle) lors de la création de nouveaux contenus, trouvez-les ci-dessous et sélectionnez la méthode de notification que vous souhaitez utiliser.',

	'notifications:subscriptions:groups:description' => 'Pour recevoir des notifications lorsqu\'un nouveau contenu est ajouté à un groupe dont vous êtes membre, trouvez le ci-dessous et sélectionnez la méthode de notifications que vous souhaitez utiliser.',

	'notifications:subscriptions:success' => 'Vos réglages de notifications ont été sauvés.',

);

	add_translation("fr", $french);
