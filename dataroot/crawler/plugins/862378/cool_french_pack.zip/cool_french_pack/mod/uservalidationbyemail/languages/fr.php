<?php
/**
 * Email user validation plugin language pack.
 *
 * @package Elgg.Core.Plugin
 * @subpackage ElggUserValidationByEmail
 */

$french = array(
	'admin:users:unvalidated' => 'Invalidé',
	
	'email:validate:subject' => "%s veuillez confirmer votre adresse pour %s!",
	'email:validate:body' => "%s,

Avant de commencer à utiliser %s, vous devez confirmer votre adresse mail.

Confirmez votre adresse en cliquant sur le lien ci-dessous :

%s

Si vous ne pouvez pas cliquer sur le lien, faîtes un copier-coller du lien dans votre navigateur.

%s
%s
",
	'email:confirm:success' => "Vous avez confirmé votre adresse mail!",
	'email:confirm:fail' => "Votre adresse mail n'a pas pu être vérifiée...",

	'uservalidationbyemail:registerok' => "Pour activer votre compte, s'il vous plaît confirmez votre adresse e-mail en cliquant sur ​​le lien que nous venons de vous envoyer.",
	'uservalidationbyemail:login:fail' => "Votre compte n'est pas validé donc la tentative de connexion a échoué. Un autre email de validation a été envoyé.",

	'uservalidationbyemail:admin:no_unvalidated_users' => 'Pas d\'utilisateurs invalidés.',

	'uservalidationbyemail:admin:unvalidated' => 'Invalidé',
	'uservalidationbyemail:admin:user_created' => 'Enregistré %s',
	'uservalidationbyemail:admin:resend_validation' => 'Renvoyer la validation',
	'uservalidationbyemail:admin:validate' => 'Valider',
	'uservalidationbyemail:admin:delete' => 'Supprimer',
	'uservalidationbyemail:confirm_validate_user' => 'Valider %s?',
	'uservalidationbyemail:confirm_resend_validation' => 'Resend validation email to %s?',
	'uservalidationbyemail:confirm_delete' => 'Delete %s?',
	'uservalidationbyemail:confirm_validate_checked' => 'Validate checked users?',
	'uservalidationbyemail:confirm_resend_validation_checked' => 'Resend validation to checked users?',
	'uservalidationbyemail:confirm_delete_checked' => 'Delete checked users?',
	'uservalidationbyemail:check_all' => 'Tous',

	'uservalidationbyemail:errors:unknown_users' => 'Utilisateurs inconnus',
	'uservalidationbyemail:errors:could_not_validate_user' => 'Impossible de valider l\'utilisateur.',
	'uservalidationbyemail:errors:could_not_validate_users' => 'Could not validate all checked users.',
	'uservalidationbyemail:errors:could_not_delete_user' => 'Impossible de supprimer l\'utilisateur.',
	'uservalidationbyemail:errors:could_not_delete_users' => 'Could not delete all checked users.',
	'uservalidationbyemail:errors:could_not_resend_validation' => 'Could not resend validation request.',
	'uservalidationbyemail:errors:could_not_resend_validations' => 'Could not resend all validation requests to checked users.',

	'uservalidationbyemail:messages:validated_user' => 'Utilisateur validé.',
	'uservalidationbyemail:messages:validated_users' => 'All checked users validated.',
	'uservalidationbyemail:messages:deleted_user' => 'Utilisateur supprimé.',
	'uservalidationbyemail:messages:deleted_users' => 'All checked users deleted.',
	'uservalidationbyemail:messages:resent_validation' => 'Mail de validation envoyé.',
	'uservalidationbyemail:messages:resent_validations' => 'Validation requests resent to all checked users.'

);

add_translation("fr", $french);