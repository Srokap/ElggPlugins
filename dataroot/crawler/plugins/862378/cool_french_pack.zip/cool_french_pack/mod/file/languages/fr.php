<?php
/**
 * Elgg file plugin language pack
 *
 * @package ElggFile
 */

$french = array(

	/**
	 * Menu items and titles
	 */
	'file' => "Fichiers",
	'file:user' => "Fichiers de  %s",
	'file:friends' => "Fichiers de mes amis",
	'file:all' => "Tous les fichiers du site",
	'file:edit' => "Modifier le fichier",
	'file:more' => "Plus de fichiers",
	'file:list' => "Affichage par liste",
	'file:group' => "Fichiers du groupe",
	'file:gallery' => "Affichage par gallerie",
	'file:gallery_list' => "Affichage par liste ou par gallerie",
	'file:num_files' => "Nombre de fichiers à afficher",
	'file:user:gallery'=>'Voir la gallerie de %s',
	'file:via' => 'via fichiers',
	'file:upload' => "Envoyer un fichier",
	'file:replace' => 'Remplacer le contenu du fichier (laisser blanc pour ne pas modifier le fichier)',
	'file:list:title' => "%s's %s %s",
	'file:title:friends' => "Friends'",

	'file:add' => 'Envoyer un fichier',

	'file:file' => "Fichier",
	'file:title' => "Titre",
	'file:desc' => "Description",
	'file:tags' => "Tags",

	'file:list:list' => 'Passer en vue par liste',
	'file:list:gallery' => 'Passer en vue gallerie',

	'file:types' => "Types de fichiers envoyés",

	'file:type:' => 'Fichiers',
	'file:type:all' => "Tous les fichiers",
	'file:type:video' => "Vidéos",
	'file:type:document' => "Documents",
	'file:type:audio' => "Audio",
	'file:type:image' => "Images",
	'file:type:general' => "Général",

	'file:user:type:video' => "Vidéos de %s",
	'file:user:type:document' => "Documents de %s",
	'file:user:type:audio' => "Pistes audio de %s",
	'file:user:type:image' => "Images de %s",
	'file:user:type:general' => "Fichiers de %s",

	'file:friends:type:video' => "Vidéos de vos amis",
	'file:friends:type:document' => "Documents de vos amis",
	'file:friends:type:audio' => "Pistes audio de vos amis",
	'file:friends:type:image' => "Images de vos amis",
	'file:friends:type:general' => "Les fichiers de vos amis",

	'file:widget' => "Widget fichiers",
	'file:widget:description' => "Afficher vos derniers fichiers",

	'groups:enablefiles' => 'Autoriser les fichiers pour le groupe',

	'file:download' => "Télécharger",

	'file:delete:confirm' => "Êtes-vous sûr de vouloir supprimer ce fichier?",

	'file:tagcloud' => "Nuage de mots-clés",

	'file:display:number' => "Nombre de fichiers à afficher",

	'river:create:object:file' => '%s a partagé le fichier %s',
	'river:comment:object:file' => '%s a commenté le fichier %s',

	'item:object:file' => 'Fichiers',

	'file:newupload' => 'Un nouveau fihcier a été envoyé',

	/**
	 * Embed media
	 **/

		'file:embed' => "Média joint",
		'file:embedall' => "Tous",

	/**
	 * Status messages
	 */

		'file:saved' => "Votre fichier a été correctement sauvé.",
		'file:deleted' => "Votre fichier a été supprimé.",

	/**
	 * Error messages
	 */

		'file:none' => "Aucun fichier.",
		'file:uploadfailed' => "Désolé; nous n'avons pas pu sauvé votre fichier.",
		'file:downloadfailed' => "Désolé; le fichier n'est pas accessible.",
		'file:deletefailed' => "Votre fichier n'a pas pu être supprimé.",
		'file:noaccess' => "Vous n'avez pas les permissions de modifier le fichier",
		'file:cannotload' => "Il y a eu une erreur pour envoyer le fichier",
		'file:nofile' => "Vous devez sélectionner un fichier",
);

add_translation("fr", $french);