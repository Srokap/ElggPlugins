<?php
/**
* Elgg send a message action page
* 
* @package ElggMessages
*/

$french = array(
	/**
	* Menu items and titles
	*/

	'messages' => "Messages",
	'messages:unreadcount' => "%s non lu(s)",
	'messages:back' => "Retour aux messages",
	'messages:user' => "Boite de réception de %s",
	'messages:posttitle' => "messages de %s : %s",
	'messages:inbox' => "Boite de réception",
	'messages:send' => "Envoyer",
	'messages:sent' => "Envoyés",
	'messages:message' => "Message",
	'messages:title' => "Sujet",
	'messages:to' => "À",
	'messages:from' => "De",
	'messages:fly' => "Envoyer",
	'messages:replying' => "Mssage en réponse de",
	'messages:inbox' => "Boite de réception",
	'messages:sendmessage' => "Envoyer un message",
	'messages:compose' => "Composer un message",
	'messages:add' => "Composer un message",
	'messages:sentmessages' => "Messages envoyés",
	'messages:recent' => "Messages récents",
	'messages:original' => "Message d'origine",
	'messages:yours' => "Votre message",
	'messages:answer' => "Répondre",
	'messages:toggle' => 'Tout sélectionner',
	'messages:markread' => 'Marquer comme lu',
	'messages:recipient' => 'Choisir un destinataire&hellip;',
	'messages:to_user' => 'À : %s',

	'messages:new' => 'Nouveau message',

	'notification:method:site' => 'Site',

	'messages:error' => 'There was a problem saving your message. Please try again.',

	'item:object:messages' => 'Messages',

	/**
	* Status messages
	*/

	'messages:posted' => "Votre message a été envoyé.",
	'messages:success:delete:single' => 'Le message a été supprimé',
	'messages:success:delete' => 'Messages supprimés',
	'messages:success:read' => 'Messages marqués comme lus',
	'messages:error:messages_not_selected' => 'Aucun message sélectionné',
	'messages:error:delete:single' => 'Impossible de supprimer le message',

	/**
	* Email messages
	*/

	'messages:email:subject' => 'Vous avez un nouveau message!',
	'messages:email:body' => "Vous avez un nouveau message de %s. Il dit :


	%s


	Pour voir vos messages, cliquez ici :

	%s

	Pour envoyer un message à %s, cliquez ici :

	%s

	Vous ne pouvez pas répondre à cet email.",

	/**
	* Error messages
	*/

	'messages:blank' => "désolé; vous devez saisir le corps du message avant de pouvoir le sauvegarder.",
	'messages:notfound' => "désolé; nous n'avons pas pu trouver le message spécifié.",
	'messages:notdeleted' => "désolé; nous n'avons pas pu supprimé le message.",
	'messages:nopermission' => "Vous n'avez pas les permissions de modifier ce message.",
	'messages:nomessages' => "Il n'y a aucun message.",
	'messages:user:nonexist' => "Nous n'avons pas trouvé cet utilisateur dans la base de données.",
	'messages:user:blank' => "Vous n'avez choisi personne à qui envoyer le message.",

	'messages:deleted_sender' => 'Utilisateur supprimé',

);
		
add_translation("fr", $french);