<?php
/**
 * Bookmarks English language file
 */

$french = array(

	/**
	 * Menu items and titles
	 */
	'bookmarks' => "Liens",
	'bookmarks:add' => "Ajouter un lien",
	'bookmarks:edit' => "Modifier le lien",
	'bookmarks:owner' => "Liens de %s",
	'bookmarks:friends' => "Liens de mes amis",
	'bookmarks:everyone' => "Tous les liens du site",
	'bookmarks:this' => "Ajouter un signet pour cette page",
	'bookmarks:this:group' => "Bookmark in %s",
	'bookmarks:bookmarklet' => "Obtenir le bookmarklet",
	'bookmarks:bookmarklet:group' => "Obtenir le bookmarklet du groupe",
	'bookmarks:inbox' => "Bookmarks inbox",
	'bookmarks:morebookmarks' => "Plus de signets",
	'bookmarks:more' => "Plus",
	'bookmarks:with' => "Partager avec",
	'bookmarks:new' => "Un nouveau lien",
	'bookmarks:via' => "via bookmarks",
	'bookmarks:address' => "Adresse du lien",
	'bookmarks:none' => 'Pas de liens',

	'bookmarks:delete:confirm' => "Êtes-vous sûr de vouloir supprimer cette ressource?",

	'bookmarks:numbertodisplay' => 'Nombre de liens à afficher',

	'bookmarks:shared' => "Ajouté",
	'bookmarks:visit' => "Voir la ressource",
	'bookmarks:recent' => "Liens récents",

	'river:create:object:bookmarks' => '%s a partagé %s',
	'river:comment:object:bookmarks' => '%s a commenté le lien %s',
	'bookmarks:river:annotate' => 'un commentaire sur ce lien',
	'bookmarks:river:item' => 'un item',

	'item:object:bookmarks' => 'Liens',

	'bookmarks:group' => 'Signets du groupe',
	'bookmarks:enablebookmarks' => 'Autoriser les signets',
	'bookmarks:nogroup' => 'Ce groupe n\'a pas encore de signets.',
	'bookmarks:more' => 'Plus de liens',

	'bookmarks:no_title' => 'Pas de titre',

	/**
	 * Widget and bookmarklet
	 */
	'bookmarks:widget:description' => "Afficher vos derniers liens.",

	'bookmarks:bookmarklet:description' =>
			"Le bookmarklet vous permet de partager n'importe quelle ressource vous trouvez sur le web avec vos amis, ou tout simplement pour vous-même. Pour l'utiliser, il suffit de faire glisser le bouton ci-dessous à la barre de votre navigateur liens :",

	'bookmarks:bookmarklet:descriptionie' =>
			"Si vous utilisez Internet Explorer, vous devrez faire un clic droit sur ​​l'icône bookmarklet, sélectionnez 'Ajouter aux favoris', puis la barre des liens.",

	'bookmarks:bookmarklet:description:conclusion' =>
			"You can then save any page you visit by clicking it at any time.",

	/**
	 * Status messages
	 */

	'bookmarks:save:success' => "Votre item a été sauvegardé.",
	'bookmarks:delete:success' => "Votre signet a été supprimé.",

	/**
	 * Error messages
	 */

	'bookmarks:save:failed' => "Votre signet n'a pas pu être sauvé. Assurez-vous que vous avez entré un titre et l'adresse, puis essayez à nouveau.",
	'bookmarks:save:invalid' => "L'adresse du signet est invalide et n'a pas être sauvé.",
	'bookmarks:delete:failed' => "Votre signet n'a pas pu être supprimé. Veuillez réessayer.",
);

add_translation('fr', $french);