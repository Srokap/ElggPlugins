<?php

add_translation('fr', array(
	'follow:user' => 'S\'abonner',
	'unfollow:user' => 'Ne plus suivre',

	'widgets:following:name' => 'Mes abonnements',
	'widgets:following:description' => 'Une liste des utilisateurs dont je suis abonné.',

	'widgets:followers:name' => 'Mes abonnés',
	'widgets:followers:description' => 'Une liste de mes abonnés',


	/* Actions */
	'followers:follow:error:noentity' => 'Impossible de trouve l\'entité désirée.  Il a pu être supprimé ou vous n\'y avez pas accès',
	'followers:follow:error:unknown' => 'Something went wrong when attempting to follow %s',
	'followers:follow:success' => 'Vous êtes abonné à %s',

	'followers:unfollow:error:noentity' => 'Impossible de trouve l\'entité désirée.  Il a pu être supprimé ou vous n\'y avez pas accès',
	'followers:unfollow:error:unknown' => 'Il y a eu un problème pour ne plus suivre %s',
	'followers:unfollow:success' => 'Vous ne suivez plus %s',

));