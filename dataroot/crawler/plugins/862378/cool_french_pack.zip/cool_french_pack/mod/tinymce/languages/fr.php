<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$french = array(
	'tinymce:remove' => "Enlever l'éditeur",
	'tinymce:add' => "Ajouter l'éditeur",
	'tinymce:word_count' => 'Nombre de mots : ',
);

add_translation("fr", $french);