<?php
/**
 * Elgg profile plugin language pack
 */

$french = array(
	'profile' => 'Profil',
	'profile:notfound' => 'Désolé. Nous n\'avons pas pu trouver le profil demandé.',

);

add_translation('fr', $french);