<?php
/**
 * dislikes English language file
 */

$french = array(
	'dislikes:this' => 'n\'aime pas',
	'dislikes:deleted' => 'Votre dislike a été supprimé',
	'dislikes:see' => 'Voir qui n\'aime pas ça',
	'dislikes:remove' => 'finalement j\'aime bien',
	'dislikes:notdeleted' => 'Il y a eu un problème pour enlever votre dislike',
	'dislikes:dislikes' => 'Vous n\'aimez pas cet item',
	'dislikes:failure' => 'Il y avait un problème pour \'ne pas aimer\' cet article',
	'dislikes:alreadyliked' => 'Vous n\'aimez pas déjà cet item',
	'dislikes:notfound' => 'L\'item que vous ne voulez pas aimer n\'a pas pu être trouvé',
	'dislikes:dislikethis' => 'disLike this',
	'dislikes:userdislikedthis' => '%s n\'aime pas',
	'dislikes:usersdislikedthis' => '%s n\'aime pas',
	'dislikes:river:annotate' => 'n\'aime pas',

	'river:dislikes' => 'dislikes %s %s',

	// notifications. yikes.
	'dislikes:notifications:subject' => '%s n\'aime pas votre post "%s"',
	'dislikes:notifications:body' =>
'Bonjour %1$s,

%2$s dislikes your post "%3$s" on %4$s

See your original post here :

%5$s

or view %2$s\'s profile here :

%6$s

Merci,
%4$s
',
	
);

add_translation('fr', $french);
