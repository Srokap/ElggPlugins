Read carefully this is easy as shit :

When you open the archive, you get two folders => languages & mod

-In the 'languages' folder, there is a file "fr.php". You have to put this file in /path/to/your/elgg/installation/languages/{here}

-In the 'mod' folder, there are a lot of plugins folders, each of them contains a folder 'languages' with a file called "fr.php".
You have to put the correct "fr.php" file in  /path/to/your/elgg/installation/mod/{the_mod}/languages/{here}

Any questions?
Feel free to ask me
webmaster@your-itouch.fr
@stanl on elgg.org
http://github.com/wisb
http://wisb.your-itouch.fr is the main project

Feel free to make a donation on the plugin page, this will help my college fees...