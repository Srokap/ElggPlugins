<?php
	/**
	 * Mass Mail outs.
	 * 
	 * @package mass_mailouts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Brucepro
	 * @copyright Brucepro 2008
	 * @link http://brucepro.net/
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	admin_gatekeeper();
	set_context('admin');
	// Set admin user for user block
		set_page_owner($_SESSION['guid']);
$result = "";
$email_subject = sanitise_string(get_input('email_subject'));
	if ($email_subject != "") {
//add in error checking, spam checking etc. 

		$access = get_access_sql_suffix('e');
		
		$query = "SELECT email from {$CONFIG->dbprefix}users_entity";
		
		$emails = get_data($query);
//
	

	// function sanitise_string adds in \r\n, need better  fix.
//$emailmessage = sanitise_string(get_input('email_text'));
	$emailmessage = get_input('email_text');	
	global $CONFIG;
	
	if (sizeof($emails)) {
for($i=0;$i<sizeof($emails);$i++) {
$email = $emails[$i]->email;
if (!empty($email)) {
					
					$site = $CONFIG->site;
					if (($site) && (isset($site->email))) // Has the current site got a from email address?
						$from = $site->email;
					else if (isset($from->url)) // If we have a url then try and use that.
					{
						$breakdown = parse_url($from->url);
						$from = 'noreply@' . $breakdown['host']; // Handle anything with a url
					}
					else // If all else fails, use the domain of the site.
						$from = 'noreply@' . get_site_domain($CONFIG->site_guid); 
					$headers = "From: \"{$CONFIG->site->name}\" <{$CONFIG->site->email}>\r\n"
				. "Content-Type: text/html; charset=UTF-8; format=flowed\r\n"
	    		. "MIME-Version: 1.0\r\n"
	    		. "Content-Transfer-Encoding: 8bit\r\n";
					mail($email, sprintf($email_subject, $CONFIG->site->name),wordwrap($emailmessage), $headers);
								
}
			}
			system_message(elgg_echo('mass_mailouts:success'));
$result = elgg_echo('mass_mailouts:success');

		} else {
			register_error(elgg_echo('mass_mailouts:failure'));
$result = elgg_echo('mass_mailouts:failure');
		}



}


	$title = elgg_view_title(elgg_echo('mass_mailouts'));
	
	$form = elgg_view('mass_mailouts/form');

	
	set_context('search');
	set_context('admin');
		
// Display main admin menu
	page_draw(elgg_echo('mass_mailouts'),elgg_view_layout("two_column_left_sidebar", '', $title . $form . $result));

?>
