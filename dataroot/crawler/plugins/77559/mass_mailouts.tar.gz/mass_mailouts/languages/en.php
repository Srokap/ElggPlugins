<?php
	/**
	 * Mass Mail outs.
	 * 
	 * @package mass_mailouts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Brucepro
	 * @copyright Brucepro 2008
	 * @link http://brucepro.net/
	 */

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'mass_mailouts' => 'Mass Mailouts',
'mass_mailouts:email_text' => 'Email Message:',
'mass_mailouts:subject' => 'Email Subject:',
'mass_mailouts:success' => 'Email Has been sent.',

'mass_mailouts:failure' => 'Email Failed to be sent.',

			'mass_mailouts:browse' => 'Browse ',
			'mass_mailouts:search' => 'Refine results',
			'mass_mailouts:user' => 'Username to search by',
			'mass_mailouts:starttime' => 'Beginning time (for example "last monday", "1 hour ago")',
			'mass_mailouts:endtime' => 'End time',
	
			'mass_mailouts:explore' => 'Explore Mass Mailouts',
	
	);
					
	add_translation("en",$english);
?>