<div id="mass_mailouts_email_area">
	

<?php 
  $form = "";
		
  $form .= "<p>" . elgg_echo('mass_mailouts:subject');
  $form .= elgg_view('input/text',array(
	'internalname' => 'email_subject',
	'value' => "" 
  )) . "</p>";
  $form .= "<p>" . elgg_echo('mass_mailouts:email_text');
  $form .= elgg_view('input/longtext',array(
	'internalname' => 'email_text',
	'value' => ""
  ))  . "</p>";
  $form .= elgg_view('input/submit',array(
	'value' => elgg_echo('Send  Email')
  ));

  $wrappedform2 = elgg_view('input/form',array(
  	'body' => $form,
	'method' => 'get',
	'action' => $vars['url'] . "mod/mass_mailouts/"
  ));

?>

<?php echo $wrappedform2; ?>
</p>
</div>
