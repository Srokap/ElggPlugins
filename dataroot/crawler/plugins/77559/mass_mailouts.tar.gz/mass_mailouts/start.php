<?php
	/**
	 * Mass Mail outs.
	 * 
	 * @package mass_mailouts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Brucepro
	 * @copyright Brucepro 2008
	 * @link http://brucepro.net/
	 */

	/**
	 * Initialise and set up the menus.
	 *
	 */
	function mass_mailouts_init()
	{
		global $CONFIG;
		
		// Register a page handler, so we can have nice URLs
		register_page_handler('mass_mailouts','mass_mailouts_page_handler');
		
		// Extend CSS
		extend_view('css','mass_mailouts/css');
		
		// Extend context menu with admin logbrowsre link
			if (isadminloggedin())
			{
	   			 extend_view('profile/menu/adminlinks','mass_mailouts/adminlinks',10000);
			}
	}
	
	/**
	 * Adding to the admin menu
	 *
	 */
	function mass_mailouts_pagesetup()
	{
		if (get_context() == 'admin' && isadminloggedin()) {
			global $CONFIG;
			add_submenu_item(elgg_echo('mass_mailouts'), $CONFIG->wwwroot . 'pg/mass_mailouts/');
		}
	}
	
	/**
	 * page handler
	 *
	 * @param array $page Array of page elements, forwarded by the page handling mechanism
	 */
	function mass_mailouts_page_handler($page) 
	{
		global $CONFIG;
		
		// only interested in one page for now
		include($CONFIG->pluginspath . "mass_mailouts/index.php"); 
	}
	
	
	
	// Initialise log browser
	register_elgg_event_handler('init','system','mass_mailouts_init');
	register_elgg_event_handler('pagesetup','system','mass_mailouts_pagesetup');
?>