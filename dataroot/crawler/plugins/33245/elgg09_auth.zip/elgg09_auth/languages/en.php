<?php

    /**
	 * Elgg 0.9 authentication
	 * 
	 * @package Elgg09Auth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Anthony Channing
	 * @copyright Anthony Channing 2009
	 * @link http://chantech.tv
	 */

    $en = array(
        'elgg09_auth:settings:label:schema' => "Elgg 0.9 Database Schema",
        'elgg09_auth:settings:help:schema' => "This should be the name of the MySQL Database Schema where the Elgg 0.9 users table is located",
        'elgg09_auth:settings:label:table' => "Elgg 0.9 Users Table",
        'elgg09_auth:settings:help:table' => "This should be the name of the Elgg 0.9 users table.  For example, if the prefix used for the installation was 'elgg', then the table name should be 'elgg_users'.",
        'elgg09_auth:no_database' => "Failed to connect to database to validate your credentials, please contact the system administrator",
        'elgg09_auth:no_account' => "Your credentials are valid, but no account was found - please contact the system administrator",
        'elgg09_auth:no_register' => 'An account could not get created for you - please contact the system administrator.'
    );
    
    add_translation('en', $en);
?>
