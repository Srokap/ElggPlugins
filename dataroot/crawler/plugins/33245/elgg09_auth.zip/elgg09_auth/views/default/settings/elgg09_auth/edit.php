<?
    /**
	 * Elgg 0.9 authentication
	 * 
	 * @package Elgg09Auth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Anthony Channing
	 * @copyright Anthony Channing 2009
	 * @link http://chantech.tv
	 */
?>
<p>
    <fieldset style="border: 1px solid; padding: 15px; margin: 0 10px 0 10px">
        <legend><?php echo elgg_echo('elgg09_auth:settings:label:schema');?></legend>
        
        <label for="params[schema]"><?php echo elgg_echo('elgg09_auth:settings:label:schema');?></label><br/>
        <div class="example"><?php echo elgg_echo('elgg09_auth:settings:help:schema');?></div>
        <input type="text" name="params[schema]" value="<?php echo $vars['entity']->schema;?>"/><br/>


        <legend><?php echo elgg_echo('elgg09_auth:settings:label:table');?></legend>
        
        <label for="params[table]"><?php echo elgg_echo('elgg09_auth:settings:label:table');?></label><br/>
        <div class="example"><?php echo elgg_echo('elgg09_auth:settings:help:table');?></div>
        <input type="text" name="params[table]" value="<?php echo $vars['entity']->schema;?>"/><br/>
    </fieldset>
</p>