<?php

	/**
	 * Elgg old kia authentication
	 * This plugin lets users login using their old kia elgg credentials
	 * 
	 * @package oldkia_auth
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Anthony Channing
	 * @copyright Anthony Channing 2009
	 * @link http://chantech.tv/
	 */

	/**
	 * Old KIA Authentication initialisation
	 *
	 * These parameters are required for the event API, but we won't use them:
	 * 
	 * @param unknown_type $event
	 * @param unknown_type $object_type
	 * @param unknown_type $object
	 */
	function oldkia_auth_init() {
		global $CONFIG;

		// Register the authentication handler
		register_pam_handler('oldkia_auth_handler');

		register_translations($CONFIG->pluginspath . "elgg09_auth/languages/");
	}
	
	// Register the initialisation function
	register_elgg_event_handler('init','system','oldkia_auth_init');

	/**
	 * Old KIA Authentication Handler
	 * 
	 * @param mixed $credentials PAM handler specific credentials
	 * @return boolean
	 */
	function oldkia_auth_handler($credentials) {
		global $CONFIG, $dblink, $DB_QUERY_CACHE, $dbcalls;

		$config = find_plugin_settings('elgg09_auth');

		// Nothing to do if not configured
		if (!$config) return false;

		$schema = $config->schema;
		$table = $config->table;

		// Try and login in the old elgg style...
		$username = $credentials['username'];
		$password = $credentials['password'];
		$pw_hash = md5($password);

		if ($dblink) {				
			$db_selected = mysql_select_db($schema);

			if($db_selected) {
				$sql="
select 
	email, name
from 
	".$table." 
where 
	username = '".$username."'
	and password = '".$pw_hash."'";

				$result = mysql_query($sql);

				$db_selected = mysql_select_db($CONFIG->dbname);

				if($result) {
					if ($row = mysql_fetch_assoc($result)) {
						$email = $row['email'];
						$name =  $row['name'];
						if ($user = get_user_by_username($username)) {
							// User exists, login            	        
							return login($user);
						} else {
							//Create user
							if ($user_guid = register_user($username, $password, $name, $email)) {
								// Success, credentials valid and account has been created
//die('success!');
								return true;
							} else {
								register_error(elgg_echo('oldkia_auth:no_register'));
die('oldkia_auth:no_register! <pre>'.print_r($user_guid,1).'</pre>');
							}
						}
					} else {
						register_error(elgg_echo('oldkia_auth:invalid_account'));
//die('oldkia_auth:invalid_account!');
					}
				} else {		
					register_error(elgg_echo('oldkia_auth:no_account'));
//die('oldkia_auth:no_account!');
				}
			} else {			
				$db_selected = mysql_select_db('devadmin_kiaelgg');
				register_error(elgg_echo('oldkia_auth:no_database'));
//die('oldkia_auth:no_database!');
			}
		}
//die('oldkia_auth:no_db_link!');
		register_error(elgg_echo('oldkia_auth:no_database'));
		return false;
	}


?>