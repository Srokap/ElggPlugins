<?php
/**
 * Provide a way of setting your language prefs
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd
 * @link http://elgg.org/
 */

global $CONFIG;
$user = page_owner_entity();

if ($user) {
?>
<p style="display: none;"><?php

		$value = $CONFIG->language;
		if ($user->language) {
			$value = $user->language;
		}

		echo elgg_view("input/hidden", array('internalname' => 'language', 'value' => $value, 'options_values' => get_installed_translations()));

	?>

</p>

<?php
}