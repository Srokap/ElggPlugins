<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	/**
	 * videos plugin initialisation functions.
	 */
    
    function videos_init() 
	{
		// Get config
		global $CONFIG;
		
	    // Set up menu for logged in users
		if (isloggedin()) 
		{
			add_menu(elgg_echo('videos'), $CONFIG->wwwroot . "pg/videos/owned/" . $_SESSION['user']->username);
		}
		
		// Extend CSS
		extend_view('css', 'video/css');
		
		// Register a page handler, so we can have nice URLs
		register_page_handler('videos','videos_page_handler');
		
		// Add a new tidypics widget
		add_widget_type('video_view',elgg_echo("video:widget"),elgg_echo("video:widget:description"), 'profile');
		
		define('VIDEO_AUTHENTICATION_URL', 'https://www.google.com/youtube/accounts/ClientLogin');
		define('VIDEO_SERVICE', 'youtube');
		define('VIDEO_SOURCE', 'Elgg 1.x');
		define('VIDEO_APPLICATION_ID', 'Video Plugin Elgg');
		//define('VIDEO_ACCESS_YOUTUBE', '1');
		define('DEVELOPER_TAG_URL', 'http://gdata.youtube.com/feeds/videos/-/%7Bhttp%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007%2Fdevelopertags.cat%7D');
		
		
		$oSetting->username = get_plugin_setting('username', 'videos');
		$oSetting->password = get_plugin_setting('password', 'videos');
		$oSetting->service = get_plugin_setting('service', 'videos');
		$oSetting->client = get_plugin_setting('client', 'videos');
		$oSetting->source = get_plugin_setting('source', 'videos');
		$oSetting->login_token = get_plugin_setting('login_token', 'videos');
		$oSetting->login_captcha = get_plugin_setting('login_captcha', 'videos');
		$oSetting->authentification_url = get_plugin_setting('authentification_url', 'videos');
		$oSetting->developer_key = get_plugin_setting('developer_key', 'videos');
		$oSetting->application_id = get_plugin_setting('application_id', 'videos');
		$oSetting->client_id = get_plugin_setting('client_id', 'videos');
		$oSetting->default_tag = get_plugin_setting('default_tag', 'videos');
		//$oSetting->accessyoutube = get_plugin_setting('accessyoutube', 'videos');
		
		$CONFIG->mod->videos->config = $oSetting;
		
		
	}
	

	
	// Register a URL handler for files
	register_entity_url_handler('video_url','object','video');

	// Register entity type
	register_entity_type('object','video');
	
	
	/**
	 * Sets up submenus for videos.  Triggered on pagesetup.
	 */
	function videos_submenus() {
		
		global $CONFIG;
		
		$page_owner = page_owner_entity();
		
		// General submenu options		
			if (get_context() == "videos" && configure_video()) 
			{			
				if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) 
				{
					add_submenu_item(sprintf(elgg_echo("videos:yours"),page_owner_entity()->name), $CONFIG->wwwroot . "pg/videos/owned/" . page_owner_entity()->username, '1view');
					add_submenu_item(sprintf(elgg_echo('videos:yours:friends'),page_owner_entity()->name), $CONFIG->wwwroot . "pg/videos/friends/". page_owner_entity()->username, '1view');
					add_submenu_item(sprintf(elgg_echo('videos:all'),page_owner_entity()->name), $CONFIG->wwwroot . "pg/videos/world/", '1view');			
				} else if (page_owner() && $page_owner instanceof ElggUser) 
				{
					add_submenu_item(sprintf(elgg_echo('videos:friends'),$page_owner->name), $CONFIG->wwwroot . "pg/videos/friends/". $page_owner->username,'1view');
					add_submenu_item(sprintf(elgg_echo('videos:all'),page_owner_entity()->name), $CONFIG->wwwroot . "pg/videos/world/", '1view');					
				}		
			}
	}

	/**
	 * videos page handler
	 *
	 * @param array $page Array of page elements, forwarded by the page handling mechanism
	 */
	function videos_page_handler($page) {
		
		global $CONFIG;
		
		if (isset($page[0])) 
		{
    		switch($page[0]) 
    		{
				case "owned":			
					if (isset($page[1])) set_input('username',$page[1]);  					
    				include($CONFIG->pluginspath . "videos/index.php");					
				break;	
				
    			case "view": //view an image individually					
    				set_input('guid',$page[1]);
					include($CONFIG->pluginspath . "videos/view.php");	
				break;
				
				case "upload": //upload images to albumvideosvideos				
					//if (isset($page[1])) set_input('container_guid',$page[1]);
					set_input('container_guid',$_SESSION['user']->guid);
					include($CONFIG->pluginspath . "videos/upload.php");
          		break;

    			case "friends": 
					if (isset($page[1])) set_input('username',$page[1]);
    				include($CONFIG->pluginspath . "videos/friends.php");
          		break;
				
   				case "world":  
   					include($CONFIG->pluginspath . "videos/world.php");
          		break;
          		
          		default:
   				    set_input('username',$_SESSION['user']->username);  	
   				    include($CONFIG->pluginspath . "videos/index.php");
				
    		}
		}
		else
		{
			// Include the standard profile index
			if (isset($page[1])) set_input('username',$page[1]); 
			include($CONFIG->pluginspath . "videos/index.php");
		}
		
	}
	
	function configure_video()
	{
		global $CONFIG;
		//Verificamos que tenga seteado todos los datos para poder hacer una accion de videos
		if(empty($CONFIG->mod->videos->config->username) ||
		   empty($CONFIG->mod->videos->config->password) ||
		   empty($CONFIG->mod->videos->config->developer_key)){
			
		   	return false;  	
		}
		return true;
	}
	
	function video_url($entity) 
	{		
			global $CONFIG;
			$title = $entity->title;
			$title = friendly_title($title);
			return $CONFIG->url . "pg/videos/view/" . $entity->getGUID() . "/" . $title;
			
	}
	
	
		
	// Make sure videos_init is called on initialisation
	register_elgg_event_handler('init','system','videos_init');
	register_elgg_event_handler('pagesetup','system','videos_submenus');
	
	// Register actions
	register_action("video/upload", false, $CONFIG->pluginspath . "videos/actions/upload.php");
	register_action("video/delete", false, $CONFIG->pluginspath. "videos/actions/delete.php");
	register_action("video/icon", true, $CONFIG->pluginspath. "videos/actions/icon.php");
	
	
	
?>