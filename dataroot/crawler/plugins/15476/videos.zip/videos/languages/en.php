<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	$english = array(

	    /*Videos*/
	    'video' => "Video",
	    'videos' => "Videos",
	    'videos:user' => "%s's Videos",
	    'videos:yours' => "Your Videos",
	    'videos:yours:friends' => "Your friends' videos",
		'videos:friends' => "%s's friends videos",
		'videos:all' => "All site videos",

		/*Actions*/
	    'videos:upload' => 'Upload',
	    'videos:addvideo' => 'Upload a video',
	    
	    /*Probmlems*/
	    'video:problem:emptyormax' => 'Problem uploading video.',
		
		'video:delete' => 'Delete Video',
		'video:delete:confirm' => 'Are you sure remove video?',
		
		'video:needflash' => 'You need flash player 8 and javascript for view the video.',
		
 		'video:by' => 'Uploaded by,',
 		
 		/*River*/
		
		'video:river:created' => "%s uploader",
		'video:river:item' => "a video",
		'video:river:annotate' => "%s comment",

		/*Control*/
		'video:next' => "next >>",
		'video:back' => "<< back",
	
		/*Video Settings*/
		'video:settings' => 'Setting Video Plugin',
 		'video:problem:configure' => 'Problem with configuration',
 		'video:problem:configure:info' => 'You must configure module first. Forward the link',
		
		/*Form Settings*/
 		'video:label:username' => "Youtube username",
		'video:label:password' => "Passeord",
		'video:label:developer_key' => "Developer key",
		'video:label:client_id' => "Client Id",
		'video:label:authentification_url' => "Authentification Url",
		'video:label:service' => "Service",
		'video:label:source' => "Source",
		'video:label:application_id' => "Application Id",
		'video:label:default_tag' => "Default Tag",
		'video:label:optionsvisibility' => "Options access",
	
		'video:access:public' => "Public video",
		'video:access:private' => "Private video",
	
		'video:deleted' => "Video deleted",
		'video:deletefailed' => "Deleted faied. Try again.",
	
		/*Widgets*/
		'video:widget' => "Videos",
		'video:more' => "More videos",
		'video:created' => 'uploaded',
		'video:num_videos' => 'Number',

	);
	
	add_translation("en",$english);
?>