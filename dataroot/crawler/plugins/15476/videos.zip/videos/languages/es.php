<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	$spanish = array(

	    /*Videos*/
	    'video' => "Video",
	    'videos' => "Videos",
	    'videos:user' => "Videos de %s",
	    'videos:yours' => "Tus videos",
	    'videos:yours:friends' => 'Videos de tus amigos',
		'videos:friends' => "Videos de amigos de %s",
		'videos:all' => "Todos los videos",
		'item:object:video' => "Videos",
	
	    
		/*Acciones para la sección videos*/
	    'videos:upload' => 'Subir un video',
	    'videos:addvideo' => 'Sube tu video',
	    
	    /*Probmlemas y errores*/
	    'video:problem:emptyormax' => 'Problemas subiendo su video, verifique que haya seleccionado uno o corrobore que no supere los 10mb.',
		
		'video:delete' => 'Borrar Video',
		'video:delete:confirm' => '¿Estás seguro que deseas eliminar este video?',
		
		'video:needflash' => 'Necesitas flash player 8 y Javascript activado para poder ver este video.',
		
 		'video:by' => 'Video subido por,',
 		
 		/*River*/
		
		'video:river:created' => "%s subió",
		'video:river:item' => "un video",
		'video:river:annotate' => "%s comentó en",

		/*Control*/
		'video:next' => "próximo >>",
		'video:back' => "<< anterior",
	
		/*Video Settings*/
		'video:settings' => 'Configuración del Plugin de Videos',
 		'video:problem:configure' => 'Problema en la configuración del plugin de videos',
 		'video:problem:configure:info' => 'Para que funcione el modulo de videos usted debe configurar primero el módulo, puede hacerlo siguiendo el siguiente link',
		
		/*Form Settings*/
 		'video:label:username' => "Usuario youtube",
		'video:label:password' => "Contraseña",
		'video:label:developer_key' => "Developer key",
		'video:label:client_id' => "Client Id",
		'video:label:authentification_url' => "Url de autentificación",
		'video:label:service' => "Servicio",
		'video:label:source' => "Fuentes",
		'video:label:application_id' => "Id de la Aplicación",
		'video:label:default_tag' => "Etiqueta por defecto",
		'video:label:optionsvisibility' => "Acceso del video",
	
		'video:access:public' => "Video público",
		'video:access:private' => "Video privado",
	
		'video:deleted' => "Video Eliminado",
		'video:deletefailed' => "No se puede eliminar el video, intente más tarde.",
	
		/*Widgets*/
		'video:widget' => "Videos",
		'video:more' => "Más videos",
		'video:created' => 'fue subido',
		'video:num_videos' => 'Número de videos',
			
	
	);
	
	add_translation("es",$spanish);
?>