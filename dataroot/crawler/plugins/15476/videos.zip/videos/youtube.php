<?php

	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	//Archivo que se encarga de conectar con la API de youtube
	set_include_path($CONFIG->pluginspath . "videos/vendors");
	
	require_once("Zend/Loader.php");
	
	
	$oConfig = $CONFIG->mod->videos->config;
	
	require_once("Zend/functionsYoutube.php");
	
	
	Zend_Loader::loadClass('Zend_Gdata_YouTube');
	$yt = new Zend_Gdata_YouTube();
	
	Zend_Loader::loadClass('Zend_Gdata_AuthSub');
	Zend_Loader::loadClass('Zend_Gdata_ClientLogin');

	
	$sHttpClient = Zend_Gdata_ClientLogin::getHttpClient(
														$username = $oConfig->username,
														$password = $oConfig->password,
														$service = $oConfig->service,
														$client = null,
														$source = $oConfig->source,
														$loginToken = null,
														$loginCaptcha = null,
														$oConfig->authentification_url);
														
	
	$sDeveloperKey = $oConfig->developer_key;
	
	$sApplicationId = $oConfig->application_id;
	
	$sClientId = $oConfig->client_id;
	
	$yt = new Zend_Gdata_Youtube($sHttpClient,$sApplicationId,$sClientId,$sDeveloperKey);
	
	
	/*Basic functions*/
	if(!function_exists('getVideoEntry'))
    {
		function getVideoEntry ($videoFeed)
	    {
		    $count = 1;
	        foreach ($videoFeed as $videoEntry) 
	        {
	            $oEntrada = $videoEntry;
	            //break;
	        }
	    
	        return $oEntrada;
	    }
    }
    
    if(!function_exists('fragmento'))
    {
        #Función que muestra el fragmento de una cadena
		function fragmento($sString, $iLargo)
		{
			return (strlen($sString) > $iLargo) ? substr($sString, 0, $iLargo) . '...' : $sString;
		}
    }
	
?>