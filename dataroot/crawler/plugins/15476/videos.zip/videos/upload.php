<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	gatekeeper();
	global $CONFIG;
	
	
	// Get the current page's owner
		if ($user = (int) get_input('container_guid')) 
		{
			$user_entity = get_entity($user);
			
			//pr($user_entity);
			
			//if album does not exist or user does not have access
			if(!$user_entity || !$user_entity->canEdit())
				forward('pg/videos/owned/');
			
			//set group to "real" container
			$container = $user_entity->container_guid;				
			set_page_owner($container);
		}
		else
			forward('pg/videos/owned/');
				
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($page_owner->getGUID());
		}
		
	set_context('videos');
	$title = elgg_echo('videos:addvideo');
	
	$area2 .= '<h2><a href="' . $user_entity->getURL() . '">'. $user_entity->title. '</a></h2>';
	
	$area2 .= elgg_view("video/forms/upload", array('user' => $user ) );	
	
	$body = elgg_view_layout('two_column_left_sidebar', '', $area2);
	
	page_draw($title, $body);
?>