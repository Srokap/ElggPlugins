<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	global $CONFIG;
	
	//this is for image uploads only. Image edits are handled by edit.php form
	$container_guid = get_input('container_guid');
	$access_id = get_entity($container_guid)->access_id;
	
	$sTitle='';
	$sDescription='';
	$sTags='';
	
	if(!configure_video())
	{
		forward("mod/videos/");
	}
?>

<form action="<?php echo $vars['url']; ?>action/video/upload" enctype="multipart/form-data" method="post">
	<?php if($container_guid): ?>
			<input type="hidden" name="container_guid" value="'.$container_guid.'" />
		<?php endif; ?>
	
	<p>
		<label><?php echo elgg_echo("title"); ?></label>
	    <?= elgg_view('input/text', array('internalname' => 'title', 'value' => $sTitle)); ?>
	</p>
	
	<p>
		<label><?php echo elgg_echo("description"); ?></label>
	    <?= elgg_view('input/longtext', array('internalname' => 'description', 'value' => $sDescription)); ?>
	</p>
	
	<p>
		<label><?php echo elgg_echo("video"); ?></label>
	    <?= elgg_view("input/file",array('internalname' => "upload_video")); ?>
	</p>
	
	<p>
		<label><?php echo elgg_echo("tags"); ?></label>
	    <?= elgg_view('input/tags', array('internalname' => 'tags', 'value' => $sTags)) ?>
	</p>
			
		
	<p>
		<label><?php echo sprintf(elgg_echo('access'), 'video'); ?></label>
		<?= elgg_view('input/access', array('internalname' => 'access_id', 'value' => $access_id)); ?>						
	</p>
	
	<p>	
		<input type="submit" value="<?php echo elgg_echo("save"); ?>" />
	</p>

</form>