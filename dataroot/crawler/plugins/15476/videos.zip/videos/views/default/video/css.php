<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */
?>

/* video gallery */
td.search_gallery_item 	{padding:0px; margin:0px; background:transparent;}
td.search_gallery_item:hover {background:none;}
	
.video_images{float:left; margin:4px; padding:5px; border:1px solid #999; text-align:center; margin:16px; background-color:#FFF;}

.video_images p {width:130px; color:#333; overflow:hidden; display:block;}
.video_images img {/*border:2px solid #3B699F; border-bottom:3px solid #3B699F; border-top:3px solid #3B699F*/}

#pages_breadcrumbs {color:#1F130F; font-size:0.9em; padding:0 32px 0 0; text-align:right;}
#pages_breadcrumbs a{color:#1F130F;}

#video_controls {text-align:center;}
#video_nav {padding:10px; 0px;}

/* independent video view only */

#video_full{ text-align:center; margin:10px;}
#video_full img{ padding:5px; border:1px solid #ccc; margin:7px 0;}


/* ---------  videos river items ------------   */

.river_video_create { background: url(<?php echo $vars['url']; ?>mod/videos/graphics/icons/river_icon_video.png) no-repeat 0 0;}

.pagination { clear:both !important;}

/* ---------- status --------------*/
div.estado 	{font-size:1em; padding:6px; border:1px solid red;}
div.estado a{color:#666666; vertical-align:bottom; }
div.estado a:hover{background:none; }

div.success { background-color:#ACE991; border:2px solid #275812; color:#275812;}
div.error 	{ background-color:#EEA8A8; border:2px solid #AC2222; color:#AC2222;}
	