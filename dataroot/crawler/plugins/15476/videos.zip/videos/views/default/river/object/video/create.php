<?php

	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	$statement = $vars['statement'];
	$performed_by = $statement->getSubject();
	$object = $statement->getObject();
	
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string = sprintf(elgg_echo("video:river:created"),$url) . " ";
	$string .= "<a href=\"" . $object->getURL() . "\">" . elgg_echo("video:river:item") . "</a>";

	echo $string;
	
?>