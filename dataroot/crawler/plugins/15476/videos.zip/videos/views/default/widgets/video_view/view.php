<?php

	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */
	
	//the number of files to display
	$number = (int)$vars['entity']->num_display;
	
	if (!$number)
		$number = 5;
	
	$owner = page_owner_entity();	
	$owner_videos = get_entities("object", "video", page_owner(), $number);

	if ($owner_videos) {
			
    	echo '<div id="video_widget_container">';
        	 
		foreach($owner_videos as $video){
	
			//get video cover if one was set 
			if($video->cover)
				$video_cover = '<img src="' . $video->cover .'" border="0" class="video_cover"  alt=""/>';
			else
				$video_cover = '<img src="'.$vars['url'].'mod/videos/graphics/video_processing.jpg" class="video_cover" alt="">';

			?>
			<div class="video_widget_single_item">			
				<div class="video_widget_title"><a href="<?php echo $video->getURL();?>"><?php echo $video->title;?></a></div>
				<div class="video_widget_timestamp"><?= elgg_echo('video:created')?> <?php echo friendly_time($video->time_created);?></div>
				<?php
				//get the number of comments
				$numcomments = elgg_count_comments($video);
				if ($numcomments)
					echo "<a href=\"{$video->getURL()}\">" . sprintf(elgg_echo("comments")) . " (" . $numcomments . ")</a><br>";
				?>
				<a href="<?php echo $video->getURL();?>"><?php echo $video_cover;?></a>
			</div>
		<?
		}
        	      	
        //get a link to the users video
        $users_video_url = $vars['url'] . "pg/videos/owned/" . $owner->username;
        echo "<a href=\"{$users_video_url}\">" . elgg_echo('video:more') . "</a>";
		echo "</div>";
        		
	} else {
		
		echo elgg_echo("video:none");
		
	}

?>