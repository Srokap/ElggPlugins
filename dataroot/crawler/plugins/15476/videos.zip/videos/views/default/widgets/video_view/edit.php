<?php
	
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */


?>

<p>
		<?php echo elgg_echo("video:num_videos"); ?>:
		
		<?
			if($vars['entity']->num_display == '') $vars['entity']->num_display = 6;
		?>
		<select name="params[num_display]">
		    <option value="1" <?php if($vars['entity']->num_display == 1) echo "selected"; ?>>1</option>
		    <option value="2" <?php if($vars['entity']->num_display == 2) echo "selected"; ?>>2</option>
		    <option value="3" <?php if($vars['entity']->num_display == 3) echo "selected"; ?>>3</option>
		    <option value="4" <?php if($vars['entity']->num_display == 4) echo "selected"; ?>>4</option>
		    <option value="5" <?php if($vars['entity']->num_display == 5) echo "selected"; ?>>5</option>
		    <option value="6" <?php if($vars['entity']->num_display == 6) echo "selected"; ?>>6</option>
		    <option value="7" <?php if($vars['entity']->num_display == 7) echo "selected"; ?>>7</option>
		    <option value="8" <?php if($vars['entity']->num_display == 8) echo "selected"; ?>>8</option>
		    <option value="9" <?php if($vars['entity']->num_display == 9) echo "selected"; ?>>9</option>
		    <option value="10" <?php if($vars['entity']->num_display == 10) echo "selected"; ?>>10</option>
		    <option value="15" <?php if($vars['entity']->num_display == 15) echo "selected"; ?>>15</option>
		    <option value="20" <?php if($vars['entity']->num_display == 20) echo "selected"; ?>>20</option>
		</select>
</p>
