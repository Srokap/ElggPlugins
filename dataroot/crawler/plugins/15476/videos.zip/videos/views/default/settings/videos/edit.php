<?php
	
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	$oConfig = $vars['config']->mod->videos->config;
	
	if(empty($oConfig->authentification_url)) $oConfig->authentification_url = VIDEO_AUTHENTICATION_URL;
	if(empty($oConfig->video_service)) $oConfig->service = VIDEO_SERVICE;
	if(empty($oConfig->video_source)) $oConfig->source = VIDEO_SOURCE;
	if(empty($oConfig->application_id)) $oConfig->application_id = VIDEO_APPLICATION_ID;
	//if(is_null($oConfig->accessyoutube)) $oConfig->accessyoutube = VIDEO_ACCESS_YOUTUBE;
	if(empty($oConfig->default_tag)) $oConfig->default_tag = strtolower($vars['config']->site->name);

?>

<p>
	<h4><?php echo elgg_echo('video:label:username'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[username]', 'value' => $vars['entity']->username ));
	?>
</p>


<p>
	<h4><?php echo elgg_echo('video:label:password'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[password]', 'value' => $vars['entity']->password ));
	?>
</p>

<p>
	<h4><?php echo elgg_echo('video:label:developer_key'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[developer_key]', 'value' => $oConfig->developer_key ));
	?>
</p>

<p>
	<h4><?php echo elgg_echo('video:label:client_id'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[client_id]', 'value' => $oConfig->client_id ));
	?>
</p>


<p>
	<h4><?php echo elgg_echo('video:label:authentification_url'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[authentification_url]', 'value' => $oConfig->authentification_url ));
	?>
</p>

<p>
	<h4><?php echo elgg_echo('video:label:service'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[service]', 'value' => $oConfig->service ));
	?>
</p>

<p>
	<h4><?php echo elgg_echo('video:label:source'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[source]', 'value' => $oConfig->source ));
	?>
</p>

<p>
	<h4><?php echo elgg_echo('video:label:application_id'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[application_id]', 'value' => $oConfig->application_id ));
	?>
</p>

<p>
	<h4><?php echo elgg_echo('video:label:default_tag'); ?>: </h4>
	<?php
		echo elgg_view('input/text', array('internalname' => 'params[default_tag]', 'value' => $oConfig->default_tag ));
	?>
</p>

<?php
/*
<p>
	<h4><?php echo elgg_echo('video:label:optionsvisibility'); ?>: </h4>
	<?php
		echo elgg_view('input/pulldown', array('internalname' => 'params[accessyoutube]', 'value' => $oConfig->accessyoutube, 'options_values' => array('0' => elgg_echo('video:access:public'),'1' => elgg_echo('video:access:private')) ));
	?>
</p>
*/
?>
