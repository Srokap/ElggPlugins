<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

   	global $CONFIG;	
	$video = $vars['entity'];
	$video_guid = $video->getGUID();
	$tags = $video->tags;
	$title = $video->title;
	$desc = $video->description;
	$owner = $vars['entity']->getOwnerEntity();
	$friendlytime = friendly_time($vars['entity']->time_created);
	
	
	$oVideo->guid = $video->getGUID();
	$oVideo->title = $video->title;
	$oVideo->description = $video->description;
	$oVideo->youtube_id = $video->youtube_id;
	$oVideo->developer_tag = $video->developer_tag;
	$oVideo->cover = $video->cover;
	$oVideo->frindlytime = friendly_time($video->time_created);
	$oVideo->thumbnail_main = "{$vars['url']}mod/videos/graphics/video_processing.jpg";
	
	if(isset($oVideo->cover) && !empty($oVideo->cover))
	{
		$oVideo->thumbnail_main = $oVideo->cover;
	}else
	{
		require_once($CONFIG->pluginspath . "videos/youtube.php");
		// create an array to hold id's to find
		$videoIdsToFind = array($oVideo->youtube_id);
		
		// Then use a read-write feed to actually perform the deletion(s)
		$myVideoFeed = $yt->getUserUploads($CONFIG->mod->videos->config->username);
		
		
		foreach($myVideoFeed as $videoEntry) 
		{
		    $id = $videoEntry->getVideoId();
		    if(in_array($id, $videoIdsToFind))
		    {
		    	$oVideo->instance_video = $videoEntry;
		    	
		    	if(isset($oVideo->instance_video))
		    	{
			    	$oVideo->thumbnails = $oVideo->instance_video->getVideoThumbnails();
			    	$oVideo->thumbnail_main = $oVideo->thumbnails[2]['url'];
			    	
			    	if($oVideo->thumbnails[2]['url'])
				    {
				        $oVideo->thumbnail_main = $oVideo->thumbnails[2]['url'];
				        //Guardamos el thumb encontrado solo si paso 30 min de subido
				        //es para darle tiempo a youtube hasta que procese la imagen
				        //hasta que encontremos una manera mejor de identificar cuando muestra
				        //las imagenes de que esta procesando el video de las finales
				        
				        $iTimeDiff = round((time() - (int) $vars['entity']->time_created)/60) /*this is minutes*/;
				        if($iTimeDiff>30)
		    			{
				        	$video->cover = $oVideo->thumbnails[2]['url'];
		    			}
				    }
		    	}
		    }
		}
	} // end if(isset($oVideo->cover) && !empty($oVideo->cover))
		
	
	
	
if (get_context() == "search") { //if this is the search view
		
        if (get_input('search_viewtype') == "gallery") 
        {
			?> 
			<div class="video_images">
				<a title="<?= $title; ?>" href="<?php echo $video->getURL();?>">
					<p><?= fragmento($title,15) ?></p>
					<img src="<?=  $oVideo->thumbnail_main . '?' . rand(0,999) /*for caching*/ ?>" border="0" alt="thumbnail"/>
				</a>
			</div>
			<?php
		}
		else{
			//image list-entity view
			$info = '<p><a href="' .$video->getURL(). '">'.$title.'</a></p>';
			$info .= "<p class=\"owner_timestamp\"><a href=\"{$vars['url']}pg/videos/owned/{$owner->username}\">{$owner->name}</a> {$friendlytime}";
			$numcomments = elgg_count_comments($video);
			if ($numcomments)
				$info .= ", <a href=\"{$video->getURL()}\">" . sprintf(elgg_echo("comments")) . " (" . $numcomments . ")</a>";
			$info .= "</p>";				
			$icon = "<a href=\"{$video->getURL()}\">" . elgg_view("videos/icon", array("mimetype" => $mime, 'thumbnail' => $video->thumbnail, 'file_guid' => $video_guid, 'size' => 'small')) . "</a>";
			
			echo elgg_view_listing($icon, $info);
		}
}
else{ //videos image display
		
	if (!$vars['full']) { //simple gallery view
	/*
?> 
		
		<div class="album_images">
			<a href="<?php echo $video->getURL();?>"><img src="<?php echo $vars['url'];?>mod/videos/thumbnail.php?file_guid=<?php echo $video_guid;?>&size=small" border="0" alt="thumbnail"/></a>
		</div>
<?php
	*/
	}
	else{  // individual full image view 
			
		$album = get_entity($video->container_guid);
	
	//compile back | next links	
		$current = array_search($video_guid, $_SESSION['image_sort']);
	
		if(!$current){  // means we are no longer using the correct album array
			
			//rebuild the array ->
			$count = get_entities("object","video", $album->guid, '', 999);
			$_SESSION['image_sort'] = array();
	
			foreach($count as $image){
				array_push($_SESSION['image_sort'], $image->guid);
			}	
			
			$current = array_search($video_guid, $_SESSION['image_sort']);	
		}
		
		if(!$current == 0)
			$back = '<a href="' .$vars['url'] . 'pg/videos/view/' . $_SESSION['image_sort'][$current-1] . '">' . elgg_echo('video:back') . ' </a> | ';
		
		if(array_key_exists(($current+1), $_SESSION['image_sort']))
			$next = '<a href="' .$vars['url'] . 'pg/videos/view/' . $_SESSION['image_sort'][$current+1] . '">' . elgg_echo('video:next') . ' </a>';	

			
			
?>	
	<div id="pages_breadcrumbs">
		<a href="<?php echo $vars['url'] . "pg/videos/owned/" . page_owner_entity()->username ;?>">Videos</a> > 
		<a href="<?php echo $album->getURL(); ?>"><?php echo $album->title; ?></a> > 
		<?php echo $title; ?>	
	</div>
<?			
	echo '<h2 id="video_title">' . $title . '</h2>';
	echo '<div id="video_desc">' . autop($desc) . '</div>';		
	echo '<div id="video_full">';
	  echo '<div id="video_nav">' . $back . $next . '</div>';	  
	  if($next) echo '<a href="' . $vars['url'] . 'pg/videos/view/' . $_SESSION['image_sort'][$current+1] . '">';
	  
?>

	<div id="ytapiplayer">
    	<?php elgg_echo('video:needflash') ?>
  	</div>	  
	  
<?
	  //echo '<img src="' . $vars['url'] . 'mod/tidypics/thumbnail.php?file_guid=' . $video_guid . '&size=large" border="0" alt="' . $title . '"/>';
	  if($next) echo '</a>';
	echo '</div>';
		
		if ($video->canEdit()) {	// add edit controls
						
?>
			<div id="video_controls">
				<?php echo elgg_view('output/confirmlink',array('href' => $vars['url'] . "action/video/delete?file=" . $video->getGUID(),
																'text' => elgg_echo("video:delete"),
																'confirm' => elgg_echo("video:delete:confirm"))) ?>
			</div>			
		

<?php		
		}		
		
?>		
		<div id="video_info">
			<div class="object_tag_string"><?php echo elgg_view('output/tags',array('value' => $tags));?></div>	
			<?php echo elgg_echo('video:by');?> <b><a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $owner->username; ?>"><?php echo $owner->name; ?></a></b>  <?php echo $friendlytime; ?><br>		
		</div>
<?php 
		echo elgg_view_comments($video);	
?>

		<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/videos/js/swfobject.js"></script>
		<script>
		
		
		 
		
		    var params = { allowScriptAccess: "always" };
		    var atts = { id: "myytplayer" };
		    swfobject.embedSWF("http://www.youtube.com/v/<?= $oVideo->youtube_id?>&enablejsapi=1&playerapiid=ytplayer", 
		                       "ytapiplayer", "425", "356", "8", null, null, params, atts);
		
		</script>
<?php
		
	}
	
}

?>