<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	$username = get_input('username');
	
	if(page_owner() == $_SESSION['guid'])
		$area2 = elgg_view_title($title = elgg_echo('videos:yours:friends'));
	else
		$area2 = elgg_view_title($title = sprintf(elgg_echo('videos:friends'), "$username"));
	
	set_context('search');
	set_input('search_viewtype', 'gallery');
	$area2 .= list_user_friends_objects(page_owner(), 'video');
	
	set_context('videos');
	$body = elgg_view_layout('two_column_left_sidebar', '', $area2);
	
	// Finally draw the page
	page_draw(sprintf(elgg_echo("videos:friends"),$_SESSION['user']->name), $body);
?>