<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	global $CONFIG;
		
	// Get common variables
	
	$container_guid = (int) get_input('container_guid', 0);
	if (!$container_guid)
		$container_guid == $_SESSION['user']->getGUID();
			
	//Seteamos en falso la bandea que nos dira si se subio o no un archivo
	$bSubio = false;
	
	if(!isset($_FILES['upload_video']))
	{
	    $error = elgg_echo("video:problem:emptyormax");	
		register_error($error);
		echo "$error <br />";
	}
	else
	{
	    
	    //testeamos de poder leer toda la info enviada
	    $sTitle = get_input('title');
	    $sDescription = get_input('description');
	    
	    $sTags = get_input('tags');
	    
	    if(empty($sTags))
	    {
	        $sTags = $CONFIG->mod->videos->config->default_tag;
	    }else
	    {
	        $sTags .= ",{$CONFIG->mod->videos->config->default_tag}";
	    }
	    
	    
	    $iContainerGUID = $_SESSION['user']->getGUID();
	    
	    $sDeveloperTag = "{$CONFIG->mod->videos->config->default_tag}{$iContainerGUID}" . time();
		
	    $iAccessId = (int) get_input("access_id");
	    $sDescription = strip_tags(substr($sDescription,0,300));
	    
	    //Cargamos el video
	    //Lo borramos asi no tiene problema con las imágenes
	    //Cargamos toda la info de youtube

		// Pero primero hacemos las comprobaciones del archivo
		$aFile = $_FILES['upload_video'];
	

		require_once($CONFIG->pluginspath . "videos/youtube.php");
	    
		
		$sType = $aFile['type'];
	
		//Creamos la entrada de videos
		$myvideo = new Zend_Gdata_YouTube_VideoEntry();
		
		
		$filesource = $yt->newMediaFileSource($aFile['tmp_name']);
		$filesource->setContentType($sType);
		$filesource->setSlug($aFile['tmp_name']);
		
		$myvideo->setMediaSource($filesource);
		
		
		$myvideo->setVideoTitle($sTitle);
		$myvideo->setVideoDescription($sDescription);
		
		$myvideo->setVideoCategory('Comedy');
		$myvideo->setVideoTags($sTags);
		
		$myvideo->setVideoDeveloperTags(array($sDeveloperTag));
		
		
		//Agregar en las opciones que se pueda configurar si los videos van a ser públicos o no
		//if($CONFIG->mod->videos->config->accessyoutube) $myvideo->setVideoPrivate();
		
		$uploadUrl = 'http://uploads.gdata.youtube.com/feeds/users/default/uploads';
		
		
		$newEntry = null;
		
		
		try
		{
			$newEntry = $yt->insertEntry($myvideo, $uploadUrl, 'Zend_Gdata_YouTube_VideoEntry');
			$iYouTubeId = $newEntry->getVideoId(); /*Id que nos devuelve el id del video recien subido*/
		} 
		catch(Zend_Gdata_App_HttpException $httpException)
		{
		    echo $httpException->getRawResponseBody() . "<br />";
			//system_message($httpException->getRawResponseBody());
		}catch (Zend_Gdata_App_Exception $e)
		{
		    echo $e->getMessage();
			//system_message($e->getMessage());
		}
		
		//Comprobamos ahora el estado
		// check if video is in draft status
		try 
		{
			$control = $newEntry->getControl();
		} 
		catch (Zend_Gdata_App_Exception $e) 
		{
			system_message($e->getMessage());
		}
		if ($control instanceof Zend_Gdata_App_Extension_Control) 
		{
			if ($control->getDraft() != null && $control->getDraft()->getText() == 'yes')
			{
				$state = $newEntry->getVideoState();
				if ($state instanceof Zend_Gdata_YouTube_Extension_State) 
				{
					system_message('Upload status: '. $state->getName() .' '.  $state->getText());
					$bSubio = true;
				} else 
				{
					system_message("Not able to retrieve the video status information yet. Please try again shortly.");
				}
			}
		}
		
	    
	    //Borramos la entrada del video para que no traiga problema con las imágenes
	    unset($_FILES['upload_video']);
	}
	
	if($bSubio && $iYouTubeId) /*Si el archivo se subio ahora lo guardamos como una entidad ;)*/
	{
	    // Initialise a new ElggObject
		$oVideo = new ElggObject();
    	
		// Tell the system it's a video
        $oVideo->subtype = "video";
	
        // Set its owner to the current user
		$oVideo->owner_guid = $iContainerGUID;
	    
		// For now, set its access to public (we'll add an access dropdown shortly)
		$oVideo->access_id = $iAccessId;
	
		// Set its nombre and description appropriately
		$oVideo->title = $sTitle;
		$oVideo->description = $sDescription;
	
		// Before we can set metadata, we need to save the caballo post
	      $iIdVideo = $oVideo->save();
			if (!$iIdVideo) {
				register_error(elgg_echo("video:save:failure"));
				forward("mod/videos/upload.php");
			}
	    
		// Leemos los datos que nos interesan del caballo subido		
	        
		$oVideo->developer_tag = $sDeveloperTag;
		
		//Guardamos el ID que nos devolvio youtube
		$oVideo->youtube_id = $iYouTubeId;
		
		// Convert string of tags into a preformatted array
        $aTags = string_to_tag_array($sTags);
		        
		// Now let's add tags. We can pass an array directly to the object property! Easy.
		if (is_array($aTags)) {
			$oVideo->tags = $aTags;
		}
		
		// Forward to the main video page
	    forward("mod/videos/");
	    
	}
	
	
	
	

?>