<?php

	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	if(!configure_video())
	{
		forward("mod/videos/");
	}

	$guid = (int) get_input('file');
	
	
	if ($file = get_entity($guid)) 
	{    
	    $youtube_id = $file->youtube_id;
	    
	    $forward_url = 'pg/videos/owned/' . $_SESSION['user']->username;

        if (!$file->delete()) 
        {
		    register_error(elgg_echo("video:deletefailed"));
        } else 
        {
		    system_message(elgg_echo("video:deleted"));
		    
		    require_once($CONFIG->pluginspath . "videos/youtube.php");
			
	        // create an array to hold id's to be deleted
			$videoIdsToBeDeleted = array($youtube_id);
			
			// Then use a read-write feed to actually perform the deletion(s)
			$myVideoFeed = $yt->getUserUploads($CONFIG->mod->videos->config->username);
			
			foreach($myVideoFeed as $videoEntry) 
			{
			    $id = $videoEntry->getVideoId();
			    if(in_array($id, $videoIdsToBeDeleted))
			    {
			        $yt->delete($videoEntry);
			    }
			
			} 
			
        }
		
	}
	else 
	{
		register_error(elgg_echo("video:deletefailed"));			
	}
		
	forward($forward_url);

?>