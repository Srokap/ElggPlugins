<?php
	/**
	 * Youtube Gallery
	 * 
	 * @author Pedro Prez
	 * @copyright (c) Pedro Prez 2008-2009
	 * @link http://community.elgg.org/pg/profile/pedroprez
	 * @license GNU General Public License (GPL) version 2
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	$owner = page_owner_entity();
	
	if(!configure_video())
	{
		
		$sTitle = elgg_echo("video:problem:configure");
		
		$area2 = elgg_view_title($title = $sTitle);
	
		$link = '<p><a href="'.$CONFIG->wwwroot . 'pg/admin/plugins/">'.elgg_echo('video:settings').'</a></p>';
		
		$area2 .= '<div class="estado error"><p>' . elgg_echo('video:problem:configure:info') . '</p>' . $link .'</div>';
		
		
	}else
	{
	
		
			
		//set the title	
		$sTitle = sprintf(elgg_echo('videos:user'), $owner->name);
		$area2 = elgg_view_title($title = $sTitle);
	
		$area2 .= '<a href="'.$CONFIG->wwwroot . 'pg/videos/upload/">'.elgg_echo('videos:upload').'</a><br><br>';	
			
		// Get objects
		set_context('search');
		set_input('search_viewtype', 'gallery');
		$area2 .= list_entities("object","video",$owner->guid,8);
	}
		
	set_context('videos');
	$body = elgg_view_layout('two_column_left_sidebar', '', $area2);
	
		
	// Finally draw the page
	page_draw($sTitle, $body);
?>