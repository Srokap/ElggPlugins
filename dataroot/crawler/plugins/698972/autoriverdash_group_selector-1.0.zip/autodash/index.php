<?php

/**
 * Elgg river dashboard plugin index page
 *
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public
License version 2
 * @author Curverider Ltd <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.org/
 */

require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
$thewireon = get_plugin_setting("addthewire", "autodash");
//gatekeeper();
//$thewireon = get_plugin_setting("addthewire", "autodash");
$content = get_input('content','');
$content = explode(',' ,$content);
$type = $content[0];
if (isset($content[1])) {
	$subtype = $content[1];
} else {
	$subtype = '';
}
$orient = get_input('display');

if ($type == 'all') {
	$type = '';
	$subtype = '';
}

$group_guid = get_input('group_content');
if (isset($group_orient)){
$type = $group_orient;
}

$callback = get_input('callback');

$body = '';
if (empty($callback)) {

	if (get_plugin_setting('useasdashboard', 'riverdashboard') == 'yes') {
		$title = elgg_echo('dashboard');
	} else {
		$title = elgg_echo('activity');
	}

	if (isloggedin()){
	//set a view to display a welcome message
	$body .= elgg_view("riverdashboard/welcome");

	//$area1 = elgg_view("riverdashboard/sitemessage");
	$area1 =  elgg_view('river_addon/hints', array('type' => 'hint'));
      }
		//set a view to display newest members
	$area1 .= elgg_view("riverdashboard/newestmembers");
	if (isloggedin()){
	$area1 .= elgg_view("river_addon/friends");
	}
	$area1 .= elgg_view("tag_cumulus/tag_cumulus");
	if (isloggedin()){
	$area1 .= elgg_view("river_addon/mygroups");
	}
	$area1 .= elgg_view("donation/donation");

	
}

switch($orient) {
		
	case 'mine':
		$subject_guid = get_loggedin_userid();
		$relationship_type = '';
		break;
	case 'friends':
		$subject_guid = get_loggedin_userid();
		$relationship_type = 'friend';
		break;
	default:
		$subject_guid = 0;
		$relationship_type = '';
		break;
}



$body .=elgg_view("autodash/refresh");
if ($thewireon == 'yes'){
if (isloggedin()){

$body .=elgg_view("activity/thewire");
}
}
$nav = elgg_view('riverdashboard/nav',array(
		'type' => $type,
		'subtype' => $subtype,
		'orient' => $orient,
		'group_orient' => $group_guid
));


if (($group_guid != '')&&($group_guid != 'none')){
		//$owner = page_owner_entity();
		//$group_guid = $owner->guid;
		$limit = 20;  // TODO: make configurable
		$pagination = true;
		$offset = (int) get_input('offset', 0);

		$limit = (int) $limit;
		$offset = (int) $offset;
	$sql = "SELECT {$CONFIG->dbprefix}river.id,
{$CONFIG->dbprefix}river.type, {$CONFIG->dbprefix}river.subtype,
{$CONFIG->dbprefix}river.action_type, {$CONFIG->dbprefix}river.access_id,
{$CONFIG->dbprefix}river.view, {$CONFIG->dbprefix}river.subject_guid,
{$CONFIG->dbprefix}river.object_guid, {$CONFIG->dbprefix}river.posted FROM
{$CONFIG->dbprefix}river INNER JOIN {$CONFIG->dbprefix}entities AS entities1 ON
{$CONFIG->dbprefix}river.object_guid = entities1.guid INNER JOIN
{$CONFIG->dbprefix}entities AS entities2 ON entities1.container_guid =
entities2.guid WHERE ";
if ($subtype != ''){
$sql .= "{$CONFIG->dbprefix}river.subtype = \"$subtype\" AND {$CONFIG->dbprefix}river.type = \"object\" AND ";
}

if (empty($relationship_type)) {
		if (!empty($subject_guid)) {
			if (!is_array($subject_guid)) {
				$sql .= " {$CONFIG->dbprefix}river.subject_guid = {$subject_guid} AND ";
			} else {
				$sql .= " {$CONFIG->dbprefix}river.subject_guid in (" . implode(',',$subject_guid) . ") AND ";
			}
		}
	} else {
		if (!is_array($subject_guid)) {
			if ($entities = elgg_get_entities_from_relationship(array(
				'relationship' => $relationship_type, 
				'relationship_guid' => $subject_guid, 
				'limit' => 9999))
			) {
				$guids = array();
				foreach($entities as $entity) {
					$guids[] = (int) $entity->guid;
				}
				// $guids[] = $subject_guid;
				$sql .= " {$CONFIG->dbprefix}river.subject_guid in (" . implode(',',$guids) . ") AND ";
			}
		}
	}

$sql .= "(entities2.guid = $group_guid OR
{$CONFIG->dbprefix}river.object_guid = $group_guid) ORDER BY posted DESC limit
{$offset},{$limit}";

	$items = get_data($sql);

        if (count($items) > 0) {
	  if ($pagination) {
		$group_river = array_slice($items, $offset);
		}
		$river = elgg_view('river/item/list',array(
					'limit' => $limit,
					'offset' => $offset,
					'items' => $items,
					'pagination' => $pagination
		));
	}
	$content = '<div class="contentWrapper">' . $nav . $river . '</div>';
}
else
{
$river = elgg_view_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '');

// Replacing callback calls in the nav with something meaningless
$river = str_replace('callback=true', 'replaced=88,334', $river);

$content = elgg_view('page_elements/contentwrapper', array('body' => $nav . $river));
}

if (empty($callback)) {
	// Add RSS support to page
	global $autofeed;
	$autofeed = true;

	// display page
	$body .= elgg_view('riverdashboard/container', array('body' => $content . elgg_view('riverdashboard/js')));
	page_draw($title, elgg_view_layout('sidebar_boxes', $area1, $body));
} else {
	// ajax callback
	header("Content-type: text/html; charset=UTF-8");
	echo $content . elgg_view('riverdashboard/js');
}

