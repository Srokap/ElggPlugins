<?php 
$refreshvar .= '<script type="text/javascript">var autorefreshrate = '.get_plugin_setting("autorefreshrate", "autodash");
echo $refreshvar;
?>


var navup=0
var x
var t
var mousx=0
var mousy=0
var internalx
var internaly
var refreshId = setInterval(function()
{ 
$(document).ready(function(){
	
	
  $().mousemove(function(e){
     internalx = e.pageX
	 internaly = e.pageY
 
  });
});
if (mousx != internalx || mousy != internaly) {
	

     mousx = internalx;
	 mousy = internaly;
	


$('#river_container').load('<?php echo $CONFIG->wwwroot; ?>mod/autodash/index.php?callback=true&display=' + $('input#display').val() + '&content=' + $('select#content').val() + '&offset=' + navup + '&group_content=' + $('select#content_groups_filter').val());
}

}, autorefreshrate*3000);

function navigationback(){	
x = window.document.getElementById("content").value;	
navup = navup + 20;
$('#river_container').load('<?php echo $CONFIG->wwwroot; ?>mod/autodash/index.php?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup + '&group_content=' + $('select#content_groups_filter').val());
}
	
function navigationforward(){
x=window.document.getElementById("content").value;
	if (navup >= 20) {
		navup = navup - 20;
		$('#river_container').load('<?php echo $CONFIG->wwwroot; ?>mod/autodash/index.php?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val()+'&offset='+navup + '&group_content=' + $('select#content_groups_filter').val());
		}
}

function dashfilter (){
$('#river_container').load('<?php echo $CONFIG->wwwroot; ?>mod/autodash/index.php?callback=true&display='+$('input#display').val() + '&content=' + $('select#content').val() + '&group_content=' + $('select#content_groups_filter').val());
navup=0;
}

function navreset (){navup=0;}

</script>
