<?php 
	
	$autorefreshrate = $vars['entity']->autorefreshrate;
	if (!$autorefreshrate) $autorefreshrate = '30';
	
	$addthewire = $vars['entity']->addthewire;
	if (!$addthewire) $addthewire = 'no';
?>
<p>Autodash refresh rate in seconds</p>
<p> 

<?php
	echo elgg_view('input/tags',array('value' => $autorefreshrate,
									  'internalname' =>'params[autorefreshrate]')); ?>
</p>
<br/>

<p>
	<?php echo 'Add the wire to the Riverdashboard?'; ?>
	
	<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[addthewire]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $addthewire
		));
	?>
	</p>