Autodash 3.0

This mod gives ability to the riverdashboard, allowing it to auto update itself. There is also now an option to include the wire on the riverdashboard. 

It is set to refresh every 30 seconds. Changing the refresh time can easily be changed in the plug in settings. Autodash is now a bit aware of the user on the web page, only making a call to the server if the user is active. 

It will refresh consistently even with the dashboard navigational features, allowing the user to sort through the dashboard options.

I am releasing this as Autodash 3.0.

Important: This is plug in is for Elgg 1.7.4

Installation:

Make sure the riverdashboard module is enabled.

If you wish for the wire to be on the riverdashboard, make sure the wire plugin is enabled.

Extract into your mod directory and enable in Administration tool panel.