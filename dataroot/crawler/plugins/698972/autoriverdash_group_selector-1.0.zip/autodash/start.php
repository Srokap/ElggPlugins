<?php
	
    function autodash_init() {	
			global $CONFIG;
			$thewireon = get_plugin_setting("addthewire", "autodash");
			register_plugin_hook('index','system','autodash');	
			/* changing how autodash adds its js code 
			 * extends the sitemessage view instead of an override
			 */
			//elgg_extend_view('riverdashboard/sitemessage','autodash/refresh', 0);
			//elgg_extend_view('riverdashboard/container','autodash/adddiv', 1000);	
			register_page_handler('dashboard','dash_page_handler');	
			if ($thewireon == 'yes'){
		
			extend_view('activity/thewire', 'thewire/activity_view');	
			register_action("autodash/add",false,$CONFIG->pluginspath . "autodash/actions/thewire/add.php");
			register_action("autodash/riverdashboard/add",false,$CONFIG->pluginspath . "autodash/actions/riverdashboard/add.php");
			}
    }
    
	
		
		
		function dash_page_handler($page) {
        //override riverdashboard index for autodash
        @include(dirname(__FILE__) . "/index.php"); //this will be your new dashboard page
            
    }
	
	register_elgg_event_handler('init','system','autodash_init');
?>