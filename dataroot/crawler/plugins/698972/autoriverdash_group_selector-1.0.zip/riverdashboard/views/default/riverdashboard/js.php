<script type="text/javascript">
	// re-add avatar menus for new avatars
	setup_avatar_menu($('.river_item_list'));
</script>