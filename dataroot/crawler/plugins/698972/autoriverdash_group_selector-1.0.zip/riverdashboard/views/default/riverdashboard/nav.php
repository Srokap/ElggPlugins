<?php

/**
 * Elgg riverdashboard navigation view
 *
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.com/
 *
 */

$contents = array();
$contents['all'] = 'all';
if (!empty($vars['config']->registered_entities)) {
	foreach ($vars['config']->registered_entities as $type => $ar) {
		foreach ($vars['config']->registered_entities[$type] as $object) {
			if (!empty($object )) {
				$keyname = 'item:' . $type . ':' . $object;
			} else {
				$keyname = 'item:' . $type;
			}
			$contents[$keyname] = "{$type},{$object}";
		}
	}
}



$content_group_filters = array();
$content_group_filters['no group selected'] = 'no group selected';
$the_groups = elgg_get_entities(array('types' => 'group', 'owner_guid' => 0, 'limit' => '', 'offset' => '', 'full_view' => false));
foreach($the_groups as $a_group)
{
    $map[] = array('name' => $a_group->name,'group' => $a_group);
}
sort($map);

if (!empty($map)) {
	foreach ($map as $a_group) {
			$keyname = $a_group['name'];
			$content_group_filters[$keyname] = $a_group['group'];
			}
	}


$allselect = '';
$friendsselect = '';
$mineselect = '';
switch($vars['orient']) {
	case '':
		$allselect = 'class="selected"';
		break;
	case 'friends':
		$friendsselect = 'class="selected"';
		break;
	case 'mine':
		$mineselect = 'class="selected"';
		break;
}

?>

<?php
if (isloggedin()) {
?>
	<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li <?php echo $allselect; ?> ><a onclick="javascript:navreset();javascript:$('#river_container').load('<?php echo $vars['url']; ?>mod/autodash/index.php?type=&content=&callback=true'); return false;" href="?type=<?php echo $vars['type']; ?>&content=<?php echo $vars['subtype']; ?>"><?php echo elgg_echo('all'); ?></a></li>
			<li <?php echo $friendsselect; ?> ><a onclick="javascript:navreset();javascript:$('#river_container').load('<?php echo $vars['url']; ?>mod/autodash/index.php?type=&display=friends&content=&callback=true'); return false;" href="?type=<?php echo $vars['type']; ?>&display=friends&content=<?php echo $vars['subtype']; ?>"><?php echo elgg_echo('friends'); ?></a></li>
			<li <?php echo $mineselect; ?> ><a onclick="javascript:navreset();javascript:$('#river_container').load('<?php echo $vars['url']; ?>mod/autodash/index.php?type=&display=mine&content=&callback=true'); return false;" href="?type=<?php echo $vars['type']; ?>&display=mine&content=<?php echo $vars['subtype']; ?>"><?php echo elgg_echo('mine'); ?></a></li>
		</ul>
	</div>
<?php
}
?>

	<div class="riverdashboard_filtermenu"><?php echo elgg_echo('riverdashboard:filter_by_content'); ?>
		<select name="content" id="content" onchange="javascript:$('#river_container').load('<?php echo $vars['url']; ?>mod/riverdashboard/?callback=true&amp;display='+$('input#display').val() + '&amp;content=' + $('select#content').val() + '&amp;group_content=' + $('select#content_groups_filter').val());">
			<?php

			foreach($contents as $label => $content) {

				if (("{$vars['type']},{$vars['subtype']}" == $content) ||
						(empty($vars['subtype']) && $content == 'all')) {
					$selected = 'selected="selected"';
				} else {
					$selected = '';
				}
				echo "<option value=\"{$content}\" {$selected}>" . elgg_echo($label) . "</option>";
			}

?>
		</select>
		<input type="hidden" name="display" id="display" value="<?php echo htmlentities($vars['orient']); ?>" />
	<div id="content_groups_filter_div"><?php echo elgg_echo('riverdashboard:filter_by_groups'); ?>
	<select name="content_groups_filter" id="content_groups_filter" onchange="javascript:$('#river_container').load('<?php echo $vars['url']; ?>mod/riverdashboard/?callback=true&amp;display='+$('input#display').val() + '&amp;content=' + $('select#content').val() + '&amp;group_content=' + $('select#content_groups_filter').val());">
			<?php
			
			foreach($content_group_filters as $label => $content_group_filter) {
				if (isset($content_group_filter->guid)){
				    $content_group_value = $content_group_filter->guid;
				}
				else
				{
				    $content_group_value = 'none';
				}
				if (($vars['group_orient'] == $content_group_value) ||
						(empty($vars['group_orient']) && $content_group_value == 'none')) {
					$selected = 'selected="selected"';
				} else {
					$selected = '';	
				}

				echo '<option value="'. $content_group_value . '"' . $selected . ' >' .  elgg_echo($label) . '</option>';
			}

?>
		</select>
		</div>
		<!-- <input type="submit" value="<?php //echo elgg_echo('filter'); ?>" /> -->
	</div>
	<!-- </div> -->
