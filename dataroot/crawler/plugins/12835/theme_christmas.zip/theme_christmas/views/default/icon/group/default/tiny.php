<?php
	echo $vars['url'] . "mod/theme_christmas/graphics/group_icons/defaulttiny.gif";
?>