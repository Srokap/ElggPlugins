<?php

	/**
Biffby jule spotlight (sentralen)
	 */
?>

<table id="spotlight_table" width="100%"cellspacing="0">
	<tr>
		<td align="left" valign="top">
		<!-- spotlight LHS content -->
					<table id="spotlight_table_left_area" width="90%" cellspacing="0">
						<tr>
							<td colspan="3" align="left" valign="top">
							<h2>Om Biffby</h2>
							<p>Biffby.com er en helt ny nettside for ungdom i Norge! Vi &oslash;nsker at DU som bruker f&oslash;ler deg hjemme her.
							Sjekk ut "Mer Om Biffby" linkene under for mer informasjon!</p> 
							<!-- <p> :D<p> -->
							</td>
						</tr>
						
						<tr><td width="100%" height="10" colspan="3" align="left" valign="top"></td>	</tr>
						
						<tr>
							<td width="33%" align="left" valign="top">
							<h2>Mer Om Biffby</h2>
							
							<ul>
								<li><a href="http://biffby.com/om/regler">Lover og Regler</a></li>
								<li><a href="http://biffby.com/om/">Om Biffby</a></li>
							</ul>
							
							</td>
							<td width="33%" align="left" valign="top">
							<ul>
								<li><a href="http://news.elgg.org/pg/blog/marcus/read/42/import-and-export-in-elgg-10">Import and Export</a></li>
								<li><a href="http://news.elgg.org/pg/blog/bwerdmuller/read/38/events-and-auditing-in-elgg">Events and Auditing</li>
								<li><a href="http://news.elgg.org/pg/blog/bwerdmuller/read/31/translations-and-views-in-elgg-10">Translations and Views</li>
								<li><a href="http://news.elgg.org/pg/blog/bwerdmuller/read/41/access-control-in-elgg">Access controls</a></li>
							</ul>
							
							
							</td>
							<td width="33%" align="left" valign="top">
							<ul>
								<li><a href="http://news.elgg.org">Elgg news</a></li>
								<li><a href="http://elgg.com">Elgg services</a></li>
								<li><a href="http://elgg.com">Elgg support</a></li>
								<li><a href="http://elgg.com">Elgg hosting</a></li>
							</ul>
							
							</td>
						</tr>
					</table>
				<!-- /spotlight LHS content -->

		</td>		
		
		
		<td width="250" align="left" valign="top">
		<!-- spotlight RHS content -->
		<h2></h2>
					
		<ul>
		
		

			<img src="http://127.0.0.1/raffle.gif"></a>
<a>Reklame.</a>
		</ul>
		<!-- Dette e liksom kult for deg som ser koden! -->
		<a href="http://biffby.com"></a> 
		</td>
	</tr>
</table>