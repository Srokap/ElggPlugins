<?php
	echo $vars['url'] . "mod/theme_christmas/graphics/user_icons/defaultlarge.gif";
?>