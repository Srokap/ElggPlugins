<?php 
$group = $vars["group"];

if(is_plugin_enabled("blog")){
	$widget = $vars["widget"];
?>
<div class="group_widget">
<h2><?php echo elgg_echo('blog:group'); ?></h2>
<?php
	$context = get_context();
	set_context('search');
	$content = elgg_list_entities(array('types' => 'object',
										'subtypes' => 'blog',
										'container_guid' => $vars['group']->guid,
										'limit' => 5,
										'full_view' => FALSE,
										'pagination' => FALSE));
	set_context($context);
			if (can_write_to_container(0, $owner->guid)) {
	$add_url = "{$vars['url']}pg/blog/new/group:{$vars['group']->guid}/";
		}

    if ($content) {
		echo $content;

		$more_url = "{$vars['url']}pg/blog/owner/group:{$vars['group']->guid}/";
		
		
		if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td><a href=\"$add_url\">" . elgg_echo('blog:newpost') . "</a></td><td style=\"text-align:right;\"><a href=\"$more_url\">" . elgg_echo('blog:more') . "</a></td></tr></table></div>";
		}
		else
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$more_url\">" . elgg_echo('blog:more') . "</a></div>";
		}
	} else {
		echo "<div class=\"forum_latest\">" . elgg_echo("blog:nogroup") . "</div>";
				if ($add_url)
				{
					echo "<div class=\"widget_more_wrapper\"><a href=\"$add_url\">" . elgg_echo('blog:newpost') . "</a></div>";
					}
	}
?>
</div>
<?php } ?>
