<?php 
$group = $vars["group"];

if(is_plugin_enabled("tidypics") && $group->photos_enable != "no"){
	
	$widget = $vars["widget"];
	
?>
<div class="group_widget">
	<h2><?php echo elgg_echo('album:group'); ?></h2>
	<?php echo elgg_view('tidypics/albums', array('num_albums' => $widget->album_count)); ?>
</div>
<?php } ?>
