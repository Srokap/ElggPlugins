<?php 
	$group = $vars["group"];
	$widget = $vars["widget"];
	
?>
<style type="text/css">
	#group_twitter_widget ul {
		margin: 0;
		padding: 0;
	}
	
	#group_twitter_widget li {
		margin:0 0 5px 0;
		padding:0;
		overflow-x: hidden;
	}
	
	#group_twitter_widget li span {
		color: #666666;
		background: #dedede;
		-webkit-border-radius: 4px; 
		-moz-border-radius: 4px;
		padding: 5px;
		display: block;
	}
	
	#group_twitter_widget p.visit_twitter a {
	    background: url(<?php echo $vars['url']; ?>mod/twitter/graphics/twitter.png) left no-repeat;
	    padding: 0 0 0 20px;
	    margin: 0;
	}
	
	#group_twitter_widget p.visit_twitter {
		background: white;
		-webkit-border-radius: 4px; 
		-moz-border-radius: 4px;
		padding: 2px;
		margin: 0 0 5px 0;
	}
	
	#group_twitter_widget li a {
		display: block;
		margin: 0 0 0 4px;
		text-align: right;
	}
	
	#group_twitter_widget li span a {
		display: inline !important;
	}
</style>
<div class="group_widget" id="group_twitter_widget">
	<h2><?php echo elgg_echo("group_custom_layout:widgets:twitter:title"); ?></h2>
	<?php if(!empty($widget->twitter_username)){ ?>
		<ul id="twitter_update_list"></ul>
		<p class="visit_twitter">
			<a href="http://twitter.com/<?php echo $widget->twitter_username; ?>"><?php echo elgg_echo("twitter:visit"); ?></a>
		</p>
		<script type="text/javascript" src="http://twitter.com/javascripts/blogger.js"></script>
		<script type="text/javascript" src="http://twitter.com/statuses/user_timeline/<?php echo $widget->twitter_username; ?>.json?callback=twitterCallback2&count=<?php echo $widget->tweet_count; ?>"></script>
	<?php 
	} else { 
		echo elgg_echo("group_custom_layout:widgets:twitter:no_username"); 
	} 
	?>
</div>
