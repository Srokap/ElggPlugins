<?php 
	$entity = $vars["entity"];
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
		$album_count = $entity->album_count;
	} else {
		$widget_name = $vars["widget_name"];
		$album_count = 4;
	}
	
	$options = "";
	for($i = 1; $i <= 10; $i++){
		if($i == $album_count){
			$options .= "<option value='" . $i . "' selected='yes'>" . $i . "</option>\n";
		} else {
			$options .= "<option value='" . $i . "'>" . $i . "</option>\n";
		}
	}
	
?>
<h3 class="settings"><?php echo elgg_echo("group_custom_layout:widgets:tidypics:settings:title"); ?></h3>
<div>
	<?php echo elgg_echo("group_custom_layout:widgets:tidypics:settings:album_count"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[album_count]">
		<?php echo $options; ?>
	</select>
</div>