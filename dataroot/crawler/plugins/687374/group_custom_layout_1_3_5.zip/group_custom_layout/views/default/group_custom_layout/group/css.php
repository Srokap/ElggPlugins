<?php 

	$group = $vars["group"];
	$layout = $vars["layout"];
        $img1_url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . "action/group_custom_layout/get_background?group_guid=" . $group->guid . "&image_id=1");
        $img2_url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . "action/group_custom_layout/get_background?group_guid=" . $group->guid . "&image_id=2");

?>
<style type="text/css">
	<?php if(!empty($layout->enable_background1) && $layout->enable_background1 == "yes"){ ?>
	html {background-image: url(<?php echo $img1_url ?>) !important;
background-repeat: <?php echo $layout->background1Repeat ?>;
background-position: <?php echo $layout->background1Position ?>;	
background-attachment: <?php echo $layout->background1Attachment ?>;		}
	<?php } ?>
	
	<?php if(!empty($layout->enable_background2) && $layout->enable_background2 == "yes"){ ?>
	#two_column_left_sidebar_maincontent {background-image: url(<?php echo $img2_url ?>) !important;
background-repeat: <?php echo $layout->background2Repeat ?>;
background-position: <?php echo $layout->background2Position ?>;	
background-attachment: <?php echo $layout->background2Attachment ?>;		}
	<?php } ?>

	<?php if(!empty($layout->enable_colors) && $layout->enable_colors == "yes"){ ?>
	#two_column_left_sidebar_maincontent_boxes,
	#two_column_left_sidebar_boxes .sidebarBox,
	#left_column .contentWrapper,
	#right_column .contentWrapper,
        .group_widget,  #group_river_widget, #group_stats
<?php if ((!empty($layout->use_header)) && ($layout->use_header =="yes")){ echo ",#content_area_group_title h2";}
if ((!empty($layout->use_fields)) && ($layout->use_fields =="yes")){ echo ",#groups_info_column_left p";}
?>
 {
		background-color: <?php echo $layout->background_color; !important?>;
		border: 1px solid <?php echo $layout->border_color; ?> !important; 
	}

#river, .river_item_list {
border-top: 1px solid <?php echo $layout->title_color; ?> !important; 
}

	<?php } ?>



	<?php if(!empty($layout->enable_widget_footer_colors) && $layout->enable_widget_footer_colors == "yes"){ ?>
	#viewall, #messageboard_widget_menu, .tidypics_download, .more_content, .widget_more_wrapper {
		background-color: <?php echo $layout->widget_footer_background_color; ?> !important;
}
	#viewall a, #messageboard_widget_menu a, .tidypics_download a, .more_content a, .widget_more_wrapper a {
		color: <?php echo $layout->widget_footer_color; ?> !important;
}
	<?php } ?>

	#groups_info_column_left p, #content_area_group_title h2  {
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	}

	#two_column_left_sidebar_maincontent h1,
	#two_column_left_sidebar_maincontent h1 a,
	#two_column_left_sidebar_maincontent h2,
	#two_column_left_sidebar_maincontent h2 a,
	#two_column_left_sidebar_maincontent h3,
	#two_column_left_sidebar_maincontent h3 a,
	#two_column_left_sidebar_maincontent h4, 
	#two_column_left_sidebar_maincontent h4 a {
color: <?php echo $layout->title_color; ?> !important;
}
	
#groups_info_column_left, #groups_info_column_right {
margin-top: 25px !important;
}

#content_area_group_title h2 {
display: inline !important;
}

	#left_column .contentWrapper,
	#right_column .contentWrapper {
		padding: 0px !important;
		margin: 0 0 10px !important;
	}
</style>
