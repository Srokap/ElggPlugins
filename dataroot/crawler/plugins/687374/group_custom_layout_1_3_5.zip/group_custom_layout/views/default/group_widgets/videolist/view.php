<?php 
$group = $vars["group"];

if(is_plugin_enabled("videolist")){
	$widget = $vars["widget"];
	echo elgg_view('videolist/groupprofile_videolist', array('entity' => $group));
}