<?php 
	$entity = $vars["entity"];
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
		$page_count = $entity->page_count;
	} else {
		$widget_name = $vars["widget_name"];
		$page_count = 4;
	}
	
	$options = "";
	for($i = 1; $i <= 10; $i++){
		if($i == $page_count){
			$options .= "<option value='" . $i . "' selected='yes'>" . $i . "</option>\n";
		} else {
			$options .= "<option value='" . $i . "'>" . $i . "</option>\n";
		}
	}
	
?>
<h3 class="settings"><?php echo elgg_echo("group_custom_layout:widgets:pages:settings:title"); ?></h3>
<div>
	<?php echo elgg_echo("group_custom_layout:widgets:pages:settings:page_count"); ?>
	<select name="group_widgets_<?php echo $widget_name; ?>_settings[page_count]">
		<?php echo $options; ?>
	</select>
</div>