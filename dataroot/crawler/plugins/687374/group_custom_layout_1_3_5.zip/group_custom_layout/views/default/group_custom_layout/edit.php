<?php 


	$group = $vars["entity"];
	$layout = $vars['group_custom_layout'];

	// Hidden fields for administration
	$form_body = elgg_view("input/hidden", array("internalname"=>"group_guid", "value" => $group->guid));
	$form_body .= "<input type='hidden' id='left_widgets' name='left_widgets' value='" . $layout->left_widgets . "'/>";
	$form_body .= "<input type='hidden' id='right_widgets' name='right_widgets' value='" . $layout->right_widgets . "'/>";

	// Widget selector
	$form_body .= "<h3 class='settings'>" . elgg_echo("group_custom_layout:edit:widgets")  . "</h3>"; 
	$form_body .= elgg_view("group_custom_layout/widgets", array("group_custom_layout" => $layout));
	
	if(get_plugin_setting("allow_colors", "group_custom_layout") != "no"){
		// Color selection
		$form_body .= "<h3 class='settings'>" . elgg_echo("group_custom_layout:edit:colors")  . "</h3>";
		
		// Enable colors?
		$form_body .= "<div>";
		$form_body .= elgg_echo("group_custom_layout:edit:colors:enable") . "&nbsp;";
		$form_body .= "<select id='enable_colors' name='enable_colors' onChange='checkColors();'>";
		if(!empty($layout->enable_colors) && $layout->enable_colors != "no"){
			$form_body .= "<option value='yes' selected='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no'>" . elgg_echo("option:no") . "</option>";
		} else {
			$form_body .= "<option value='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no' selected='yes'>" . elgg_echo("option:no") . "</option>";
		}
		$form_body .= "</select>";
		$form_body .= "</div>";
		
		// Color pickers
		$form_body .= "<table id='colorpicker_container'><tr><td>";
		$background_color = $layout->background_color;
		if(empty($background_color)) $background_color = "#123456";
		$form_body .= "<label for='backgroundcolor'>" . elgg_echo("group_custom_layout:edit:backgroundcolor") . "</label><div id='backgroundpicker'></div><input type='text' id='backgroundcolor' name='background_color' value='" . $background_color . "' />";
		$form_body .= "</td><td>";
		
		$border_color = $layout->border_color;
		if(empty($border_color)) $border_color = "#123456"; 
		$form_body .= "<label for='bordercolor'>" . elgg_echo("group_custom_layout:edit:bordercolor") . "</label><div id='borderpicker'></div><input type='text' id='bordercolor' name='border_color' value='" . $border_color . "' />";
		$form_body .= "</td><td>";
		
		$title_color = $layout->title_color;
		if(empty($title_color )) $title_color  = "#123456";
		
		$form_body .= "<label for='titlecolor'>" . elgg_echo("group_custom_layout:edit:titlecolor") . "</label><div id='titlepicker'></div><input type='text' id='titlecolor' name='title_color' value='" . $title_color . "' />";
		$form_body .= "</td></tr>";

		if(empty($layout->use_header)) $layout->use_header = "no";
		$use_header = $layout->use_header;

		if(empty($layout->use_fields)) $layout->use_fields = "no";
		$use_fields = $layout->use_fields;
		$form_body .= "<tr><td colspan='3'>". elgg_echo("group_custom_layout:edit:colors:header") . " ";

		$form_body .= elgg_view("input/pulldown", array("internalname" => "use_header", "options" => array("yes", "no"), "value" => "$layout->use_header"));


$form_body .= "</td></tr>";
		
$form_body .= "<tr><td colspan='3'>". elgg_echo("group_custom_layout:edit:colors:fields") . " ";
		$form_body .= elgg_view("input/pulldown", array("internalname" => "use_fields", "options" => array("yes", "no"), "value" => "$layout->use_fields"));
$form_body .= "</td></tr></table>";

	
	
		// Enable widget footer colors?

		if(empty($layout->enable_widget_footer_colors)) $layout->enable_widget_footer_colors = "no";
		$enable_widget_footer_colors = $layout->enable_widget_footer_colors;

		$form_body .= "<div><br/>";
		$form_body .= elgg_echo("group_custom_layout:edit:widget_footer_colors:enable") . "&nbsp;";
		$form_body .= "<select id='enable_widget_footer_colors' name='enable_widget_footer_colors' onChange='check_footer_widget_Colors();'>";
		if(!empty($layout->enable_widget_footer_colors) && $layout->enable_widget_footer_colors != "no"){
			$form_body .= "<option value='yes' selected='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no'>" . elgg_echo("option:no") . "</option>";
		} else {
			$form_body .= "<option value='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no' selected='yes'>" . elgg_echo("option:no") . "</option>";
		}
		$form_body .= "</select>";
		$form_body .= "</div><br/>";


		// widget footer Color pickers
		$form_body .= "<table id='widget_footer_colorpicker_container'><tr><td>";
		$widget_footer_background_color = $layout->widget_footer_background_color;
		if(empty($widget_footer_background_color)) $widget_footer_background_color = "#123456";
		$form_body .= "<label for='widget_footer_background_color'>" . elgg_echo("group_custom_layout:edit:widget_footer_background_color") . "</label><div id='widget_footer_background_picker'></div><input type='text' id='widget_footer_background_color' name='widget_footer_background_color' value='" . $widget_footer_background_color . "' />";
		$form_body .= "</td><td>";
		
		$widget_footer_color = $layout->widget_footer_color;
		if(empty($widget_footer_color )) $widget_footer_color  = "#123456";
		
		$form_body .= "<label for='widget_footer_color'>" . elgg_echo("group_custom_layout:edit:widget_footer_color") . "</label><div id='widget_footer_color_picker'></div><input type='text' id='widget_footer_color' name='widget_footer_color' value='" . $widget_footer_color . "' />";
		$form_body .= "</td></tr></table>";

	
	} else {
		$form_body .= elgg_view("input/hidden", array("internalname" => "enable_colors", "value" => "no"));
	}

	if(get_plugin_setting("allow_background", "group_custom_layout") != "no"){

        $img1_url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . "action/group_custom_layout/get_background?group_guid=" . $group->guid . "&image_id=1");
        $img2_url = elgg_add_action_tokens_to_url($CONFIG->wwwroot . "action/group_custom_layout/get_background?group_guid=" . $group->guid . "&image_id=2");


		// Background image 1
		$form_body .= "<h3 class='settings'>" . elgg_echo("group_custom_layout:edit:background1")  . "</h3>";
		
		// Enable background image 1?
		$form_body .= "<div>";
		$form_body .= elgg_echo("group_custom_layout:edit:background1:enable") . "&nbsp;";
		$form_body .= "<select id='enable_background1' name='enable_background1' onChange='checkBackground1();'>";
		if(!empty($layout->enable_background1) && $layout->enable_background1 != "no"){
			$form_body .= "<option value='yes' selected='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no'>" . elgg_echo("option:no") . "</option>";
		} else {
			$form_body .= "<option value='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no' selected='yes'>" . elgg_echo("option:no") . "</option>";
		}
		$form_body .= "</select>";
		$form_body .= "</div>";
		
		// Build input fields
		$form_body .= "<div id='background1_container'>";
		$form_body .= "<br />";
		$form_body .= elgg_echo("group_custom_layout:edit:background1file"); 
		$form_body .= "<br />";
		$form_body .= elgg_view("input/file", array("internalname" => "background1File", "class" => "image_field_float", "value" => "$layout->background1File")) . "<img src='$img1_url' height='60' width='60'/>";

		$form_body .= "<br /><br/>";
		$form_body .= elgg_echo("group_custom_layout:edit:background1:repeat") . "&nbsp;";
		$form_body .= elgg_view("input/pulldown", array("internalname" => "background1Repeat", "options" => array("no-repeat","repeat-x","repeat-y","repeat"), "value" => "$layout->background1Repeat"));
		$form_body .= "<br />";
		$form_body .= elgg_echo("group_custom_layout:edit:background1:position") . "&nbsp;";
		$form_body .= elgg_view("input/pulldown", array("internalname" => "background1Position", "options" => array("left top", "left center", "left bottom", "right top", "right center", "right bottom", "center top", "center center", "center bottom"), "value" => "$layout->background1Position"));
		$form_body .= "<br />";
		$form_body .= elgg_echo("group_custom_layout:edit:background1:attachment") . "&nbsp;";
		$form_body .= elgg_view("input/pulldown", array("internalname" => "background1Attachment", "options" => array("fixed", "scroll"), "value" => "$layout->background1Attachment"));
		$form_body .= "</div>";

		// Background image 2
	        $form_body .= "<h3 class='settings'>" . elgg_echo("group_custom_layout:edit:background2")  . "</h3>";
		// Enable background image 2?
		$form_body .= "<div>";
		$form_body .= elgg_echo("group_custom_layout:edit:background2:enable") . "&nbsp;";
		$form_body .= "<select id='enable_background2' name='enable_background2' onChange='checkBackground2();'>";
		if(!empty($layout->enable_background2) && $layout->enable_background2 != "no"){
			$form_body .= "<option value='yes' selected='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no'>" . elgg_echo("option:no") . "</option>";
		} else {
			$form_body .= "<option value='yes'>" . elgg_echo("option:yes") . "</option>";
			$form_body .= "<option value='no' selected='yes'>" . elgg_echo("option:no") . "</option>";
		}
		$form_body .= "</select>";
		$form_body .= "</div>";
		
		// Build input field
		$form_body .= "<div id='background2_container'>";
		$form_body .= "<br />";
		$form_body .= elgg_echo("group_custom_layout:edit:background2file"); 
		$form_body .= "<br />";
		$form_body .= elgg_view("input/file", array("internalname" => "background2File", "class" => "image_field_float", "value" => "$layout->background2File")) . "<img src='$img2_url' height='60' width='60'/>";
		$form_body .= "<br /><br/>";
		$form_body .= elgg_echo("group_custom_layout:edit:background2:repeat") . "&nbsp;";
		$form_body .= elgg_view("input/pulldown", array("internalname" => "background2Repeat", "options" => array("no-repeat","repeat-x","repeat-y","repeat"), "value" => "$layout->background2Repeat"));
		$form_body .= "<br />";
		$form_body .= elgg_echo("group_custom_layout:edit:background2:position") . "&nbsp;";
		$form_body .= elgg_view("input/pulldown", array("internalname" => "background2Position", "options" => array("left top", "left center", "left bottom", "right top", "right center", "right bottom", "center top", "center center", "center bottom"), "value" => "$layout->background2Position"));
		$form_body .= "<br />";
		$form_body .= elgg_echo("group_custom_layout:edit:background2:attachment") . "&nbsp;";
		$form_body .= elgg_view("input/pulldown", array("internalname" => "background2Attachment", "options" => array("fixed", "scroll"), "value" => "$layout->background2Attachment"));
		$form_body .= "</div>";
	} else {
		$form_body .= elgg_view("input/hidden", array("internalname" => "enable_background1", "value" => "no"));
		$form_body .= elgg_view("input/hidden", array("internalname" => "enable_background2", "value" => "no"));
	}
	
	// Buttons
	$form_body .= "<br />";
	$form_body .= elgg_view("input/submit", array("internalname" => "saveButton", "value" => elgg_echo("save")));
	
	$ts = time();
	$token = generate_action_token($ts);
	
	if(!empty($layout)){
		$form_body .= " " . elgg_view("input/button", array("internalname" => "resetButton", "value" => elgg_echo("group_custom_layout:edit:reset"), "type"=>"button", "js"=>"onclick='if(confirm(\"" . elgg_echo("group_custom_layout:edit:reset:confirm") . "\")) document.location.href = \"" . $CONFIG->wwwroot . "action/group_custom_layout/reset?group_guid=" . $group->guid . "&__elgg_token=$token&__elgg_ts=$ts\"'"));
	}
	
	$form_body .= elgg_view('input/securitytoken');
	$form = elgg_view("input/form", array(
									"body" => $form_body,
									"enctype" => "multipart/form-data",
									"internalid" => "editForm",
									"action" => $CONFIG->wwwroot . "action/group_custom_layout/save"
											));
	
	
?>
<div class="contentWrapper"> 
	<script type="text/javascript" src="<?php echo $CONFIG->wwwroot;?>mod/group_custom_layout/js/thickbox/thickbox-compressed.js"></script>
	<script type="text/javascript" src="<?php echo $CONFIG->wwwroot;?>mod/group_custom_layout/js/farbtastic/farbtastic.js"></script>
	
	<link rel="stylesheet" href="<?php echo $CONFIG->wwwroot;?>mod/group_custom_layout/js/farbtastic/farbtastic.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $CONFIG->wwwroot;?>mod/group_custom_layout/js/thickbox/thickbox.css" type="text/css" />
	
	<script type="text/javascript" charset="utf-8">


		function check_footer_widget_Colors(){
			var enable = $('#enable_widget_footer_colors').val();
			
			if(enable != "yes"){
				$('#widget_footer_colorpicker_container').hide();
			} else {
				$('#widget_footer_colorpicker_container').show();
			}
		}

		function checkColors(){
			var enable = $('#enable_colors').val();
			
			if(enable != "yes"){
				$('#colorpicker_container').hide();
			} else {
				$('#colorpicker_container').show();
			}
		}

		function checkBackground1(){
			var enable = $('#enable_background1').val();
			
			if(enable != "yes"){
				$('#background1_container').hide();
			} else {
				$('#background1_container').show();
			}
		}

		function checkBackground2(){
			var enable = $('#enable_background2').val();
			
			if(enable != "yes"){
				$('#background2_container').hide();
			} else {
				$('#background2_container').show();
			}
		}
		
		$(document).ready(function() {
			checkColors();
			check_footer_widget_Colors()
			checkBackground1();
			checkBackground2();
			
			$('#backgroundpicker').farbtastic('#backgroundcolor');
			$('#borderpicker').farbtastic('#bordercolor');
			$('#titlepicker').farbtastic('#titlecolor');
			$('#widget_footer_background_picker').farbtastic('#widget_footer_background_color');
			$('#widget_footer_color_picker').farbtastic('#widget_footer_color');

			// WIDGET GALLERY EDIT PANEL
			// Sortable widgets
			var gclw = ['#leftcolumn_widgets', '#middlecolumn_widgets', '#rightcolumn_widgets'];
			var $gclw = $(gclw.toString());

			$gclw.sortable('destroy');
			
			$gclw.sortable({
				items: '.draggable_group_widget',
				handle: '.drag_handle',
				cursor: 'move',
				revert: true,
				opacity: 1.0,
				appendTo: 'body',
				placeholder: 'placeholder',
				connectWith: gclw,
				start: function(e,ui) {
			
				},
				stop: function(e,ui) {	
					// refresh list before updating hidden fields with new widget order		
					$('#leftcolumn_widgets').sortable( "refresh" );
					$('#middlecolumn_widgets').sortable( "refresh" );
		
					var leftWidgets = $('#leftcolumn_widgets').sortable('toArray');
					var rightWidgets = $('#middlecolumn_widgets').sortable('toArray');
					var widgetsLeft = "";
					var widgetsRight = "";
		
					for(var i in leftWidgets){
						if(widgetsLeft == ""){
							widgetsLeft = leftWidgets[i];
						} else {
							widgetsLeft = widgetsLeft + "," + leftWidgets[i];
						}
					}
		
					for(var j in rightWidgets){
						if(widgetsRight == ""){
							widgetsRight = rightWidgets[j];
						} else {	
							widgetsRight = widgetsRight + "," + rightWidgets[j];
						}
					} 
					
					$('#left_widgets').val(widgetsLeft);
					$('#right_widgets').val(widgetsRight);
					
				}
				
			});

			$('#rightcolumn_widgets').sortable({
				items: 'table'
			});
		
		}); /* end document ready function */
		
	</script>
	
	<?php echo $form;?>
</div> 
