<?php 
	$entity = $vars["entity"];
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
	} else {
		$widget_name = $vars["widget_name"];
	}
	
?>
<h3 class="settings"><?php echo elgg_echo("group_custom_layout:widgets:videolist:settings:title"); ?></h3>
