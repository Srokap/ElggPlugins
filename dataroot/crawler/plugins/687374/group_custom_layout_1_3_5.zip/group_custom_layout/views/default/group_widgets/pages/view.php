<?php 
$group = $vars["group"];

if(is_plugin_enabled("pages") && $group->pages_enable != "no"){
	
	$widget = $vars["widget"];
	
?>
<div class="group_widget">
<h2><?php echo elgg_echo("pages:groupprofile"); ?></h2>
<?php

    $objects = list_entities("object", "page_top", $group->guid, $widget->page_count, false, false, false);
    				if (can_write_to_container(0, $owner->guid)) {
	$add_url = "{$vars['url']}pg/pages/new/?container_guid={$group->guid}";
	}
    if(!empty($objects)){
		echo $objects;
		$more_url = "{$vars['url']}pg/pages/owned/group:{$group->guid}";
		

if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td><a href=\"$add_url\">" . elgg_echo('pages:new') . "</a></td><td style=\"text-align:right;\"><a href=\"$more_url\">" . elgg_echo('pages:more') . "</a></td></tr></table></div>";
		}
		else
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$more_url\">" . elgg_echo('pages:more') . "</a></div>";
		}
    } else {
    	
		echo "<div class=\"forum_latest \">" . elgg_echo("pages:nogroup") . "</div>";
		if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$add_url\">" . elgg_echo('pages:new') . "</a></div>";
		}
    }
	
?>
</div>

<?php } ?>
