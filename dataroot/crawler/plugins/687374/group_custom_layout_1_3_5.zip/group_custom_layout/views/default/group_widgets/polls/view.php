<?php 
$group = $vars["group"];

if(is_plugin_enabled("polls")){
	$widget = $vars["widget"];
	echo elgg_view('groups/grouppolls', array('entity' => $group));
}