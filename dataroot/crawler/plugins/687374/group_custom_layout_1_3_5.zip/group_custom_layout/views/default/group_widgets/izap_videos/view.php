<?php 
$group = $vars["group"];

if(is_plugin_enabled("izap_videos") && $group->izap_videos_enable != "no"){
	
	$widget = $vars["widget"];
	
?>
<div class="group_widget">
	<h2><?php echo elgg_echo('izap_videos:groupvideos'); ?></h2>
	<?php 
		$shares = get_entities('object', 'izap_videos', $group->guid, "", $widget->video_count);
					if (can_write_to_container(0, $owner->guid)) {
				$add_url = $CONFIG->wwwroot . "pg/videos/add/" . $group->username;
		}

			$more_url = $CONFIG->wwwroot . "pg/videos/list/group:" . $group->guid;
		if(!empty($shares)){
			
			foreach($shares as $s){
				//	$izap_videos_image = $CONFIG->wwwroot . "mod/izap_videos/thumbs.php?what=image&id=" . $s->getGUID();			
				$dir = substr(strrchr($s->getUrl(), "/"), 1);
			      	$izap_videos_image = $CONFIG->wwwroot . "/pg/izap_videos_files/image/" . $s->getGUID() . "/" . $dir;

				$owner = $s->getOwnerEntity();
				$friendlytime = friendly_time($s->time_created);
				$icon = '<img src="'.$izap_videos_image.'" height="40" width="40">';
				
				echo "<div class='forum_latest'>";
				
				echo "<div class='izap_shares_widget_icon'>";
				echo "<a href='" . $s->getUrl() . "' class='screenshot' rel='" . $izap_videos_image . "'>" . $icon . "</a>";
				echo "</div>";
				
				echo "<div>";
				?>
				<p class="izap_shares_title">
					<a href="<?php echo $s->getUrl(); ?>" class="screenshot" rel="<?php echo $izap_videos_image; ?>"><?php echo substr($s->title,0,30); ?>..</a>
				</p>
				<p class="izap_shares_timestamp" align="right">
					<small>
						<!--
							<a href="<?php echo $owner->getUrl(); ?>"> by : <?php echo $owner->name; ?></a>
						-->
						<?php echo $friendlytime; ?>
					</small>
				</p>
				<?php
				echo "</div>";
				
				echo "<div class='clearfloat'></div>";
				echo "</div>";
				
			}
		
			$user_inbox = $CONFIG->wwwroot . "pg/videos/list/" . $group->username;
			if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td><a href=\"$add_url\">" . elgg_echo('izap_videos:add') . "</a></td><td style=\"text-align:right;\"><a href=\"$more_url\">" . elgg_echo('izap_videos:everyone') . "</a></td></tr></table></div>";
		}
		else
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$more_url\">" . elgg_echo('izap_videos:everyone') . "</a></div>";
		}
	
		} else {

			echo '<div class="forum_latest">' . elgg_echo('izap_videos:notfound') . '</div>';
						if ($add_url){
							echo "<div class=\"widget_more_wrapper\"><a href=\"$add_url\">" . elgg_echo('izap_videos:add') . "</a></div>";
				}
		}
		
	?>
</div>

<?php } ?>
