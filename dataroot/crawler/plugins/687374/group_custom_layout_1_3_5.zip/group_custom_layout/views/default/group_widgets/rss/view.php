<?php
	global $CONFIG;
	$group = $vars["group"];
	$widget = $vars["widget"];
	
	if (!class_exists('SimplePie')){
		require_once($CONFIG->pluginspath . 'group_custom_layout/vendors/simplepie/simplepie.inc');
	}
	
	$blog_tags = '<a><p><br><b><i><em><del><pre><strong><ul><ol><li>';
	$feed_url = $widget->rssfeed;
	
	if(!empty($feed_url)){
		if($widget->excerpt == "yes"){
			$excerpt = true;
		} else {
			$exerpt = false;
		}
		
		$num_items = $widget->rss_count;
		
		if($widget->post_date == "yes"){
			$post_date = true;
		} else {
			$post_date = false;
		}
		
		$cache_loc = $CONFIG->pluginspath . 'group_custom_layout/vendors/simplepie/cache';
		
		$feed = new SimplePie($feed_url, $cache_loc);
		
		// doubles timeout if going through a proxy
		//$feed->set_timeout(20);
		
		$num_posts_in_feed = $feed->get_item_quantity();
		
?>
<style type="text/css">
	/*-------------------------------
	SIMPLEPIE FEED WIDGET
	-------------------------------*/
	.group_simplepie_item {
		margin-bottom: 12px;
	}
	
	.group_simplepie_title {
		margin-bottom: 4px;
	}
	
	.group_simplepie_excerpt {
		margin-bottom: 4px;
	}
	
	.group_simplepie_date {
		font-size: 70%;
		text-align: right;
	}
	
	.group_simplepie_excerpt img {
		width: 170px;
	}
</style>
<div class="group_widget">
	<h2><?php echo $feed->get_title(); ?></h2>
	<?php
		if (empty($num_posts_in_feed)){
			echo '<p>' . elgg_echo('group_custom_layout:widgets:rss:error:notfind') . '</p>';
		} else {
			if ($num_items > $num_posts_in_feed){
				$num_items = $num_posts_in_feed;
			}
			
			foreach ($feed->get_items(0, $num_items) as $item){
			?>
				<div class="group_simplepie_item">
					<h4 class="group_simplepie_title"><a href="<?php echo $item->get_permalink(); ?>" target="_blank"><?php echo $item->get_title(); ?></a></h4>
					<?php 
					if ($excerpt){
						echo '<div class="group_simplepie_excerpt">' . strip_tags($item->get_description(true), $blog_tags) . '</div>';
					}
					
					if ($post_date){
						echo '<div class="group_simplepie_date">'. sprintf(elgg_echo("group_custom_layout:widgets:rss:post_date"), $item->get_date('j F Y | G:i')) . '</div>';
					}
					?>
				</div>
			<?php 
			}
		}
	} else {
		echo '<p>' . elgg_echo('group_custom_layout:widgets:rss:error:notset') . '</p>';      
	}
	?>
</div>
