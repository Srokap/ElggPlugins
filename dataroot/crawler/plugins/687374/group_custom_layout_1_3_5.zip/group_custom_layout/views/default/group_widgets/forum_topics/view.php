<?php
$group = $vars["group"];

if($group->forum_enable != "no"){

	$widget = $vars["widget"];
	
	
?>
<div class="group_widget">
<h2><?php echo elgg_echo('groups:latestdiscussion'); ?></h2>
<?php
	
    $forum = get_entities_from_annotations("object", "groupforumtopic", "group_topic_post", "", 0, $group->guid, $widget->topic_count, 0, "desc", false);
    				if (can_write_to_container(0, $owner->guid)) {
	$add_url = "{$vars['url']}pg/forum/new/{$group->guid}/";
	}
	if(!empty($forum)){
        foreach($forum as $f){
			
		$count_annotations = $f->countAnnotations("group_topic_post");
			
            	echo "<div class=\"forum_latest\">";
            	echo "<div class=\"topic_owner_icon\">" . elgg_view('profile/icon',array('entity' => $f->getOwnerEntity(), 'size' => 'tiny', 'override' => true)) . "</div>";
            	echo "<div class=\"topic_title\"><p><a href=\"" . $CONFIG->wwwroot . "mod/groups/topicposts.php?topic=" . $f->guid . "&group_guid=" . $group->guid . "\">" . $f->title . "</a></p> <p class=\"topic_replies\"><small>" . elgg_echo('groups:posts') . ": " . $count_annotations . "</small></p></div>";
	        echo "</div>";
		}
		
		$more_url = "{$vars['url']}pg/groups/forum/{$group->guid}/";
		if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td><a href=\"$add_url\">" . elgg_echo('groupforumtopic:new') . "</a></td><td style=\"text-align:right;\"><a href=\"$more_url\">" . elgg_echo('group_custom_layout:widgets:forum_topics:more') . "</a></td></tr></table></div>";
		}
		else
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$more_url\">" . elgg_echo('group_custom_layout:widgets:forum_topics:more') . "</a></div>";
		}
	
	} else {
		echo "<div class=\"forum_latest\">";
		echo elgg_echo("grouptopic:notcreated");
		echo "</div>";
				if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$add_url\">" . elgg_echo('groupforumtopic:new') . "</a></div>";
		}
	}
?>
</div>

<?php } ?>
