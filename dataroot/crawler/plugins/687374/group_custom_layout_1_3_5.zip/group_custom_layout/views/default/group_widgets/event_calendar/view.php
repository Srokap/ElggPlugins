<?php 
$group = $vars["group"];

if(is_plugin_enabled("event_calendar") && $group->event_calendar_enable != "no"){
	
	$widget = $vars["widget"];
$page_owner_entity = page_owner_entity();

if (event_calendar_activated_for_group($page_owner_entity)) {
    $num = 5;
    // Get the upcoming events
    $start_date = time(); // now
    $end_date = $start_date + 60*60*24*365*2; // maximum is two years from now
	$events = event_calendar_get_events_between($start_date,$end_date,false,$num,0,page_owner());
	if (can_write_to_container(0, $owner->guid)) {
	$add_url = $vars['url']."pg/event_calendar/new/group/?group_guid=".page_owner();
	}
	$more_url= $vars['url']."pg/event_calendar/group/".page_owner();
	// If there are any events to view, view them
	if (is_array($events) && sizeof($events) > 0) {

		echo '<div class="group_widget" >';
		echo '<h2>'.elgg_echo("event_calendar:groupprofile").'</h2>';
		foreach($events as $event) {
			echo elgg_view("object/event_calendar",array('entity' => $event));
		}
		if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td><a href=\"$add_url\">" . elgg_echo('event_calendar:new_event') . "</a></td><td style=\"text-align:right;\"><a href=\"$more_url\">" . elgg_echo('event_calendar:view_calendar') . "</a></td></tr></table></div>";
		}
		else
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$more_url\">" . elgg_echo('event_calendar:view_calendar') . "</a></div>";
		}
		echo "</div>";
    } else  {
    	echo '<div class="group_widget">';
	echo '<h2>'.elgg_echo("event_calendar:groupprofile").'</h2>';
    	echo '<div class="forum_latest">'.elgg_echo('event_calendar:no_events_found').'</div>';
    	if ($add_url){
    	echo '<div class="widget_more_wrapper"><a href="'. $add_url .'">'.elgg_echo('event_calendar:new_event').'</a></div>';
    	}
    	echo "</div>";
    }
}
 } ?>
