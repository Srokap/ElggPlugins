<?php 

?>
<div>
	<div><?php echo elgg_echo("group_custom_layout:settings:metadata_key"); ?></div>
	<input type="text" value="<?php echo $vars["entity"]->metadata_key; ?>" name="params[metadata_key]">
	
	<div><?php echo elgg_echo("group_custom_layout:settings:metadata_value"); ?></div>
	<input type="text" value="<?php echo $vars["entity"]->metadata_value; ?>" name="params[metadata_value]">
	
	<br />
	<br />
	
	<div>
		<select name="params[allow_colors]">
			<option value="yes" <?php if($vars["entity"]->allow_colors != "no") echo "selected='selected'"; ?>><?php echo elgg_echo("option:yes"); ?></option>
			<option value="no" <?php if($vars["entity"]->allow_colors == "no") echo "selected='selected'"; ?>><?php echo elgg_echo("option:no"); ?></option>
		</select>
		<?php echo elgg_echo("group_custom_layout:settings:allow_colors"); ?>
	</div>
	
	<div>
		<select name="params[allow_background]">
			<option value="yes" <?php if($vars["entity"]->allow_background != "no") echo "selected='selected'"; ?>><?php echo elgg_echo("option:yes"); ?></option>
			<option value="no" <?php if($vars["entity"]->allow_background == "no") echo "selected='selected'"; ?>><?php echo elgg_echo("option:no"); ?></option>
		</select>
		<?php echo elgg_echo("group_custom_layout:settings:allow_background"); ?>
	</div>
</div>