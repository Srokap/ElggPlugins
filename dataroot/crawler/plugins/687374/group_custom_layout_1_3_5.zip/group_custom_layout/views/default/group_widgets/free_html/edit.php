<?php 
	$entity = $vars["entity"];
	
	if(!empty($entity) && $entity instanceof ElggObject && $entity->getSubtype() == GROUP_CUSTOM_LAYOUT_WIDGET){
		$widget_name = $entity->guid;
	} else {
		$widget_name = $vars["widget_name"];
	}
	
?>
<h3 class="settings"><?php echo elgg_echo("group_custom_layout:widgets:free_html:settings:title"); ?></h3>
<div>
	<?php echo elgg_echo("group_custom_layout:widgets:free_html:settings:widget_title"); ?><br />
<input type="text" name="group_widgets_<?php echo $widget_name; ?>_settings[widget_title]" value="<?php echo $entity->widget_title; ?>" size="40" maxlength="250"/><br /> 
    <?php echo elgg_echo("group_custom_layout:widgets:free_html:settings:html_content"); ?><br /> 
    <textarea name="group_widgets_<?php echo $widget_name; ?>_settings[html_content]" cols="40" rows="6"><?php echo filter_tags($entity->html_content); ?></textarea>
</div>