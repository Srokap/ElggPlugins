<?php 
$group = $vars["group"];

if(is_plugin_enabled("webgalli_gmessageboard")){
	$widget = $vars["widget"];
	echo elgg_view('webgalli_gmessageboard/group_messageboard', array('entity' => $group));
}
?>
