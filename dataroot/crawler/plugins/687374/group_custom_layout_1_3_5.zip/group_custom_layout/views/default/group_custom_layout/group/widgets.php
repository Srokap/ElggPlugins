<?php 
	$group = $vars["group"];
	$layout = $vars["layout"];
	
	$left_widgets = explode(",", $layout->left_widgets);
	$right_widgets = explode(",", $layout->right_widgets);
?>

	<div id="right_column">
		<?php 
			if(!empty($right_widgets)){
				foreach($right_widgets as $guid){
					$widget = get_entity($guid);
					
					echo elgg_view("group_widgets/" . $widget->title . "/view", array("widget" => $widget, "group" => $group));
				}
			} else {
				echo "&nbsp;";
			}
		?>
	</div>
	<div id="left_column">
		<?php 
			if(!empty($left_widgets)){
				foreach($left_widgets as $guid){
					$widget = get_entity($guid);
					
					echo elgg_view("group_widgets/" . $widget->title . "/view", array("widget" => $widget, "group" => $group));
				}
			} else {
				echo "&nbsp;";
			}
		?>
	</div>
	
	<div class="clearfloat"></div>
