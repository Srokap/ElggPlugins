<?php 



$group = $vars["group"];

if(is_plugin_enabled("file") && $group->files_enable != "no"){

	$widget = $vars["widget"];
	
?>
<script type="text/javascript">
	$(document).ready(function () {
		$('a.show_file_desc').click(function () {
			$(this.parentNode).children("[class=filerepo_listview_desc]").slideToggle("fast");
			return false;
		});
	});
</script>



<div class="group_widget">
<h2><?php echo elgg_echo('file:group'); ?></h2>
<?php
	$context = get_context();
	set_context('search');
	$content = elgg_list_entities(array('types' => 'object',
										'subtypes' => 'file',
										'container_guid' => $group->guid,
										'limit' => $widget->file_count,
										'full_view' => FALSE,
										'pagination' => FALSE));
	set_context($context);
				if (can_write_to_container(0, $owner->guid)) {
$add_url = "{$vars['url']}pg/file/new/group:{$group->guid}/";
}
    if ($content) {
		echo $content;
		if (get_version() < 2010071002){
		$more_url = "{$vars['url']}pg/file/group:{$group->guid}/";
		}
		else
		{
		$more_url = "{$vars['url']}pg/file/owner/group:{$group->guid}/";
		}
		if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td><a href=\"$add_url\">" . elgg_echo('file:upload') . "</a></td><td style=\"text-align:right;\"><a href=\"$more_url\">" . elgg_echo('file:more') . "</a></td></tr></table></div>";
		}
		else
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$more_url\">" . elgg_echo('file:more') . "</a></div>";
		}
		} else {
		echo "<div class=\"forum_latest\">" . elgg_echo("file:nogroup") . "</div>";
				if ($add_url)
		{
			echo "<div class=\"widget_more_wrapper\"><a href=\"$add_url\">" . elgg_echo('file:upload') . "</a></div>";
		}
	}
?>
</div>

<?php } ?>
