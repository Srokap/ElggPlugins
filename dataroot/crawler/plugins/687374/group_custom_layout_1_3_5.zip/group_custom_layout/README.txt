====================================================================
			CREDITS
====================================================================
The development of this plugin was commissioned by Butterfly Media (The Netherlands) for the website:

http://www.detrotsvanhetzuiden.com/

=============
Version 1.1 was funded by Roberto Scano (http://robertoscano.info/)
Version 1.2 was updated by Susana Cipriota (http://www.condiminds.com)
Versions 1.2.2 to 1.3.5 were updated by nick lankester (http://www.perfectmedium.co.uk)



====================================================================
			INSTRUCTIONS
====================================================================
To get this plugin working, go to the admin settings and enter a 
metadatafield name which your special groups have and a metadatafield value.

Example:
- field name: featured_group
- field value: yes

Also since this plugin was made for http://www.detrotsvanhetzuiden.com/ the CSS is based on their theme.
To get the Group CSS working for your theme edit:
[mod_dir]/group_custom_layout/views/default/group_custom_layout/group/css.php 
