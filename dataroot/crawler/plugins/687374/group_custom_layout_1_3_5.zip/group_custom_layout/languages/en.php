<?php 
	$english = array(
		'group_custom_layout' => "Group Custom Layout",
		'item:object:group_widget' => "Group Widget",
		'item:object:custom_layout' => "Group Custom Layout",
		
		// Settings
		'group_custom_layout:settings:metadata_key' => "Metatdata field name",
		'group_custom_layout:settings:metadata_value' => "Metadata field value",
		'group_custom_layout:settings:allow_colors' => "Allow customization of colors",
		'group_custom_layout:settings:allow_background' => "Allow customization of background image",
	
		// Edit
		'group_custom_layout:edit' => "Edit Group Layout",
		'group_custom_layout:edit:title' => "Edit Group Layout",
		'group_custom_layout:edit:widgets' => "Widgets",
		'group_custom_layout:edit:colors' => "Colors",
		'group_custom_layout:edit:colors:enable' => "Enable custom colors:",
		'group_custom_layout:edit:colors:header' => "Use the selected background/border colors for the main group header text?:",
		'group_custom_layout:edit:colors:fields' => "Use the selected background/border colors for this group's field text?:",
		'group_custom_layout:edit:widget_footer_colors:enable' => "Enable custom widget footer colors?:",
		'group_custom_layout:edit:widget_footer_background_color' => "footer bg color",
		'group_custom_layout:edit:widget_footer_color' => "footer link color",
		'group_custom_layout:edit:background1' => "Background 1 image (main page background):",
		'group_custom_layout:edit:background1:repeat' => "Background 1 repeat mode:",
		'group_custom_layout:edit:background1:position' => "Background 1 position mode:",
		'group_custom_layout:edit:background1:attachment' => "Background 1 attachment mode:",
		'group_custom_layout:edit:background1:enable' => "Enable custom background image 1:",
		'group_custom_layout:edit:background1file' => "Select background image 1:",
		'group_custom_layout:edit:background2' => "Background 2 image (group panel background):",
		'group_custom_layout:edit:background2:repeat' => "Background 2 repeat mode:",
		'group_custom_layout:edit:background2:position' => "Background 2 position mode:",
		'group_custom_layout:edit:background2:attachment' => "Background 2 attachment mode:",
		'group_custom_layout:edit:background2:enable' => "Enable custom background image 2:",
		'group_custom_layout:edit:background2file' => "Select background image 2:",
		'group_custom_layout:edit:backgroundcolor' => "Background Color",
		'group_custom_layout:edit:bordercolor' => "Border Color",
		'group_custom_layout:edit:titlecolor' => "Title Color",
		'group_custom_layout:edit:reset' => "Reset",
		'group_custom_layout:edit:reset:confirm' => "Are you sure you wish to reset the custom group layout?",

		// widgets
		'group_custom_layout:widgets:edit' => "Edit widget settings",
		
		// Forum topic widget
		'group_custom_layout:widgets:forum_topics:title' => "Forum Topics",
		'group_custom_layout:widgets:forum_topics:description' => "Show the latest forum topics",
		'group_custom_layout:widgets:forum_topics:settings:title' => "Forum Topics Settings",
		'group_custom_layout:widgets:forum_topics:settings:topic_count' => "Number of topics to show",
		'group_custom_layout:widgets:forum_topics:more' => "More Topics",
		
		// grouptagcloud widget - add-in to group custom layout plugin
		//settings
		'group_custom_layout:widgets:tagcloud:settings:title' => "Group tagcloud settings",
		'group_custom_layout:widgets:tagcloud:settings:tag_count' => "Number of tags to display",
		'group_custom_layout:widgets:tagcloud:settings:name' => "Widget title to display",
		'group_custom_layout:widgets:tagcloud:settings:tag_sort' => "Sort order",

		//widget
		'group_custom_layout:widgets:tagcloud:title' => "Group tagcloud",
		'group_custom_layout:widgets:tagcloud:description' => "Show the group tagcloud",

		// Pages widget
		'group_custom_layout:widgets:pages:title' => "Group Pages",
		'group_custom_layout:widgets:pages:description' => "Show the latest group pages",
		'group_custom_layout:widgets:pages:settings:title' => "Group Pages settings",
		'group_custom_layout:widgets:pages:settings:page_count' => "Number of pages to show",
		
		// Files widget
		'group_custom_layout:widgets:files:title' => "Group Files",
		'group_custom_layout:widgets:files:description' => "Show the latest group files",
		'group_custom_layout:widgets:files:settings:title' => "Group Files settings",
		'group_custom_layout:widgets:files:settings:file_count' => "Number of files to show",

		// Bookmarks widget
		'group_custom_layout:widgets:bookmarks:title' => "Group Bookmarks",
		'group_custom_layout:widgets:bookmarks:none' => "no bookmarks added yet",
		'group_custom_layout:widgets:bookmarks:description' => "Show the latest group bookmarks",
		'group_custom_layout:widgets:bookmarks:settings:title' => "Group bookmarks settings",
		'group_custom_layout:widgets:bookmarks:settings:bookmark_count' => "Number of bookmarks to show",

		
		// Tidypics widget
		'group_custom_layout:widgets:tidypics:title' => "Tidypics",
		'group_custom_layout:widgets:tidypics:description' => "Show the latest Tidypics album",
		'group_custom_layout:widgets:tidypics:settings:title' => "Tidypics settings",
		'group_custom_layout:widgets:tidypics:settings:album_count' => "Number of albums to show",

		// Webgalli Messageboard widget
		'group_custom_layout:widgets:webgalli_gmessageboard:title' => "Group Messageboard",
		'group_custom_layout:widgets:webgalli_gmessageboard:description' => "Show the latest messageboard posts",
		'group_custom_layout:widgets:webgalli_gmessageboard:settings:title' => "Messageboard settings",
		'group_custom_layout:widgets:webgalli_gmessageboard:settings:message_count' => "Number of messages to show",
		
		// iZap Videos widget
		'group_custom_layout:widgets:izap_videos:title' => "iZap Videos",
		'group_custom_layout:widgets:izap_videos:description' => "Show the latest iZap Videos",
		'group_custom_layout:widgets:izap_videos:settings:title' => "iZap Videos settings",
		'group_custom_layout:widgets:izap_videos:settings:video_count' => "Number of videos to show",
		
		// Event Calendar widget
		'group_custom_layout:widgets:event_calendar:title' => "Event Calendar",
		'group_custom_layout:widgets:event_calendar:description' => "Show the upcomming events",
		'group_custom_layout:widgets:event_calendar:settings:title' => "Event Calendar settings",
		'group_custom_layout:widgets:event_calendar:settings:event_count' => "Number of events to show",
		
		// Group River widget
		'group_custom_layout:widgets:groupriver:settings:title' => "Group activity settings",
		'group_custom_layout:widgets:groupriver:title' => "Group activity",
		'group_custom_layout:widgets:groupriver:description' => "Show the group activity",

		// Blog widget
		'group_custom_layout:widgets:blog:settings:title' => "Group blog settings",
		'group_custom_layout:widgets:blog:title' => "Group blog",
		'group_custom_layout:widgets:blog:description' => "Show the group blog entries",

		// Polls widget
		'group_custom_layout:widgets:polls:settings:title' => "Group polls settings",
		'group_custom_layout:widgets:polls:title' => "Group polls",
		'group_custom_layout:widgets:polls:description' => "Show the group polls",

		// Videolist widget
		'group_custom_layout:widgets:videolist:settings:title' => "Group video settings",
		'group_custom_layout:widgets:videolist:title' => "Group video",
		'group_custom_layout:widgets:videolist:description' => "Show the group videos",

		// Twitter widget
		'group_custom_layout:widgets:twitter:title' => "Twitter",
		'group_custom_layout:widgets:twitter:description' => "Show the latest tweets",
		'group_custom_layout:widgets:twitter:no_username' => "No Twitter username provided to show",
		'group_custom_layout:widgets:twitter:settings:title' => "Twitter settings",
		'group_custom_layout:widgets:twitter:settings:tweet_count' => "Number of tweets to show",
		'group_custom_layout:widgets:twitter:settings:twitter_username' => "Twitter username",
		
		// RSS widget (based on SimplePie)
		'group_custom_layout:widgets:rss:title' => "RSS Feed",
		'group_custom_layout:widgets:rss:description' => "Show a RSS feed (based on SimplePie)",
		'group_custom_layout:widgets:rss:error:notset' => "No RSS Feed URL provided",
		'group_custom_layout:widgets:rss:post_date' => "Posted on: %s",
		'group_custom_layout:widgets:rss:error:notfind' => "No Items found",
		'group_custom_layout:widgets:rss:settings:title' => "RSS Feed settings",
		'group_custom_layout:widgets:rss:settings:rss_count' => "Number of feeds to show",
		'group_custom_layout:widgets:rss:settings:rssfeed' => "URL of the RSS feed",
		'group_custom_layout:widgets:rss:settings:excerpt' => "Show an excerpt",
		'group_custom_layout:widgets:rss:settings:post_date' => "Show post date",
		'group_custom_layout:widgets:rss:settings:compatibility' => "Compatibility check",
		'group_custom_layout:widgets:rss:settings:permission' => "Permissions check (for caching)",
		
		// Free HTML widget
		'group_custom_layout:widgets:free_html:title' => "Free HTML",
		'group_custom_layout:widgets:free_html:description' => "Add custom HTML content to the group page",
		'group_custom_layout:widgets:free_html:settings:title' => "Free HTML settings",
		'group_custom_layout:widgets:free_html:settings:widget_title' => "Title (optional)",
		'group_custom_layout:widgets:free_html:settings:html_content' => "HTML content",
		
		// Reset
		'group_custom_layout:action:reset:error:input' => "Incorrect input provided",
		'group_custom_layout:action:reset:error:no_group' => "The supplied GUID is not an ElggGroup",
		'group_custom_layout:action:reset:error:no_custom' => "This group doesn't have a Custom Layout to remove",
		'group_custom_layout:action:reset:error:remove' => "Error while removing Custom Layout, please try again",
		'group_custom_layout:action:reset:success' => "Custom Layout successfully removed",
		
		// Save
		'group_custom_layout:action:save:error:input' => "Incorrect input provided",
		'group_custom_layout:action:save:error:no_group' => "The supplied GUID is not an ElggGroup",
		'group_custom_layout:action:save:error:add_to_group' => "Error while adding Custom Layout to group",
		'group_custom_layout:action:save:success:group' => "Custom Layout successfully saved",
		'group_custom_layout:action:save:error:last_save' => "Error while saving existing Custom Layout",
		'group_custom_layout:action:save:success:existing' => "Custom Layout successfully edited",
		
		'group_custom_layout:action:save:error:no_widget' => "No Group Widget for id: %s",
		'group_custom_layout:action:save:error:widget_save' => "Error while saving Group Widget: %s",
		
		'group_custom_layout:action:save:error:title_color' => "Error while saving title color",
		'group_custom_layout:action:save:success:title_color' => "Title color successfully saved",
		
		'group_custom_layout:action:save:error:border_color' => "Error while saving border color",
		'group_custom_layout:action:save:success:border_color' => "Border color successfully saved",
		
		'group_custom_layout:action:save:error:background_color' => "Error while saving background color",
		'group_custom_layout:action:save:success:background_color' => "Background color successfully saved",
		
		'group_custom_layout:action:save:error:background' => "Background image was not changed",
		'group_custom_layout:action:save:success:background' => "Background image successfully saved",

		'group_custom_layout:action:save:success:widget_footer_background_color' => "Widget footer background color successfully saved",
		'group_custom_layout:action:save:error:widget_footer_background_color' => "Error while saving widget footer background color",

		'group_custom_layout:action:save:success:widget_footer_color' => "Widget footer link color successfully saved",
		'group_custom_layout:action:save:error:widget_footer_color' => "Error while saving widget footer link color",


		
	);
	
	add_translation("en", $english);
?>
