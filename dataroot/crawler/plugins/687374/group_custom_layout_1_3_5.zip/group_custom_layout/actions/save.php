<?php 

	action_gatekeeper();
	gatekeeper();
	group_gatekeeper();
	
	$group_guid = (int) get_input("group_guid");
	
	if(!empty($group_guid) && $group = get_entity($group_guid)){
		if($group instanceof ElggGroup){
			// Check if custom layout allready exists
			$existing = false;
			if($group->countEntitiesFromRelationship(GROUP_CUSTOM_LAYOUT_RELATION) > 0){
				$layout = $group->getEntitiesFromRelationship(GROUP_CUSTOM_LAYOUT_RELATION);
				$layout = $layout[0];
				$existing = true;
			} else {
				$layout = new ElggObject();
				$layout->subtype = GROUP_CUSTOM_LAYOUT_SUBTYPE;
				$layout->owner_guid = $group->guid;
				$layout->container_guid = $group->guid;
				$layout->access_id = ACCESS_PUBLIC;
				
				$layout->save();
			}
			
			// adding background 1
			$layout->enable_background1 = get_input("enable_background1", "no");
			if ($layout->enable_background1 != "no")
			{
			$background1 = $_FILES["background1File"];
			if(!empty($background1) && !$background1["error"] && stristr($background1["type"], "image")){
				$bgf1 = new ElggFile();
				$bgf1->owner_guid = $group->guid;
				
				$bgf1->setFilename(GROUP_CUSTOM_LAYOUT_BACKGROUND . "_" . $group->guid . "_1");
				$bgf1->open("write");
				$bgf1->write(get_uploaded_file("background1File"));
				$bgf1->close();
				
				system_message(elgg_echo("group_custom_layout:action:save:success:background"));
			} 
			}
			$layout->save();

			// adding background 2
			$layout->enable_background2 = get_input("enable_background2", "no");
			if ($layout->enable_background2 != 'no')
			{
			$background2 = $_FILES["background2File"];
			
			if(!empty($background2) && !$background2["error"] && stristr($background2["type"], "image")){
				$bgf2 = new ElggFile();
				$bgf2->owner_guid = $group->guid;
				$bgf2->setFilename(GROUP_CUSTOM_LAYOUT_BACKGROUND . "_" . $group->guid . "_2");
				$bgf2->open("write");
				$bgf2->write(get_uploaded_file("background2File"));
				$bgf2->close();
				
				system_message(elgg_echo("group_custom_layout:action:save:success:background"));
			}
			}
			
			$layout->save();

			
			// adding colors
			$layout->enable_colors = get_input("enable_colors", "no");
			$layout->enable_widget_footer_colors = get_input("enable_widget_footer_colors", "no");
			$layout->background1Repeat = get_input("background1Repeat");
			$layout->background1Position = get_input("background1Position");
			$layout->background1Attachment = get_input("background1Attachment");
			$layout->background1 = get_input("background1File");
			$layout->background2Repeat = get_input("background2Repeat");
			$layout->background2Position = get_input("background2Position");
			$layout->background2Attachment = get_input("background2Attachment");
			$layout->background2 = get_input("background2File");
			$layout->use_header = get_input("use_header");
			$layout->use_fields = get_input("use_fields");
			$background_color = get_input("background_color");
			$border_color = get_input("border_color");
			$title_color = get_input("title_color");
			$widget_footer_background_color = get_input("widget_footer_background_color");
			$widget_footer_color = get_input("widget_footer_color");
			
			if(!empty($background_color)){
				$layout->background_color = $background_color;
				system_message(elgg_echo("group_custom_layout:action:save:success:background_color"));
			} else {
				register_error(elgg_echo("group_custom_layout:action:save:error:background_color"));
			}
			
			if(!empty($border_color)){
				$layout->border_color = $border_color;
				system_message(elgg_echo("group_custom_layout:action:save:success:border_color"));
			} else {
				register_error(elgg_echo("group_custom_layout:action:save:error:border_color"));
			}
			
			if(!empty($title_color)){
				$layout->title_color = $title_color;
				system_message(elgg_echo("group_custom_layout:action:save:success:title_color"));
			} else {
				register_error(elgg_echo("group_custom_layout:action:save:error:title_color"));
			}

			if(!empty($widget_footer_background_color)){
				$layout->widget_footer_background_color = $widget_footer_background_color;
				system_message(elgg_echo("group_custom_layout:action:save:success:widget_footer_background_color"));
			} else {
				register_error(elgg_echo("group_custom_layout:action:save:error:widget_footer_background_color"));
			}

			if(!empty($widget_footer_color)){
				$layout->widget_footer_color = $widget_footer_color;
				system_message(elgg_echo("group_custom_layout:action:save:success:widget_footer_color"));
			} else {
				register_error(elgg_echo("group_custom_layout:action:save:error:widget_footer_color"));
			}
			
			$layout->save();
			
			// adding widgets
			// Left
			$left_widgets = get_input("left_widgets");
			$left_order = array();
			
			if(!empty($left_widgets)){
				$left_array = explode(",", $left_widgets);
				
				foreach($left_array as $widget_id){
					
					$widget_id = str_replace("group_widget_", "", $widget_id);
					
					if(is_numeric($widget_id)){
						$widget = get_entity($widget_id);
					} else {
						$widget = new ElggObject();
						$widget->subtype = GROUP_CUSTOM_LAYOUT_WIDGET;
						$widget->owner_guid = $group->guid;
						$widget->container_guid = $group->guid;
						$widget->title = $widget_id;
						$widget->access_id = ACCESS_PUBLIC;
						
						$widget->save();
					}
					
					if(!empty($widget)){
						$settings = get_input("group_widgets_" . $widget_id . "_settings", "", false);
						foreach($settings as $key => $value){
							$widget->$key = $value;
						}
						
						if($widget->save()){
							$layout->addRelationship($widget->guid, GROUP_CUSTOM_LAYOUT_WIDGET_RELATION);
							$left_order[] = $widget->guid;
						} else {
							register_error(sprintf(elgg_echo("group_custom_layout:action:save:error:widget_save"), $widget_id));
						}
					} else {
						register_error(sprintf(elgg_echo("group_custom_layout:action:save:error:no_widget"), $widget_id));
					}
				}
			}
			
			// Cleanup / re-order left widgets
			if(!empty($left_order)){
				$layout->left_widgets = implode(",", $left_order);
			} else {
				remove_metadata($layout->guid, "left_widgets");
			}
			
			// Right
			$right_widgets = get_input("right_widgets");
			$right_order = array();
			
			if(!empty($right_widgets)){
				$right_array = explode(",", $right_widgets);
				
				foreach($right_array as $widget_id){
					$widget_id = str_replace("group_widget_", "", $widget_id);
					
					if(is_numeric($widget_id)){
						$widget = get_entity($widget_id);
					} else {
						$widget = new ElggObject();
						$widget->subtype = GROUP_CUSTOM_LAYOUT_WIDGET;
						$widget->owner_guid = $group->guid;
						$widget->container_guid = $group->guid;
						$widget->title = $widget_id;
						$widget->access_id = ACCESS_PUBLIC;
						
						$widget->save();
					}
					
					if(!empty($widget)){
						$settings = get_input("group_widgets_" . $widget_id . "_settings", "", false);
						foreach($settings as $key => $value){
							$widget->$key = $value;
						}
						
						if($widget->save()){
							$layout->addRelationship($widget->guid, GROUP_CUSTOM_LAYOUT_WIDGET_RELATION);
							$right_order[] = $widget->guid;
						} else {
							register_error(sprintf(elgg_echo("group_custom_layout:action:save:error:widget_save"), $widget_id));
						}
					} else {
						register_error(sprintf(elgg_echo("group_custom_layout:action:save:error:no_widget"), $widget_id));
					}
				}
			}
			
			// Cleanup / re-order right widgets 
			if(!empty($right_order)){
				$layout->right_widgets = implode(",", $right_order);
			} else {
				remove_metadata($layout->guid, "right_widgets");
			}
			
			// cleaning up old widgets
			$widgets_order = array_merge($left_order, $right_order);
			$widget_count = $layout->countEntitiesFromRelationship(GROUP_CUSTOM_LAYOUT_WIDGET_RELATION);
			
			if($widget_count > 0){
				$widgets = $layout->getEntitiesFromRelationship(GROUP_CUSTOM_LAYOUT_WIDGET_RELATION, $widget_count);
				
				foreach($widgets as $widget){
					if(!in_array($widget->guid, $widgets_order)){
						echo $widget->guid . "<br />";
						$widget->delete();
					}
				}
			}
			
			// Last save
			$last_save = $layout->save();
			
			// Add layout to group
			if($existing && $last_save){
				system_message(elgg_echo("group_custom_layout:action:save:success:existing"));
			} elseif($existing && !$last_save){
				register_error(elgg_echo("group_custom_layout:action:save:error:last_save"));
			} elseif(!$existing && $group->addRelationship($layout->guid, GROUP_CUSTOM_LAYOUT_RELATION)){
				system_message(elgg_echo("group_custom_layout:action:save:success:group"));
			} else {
				register_error(elgg_echo("group_custom_layout:action:save:error:add_to_group"));
			}
		} else {
			register_error(elgg_echo("group_custom_layout:action:save:error:no_group"));
		}
	} else {
		register_error(elgg_echo("group_custom_layout:action:save:error:input"));
	}

	forward($CONFIG->wwwroot . "pg/groups/" . $group->guid);
?>
