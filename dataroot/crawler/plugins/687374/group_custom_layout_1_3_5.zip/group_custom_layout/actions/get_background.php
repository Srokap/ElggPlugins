<?php 
	$guid = (int) get_input("group_guid");
	$image_id = (int) get_input("image_id");

	if(!empty($guid) && $group = get_entity($guid)){
		if($group instanceof ElggGroup){
			// Check if custom layout exists
			if($group->countEntitiesFromRelationship(GROUP_CUSTOM_LAYOUT_RELATION) > 0){
				$layout = $group->getEntitiesFromRelationship(GROUP_CUSTOM_LAYOUT_RELATION);
				$layout = $layout[0];
				// Check if background isset
				if ($image_id == 1){
					$bg_to_return = $layout->enable_background1;}
				if ($image_id == 2){
					$bg_to_return = $layout->enable_background2;}
				if(!empty($bg_to_return) && $bg_to_return == "yes"){
					$bgf = new ElggFile();
					$bgf->owner_guid = $group->guid;
					$bgf->setFilename(GROUP_CUSTOM_LAYOUT_BACKGROUND . "_" . $group->guid . "_" . $image_id);
					$background = $bgf->grabFile();
					if(!empty($background)){

						header("Content-type: image");
						header('Expires: ' . date('r', time() + 864000));
						header("Pragma: public");
						header("Cache-Control: public");
						header("Content-Length: " . strlen($background));
						echo $background;
					}
				}
			}
		}
	}
	
	exit();
?>
