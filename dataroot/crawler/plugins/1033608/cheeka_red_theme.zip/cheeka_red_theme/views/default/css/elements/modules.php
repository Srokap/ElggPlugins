/* ***************************************
	Modules
*************************************** */
.elgg-module {
	overflow: hidden;
	margin-bottom: 20px;
}

/* Aside */
.elgg-module-aside .elgg-head {
	border-bottom: 1px solid #0054A7;
	
	margin-bottom: 5px;
	padding-bottom: 5px;
}

/* Info */
.elgg-module-info > .elgg-head {
	background: #e4e4e4;
	padding: 5px;
	margin-bottom: 10px;
	
	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
.elgg-module-info > .elgg-head * {
	color: #000000}

/* Popup */
.elgg-module-popup {
	background-color: white;
	border: 1px solid #000000;
	
	z-index: 9999;
	margin-bottom: 0;
	padding: 5px;
}
.elgg-module-popup > .elgg-head {
	margin-bottom: 5px;
}
.elgg-module-popup > .elgg-head * {
	color: #0054A7;
}

/* Dropdown */
.elgg-module-dropdown {
	background-color:white;
	border:5px solid #000000;
	display:none;
	
	width: 210px;
	padding: 11px;
	margin-right: 0px;
	z-index:100;
	
	
	position:absolute;
	right: 0px;
	top: 100%;
}

/* Featured */
.elgg-module-featured {
	
}
.elgg-module-featured > .elgg-head {
	padding: 5px;
}
.elgg-module-featured > .elgg-head * {
	color: #0054A7;
}
.elgg-module-featured > .elgg-body {
	padding: 10px;
}

/* ***************************************
	Widgets
*************************************** */
.elgg-widgets {
	float: right;
	min-height: 30px;
}
.elgg-widget-add-control {
	text-align: right;
	margin: 5px 5px 15px;
}
.elgg-widgets-add-panel {
	padding: 10px;
	margin: 0 5px 15px;
	background: url(<?php echo $vars['url']; ?>mod/cheeka_red_theme/graphics/add_widget.gif);
	border: 1px solid #CACFCF;
}
<?php //@todo location-dependent style: make an extension of elgg-gallery ?>
.elgg-widgets-add-panel li {
	float: left;
	margin: 1px 10px;
	width: 200px;
	padding: 4px;
	background-color: #F5F10A;
	border: 1px solid #CACFCF;
	font-weight: bold;
}
.elgg-widgets-add-panel li a {
	display: block;
}
.elgg-widgets-add-panel .elgg-state-available {
	color: #000000;
	cursor: pointer;
}
.elgg-widgets-add-panel .elgg-state-available:hover {
	background-color: #8E9191;
}
.elgg-widgets-add-panel .elgg-state-unavailable {
	color: #888;
}

.elgg-module-widget {
	background: url(<?php echo $vars['url']; ?>mod/cheeka_red_theme/graphics/panel.png);
	padding: 2px;
	margin: 0 5px 15px;
	position: relative;
}
.elgg-module-widget:hover {
	background: url(<?php echo $vars['url']; ?>mod/cheeka_red_theme/graphics/panel.png);
}
.elgg-module-widget > .elgg-head {
	background:url(<?php echo $vars['url']; ?>mod/cheeka_red_theme/graphics/panel.png);
	height: 32px;
	overflow: hidden;
}
.elgg-module-widget > .elgg-head h3 {
	float: left;
	padding:10px 60px 0 20px;
	color: #ffffff;
}
.elgg-module-widget.elgg-state-draggable > .elgg-head {
	cursor: move;
}
.elgg-module-widget > .elgg-head a {
	position: absolute;
	top: 4px;
	display: inline-block;
	width: 18px;
	height: 18px;
	padding: 0px 5px 0 0;
}
a.elgg-widget-collapse-button {
	color: #000000;
}
a.elgg-widget-collapse-button:hover,
a.elgg-widget-collapsed:hover {
	color: #ffffff;
	text-decoration: none;
}
a.elgg-widget-collapse-button:before {
	content: "\25BC";
}
a.elgg-widget-collapsed:before {
	content: "\25BA";
}
a.elgg-widget-delete-button {
	right: 5px;
}
a.elgg-widget-edit-button {
	right: 25px;
}
.elgg-module-widget > .elgg-body {
	background-color: #F5F10A;
	width: 100%;
	overflow: hidden;
	border-top: 1px solid #C0C0C0;
}
.elgg-widget-edit {
	display: none;
	width: 96%;
	padding: 2%;
	border-bottom: 1px solid #C0C0C0;
	background-color: none;
}
.elgg-widget-content {
	padding: 10px;
}
.elgg-widget-placeholder {
	border: 1px dashed #C0C0C0;
	margin-bottom: 15px;
}