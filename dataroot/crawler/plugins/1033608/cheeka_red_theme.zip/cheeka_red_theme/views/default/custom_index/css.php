<?php
/**
 * Custom Index CSS
 *
 */
?>

/*******************************
	Custom Index
********************************/
.custom-index {
	padding: 10px 0;
}
.custom-index .elgg-module-featured {
}
.custom-index .elgg-module-featured:hover {
}
