<?php
function cheeka_red_theme_init() {
	elgg_extend_view ('page/elements/head','cheeka_red_theme/meta');
	elgg_unregister_menu_item('topbar', 'elgg_logo');
}
elgg_register_event_handler('init', 'system', 'cheeka_red_theme_init');
?>