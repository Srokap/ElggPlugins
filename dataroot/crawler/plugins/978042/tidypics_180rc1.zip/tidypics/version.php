<?php
/**
 * Version of this plugin.
 * Used for the upgrade system.
 */

$version = 2012020901;
