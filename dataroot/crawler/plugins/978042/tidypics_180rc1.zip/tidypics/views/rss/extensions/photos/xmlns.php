<?php
/**
 * Support media files by adding a namespace
 *
 * @author Cash Costello
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU General Public License v2
 */

?> xmlns:media="http://search.yahoo.com/mrss/"