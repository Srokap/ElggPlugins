<?php
/**
 * Deactive Tidypics
 *
 * @author Cash Costello
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU General Public License v2
 */

update_subtype('object', 'album');
update_subtype('object', 'image');
