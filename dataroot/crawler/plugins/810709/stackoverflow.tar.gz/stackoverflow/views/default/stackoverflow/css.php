<?php
?>

.search-result-table {
	border-top:1px solid black;
	display:table;
	width:100%;
}

.search-result-cell {
	display: table-cell;
}

.question-details {
	border: 1px solid silver;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	border-radius: 4px;
	padding: 5px;
}

#stackoverflow-search-results {
	border: 1px solid silver;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	border-radius: 4px;
	padding: 5px;
}

