<h3>Search Results</h3>
<div id="ajax-progress" style="width:100%;">
	<div style="display:table-cell;">
		<img alt="The ajax progress bar" src="<?php echo $vars['url'];?>mod/stackoverflow/graphics/ajax-loader.gif" />
	</div>
</div>
<div style="" class="search-result-table">
	<div class="search-result-cell" style="width:50%;" id="stackoverflow-search-results">
		<div style="display:table;">No search results</div>
	</div>
	<div class="question-details search-result-cell">
	</div>
</div>


