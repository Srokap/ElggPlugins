<?php
/**
 * Elgg Search css
 * 
 */
?>

/**********************************
Search plugin
***********************************/
.elgg-page-header .elgg-search {
	bottom: 5px;
	height: 23px;
	position: absolute;
	right: 0;
    top:40px;
}
.elgg-page-header .elgg-search input[type=text] {
	width: 200px;
}
.elgg-page-header .elgg-search input[type=submit] {
	color: white;
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	background:#000;
	border: solid 1px #FFF;
	height: 26px;
	margin:0;
    padding:3px 6px 5px 6px;
    border:none;
	cursor: pointer;
    width: auto;
}
.elgg-page-header .elgg-search input[type=submit]:hover {
	background: #FFF;
	color: #000;
}
.elgg-search input[type=text] {
	font-family:Arial, Helvetica, sans-serif;
	background-color:#dedede;
	border:1px solid #a6a6a6;
	color:#151515;
	font-size:12px;
	margin:0;
	height:26px;
    padding:0 6px;
}
.elgg-search input[type=text]:focus, .elgg-search input[type=text]:active {
	background-color:#FFF;
	border:1px solid #151515;
	color:#151515;
}

.search-list li {
	padding: 5px 0 0;
}
.search-heading-category {
	margin-top: 20px;
}

.search-highlight {
	background-color: #b3daff;
}
.search-highlight-color1 {
	background-color: #b3daff;
}
.search-highlight-color2 {
	background-color: #8bffff;
}
.search-highlight-color3 {
	background-color: #fdffb5;
}
.search-highlight-color4 {
	background-color: #b2b2b2;
}
.search-highlight-color5 {
	background-color: #3086d8;
}
