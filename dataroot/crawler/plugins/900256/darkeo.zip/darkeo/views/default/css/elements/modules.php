/* ***************************************
	Modules
*************************************** */
.elgg-module {
	overflow: hidden;
	margin-bottom: 20px;
    color: #151515;
}

/* Aside */
.elgg-module-aside .elgg-head {
	margin-bottom: 5px;
	padding-bottom: 5px;
}

.elgg-module-aside .elgg-head h3 {
color: #000;
}

.custom-index .elgg-module-aside .elgg-head h3 {
color: #FFF;
}

.custom-index .elgg-module-featured  h2 {
color: #FFF;
}

.elgg-module-aside a:link, .elgg-module-aside a:visited {
color: #909090;
text-decoration: none;
}

.elgg-module-aside a:hover, .elgg-module-aside a:active {
color: #151515;
text-decoration: underline;
}


/* Info */
.elgg-module-info > .elgg-head {
	padding: 5px 0;
	margin-bottom: 10px;
}
.elgg-module-info > .elgg-head * {
	color: #000;
}

/* Popup */
.elgg-module-popup {
    background: #FFF;
    color: #000;
	border: 1px solid #151515;	
	
	z-index: 9999;
	margin-bottom: 0;
	padding: 5px;

}
.elgg-module-popup > .elgg-head {
	margin-bottom: 5px;
}
.elgg-module-popup > .elgg-head * {
	color: #151515;
}

/* Dropdown */
.elgg-module-dropdown {
	background: #FFF;
    color: #000;
	border:5px solid #CCC;
	
	display:none;
	
	width: 210px;
	padding: 12px;
	margin-right: 0px;
	z-index:100;
	
	-webkit-box-shadow: 0 3px 3px rgba(0, 0, 0, 0.45);
	-moz-box-shadow: 0 3px 3px rgba(0, 0, 0, 0.45);
	box-shadow: 0 3px 3px rgba(0, 0, 0, 0.45);
	
	position:absolute;
	right: 0px;
	top: 100%;
}

/* Featured */
.elgg-module-featured {
background: #000;
border: 1px solid #000;
color: #FFF;
}
.elgg-module-featured > .elgg-head {
	padding: 5px;
    border-bottom: 1px solid #151515;
    background: #000;
    color: #fff;
}
.elgg-module-featured > .elgg-head * {
	color:#FFF;
    text-transform: uppercase;
}
.elgg-module-featured > .elgg-body {
	padding: 10px;
}

/* ***************************************
	Widgets
*************************************** */
.elgg-widgets {
	float: right;
	min-height: 30px;
}
.elgg-widget-add-control {
	text-align: right;
	margin: 5px 5px 15px;
}
.elgg-widgets-add-panel {
	padding: 10px;
	margin: 0 5px 15px;
    border: 1px solid #151515;
}
<?php //@todo location-dependent style: make an extension of elgg-gallery ?>
.elgg-widgets-add-panel li {
	float: left;
	margin: 2px 10px;
	width: 200px;
	padding: 4px;
	background:#909090;
	font-weight: bold;
}
.elgg-widgets-add-panel li a {
	display: block;
}
.elgg-widgets-add-panel .elgg-state-available {
	color: #FFF;
	cursor: pointer;
}
.elgg-widgets-add-panel .elgg-state-available:hover {
	background:#909090;
}
.elgg-widgets-add-panel .elgg-state-unavailable {
    background:#49515B;
	color:#151515;
}

.elgg-module-widget {
	margin: 0 5px 15px;
	position: relative;
    border: 1px solid #151515;
    background: #000;
    color: #FFF;
}
.elgg-module-widget:hover {

}
.elgg-module-widget > .elgg-head {
	color: #FFF;
    border-bottom: 1px solid #151515;
    background: url(<?php echo $vars['url']; ?>mod/darkeo/graphics/gradients/bg40.png) repeat;
	height: 26px;
	overflow: hidden;
}
.elgg-module-widget > .elgg-head h3 {
	float: left;
	padding: 4px 45px 0 20px;
	color: #FFF;
}
.elgg-module-widget.elgg-state-draggable > .elgg-head {
	cursor: move;
}
.elgg-module-widget > .elgg-head a {
	position: absolute;
	top: 4px;
	display: inline-block;
	width: 18px;
	height: 18px;
	padding: 2px 2px 0 0;
}
a.elgg-widget-collapse-button {
	left: 5px;
	color: #c5c5c5;
}
a.elgg-widget-collapse-button:hover,
a.elgg-widget-collapsed:hover {
	color: #9d9d9d;
	text-decoration: none;
}
a.elgg-widget-collapse-button:before {
	content: "\25BC";
}
a.elgg-widget-collapsed:before {
	content: "\25BA";
}
a.elgg-widget-delete-button {
	right: 5px;
}
a.elgg-widget-edit-button {
	right: 25px;
}
.elgg-module-widget > .elgg-body {
	width: 100%;
	overflow: hidden;
}
.elgg-widget-edit {
	display: none;
	width: 96%;
	padding: 2%;
    border-bottom: 1px solid #151515;
}
.elgg-widget-content {
	padding: 10px;
}
.elgg-widget-content .elgg-form-messageboard-add{
	margin-right: 10px;
}
.elgg-widget-placeholder {
	border: 1px dashed #dedede;
	margin-bottom: 15px;
}