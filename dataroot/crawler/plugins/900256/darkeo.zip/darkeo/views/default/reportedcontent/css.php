<?php
/**
 * Elgg reported content CSS
 */

?>
/* Reported Content */
.elgg-icon-report-this {
	height:14px;
    margin-right:6px;
	background: url(<?php echo elgg_get_site_url(); ?>mod/elggzone_darkeo/graphics/icons/icon_reportthis.png) no-repeat left top;
}
