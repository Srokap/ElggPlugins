<?php
/**
 * User dashboard CSS
 */
?>

#dashboard-info {
	border:1px solid #151515;
	margin-bottom: 15px;
}
