<?php

$english = array(

	// topbar
	'darkeo:guest'			=> 'Welcome Guest',
	'darkeo:guest:tooltip'	=> 'Go to registration',
		
);

add_translation("en", $english);
