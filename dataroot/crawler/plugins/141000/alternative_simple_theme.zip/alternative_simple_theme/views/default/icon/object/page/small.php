<?php
	echo $vars['url'] . "mod/alternative_simple_theme/graphics/file_icons/pages.gif";
?>
