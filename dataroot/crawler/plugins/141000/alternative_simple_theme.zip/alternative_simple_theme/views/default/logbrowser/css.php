<?php

?>

#logbrowser_search_area {
	margin: 3px;
}

#logbrowserSearchform {
	background: #ededed;
	-moz-border-radius-bottomleft:10px;
	-moz-border-radius-bottomright:10px;
	-moz-border-radius-topleft:10px;
	-moz-border-radius-topright:10px;
	-webkit-border-top-left-radius:10px;
	-webkit-border-top-right-radius:10px;
	-webkit-border-bottom-left-radius:10px;
	-webkit-border-bottom-right-radius:10pxw;
	padding:10px;
	margin-bottom:10px;
}
#logbrowserSearchform .submit_button {
	margin:0 10px 0 10px;
}

.log_entry {
	margin: 2px 0px 2px 0px;
	width: 720px;
	font-size: 90%;
}
.log_entry td {
	background-color: #dedede;
}

.log_entry_user {
	width: 120px;
}

.log_entry_time {
	width: 280px;
	padding-left:8px;
}

.log_entry_item {
	
}

.log_entry_action {
	width: 75px;
}