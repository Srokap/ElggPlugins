<?php
	echo $vars['url'] . "mod/alternative_simple_theme/graphics/group_icons/defaulttiny.gif";
?>
