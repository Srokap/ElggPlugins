
<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">
<!-- site name -->
	<div id="site_name"><h1><a href="<?php echo $vars['url']; ?>"><?php echo $vars['config']->sitename; ?></a></h1></div>
	
	<div id="menu">
		<div id="menu_inner">
		<a href="<?php echo $vars['url']; ?>" title="Home"><span>Aleya.pl</span></a>
		<a href="<?php echo $vars['url']; ?>mod/riverdashboard/" title="Latest Activity"><span>AKTYWNOŚĆ</span></a>
		<a href="<?php echo $vars['url']; ?>mod/blog/everyone.php" title="Blog"><span>BLOG</span></a>
		<a href="<?php echo $vars['url']; ?>mod/izap_videos/all.php" title="Video"><span>VIDEO</span></a>
		<a href="<?php echo $vars['url']; ?>pg/groups/world/" title="Groups"><span>SPOŁECZNOŚCI</span></a>
		<a href="<?php echo $vars['url']; ?>pg/photos/world/" title="Pages"><span>FOTOGRAFIE I ALBUMY</span></a>
		</div>
	</div>

<div class="clearfloat"></div>
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
