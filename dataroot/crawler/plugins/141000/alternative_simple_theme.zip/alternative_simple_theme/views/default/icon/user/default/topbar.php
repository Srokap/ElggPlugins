<?php
	echo $vars['url'] . "mod/alternative_simple_theme/graphics/user_icons/defaulttopbar.gif";
?>
