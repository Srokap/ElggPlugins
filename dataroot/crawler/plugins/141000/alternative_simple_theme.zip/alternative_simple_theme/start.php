<?php

    /**
     * Alternative Simple theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function alternativesimple_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','alternativesimple_init');
	
?>
