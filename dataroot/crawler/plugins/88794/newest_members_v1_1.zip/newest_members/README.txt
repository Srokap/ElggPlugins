/**

    README.php, part of Newest_members
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.


    Elgg version: 1.5
    Title: Newest_Members
    Intro: Shows last registered users
    Description: Makes widget to show last registered users. Very simple and very similar to Elgg 1.5 standard plugin. Have some differences in configuration.
    Plugin is developed by Web100 Net Technology Center, Ltd. http://web100.com.ua  under the assignment of Lorinthe,BV.
    Dependencies: No
    Version: 1.1
    Licence: GPL v.3						    	
*/

The Elgg 1.x newest_members plugin allows to use widget with list of 
newest members. Admin can setup number of members in list.

*Activating the newest_members plugin*

Simply extract the newest_members plugin into the mod directory and 
activate it as usual using the Elgg 1.x tool administration.

This creates a "newest_members" widget item in widgets listr.

*Plugin settings*

Admin can use Elgg 1.x tool administration to configure number of 
newest members in widget list.

