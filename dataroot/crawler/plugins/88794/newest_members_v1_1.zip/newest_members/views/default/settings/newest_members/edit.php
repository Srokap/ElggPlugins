<?php
/**
    edit.php, part of Newest_members
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
	Declared variables:
	display_members 		- count of members for displaying in widget
	display_members_on_line - maximum count of members on each line
*/
?>
<table border="0">
<tr>
    <td><?php echo elgg_echo('newest_members:members_display');?></td>
    <td>&nbsp;</td>
    <td><input type="text" name="params[display_members]" value="<?php echo $vars['entity']->display_members;?>"></td>
</tr>
<!--
<tr>
    <td><?php echo elgg_echo('newest_members:members_display_on_line');?></td>
    <td>&nbsp;</td>
    <td><input type="text" name="params[display_members_on_line]" value="<?php echo $vars['entity']->display_members_on_line;?>"></td>
</tr>
-->
</table>