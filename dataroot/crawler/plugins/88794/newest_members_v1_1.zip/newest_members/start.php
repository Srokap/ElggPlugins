<?php
/**
    start.php, part of Newest_members
    Copyright (C) 2009, Lorinthe, BV and Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
	    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
			    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
					    
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
						    	
*/

// unique function for lugin initialization
function newest_members_init(){
    global $CONFIG;
    // registering languages translation constants
    register_translations($CONFIG->pluginspath . "newest_members/languages/");
    // register plugin widget
    add_widget_type('newest_members', elgg_echo('newest_members:widget:title'), elgg_echo('newest_members:widget:description'));
	// registering css styles
	extend_view('css','newest_members/css');
}

// register plugin event handler for plugin initialization
register_elgg_event_handler('init', 'system', 'newest_members_init');

?>
