<?php
/**
 * Spanish language file. Traducción de Rafa Atencia
 */

$spanish = array(
	
	/**
	 * Menu items and titles
	 */
	'answers' => "Preguntas",
	'answers:add' => "Nueva pregunta",
	'answers:question' => "Pregunta",
	'answers:questions' => "Preguntas",
	'answers:answers' => "Respuestas",
	'answers:question:pretitle' => "Pregunta: ",
	'answers:answers:best' => "Mejor Respuesta",
	'answers:answers:other_answers' => 'Otras Respuestas',
	'answers:answer' => "Respuesta",
	'answers:user' => "Preguntas de %s",
	'answers:user:friends' => "%s's following questions",
	'answers:your' => "Tus preguntas",
	'answers:group' => "Respuestas de grupo",
	'answers:group:filter' => "Grupos",
	'answers:group:title' => "Preguntas de grupo",
	'answers:group:pretitle' => "Pregunta de grupo: ",
	'answers:posttitle' => "preguntas de %s: %s",
	'answers:friends' => "Preguntas de amigos",
	'answers:everyone' => "Todas las preguntas del sitio",
	'answers:via' => "via questions",
	'answers:read' => "Leer preguntas",
	'answers:question:add' => "Haz una pregunta",
	'answers:question:groupadd' => "Haz una pregunta en %s",
	'answers:question:edit' => "Editar pregunta",
	'answers:question:fulltitle' => "%s",
	'answers:questiontitle' => "Pregunta",
	'answers:questiondetails' => "Detalles adicionales",
	'answers:strapline' => "%s",
	'item:object:question' => 'Preguntas',
	'item:object:answer' => 'Respuestas',
	'answers:answer:add' => "Responde a esta pregunta",
	'answers:answer:answer' => "Respuesta",
	'answers:answer:mustbeingroup' => "Debes ser miembro de %s para responder o comentar esta pregunta.",
	'answers:questions:more' => "Más preguntas",
	'answers:questions:none' => "No hay preguntas aquí.",
	'groups:enableanswers' => "Habilitar respuestas de grupo",
	'answers:group:questions:none' => "Este grupo no tiene aún ninguna pregunta",
	'answers:question:tooltip:edit' => "Editar pregunta",
	'answers:question:tooltip:delete' => "Borrar pregunta",
	'answers:answer:tooltip:delete' => "Borrar respuesta",
	'answers:answer:tooltip:like' => "'Me gusta' esta respuesta",
	'answers:answer:tooltip:dislike' => "'No me gusta' esta respuesta",
	'answers:answer:tooltip:unlike' => "eliminar voto",
	'answers:answer:tooltip:choose' => "elegir esta respuesta como la mejor",
	'answers:question:new' => "Nueva pregunta",
	'answers:answer:new' => "Nueva respuesta",
	'answers:comment:comment' => "Añadir comentario",
	'answers:comment:save' => "Enviar",

	/**
	 * Answers river
	 */
	'question:river:created' => "%s preguntó %s",
	'question:river:answered' => "%s respondió la pregunta %s",
	'question:river:chosen' => "%s elige la mejor respuesta a la pregunta %s",
	'question:river:updated' => "%s actualizó la pregunta",
	'question:river:comment:question' => "%s comentó la pregunta %s",
	'question:river:comment:answer' => "%s comentó una respuesta a la pregunta %s",
	'answer:river:updated' => "%s actualizó una respuesta a la pregunta",

	/**
	 * Widget
	 */
	'answers:widget' => 'Mostrar las últimas preguntas',
	'answers:widget:numbertodisplay' => 'Número de preguntas',
	'answers:widget:type' => "Mostrar preguntas de",

	/**
	 * Status messages
	 */	
	'answers:question:posted' => "Tu pregunta se ha enviado correctamente.",
	'answers:question:updated' => "Tu pregunta se ha actualizado correctamente.",
	'answers:question:deleted' => "Tu pregunta se ha eliminado correctamente.",
	'answers:answer:posted' => "Tu respuesta se ha enviado correctamente.",
	'answers:answer:updated' => "Tu respuesta se ha actualizado correctamente.",
	'answers:answer:deleted' => "Tu respuesta se ha eliminado correctamente.",
	'answers:liked' => "Has marcado con 'Me gusta' una respuesta.",
	'answers:disliked' => "Has marcado con 'No me gusta' una respuesta.",
	'answers:unliked' => "Has quitado la marca 'Me gusta' a una respuesta.",
	'answers:answer:chosen' => "Tu respuesta favorita se ha elegido correctamente.",
	'answers:comment:posted' => "Se ha enviado correctamente tu comentario.",
	'answers:comment:updated' => "Se ha actualizado correctamente tu comentario.",
	'answers:comment:deleted' => "Se ha borrado correctamente tu comentario.",

	/**
	 * Error messages
	 */
	'answers:answer:blank' => "Lo sentimos: tu respuesta no puede estar en blanco.",
	'answers:error' => 'Algo ha ido mal. Por favor, inténtalo de nuevo.',
	'answers:save:failure' => "La respuesta que has enviado no se ha podido guardar. Por favor, inténtalo de nuevo",
	'answers:failure' => "Tu respuesta no se ha guardado. Por favor, inténtalo de nuevo.",
	'answers:blank' => "Lo sentimos: el título de tu pregunta no puede estar en blanco.",
	'answers:notfound' => "Lo sentimos: no se ha podido encontrar la pregunta especificada.",
	'answers:question:notdeleted' => "Lo sentimos: no se ha podido borrar esta pregunta.",
	'answers:liked:failure' => "Lo sentimos: No se ha guardado tu 'Me gusta'.",
	'answers:disliked:failure' => "Lo sentimos: No se ha guardado tu 'No me gusta'.",
	'answers:unliked:failure' => "Lo sentimos: No se ha guardado tu 'Me ha dejado de gustar'.",
	'answers:comment:blank' => "Lo sentimos: tu comentario no puede estar en blanco.",
	
	/**
	 * Email Notifications
	 */
	'answers:notify:question:subject' => "%s preguntó \"%s\"",
	'answers:notify:answer:subject' => "%s respondió a la pregunta \"%s\"",
	
	'answers:notify:body' => "Enlace a %s:\n%s",

	'answers:question:comment:email:subject' => "Comentario sobre la pregunta: %s",
	'answers:answer:comment:email:subject' => "Comentario sobre la respuesta a la pregunta: %s",
	'answers:question:comment:email:body' => "%s envió un comentario a la pregunta: %s

Texto del comentario:
%s

Enlace al comentario:
%s
",
	'answers:answer:comment:email:body' => "%s envió un comentario sobre una respuesta a la pregunta: %s

texto del comentario:
%s

Enlace al comentario:
%s
",

);
					
add_translation("es", $spanish);
