******* Sharemaps Plugin *******

Upload and share maps such as routes, placemarks etc using Google Maps.
 
This plugin is useful for travel communities giving users the option to upload and share map files (kml or kmz) or insert and share maps directly from Google Maps by using share "Link" option.

== Contents ==
1. Features
2. Bugs and Issues
3. ToDo


== 1. Features ==
- Google maps integration
- Upload google kml or kmz files
- Download maps shared by other users
- Insert map link directly from Google Maps, without need of uploading files


== 2. Bugs and Issues ==
If users upload map files and select "non public" access, maps will not be displayed. This happens because javascript cannot load elgg non public entities. You can override this by doing the following:

a. In your website root directory, create a symbolic links called "maps" to indicate absolute path to your elgg data directory (e.g. /path/to/elggdata)
b. In /mod/sharemaps/pages/sharemaps/view.php file, on line 89 assign this path to $pathd variable
c. Uncomment lines 89 and 90
d. Comment line 91


== 3. ToDo ==
- Resolve known bugs and issues
- Upload gpx files (directly from GPS Trackers)
- Option in settings for enable/disable uploading files, sharing map links or both (now both are enabled)
- Add google maps V3 on share link
