<?php
	echo $vars['url'] . "mod/theme_purplerounded/graphics/user_icons/defaultsmall.gif";
?>