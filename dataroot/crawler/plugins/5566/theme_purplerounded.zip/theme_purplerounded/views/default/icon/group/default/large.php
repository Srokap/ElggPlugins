<?php
	echo $vars['url'] . "mod/theme_purplerounded/graphics/group_icons/defaultlarge.gif";
?>