<?php

    /**
     * PurpleRounded theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function purplerounded_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','purplerounded_init');
	
?>