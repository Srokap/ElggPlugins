<?php

$german = array(
    'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
    'admin:plugins:category:menu' => 'Menü',

	'phloor_menu_manager' => 'Menu Manager',

	'phloor_menu_manager:admin:appearance:phloor_menu_sooperfish' => 'Design',
	'menu:page:header:menu' => 'Menü-Manager',
);

add_translation("de", $german);
