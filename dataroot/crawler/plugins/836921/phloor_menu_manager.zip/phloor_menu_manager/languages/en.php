<?php

$english = array(
    'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
    'admin:plugins:category:menu' => 'Menu',

	'phloor_menu_manager' => 'Menu Manager',

	'phloor_menu_manager:admin:appearance:phloor_menu_sooperfish' => 'Design',
	'menu:page:header:menu' => 'Menu Manager',
);

add_translation("en", $english);
