<?php 
/*****************************************************************************
 * Phloor Menu Manager                                                       *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>
<?php
/**
 * Phloor Menu Manager
 *
 */
elgg_register_event_handler('ready',  'system', 'phloor_menu_manager_ready', 999);

/**
 * Init
 */
function phloor_menu_manager_ready() {
	// just do something if admin is logged in
	if(elgg_is_admin_logged_in()) {
		// unregister the menu item created by 'Menuitem for 1.8'
		elgg_unregister_menu_item('page', 'appearance:phloor_menuitem');
		// unregister the menu item created by 'Menu Sooperfish for 1.8'
		elgg_unregister_menu_item('page', 'appearance:phloor_menu_sooperfish');
		
		// register new item for 'Menuitem for 1.8'
		// <-- safety check (manifest requires)
		if(elgg_is_active_plugin('phloor_menuitem')) { 
			elgg_register_menu_item('page', array(
				'name' => 'appearance:phloor_menuitem',
				'href' => "admin/appearance/phloor_menuitem",
				'text' => elgg_echo("admin:appearance:phloor_menuitem"),
				'context' => 'admin',
				'priority' => 100,
				'section' => 'menu',
			));
		}
		
		if(elgg_is_active_plugin('phloor_menu_sooperfish')) {
			// register new item for 'Menu Sooperfish for 1.8'
			elgg_register_menu_item('page', array(
				'name' => 'appearance:phloor_menu_sooperfish',
				'href' => "admin/appearance/phloor_menu_sooperfish",
				'text' => elgg_echo("phloor_menu_manager:admin:appearance:phloor_menu_sooperfish"),
				'context' => 'admin',
				'priority' => 200,
				'section' => 'menu',
			));
		}
		
		elgg_register_menu_item('page', array(
			'name' => 'appearance:phloor_logo_manager',
			'href' => "admin/plugin_settings/phloor_menuitem",
			'text' => elgg_echo("more"),
			'context' => 'admin',
			'priority' => 300,
			'section' => 'menu',
        ));
	}
}
