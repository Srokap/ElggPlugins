/**
 * Phloor Menu Manager
 * 
 * @package phloor_menu_manager
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */

/**
 * Description
 */
Menu Manager lets you manage and style menus on your Elgg site. 
 
This is a dependecny plugin for other menu related plugins.
Required plugins are:
- Menuitem for 1.8.1

Suggested plugins are:
- Menu Sooperfish for 1.8
- Menu Sooperfish Theme5 for 1.8
- Menu Admin Plugins for 1.8
- Sidemenu for 1.8

It combines the plugins mentioned above, creates a new admin menu 
section 'menu manager' and displays links to their settings as menu 
items in it.

/**
 * Languages
 */
English
German
