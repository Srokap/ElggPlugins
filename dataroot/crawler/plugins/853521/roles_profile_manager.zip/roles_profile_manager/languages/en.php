<?php 
	$english = array(
		'roles:pm:profile_type_label' => '%s Profile',
		'roles:pm:profile_type_cat_label' => '%s Default',
		
	);
	
	add_translation("en", $english);
	