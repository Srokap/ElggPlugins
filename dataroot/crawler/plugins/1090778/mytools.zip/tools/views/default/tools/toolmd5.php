<?php
function printForm3()
{

echo '<h1>MD5 Hash Generator</h1><BR><form method="post" action="toolmd5.php"><input type="text" name="keyword" style="width:250px;" value=""/><input type="submit" style="width:110px;" value="Submit"/></p></form><BR>';
}

if(isset($_REQUEST['keyword']))
{
printForm3();

$word = urldecode($_REQUEST['keyword']);
$hash = md5($word);
		
print "<pre>$hash</pre>\n";
}
else
{
printForm3();
}
?>