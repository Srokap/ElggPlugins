<?php

function printForm()
{
global $domain;

	if(!isset($domain))
	{
	$domain = "http://";
	}




echo '<br><h1>Resolve Hostname</h1><BR><form method="post" action="toolresolve.php">
<input type="text" name="www" size="30" style="width:250px;" value="http://"/> <input type="submit" style="width:110px;" value="Submit"/>
</form><BR>';

}

if(isset($_REQUEST['www']))
{
$domain = $_REQUEST['www'];

	if(!$xHost = @parse_url($domain, PHP_URL_HOST))
	{
	print "<p>Error: Could not parse URL.</p>";
	printForm();

	exit();
	}

	printForm();

		if(@gethostbyname($xHost) == $xHost)
		{
		$ip2 = "Could not get IP address of <a href=\"$domain\">$domain</a>";
		$hostname2 = "Function cancelled";
		}
		else
		{
		$ip2 = @gethostbyname($xHost);
		$hostname2 = @gethostbyaddr($ip2);
		}

	print "<div><p>IP Address: $ip2</p></div>\n";
	print "<div><p>Hostname: $hostname2</p></div>\n";
}
else
{
printForm();
}

?>