<?php
include('toolresolve.php');
include('toolmd5.php');
include('toolwhois.php');
include('tooltrace.php');
?>