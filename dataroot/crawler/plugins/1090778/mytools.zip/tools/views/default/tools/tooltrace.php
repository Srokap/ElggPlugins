<?php
// Get Variable from form via register globals on/off
//-------------------------
$unix      =  1; //set this to 1 if you are on a *unix system      
$windows   =  0; //set this to 1 if you are on a windows system
// -------------------------
// nothing more to be done.
// -------------------------
//globals on or off ?
$register_globals = (bool) ini_get('register_gobals');
$system = ini_get('system');
$unix = (bool) $unix;
$win  = (bool)  $windows;
//
If ($register_globals)
{
   $ip = getenv(REMOTE_ADDR);
   $self = $PHP_SELF;
} 
else 
{
   $submit = $_GET['submit'];
   $host   = $_GET['host'];
   $ip     = $_SERVER['REMOTE_ADDR'];
   $self   = $_SERVER['PHP_SELF'];
};
// form submitted ?
If ($submit == "Traceroute!") 
{
      // replace bad chars
      $host= preg_replace ("/[^A-Za-z0-9.]/","",$host);
      echo '<body bgcolor="#000000" text="#ffffff"></body>';
      echo("Trace Output:<br>"); 
      echo '<pre>';           
      //check target IP or domain
      if ($unix) 
      {
         system ("traceroute $host");
         system("killall -q traceroute");// kill all traceroute processes in case there are some stalled ones or use echo 'traceroute' to execute without shell
      }
      else
      {
         system("tracert $host");
      }
      echo '</pre>'; 
      echo 'done ...';  
 echo '<br><h1>Traceroute</h1><BR><form method="get" action="tooltrace.php">';
    echo '<input type="text" name="host" style="width:250px;" value="'.$ip.'"></input>';
    echo '   <input type="submit" name="submit" style="width:110px;" value="Traceroute!"></input>';
    echo '</form>';
} 
else 
{
   
   
    echo '<br><h1>Traceroute</h1><BR><form method="get" action="tooltrace.php">';
    echo '<input type="text" name="host" style="width:250px;" value="'.$ip.'"></input>';
    echo '   <input type="submit" name="submit" style="width:110px;" value="Traceroute!"></input>';
    echo '</form>';
    echo '<br><b>'.$system.'</b>';
}
?>