<?php

  if (isset($_GET['domain1'])) {
      print whois($_GET['domain1']);
  }

function whois($domainName) {
    $whoisServer = "whois.geektools.com";//server where the query is sent
    $output = "";

    $connection = fsockopen($whoisServer, 43);//connect to  server
    //return error if could not connect to server
    if (!$connection) {
        $output = "Sorry, we could not connect to the server. Please try again later.";
    }
    else {
        fwrite($connection, $domainName . "\r\n");//send query to server
        //catch server reply
        while (!feof($connection)) {
            $output .= fgets($connection);
        }
        fclose($connection);
    }

    $output = str_replace("\n", "<br />\n", $output);
    return $output . "";
}

?>
<h1>Whois Lookup:</h1><BR>
  <form action="mytools.php" method="get">
    <input type="text" name="domain1" size="10" style="width:250px;" value = "<?php print $_GET['domain1']; ?>"/><input type="submit" style="width:110px;" value="Get Whois Info" />
  </form>
<BR>