<?php


	function tools_init() 
	{
		global $CONFIG;
		add_menu('Misc Tools', $CONFIG->wwwroot ."tools/mytools");	
		register_page_handler('tools','tools_page_handler');	
	}


	function tools_page_handler($page) 
	{

		global $CONFIG;
		if (!isset($page[0])) {
		      forward();
		}

		$base_dir = elgg_get_plugins_path() . 'tools/pages/tools';

		switch ($page[0]) {

			case 'mytools':
				include "$base_dir/mytools.php";
				break;
			default:
				include "$base_dir/mytools.php";
				break;
		}

		
	}
	register_elgg_event_handler('init','system','tools_init');
?>