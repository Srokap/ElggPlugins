<?php

	/**
	 * Elgg addthis plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Damir Gasparlin http://www.juipo.com
	 * @copyright Damir Gasparlin
	 * @link http://www.juipo.com
	 */

		
		function addthis_init() {
		$view_to_extend = 'owner_block/extend';	
		// For backward compatibility, we'll check if the elgg_extend_view() function exists (Elgg 1.7+) or the extend_view() function exists (Elgg 1.6.1 - Elgg 1.7)
        // *** extend_view may exist in previous version of Elgg as well.
		if (function_exists('elgg_extend_view') || function_exists('extend_view')) {
                if (function_exists('elgg_extend_view')) {
                        elgg_extend_view($view_to_extend, 'addthis/extend');
                        
                } else if (function_exists('extend_view')) {
                        extend_view($view_to_extend, 'addthis/extend');
                        
                }
            }

						
		}

		register_elgg_event_handler('init','system','addthis_init');
				
		
?>