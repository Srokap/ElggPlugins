<?php

	/**
	 * Elgg addthis plugin
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Damir Gasparlin Juipo.com and ElggFactory.com
	 * @copyright Juipo.com 2010
	 * @link http://juipo.com
	 */

	 
   	
$contents .= "<!-- Custom SEO Elgg Bookmark by Juipo - http://juipo.com/ and ElggFactory http://elgfactory.com/ -->	 ";
$contents .= "<br /><!-- AddThis Button BEGIN -->
<div class=\"addthis_toolbox addthis_default_style\">
<a href=\"http://addthis.com/bookmark.php?v=250&amp;username=xa-4b92d0641059b108\" class=\"addthis_button_compact\">Share</a>
<span class=\"addthis_separator\">|</span>
<a class=\"addthis_button_facebook\"></a>
<a class=\"addthis_button_myspace\"></a>
<a class=\"addthis_button_google\"></a>
<a class=\"addthis_button_twitter\"></a>
</div>
<script type=\"text/javascript\" src=\"http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4b92d0641059b108\"></script>
<!-- AddThis Button END -->
";
          echo $contents;
    
?>