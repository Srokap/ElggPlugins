<?php
		function music_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('Music'), $CONFIG->wwwroot . "mod/music");
		}
		
	register_elgg_event_handler('init','system','music_init');
	// Shares widget

?>