<?php
$portugues_brasileiro = array (
	'tidypics_colorbox:currentimage' => 'imagem {current} de {total}',
	'tidypics_colorbox:previous' => 'anterior',
	'tidypics_colorbox:next' => 'próxima',
	'tidypics_colorbox:close' => 'fechar',
	'tidypics_colorbox:slideShowStart' => "Iniciar apresentação",
	'tidypics_colorbox:slideShowStop' => "Parar apresentação",
	'tidypics_colorbox:transition' => "Transição entre imagens",
	'tidypics_colorbox:elastic' => "Elastica",
	'tidypics_colorbox:fade' => "Esmaecimento",
	'tidypics_colorbox:none' => "Nenhuma",
	'tidypics_colorbox:colorboxStyle' => "Estilo da janela",
	'tidypics_colorbox:slideshowInterval' => "Intervalo entre imagens (Em segundos)"
);
add_translation("pt_br", $portugues_brasileiro);
?>