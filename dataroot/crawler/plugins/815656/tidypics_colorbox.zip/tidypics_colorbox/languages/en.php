<?php
$english = array(
	'tidypics_colorbox:currentimage' => "image {current} of {total}",
	'tidypics_colorbox:previous' => "previous",
	'tidypics_colorbox:next' => "next",
	'tidypics_colorbox:close' => "close",
	'tidypics_colorbox:slideShowStart' => "Start slideshow",
	'tidypics_colorbox:slideShowStop' => "Stop slideshow",
	'tidypics_colorbox:transition' => "Image transition",
	'tidypics_colorbox:elastic' => "Elastic",
	'tidypics_colorbox:fade' => "Fade",
	'tidypics_colorbox:none' => "None",
	'tidypics_colorbox:colorboxStyle' => "Colorbox style",
	'tidypics_colorbox:slideshowInterval' => "Slideshow interval (In seconds)"
);
add_translation("en",$english);
?>