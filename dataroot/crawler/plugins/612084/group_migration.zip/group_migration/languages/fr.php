<?php

	$french = array(
    'group_migration:menu' => "Migration des groupes",
    'group_migration:title' => "Outil de migration des contenus d'un groupe",
    
    
    'group_migration:grouplist:title' => "Les %s groupes de %s",
    'group_migration:objects' => "Contenus",
    'group_migration:members' => "Membres",
    'group_migration:to' => "vers",
    'group_migration:ingroup' => "dans le groupe",
    'group_migration:submit' => "Go !",
    'group_migration:grouplist:item' => '<b>Déplacer %s objets</b> et <b>%s membres</b> dans',
    
    'group_migration:migration:title' => 'Déplacement depuis <i>%s</i> vers <i>%s</i>&nbsp;:',
    'group_migration:migration:objects:success' => 'Parfait, les %s $success objets ont bien été transférés',
    'group_migration:migration:objects:fail' => 'Oups, %s échecs et %s objets transférés',
    'group_migration:migration:objects:none' => 'Rien de grave, mais aucun transfert : %s échec et %s objet transféré',
    
    'group_migration:migration:members:success' => 'Parfait, les %s membres de %s ont bien été inscrits dans le groupe %s',
    'group_migration:migration:members:fail' => 'Oups, %s échecs et %s nouveaux inscrits dans le groupe %s',
    'group_migration:migration:members:none' => 'Rien de grave, mais aucune nouvelle inscription : %s échec et %s membre inscrit',
    
	);
					
	add_translation("fr",$french);

?>
