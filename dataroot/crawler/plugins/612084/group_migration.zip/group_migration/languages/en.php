<?php

	$english = array(
    'group_migration:menu' => "Group Migration",
    'group_migration:title' => "Migration tool for group contents",
    
    
    'group_migration:grouplist:title' => "The %s groups of %s",
    'group_migration:objects' => "Contents",
    'group_migration:members' => "Members",
    'group_migration:to' => "to",
    'group_migration:ingroup' => "in the group",
    'group_migration:submit' => "Go!",
    'group_migration:grouplist:item' => '<b>Move %s objects</b> and <b>%s members</b> in',
    
    'group_migration:migration:title' => 'Moving from <i>%s</i> to <i>%s</i>&nbsp;:',
    'group_migration:migration:objects:success' => 'Perfect, the %s $success objects have been transfered',
    'group_migration:migration:objects:fail' => 'Oops, %s failures and %s objects transfered',
    'group_migration:migration:objects:none' => 'Nothing serious, but no transfer : %s failures and %s objects transfered',
    
    'group_migration:migration:members:success' => 'Perfect, the %s members of %s have been written to the group %s',
    'group_migration:migration:members:fail' => 'Oops, %s failures and %s new registrants in the group %s',
    'group_migration:migration:members:none' => 'No serious errors, but no new registrations : %s failures and %s members written',
    
	);
					
	add_translation("en",$english);

?>
