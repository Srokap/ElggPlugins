<?php	

/*
** Communities (as opposed to groups)
**
** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
** @copyright Tesserae Ltd 2009
** @link http://www.c4lpt.co.uk/ElggConsultancy.html
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

function communities_init()
{
	global $CONFIG;
  	
  	// Default language path in absence of either contacts or colleagues plugins
	$languagePath = "communities/languages/friends/";
  	
	// By default assume contacts and colleagues plugins not installed, hence order = 0
	$contactsPluginOrder = 0;
	$colleaguesPluginOrder = 0;
  	
	// Determine whether contracts or colleagues plugins exist and, if enabled, the order of appearance
	$plugins = get_plugin_list();
	foreach($plugins as $index => $plugin)
	{
		// Plugin must be installed and enabled
		if (is_plugin_enabled($plugin))
		{
			if ($plugin == "contacts") $contactsPluginOrder = $index + 1;		// Increment ensures non-zero value 
			if ($plugin == "colleagues") $colleaguesPluginOrder = $index + 1;
		}
	}
  	
	// If either or both plugins are deployed and enabled, determine the language path
	if ($contactsPluginOrder || $colleaguesPluginOrder)
	{
		if ($contactsPluginOrder > $colleaguesPluginOrder)
		{
			$languagePath = "communities/languages/contacts/";
		}
		else
		{
			$languagePath = "communities/languages/colleagues/";
		}  		
	}
	
	// Register the language translation
	register_translations($CONFIG->pluginspath . $languagePath);
}

  
// Initialise this plugin
register_elgg_event_handler('init','system','communities_init');


?>
