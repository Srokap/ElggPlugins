<?php

/*
** Communities (as opposed to groups)
**
** @author Philip Hart, Centre for Learning and Performance Technology (www.c4lpt.co.uk)
** @copyright Tesserae Ltd 2009
** @link http://www.c4lpt.co.uk/ElggConsultancy.html
** @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
**
*/

$english = array(

	/*
	** pages plugin
	*/
	'pages:group' => 'Community pages',
	'pages:groupprofile' => 'Community pages',
	'pages:nogroup' => 'This community does not have any pages yet',


	/*
	** group_contact_list plugin
	*/
	'groupclist:title' => 'Community Contact List',
	'groupclist:title_users' => 'Community Contact List: select/unselect community users',
	'groupclist:totalpages' => 'Total Communities:',
	'groupclist:delete:yes' => 'Community deleted',
	'groupclist:delete:no' => 'Error: Community not deleted',
	'groupclist:addmember:yes' => 'All selected users are now community members',
	'groupclist:addmember:no' => 'Error adding user to community',


	/*
	** vazco_mainpage plugin
	*/
	'custom:groups' => "Latest communities",
	'custom:featuredgroups' => 'Featured communities',
	'custom:groupicons' => 'Latest communities (icons)',
	'custom:groups:desc' => "Shows latest communities",
	'custom:featuredgroups:desc' => 'Displays featured communities',
	'custom:groupicons:desc' => 'Displays latest communities as icons. Displays only communities that have icons.',


	/*
	** blog plugin
	*/
	'blog:enableblog' => 'Enable community blog',
	'blog:group' => 'Community blog',


	/*
	** file plugin
	*/
	'file:group' => "Community files",


	/*
	** notifications plugin
	*/
	'notifications:subscriptions:changesettings:groups' => 'Community notifications',
	'notifications:subscriptions:groups:description' => 'To receive notifications when new content is added to a community you are a member of, find it below and select the notification method you would like to use.',


	/*
	** groups plugin
	*/
	'groups' => "Communities",
	'groups:owned' => "Communities you own",
	'groups:yours' => "Your communities",
	'groups:user' => "%s's communities",
	'groups:all' => "All site communities",
	'groups:new' => "Create a new community",
	'groups:edit' => "Edit community",
	'groups:delete' => 'Delete community',
	'groups:icon' => 'Community icon (leave blank to leave unchanged)',
	'groups:name' => 'Community name',
	'groups:username' => 'Community short name (displayed in URLs, alphanumeric characters only)',
	'groups:members' => 'Community members',
	'groups:membership' => "Community membership permissions",
	'groups:widget:num_display' => 'Number of communities to display',
	'groups:widget:membership' => 'Community membership',
	'groups:widgets:description' => 'Display the communities you are a member of on your profile',
	'groups:noaccess' => 'No access to community',
	'groups:cantedit' => 'You can not edit this community',
	'groups:saved' => 'Community saved',
	'groups:featured' => 'Featured communities',
	'groups:featuredon' => 'You have made this community a featured one.',
	'groups:unfeature' => 'You have removed this community from the featured list',
	'groups:join' => 'Join community',
	'groups:leave' => 'Leave community',
	'groups:nofriends' => "You have no friends left who have not been invited to this community.",
	'groups:viagroups' => "via communities",
	'groups:group' => "Community",
	'groups:notfound' => "Community not found",
	'groups:notfound:details' => "The requested community either does not exist or you do not have access to it",
	'groups:count' => "communities created",
	'groups:open' => "open community",
	'groups:closed' => "closed community",
	'groups:searchtag' => "Search for communities by tag",
	'groups:closedgroup' => 'This community has a closed membership. To ask to be added, click the "request membership" menu link.',
	'groups:visibility' => 'Who can see this community?',
	'groups:enablepages' => 'Enable community pages',
	'groups:enableforum' => 'Enable community discussion',
	'groups:enablefiles' => 'Enable community files',
	'groups:pages' => 'Community pages',
	'groups:files' => 'Community files',
	'groups:forum' => 'Community discussion',
	'grouptopic:error' => 'Your community topic could not be created. Please try again or contact a system administrator.',
	'groups:privategroup' => 'This community is private, requesting membership.',
	'groups:notitle' => 'Communities must have a title',
	'groups:cantjoin' => 'Can not join community',
	'groups:cantleave' => 'Could not leave community',
	'groups:addedtogroup' => 'Successfully added the user to the community',
	'groups:joinrequestmade' => 'Request to join community successfully made',
	'groups:joined' => 'Successfully joined community!',
	'groups:left' => 'Successfully left community',
	'groups:notowner' => 'Sorry, you are not the owner of this community.',
	'groups:alreadymember' => 'You are already a member of this community!',
	'groups:invite:body' => "Hi %s,

You have been invited to join the '%s' community, click below to confirm:

%s",

	'groups:welcome:subject' => "Welcome to the %s community!",
	'groups:welcome:body' => "Hi %s!

You are now a member of the '%s' community! Click below to begin posting!

%s",

	'groups:request:body' => "Hi %s,

%s has requested to join the '%s' community, click below to view their profile:

%s

or click below to confirm request:

%s",

	'groups:nowidgets' => 'No widgets have been defined for this community.',
	'groups:widgets:members:title' => 'Community members',
	'groups:widgets:members:description' => 'List the members of a community.',
	'groups:widgets:members:label:displaynum' => 'List the members of a community.',
	'groups:widgets:entities:title' => "Objects in community",
	'groups:widgets:entities:description' => "List the objects saved in this community",
	'groups:widgets:entities:label:displaynum' => 'List the objects of a community.',
	'groups:allowhiddengroups' => 'Do you want to allow private (invisible) communities?',
	'group:deleted' => 'Community and community contents deleted',
	'group:notdeleted' => 'Community could not be deleted',
	'grouppost:deleted' => 'Community posting successfully deleted',
	'grouppost:notdeleted' => 'Community posting could not be deleted',
	'groups:deletewarning' => "Are you sure you want to delete this community? There is no undo!",


	/*
	** bookmarks plugin
	*/
	'bookmarks:bookmarklet:group' => "Get community bookmarklet",
	'bookmarks:group' => 'Community bookmarks',
	'bookmarks:enablebookmarks' => 'Enable community bookmarks',


	/*
	** vazco_groupmailer plugin
	*/
	'vazco_groupmailer:send' => 'Send community e-mail',
	'vazco_groupmailer:send:menu' => 'Send community e-mail',
	'vazco_groupmailer:nogroup' => 'No community was chosen',
	'vazco_groupmailer:norights' => 'You have no rights to send mass e-mail to this community',
	'vazco_groupmailer:description' => 'This form allows you to send e-mails to all the community members.<br/>
<br/>You can use the following special markers:<br/>
{$message_receiver} - the receiver of the message',
	'phpmailer:template:settings' => 'Set template for the messages sent to communities. You can use the following markers:<br/><br/>
{$message_body} - the context of the message<br/>
{$message_title} - the title of the message<br/>
{$message_sender} - the name of the sender of the message<br/>
{$message_receiver} - the name of the receiver of the message',


	/*
	** event_calendar plugin
	*/
	'event_calendar:group' => "Community calendar",
	'event_calendar:settings:group_profile_display:title' => "Community calendar profile display (if community calendars are enabled)",
	'event_calendar:settings:autogroup:title' => "Automatically add community events for all members to their personal calendars.",
	'event_calendar:settings:group_calendar:title' => "Community calendars",
	'event_calendar:settings:group_calendar:admin' => "yes, only admins and community owners can post events",
	'event_calendar:settings:group_calendar:members' => "yes, any community member can post an event",
	'event_calendar:settings:group_default:title' => "New communities should by default have a community calendar (if group calendars are enabled)",
	'event_calendar:settings:group_default:no' => "no (but admins or community owners can turn a community calendar on if desired)",
	'event_calendar:settings:group_default:yes' => "yes (but admins or community owners can turn a community calendar off if desired)",
	'event_calendar:settings:group_always_display:title' => "If community calendar is enabled, always display it (even if empty)",
	'event_calendar:enable_event_calendar' => "Enable community event calendar",


	/*
	** Default Elgg group languauge mappings
	*/
	'group' => "Community", 
	'item:group' => "Communities",
	'groups:searchtitle' => "Searching for communities: %s",
	'group:search:startblurb' => "Communities matching '%s':",

);

add_translation("en", $english);

?>
