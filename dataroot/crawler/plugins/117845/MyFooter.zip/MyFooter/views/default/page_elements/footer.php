<?php

	/**
	 * My Footer
	 * The standard HTML footer that displays across the site
	 * @author Carlos Reo-Dero
	 */
	 
	 // get the tools menu
	//$menu = get_register('menu');

?>

<div class="clearfloat"></div>

<div id="layout_footer" style="padding-right:35px;">
<table align="center" cellpadding="0" cellspacing="0" class="footContainer">
	<tr>
      	<!--Site name and/or copy right statement-->
            
		<td class="left">My Site 2009. All rights reserved.</td>
            
      	<!--End Site name and/or copy right statement-->
            
		<td class="right">
            
            	<table align="right" cellpadding="0" cellspacing="0" class="footerLinks" style="border:none;">
                  	<tr>
                        	
			            <!--Footer Links // Modify these links as you need-->
                              
                              <td class="link"><a href="<?php echo $vars['url']; ?>" target="_self">About</a></td>
                              <td class="link"><a href="<?php echo $vars['url']; ?>" target="_self">Terms</a></td>
                              <td class="link"><a href="<?php echo $vars['url']; ?>" target="_self">Privacy</a></td>
                              <td class="link"><a href="<?php echo $vars['url']; ?>" target="_self">Search</a></td>
                              <td class="link"><a href="<?php echo $vars['url']; ?>" target="_self">Contact</a></td>
                              
                              <!--End Footer Links-->
                              
                        </tr>
                  </table>
                  
            </td>
	</tr>
</table>
</div><!-- /#layout_footer -->

<div class="clearfloat"></div>

</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->
<!-- insert an analytics view to be extended -->
<?php
	echo elgg_view('footer/analytics');
?>
</body>
</html>