

Elgg - MyFooter
Author: Carlos Reo-Dero
License: GNU Public License version
Date: May 2009

===========================================

1. Open 'views/default/footer.php' in your html editor and add your site name, copy right statement and the links you want displayed.

	Note: Your site url is called with php so all you need to add is the rest of your link url's.

2. Save.

3. Upload to your mod directory.

4. Enable plugin (disable/enable plugin or run upgrade.php).


Note: You can modify css.php to achieve the look you want within the links table (font, color..etc). You can add as many links as you want and add images and so on in 'footer.php'.


That's it.


