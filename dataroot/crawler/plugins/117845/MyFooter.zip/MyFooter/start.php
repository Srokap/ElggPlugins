<?php

	/* MyFooter */
	
	
	/* Initialise the plugin */
    function MyFooter_init() {
			
	    // Load system configuration
		    global $CONFIG;
		    
         // Add our CSS
				extend_view('css','footer/css');
				
     }
     
     // Make sure the status initialisation function is called on initialisation
		register_elgg_event_handler('init','system','MyFooter_init',9999);
       
?>