<?php
/////////////////////////////////////////////////////////////////////////////////
// Plus River - index.php
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////


// Get the Elgg engine

require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

// Ensure that only logged-in users can see this page
gatekeeper();

// Set context and title
set_context('dashboard');
set_page_owner(get_loggedin_userid());
$title = elgg_echo('dashboard');


//////////////////////////////////////////////////////
//	River - Middle Column
//////////////////////////////////////////////////////
$content = get_input('content','');
$content = explode(',' ,$content);
$type = $content[0];
if (isset($content[1])) {
	$subtype = $content[1];
} else {
	$subtype = '';
}
//select default view//

$orient = get_input('display');
if($orient == '')
	{
	$orient = get_plugin_usersetting('orient', '0', 'plusriver');

		
		if(!$orient)
			{
					$orient = get_plugin_setting('orient', 'plusriver'); 
					set_plugin_usersetting('orient', $orient, '0', 'plusriver');
			}
	}


		

		
switch($orient) {
		
	case 'mine':
		$subject_guid = get_loggedin_userid();
		$relationship_type = '';
		break;
	case 'friends':
		$subject_guid = get_loggedin_userid();
		$relationship_type = 'friend';
		break;
	case 'all':
		$subject_guid = 0;
		$relationship_type = '';
		break;
}

//end//

$callback = get_input('callback');

if ($type == 'all') {
	$type = '';
	$subtype = '';
}

$area2 = '';

$area2 .=elgg_view("plusriver/mainheader");



$river = elgg_view_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '');

// Replacing callback calls in the nav with something meaningless
$river = str_replace('callback=true', 'replaced=88,334', $river);

$nav = elgg_view('riverdashboard/nav',array(
		'type' => $type,
		'subtype' => $subtype,
		'orient' => $orient
));

$content = elgg_view('page_elements/contentwrapper', array('body' => $nav . $river));

$area2 .= elgg_view('riverdashboard/container', array('body' => $content . elgg_view('riverdashboard/js')));

//////////////////////////////////////////////////////
//	END: River - Middle Column
//////////////////////////////////////////////////////

//////////////////////////////////////////////////////
//	River - Left Fixed Column
//////////////////////////////////////////////////////
$area1 = '';
$addavatar = get_plugin_setting('addavatar', 'plusriver');
if ($addavatar == 'yes')
{
$area1 .= elgg_view('plusriver/boxes/avatar/view');

}

$addquicklinks = get_plugin_setting('addquicklinks', 'plusriver');
if ($addquicklinks == 'yes')
{
$area1 .= elgg_view('plusriver/boxes/quicklinks/view');
}

//////////////////////////////////////////////////////
//	END: River - Left Fixed Column
//////////////////////////////////////////////////////

//////////////////////////////////////////////////////
//	River - Right Fixed Column
//////////////////////////////////////////////////////
$area3 = '';
$addsitemessage = get_plugin_setting('addsitemessage', 'plusriver');
if ($addsitemessage == 'yes')
{
$area3 .= elgg_view('riverdashboard/sitemessage');
}

$addads = get_plugin_setting('addads', 'plusriver');
if ($addads == 'yes')
{
$area3 .= elgg_view('plusriver/boxes/ads/view');
}

//////////////////////////////////////////////////////
//	END: River - Right Fixed Column
//////////////////////////////////////////////////////


// Try and get the user from the username and set the page body accordingly
$body = elgg_view_layout('plusriver',$area1,$area2,$area3);

page_draw($title, $body);

