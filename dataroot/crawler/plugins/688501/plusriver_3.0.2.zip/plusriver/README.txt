See CREDITS.txt for further info about the developers who made this plugin.

INSTALLATION:

1.- Extract the .zip archive

2.- Upload it to /mod/ directory in your elgg site

3.- Activate it trought your tools admin page

4.- Make sure that the wire and riverdashboard plugin was activated before you use this plugin and place this plugin below them. 
