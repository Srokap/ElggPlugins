<?php
/////////////////////////////////////////////////////////////////////////////////
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////






$minmax = $vars['url'] . 'mod/plusriver/graphics/';


?>





	<div class="collapsable_box_header"><h1><?php echo elgg_echo('plusriver:box:quicklinks') ?></h1></div>
			

<div class="collapsable_box">




 


      <a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/edit/"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'26.png'; ?>"><?php echo elgg_echo('profile:edit')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/editicon/"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'38.png'; ?>"><?php echo elgg_echo('plusriver:change_photo')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/photos/owned/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'40.png'; ?>"><?php echo elgg_echo('plusriver:manage_photos')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/file/<?php echo $_SESSION['user']->username; ?>/new"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'7.png'; ?>"><?php echo elgg_echo('plusriver:upload_file')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'24.png'; ?>"><?php echo elgg_echo('plusriver:blog')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/thewire/owner/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'16.png'; ?>"><?php echo elgg_echo('plusriver:thewire')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/messageboard/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'18.png'; ?>"><?php echo elgg_echo('plusriver:messageboard')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'41.png'; ?>"><?php echo elgg_echo('plusriver:friends')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/settings/user/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_widget_quicklinks"><span><img src="<?php echo $minmax.'72.png'; ?>"><?php echo elgg_echo('plusriver:settings')?></span></div></a>

     

</div>








