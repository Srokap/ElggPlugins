<?php
/////////////////////////////////////////////////////////////////////////////////
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////

$minmax = $vars['url'] . 'mod/plusriver/graphics/';
?> 



	<div class="collapsable_box_header"><h1><?php echo elgg_echo('plusriver:box:avatar'); echo $_SESSION['user']->username; ?></h1></div>
			

<div class="collapsable_box">


	<div class="plusriver_perfilquicklinks">
	      <a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/edit/"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'user_edit.gif'; ?>"><span><?php echo elgg_echo('profile:edit')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/photos/new/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'album_add.gif'; ?>"><span><?php echo elgg_echo('album:create')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/blog/new/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'document_edit.gif'; ?>"><span><?php echo elgg_echo('blog:addpost')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/groups/new/"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'user_groups.gif'; ?>"><span><?php echo elgg_echo('groups:new')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/pages/new/?container_guid=<?php echo $_SESSION['user']->guid; ?>"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'documents.gif'; ?>"><span><?php echo elgg_echo('pages:new')?></span></div></a>

      <a href="<?php echo $vars['url']; ?>pg/settings/user/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'wrench.gif'; ?>"><span><?php echo elgg_echo('plusriver:settings')?></span></div></a>




<?php
//get unread messages
	$num_messages = count_unread_messages();
	if($num_messages){
		$num = $num_messages;
	} else {
		$num = 0;
	}

	if($num == 0){

?>
<a href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'mailing.gif'; ?>"><span><?php echo elgg_echo('messages:user')?></span></div></a>

	
<?php
    }else{
?>

<a href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo $_SESSION['user']->username; ?>"><div class="plusriver_perfil_quicklinks"><img src="<?php echo $minmax.'mailing_new.gif'; ?>"><span><?php echo $num . ' '; echo elgg_echo('messages')?></span></div></a>
	
<?php
    }
?>



	</div>

	<div class="plusriver_perfilimg">
	
		<a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/editicon"><span>
			<?php echo elgg_echo('plusriver:change_photo'); ?>
		</span></a>
	

<a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>"><img src="<?php echo $_SESSION['user']->getIcon('large'); ?>" />
</a>

	</div>

<div class="plusriver_perfilstatus">
<?php
$owner = get_loggedin_userid();
$url_to_wire = $vars['url'] . "pg/thewire/owner/" . $_SESSION['user']->username;

//grab the user's latest from the wire
$params = array(
	'types' => 'object',
	'subtypes' => 'thewire',
	'owner_guid' => $owner,
	'limit' => 1,
);
$latest_wire = elgg_get_entities($params);

if ($latest_wire) {
	foreach ($latest_wire as $lw) {
		$content = $lw->description;
		$time = " (" . elgg_view_friendly_time($lw->time_created) . ")";
	}
}

if ($latest_wire) {
	
	echo $content;
	if ($owner == get_loggedin_userid()) {
		$text = elgg_echo('thewire:update');
		echo " <a href=\"$url_to_wire\">$text</a>";
	}
	echo $time;
	
}
?>
</div>


</div>



