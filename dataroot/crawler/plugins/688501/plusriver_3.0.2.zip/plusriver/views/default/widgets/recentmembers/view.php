<?php
/////////////////////////////////////////////////////////////////////////////////
// Plus River - views/default/widgets/friendsonline/view.php
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////




//get the num of friends online the user wants to display
$num = $vars['entity']->num_display;

//if no number has been set, default to 4
if (!$num) {
	$num = 4;
}

//get the size of icons
$size = $vars['entity']->size_display;

//if no size has been set, default to tiny
if (!$size) {
	$size = 'medium';
}







$newest_members = elgg_get_entities_from_metadata(array('metadata_names' => 'icontime', 'types' => 'user', 'limit' => $num));



		foreach ($newest_members as $memb) 
		{
					
				$icon = elgg_view("profile/icon",array('entity' => $memb, 'size' => $size));
				echo "<div class=\"plusriver_widget_recent_members\">\n";     
				echo $icon;
				echo "</div>\n";
				
			 
		} 
	
?>


<div class="clearfloat"></div>





