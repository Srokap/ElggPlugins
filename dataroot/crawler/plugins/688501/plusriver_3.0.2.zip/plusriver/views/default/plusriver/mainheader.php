<?php

/////////////////////////////////////////////////////////////////////////////////
// Plus River - Main Header
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////






?>

<script>
$(document).ready(function(){
           $("#share_wire_form").css("display","none");
           $("#share_video_form").css("display","none");
 
  $("#share_status").click(function () {
          $("#share_video_form").css("display","none");
    $("#share_wire_form").slideToggle(10);

 
 
  });


  $("#share_video").click(function () {
           $("#share_wire_form").css("display","none");
    $("#share_video_form").slideToggle(10);


 
  });


});
</script>
<div class="plusriver_shares">
<?php echo elgg_echo('plusriver:share'); ?> 



<?php
			$thewireon = get_plugin_setting("addthewire", "plusriver");
			if($thewireon == 'yes')
			{
?>
<span class="share_status" id="share_status"><?php echo elgg_echo('plusriver:share_status'); ?></span>
<?php
			}
?>


<?php
			$videoon = get_plugin_setting("addvideo", "plusriver");
			if($videoon == 'yes')
			{
?>
<span class="share_status" id="share_video"><?php echo elgg_echo('plusriver:share_video'); ?></span>
<?php
			}
?>



</div>
<div id="share_wire_form">

<?php
			if($thewireon == 'yes')

			{
				require_once(dirname(__FILE__) . '/thewire.php');
			}
?>

</div>

<div id="share_video_form">

<?php
			if($videoon == 'yes')

			{
				require_once(dirname(__FILE__) . '/videos.php');
			}
?>

</div>
