<?php
/////////////////////////////////////////////////////////////////////////////////
// Plus River - Simple Ads Box
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////

?>

<div class="collapsable_box_header"><h1><?php echo elgg_echo('plusriver:box:ads'); ?></h1></div>


<div class="collapsable_box">
You can edit this box in <b>mod/plusriver/views/default/plusriver/boxes/ads/view.php</b>

</div>
