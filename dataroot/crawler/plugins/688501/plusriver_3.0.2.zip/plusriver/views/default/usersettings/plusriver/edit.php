		<?php echo elgg_echo('plusriver:default_view'); ?><select name="params[orient]">
        	<?php
       		 foreach(array('all','friends','mine') as $view) {
           	 echo "<option value='$view'";
            		if ($vars['entity']->orient == $view) echo ' selected="yes" ';
            			echo ">".elgg_echo($view)."</option>";

       			 }?>
		</select>
<br>

<?php echo elgg_echo("plusriver:avatar_size");?>
<select name="params[avatar_size]">
			<option value="tiny" <?php if ($vars['entity']->avatar_size == 'tiny') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('plusriver:size_tiny'); ?></option>
			<option value="small" <?php if ($vars['entity']->avatar_size == 'small' || empty($vars['entity']->avatar_size)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('plusriver:size_small'); ?></option>
			<option value="medium" <?php if ($vars['entity']->avatar_size == 'medium') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('plusriver:size_medium'); ?></option>
		</select>
