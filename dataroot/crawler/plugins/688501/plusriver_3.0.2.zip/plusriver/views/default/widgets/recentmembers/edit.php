<?php
// set default value
if (!isset($vars['entity']->num_display)) {
	$vars['entity']->num_display = 4;
}
?>
<p>
	<?php echo elgg_echo('plusriver:widget:edit:recent_members:number'); ?>:
	<select name="params[num_display]">
<?php

for ($i=1; $i<=20; $i++) {
	$selected = '';
	if ($vars['entity']->num_display == $i) {
		$selected = "selected='selected'";
	}

	echo "	<option value='{$i}' $selected >{$i}</option>\n";
}
?>
	</select>
</p>









<?php 
// set default value
if (!isset($vars['entity']->size_display)) {
	$vars['entity']->size_display = 'tiny';
}
?>
<p>
	<?php echo elgg_echo('plusriver:widget:edit:recent_members:size'); ?>:
	<select name="params[size_display]">
	<option value="tiny" <?php if($vars['entity']->size_display == 'tiny') echo "selected='selected'"; ?>><?php echo elgg_echo('plusriver:size_tiny'); ?></option> 
	<option value="small"<?php if($vars['entity']->size_display == 'small') echo "selected='selected'"; ?>><?php echo elgg_echo('plusriver:size_small'); ?></option> 
	<option value="medium"<?php if($vars['entity']->size_display == 'medium') echo "selected='selected'"; ?>><?php echo elgg_echo('plusriver:size_medium'); ?></option> 
	</select>
</p>
