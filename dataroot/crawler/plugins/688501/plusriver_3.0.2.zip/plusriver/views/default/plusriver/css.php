

/********************************************************
	MAIN STYLES
*********************************************************/

/* canvas layout: widgets  dashboard) */
.plusriver_widgets_left {
	width:240px;
	margin:0 5px 20px -7px;
	min-height:360px;
	padding:0;
}
.plusriver_main_content {
	width:470px;
	margin:0 0 20px 0;
	padding:0;
}
.plusriver_widgets_right {
	width:240px;
	margin:0px 0 20px 5px;
	float:left;
	padding:0;
}
#widget_table td {
	border:0;
	padding:0;
	margin:0;
	text-align: left;
	vertical-align: top;
}








/* ***************************************
	WIDGET PICKER 
*************************************** */
/* 'edit page' button */
a.toggle_customise_edit_panel {
	float:right;
	clear:right;
	color: #4690d6;
	background: white;
	border:1px solid #cccccc;
	padding: 5px 10px 5px 10px;
	margin:0 0 20px 0;
	width:220px;
	text-align: left;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
}
a.toggle_customise_edit_panel:hover {
	color: #ffffff;
	background: #0054a7;
	border:1px solid #0054a7;
	text-decoration:none;
}


/*	EDIT WINDOW    */


.plusriver_edit_middle
{
	background: rgba(50,50,50,.3);
	margin-right: 10px;
	height: 270px;
}














/*************************************
 *	 the wire style              *
 *************************************/


#plusriver_thewire
{

	width: 400px;
	height: 20px;

-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;



	
}

#plusriver_characters_remaining
{

float: right;
}



/*************************************
 *	 share header style          *
 *************************************/

.share_status
{
 	background: #7294B2;
	color: white;
	 cursor:pointer;
	padding: 2px;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
}

.plusriver_shares
{
	background: #CFDAE3;
	margin: 0 0 0 20px;
	width: 410px;
	height: 30px;
	color: #888;
	font-size: 15px;
	font-weight: bold;
	padding: 7px 0 0 20px;
	border: 2px groove #F0F7FD;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
}

.plusriver_perfilselector
{
	
	position: relative;

	
	
}



.plusriver_perfilselector div
{
	
	text-shadow: -1px -1px 0 #aaa;
	float: right;

	padding: 5px;



margin: 0 5px 0 0;


}

.plusriver_perfilselector div:hover
{

color:white;
	background: #7294B2;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
}

.seleccionado
{
color:white;
	background: #7294B2;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
}




/****************************************************
*		WIDGETS STYLES
*
****************************************************/

/*************************************
 *	 widget friendson            *
 *************************************/
.plusriver_widget_friends_online 
{
	float:left;
	margin:0 4px 4px 0;
}


/*************************************
 *	 widget recent members       *
 *************************************/
.plusriver_widget_recent_members 
{
	float:left;
	margin:0 4px 4px 0;
}






/****************************************************
*		BOXES STYLES
*
****************************************************/



/*************************************
 *	 box avatar                  *
 *************************************/

.plusriver_perfilquicklinks
{
	
	
	background: none;
	float: left;
	width: 40px;

}

.plusriver_perfil_quicklinks
{
	
	
	background: none;

	text-align: center;
	padding: 4px;
	border-bottom: 1px solid #edeff4;

}

.plusriver_perfil_quicklinks:hover
{
	background: #9bb6db;
}

.plusriver_perfil_quicklinks span
{
	display: none;
	color: white;
	padding: 4px;
	width: 100px;
	position: absolute;

	margin: -22px 0 0 -110px;

-webkit-border-bottom-left-radius: 10px;
-moz-border-radius-bottomleft: 10px;
border-bottom-left-radius: 10px;

-webkit-border-top-left-radius: 10px;
-moz-border-radius-topleft: 10px;
border-top-left-radius: 10px;
}

.plusriver_perfil_quicklinks:hover span
{
	display: block;

	background: black;

}



.plusriver_perfilimg img
{
	border: 1px solid #cccccc;
	padding: 4px;
	width: 190px;

}

.plusriver_perfilimg span
{
	display: none;

}

.plusriver_perfilimg:hover span
{
	display: block;
	position: absolute;
	margin-left: 40px;
	color: white;
	font-weight: bold;
	padding: 0 5px 5px 5px;
	background: rgba(2,2,2,.5);
	text-align: center;
	border-bottom: 1px solid rgb(200,200,200);
	border-right: 1px solid rgb(200,200,200);
-webkit-border-bottom-right-radius: 10px;
-moz-border-radius-bottomright: 10px;
border-bottom-right-radius: 10px;
}

.plusriver_perfilimg span:hover 
{
	display: inline;
	position: absolute;
	padding: 0 5px 5px 5px;	
	background: rgba(2,2,2,.9);
	text-align: center;
}

.plusriver_perfilstatus
{
	background: #CFDAE3;
	padding: 10px;

border: 1px solid #7294B2;

-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
}

/*************************************
 *	 box quicklinks              *
 *************************************/

.plusriver_widget_quicklinks
{
	background: transparent;


	padding-left: 25px; 

	border-top: 1px solid #edeff4;
}

.plusriver_widget_quicklinks:hover
{
	background: #9bb6db;


	

	border-top: 1px solid #edeff4;
}

.plusriver_widget_quicklinks img
{

	margin-left: -20px;
	margin-top: 2px;
	
}
