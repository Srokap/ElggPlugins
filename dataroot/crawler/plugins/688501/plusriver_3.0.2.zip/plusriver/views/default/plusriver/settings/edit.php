 <?php 
/////////////////////////////////////////////////////////////////////////////////
// Plus River - Plugin Settings Editor
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////


//Make sure that an admin is loged in
	if (get_context() == 'admin' && isadminloggedin()) 
		{}
	else
	{
		register_error(elgg_echo('adminrequired'));forward();
	}
	

echo "<p>";

$addthewire = $vars['entity']->addthewire;
	if (!$addthewire) $addthewire = 'no';


 echo elgg_echo('plusriver:add_thewire'); ?>	
		<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[addthewire]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $addthewire
		));

echo "</p>";//separate options
echo "<p>";

$addvideo = $vars['entity']->addvideo;
	if (!$addvideo) $addvideo = 'no';


 echo elgg_echo('plusriver:add_video'); ?>	
		<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[addvideo]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $addvideo
		));

		
echo "</p>";
echo "<p>";
?>


		<?php echo elgg_echo('plusriver:default_view'); ?><select name="params[orient]">
        	<?php
       		 foreach(array('all','friends','mine') as $view) {
           	 echo "<option value='$view'";
            		if ($vars['entity']->orient == $view) echo ' selected="yes" ';
            			echo ">".elgg_echo($view)."</option>";

       			 }?>
		</select>

<?php
echo "</p>";
echo "<p>";

$addavatar = $vars['entity']->addavatar;
	if (!$addavatar) $addavatar = 'no';


 echo elgg_echo('plusriver:add_avatar'); ?>	
		<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[addavatar]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $addavatar
		));

		
echo "</p>";?>

<?php

echo "<p>";

$addquicklinks = $vars['entity']->addquicklinks;
	if (!$addquicklinks) $addquicklinks = 'no';


 echo elgg_echo('plusriver:add_quicklinks'); ?>	
		<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[addquicklinks]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $addquicklinks
		));

		
echo "</p>";?>

<?php

echo "<p>";

$addsitemessage = $vars['entity']->addsitemessage;
	if (!$addsitemessage) $addsitemessage = 'no';


 echo elgg_echo('plusriver:add_sitemessage'); ?>	
		<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[addsitemessage]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $addsitemessage
		));

		
echo "</p>";?>

<?php

echo "<p>";

$addads = $vars['entity']->addads;
	if (!$addads) $addads = 'no';


 echo elgg_echo('plusriver:add_ads'); ?>	
		<?php
		echo elgg_view('input/pulldown', array(
			'internalname' => 'params[addads]',
			'options_values' => array(
				'no' => elgg_echo('option:no'),
				'yes' => elgg_echo('option:yes')
			),
			'value' => $addads
		));

		
echo "</p>";?>



<?php echo elgg_echo("plusriver:avatar_size");?>
<select name="params[avatar_size]">
			<option value="tiny" <?php if ($vars['entity']->avatar_size == 'tiny') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('plusriver:size_tiny'); ?></option>
			<option value="small" <?php if ($vars['entity']->avatar_size == 'small' || empty($vars['entity']->avatar_size)) echo " selected=\"yes\" "; ?>><?php echo elgg_echo('plusriver:size_small'); ?></option>
			<option value="medium" <?php if ($vars['entity']->avatar_size == 'medium') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('plusriver:size_medium'); ?></option>
		</select>






