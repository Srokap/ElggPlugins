<?php
/////////////////////////////////////////////////////////////////////////////////
// Plus River - views/default/widgets/friendsonline/view.php
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////




//get the num of friends online the user wants to display
$num = $vars['entity']->num_display;

//if no number has been set, default to 4
if (!$num) {
	$num = 4;
}

//get the size of icons
$size = $vars['entity']->size_display;

//if no size has been set, default to tiny
if (!$size) {
	$size = 'medium';
}







$friends = $_SESSION['user']->getFriends("","10000");

$friends_online = 0;
	if (count($friends) > 0) 
	{
		foreach ($friends as $friend) 
		{
			if ($friend->last_action > time() - 200 && $friends_online < $num) 
			{		
				$icon = elgg_view("profile/icon", array('entity' => get_user($friend->guid), 'size' => $size));
				echo "<div class=\"plusriver_widget_friends_online\">\n";     
				echo $icon;
				echo "</div>\n";
				$friends_online++;
			} 
		} 
	}
	if ($friends_online == 0) 
	{
    //No friends online
    echo elgg_echo('plusriver:friends.online_nobody');
	}
?>


<div class="clearfloat"></div>





