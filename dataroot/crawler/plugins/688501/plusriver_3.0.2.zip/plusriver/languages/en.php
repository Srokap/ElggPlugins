<?php

	$english = array(




		//constants
		'plusriver:size_tiny'   => 'Tiny',
		'plusriver:size_small'   => 'Small',
		'plusriver:size_medium'   => 'Medium',
		'plusriver:change_photo'   => 'Change Photo ',





		/************************************************
		*		ADMIN
		************************************************/

		'plusriver:admin'   => 'Plus River Settings',
		'plusriver:add_thewire'   => 'Add the wire form? ',
		'plusriver:add_video'   => 'Add video form? ',
		'plusriver:default_view'   => 'Default View ',
		'plusriver:add_avatar'   => 'Enable Fixed Box with Avatar?  ',
		'plusriver:add_quicklinks'   => 'Enable Fixed Box with Quick Links? ',
		'plusriver:add_sitemessage'   => 'Enable Fixed Box with Site Message? ',
		'plusriver:add_ads'   => 'Enable Fixed Box with Custom HTML? ',
		'plusriver:avatar_size'   => 'Size of avatars in river: ',





		/************************************************
		*		MAIN
		************************************************/

		//edit widgets window
		'plusriver:edit_middle'   => 'Main Content',


		//share forms
		'plusriver:share'   => 'Share:',
		'plusriver:share_status'   => 'My Status',
		'plusriver:share_video'   => 'Video',





		/****************************************************
		* 		WIDGETS
		*****************************************************/

		// Friends Online
		'plusriver:widget:friends_online'   => 'Friends Online',
		'plusriver:widget:edit:friends_online:number'   => 'Number of Friends to display ',
		'plusriver:widget:friends_online:description'   => 'Display wich of your friends are online ',
		'plusriver:friends.online_nobody'   => 'Nobody of your friends are online ',
		'plusriver:widget:edit:friends_online:size'   => 'Size of friend\'s icons ', 



		// Recent Members
		'plusriver:widget:recent_members'   => 'Recent Members',
		'plusriver:widget:edit:recent_members:number'   => 'Number of recent users to display ',
		'plusriver:widget:recent_members:description'   => 'Display the most recent members ',
		'plusriver:widget:edit:recent_members:size'   => 'Size of user\'s icons ', 




		/****************************************************
		* 		FIXED BOXES
		*****************************************************/

		//Avatar Box
		'plusriver:box:avatar'   => 'Welcome ',



		//Quick Links Box
		'plusriver:box:quicklinks'   => 'Quick Links ',
		'plusriver:manage_photos'   => 'Manage Photos',
		'plusriver:upload_file'   => 'Upload a File',
		'plusriver:blog'   => 'Blog',
		'plusriver:thewire'   => 'The Wire',
		'plusriver:messageboard'   => 'Message Board',
		'plusriver:friends'   => 'Friends',
		'plusriver:settings'   => 'Settings',

		//Ads Box
		'plusriver:box:ads'   => 'Advertisments ',





);
					
	add_translation("en",$english);

?>
