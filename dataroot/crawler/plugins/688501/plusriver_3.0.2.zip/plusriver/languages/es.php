<?php

	$spanish = array(




		//constants
		'plusriver:size_tiny'   => 'Diminuto',
		'plusriver:size_small'   => 'Pequeño',
		'plusriver:size_medium'   => 'Mediano',
		'plusriver:change_photo'   => 'Cambiar Foto ',




		/************************************************
		*		ADMIN
		************************************************/

		'plusriver:admin'   => 'Conf. de Plus River',
		'plusriver:add_thewire'   => '¿Activar el formulario de estado? ',
		'plusriver:add_video'   => '¿Activar el formulario de video? ',
		'plusriver:default_view'   => 'Vista por Defecto ',
		'plusriver:add_avatar'   => '¿Activar la caja fija con Persona?  ',
		'plusriver:add_quicklinks'   => '¿Activar la caja fija con atajos? ',
		'plusriver:add_sitemessage'   => '¿Activar la caja fija con los mensajes del sitio? ',
		'plusriver:add_ads'   => '¿Activar la caja fija con HTML personalizado? ',
		'plusriver:avatar_size'   => 'Tamaño de las fotos en el escritorio: ',





		/************************************************
		*		MAIN
		************************************************/

		//edit widgets window
		'plusriver:edit_middle'   => 'Principal',


		//share forms
		'plusriver:share'   => 'Compartir:',
		'plusriver:share_status'   => 'Mensaje',
		'plusriver:share_video'   => 'Video',





		/****************************************************
		* 		WIDGETS
		*****************************************************/

		// Friends Online
		'plusriver:widget:friends_online'   => 'Amigos Conectados',
		'plusriver:widget:edit:friends_online:number'   => 'Numero de amigos a mostrar ',
		'plusriver:widget:friends_online:description'   => 'Muestra a tus amigos conectados ',
		'plusriver:friends.online_nobody'   => 'Ninguno de tus amigos esta en línea ',
		'plusriver:widget:edit:friends_online:size'   => 'Tamaño de las fotos de amigos ', 



		// Recent Members
		'plusriver:widget:recent_members'   => 'Nuevos Usuarios',
		'plusriver:widget:edit:recent_members:number'   => 'Numero de Usuarios a Mostrar ',
		'plusriver:widget:recent_members:description'   => 'Muestra los usuarios mas nuevos ',
		'plusriver:widget:edit:recent_members:size'   => 'Tamaño de la foto de nuevos usuarios ', 





		/****************************************************
		* 		FIXED BOXES
		*****************************************************/

		//Avatar Box
		'plusriver:box:avatar'   => 'Bienvenido ',



		//Quick Links Box
		'plusriver:box:quicklinks'   => 'Atajos ',
		'plusriver:manage_photos'   => 'Mis Fotos',
		'plusriver:upload_file'   => 'Subir un Archivo',
		'plusriver:blog'   => 'Blog',
		'plusriver:thewire'   => 'Microblogging',
		'plusriver:messageboard'   => 'Libro de Visitas ',
		'plusriver:friends'   => 'Amigos',
		'plusriver:settings'   => 'Opciones',

		//Ads Box
		'plusriver:box:ads'   => 'Publicidad ',






);
					
	add_translation("es",$spanish);

?>
