<?php

/////////////////////////////////////////////////////////////////////////////////
// Plus River - start.php
// Packed by Angel Gabriel - angel.wrt@gmail.com
// Website www.redvabel.com
// Plugin Homepage http://dev.redvabel.com/elgg/pg/groups/5/plugin-plus-river/
/////////////////////////////////////////////////////////////////////////////////


	
    	function plusriver_init() 
	{	
			global $CONFIG;
			
			register_plugin_hook('index','system','plusriver');

			register_translations($CONFIG->pluginspath . "plusriver/languages/");//translations	

			elgg_extend_view('css','plusriver/css');//Styles

			register_page_handler('dashboard','plusriver_page_handler');//the page handler

			register_elgg_event_handler('pagesetup', 'system', 'plusriver_pagesetup');//admin page link to our settings

			register_action("plusriver/riverdashboard/add",false,$CONFIG->pluginspath . "plusriver/actions/riverdashboard/add.php");//action for the river

			//ask if the admin wants the wire form
			$thewireon = get_plugin_setting("addthewire", "plusriver");
			if($thewireon == 'yes')
			{
			register_action("plusriver/add",false,$CONFIG->pluginspath . "plusriver/actions/thewire/add.php");//action for post trought the wire
			}

			/**** WIDGETS ****/
			// Friends Online
				add_widget_type('friendsonline',elgg_echo('plusriver:widget:friends_online'),elgg_echo('plusriver:widget:friends_online:description'));

			// Recent Members
				add_widget_type('recentmembers',elgg_echo('plusriver:widget:recent_members'),elgg_echo('plusriver:widget:recent_members:description'));
    	}
    
	
		
		
	function plusriver_page_handler($page) 
		{
			global $CONFIG;
			$page = (isset($page[0])) ? $page[0] : FALSE;
			if($page == 'admin')
				{
					set_context('admin');
					$plugin = find_plugin_settings('plusriver');
					$form_body = elgg_view('plusriver/settings/edit', array('entity' => $plugin));
					$form_body .= "<p>" . elgg_view('input/hidden', array('internalname' => 'plugin', 'value' => 'plusriver')) . elgg_view('input/submit', 						array('value' => elgg_echo('save'))) . "</p>";

	
					$content = elgg_view('input/form', array('action' => "{$CONFIG->url}action/plugins/settings/save", 'body' => $form_body));
					$content = "<div class='contentWrapper'>$subtitle <br /> $content</div>";
	
					$title = elgg_echo('plusriver:admin');
					$body = elgg_view_layout('two_column_left_sidebar', '', elgg_view_title($title) . $content);
					page_draw($title, $body);
				}
        		else//override riverdashboard index for plusriver
				{
        				@include(dirname(__FILE__) . "/index.php"); //this will be your new dashboard page
       				}     
    		}



	function plusriver_pagesetup() 
		{
			if (get_context() == 'admin' && isadminloggedin()) 
				{
					global $CONFIG;
					add_submenu_item(elgg_echo('plusriver:admin'), $CONFIG->wwwroot . 'pg/dashboard/admin/');
				}
		}



	
	register_elgg_event_handler('init','system','plusriver_init');


