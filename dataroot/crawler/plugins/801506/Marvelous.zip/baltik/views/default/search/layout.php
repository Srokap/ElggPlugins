<?php
/**
   * Elgg core search listing.
   *
   * @package Elgg
   * @subpackage Core
   * @author Curverider Ltd and customized by Juipo.com <info@elgg.com>, The MITRE Corporation <http://www.mitre.org>
   * @link http://elgg.org/  and  http://juipo.com/
   */

echo elgg_view_layout('two_column_left_sidebar', '', $vars['body']);