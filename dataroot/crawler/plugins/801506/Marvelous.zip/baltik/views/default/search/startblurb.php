<?php
/**
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd and customized by Juipo.com
 * @link http://elgg.org/  and  http://juipo.com/
 */
?>
<div class="contentWrapper">
<?php
	echo sprintf(elgg_echo("tag:search:startblurb"), $vars['query']);
?>
</div>