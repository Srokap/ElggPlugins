<?php
/**
 * Elgg search listing: gallery view
 *
 * DEPRECATED VIEW: use entities/gallery_listing instead
 *
 * @package Elgg
 * @subpackage Core
 * @author Curverider Ltd and customized by Juipo.com
 * @link http://elgg.org/  and  http://juipo.com/
 */


    echo elgg_view('entities/gallery_listing', $vars);

?>