<?php
if (isloggedin()) forward('pg/dashboard/');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <title>Baltik Theme</title>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="Fill this for SEO"> 
        <meta name="description" content="Fill this for SEO" />
        <meta name="keywords" content="Fill this for SEO" />
		<meta name="author" content="Fill this for SEO" />
		<link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="mod/baltik/css/demo.css" />
		<link rel="stylesheet" type="text/css" href="mod/baltik/css/style.css" />
		<link rel="stylesheet" type="text/css" href="mod/baltik/css/elastislide.css" />
		<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow&v1' rel='stylesheet' type='text/css' />
		<link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css' />
		
		<script type="text/javascript"> 
var totalCount = 7;
function SW_SocialWeb_engine() 
{
var num = Math.ceil( Math.random() * totalCount );
document.body.background = 'mod/baltik/images/'+num+'.jpg';
document.body.style.backgroundRepeat = "no-repeat";// Background repeat
}
</script>
		
		<noscript>
			<style>
				.es-carousel ul{
					display:block;
				}
			</style>
		</noscript>
	
				
				
			
    </head>

	
	

<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
    <body>
	<script type="text/javascript"> 
SW_SocialWeb_engine();
</script> 
	
	
	<div class="header">
			
				<span class="right_ab" style="font-weight:bold;">
					<?php include("mod/baltik/form.php"); ?>
				</span>
				<div class="clr"></div>
			</div>
			&nbsp;<div style="float:right; padding-right:30px; padding-top: 58px;"> <p>&nbsp; </p>
			
			<img style=" border:1px solid #ddd;
	margin:0 auto;
	-moz-box-shadow:1px 1px 7px #ccc;
	-webkit-box-shadow:1px 1px 7px #ccc;
	box-shadow:1px 1px 7px #ccc;"src="mod/baltik/images/back.jpg">
			</div>
			<div style="padding-left:58px; padding-top: 48px; ">
			<p style="font-size:38px;">Sign up! It is free!</p>
				&nbsp;
			<?php
								////////////////////////////////////////////////////////////////
								$form_body  = "<p><label style='font-size:28px;'>" . elgg_echo('name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
								$form_body .= "<label  style='font-size:28px;'>" . elgg_echo('email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
								$form_body .= "<label  style='font-size:28px;'>" . elgg_echo('username') . "<br />" . elgg_view('input/text' , array('internalname' => 'username', 'class' => "general-textarea", 'value' => $username)) . "</label><br />";
								$form_body .= "<label  style='font-size:28px;'>" . elgg_echo('password') . "<br />" . elgg_view('input/password' , array('internalname' => 'password', 'class' => "general-textarea")) . "</label><br />";
								$form_body .= "<label  style='font-size:28px;'>" . elgg_echo('passwordagain') . "<br />" . elgg_view('input/password' , array('internalname' => 'password2', 'class' => "general-textarea")) . "</label><br /><br />";
								$form_body .= elgg_view('register/extend');
								$form_body .= elgg_view('input/captcha');
								if ($admin_option) {
									$form_body .= elgg_view('input/checkboxes', array('internalname' => "admin", 'options' => array(elgg_echo('admin_option'))));
								}
								$form_body .= elgg_view('input/hidden', array('internalname' => 'friend_guid', 'value' => $vars['friend_guid']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'invitecode', 'value' => $vars['invitecode']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'register'));
								$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('register'))) . "</p>";
								?>
								
								<h2>
								<?php
								//echo elgg_echo('register');
								?>
								</h2>
								<?php
								////////////////////////////////////////////////////////////////
								echo elgg_view
								(
									'input/form'
									,array
									(
										'body' => $form_body
										,'action' => "{$vars['url']}action/register"
									)
								);
								?>
								&nbsp;</div>
		<div class="container">
			<!-- header -->
			
			<div class="content">
				
				<div id="rg-gallery" class="rg-gallery">
					<div class="rg-thumbs">
						<!-- Elastislide Carousel Thumbnail Viewer -->
						
						<!-- End Elastislide Carousel Thumbnail Viewer -->
					</div><!-- rg-thumbs -->
				</div><!-- rg-gallery -->
			</div><!-- content -->
		</div><!-- container -->
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
	<div class="headers">
		
		
				<a style="color:#ddd;" href="http://www.swsocialweb.com/shop"><span> Copyright </span>SW Social Web</a>
				<span class="right_ab">
					Designed by <a style="color:#ddd;" href="http://www.swsocialweb.com/shop" target="_blank">SW Social Web</a>
					<a style="color:#ddd;" href="#">About</a>
					<a style="color:#ddd;" href="#"><strong>Terms</strong></a>
				</span>
				<div class="clr"></div>
			</div>
				
	<script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
    </body>
</html>