<?php
$english = array(
    'item:object:anonymous_comments' => 'comments',
    'anonymous_comments:list' => 'Public comments',
    'anonymous_comments:anonymous_comment' => 'Public comment',
    'anonymous_comments:anonymous_owner' => 'Visitor',
    'comments:list' => 'Public comments listing',
    'comments:total' => 'Total comments = ',
    
    // Settings
    'anonymous_comments:disableform' => "Disable anonymous comment form",
    'anonymous_comments:disableanocomments' => "Disable all anonymous comments (note : do NOT disable the plugin itself)",
    'anonymous_comments:blockip' => "Blocked IP",
    'anonymous_comments:notify' => "User GUID to notify (either a GUID, or comma-separated list of GUIDs, and no space at all, e.g. : \"2\"  or \"2,12,23\"  )",
    'settings:yes' => "yes",
    'settings:no' => "no",
    
    // Messages envoyés aux utilisateurs spécifiés
    'anonymous_comments:commentanonymus' => "Anonymous comment [%s] %s",
    'anonymous_comments:adminmail' => "Anonymous comment :
    
- by : %s
- mail : %s
- from IP : %s
- content :
%s",
    /*
    'generic_comment:email:body' => "",
    'generic_comment:email:subject' => "",
    */
    
    
    // Actions - déjà définies ailleurs ?
    'anonymous_comments:missingfield' => "Oups! looks like you've forgotten something - please fill all fields and do the maths for your comment to be published !",
    /*
    'generic_comment:failure' => "Commentaires publics : une erreur est survenue",
    'generic_comment:notfound' => "Commentaire non trouvé",
    'generic_comment:posted' => "Commentaire publié !",
    'generic_comment:deleted' => "Commentaire supprimé",
    'generic_comment:notdeleted' => "Le commentaire n'a pas pu être supprimé",
    */
    
);

add_translation("en",$english);
