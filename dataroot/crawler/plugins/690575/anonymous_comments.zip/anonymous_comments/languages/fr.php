<?php
/*******************************************************************************
 * fr.php
 *
 * @package             anonymous_comment
 ******************************************************************************/


$french = array(
    'item:object:anonymous_comments' => 'commentaires',
    'anonymous_comments:list' => 'Commentaires publics',
    'anonymous_comments:anonymous_comment' => 'Commentaire public',
    'anonymous_comments:anonymous_owner' => 'Visiteur',
    'comments:list' => 'Commentaires publics',
    'comments:total' => 'Total commentaires = ',
    
    // Settings
    'anonymous_comments:disableform' => "Désactiver le formulaire de commentaire anonyme",
    'anonymous_comments:disableanocomments' => "Désactiver tous les commentaires anonymes (note : ne PAS désactiver le plugin)",
    'anonymous_comments:blockip' => "IP bloquées",
    'anonymous_comments:notify' => "GUID (ex.: \"2\") ou liste de GUID (ex.: \"2,12,23\") des utilisateurs à prévenir par mail lors de l'ajout d'un commentaire anonyme",
    'settings:yes' => "oui",
    'settings:no' => "non",
    
    // Messages envoyés aux utilisateurs spécifiés
    'anonymous_comments:commentanonymus' => "Commentaire anonyme [%s] %s",
    'anonymous_comments:adminmail' => "Commentaire public à examiner :
    
- publié par : %s
- au nom de l'adresse mail : %s
- depuis l'IP : %s
- contenu publié :
%s",
    /*
    'generic_comment:email:body' => "",
    'generic_comment:email:subject' => "",
    */
    
    
    // Actions - déjà définies ailleurs ?
    'anonymous_comments:missingfield' => "Oups! Merci de bien vouloir renseigner tous les champs et effectuer le calcul proposé pour valider votre commentaire.",
    /*
    'generic_comment:failure' => "Commentaires publics : une erreur est survenue",
    'generic_comment:notfound' => "Commentaire non trouvé",
    'generic_comment:posted' => "Commentaire publié !",
    'generic_comment:deleted' => "Commentaire supprimé",
    'generic_comment:notdeleted' => "Le commentaire n'a pas pu être supprimé",
    */
    
);

add_translation("fr",$french);
