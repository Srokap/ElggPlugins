<?php
/*******************************************************************************
 * anonymous comments
 *
 * @author klermor
 ******************************************************************************/

function anonymous_comments_init() {
    global $CONFIG;

    extend_view('css',	'comments/css');

    $opencomments = find_plugin_settings('anonymous_comments');

    $anonymous_exist = get_entities('object','anonymous_comments', 0 ,'', 1,0,TRUE); //

    if ($anonymous_exist == 0 ) {
        $anonymous = new ElggObject();
        $anonymous->subtype     = "anonymous_comments";
        $anonymous->title 	= "anonymous_comments";
        $anonymous->description	= "";
        $anonymous->access_id 	= ACCESS_PUBLIC;

        if (!$anonymous->save()) {
            register_error(elgg_echo('create object anonymous fail'));
            forward();
        }

        $anonymous_entity = get_entities('object','anonymous_comments', 0 ,'', 1,0,FALSE);
        set_plugin_setting('anonymous', $anonymous_entity[0]->guid, 'anonymous_comments');

    }

    return true;
}

/**
 * page handler for nicer urls
 */
function anonymous_comments_page_handler($page) {
    global $CONFIG;

    $tab = $page[0];

    if (!$tab) {
        $tab = "list";
    }

    if ($tab == 'list') {
        include $CONFIG->pluginspath . "anonymous_comments/list.php";
        return true;
    } else {
        return false;
    }
}

/**
 * Set up menu items
 *
 */
function anonymous_comments_pagesetup() {
    if (get_context() == 'admin' && isadminloggedin()) {
        global $CONFIG;
        add_submenu_item(elgg_echo('anonymous_comments:list'), $CONFIG->wwwroot . 'pg/anonymous_comments/list');
    }
}

global $CONFIG;

require_once(dirname(__FILE__) . "/lib/anonymous_comments.php");

register_action('comments/add', 	false, $CONFIG->pluginspath .'anonymous_comments/actions/add.php');
register_action('comments/delete', 	false, $CONFIG->pluginspath .'anonymous_comments/actions/delete.php');
//register_action('comments/update', 	false, $CONFIG->pluginspath .'anonymous_comments/actions/update.php');

register_entity_type('object','anonymous_comments');

register_page_handler('anonymous_comments','anonymous_comments_page_handler');

register_elgg_event_handler('pagesetup','system','anonymous_comments_pagesetup');
register_elgg_event_handler('init', 'system', 'anonymous_comments_init');
