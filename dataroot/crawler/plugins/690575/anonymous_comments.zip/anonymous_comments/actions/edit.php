<?php

// Make sure we're logged in (send us to the front page if not)
if (!isloggedin()) forward();
/*		
// Make sure we can get the comment in question
$annotation_id = get_input("annotation_id");
$post_comment = get_input("postComment{$field_num}");
$annotation = get_annotation($annotation_id);
$commentOwner = $annotation->owner_guid;
$access_id = $annotation->access_id;
if($annotation){
	//can edit? Either the comment owner or admin can
	if($annotation->canEdit()){
		update_annotation($annotation_id, "generic_comment", $post_comment, "",$commentOwner, $access_id);
		system_message(elgg_echo("comment:edited"));
	} else {
		system_message(elgg_echo("comment:error"));
	}
			
} else {
	system_message(elgg_echo("comment:error"));
}

forward($_SERVER["HTTP_REFERER"]);
*/  

