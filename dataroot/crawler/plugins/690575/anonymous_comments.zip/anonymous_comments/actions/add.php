<?php

action_gatekeeper();
global $CONFIG;
$entity_guid            = (int) get_input('entity_guid');
$comment_text           = trim(get_input('generic_comment'));
$comment_anonymous_name = get_input('comment_anonymous_name');
$comment_anonymous_mail = get_input('comment_anonymous_mail');
$nb1                    = (int)get_input('nb1');
$nb2                    = (int)get_input('nb2');
$equ                    = (int)get_input('equ');
$comment_anonymous_ip   = $_SERVER['REMOTE_ADDR'];



if ($entity = get_entity($entity_guid)) {

    if (str_replace(' ', '',$comment_text)==''){
        register_error(elgg_echo("generic_comment:failure"));
        forward($entity->getURL());
    }



    if (!isloggedin()) {

        if ($comment_text =='' OR $comment_anonymous_name=='' OR $comment_anonymous_mail==''OR ($equ != $nb1+$nb2) ) {
            //register_error(elgg_echo("generic_comment:failure"));
            $notice = elgg_echo("anonymous_comments:missingfield");
            register_error($notice);
            forward($entity->getURL());
        }
        
        $opencomments = find_plugin_settings('anonymous_comments');
        $message = sprintf(elgg_echo('anonymous_comments:adminmail'), $comment_anonymous_name, $comment_anonymous_mail, $comment_anonymous_ip, $comment_text);
        $comment_text = $comment_anonymous_name . ','.$comment_anonymous_mail.','.$comment_anonymous_ip.'|'.$comment_text;

        if ($entity->annotate('generic_comment',$comment_text,$entity->access_id, $opencomments->anonymous )) {
            system_message(elgg_echo("generic_comment:posted"));
            //add_to_river('annotation/annotate','comment',$opencomments->anonymous,$entity->guid);
            // klermor 20101103
            // Facyla 20101201 : new subject with date
            $subject = sprintf(elgg_echo('anonymous_comments:commentanonymus'), $CONFIG->site->name, date('d-m-Y G:i'));
            // Facyla 20101201 : configurable notified users + antifail if wrong settings syntax
            if ( $notified_users = explode(',', trim($opencomments->notify)) ) notify_user($notified_users, $CONFIG->site->guid, $subject, $message, NULL, 'email');
        }
        forward($entity->getURL());
    }


    if ($entity->annotate('generic_comment',$comment_text,$entity->access_id, $_SESSION['guid'])) {

        if ($entity->owner_guid != $_SESSION['user']->getGUID())
            notify_user($entity->owner_guid, $_SESSION['user']->getGUID(), elgg_echo('generic_comment:email:subject'),
                    sprintf(
                    elgg_echo('generic_comment:email:body'),
                    $entity->title,
                    $_SESSION['user']->name,
                    $comment_text,
                    $entity->getURL(),
                    $_SESSION['user']->name,
                    $_SESSION['user']->getURL()
                    )
            );

        system_message(elgg_echo("generic_comment:posted"));
        add_to_river('annotation/annotate','comment',$_SESSION['user']->guid,$entity->guid);

    } else {
        register_error(elgg_echo("generic_comment:failure"));
    }
} else {
    register_error(elgg_echo("generic_comment:notfound"));
}

forward($entity->getURL());
