<?php


//action_gatekeeper();

// TODO supprimer par la meme occasion la ref dans la river

if (!isloggedin()) forward();

// Make sure we can get the comment in question
$annotation_id = (int) get_input('annotation_id');
if ($comment = get_annotation($annotation_id)) {

    $entity = get_entity($comment->entity_guid);

    if ($comment->canEdit()) {
        $comment->delete();

        //remove_from_river_by_annotation($annotation_id);
        //remove_from_river_by_object($annotation_id);

        system_message(elgg_echo("generic_comment:deleted"));
        forward($_SERVER["HTTP_REFERER"]);
    }

} else {
    $url = "";
}

register_error(elgg_echo("generic_comment:notdeleted"));

forward($_SERVER["HTTP_REFERER"]);
