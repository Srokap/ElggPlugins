<?php

function generic_comment_anonymous($owner_guid) {
    $opencomments = find_plugin_settings('anonymous_comments');
    if ($opencomments->anonymous != $owner_guid ) {
        return FALSE;
    }
    return TRUE;
}

function generic_comment_anonymous_content($string) {

    //$metadata_string    = strstr($vars['annotation']->value, '|', true); // uniquement à partir de PHP 5.3
    $len_max            = strlen($string);
    $annotation         = substr( strstr($string, '|') ,1);
    $len_annotation     = strlen($annotation);
    $metadata_string    = substr($string, 0, ($len_max - $len_annotation - 1));
    $metadata           = explode(',',$metadata_string);
    $annotation         = substr( strstr($string, '|') ,1);

    return array($annotation,$metadata);
}


function get_annotations_not_anonymous($entity_guid = 0, $entity_type = "", $entity_subtype = "", $name = "", $value = "", $owner_guid = 0, $limit = 10, $offset = 0, $order_by = "asc", $timelower = 0, $timeupper = 0) {


    global $CONFIG;
    $opencomments = find_plugin_settings('anonymous_comments');

    $owner_anonymous = $opencomments->anonymous;

    $timelower = (int) $timelower;
    $timeupper = (int) $timeupper;

    if (is_array($entity_guid)) {
        if (sizeof($entity_guid) > 0) {
            foreach($entity_guid as $key => $val) {
                $entity_guid[$key] = (int) $val;
            }
        } else {
            $entity_guid = 0;
        }
    } else {
        $entity_guid = (int)$entity_guid;
    }
    $entity_type = sanitise_string($entity_type);
    $entity_subtype = get_subtype_id($entity_type, $entity_subtype);
    if ($name) {
        $name = get_metastring_id($name);

        if ($name === false)
            $name = 0;
    }
    if ($value != "") $value = get_metastring_id($value);


    // owner
    if (is_array($owner_guid)) {
        if (sizeof($owner_guid) > 0) {
            foreach($owner_guid as $key => $val) {
                // klermor
                if ($owner_anonymous == (int) $val) {
                    // rien... mais ca serait vicieux de mettre à FALSE et demander ce owner !!!
                } else {
                    $owner_guid[$key] = (int) $val;
                }
                //
            }
        } else {
            $owner_guid = 0;
        }
    } else {
        $owner_guid = (int)$owner_guid;
        // on traitera le cas dans la requete...
    }





    $limit = (int)$limit;
    $offset = (int)$offset;
    if($order_by == 'asc')
        $order_by = "a.time_created asc";

    if($order_by == 'desc')
        $order_by = "a.time_created desc";

    $where = array();

    if ($entity_guid != 0 && !is_array($entity_guid)) {
        $where[] = "a.entity_guid=$entity_guid";
    } else if (is_array($entity_guid)) {
        $where[] = "a.entity_guid in (". implode(",",$entity_guid) . ")";
    }

    if ($entity_type != "")
        $where[] = "e.type='$entity_type'";

    if ($entity_subtype != "")
        $where[] = "e.subtype='$entity_subtype'";

    if ($owner_guid != 0 && !is_array($owner_guid) && $owner_guid != $owner_anonymous ) {
        $where[] = "a.owner_guid=$owner_guid";
    } else {

        if (is_array($owner_guid)) {
            // klermor
            unset($owner_guid[array_search($owner_anonymous, $owner_guid)]);
            if (count($owner_guid) > 0) {
                $owners = implode(",",$owner_guid);
                $where[] = "a.owner_guid in (" . implode(",",$owner_guid) . ")";
            }
        }
    }
    $where[] = "a.owner_guid!=$owner_anonymous";


    if ($name !== "")
        $where[] = "a.name_id='$name'";

    if ($value != "")
        $where[] = "a.value_id='$value'";

    if ($timelower)
        $where[] = "a.time_created >= {$timelower}";
    if ($timeupper)
        $where[] = "a.time_created <= {$timeupper}";

    $query = "SELECT a.*, n.string as name, v.string as value from {$CONFIG->dbprefix}annotations a JOIN {$CONFIG->dbprefix}entities e on a.entity_guid = e.guid JOIN {$CONFIG->dbprefix}metastrings v on a.value_id=v.id JOIN {$CONFIG->dbprefix}metastrings n on a.name_id = n.id where ";
    foreach ($where as $w)
        $query .= " $w and ";
    $query .= get_access_sql_suffix("a"); // Add access controls
    $query .= " order by $order_by limit $offset,$limit"; // Add order and limit

    return get_data($query, "row_to_elggannotation");

}


/**
 * Get a list of annotations for a given object/user/annotation type.
 *
 * @param int|array $entity_guid
 * @param string $entity_type
 * @param string $entity_subtype
 * @param string $name
 * @param mixed $value
 * @param int|array $owner_guid
 * @param int $limit
 * @param int $offset
 * @param string $order_by
 */
function get_annotations_multisite($entity_guid = 0, $entity_type = "", $entity_subtype = "", $name = "", $value = "", $owner_guid = 0, $limit = 10, $offset = 0, $order_by = "asc", $timelower = 0, $timeupper = 0) {
    global $CONFIG;

    $timelower = (int) $timelower;
    $timeupper = (int) $timeupper;

    if (is_array($entity_guid)) {
        if (sizeof($entity_guid) > 0) {
            foreach($entity_guid as $key => $val) {
                $entity_guid[$key] = (int) $val;
            }
        } else {
            $entity_guid = 0;
        }
    } else {
        $entity_guid = (int)$entity_guid;
    }
    $entity_type = sanitise_string($entity_type);
    $entity_subtype = get_subtype_id($entity_type, $entity_subtype);
    if ($name) {
        $name = get_metastring_id($name);

        if ($name === false)
            $name = 0;
    }
    if ($value != "") $value = get_metastring_id($value);
    if (is_array($owner_guid)) {
        if (sizeof($owner_guid) > 0) {
            foreach($owner_guid as $key => $val) {
                $owner_guid[$key] = (int) $val;
            }
        } else {
            $owner_guid = 0;
        }
    } else {
        $owner_guid = (int)$owner_guid;
    }
    $limit = (int)$limit;
    $offset = (int)$offset;
    if($order_by == 'asc')
        $order_by = "a.time_created asc";

    if($order_by == 'desc')
        $order_by = "a.time_created desc";

    $where = array();

    // klermor : multisite
    $where[] = "e.site_guid=$CONFIG->site_guid";


    if ($entity_guid != 0 && !is_array($entity_guid)) {
        $where[] = "a.entity_guid=$entity_guid";
    } else if (is_array($entity_guid)) {
        $where[] = "a.entity_guid in (". implode(",",$entity_guid) . ")";
    }

    if ($entity_type != "")
        $where[] = "e.type='$entity_type'";

    if ($entity_subtype != "")
        $where[] = "e.subtype='$entity_subtype'";

    if ($owner_guid != 0 && !is_array($owner_guid)) {
        $where[] = "a.owner_guid=$owner_guid";
    } else {
        if (is_array($owner_guid))
            $where[] = "a.owner_guid in (" . implode(",",$owner_guid) . ")";
    }

    if ($name !== "")
        $where[] = "a.name_id='$name'";

    if ($value != "")
        $where[] = "a.value_id='$value'";

    if ($timelower)
        $where[] = "a.time_created >= {$timelower}";
    if ($timeupper)
        $where[] = "a.time_created <= {$timeupper}";

    $query = "SELECT a.*, n.string as name, v.string as value from {$CONFIG->dbprefix}annotations a JOIN {$CONFIG->dbprefix}entities e on a.entity_guid = e.guid JOIN {$CONFIG->dbprefix}metastrings v on a.value_id=v.id JOIN {$CONFIG->dbprefix}metastrings n on a.name_id = n.id where ";
    foreach ($where as $w)
        $query .= " $w and ";
    $query .= get_access_sql_suffix("a"); // Add access controls
    $query .= " order by $order_by limit $offset,$limit"; // Add order and limit

    return get_data($query, "row_to_elggannotation");

}

