<?php
/**
 * Add link to the javascript and css for showcase plugin to the
 * page metatags
 */

if(get_context()=='admin') {
    ?>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/anonymous_comments/assets/jquery.pagination.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/anonymous_comments/assets/jquery.tablesorter.min.js"></script>
<script type="text/javascript">
/**
 * Callback function that displays the content.
 *
 * Gets called every time the user clicks on a pagination link.
 *
 * @param {int} page_index New Page index
 * @param {jQuery} jq the container with the pagination links as a jQuery object
 */
function pageselectCallback(page_index, jq){
    var new_content = jQuery('#hiddenresult div.result:eq('+page_index+')').clone();
    $('#Searchresult').empty().append(new_content);
     $.tablesorter.defaults.widgets = ['zebra'];
    $("#myList").tablesorter({
        headers: { 4: { sorter: false } }
    });
    return false;
}

/**
 * Initialisation function for pagination
 */
function initPagination() {
    // count entries inside the hidden content
    var num_entries = jQuery('#hiddenresult div.result').length;
    // Create content inside pagination element
    $("#Pagination").pagination(num_entries, {
        callback: pageselectCallback,
        items_per_page:1 // Show only one item per page
    });
}

// When document is ready, initialize pagination
$(document).ready(function(){
   initPagination();
});
/*
$(function(){
     $.tablesorter.defaults.widgets = ['zebra'];
    $("#myList").tablesorter({
        headers: { 4: { sorter: false } }
    });
   
});
*/
</script>

<style type="text/css" media="screen">
    /* tables */
    table.tablesorter {
        font-family:arial;
        background-color: #CDCDCD;
        margin:10px 0pt 15px;
        font-size: 8pt;
        width: 100%;
        text-align: left;
    }
    table.tablesorter thead tr th, table.tablesorter tfoot tr th {
        background-color: #e6EEEE;
        border: 1px solid #FFF;
        font-size: 8pt;
        padding: 4px;
    }
    table.tablesorter thead tr .header {
        background-image: url(<?php echo $vars['url']; ?>mod/anonymous_comments/graphics/bg.gif);
        background-repeat: no-repeat;
        background-position: center right;
        cursor: pointer;
    }
    table.tablesorter tbody td {
        color: #3D3D3D;
        padding: 4px;
        background-color: #FFF;
        vertical-align: top;
    }
    table.tablesorter tbody tr.odd td {
        background-color:#F0F0F6;
    }
    table.tablesorter thead tr .headerSortUp {
        background-image: url(<?php echo $vars['url']; ?>mod/anonymous_comments/graphics/asc.gif);
    }
    table.tablesorter thead tr .headerSortDown {
        background-image: url(<?php echo $vars['url']; ?>mod/anonymous_comments/graphics/desc.gif);
    }
    table.tablesorter thead tr .headerSortDown, table.tablesorter thead tr .headerSortUp {
        background-color: #8dbdd8;
    }

    .pagination {
        font-size: 80%;
    }

    .pagination a {
        text-decoration: none;
        border: solid 1px #AAE;
        color: #15B;
    }

    .pagination a, .pagination span {
        display: block;
        float: left;
        padding: 0.3em 0.5em;
        margin-right: 5px;
        margin-bottom: 5px;
        min-width:1em;
        text-align:center;
    }

    .pagination .current {
        background: #26B;
        color: #fff;
        border: solid 1px #AAE;
    }

    .pagination .current.prev, .pagination .current.next{
        color:#999;
        border-color:#999;
        background:#fff;
    }
</style>
    <?php
}
?>

<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/anonymous_comments/assets/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/anonymous_comments/assets/additional-methods.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/anonymous_comments/assets/localization/messages_fr.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $("#commentAnonymous").validate();
});
</script>
