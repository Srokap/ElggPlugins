<?php

$performed_by   = get_entity($vars['item']->subject_guid); // $statement->getSubject();
$object         = get_entity($vars['item']->object_guid);
$subtype        = get_subtype_from_id($object->subtype);

$opencomments = find_plugin_settings('anonymous_comments');

if($performed_by->guid != $opencomments->anonymous ) {
   $url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
} else {
    $url = elgg_echo("blog:river:noperformer");
    $url = "invité";
}

$string = sprintf(elgg_echo("river:posted:generic"),$url) . " ";
$string .= elgg_echo("{$subtype}:river:annotate") . " | <a href=\"" . $object->getURL() . "\">" . $object->title . "</a>";

echo $string; 