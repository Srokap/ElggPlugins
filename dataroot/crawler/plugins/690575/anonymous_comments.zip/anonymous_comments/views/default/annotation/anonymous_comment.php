<?php

$opencomments = find_plugin_settings('anonymous_comments');

if (generic_comment_anonymous($vars['annotation']->owner_guid)){
    $owner = "anonymous";
} else {
    $owner = get_user($vars['annotation']->owner_guid);
}

if ($opencomments->comments_disabled == 'yes' AND $owner == "anonymous") {
    // rien
} else {


?>

<div class="generic_comment">
        <?php   if ($owner !="anonymous") {  ?>
    <div class="generic_comment_icon">
                <?php
                echo elgg_view("profile/icon",
                array(
                'entity' => $owner,
                'size' => 'small'));
                ?>
    </div>
            <?php
        }
        ?>

    <div class="generic_comment_details">
            <?php
            $annotation = $vars['annotation']->value;
            if ($owner =="anonymous") {
                $annotations = generic_comment_anonymous_content($annotation);
                //$metadata_string    = strstr($vars['annotation']->value, '|', true); // uniquement à partir de PHP 5.3
                /*
                $len_max            = strlen($vars['annotation']->value);
                $annotation         = substr( strstr($vars['annotation']->value, '|') ,1);
                $len_annotation     = strlen($annotation);
                $metadata_string    = substr($vars['annotation']->value, 0, ($len_max - $len_annotation - 1));
                $metadata = explode(',',$metadata_string);
                $annotation         = substr( strstr($vars['annotation']->value, '|') ,1);
                 */
               $annotation  = $annotations[0];
               $metadata    = $annotations[1];
            }
            echo elgg_view("output/longtext",array("value" => $annotation));
            ?>

        <p class="generic_comment_owner">
                <?php
                if ($owner !="anonymous") {
                    echo '<a href="'.$owner->getURL().'">'.$owner->name.'</a> ';
                } else {
                    echo $metadata[0].'(invité) ';
                }
                echo friendly_time($vars['annotation']->time_created);
                ?>
        </p>

            <?php if ($vars['annotation']->canEdit()) { ?>
        <p>
                    <?php

                    echo elgg_view("output/confirmlink",array(
                    'href' => $vars['url'] . "action/comments/delete?annotation_id=" . $vars['annotation']->id,
                    'text' => elgg_echo('delete'),
                    'confirm' => elgg_echo('deleteconfirm'),
                    ));

                    ?>
        </p>

                <?php
            }
            ?>
    </div>
</div>


    <?php

}

?>