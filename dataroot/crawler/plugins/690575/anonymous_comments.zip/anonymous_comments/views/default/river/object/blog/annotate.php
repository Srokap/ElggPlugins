<?php

$statement      = $vars['statement'];
$performed_by   = $statement->getSubject();
$object         = $statement->getObject();

$opencomments = find_plugin_settings('comments');

if($performed_by->guid != $opencomments->anonymous ) {
   $url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
} else {
    $url = elgg_echo("blog:river:noperformer");
    $url = "invité";
}

$string = sprintf(elgg_echo("blog:river:posted"),$url) . " ";
$string .= elgg_echo("blog:river:annotate:create") . " <a href=\"" . $object->getURL() . "\">" . $object->title . "</a>";

echo $string;