<?php
global $CONFIG;

$annotations    = $vars['annotations'];
$nb_annotations = count ($annotations);
echo elgg_echo('comments:total') . $nb_annotations . " / ". count_annotations(0, '', '', 'generic_comment');;
$limit_pagination = 20;

$opencomments = find_plugin_settings('comments');

if (is_array($annotations) && sizeof($annotations) > 0) {

    $tabheader = '<table id="myList" class="tablesorter">
	<thead> 
	<tr> 
	    <th>guid</th> 
	    <th>title post</th>
	    <th>Auteur comment</th>
	    <th>Date</th>
        <th>content</th>
        <th>éditer</th>
	    <th>supprimer</th>
	    <th>check</th>
	</tr> 
	</thead> 
	<tbody> ';
    $tabbottom = '</tbody></table> ';
    $flag = 0;
    $counter = 1;
    $body = '';
    $ii = 1;
    foreach ($annotations as $annotation) {
        $url        = $annotation->getURL();
        $comment    = $annotation->value;
        $blog = get_entity($annotation->entity_guid);

        if (generic_comment_anonymous($annotation->owner_guid)) {
            $comment_metadata = generic_comment_anonymous_content($comment);
            $comment  = $comment_metadata[0];
            $metadata = $comment_metadata[1];
            $username = $metadata[0] . ' ('.$metadata[1].' | '. $metadata[2] .')';
        } else {
            $username = '<a href="'.$CONFIG->wwwroot.'pg/profile/'.get_user($annotation->owner_guid)->username.'">'.get_user($annotation->owner_guid)->name.'</a>';
        }

        $tabbody .= '<tr>';
        $tabbody .=  '<td><a href="'.$url.'">'.$annotation->id.'</a></td>';
        $tabbody .=  '<td><a href="'.$blog->getURL().'">'.$blog->title. '</a></td>';
        $tabbody .=  '<td>'.$username.'</td>';
        $tabbody .=  '<td>'.date("d M Y", $annotation->time_created).'</td>';
 /*       
        $comment_edit  	= "  <a class=\"collapsibleboxlink\"> ".elgg_echo('edit')."</a>  ";
        $comment_edit  .= "<div class=\"collapsible_box\">";
        $submit_input  	= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('save')));
		$text_textarea 	= elgg_view('input/longtext', array('internalname' => 'postComment'.$annotation->id, 'value' => $comment));
		$post 			= elgg_view('input/hidden', array('internalname' => 'annotation_id', 'value' => $annotation->id));
		$form_body 		= "<div class='edit_forum_comments'>
							<p class='longtext_editarea'>".$text_textarea."</p>".
                            $post. 
                            "<p>".$submit_input."</p>".
                            " </div>";
		$form_edit 		=  elgg_view('input/form', array('action' => "{$vars['url']}action/comments/edit", 'body' => $form_body, 'internalid' => 'editforumpostForm'));
*/
        
        $tabbody .=  '<td>'.$comment.$form_edit.'</td>';
        $tabbody .=  '<td>edit</td>';
        $tabbody .=  '<td>';
        $tabbody .= elgg_view('output/confirmlink',array(
                'href' 		=> $vars['url'] . "action/comments/delete?annotation_id={$annotation->id}",
                'text' 		=> elgg_echo("delete"),
                'confirm' 	=> elgg_echo("acl:role:delete:confirm"),
                'is_action' => TRUE
        ));
        $tabbody .= '</td>';
        $tabbody .=  '<td>check</td>';
        $tabbody .=  '</tr>';

        $controls .= elgg_view('output/confirmlink',array(
                'href' 		=> $vars['url'] . "action/comments/delete?annotation_id={$annotation->id}",
                'text' 		=> elgg_echo("delete"),
                'confirm' 	=> elgg_echo("acl:role:delete:confirm"),
                'is_action' => TRUE
        ));


        if ($counter == $limit_pagination OR $ii ==  $nb_annotations ) {
            $flag = 1;
            $body .= '<div class="result">';
            $body .= $tabheader;
            $body .= $tabbody;
            $body .= $tabbottom;
            $body .= '</div>';
            $tabbody = '';
            $counter = 0;
        }
        ++$counter;
        ++$ii;
    }

    if ($body =="" AND $flag == 0 ) {
        $body .= '<div class="result">';
        $body .= $tabheader;
        $body .= $tabbody;
        $body .= $tabbottom;
        $body .= '</div>';
    }

}

echo '<div id="Pagination"></div>';
echo '<br style="clear:both;" /><div id="Searchresult">search comments... </div>';
echo '<div id="hiddenresult" style="display:none;">';
echo $body;
echo '</div>';
