<?php

$disabled = 'disabled';
//if (isadminloggedin()) $disabled = '';

$anonymous = $vars['entity']->anonymous;
echo elgg_echo('anonymous_comments:anonymous');
echo elgg_view('input/text', array(
    'internalname' 	=> 'params[anonymous]',
    'value' 	=> $anonymous,
    'disabled'=>$disabled
  ));


// Facyla : make this configurable
$anonymous = $vars['entity']->notify;
echo elgg_echo('anonymous_comments:notify');
echo elgg_view('input/text', array(
    'internalname' 	=> 'params[notify]',
    'value' 	=> $vars['entity']->notify,
  ));


// disabled formedit
$yn_options_f = array(elgg_echo('settings:yes')=>'yes', elgg_echo('settings:no')=>'no');
echo elgg_echo('anonymous_comments:disableform').'<br />';
$comments_formedit_disabled = $vars['entity']->comments_formedit_disabled;
echo elgg_view('input/radio', array('value'=>$comments_formedit_disabled, 'internalname'=>'params[comments_formedit_disabled]', 'options'=>$yn_options_f));

// disabled global
$yn_options = array(elgg_echo('settings:yes')=>'yes', elgg_echo('settings:no')=>'no');
echo elgg_echo('anonymous_comments:disableanocomments').'<br />';
$comments_disabled = $vars['entity']->comments_disabled;
echo elgg_view('input/radio', array('value'=>$comments_disabled, 'internalname'=>'params[comments_disabled]', 'options'=>$yn_options));


// une IP par ligne
$blackbloc = $vars['entity']->blackbloc;
echo elgg_echo('anonymous_comments:blockip');
echo elgg_view('input/longtext', array(
'internalname' 	=> 'params[blackbloc]',
'value' 	=> $blackbloc
));