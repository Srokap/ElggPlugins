<?php

$opencomments   = find_plugin_settings('anonymous_comments');

if (generic_comment_anonymous($vars['annotation']->owner_guid)) {
    $owner = "anonymous";
} else {
    $owner = get_user($vars['annotation']->owner_guid);
}

if ($opencomments->comments_disabled == 'yes' AND $owner == "anonymous") {
    // rien
} else {


    ?>

<div class="generic_comment">
        <?php   if ($owner !="anonymous") {  ?>
    <div class="generic_comment_icon">
                <?php
                echo elgg_view("profile/icon",
                array(
                'entity' => $owner,
                'size' => 'small'));
                ?>
    </div>
            <?php
        }
        ?>

    <div class="generic_comment_details">
            <?php
            $annotation = $vars['annotation']->value;
            if ($owner =="anonymous") {
                $annotations = generic_comment_anonymous_content($annotation);
                $annotation  = $annotations[0];
                $metadata    = $annotations[1];
            }
            echo elgg_view("output/longtext",array("value" => $annotation));
            ?>

        <p class="generic_comment_owner">
                <?php
                if ($owner !="anonymous") {
                    echo '<a href="'.$owner->getURL().'">'.$owner->name.'</a> ';
                }else {
                    echo $metadata[0].' (invité) ';
                }
                echo friendly_time($vars['annotation']->time_created);
                ?>
        </p>

            <?php if ($vars['annotation']->canEdit()) { ?>
        <p>
                    <?php

                    echo elgg_view("output/confirmlink",array(
                    'href' => $vars['url'] . "action/comments/delete?annotation_id=" . $vars['annotation']->id,
                    'text' => elgg_echo('delete'),
                    'confirm' => elgg_echo('deleteconfirm'),
                    ));

                    ?>
        </p>

                <?php
            }
            ?>
    </div>
</div>


    <?php

}

?>