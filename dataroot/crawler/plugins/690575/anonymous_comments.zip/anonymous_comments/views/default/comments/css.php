<?php

?>


#commentAnonymous label.error {
	/* remove the next line when you have trouble in IE6 with labels in list */
	color: red;
	font-style: italic;
        font-size:10px;
}


