<?php

/**
 * anonymous Comments Plugin list.php
 *
 * @package anonymous Comments
 * @license klermor
 * @author Yann Sallou (klermor)
 * @copyright Yann Sallou 2010
 * @link http://carnets.parisdescartes.fr/
 **/

// Load engine and restrict to admins

require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

admin_gatekeeper();

// Set context
set_context('admin');

extend_view('metatags',	'comments/metatags');

$limit  = (int)get_input('limit');
if (empty($limit)) { $limit = 1000;}
$offset = (int)get_input('offset');

$nb_annotations = count_annotations(0, '', '', 'generic_comment');

// klermor 20101026
if ($limit < $nb_annotations ) {
	$nb_annotations = $limit;
}

//get_annotations($entity_guid = 0, $entity_type = "", $entity_subtype = "", $name = "", $value = "", $owner_guid = 0, $limit = 10, $offset = 0, $order_by = "asc", $timelower = 0, $timeupper = 0)
if (is_plugin_enabled('multisite') && function_exists('get_annotations_multisite')) {
  $annotations    = get_annotations_multisite(0, "","", "generic_comment","", 0 , $nb_annotations, $offset, 'desc');
} else {
  $annotations    = get_annotations(0, "","", "generic_comment","", 0 , $nb_annotations, $offset, 'desc');
}
if (empty($annotations)) $annotations    = get_annotations(0, "","", "generic_comment","", 0 , $nb_annotations, $offset, 'desc'); // Facyla : Fallback générique si on modère depuis une autre communauté

$title  = elgg_view_title( elgg_echo('comments:list') );
$list   = elgg_view('comments/list', array('annotations' => $annotations) );
$body   = elgg_view_layout('two_column_left_sidebar','', $title . $list);

// Display page
page_draw( elgg_echo('comments:list'), $body );

