<?php

	/**
	 * Elgg Dailymotion widget
	 * This plugin allows users to add Dailymotion boxes to their profile
	 * 
	 * @package ElggDailymotion
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Quentin N <quentin@nichini.fr>
	 * @copyright Quentin N 2008
	 * @link http://www.elgg.com/
	 */
	
		function dailymotion_init() {
    		
			// Load system configuration
				global $CONFIG;
				
			// Load the language file
				register_translations($CONFIG->pluginspath . "dailymotion/languages/");
							
    		//add a widget
			    add_widget_type('dailymotion',"Dailymotion","Dailymotion widget");
			
		}
		
		register_elgg_event_handler('init','system','dailymotion_init');

?>