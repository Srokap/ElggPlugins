<?php

	$french = array(
	
		/**
		 * dailymotion widget details
		 */
		
		'dailymotion:notset' => 'Aucune vid&eacute;o ajout&eacute;e',
		'dailymotion:title' => 'Titre de la vid&eacute;o',
		'dailymotion:text' => 'Code &agrave; implanter',
		
		
		 /**
	     * dailymotion widget river
	     **/
	        
	        //generic terms to use
	        'dailymotion:river:created' => "%s a ajout&eacute; le Widget Dailymotion.",
	        'dailymotion:river:updated' => "%s a mis &agrave; jour son widget Dailymotion.",
	        'dailymotion:river:delete' => "%s a enlev&eacute; son widget Dailymotion.",
	        
		
	);
					
	add_translation("fr",$french);

?>