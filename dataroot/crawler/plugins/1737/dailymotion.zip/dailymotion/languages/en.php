<?php

	$english = array(
	
		/**
		 * dailymotion widget details
		 */
		
	
		'dailymotion:notset' => 'No video has been added',
		'dailymotion:title' => 'Video title',
		'dailymotion:text' => 'dailymotion embed code',
		
		 /**
	     * dailymotion widget river
	     **/
	        
	        //generic terms to use
	        'dailymotion:river:created' => "%s added the Dailymotion widget.",
	        'dailymotion:river:updated' => "%s updated the Dailymotion widget.",
	        'dailymotion:river:delete' => "%s removed the Dailymotion widget.",      
		
	);
					
	add_translation("en",$english);

?>