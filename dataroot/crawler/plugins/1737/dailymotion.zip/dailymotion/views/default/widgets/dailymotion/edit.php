<?php

/**
	 * Elgg Dailymotion widget
	 * This plugin allows users to add Dailymotion boxes to their profile
	 * 
	 * @package ElggDailymotion
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Quentin N <quentin@nichini.fr>
	 * @copyright Quentin N 2008
	 * @link http://www.elgg.com/
	 */

?>
	<p>
		<?php echo elgg_echo("dailymotion:title"); ?><br />
		<input type="text" name="params[title]" value="<?php echo htmlentities($vars['entity']->title); ?>" />	
		<br /><?php echo elgg_echo("dailymotion:text"); ?><br />
		<textarea name="params[embed]"><?php echo htmlentities($vars['entity']->embed); ?></textarea>
	
	</p>