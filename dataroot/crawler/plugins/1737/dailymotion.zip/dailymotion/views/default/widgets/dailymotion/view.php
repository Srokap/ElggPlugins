<?php
    
/**
	 * Elgg Dailymotion widget
	 * This plugin allows users to add Dailymotion boxes to their profile
	 * 
	 * @package ElggDailymotion
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Quentin N <quentin@nichini.fr>
	 * @copyright Quentin N 2008
	 * @link http://www.elgg.com/
	 */
	 
	 //some required params
	 
	 $title = $vars['entity']->title;
	 $embed = $vars['entity']->embed;
	 
    // if the dailymotion username is empty, then do not show
    if($embed){
	 
?>
<style type="text/css">

.dailymotion_widget {
    background:#000;
}

.dailymotion_widget h2 {
    font-size:14px;
    margin:0 0 10px 0;
    padding:3px;
    color:#fff;
}
.dailymotion_embed object, embed{
    width:280px;
    height:210px;
}
</style>
<div class="dailymotion_widget">

<?php
    echo "<h2>" . $title . "</h2>";
    echo "<div class=\"dailymotion_embed\"><p>" . $embed . "</p></div>";
?>

</div>
<?php 
    } else {
        
      echo "<p>" . elgg_echo("dailymotion:notset") . ".</p>";
      
  }
?>