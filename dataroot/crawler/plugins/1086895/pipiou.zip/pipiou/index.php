<?php

//Jeguit pipiou 2012 Plugin.
	 
	 	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	 
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}
	
		$area2 .= elgg_view("pipiou/start"); 
		page_draw(elgg_echo('pipiou'),elgg_view_layout($area1, $area2));
	
?>