<?php
		function pipiou_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('pipiou'), $CONFIG->wwwroot . "mod/pipiou");
		}
		
	register_elgg_event_handler('init','system','pipiou_init');
	// Shares widget

?>