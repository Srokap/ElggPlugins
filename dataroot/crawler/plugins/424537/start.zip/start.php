<?php 

	require_once(dirname(__FILE__) . "/lib/functions.php");
	
	function translation_editor_init(){
		global $CONFIG;
		
		extend_view("css", "translation_editor/css");
		// Extend context menu with admin links
		if (isadminloggedin()){
   			 extend_view('profile/menu/adminlinks','translation_editor/adminlinks');
		}
		
		if(translation_editor_is_translation_editor(get_loggedin_userid())){
			register_page_handler('translation_editor', 'translation_editor_page_handler');
			
			if(get_plugin_setting("show_in_tools", "translation_editor") != "no"){
				add_menu(elgg_echo("translation_editor:menu:title"), $CONFIG->wwwroot . "pg/translation_editor/");
			}
		}
	}
	
	function translation_editor_pagesetup(){
		global $CONFIG;
		
		if(get_context() == "admin" && isadminloggedin()){
			add_submenu_item(elgg_echo("translation_editor:menu:title"), $CONFIG->wwwroot . "pg/translation_editor/");
		}
	}
	
	function translation_editor_page_handler($page){
		global $CONFIG;
		
		if(!empty($page[0])){
			set_input("current_language", $page[0]);
		} else {
			$current_language = get_current_language();
			forward($CONFIG->wwwroot . "pg/translation_editor/" . $current_language);
		}
		
		if(!empty($page[1])){
			set_input("plugin", $page[1]);
		}
		
		include(dirname(__FILE__) . "/index.php");
	}
	
	function translation_editor_plugins_boot_event(){
		translation_editor_load_translations();
	}
	
	// Plugin init
	register_elgg_event_handler('plugins_boot', 'system', 'translation_editor_plugins_boot_event');
	register_elgg_event_handler('init', 'system', 'translation_editor_init');
	register_elgg_event_handler('pagesetup','system','translation_editor_pagesetup');
	
	// Register actions
	register_action("translation_editor/translate", false, $CONFIG->pluginspath . "translation_editor/actions/translate.php");
	register_action("translation_editor/merge", false, $CONFIG->pluginspath . "translation_editor/actions/merge.php");
	register_action("translation_editor/make_translation_editor", false, $CONFIG->pluginspath . "translation_editor/actions/make_translation_editor.php", true);
	register_action("translation_editor/unmake_translation_editor", false, $CONFIG->pluginspath . "translation_editor/actions/unmake_translation_editor.php", true);
	
?>