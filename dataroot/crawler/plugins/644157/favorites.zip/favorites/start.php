<?php

/**
 * Elgg Favorites plugin
 *
 * @package ElggFavorites
 */

// Favorites initialisation function
function favorites_init() {

	// Grab the config global
	global $CONFIG;

	//add a tools menu option
	if (isloggedin()) {
		add_menu(elgg_echo('favorites'), $CONFIG->wwwroot . "pg/favorites/owner/" . $_SESSION['user']->username);

		// add "favorite this" to owner block
		elgg_extend_view('owner_block/extend', 'favorites/owner_block');
	}

	// Register a page handler, so we can have nice URLs
	register_page_handler('favorites','favorites_page_handler');

	// Add our CSS
	elgg_extend_view('css','favorites/css');

	// Register granular notification for this type
	if (is_callable('register_notification_object')) {
		register_notification_object('object', 'favorites', elgg_echo('favorites:new'));
	}

	// Listen to notification events and supply a more useful message
	register_plugin_hook('notify:entity:message', 'object', 'favorites_notify_message');

	// Register a URL handler for shared items
	register_entity_url_handler('favorite_url','object','favorites');

	// Shares widget
	add_widget_type('favorites',elgg_echo("favorites"),elgg_echo("favorites:widget:description"));

	// Register entity type
	register_entity_type('object','favorites');

	
}

/**
 * Sidebar menu for favorites
 *
 */
function favorites_pagesetup() {
	global $CONFIG;

	$page_owner = page_owner_entity();

	//add submenu options
	if (get_context() == "favorites") {

		if (isloggedin()) {
			// link to add favorite form
			if ($page_owner instanceof ElggGroup) {
				if ($page_owner->isMember(get_loggedin_user())) {
				add_submenu_item(elgg_echo('favorites:add'), $CONFIG->wwwroot."pg/favorites/add/" . $page_owner->username);
			}
			} else	{
				add_submenu_item(elgg_echo('favorites:add'), $CONFIG->wwwroot."pg/favorites/add/" . $_SESSION['user']->username);
				add_submenu_item(elgg_echo('favorites:inbox'),$CONFIG->wwwroot."pg/favorites/inbox/" . $_SESSION['user']->username);
			}
			if (page_owner()) {
				add_submenu_item(sprintf(elgg_echo('favorites:read'), $page_owner->name),$CONFIG->wwwroot."pg/favorites/owner/" . $page_owner->username);
			}
		}

		if (!$page_owner instanceof ElggGroup) {
			add_submenu_item(elgg_echo('favorites:everyone'),$CONFIG->wwwroot."pg/favorites/all/");
		}
		
		

	}

	
}

/**
 * Favorites page handler; allows the use of fancy URLs
 *
 * @param array $page From the page_handler function
 * @return true|false Depending on success
 */
function favorites_page_handler($page) {

		
		// user usernames
	$user = get_user_by_username($page[0]);
	if ($user) {
		favorites_url_forwarder($page);
	}

	switch ($page[0]) {
		case "read":
			set_input('guid', $page[1]);
			require(dirname(dirname(dirname(__FILE__))) . "/entities/index.php");
			break;
		case "friends":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/friends.php");
			break;
		case "all":
			include(dirname(__FILE__) . "/everyone.php");
			break;
		case "inbox":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/inbox.php");
			break;
		case "owner":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/index.php");
			break;
		case "add":
			set_input('username', $page[1]);
			include(dirname(__FILE__) . "/add.php");
			break;
		case "edit":
			set_input('favorite', $page[1]);
			include(dirname(__FILE__) . "/add.php");
			break;
		default:
			return false;
	}

	return true;
}

/**
 * Forward to the new style of URLs
 *
 * @param string $page
 */
function favorites_url_forwarder($page) {
	global $CONFIG;

	if (!isset($page[1])) {
		$page[1] = 'items';
	}

	switch ($page[1]) {
		case "read":
			$url = "{$CONFIG->wwwroot}pg/favorites/read/{$page[2]}/{$page[3]}";
			break;
		case "inbox":
			$url = "{$CONFIG->wwwroot}pg/favorites/inbox/{$page[0]}/";
			break;
		case "friends":
			$url = "{$CONFIG->wwwroot}pg/favorites/friends/{$page[0]}/";
			break;
		case "add":
			$url = "{$CONFIG->wwwroot}pg/favorites/add/{$page[0]}/";
			break;
		case "items":
			$url = "{$CONFIG->wwwroot}pg/favorites/owner/{$page[0]}/";
			break;
	}

	//register_error(elgg_echo("changefavorite"));
	forward($url);
}

/**
 * Populates the ->getUrl() method for favorited objects
 *
 * @param ElggEntity $entity The favorited object
 * @return string favorited item URL
 */
function favorite_url($entity) {

	global $CONFIG;
	$title = $entity->title;
	$title = elgg_get_friendly_title($title);
	return $CONFIG->url . "pg/favorites/read/" . $entity->getGUID() . "/" . $title;
}

/**
 * Returns a more meaningful message
 *
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $returnvalue
 * @param unknown_type $params
 */
function favorites_notify_message($hook, $entity_type, $returnvalue, $params) {
	$entity = $params['entity'];
	$to_entity = $params['to_entity'];
	$method = $params['method'];
	if (($entity instanceof ElggEntity) && ($entity->getSubtype() == 'favorites')) {
		$descr = $entity->description;
		$title = $entity->title;
		global $CONFIG;
		$url = $CONFIG->wwwroot . "pg/view/" . $entity->guid;
		if ($method == 'sms') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("favorites:via") . ': ' . $url . ' (' . $title . ')';
		}
		if ($method == 'email') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("favorites:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
		}
		if ($method == 'web') {
			$owner = $entity->getOwnerEntity();
			return $owner->name . ' ' . elgg_echo("favorites:via") . ': ' . $title . "\n\n" . $descr . "\n\n" . $entity->getURL();
		}

	}
	return null;
}


// Make sure the initialisation function is called on initialisation
register_elgg_event_handler('init','system','favorites_init');
register_elgg_event_handler('pagesetup','system','favorites_pagesetup');

// Register actions
global $CONFIG;
register_action('favorites/add',false,$CONFIG->pluginspath . "favorites/actions/add.php");
register_action('favorites/delete',false,$CONFIG->pluginspath . "favorites/actions/delete.php");

?>