<?php

$label = elgg_echo('favorites:this');
$user = get_loggedin_user();
$url = "'" . $vars['url'] . "pg/favorites/add/{$user->username}?address='+encodeURIComponent(location.href)+'&title='+encodeURIComponent(document.title)";

?>
<div id="owner_block_favorite_this">
<a href="javascript:location.href=<?php echo $url; ?>"><?php echo $label ?></a>
</div>
