<?php

	/**
	 * Elgg favorite view
	 *
	 * @package ElggFavorites
	 */

	$owner = $vars['entity']->getOwnerEntity();
	$friendlytime = elgg_view_friendly_time($vars['entity']->time_created);
	$address = $vars['entity']->address;

	// you used to be able to add without titles, which created unclickable favorites
	// putting a fake title in so you can click on it.
	if (!$title = $vars['entity']->title) {
		$title = elgg_echo('favorites:no_title');
	}

	$a_tag_visit = filter_tags("<a href=\"{$address}\">" . elgg_echo('favorites:visit') . "</a>");
	$a_tag_title = filter_tags("<a href=\"{$address}\">$title</a>");

	if (get_context() == "search") {

		if (get_input('search_viewtype') == "gallery") {

			$parsed_url = parse_url($address);
			$faviconurl = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/favicon.ico";

			$info = "<p class=\"shares_gallery_title\">". elgg_echo("favorites:visit") . ": <a href=\"{$vars['entity']->address()}\">$title</a> (<a href=\"{$vars['entity']->getURL()}\">".elgg_echo('favorites:shared')."</a>)</p>";
			$info .= "<p class=\"shares_gallery_user\">By: <a href=\"{$vars['url']}pg/favorites/owner/{$owner->username}\">{$owner->name}</a> <span class=\"shared_timestamp\">{$friendlytime}</span></p>";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= "<p class=\"shares_gallery_comments\"><a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a></p>";

			//display
			echo "<div class=\"share_gallery_view\">";
			echo "<div class=\"share_gallery_info\">" . $info . "</div>";
			echo "</div>";


		} else {

			$parsed_url = parse_url($address);
			$faviconurl = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/favicon.ico";
			if (@file_exists($faviconurl)) {
				$icon = "<img src=\"{$faviconurl}\" />";
			} else {
				$icon = elgg_view(
					"profile/icon", array(
										'entity' => $owner,
										'size' => 'small',
									)
				);
			}

			$info = "<p class=\"shares_gallery_title\">". elgg_echo("favorites:visit") .": <a href=\"{$vars['entity']->address}\">{$title}</a> (<a href=\"{$vars['entity']->getURL()}\">".elgg_echo('favorites:shared')."</a>)</p>";
			$info .= "<p class=\"owner_timestamp\"><a href=\"{$vars['url']}pg/favorites/owner/{$owner->username}\">{$owner->name}</a> {$friendlytime}";
			$numcomments = elgg_count_comments($vars['entity']);
			if ($numcomments)
				$info .= ", <a href=\"{$vars['entity']->getURL()}\">".sprintf(elgg_echo("comments")). " (" . $numcomments . ")</a>";
			$info .= "</p>";
			echo elgg_view_listing($icon, $info);

		}

	} else {

?>
	<?php echo elgg_view_title(elgg_echo('favorites:shareditem'), false); ?>
	<div class="contentWrapper">
	<div class="sharing_item">

		<div class="sharing_item_title">
			<h3>
				<?php echo $a_tag_title; ?>
			</h3>
		</div>
		<div class="sharing_item_owner">
			<p>
				<b><a href="<?php echo $vars['url']; ?>pg/favorites/owner/<?php echo $owner->username; ?>"><?php echo $owner->name; ?></a></b>
				<?php echo $friendlytime; ?>
			</p>
		</div>
	
<?php

	$tags = $vars['entity']->tags;
	if (!empty($tags)) {

?>
		<div class="sharing_item_tags">
			<p>
				<?php echo elgg_view('output/tags',array('value' => $vars['entity']->tags)); ?>
			</p>
		</div>
<?php

	}

?>
		<div class="sharing_item_address">
			<p>
				<?php echo $a_tag_visit; ?>
			
		<?php

			if ($vars['entity']->canEdit()) {

		?>
		
				<a href="<?php echo $vars['url']; ?>pg/favorites/edit/<?php echo $vars['entity']->getGUID(); ?>"><?php echo elgg_echo('edit'); ?></a> &nbsp;
				<?php
						echo elgg_view('output/confirmlink',array(

							'href' => $vars['url'] . "action/favorites/delete?favorite_guid=" . $vars['entity']->getGUID(),
							'text' => elgg_echo("delete"),
							'confirm' => elgg_echo("favorites:delete:confirm"),

						));
					?>
			</p>
		</div>
		<?php

			}

		?>

	</div>
	</div>


<?php

	}

?>