<?php

	$english = array(

		/**
		 * Menu items and titles
		 */

			'favorites' => "Favorites",
			'favorites:add' => "Add favorite",
			'favorites:read' => "%s's favorited items",
			'favorites:friends' => "Friends' favorites",
			'favorites:everyone' => "All site favorites",
			'favorites:this' => "Favorite this",
			'favorites:this:group' => "Favorite in %s",
			'favorites:inbox' => "Favorites inbox",
			'favorites:morefavorites' => "More favorites",
			'favorites:more' => "More",
			'favorites:shareditem' => "Favorited item",
			'favorites:with' => "Share with",
			'favorites:new' => "A new favorited item",
			'favorites:via' => "via favorites",
			'favorites:address' => "Address of the resource to favorite",

			'favorites:delete:confirm' => "Are you sure you want to delete this resource?",

			'favorites:numbertodisplay' => 'Number of favorited items to display',

			'favorites:shared' => "&lowast;",
			'favorites:visit' => "Visit resource",
			'favorites:recent' => "Recent favorites",

			'favorites:river:created' => '%s favorited',
			'favorites:river:annotate' => 'a comment on this favorited item',
			'favorites:river:item' => 'an item',

			'item:object:favorites' => 'Favorited items',

			'favorites:more' => 'More favorites',


		/**
		 * More text
		 */

			'favorites:widget:description' =>
					"This widget displays your latest favorites.",

			'favorites:no_title' => 'No title',

		/**
		 * Status messages
		 */

			'favorites:save:success' => "Your item was successfully favorited.",
			'favorites:delete:success' => "Your favorited item was successfully deleted.",

		/**
		 * Error messages
		 */

			'favorites:save:failed' => "Your favorited item could not be saved. Make sure you've entered a title and address and then try again.",
			'favorites:delete:failed' => "Your favorited item could not be deleted. Please try again.",


	);

	add_translation("en",$english);

?>