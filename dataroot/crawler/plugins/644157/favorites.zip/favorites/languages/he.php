<?php

	$hebrew = array(
	
		/**
		 * Menu items and titles
		 */
	
			'favorites' => "מועדפים",
			'favorites:add' => "הוספת מועדף",
			'favorites:read' => "המועדפים של %s",
			'favorites:friends' => "המועדפים של חבריי",
			'favorites:everyone' => "כלל המועדפים באתר",
			'favorites:this' => "הוסף למועדפים שלי",
			'favorites:this:group' => "מועדפים של %s",
			'favorites:inbox' => "מועדפים ששלחו לי חבריי",
			'favorites:more' => "עוד",
			'favorites:shareditem' => "פריט מועדפים",
			'favorites:with' => "שלח ל",
			'favorites:new' => "מועדף חדש",
			'favorites:via' => "באמצעות מועדפים",
			'favorites:address' => "כתובת המועדף",
	
			'favorites:delete:confirm' => "למחוק מועדף זה?",
	
			'favorites:numbertodisplay' => 'מס. המועדפים להציג',
	
			'favorites:shared' => "&lowast;",
			'favorites:visit' => "גש למועדף",
			'favorites:recent' => "מועדפים חדשים",
	
			'favorites:river:created' => "%s הוסיף/ה מועדף",
			'favorites:river:annotate' => "תגובה למועדף זה",
			'favorites:river:item' => "פריט",
			'favorites:more' => "צפייה בעוד",
			'item:object:favorites' => 'מועדפים מומלצים',
	
				
	
		/**
		 * More text
		 */
		    
		    'favorites:widget:description' => 
		            "ווידגט זה נועד לדף הווידגטים האישי שלך וייציג את המועדפים אשר שלחו לך חבריך.",
	
			'favorites:no_title' => "ללא כותרת",
	
		/**
		 * Status messages
		 */
	
			'favorites:save:success' => "הפריט נוסף בהצלחה למועדפים.",
			'favorites:delete:success' => "הפריט נמחק בהצלחה ממועדפים.",
	
		/**
		 * Error messages
		 */
	
			'favorites:save:failed' => "לא הצלחנו לשמור את המועדף, אנא נסה שוב.",
			'favorites:delete:failed' => "לא הצלחנו למחוק את המועדף אנא נסה שוב.",
	
	
	);
					
	add_translation("he",$hebrew);

?>