<?php

	/**
	 * Elgg favorites delete action
	 * 
	 * @package ElggFavorites
	 */

		$guid = get_input('favorite_guid',0);
		if ($entity = get_entity($guid)) {

			$container = get_entity($entity->container_guid);
			if ($entity->canEdit()) {
				
				if ($entity->delete()) {
					
					system_message(elgg_echo("favorites:delete:success"));
					forward("pg/favorites/owner/$container->username/");
					
				}
				
			}
			
		}
		
		register_error(elgg_echo("favorites:delete:failed"));
		forward(REFERER);

?>