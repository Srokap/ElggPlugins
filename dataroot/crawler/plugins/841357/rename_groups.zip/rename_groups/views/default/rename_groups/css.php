
.rename_groups_language_edit {
	padding: 20px;
	margin: 10px 30px;
	background-color: white;
	border: 1px solid #cccccc;
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;
}

.rename_groups_language_edit input[type=text] {
	display: inline;
	width: 200px;
}

.rename_groups_language_edit table {
	margin-top: 10px;
}

.rename_groups_language_edit table tr td {
	padding: 0 10px;
}