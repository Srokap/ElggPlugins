<?php
/*******************************************************************************
 * registration page
 *
 * @author Fusion
 ******************************************************************************/
 ?>
 <!-- top box -->
 <div id="reg_top">
 <?php if (isset($vars['area1'])) echo $vars['area1']; ?>
 </div><!--// reg_top -->
 
 <!-- login/registration boxes -->
 <div id="reg_content_boxes">
 
 <div id="reg_loginbox">
 <?php if (isset($vars['area2'])) echo $vars['area2']; ?>
 </div>
 
 <div id="reg_registerbox">
 <?php if (isset($vars['area3'])) echo $vars['area3']; ?>
 </div>
 
 <div class="clearfloat"></div>
 
 </div><!--// reg_content_boxes -->