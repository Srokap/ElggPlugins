<?php
/*******************************************************************************
 * registration page
 *
 * @author Fusion
 ******************************************************************************/
 ?>
 
 <div id="reg_box">
 <p><center><b>Attention! To create a login account you must be a bonafide business related to architectural coatings!!<br />
 ALL OTHER'S WILL BE DELETED!!!</b></center></p>
 </div>