<div id="reg_box">
If you already have an account with mypaintersplace.com, you may log in below.
</div>