<div id="reg_box">
Instructions
</div>