#reg_top{
   width:100%;
}

#reg_content_boxes {
   margin-top:10px;
}

#reg_loginbox {
    width:465px;
    float:left;
}
#login-box {
    border:1px solid #cccccc;
    background:#ffffff;
    width:465px;
}
#login-box form{
    width:300px;
    margin:auto;
    padding:10px 70px 0 70px;
}
  
#reg_registerbox {
    width:465px;
    float:right;
}

#register-box {
    width:445px;
    background:#ffffff;
    border: 1px solid #cccccc;
    -webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}
#reg_inside {
    padding:0 0 0 30px;
}

#reg_box {
    border:1px solid #cccccc;
    margin-bottom:10px;
    padding:10px;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}