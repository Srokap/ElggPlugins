<?php
/*******************************************************************************
 * registration page
 *
 * @author Fusion
 ******************************************************************************/

	function custom_reg_init()
	{
		global $CONFIG;
		
        // Page handler
		register_page_handler('registration','custom_reg_page_handler');

        // extend some views
		extend_view('css','custom_reg/css');

        return true;
	}
	
	function custom_reg_page_handler($page)
	{
		global $CONFIG;
			
		@include(dirname(__FILE__) . "/index.php");
		return true;
	}
	function custom_reg_registration() {
			
			include(dirname(__FILE__) . '/index.php');
			
		}

    register_elgg_event_handler('init', 'system', 'custom_reg_init');
?>