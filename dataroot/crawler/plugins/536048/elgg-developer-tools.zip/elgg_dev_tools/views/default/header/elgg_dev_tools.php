
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/elgg_dev_tools/includes/jsTree/tree_component.js"></script>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/elgg_dev_tools/includes/jsTree/css.js"></script>
<link rel="stylesheet" href="<?php echo $vars['url']; ?>mod/elgg_dev_tools/includes/jsTree/tree_component.css" type="text/css" />
