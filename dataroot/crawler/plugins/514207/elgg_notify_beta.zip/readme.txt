*** THIS IS A PLUGIN BY MARK HARDING ***
****** www.marksmusiconline.co.uk ******

This plugin provides the ability for plugins to send instant notification to users, similar to facebooks system. If you used the previous version then please remove the old API. 


To get started add drag the two folders into your mod folder. Make sure that the notifications plugin is right at the bottom of the plugins list