
<script>
$(document).ready(function() {
$("#notify").hide();						   
$("#notify_link").click(
			
		function () { $("#notify").toggle($('#notify').css('display') == 'none');
				$('#loader').html('<?php echo elgg_view('ajax/loader',array('slashes' => true)); ?>');	
		$("#result").load("<?php echo $vars['url']; ?>mod/notifications/ajax/data.php",function(){
	                    $('#loader').empty(); // remove the loading gif
	                    
	                });	   
		});
				   
$("#notify_link").toggle(
     function () {
    $(this).addClass("selected");
  },
  function () {
    $(this).removeClass("selected");
  } );

	 $("#count").load("<?php echo $vars['url']; ?>mod/notifications/ajax/livenum.php");
   var refreshId = setInterval(function() {
      $("#count").load("<?php echo $vars['url']; ?>mod/notifications/ajax/livenum.php");
   }, 9000);

});
</script>

<a href="#" id="notify_link">&nbsp;</a><span id="count"></span>


<div id="notify">
<h4>Notifications</h4>
<div id="loader"></div>
    <div id="result" style="width:100%; height:100%;"></div>
    <div class="seeall"><a href="<?php echo $vars['url']; ?>mod/notifications/all.php">See All Notifications</a></div>
</div>