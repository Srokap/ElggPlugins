<?php
	/**
	 * Elgg notify
	 * 
	 * @package Elgg_Notify
	 * @author Mark Harding
	 * @copyright Mark Harding 2010
	 * @link http://marksmusiconline.co.uk/
	 */

	global $CONFIG;
	
	$notify = $vars['entity'];
	
	$notify_guid = $notify->getGUID();
	
	$friendlytime = friendly_time($vars['entity']->time_created);

	$desc = $notify->desc;
	$owner = $vars['entity']->getOwnerEntity();
	$action_user = get_entity($notify->action_user);

$notify->readYet = 1;
$notify->save();
	
	$url = $vars['site']->url;
echo "<div class=\"notifications_content\">";
echo ("<a href=\"$url/pg/profile/$action_user->username\">" . $action_user->name . "</a> ". $desc . "<span class=\"time\">" .$friendlytime ."</span>");
echo "</div>";

	?>


<?php

?>