<?php

	/**
	 * Elgg notifications CSS
	 * 
	 * @package notifications
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.org/
	 */

?>

#notificationstable td.namefield {
	width:250px;
	text-align: left;
	vertical-align: middle;
}
#notificationstable td.namefield p {
	margin:0;
	vertical-align: middle;
	line-height: 1.1em;
	padding:5px 0 5px 0;
}
#notificationstable td.namefield img {
	padding:6px 10px 6px 3px;
	float:left;
}
#notificationstable td.namefield p.namefieldlink {
	margin:9px 0 0 0;
}
#notificationstable td.emailtogglefield,
#notificationstable td.smstogglefield {
	width:50px;
	text-align: center;
	vertical-align: middle;
}
#notificationstable td.spacercolumn {
	width:30px;
}
#notificationstable td {
	border-bottom: 1px solid silver;
}
#notificationstable td.emailtogglefield input {
	margin-right:36px;
	margin-top:5px;
}
#notificationstable td.emailtogglefield a {
	width:46px;
	height:24px;
	cursor: pointer;
	display: block;
	outline: none;
}
#notificationstable td.emailtogglefield a.emailtoggleOff {
	background: url(<?php echo $vars['url']; ?>mod/notifications/graphics/icon_notifications_email.gif) no-repeat right 2px;
}
#notificationstable td.emailtogglefield a.emailtoggleOn {
	background: url(<?php echo $vars['url']; ?>mod/notifications/graphics/icon_notifications_email.gif) no-repeat right -36px;
}

.notification_collections,
.notification_personal {
	margin-bottom: 25px;
}

.settings_form .friendsPicker_container h3 {
	color:#999999;
	font-size:3em;
	margin:0 0 20px;
	text-align:left;
	background: none;
	border-bottom: none;
}
a#notify_link{
	background: url(<?php echo $vars['url']; ?>mod/notifications/graphics/icon_notifications_email.png) no-repeat right 0px;
   	padding:0 0 3px 16px;
	margin:0 2px 0 2px;
	cursor:pointer;    
}
a#notify_link.selected{
	background:url(<?php echo $vars['url']; ?>mod/notifications/graphics/icon_notifications_email.png) no-repeat right -18px;
   	padding:0 0 4px 16px;
	margin:0 2px 0 2px;
	cursor:pointer;    
}
span#count{
	background:url(<?php echo $vars['url']; ?>mod/notifications/graphics/icon_notifications_email.png) no-repeat center -37px;
   	padding:0 4px 1px 3px;
	margin:0px 0 0 -10px;
	cursor:pointer;    
    font-size:10px;
    position:absolute;
}
a#notify_link:hover{
text-decoration:none;
}
#notify{
float:left; 
position:absolute; 
background:#FFF; 
width:450px; 
min-height:100px; 
margin:3px 0 0 43px; 
color:#333;border:#000 1px solid;}
#notify h4{
margin:2px 0 2px 2px;
border-bottom:1px #999 solid;
}
#notify .seeall {
background-color:#D5D9F6;
padding:6px 0 6px 0;
text-align:center;

}
#notify .seeall:hover {
background:#4690d6;
border-top:1px #3349CC solid;
border-bottom:1px #3349CC solid;
text-decoration:none;
color:#FFF;

}
#notify .seeall:hover a {
text-decoration:none;
color:#FFF;
display: block;
}
.notifications_content{
font-size:10px;
margin:0px 2px 0px 2px;
padding:6px 0 6px 0;
}
.notifications_content:hover a{
color:#FFF;
cursor:pointer;
}
.notifications_content:hover{
font-size:10px;
margin:0px 0px 0px 0px;
padding:5px 2px 5px 2px;
background:#4690d6;
border-top:1px #3349CC solid;
border-bottom:1px #3349CC solid;
color:#FFF;
cursor:pointer;
}

.notifications_content span.time{
font-size:8px;
color:#CCC;
padding-left:2px;

}