<?php

	/**
	 * Elgg notifications plugin 
	 * 
	 * @package ElggNotifications
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd/Mark Harding
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/ - http://www.marksmusiconline.co.uk
	 */
	 

	/**
	 * Notification settings page setup function
	 *
	 */

	
				
				
		function notifications_plugin_pagesetup() {
			global $CONFIG;
			if (get_context() == 'settings') {
				add_submenu_item(elgg_echo('notifications:subscriptions:changesettings'), $CONFIG->wwwroot . "mod/notifications/");
				add_submenu_item(elgg_echo('notifications:showall'), $CONFIG->wwwroot . "mod/notifications/all.php");
				if (is_plugin_enabled('groups'))
					add_submenu_item(elgg_echo('notifications:subscriptions:changesettings:groups'), $CONFIG->wwwroot . "mod/notifications/groups.php");
					
			}
		}
		
		function notifications_plugin_init() {
			elgg_extend_view('css','notifications/css');
			 // Extend the elgg topbar
				elgg_extend_view('elgg_topbar/extend','notifications/topbar');
			global $CONFIG;
			
			unregister_notification_handler('site');
			
			register_notification_handler('live', 'live_notify_handler');
			
			// Unset the default user settings hook
			if (isset($CONFIG->hooks['usersettings:save']['user']))
				foreach($CONFIG->hooks['usersettings:save']['user'] as $key => $function) {
					if ($function == 'notification_user_settings_save')
						unset($CONFIG->hooks['usersettings:save']['user'][$key]); 
				}
		}
//The API for notifications
function live_notify_handler(ElggEntity $from, ElggUser $to, $subject, $message, $live, array $params = NULL) {
	global $CONFIG;
	$notify = new ElggObject();
 
$notify->subtype = "notification";
 
	$notify->access_id = 1;
	
	//notify the person who needs to be notified
	$notify->to_id = $to->guid;
	
	//who took the action
$notify->action_user = $from->guid;
	
	//message assigned by developer , eg. 'userx' wrote on your message board, must include html link!
	$notify->desc = $live;
	//set it as not read
	$notify->read = 0;
	
if (!empty($live)) {
	return $notify->save();
} else { register_error("live notifications could not work because the plugin has not been updated"); }
}


	//register_elgg_event_handler('new_notification','system','new_notification',1000);
	
		register_elgg_event_handler('pagesetup','system','notifications_plugin_pagesetup',1000);
		register_elgg_event_handler('init','system','notifications_plugin_init',1000);
		
			// Register entity type
		register_entity_type('object','notification');
	// Register action
		global $CONFIG;
		//unregister_notification_handler($site);
		register_action("comments/add",false,$CONFIG->pluginspath . "notifications/actions/comments/add.php");
		register_action("messageboard/add",false,$CONFIG->pluginspath . "notifications/actions/messageboard/add.php");
		register_action("notificationsettings/reset",false,$CONFIG->pluginspath . "notifications/actions/reset.php");
		register_action("notificationsettings/save",false,$CONFIG->pluginspath . "notifications/actions/save.php");
		register_action("notificationsettings/groupsave",false,$CONFIG->pluginspath . "notifications/actions/groupsave.php");
		
?>