  <?php   // Load Elgg engine will not include plugins
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
	 //Data must me loaded into here so that it can be shown in the notifications drop down
	 
		
		$body = list_entities_from_metadata('to_id',$_SESSION['user']->getGUID(), 'object','notification',0,5,false, false, false);
		// Insert it into the correct canvas layout
		
	echo $body;
//a system needs to be made where read notifications are set to an entity/user as metadata so they do not show
	 ?>
	 