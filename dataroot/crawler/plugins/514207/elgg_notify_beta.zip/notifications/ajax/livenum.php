  <?php   // Load Elgg engine will not include plugins
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
	 //Data must me loaded into here so that it can be shown in the notifications drop down
	 
	$num_notify = elgg_get_entities_from_metadata(array('metadata_name_value_pairs' => array(
		    							'to_id' => $_SESSION['user']->guid,
		    							'read' => '0'), 'types' => 'object', 'subtypes' => 'notification','limit' => 9999));

		
	
	$num_notify_read = elgg_get_entities_from_metadata(array('metadata_name_value_pairs' => array(
		    							'to_id' => $_SESSION['user']->guid,'read' => '0',
		    							'readYet' => '1'), 'types' => 'object', 'subtypes' => 'notification','limit' => 9999));
	
	$result = (count($num_notify) - count($num_notify_read));
	
	if ($result == !0){
		echo $result;
	}
		
//a system needs to be made where read notifications are set to an entity/user as metadata so they do not show
	 ?>
	 