<?php
/* LiangLee Administrator Theme
 * FrameWork for Liang Lee Plugins
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework( LEFW )
 * @subpackage LiangLee Admino
 * @author Liang Lee
 * @copyright 2012, Liang Lee
 * @File lefw_menu.php 
 */
?>
<?php
/*For next release */
$liang_lee_frameworkurl     = "{$CONFIG->url}mod/LiangleeFramework";
$liang_lee_pname     = "LiangLee_Admino";
$le_aop_url     = "{$CONFIG->url}mod/LiangLee_Admino";

$LiangleeFramework_jqonefour = $plugin_base_url."mod/LiangleeFramework/loaders/lefw_jquery-1.4.3.min.js.php";
include $LiangleeFramework_jqonefour
?>

