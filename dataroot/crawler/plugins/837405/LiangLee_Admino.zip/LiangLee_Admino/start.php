<?php
/* LiangLee Administrator Theme Redo
 * FrameWork for Liang Lee Plugins
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework( LEFW )
 * @subpackage LiangLee Admino
 * @author Liang Lee
 * @copyright 2012, Liang Lee
 * @File start.php 
 */
?>
<?php

elgg_register_event_handler('init', 'system', 'LiangLee_Adminoe_init');

function LiangLee_Admino_init() {
	elgg_extend_view ('page/elements/head','Admino/meta');
	$liang_lee_pname     = "'LiangLee_Adminoe";
      $liang_lee_frameworkurl     = "{$CONFIG->url}mod/LiangleeFramework";
}
?>