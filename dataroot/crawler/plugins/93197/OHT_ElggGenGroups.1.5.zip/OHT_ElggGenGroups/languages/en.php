<?php
/*******************************************************************************
 * Elgg Generate Groups Language File
 * 
 * @package OHT
 * @subpackage ElggGenGroups
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/** build new array **/
$english = array(
    /** generics **/
    'OHT_ElggGenGroups:Title'                    => 'Generate Groups for Elgg',
    'OHT_ElggGenGroups:adminlink'                => 'Elgg Gen Groups',
    'OHT_ElggGenGroups:message:successfulupdate' => 'The Groups have been generated successfully.',
        
    /** completed items **/
    'OHT_ElggGenGroups:completedtitle'          =>  'Groups Successfully Generated',
    'OHT_ElggGenGroups:completedexplanation'    =>  'The groups have successfully been generated using this plugin.',
    'OHT_ElggGenGroups:completedsuccessmessage' =>  'Congratulations - the group generation was successful!',

    /** groups not enabled **/
    'OHT_ElggGenGroups:groupsnotenabledtitle'   =>  'Groups Plugin Not Enabled',
    'OHT_ElggGenGroups:groupsnotenabledexplanation' =>  'The Groups plugin is not enabled.  There is really no way to start generating groups without that plugin enabled.  Plus, that would just be silly... Probably go ahead and enable it.',

    /** group info **/
    'OHT_ElggGenGroups:groupinfolegend'         =>  'Group Information',
    'OHT_ElggDevTools:groupinfoexplanation'     =>  'The following options are used to generate the groups.  These options are based on the settings you have enabled for your site.  For example, if you do not have pages enabled, you will not see an option for pages.  The recommended settings are already entered.',

    /** number of groups **/
    'OHT_ElggGenGroups:numberofgroups:question' =>  'Number of Groups to generate?',

    /** group name **/
    'OHT_ElggGenGroups:groupnameprefix:question'    =>  'Prefix of group names?',

    /** generate group icons **/
    'OHT_ElggGenGroups:groupicon:question'      =>  'Generate some group icons?',
    'OHT_ElggGenGroups:groupicon:answer:yes'    =>  'Yes',
    'OHT_ElggGenGroups:groupicon:answer:no'     =>  'No',
    'OHT_ElggGenGroups:groupicon:explanation'   =>  'If you choose yes, some groups still will not have an icon.  Most will.  This is by design.',
    
    /** group membership mixed option answer **/
    'OHT_ElggGenGroups:membership:answer:mixed'     => 'Mixed/Random',

    /** group options based on the copy from the groups plugin **/
    'OHT_ElggGenGroups:group_options:answer:mixed'  =>  'Mixed/Random',

    /** form items **/
    'OHT_ElggGenGroups:formbutton'              =>  'Generate Groups',

    /** errors **/
    'OHT_ElggGenGroups:error:groupsnotenabled'  =>  'Groups plugin is not enabled.', //fun note - probably should never hit this... but JUST in case...

);
                    
add_translation("en",$english);
?>