<?php
/*******************************************************************************
 * Generate Elgg Groups
 *
 * This will generate the groups.  This will error out if any option is incorrect
 * or if we determine that the group plugin is not enabled.  Also, we'll 
 * try to set the timeout settings using this.
 * 
 * Since this is an admin only plugin, the error handling is more rough...
 * 
 * @package OHT
 * @subpackage ElggGenGroups
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

global $CONFIG;

/** make sure admin/action submitted **/
action_gatekeeper();
admin_gatekeeper();

/**
 * very first thing I want to do is make sure the groups plugin is enabled
 */
if (!is_plugin_enabled('groups')) {
    register_error(elgg_echo('OHT_ElggGenGroups:error:groupsnotenabled'));
    forward($_SERVER['HTTP_REFERER']);
}

/**
 * OK good to go - lets try to set our timeout limit to nothing so this may take a while
 */
set_time_limit(0);

/**
 * get all the inputs now
 */
$numberofgroups = (int) get_input('numberofgroups', 15);
$groupicon = (int) get_input('groupicon', 1);
$groupnameprefix = get_input('groupnameprefix', '');
$membership = (int) get_input('membership', 9);

/** start the generation **/

/** load/generate/get info **/
$groupnames = array_map('trim', file($CONFIG->pluginspath . 'OHT_ElggGenGroups/data/groupnames.txt'));
$groupdescriptions = array_map('trim', file($CONFIG->pluginspath . 'OHT_ElggGenGroups/data/groupdescriptions.txt'));

/** there was a note that maybe group accesses will be write access - but so far its not- hence this comment **/
//$groupaccesses = get_write_access_array();
$groupaccesses = array(ACCESS_PUBLIC=>ACCESS_PUBLIC, ACCESS_PRIVATE=>ACCESS_PRIVATE);

$grouptooloptionsvalues = array('yes', 'no');
$groupicons = glob($CONFIG->pluginspath . 'OHT_ElggGenGroups/data/icons/*.jpg');

/** get the users guids into an array **/
$sql = "select guid from {$CONFIG->dbprefix}users_entity";
$usersguids = get_data($sql);
$countusersguids = count($usersguids);

/** start the loop for number of groups **/
for ($count = 0; $count < $numberofgroups; $count++) {

    /** create group **/
    $group = new ElggGroup(); 
    
    /** 
     * add the following group items - some of these we may not have something 
     * to do with if we don't know what they are - so we'll just assign them a value and hope for the best
     */
    foreach($CONFIG->group as $shortname => $valuetype) {
        switch ($shortname) {
            case 'name':
                /** choose a name and prefix it **/
                $groupname = $groupnameprefix . $groupnames[array_rand($groupnames)] . $count;
                $group->name = $groupname;
                break;
                
            case 'description':
                /** choose a description **/
                $group->description = $groupdescriptions[array_rand($groupdescriptions)];
                break;
                
            /** items I care to skip for now - so do nothing **/
            case 'interests':
            case 'website':
                break;
                
            default:
                /** if we dont' know what ti is, call it by its name plus the group number **/
                $group->$shortname = $shortname . $count;
        }
    }    

    /** ok so now some more hardset stuff **/
    switch ($membership) {
        case 2:
            $group->membrship = ACCESS_PUBLIC;
            break;
            
        case 9:
            /** our random **/
            $group->membership = array_rand($groupaccesses);
            break;
            
        default:
            $group->membership = ACCESS_PRIVATE;
    }
    
    // Set access - all groups are public from elgg's point of view.
    $group->access_id = ACCESS_PUBLIC;    
    
    /** copied sort of from the group plugin **/
    // Set group tool options
    if (isset($CONFIG->group_tool_options)) {
        foreach($CONFIG->group_tool_options as $group_option) {
            $group_option_toggle_name = $group_option->name."_enable";
            if ($group_option->default_on) {
                $group_option_default_value = 'yes';
            } else {
                $group_option_default_value = 'no';
            }
            
            $value = get_input($group_option_toggle_name, $group_option_default_value);
            
            /** if its our mixed, grab one of these **/
            if ($value == 'mixed') {
                $value = $grouptooloptionsvalues[array_rand($grouptooloptionsvalues)];
            }
            
            $group->$group_option_toggle_name = get_input($group_option_toggle_name, $group_option_default_value);
        }
    }   

    /** save it now **/
    $group->save();
    
    /** create icons now if they requested - note we'll only create some **/
    if ($groupicon && (rand(1,3) > 1)) {
        /** ok to generate one **/
        
        $prefix = "groups/".$group->guid;
        
        $filehandler = new ElggFile();
        $filehandler->owner_guid = $group->owner_guid;
        $filehandler->setFilename($prefix . ".jpg");
        $filehandler->open("write");
        $filehandler->write(file_get_contents($groupicons[array_rand($groupicons)]));
        $filehandler->close();
        
        $thumbtiny = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),25,25, true);
        $thumbsmall = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),40,40, true);
        $thumbmedium = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),100,100, true);
        $thumblarge = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),200,200, false);
        if ($thumbtiny) {
            
            $thumb = new ElggFile();
            $thumb->owner_guid = $group->owner_guid;
            $thumb->setMimeType('image/jpeg');
            
            $thumb->setFilename($prefix."tiny.jpg");
            $thumb->open("write");
            $thumb->write($thumbtiny);
            $thumb->close();
            
            $thumb->setFilename($prefix."small.jpg");
            $thumb->open("write");
            $thumb->write($thumbsmall);
            $thumb->close();
            
            $thumb->setFilename($prefix."medium.jpg");
            $thumb->open("write");
            $thumb->write($thumbmedium);
            $thumb->close();
            
            $thumb->setFilename($prefix."large.jpg");
            $thumb->open("write");
            $thumb->write($thumblarge);
            $thumb->close();
                
        }
    }

    /** current user is our owner **/
    $user = $_SESSION['user'];
    if (!$group->isMember($user)) $group->join($user); // Creator always a member
    
    /** add some more members **/
    $keystojoin = array_rand($usersguids, rand(1, $countusersguids));
    foreach ($keystojoin as $key) {
        $user = get_user($usersguids[$key]->guid);
        $group->join($user);
    }

}

/**
 * tell them that we've finished updating
 */
set_plugin_setting('groups_generated', 1, 'OHT_ElggGenGroups');
system_message(elgg_echo("OHT_ElggGenGroups:completedsuccessmessage"));
forward($_SERVER['HTTP_REFERER']);