<?php
/*******************************************************************************
 * Generate Groups for Elgg Instances
 * 
 * This is the launching script for the Group Generation
 * 
 * @package OHT
 * @subpackage ElggGenGroups
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/**
 * The Initial Plugin launcher
 * 
 * This launches the dev tools code - as well as grabs additional CSS to extend
 * the view.  This is also the main hook that must be there.
 * 
 * @return boolean launched successfully?
 */
function OHT_ElggGenGroups_init()
{
}

/**
 * Page handler - used for making pretty URLs
 * 
 * Right now, we're only using one page - so this is pretty simple
 * 
 * @return boolean whether it included the file
 */
function OHT_ElggGenGroups_page_handler()
{
    global $CONFIG;
    return require $CONFIG->pluginspath . "OHT_ElggGenGroups/index.php"; 
}

/**
 * Page setup - adds menu options
 * @return boolean whether the menu option was added successfully
 */
function OHT_ElggGenGroups_pagesetup()
{
    if (get_context () == 'admin' && isadminloggedin ()) {
        global $CONFIG;
        add_submenu_item (elgg_echo('OHT_ElggGenGroups:adminlink'), $CONFIG->wwwroot . 'pg/OHT_ElggGenGroups');
    }
    
    return true;
}

/** register event handlers **/
register_elgg_event_handler('init', 'system', 'OHT_ElggGenGroups_init', 1);
register_elgg_event_handler('pagesetup', 'system', 'OHT_ElggGenGroups_pagesetup');

/** make pretty URLs **/
register_page_handler('OHT_ElggGenGroups','OHT_ElggGenGroups_page_handler');

/** register actions **/
register_action("OHT_ElggGenGroups/generate", false,$CONFIG->pluginspath ."OHT_ElggGenGroups/actions/generate.php", true);
?>