<?php
/*******************************************************************************
 * The Admin Options Index Page
 * 
 * The admin launching page for generating groups
 * 
 * @package OHT
 * @subpackage ElggGenGroups
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/** elgg engine **/
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

/** admin settings **/
admin_gatekeeper();
set_context('admin');

/**
 * get content
 */
$title = elgg_view_title(elgg_echo('OHT_ElggGenGroups:Title'));

/** make sure groups is enabled **/
if (is_plugin_enabled('groups')) {

    /** see if already generated **/
    $generated = get_plugin_setting('groups_generated', 'OHT_ElggGenGroups');
    if ($generated) {
        $body = elgg_view('OHT_ElggGenGroups/completed');
    }
    else {
        $body = elgg_view('OHT_ElggGenGroups/index');
    }
}
else {
    $body = elgg_view('OHT_ElggGenGroups/groupsnotenabled');
}

/** and draw **/
page_draw(elgg_echo('OHT_ElggGenGroups:Title'), elgg_view_layout("two_column_left_sidebar", '', $title . $body));
?>