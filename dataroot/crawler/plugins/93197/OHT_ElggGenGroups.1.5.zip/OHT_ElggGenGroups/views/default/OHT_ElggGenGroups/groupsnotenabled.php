<?php
/*******************************************************************************
 * Admin Groups Not Enabled
 * 
 * This is the note that tells them that groups plugin is not enabled
 * 
 * @package OHT
 * @subpackage ElggGenGroups
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

echo '<div class="contentWrapper">';
echo '<h3>' . elgg_echo('OHT_ElggGenGroups:groupsnotenabledtitle') . '</h3>';
echo '<p>' . elgg_echo('OHT_ElggGenGroups:groupsnotenabledexplanation') . '</p>';
echo '</div>';