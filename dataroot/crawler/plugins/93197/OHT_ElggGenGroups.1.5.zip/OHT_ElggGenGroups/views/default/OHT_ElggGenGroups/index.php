<?php 
/*******************************************************************************
 * Admin Form View
 * 
 * This is the form that the admin uses to generate groups
 * 
 * @package OHT
 * @subpackage ElggGenGroups
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

echo '<div class="contentWrapper">';

$form_body = "<fieldset><legend>" . elgg_echo('OHT_ElggGenGroups:groupinfolegend') . "</legend>";
$form_body .= '<p>' . elgg_echo('OHT_ElggDevTools:groupinfoexplanation') . '</p>';

/** number of groups **/
$form_body .= "<p><h3>" . elgg_echo('OHT_ElggGenGroups:numberofgroups:question') . "</h3>";
$value = 15;
$form_body .= elgg_view('input/text', array('value'=>$value, 'internalname'=>'numberofgroups'));
$form_body .= "</p>";
/** end number of groups **/

/** generate group icons **/
$form_body .= "<p><h3>" . elgg_echo('OHT_ElggGenGroups:groupicon:question') . "</h3>";
$value = 1;
$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'groupicon', 'options'=>array(elgg_echo('OHT_ElggGenGroups:groupicon:answer:yes')=>1, elgg_echo('OHT_ElggGenGroups:groupicon:answer:no')=>0)));
$form_body .= "<em>" . elgg_echo('OHT_ElggGenGroups:groupicon:explanation') . "</em>";
$form_body .= '</p>';
/** end group icons **/

/** group name prefix **/
$form_body .= "<p><h3>" . elgg_echo('OHT_ElggGenGroups:groupnameprefix:question') . "</h3>";
$value = 'OHT_';
$form_body .= elgg_view('input/text', array('value'=>$value, 'internalname'=>'groupnameprefix'));
$form_body .= "</p>";
/** end group name prefix **/

/** group membership - somewhat copied from group plugin **/
$form_body .= "<p><h3>" . elgg_echo('groups:membership') . "</h3>";
$value = '9';
$form_body .= elgg_view('input/pulldown', array('internalname' => 'membership','value' => $value, 'options_values' => array('9'=>elgg_echo('OHT_ElggGenGroups:membership:answer:mixed'), ACCESS_PRIVATE => elgg_echo('groups:access:private'), ACCESS_PUBLIC => elgg_echo('groups:access:public'))));  //technically this should use input/access - but I had an issue - so I did this.
$form_body .= "</p>";
/** end group membership **/

/** other items copied from group plugin **/
if (isset($vars['config']->group_tool_options)) {
    foreach($vars['config']->group_tool_options as $group_option) {
        $group_option_toggle_name = $group_option->name."_enable";
            
        if ($group_option->default_on) {
            $group_option_default_value = 'yes';
        } else {
            $group_option_default_value = 'no';
        }
        
        $form_body .= '<p><h3>' . $group_option->label . '</h3>';

        $form_body .= elgg_view("input/radio",array(
                        "internalname" => $group_option_toggle_name,
                        "value" => 'mixed',
                        'options' => array(
                                            elgg_echo('OHT_ElggGenGroups:group_options:answer:mixed')   =>  'mixed',
                                            elgg_echo('groups:yes') => 'yes',
                                            elgg_echo('groups:no') => 'no',
                                           ),
                                        ));
        $form_body .= '</p>';
    }
}
            



$form_body .= '</fieldset>';


$form_body .= elgg_view('input/submit', array('value'=>elgg_echo('OHT_ElggGenGroups:formbutton')));
echo elgg_view('input/form', array('body'=>$form_body, 'action'=>$CONFIG->wwwroot . 'action/OHT_ElggGenGroups/generate', 'internalid'=>'OHT_ElggGenGroups_form'));

echo '</div>';