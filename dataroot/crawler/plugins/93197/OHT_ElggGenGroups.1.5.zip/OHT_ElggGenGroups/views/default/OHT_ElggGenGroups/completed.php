<?php
/*******************************************************************************
 * Admin Completed View
 * 
 * This is the note that tells them they've already completed the generation
 * 
 * @package OHT
 * @subpackage ElggGenGroups
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

echo '<div class="contentWrapper">';
echo '<h3>' . elgg_echo('OHT_ElggGenGroups:completedtitle') . '</h3>';
echo '<p>' . elgg_echo('OHT_ElggGenGroups:completedexplanation') . '</p>';
echo '</div>';