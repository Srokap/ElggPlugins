<?php
	
	/**
	 * Tag Cumulus
	 * 
	 * @package tag_cumulus
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
 	*/
	
?>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/tag_cumulus/vendors/swfobject.js"></script>
	
	
