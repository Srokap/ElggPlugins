<p>
<?php echo elgg_echo('Example'); ?>
	<a href="<?php echo $vars['url'] ?>mod/tag_cumulus/example.php">Example</a>
</p>