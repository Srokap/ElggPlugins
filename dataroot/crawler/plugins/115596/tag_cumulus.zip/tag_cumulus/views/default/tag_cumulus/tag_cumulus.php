<?php
   if(get_context() != 'admin'){
    	echo '<div id="tag_cumulus_container">' . elgg_view_title('Tags');
    	echo display_tag_cumulus(0,50,'tags','object','','','') . '</div>';
   }
?>