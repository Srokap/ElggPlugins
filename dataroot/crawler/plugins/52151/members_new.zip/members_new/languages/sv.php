﻿<?php

	$swedish = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Webbplatsanv&auml;ndare",
	    	'members:online' => "Anv&auml;ndare aktiva nu",
		'members:active' => "anv&auml;ndare",
		'members:searchtag' => "S&ouml;k anv&auml;ndare via taggar",
		'members:searchname' => "S&ouml;k anv&auml;ndare via namn",
		'members:members' => "Anv&auml;ndare",
		'members:newest' => "Senaste",
		'members:popular' => "Popul&auml;ra",
		'members:go' => "K&ouml;r",
		'members:name' => "Medlemmars namn",
		'members:tags' => "Medlemmars tags",	   
		
	);
					
	add_translation("sv",$swedish);

?>