<?php

	$english = array(
	
		/**
		 * Site info details
		 */
		
		'members:members' => "Site members",
	    	'members:online' => "Members active now",
	    	'members:active' => "site members",
	    	'members:searchtag' => "Member search via tag",
		'members:searchname' => "Member search via name",
   		'members:newest' => "Newest",
		'members:popular' => "Popular",
		'members:go' => "Go",
		'members:name' => "Members name",
		'members:tags' => "Members tags",
		
	);
					
	add_translation("en",$english);

?>