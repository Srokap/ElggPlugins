Licence: GNU General Public License (GPL) version 3

This is a modification of the original Members plugin to get full language support.

The original had some words and phrases hard coded so I've modified the code (and language files) so that it supports translations in full.

Installation:

1. Backup your original files (/mod/members/) and save it somewhere. If the steps below doesn't work as intended just reverse the operation by FTP'ing your backup'ed files to the /mod/members directory and overwriting all files.

2. Download this package and unzip it to your hard drive. FTP the files from your hard drive to your sites /mod/members directory and be sure to overwrite all files.

3. Done!

I don't take any responsibility for data loss or broken sites. You use it at your own risk.


What does this plugin do??
It replaces hard coded words and phrases with it's equivalent code for the language file.

I.e, it takes a line like this in index.php
// Display page
page_draw(sprintf(elgg_echo('Members'),$page_owner->name),$body);

and replaces it with
// Display page
page_draw(sprintf(elgg_echo('members:members'),$page_owner->name),$body);


And like in members_sort_menu.php lines like:
<li <?php if($filter == "newest") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=newest">Newest</a></li>

and replaces it with
<li <?php if($filter == "newest") echo "class='selected'"; ?>><a href="<?php echo $url; ?>?filter=newest"><?php echo elgg_echo("members:newest"); ?></a></li>

It's nothing fancy, just more translation friendly.

Cheers,
Alvmarken
