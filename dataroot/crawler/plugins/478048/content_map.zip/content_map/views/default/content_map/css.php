/**
* @package Elgg
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Tingxi Tan, Grid Research Centre [txtan@cpsc.ucalgary.ca]
* @link http://grc.ucalgary.ca/
*/

.content_map{
	height:100%;
	width:100%;
}
