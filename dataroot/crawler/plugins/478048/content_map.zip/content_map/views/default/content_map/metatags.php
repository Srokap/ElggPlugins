<?php
/**
* @package Elgg
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Tingxi Tan, Grid Research Centre [txtan@cpsc.ucalgary.ca]
* @link http://grc.ucalgary.ca/
*/
?>

<script type="text/javascript" src="<?php echo $vars['url'];?>mod/content_map/javascript/content_map.js"></script>


<!--uncomment this part and enter your own api key if not using google-map plugin
<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=false&amp;key=" type="text/javascript"></script>-->

