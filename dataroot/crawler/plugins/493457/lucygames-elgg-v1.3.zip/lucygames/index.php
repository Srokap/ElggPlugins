<?php
/*
	LucyGames Elgg plugin
	
	Index file per i contenuti
	
	revision: 5
*/

//error_reporting(E_ALL);


// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

//	Valori delle impostazioni di default
$plugin = find_plugin_settings('lucygames');
$server = $plugin->server;
$dglang = $plugin->dglang;
$dgtype = $plugin->dgtype;
$genreid = $plugin->genreid;
$hometask = $plugin->hometask;
$fitems = $plugin->fitems;
$litems = $plugin->litems;

//	Parametri passati tramite GET, con i valori di default se mancanti
$_task = get_input('task',$hometask);
$_gtype = get_input('gtype',$dgtype);
$_glang = get_input('glang',$dglang);
//	Per la ricerca passo la stringa tramite POST
$_string = get_input('string','');


//	Tab visibili(home, windows, macintosh, online)
//	i giochi macintosh sono disponibili solo in inglese
$visibletabs = array('home','windows','online');
if($_glang == 'en') $visibletabs[] = 'macintosh';

//	Tabs attivi (home, windows, macintosh, online)
//	per il momento uno solo � attivo (selezionato)
$activetabs = array();
if($_task == $hometask)
	$activetabs[] = 'home';
else
	switch($_gtype){
		case 'pc': $activetabs[] = 'windows'; break;
		case 'mac': $activetabs[] = 'macintosh'; break;
		case 'og': $activetabs[] = 'online'; break;
	}


//	URL del server remoto con i relativi parametri
$games_url = remoteServerUrl($server).'_content.php?platform=elgg&'.$_SERVER['QUERY_STRING'].'&wwwroot='.substr($CONFIG->wwwroot,7);
if(!isset($_GET['glang'])) $games_url .= '&glang='.$_glang;
if(!isset($_GET['gtype'])) $games_url .= '&gtype='.$_gtype;
if(!isset($_GET['task'])) $games_url .= '&task='.$_task;
if($_string!='') $games_url .= '&string='.$_string;
$games_url .= '&fitems='.$fitems.'&litems='.$litems;
if($genreid!='all') $games_url .= '&genreid='.$genreid;

$navigation_tabs = elgg_view('lucygames/tabs', array('activetabs'=>$activetabs, 'visibletabs'=>$visibletabs));
$body = '<div id="one_column">'.$navigation_tabs.'<div class="lucygames-content">'.getRemoteHTML($games_url).'</div></div>';

//	Disegna la pagina, metodo di elgg
page_draw(elgg_echo('lucygames:pagetitle'),$body);

?>