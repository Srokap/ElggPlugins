<?php
/*
	LucyGames Elgg plugin
	
	Revision: 10
*/

//error_reporting(E_ALL);

require_once dirname(__FILE__).'/lib.php';

function lucygames_init() {
	//	System configuration
	global $CONFIG;
	
	//	Default values for plugin settings
	$plugin = find_plugin_settings('lucygames');
	if ($plugin->server == '') set_plugin_setting('server', 'usa_a', 'lucygames');
	if ($plugin->dglang == '') set_plugin_setting('dglang', 'en', 'lucygames');
	if ($plugin->dgtype == '') set_plugin_setting('dgtype', 'pc', 'lucygames');
	if ($plugin->genreid == '') set_plugin_setting('genreid', 'all', 'lucygames');
	if ($plugin->hometask == '') set_plugin_setting('hometask', 'today_recent', 'lucygames');
	if ($plugin->fitems == '') set_plugin_setting('fitems', '12', 'lucygames');
	if ($plugin->litems == '') set_plugin_setting('litems', '24', 'lucygames');
				
	//	Extend CSS
	extend_view('css', 'lucygames/css');
	
	//	Set up menu for logged in users
	if (isloggedin()) {
		add_menu(elgg_echo('lucygames:m:games'), $CONFIG->wwwroot.'mod/lucygames/index.php');
	}
		
	//	Add widgets
	add_widget_type('listrandom', elgg_echo('lucygames:w:random'), elgg_echo('lucygames:w:randomdesc'));
	add_widget_type('listrecent', elgg_echo('lucygames:w:recent'), elgg_echo('lucygames:w:recentdesc'));
	add_widget_type('listbest', elgg_echo('lucygames:w:bsell'), elgg_echo('lucygames:w:bselldesc'));
	add_widget_type('listcustom', elgg_echo('lucygames:w:custom'), elgg_echo('lucygames:w:customdesc'));
}

register_elgg_event_handler('init','system','lucygames_init');

?>