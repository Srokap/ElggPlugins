<?php
/*
	Copia del widget GamesList
*/

define('lucygamesTASK','random');

include dirname(dirname(__FILE__)).'/_include/view.inc.php';

?>