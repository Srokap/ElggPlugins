<?php
/*
	Copia del widget GamesList
*/

//include dirname(dirname(__FILE__)).'/_include/edit.inc.php';

// Default values
if($vars['entity']->gicon == '') $vars['entity']->gicon = 'med';
if($vars['entity']->gtitle == '') $vars['entity']->gtitle = 'hide';
if($vars['entity']->gdesc == '') $vars['entity']->gdesc = 'hide';
if($vars['entity']->wtitle == '') $vars['entity']->wtitle = 'Custom list';
if($vars['entity']->gids == '') $vars['entity']->gids = '6414,7382,1760';

?>

<p>
<?php echo elgg_echo('lucygames:w:wtitle').' '; ?>
<input name="params[wtitle]" type="text" value="<?php echo $vars['entity']->wtitle; ?>" />
</p>


<p>
<?php echo elgg_echo('lucygames:w:gids').' '; ?>
<input name="params[gids]" type="text" value="<?php echo $vars['entity']->gids; ?>" />
</p>



<p>
<?php echo elgg_echo('lucygames:w:gicon').' '; ?>
<select name="params[gicon]" > 
	<option value="hide" <?php if($vars['entity']->gicon == 'hide') echo "SELECTED"; ?> >Hide</option>
	<option value="small" <?php if($vars['entity']->gicon == 'small') echo "SELECTED"; ?> >Small 60x40</option>
	<option value="med" <?php if($vars['entity']->gicon == 'med') echo "SELECTED"; ?> >Medium 80x80</option>
	<option value="feature" <?php if($vars['entity']->gicon == 'feature') echo "SELECTED"; ?> >Large 175x150</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:w:gtitle').' '; ?>
<select name="params[gtitle]" > 
	<option value="hide" <?php if($vars['entity']->gtitle == 'hide') echo "SELECTED"; ?> >Hide</option>
	<option value="show" <?php if($vars['entity']->gtitle == 'show') echo "SELECTED"; ?> >Show</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:w:gdesc').' '; ?>
<select name="params[gdesc]" >
	<option value="hide" <?php if($vars['entity']->gdesc == 'hide') echo "SELECTED"; ?> >Hide</option>
	<option value="show" <?php if($vars['entity']->gdesc == 'show') echo "SELECTED"; ?> >Show</option>
</select>
</p>