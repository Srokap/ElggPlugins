<div id="elgg_horizontal_tabbed_nav">
	<ul>
		<?php
		if(in_array('home',$vars['visibletabs'])) echo '<li ' , (in_array('home',$vars['activetabs'])?'class="selected"':'') , '><a href="' , $CONFIG->wwwroot , 'mod/lucygames/index.php">' , elgg_echo('lucygames:t:home') , '</a></li>';
		if(in_array('windows',$vars['visibletabs'])) echo '<li ' , (in_array('windows',$vars['activetabs'])?'class="selected"':'') , '><a href="' , $CONFIG->wwwroot , 'mod/lucygames/index.php?task=gameslist&gtype=pc">' , elgg_echo('lucygames:t:windows') , '</a></li>';
		if(in_array('macintosh',$vars['visibletabs'])) echo '<li ' , (in_array('macintosh',$vars['activetabs'])?'class="selected"':'') , '><a href="' , $CONFIG->wwwroot , 'mod/lucygames/index.php?task=gameslist&gtype=mac">' , elgg_echo('lucygames:t:macintosh') , '</a></li>';
		if(in_array('online',$vars['visibletabs'])) echo '<li ' , (in_array('online',$vars['activetabs'])?'class="selected"':'') , '><a href="' , $CONFIG->wwwroot , 'mod/lucygames/index.php?task=gameslist&gtype=og">' , elgg_echo('lucygames:t:online') , '</a></li>';
		?>
	</ul>
</div>