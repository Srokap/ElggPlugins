<?php
/*
	Copia del widget GamesList
*/

define('lucygamesTASK','custom');

include dirname(dirname(__FILE__)).'/_include/view.inc.php';

?>