<?php
/*
	LucyGames Elgg plugin
	
	Tool administration settings
	
	revision: 4
*/

// Default values
$server = $vars['entity']->server;
$dglang = $vars['entity']->dglang;
$dgtype = $vars['entity']->dgtype;
$genreid = $vars['entity']->genreid;
$hometask = $vars['entity']->hometask;
$fitems = $vars['entity']->fitems;
$litems = $vars['entity']->litems;
?>


<p>
<?php echo elgg_echo('lucygames:s:dglang').' '; ?>
<select name="params[dglang]">
  <option value="en" <?php if ($dglang == 'en') echo " selected=\"yes\" "; ?>>English</option>
  <option value="es" <?php if ($dglang == 'es') echo " selected=\"yes\" "; ?>>Spanish</option>
  <option value="fr" <?php if ($dglang == 'fr') echo " selected=\"yes\" "; ?>>French</option>
  <option value="de" <?php if ($dglang == 'de') echo " selected=\"yes\" "; ?>>German</option>
  <option value="jp" <?php if ($dglang == 'jp') echo " selected=\"yes\" "; ?>>Japanese</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:s:dgtype').' '; ?>
<select name="params[dgtype]" >
	<option value="pc" <?php if($dgtype == 'pc') echo "SELECTED"; ?> >PC Windows</option>
	<option value="mac" <?php if($dgtype == 'mac') echo "SELECTED"; ?> >Macintosh</option>
	<option value="og" <?php if($dgtype == 'og') echo "SELECTED"; ?> >Online</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:s:genreid').' '; ?>
<select name="params[genreid]" >
	<option value="all" <?php if($genreid == 'all') echo "SELECTED"; ?> >All games</option>
	<option value="15" <?php if($genreid == '15') echo "SELECTED"; ?> >Hidden object</option>
	<option value="25" <?php if($genreid == '25') echo "SELECTED"; ?> >Time management</option>
	<option value="21" <?php if($genreid == '21') echo "SELECTED"; ?> >Adventure</option>
	<option value="4" <?php if($genreid == '4') echo "SELECTED"; ?> >Puzzle</option>
	<option value="17" <?php if($genreid == '17') echo "SELECTED"; ?> >Match 3</option>
	<option value="18" <?php if($genreid == '18') echo "SELECTED"; ?> >Marble popper</option>
	<option value="19" <?php if($genreid == '19') echo "SELECTED"; ?> >Brain theaser</option>
	<option value="29" <?php if($genreid == '29') echo "SELECTED"; ?> >Strategy</option>
	<option value="6" <?php if($genreid == '6') echo "SELECTED"; ?> >Word</option>
	<option value="1" <?php if($genreid == '1') echo "SELECTED"; ?> >Arcade &amp; Action</option>
	<option value="5" <?php if($genreid == '5') echo "SELECTED"; ?> >Card &amp; Board</option>
	<option value="3" <?php if($genreid == '3') echo "SELECTED"; ?> >Mahjong</option>
	<option value="26" <?php if($genreid == '26') echo "SELECTED"; ?> >Kids</option>
	<option value="20" <?php if($genreid == '20') echo "SELECTED"; ?> >Large file adventure</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:s:hometask').' '; ?>
<select name="params[hometask]">
  <option value="today_bsell" <?php if ($hometask == 'today_bsell') echo " selected=\"yes\" "; ?>>Today + Best seller</option>
  <option value="today_recent" <?php if ($hometask == 'today_recent') echo " selected=\"yes\" "; ?>>Today + Recent</option>
  <option value="today_recent_bsell" <?php if ($hometask == 'today_recent_bsell') echo " selected=\"yes\" "; ?>>Today + Recent + Best seller</option>
  <option value="gameslist" <?php if ($hometask == 'gameslist') echo " selected=\"yes\" "; ?>>Games list</option>
</select>
<br/>
<i><?php echo elgg_echo('lucygames:s:htnote'); ?></i>
</p>

<p>
<?php echo elgg_echo('lucygames:s:fitems').' '; ?>
<select name="params[fitems]">
	<option value="3"<?php if ($fitems == '3') echo " selected=\"yes\" "; ?>>3</option>
	<option value="4"<?php if ($fitems == '4') echo " selected=\"yes\" "; ?>>4</option>
	<option value="5"<?php if ($fitems == '5') echo " selected=\"yes\" "; ?>>5</option>
	<option value="6"<?php if ($fitems == '6') echo " selected=\"yes\" "; ?>>6</option>
	<option value="7"<?php if ($fitems == '7') echo " selected=\"yes\" "; ?>>7</option>
	<option value="8"<?php if ($fitems == '8') echo " selected=\"yes\" "; ?>>8</option>
	<option value="9"<?php if ($fitems == '9') echo " selected=\"yes\" "; ?>>9</option>
	<option value="10"<?php if ($fitems == '10') echo " selected=\"yes\" "; ?>>10</option>
	<option value="11"<?php if ($fitems == '11') echo " selected=\"yes\" "; ?>>11</option>
	<option value="12"<?php if ($fitems == '12') echo " selected=\"yes\" "; ?>>12</option>
	<option value="13"<?php if ($fitems == '13') echo " selected=\"yes\" "; ?>>13</option>
	<option value="14"<?php if ($fitems == '14') echo " selected=\"yes\" "; ?>>14</option>
	<option value="15"<?php if ($fitems == '15') echo " selected=\"yes\" "; ?>>15</option>
	<option value="16"<?php if ($fitems == '16') echo " selected=\"yes\" "; ?>>16</option>
	<option value="17"<?php if ($fitems == '17') echo " selected=\"yes\" "; ?>>17</option>
	<option value="18"<?php if ($fitems == '18') echo " selected=\"yes\" "; ?>>18</option>
	<option value="19"<?php if ($fitems == '19') echo " selected=\"yes\" "; ?>>19</option>
	<option value="20"<?php if ($fitems == '20') echo " selected=\"yes\" "; ?>>20</option>
	<option value="21"<?php if ($fitems == '21') echo " selected=\"yes\" "; ?>>21</option>
	<option value="22"<?php if ($fitems == '22') echo " selected=\"yes\" "; ?>>22</option>
	<option value="23"<?php if ($fitems == '23') echo " selected=\"yes\" "; ?>>23</option>
	<option value="24"<?php if ($fitems == '24') echo " selected=\"yes\" "; ?>>24</option>
	<option value="25"<?php if ($fitems == '25') echo " selected=\"yes\" "; ?>>25</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:s:litems').' '; ?>
<select name="params[litems]">
	<option value="20"<?php if ($litems == '20') echo " selected=\"yes\" "; ?>>20</option>
	<option value="21"<?php if ($litems == '21') echo " selected=\"yes\" "; ?>>21</option>
	<option value="22"<?php if ($litems == '22') echo " selected=\"yes\" "; ?>>22</option>
	<option value="23"<?php if ($litems == '23') echo " selected=\"yes\" "; ?>>23</option>
	<option value="24"<?php if ($litems == '24') echo " selected=\"yes\" "; ?>>24</option>
	<option value="25"<?php if ($litems == '25') echo " selected=\"yes\" "; ?>>25</option>
	<option value="26"<?php if ($litems == '26') echo " selected=\"yes\" "; ?>>26</option>
	<option value="27"<?php if ($litems == '27') echo " selected=\"yes\" "; ?>>27</option>
	<option value="28"<?php if ($litems == '28') echo " selected=\"yes\" "; ?>>28</option>
	<option value="29"<?php if ($litems == '29') echo " selected=\"yes\" "; ?>>29</option>
	<option value="30"<?php if ($litems == '30') echo " selected=\"yes\" "; ?>>30</option>
	<option value="31"<?php if ($litems == '31') echo " selected=\"yes\" "; ?>>31</option>
	<option value="32"<?php if ($litems == '32') echo " selected=\"yes\" "; ?>>32</option>
	<option value="33"<?php if ($litems == '33') echo " selected=\"yes\" "; ?>>33</option>
	<option value="34"<?php if ($litems == '34') echo " selected=\"yes\" "; ?>>34</option>
	<option value="35"<?php if ($litems == '35') echo " selected=\"yes\" "; ?>>35</option>
	<option value="36"<?php if ($litems == '36') echo " selected=\"yes\" "; ?>>36</option>
	<option value="37"<?php if ($litems == '37') echo " selected=\"yes\" "; ?>>37</option>
	<option value="38"<?php if ($litems == '38') echo " selected=\"yes\" "; ?>>38</option>
	<option value="39"<?php if ($litems == '39') echo " selected=\"yes\" "; ?>>39</option>
	<option value="40"<?php if ($litems == '40') echo " selected=\"yes\" "; ?>>40</option>
	<option value="41"<?php if ($litems == '41') echo " selected=\"yes\" "; ?>>41</option>
	<option value="42"<?php if ($litems == '42') echo " selected=\"yes\" "; ?>>42</option>
	<option value="43"<?php if ($litems == '43') echo " selected=\"yes\" "; ?>>43</option>
	<option value="44"<?php if ($litems == '44') echo " selected=\"yes\" "; ?>>44</option>
	<option value="45"<?php if ($litems == '45') echo " selected=\"yes\" "; ?>>45</option>
	<option value="46"<?php if ($litems == '46') echo " selected=\"yes\" "; ?>>46</option>
	<option value="47"<?php if ($litems == '47') echo " selected=\"yes\" "; ?>>47</option>
	<option value="48"<?php if ($litems == '48') echo " selected=\"yes\" "; ?>>48</option>
	<option value="49"<?php if ($litems == '49') echo " selected=\"yes\" "; ?>>49</option>
	<option value="50"<?php if ($litems == '50') echo " selected=\"yes\" "; ?>>50</option>
	<option value="51"<?php if ($litems == '51') echo " selected=\"yes\" "; ?>>51</option>
	<option value="52"<?php if ($litems == '52') echo " selected=\"yes\" "; ?>>52</option>
	<option value="53"<?php if ($litems == '53') echo " selected=\"yes\" "; ?>>53</option>
	<option value="54"<?php if ($litems == '54') echo " selected=\"yes\" "; ?>>54</option>
	<option value="55"<?php if ($litems == '55') echo " selected=\"yes\" "; ?>>55</option>
	<option value="56"<?php if ($litems == '56') echo " selected=\"yes\" "; ?>>56</option>
	<option value="57"<?php if ($litems == '57') echo " selected=\"yes\" "; ?>>57</option>
	<option value="58"<?php if ($litems == '58') echo " selected=\"yes\" "; ?>>58</option>
	<option value="59"<?php if ($litems == '59') echo " selected=\"yes\" "; ?>>59</option>
	<option value="60"<?php if ($litems == '60') echo " selected=\"yes\" "; ?>>60</option>
	<option value="61"<?php if ($litems == '61') echo " selected=\"yes\" "; ?>>61</option>
	<option value="62"<?php if ($litems == '62') echo " selected=\"yes\" "; ?>>62</option>
	<option value="63"<?php if ($litems == '63') echo " selected=\"yes\" "; ?>>63</option>
	<option value="64"<?php if ($litems == '64') echo " selected=\"yes\" "; ?>>64</option>
	<option value="65"<?php if ($litems == '65') echo " selected=\"yes\" "; ?>>65</option>
	<option value="66"<?php if ($litems == '66') echo " selected=\"yes\" "; ?>>66</option>
	<option value="67"<?php if ($litems == '67') echo " selected=\"yes\" "; ?>>67</option>
	<option value="68"<?php if ($litems == '68') echo " selected=\"yes\" "; ?>>68</option>
	<option value="69"<?php if ($litems == '69') echo " selected=\"yes\" "; ?>>69</option>
	<option value="70"<?php if ($litems == '70') echo " selected=\"yes\" "; ?>>70</option>
	<option value="71"<?php if ($litems == '71') echo " selected=\"yes\" "; ?>>71</option>
	<option value="72"<?php if ($litems == '72') echo " selected=\"yes\" "; ?>>72</option>
	<option value="73"<?php if ($litems == '73') echo " selected=\"yes\" "; ?>>73</option>
	<option value="74"<?php if ($litems == '74') echo " selected=\"yes\" "; ?>>74</option>
	<option value="75"<?php if ($litems == '75') echo " selected=\"yes\" "; ?>>75</option>
	<option value="76"<?php if ($litems == '76') echo " selected=\"yes\" "; ?>>76</option>
	<option value="77"<?php if ($litems == '77') echo " selected=\"yes\" "; ?>>77</option>
	<option value="78"<?php if ($litems == '78') echo " selected=\"yes\" "; ?>>78</option>
	<option value="79"<?php if ($litems == '79') echo " selected=\"yes\" "; ?>>79</option>
	<option value="80"<?php if ($litems == '80') echo " selected=\"yes\" "; ?>>80</option>
</select>
</p>

<hr/>

<p>
<?php echo elgg_echo('lucygames:s:server').' '; ?>
<select name="params[server]">
  <option value="usa_a" <?php if ($server == 'usa_a') echo " selected=\"yes\" "; ?>>USA</option>
  <option value="ita_a" <?php if ($server == 'ita_a') echo " selected=\"yes\" "; ?>>Italy</option>
</select>
</p>