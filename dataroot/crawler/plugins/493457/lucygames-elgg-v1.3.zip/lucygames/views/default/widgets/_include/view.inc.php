<?php
/*
	LucyGames Elgg plugin
	
	Base per la view dei widget che mostrano l'elenco dei giochi
	
	revision: 6
*/


//	Opzione task: random, recent, bsell, custom. Di default richiedo una lista random
defined('lucygamesTASK') or define('lucygamesTASK','random');

//	Parametri da accodare alla url del server
$url_params = '';
$url_params .= '&task='.lucygamesTASK;
$url_params .= '&gicon='.$vars['entity']->gicon;
$url_params .= '&gtitle='.$vars['entity']->gtitle;
$url_params .= '&gdesc='.$vars['entity']->gdesc;
if(lucygamesTASK != 'custom'){
	$url_params .= '&gtype='.$vars['entity']->gtype;
	$url_params .= '&glang='.$vars['entity']->glang;
	$url_params .= '&genreid='.$vars['entity']->genreid;
	$url_params .= '&fitems='.$vars['entity']->fitems;
	if($vars['entity']->keywordfilter == 'yes')
		$url_params .= '&keywords='.$vars['entity']->keywords;
} else {
	$url_params .= '&gids='.$vars['entity']->gids;
}

//	Global plugin settings
$plugin = find_plugin_settings('lucygames');
$server = $plugin->server;
?>

<div class="contentWrapper">
	<div class="lucygames-widget">
		<?php
		echo '<h2>'.$vars['entity']->wtitle.'</h2>';
		$games_url = remoteServerUrl($server)."_widget.php?platform=elgg".$url_params.'&wwwroot='.substr($CONFIG->wwwroot,7);
		echo getRemoteHTML($games_url);
		?>
	</div>
</div>