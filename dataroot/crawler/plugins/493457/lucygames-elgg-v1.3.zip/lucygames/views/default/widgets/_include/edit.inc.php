<?php
/*
	LucyGames Elgg plugin
	
	Base per la edit dei widget che mostrano l'elenco dei giochi
	
	revision: 3
*/

//	Impostazione dei valori di default
if($vars['entity']->gtype == '') $vars['entity']->gtype = 'pc';
if($vars['entity']->glang == '') $vars['entity']->glang = 'en';
if($vars['entity']->genreid == '') $vars['entity']->genreid = 'all';
if($vars['entity']->gicon == '') $vars['entity']->gicon = 'med';
if($vars['entity']->gtitle == '') $vars['entity']->gtitle = 'hide';
if($vars['entity']->gdesc == '') $vars['entity']->gdesc = 'hide';
if($vars['entity']->fitems == '') $vars['entity']->fitems = '9';
if($vars['entity']->keywordfilter == '') $vars['entity']->keywordfilter = 'no';

?>

<p>
<?php echo elgg_echo('lucygames:w:wtitle').' '; ?>
<input name="params[wtitle]" type="text" value="<?php echo $vars['entity']->wtitle; ?>" />
</p>

<p>
<?php echo elgg_echo('lucygames:w:gtype').' '; ?>
<select name="params[gtype]" >
	<option value="pc" <?php if($vars['entity']->gtype == 'pc') echo "SELECTED"; ?> >PC Windows</option>
	<option value="mac" <?php if($vars['entity']->gtype == 'mac') echo "SELECTED"; ?> >Macintosh</option>
	<option value="og" <?php if($vars['entity']->gtype == 'og') echo "SELECTED"; ?> >Online games</option>
</select>
</p>

<p><?php echo elgg_echo('lucygames:w:glang').' '; ?>
<select name="params[glang]" >
	<option value="de" <?php if($vars['entity']->glang == 'de') echo "SELECTED"; ?> >German</option>
	<option value="en" <?php if($vars['entity']->glang == 'en') echo "SELECTED"; ?> >English</option>
	<option value="es" <?php if($vars['entity']->glang == 'es') echo "SELECTED"; ?> >Spanish</option>
	<option value="fr" <?php if($vars['entity']->glang == 'fr') echo "SELECTED"; ?> >French</option>
	<option value="jp" <?php if($vars['entity']->glang == 'jp') echo "SELECTED"; ?> >Japanese</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:s:genreid').' '; ?>
<select name="params[genreid]" >
	<option value="all" <?php if($vars['entity']->genreid == 'all') echo "SELECTED"; ?> >All games</option>
	<option value="15" <?php if($vars['entity']->genreid == '15') echo "SELECTED"; ?> >Hidden object</option>
	<option value="25" <?php if($vars['entity']->genreid == '25') echo "SELECTED"; ?> >Time management</option>
	<option value="21" <?php if($vars['entity']->genreid == '21') echo "SELECTED"; ?> >Adventure</option>
	<option value="4" <?php if($vars['entity']->genreid == '4') echo "SELECTED"; ?> >Puzzle</option>
	<option value="17" <?php if($vars['entity']->genreid == '17') echo "SELECTED"; ?> >Match 3</option>
	<option value="18" <?php if($vars['entity']->genreid == '18') echo "SELECTED"; ?> >Marble popper</option>
	<option value="19" <?php if($vars['entity']->genreid == '19') echo "SELECTED"; ?> >Brain theaser</option>
	<option value="29" <?php if($vars['entity']->genreid == '29') echo "SELECTED"; ?> >Strategy</option>
	<option value="6" <?php if($vars['entity']->genreid == '6') echo "SELECTED"; ?> >Word</option>
	<option value="1" <?php if($vars['entity']->genreid == '1') echo "SELECTED"; ?> >Arcade &amp; Action</option>
	<option value="5" <?php if($vars['entity']->genreid == '5') echo "SELECTED"; ?> >Card &amp; Board</option>
	<option value="3" <?php if($vars['entity']->genreid == '3') echo "SELECTED"; ?> >Mahjong</option>
	<option value="26" <?php if($vars['entity']->genreid == '26') echo "SELECTED"; ?> >Kids</option>
	<option value="20" <?php if($vars['entity']->genreid == '20') echo "SELECTED"; ?> >Large file adventure</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:w:fitems').' '; ?>
<select name="params[fitems]" >
	<option value="1" <?php if($vars['entity']->fitems == '1') echo "SELECTED"; ?> >1</option>
	<option value="2" <?php if($vars['entity']->fitems == '2') echo "SELECTED"; ?> >2</option>
	<option value="3" <?php if($vars['entity']->fitems == '3') echo "SELECTED"; ?> >3</option>
	<option value="4" <?php if($vars['entity']->fitems == '4') echo "SELECTED"; ?> >4</option>
	<option value="5" <?php if($vars['entity']->fitems == '5') echo "SELECTED"; ?> >5</option>
	<option value="6" <?php if($vars['entity']->fitems == '6') echo "SELECTED"; ?> >6</option>
	<option value="7" <?php if($vars['entity']->fitems == '7') echo "SELECTED"; ?> >7</option>
	<option value="8" <?php if($vars['entity']->fitems == '8') echo "SELECTED"; ?> >8</option>
	<option value="9" <?php if($vars['entity']->fitems == '9') echo "SELECTED"; ?> >9</option>
	<option value="10" <?php if($vars['entity']->fitems == '10') echo "SELECTED"; ?> >10</option>
	<option value="11" <?php if($vars['entity']->fitems == '11') echo "SELECTED"; ?> >11</option>
	<option value="12" <?php if($vars['entity']->fitems == '12') echo "SELECTED"; ?> >12</option>
	<option value="13" <?php if($vars['entity']->fitems == '13') echo "SELECTED"; ?> >13</option>
	<option value="14" <?php if($vars['entity']->fitems == '14') echo "SELECTED"; ?> >14</option>
	<option value="15" <?php if($vars['entity']->fitems == '15') echo "SELECTED"; ?> >15</option>
	<option value="16" <?php if($vars['entity']->fitems == '16') echo "SELECTED"; ?> >16</option>
	<option value="17" <?php if($vars['entity']->fitems == '17') echo "SELECTED"; ?> >17</option>
	<option value="18" <?php if($vars['entity']->fitems == '18') echo "SELECTED"; ?> >18</option>
	<option value="19" <?php if($vars['entity']->fitems == '19') echo "SELECTED"; ?> >19</option>
	<option value="20" <?php if($vars['entity']->fitems == '20') echo "SELECTED"; ?> >20</option>
</select>
</p>

<hr /><b><?php echo elgg_echo('lucygames:w:advoptions'); ?></b><br /><br />

<p>
<?php echo elgg_echo('lucygames:w:gicon').' '; ?>
<select name="params[gicon]" > 
	<option value="hide" <?php if($vars['entity']->gicon == 'hide') echo "SELECTED"; ?> >Hide</option>
	<option value="small" <?php if($vars['entity']->gicon == 'small') echo "SELECTED"; ?> >Small 60x40</option>
	<option value="med" <?php if($vars['entity']->gicon == 'med') echo "SELECTED"; ?> >Medium 80x80</option>
	<option value="feature" <?php if($vars['entity']->gicon == 'feature') echo "SELECTED"; ?> >Large 175x150</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:w:gtitle').' '; ?>
<select name="params[gtitle]" > 
	<option value="hide" <?php if($vars['entity']->gtitle == 'hide') echo "SELECTED"; ?> >Hide</option>
	<option value="show" <?php if($vars['entity']->gtitle == 'show') echo "SELECTED"; ?> >Show</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:w:gdesc').' '; ?>
<select name="params[gdesc]" >
	<option value="hide" <?php if($vars['entity']->gdesc == 'hide') echo "SELECTED"; ?> >Hide</option>
	<option value="show" <?php if($vars['entity']->gdesc == 'show') echo "SELECTED"; ?> >Show</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:w:keywordfilter').' '; ?>
<select name="params[keywordfilter]" >
	<option value="no" <?php if($vars['entity']->keywordfilter == 'no') echo "SELECTED"; ?> >No</option>
	<option value="yes" <?php if($vars['entity']->keywordfilter == 'yes') echo "SELECTED"; ?> >Yes</option>
</select>
</p>

<p>
<?php echo elgg_echo('lucygames:w:keywords').' '; ?>
<input name="params[keywords]" type="text" value="<?php echo $vars['entity']->keywords; ?>" />
</p>