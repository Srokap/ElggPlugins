<?php
	//	LucyGames, Elgg plugin
	//	css extension

//	use style.css file in the plugin root
include dirname(dirname(dirname(dirname(__FILE__)))).'/style.css';
?>