<?php
/*
	Copia del widget GamesList
*/

include dirname(dirname(__FILE__)).'/_include/edit.inc.php';

?>