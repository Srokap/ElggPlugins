<?php
$english = array(
	'lucygames:pagetitle' => 'Free video games by LucyGames.com',
//	Men�
	'lucygames:m:games' => 'Games',
//	Tabs
	'lucygames:t:home' => 'Home',
	'lucygames:t:windows' => 'Windows',
	'lucygames:t:macintosh' => 'Macintosh',
	'lucygames:t:online' => 'Online',
//	Settings
	'lucygames:s:hometask' => 'What to show on the games homepage?',
	'lucygames:s:htnote' => 'Note: best seller listing are available only for Windows and Macintosh games.',
	'lucygames:s:server' => 'Remote server location',
	'lucygames:s:dgtype' => 'Default games platform',
	'lucygames:s:dglang' => 'Default games language',
	'lucygames:s:genreid' => 'Games genre',
	'lucygames:s:fitems' => 'Number of games in a featured list',
	'lucygames:s:litems' => 'Number of games in a generic list',
//	Widget
	'lucygames:w:wtitle' => 'Widget title',
	'lucygames:w:advoptions' => 'Advanced options',
	'lucygames:w:gtype' => 'Games type',
	'lucygames:w:glang' => 'Games language',
	'lucygames:w:gicon' => 'Games icon',
	'lucygames:w:gtitle' => 'Games title',
	'lucygames:w:gdesc' => 'Games description',
	'lucygames:w:fitems' => 'Number of games',
	'lucygames:w:keywordfilter' => 'Filter by keyword?',
	'lucygames:w:keywords' => 'Keyword',
	'lucygames:w:gids' => 'Games list (IDs)',
	'lucygames:w:recent' => 'Recent games',
	'lucygames:w:recentdesc' => 'Latest released games',
	'lucygames:w:random' => 'Random games',
	'lucygames:w:randomdesc' => 'Random games listing',
	'lucygames:w:bsell' => 'Best seller games',
	'lucygames:w:bselldesc' => 'List games by selling volumes',
	'lucygames:w:custom' => 'Custom games list',
	'lucygames:w:customdesc' => 'A custom list of games. Use a comma separated list of game ids.',
);

add_translation("en",$english);
?>