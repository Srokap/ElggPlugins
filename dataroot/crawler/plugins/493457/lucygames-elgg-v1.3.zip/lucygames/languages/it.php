<?php
$italiano = array(
	'lucygames:pagetitle' => 'Video giochi gratis by LucyGames.com',
//	Men�
	'lucygames:m:games' => 'Giochi',
//	Tabs
	'lucygames:t:home' => 'Home',
	'lucygames:t:windows' => 'Windows',
	'lucygames:t:macintosh' => 'Macintosh',
	'lucygames:t:online' => 'Online',
//	Settings
	'lucygames:s:hometask' => 'Cosa mostrare nella home page dei giochi?',
	'lucygames:s:htnote' => 'Nota: l\'elenco dei giochi pi&ugrave; venduti &egrave; disponibile solo per i giochi Windows e Macintosh.',
	'lucygames:s:server' => 'Posizione server remoto',
	'lucygames:s:dgtype' => 'Piattaforma predefinita dei giochi',
	'lucygames:s:dglang' => 'Lingua predefinita dei giochi',
	'lucygames:s:genreid' => 'Genere dei giochi',
	'lucygames:s:fitems' => 'Numero di giochi in una sezione in primo piano',
	'lucygames:s:litems' => 'Numero di giochi in una lista generica',
//	Widget
	'lucygames:w:wtitle' => 'Titolo del widget',
	'lucygames:w:advoptions' => 'Opzioni avanzate',
	'lucygames:w:gtype' => 'Piattaforma dei giochi',
	'lucygames:w:glang' => 'Lingua dei giochi',
	'lucygames:w:gicon' => 'Icona del gioco',
	'lucygames:w:gtitle' => 'Titolo del gioco',
	'lucygames:w:gdesc' => 'Descrizione del gioco',
	'lucygames:w:fitems' => 'Numero di giochi',
	'lucygames:w:keywordfilter' => 'Filtra con una parola chiave?',
	'lucygames:w:keywords' => 'Parola chiave',
	'lucygames:w:gids' => 'Lista dei giochi (ID)',
	'lucygames:w:recent' => 'Giochi recenti',
	'lucygames:w:recentdesc' => 'Giochi rilasciati di recente',
	'lucygames:w:random' => 'Giochi casuali',
	'lucygames:w:randomdesc' => 'Lista casuale di giochi',
	'lucygames:w:bsell' => 'Pi&ugrave; venduti',
	'lucygames:w:bselldesc' => 'Lista ordinata secondo i volumi di vendita',
	'lucygames:w:custom' => 'Lista personalizzata',
	'lucygames:w:customdesc' => 'Lista personalizzata di giochi. Indicare gli ID separati da virgola.',
);

add_translation("it",$italiano);
?>