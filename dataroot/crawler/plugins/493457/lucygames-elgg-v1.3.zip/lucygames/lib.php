<?php
/*
	Lucy Games, Function library

	Revision: 4
 */

//define("lucygamesGAMESERVER","http://cdn.lucygames.com/web-services/lucygames_v3/");

//	DEBUG
function debugVar($variable){
echo '<pre style="background-color:yellow;">';
	var_dump($variable);
echo '</pre>';
}


function remoteServerUrl($serverid){
switch($serverid){
	case 'usa_a': return 'http://cdn-usa.lucygames.com/web-services/lucygames_v3/';
	case 'ita_a': return 'http://cdn-ita.lucygames.com/web-services/lucygames_v3/';
	default: return 'http://cdn-usa.lucygames.com/web-services/lucygames_v3/';
}
}

//	Return the content returned by a remote server
function getRemoteHTML($url){
if(ini_get('allow_url_fopen')){
	$handle = fopen($url,"r");
	$html = "";
	while(!feof($handle)){
		$html .= fgets($handle, 200);
		//echo "$str";
	}
	fclose($handle);
	return $html;
}
if(function_exists('curl_init')){
	$timeout = 10000;
	$html = NULL;
	$cu = curl_init ();
	curl_setopt($cu, CURLOPT_URL, $url);
	//curl_setopt($cu, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($cu, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($cu, CURLOPT_HEADER, 0);
	curl_setopt ($cu, CURLOPT_TIMEOUT, $timeout);
	$html = curl_exec($cu);
	curl_close ($cu);
	return $html;
}
return 'Warning: unable to retrieve data, failed to use fopen and curl functions.';
}

?>