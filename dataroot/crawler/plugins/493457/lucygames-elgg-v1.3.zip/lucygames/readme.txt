
LucyGames Elgg plugin
---------------------


If you find any bug feel free to write us:

 - support@lucygames.com

If you find it useful please leave a testimonial here:

 - www.lucygames.com/index.php?option=com_rsmonials#submitform




Provides a total of 6000+ games for free play. Windows, Mac and online versions
in five languages: German, English, Spanish, French and Japanese. All games are dowloadable
and fully playable for free.
If the end user likes the game will then pay for the full unlimited version.

    * Full game catalog: 6000+ titles
    * High quality games
    * Save hosting space: no game files in your server
    * Games for Windows, Macintosh and for online play
    * Online games are played into your site (no popups)
    * Games in four languages: English, German, Spanish, French and Japanese
    * Fully integrated within your template
    * Uses standard CSS file to style
    * No advertising banners
    * Completely free, lifetime
    * Free e-mail support
