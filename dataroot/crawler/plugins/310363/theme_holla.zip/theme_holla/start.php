<?php

    /**
     * Holla theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function hollatheme_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','hollatheme_init');
	
?>