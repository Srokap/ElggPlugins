
<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">

	<!-- site logo -->
	<div id="logo">
	<a href="<?php echo $vars['url']; ?>">
		<img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/logo.png" width="201px" height="35px" border="0" /></a>
	</div>
<?php
     if (isloggedin()) {
?>

	<div id="smallmenu">
       <span id="adminicon"><a href="<?php echo $_SESSION['user']->getURL(); ?>"><?php echo $vars['user']->name; ?></a></span>
       <span id="rssicon"><a href="#" onclick="toggle('dropBox');">applications</a></span>
    </div>
	<div id="dropBox" style="display: none;">
	<a onclick="toggle('dropBox');" style="cursor:pointer;">+ CLOSE</a>
	<table>
		<tr>
			<td width="50%">
			
					<ul>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/home.png">&nbsp;<a href="<?php echo $vars['url']; ?>">home</a></li>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/profile.png">&nbsp;<a href="<?php echo $_SESSION['user']->getURL(); ?>">Profile</a>
						</li>  
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/friend.png">&nbsp;<a href="<?php echo $vars['url']; ?>pg/friends/">Friends</a>
						</li>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/blog.png">&nbsp;<a href="<?php echo $vars['url']; ?>mod/blog/everyone.php">Blogs</a>
						</li>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/pages.png">&nbsp;<a href="<?php echo $vars['url']; ?>mod/pages/world.php">Pages</a>
						</li>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/groups.png">&nbsp;<a href="<?php echo $vars['url']; ?>pg/groups/world/">Groups</a>
						</li>
						
					</ul>
			</td>
			<td>
					<ul>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/bookmark.png">&nbsp;<a href="<?php echo $vars['url']; ?>mod/bookmarks/everyone.php">B'marks</a></li>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/file.png">&nbsp;<a href="<?php echo $vars['url']; ?>mod/file/world.php">Files</a></li>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/wire.png">&nbsp;<a href="<?php echo $vars['url']; ?>mod/thewire/everyone.php">Wire</a></li>
						<!--<li><a href="<?php echo $vars['url']; ?>pg/myshare/myshare/">myShare</a></li>-->
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/email.png">&nbsp;<a href="<?php echo $vars['url']; ?>pg/myemail/myemail/">E-mail</a></li>
						<li><img src="<?php echo $vars['url']; ?>mod/theme_holla/graphics/member.png">&nbsp;<a href="<?php echo $vars['url']; ?>mod/members/index.php">Members</a></li>

					</ul>
			
			</td>
		</tr>
	</table>
					
	</div>
<?php } ?>
	
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
