<?php

register_error("Blocked from sending messages");

forward();
