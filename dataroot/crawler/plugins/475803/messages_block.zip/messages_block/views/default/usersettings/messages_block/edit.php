<p>
<?php
	$options = array(0 => elgg_echo('mb:anyone'), 1 => elgg_echo('mb:friends') );
	echo elgg_echo('mb:instruct');
	echo elgg_view('input/pulldown', array('internalname' => 'params[messages_friends_only]',
											'value' => $vars['entity']->messages_friends_only,
											'options_values' => $options));
?>
</p>