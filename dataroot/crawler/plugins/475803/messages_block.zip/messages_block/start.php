<?php

register_elgg_event_handler('init', 'system', 'messages_block_init');

function messages_block_init() {
	register_plugin_hook('action', 'messages/send', 'messages_block_friends_only');
}

function messages_block_friends_only($hook, $type, $params, $result) {
	$send_to = get_input('send_to');
	$user = get_user($send_to);
	if (!$user) {
		return $result;
	}

	$setting = get_plugin_usersetting('messages_friends_only', $user->guid, 'messages_block');
	// check if this user wants friends only mail
	if ($setting != 1) {
		return $result;
	}

	// is sender a friend
	if ($user->isFriendsWith(get_loggedin_userid())) {
		return TRUE;
	}

	register_error(elgg_echo('mb:deny'));

	return FALSE;
}




// add guids here that you want to block
$blocked_user_guids = array(21493);

$current_user = get_loggedin_userid();

if (!in_array($current_user, $blocked_user_guids)) {
	return TRUE;
}

// block this user
unregister_elgg_event_handler('init','system','messages_init');

// trash the send action
register_action("messages/send", false, $CONFIG->pluginspath . "messages_block/nosend.php");

