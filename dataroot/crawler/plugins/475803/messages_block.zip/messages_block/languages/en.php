<?php

	$english = array(
		'messages_block' => 'Private messaging',
		'mb:instruct' => 'Who can send you messages: ',
		'mb:deny' => "We're sorry. This user only accepts mail from friends",
		'mb:anyone' => "anyone",
		'mb:friends' => "just friends",
	);

	add_translation("en",$english);

?>
