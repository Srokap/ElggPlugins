Comment-Tracker-1.8.x
=====================

Subscribes commenters to an entity so they receive notifications of new comments.  Subscription toggle, notification type settings.