=============================
PLUGIN NAME
=============================
Google Analytics 1.8 (modified)

=============================
PLUGIN VERSION
=============================
1.0 (18th Jan 2012)

=============================
PLUGIN DESCRIPTION
=============================
Implementing Google Analytics on your Elgg website.

To track your website with Google Analytics tools, you will need to implement Google Analytics Tracking Code on your webpage before the closing </head> tag. This plugin does this for you. (See the instrallation note below for more details)

This is modified version of Google Analytics 1.8 by by Purus found here:
http://community.elgg.org/pg/plugins/project/794966/developer/Purus/google-analytics-18

This plugin is modified to work with Elgg 1.8.3 and latest Google Analytics tracking code.

=============================
REQUIREMENT(S)
=============================
Elgg 1.8.3+
Google Analytics Tracking Code (You can obtain this from http://www.google.com/analytics/)

=============================
INSTRALLATION
=============================
Copy the unzipped google_analytics folder to the "mod" directory in your Elgg installation.

You must then activate the plugin:

    Log in to your Elgg site with your administrator account
    Go to Administration -> Configure -> Plugins
    Find your plugin in the list of installed plugins and click on the 'enable' button.
    In the plugin's setting, add your Google Analytics Tracking Code and save.

=============================
CREDITS
=============================
All the credits goes to the owner of this orginal plugin: Purus - http://www.iYaffle.com