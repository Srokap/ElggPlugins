<?php

/* ***********************************************************************
 * @author : Aung Aung (http://community.elgg.org/pg/profile/aung)
 * This script is modified from Google Analytics 1.8
 * originally written by Original author: Purusothaman Ramanujam (http://www.iYaffle.com/)
 * ***********************************************************************/

add_translation('en', array(
    'google-analytics:lblID' => 'Analytics Tracking ID: ',
    'google-analytics:lblExample' => '(Eg. UA-1234567-8)',
    'google-analytics:lblHelp' => 'For more information please visit '
));