<?php

/**
 * Elgg river dashboard plugin index page
 *
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider Ltd <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.org/
 */

require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

//gatekeeper();

$content = get_input('content','');
$content = explode(',' ,$content);
$type = $content[0];
if (isset($content[1])) {
	$subtype = $content[1];
} else {
	$subtype = '';
}
$orient = get_input('display');
$callback = get_input('callback');

if ($type == 'all') {
	$type = '';
	$subtype = '';
}

$body = '';
if (empty($callback)) {

	if (get_plugin_setting('useasdashboard', 'riverdashboard') == 'yes') {
		$title = elgg_echo('dashboard');
	} else {
		$title = elgg_echo('activity');
	}

	
	
	//set a view to display the mini profile
	$area1 = elgg_view("riverdashboard/miniprofile");
	
	//set a view to display recent visitors
	if(get_plugin_setting("recent_visitors", "riverdashboard") != "no")
	{
		$area1 .= elgg_view("riverdashboard/recentvisitors");
	}
	
	//set a view to displaye friends
	if(get_plugin_setting("show_friends", "riverdashboard") != "no")
	{
	        $area1 .= elgg_view("riverdashboard/friends");
	}
	
	//set a view to displaye find friends
	
	        $area1 .= elgg_view("riverdashboard/findfriends");
	
	
	//set a view to display newest members
	if(get_plugin_setting("show_newestmembers", "riverdashboard") != "no")
	{
		$area1 .= elgg_view("riverdashboard/newestmembers");
	}
	
	//set a view to display online friends
	$area1 .= elgg_view("riverdashboard/friendsonline");
	//set a view to display admin links
	$area1 .= elgg_view("riverdashboard/linksleft");
	//set a view to display links
	$area3 = elgg_view("riverdashboard/links");
	
	
	//set a view to display people from the neighborhood
	$area3 .= elgg_view("riverdashboard/pftn");
	
	
	//set a view to display newest members
		$area3 .= elgg_view("riverdashboard/events");
	
	
	if(get_plugin_setting("show_polls", "riverdashboard") != "no")
	{
	//set a view to display newest members
		$area3 .= elgg_view("riverdashboard/polls");
	}
	
	
	if(get_plugin_setting("show_bookmarks", "riverdashboard") != "no")
	{
	//set a view to display bookmarks
		$area3 .= elgg_view("riverdashboard/bookmarks");
	}	
	
	//set a view to display sitemessage
	if(get_plugin_setting("site_messages", "riverdashboard") != "no")
	{
		$area3 .= elgg_view("riverdashboard/sitemessage");
	}
	$area3 .= "
		<center>Designed By
	    	<a href='http://www.trendz.tk'>Deepak Bansal</a> and <a href='http://ishouvik.com/'>Shouvik Mukherjee</a><br /><br />
		</center>
		";
	//set a view to display advert
	if(get_plugin_setting("display_rightadvert", "riverdashboard") != "no")
	{
		$area3 .= elgg_view("riverdashboard/advert");
	}
	
	if(get_plugin_setting("show_thewire", "riverdashboard") != "no")
	{
	//set a view to display a welcome message
	$body .= elgg_view("riverdashboard/welcome");
	}

}
switch($orient) {
			case 'friends':	$subject_guid = $_SESSION['user']->guid;
							$relationship_type = 'friend';
							break;
			case 'mine':	$subject_guid = $_SESSION['user']->guid;
							$relationship_type = ''; 
							break;
			case 'all':		$subject_guid = 0;
							$relationship_type = '';
							break;
			default:		$subject_guid = $_SESSION['user']->guid;
							$relationship_type = 'friend';
							break;
}

$river = elgg_view_river_items($subject_guid, 0, $relationship_type, $type, $subtype, '');

// Replacing callback calls in the nav with something meaningless
$river = str_replace('callback=true', 'replaced=88,334', $river);

$nav = elgg_view('riverdashboard/nav',array(
		'type' => $type,
		'subtype' => $subtype,
		'orient' => $orient
));

$content = elgg_view('page_elements/contentwrapper', array('body' => $nav . $river));

if (empty($callback)) {
	// Add RSS support to page
	global $autofeed;
	$autofeed = true;

	// display page
	$body .= elgg_view('riverdashboard/container', array('body' => $content . elgg_view('riverdashboard/js')));
	page_draw($title, elgg_view_layout('river_boxes', $area1, $body , $area3));
} else {
	// ajax callback
	header("Content-type: text/html; charset=UTF-8");
	echo $content . elgg_view('riverdashboard/js');
}
