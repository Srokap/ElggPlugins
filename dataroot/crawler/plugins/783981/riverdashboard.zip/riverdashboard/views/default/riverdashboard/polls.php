<?php if(is_plugin_enabled('polls')){ ?>
<div class="collapsable_box">
	<div class="collapsable_box_header">
	<a href="javascript:void(0);" class="toggle_box_contents">-</a>
<h5><?php echo elgg_echo('polls') ?></h5>
</div>
<div class="collapsable_box_content">
<div class="sidebarBox">
    <div class="membersWrapper">
<?php

	//get the num of polls the user want to display
	$limit = get_plugin_setting('pollsToDisplay','riverdashboard');
	
	//the page owner
	$owner_guid = $vars['entity']->owner_guid;
	$owner = page_owner_entity();
	
	if($polls = get_entities('object','poll',0,'time_created desc',$limit,0,false,0)){
		$polls_ = array();		
		foreach($polls as $pollpost){
			if($pollpost->owner_guid != $owner_guid){
				echo elgg_view("polls/widget", array('entity' => $pollpost));
			}else{
				$polls_[] = $pollpost;
			}
		}	
	}
	
	if(count($polls_) >= count($polls))
	{
		echo "<div class=\"contentWrapper\">";
		echo "<p>" . elgg_echo("polls:widget:nonefound") . "</p>";	
		echo "</div>";
	}
		
?>
<div class="clearfloat">
</div>
<a href="<?php echo $vars['url']; ?>pg/polls/all/" class="viewall"><?php echo elgg_echo('viewall') ?></a>
<span style="color:#33339F;font-size:7pt"><b><a href="<?php echo $vars['url']; ?>pg/polls/add/<?php echo $_SESSION['user']->username; ?>"><?php echo elgg_echo('polls:add'); ?></a></b></span>

</div></div></div></div>
<?php } ?>
