<?php 
/**
 * Elgg riverdashboard links sidebar box
 * 
 * @package riverdashboard reloaded v1.3
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Deepak Bansal <www.trendz.tk>
 * @copyright Curverider Ltd 2008-2010
 * 
 */

?><div id="dashboard1">
<div id="dashboard_navigation">
<ul>

<?php if(is_plugin_enabled('tidypics')){ ?>
	<li>
	<a href="<?php echo $vars['url']; ?>pg/photos/owned/<?php echo $_SESSION['user']->username; ?>">
	<?php echo elgg_echo('photos'); ?></a> 
	<span style="color:#33339F;font-size:7pt">
	<a href="<?php echo $vars['url']; ?>pg/photos/new/<?php echo $_SESSION['user']->username; ?>">
	<?php echo elgg_echo('album:create') ?></a></span>
	</li>
<?php } ?>
<?php if(is_plugin_enabled('izap_videos')){ ?>
	<li>
	<a href="<?php echo $vars['url']; ?>pg/videos/list/<?php echo $_SESSION['user']->username; ?>">
    	<?php echo elgg_echo('videos'); ?></a> 
    	<span style="color:#33339F;font-size:7pt">
    	<a href="<?php echo $vars['url']; ?>pg/videos/add/<?php echo $_SESSION['user']->username; ?>">
    	<?php echo elgg_echo('izap_videos:add') ?></a>
	</li>
<?php } ?>
<?php if(is_plugin_enabled('blog')){ ?>
	<li>
	<a href="<?php echo $vars['url']; ?>pg/blog/owner/<?php echo $_SESSION['user']->username; ?>">
	<?php echo elgg_echo('blogs'); ?></a> 
	<span style="color:#33339F;font-size:7pt">
	<a href="<?php echo $vars['url']; ?>pg/blog/new/<?php echo $_SESSION['user']->username; ?>" title="Write a Blog Post">
	<?php echo elgg_echo('blog:newpost') ?></a></span>
	</li>
<?php } ?>
    </ul></div></div>