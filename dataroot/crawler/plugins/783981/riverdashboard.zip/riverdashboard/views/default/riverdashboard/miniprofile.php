<?php 
/**
 * Elgg riverdashboard mini-profile sidebar box
 * 
 * @package Riverdashboard Reloaded
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Deepak Bansal <www.anjaan.tk>
 * @copyright Curverider Ltd 2008-2010
 * @link http://www.trendz.tk/
 * 
 */

?>
<div id="dashboard1">
<table>
<tr>
<td>
<div id="river_avatar"> <!-- displayes user's avatar -->
  <a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>">  <img class="river_avatar" src="<?php echo get_loggedin_user()->getIcon('small'); ?>" alt="User avatar" />
</a></div> <!-- /river_avatar -->
 </td><td> <b>
<a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>"><?php 
		$name = '';
		if (isloggedin()) {
			$name = get_loggedin_user()->name;
			echo sprintf(elgg_echo('%s'), $name) . "<br />";
		}
    ?></a></b>
     <a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $_SESSION['user']->username; ?>/edit/">Edit My Proflie</a></li>
</td></tr></table>
</div> <!-- /dasboard1 -->
