<?php 
/**
 * Elgg riverdashboard friends element sidebar box
 * 
 * @package iShouvik Elgg River
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author iShouvik <contact@ishouvik.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://ishouvik.com/
 * 
 */

?>

<?php
if (is_plugin_enabled('friends_online')){
?>
<div class="collapsable_box">
	<div class="collapsable_box_header">
	<a href="javascript:void(0);" class="toggle_box_contents">-</a>

    <h5><?php echo elgg_echo('river:friendsonline') ?></h5></div>
    <div class="collapsable_box_content">
<div class="sidebarBox">
    <div class="membersWrapper">

<?php
	

$friends = $_SESSION['user']->getFriends("",1000);

$friends_online = 0;
	if (count($friends) > 0) 
	{
		foreach ($friends as $friend) 
		{
			if ($friend->last_action > time() - 200) 
			{		
				$icon = elgg_view("profile/icon", array('entity' => get_user($friend->guid), 'size' => 'tiny'));
				echo "<div class=\"friends_online\">\n";     
				echo $icon;
				echo "</div>\n";
				$friends_online++;
			} 
		} 
	}
	if ($friends_online == 0) 
	{
    //No Mates online
    echo elgg_echo('friends_online:nobodyonline');
	}
	

?>
<div class="clearfloat"></div>



   
    <div class="clearfloat"></div>
     <a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>" class="viewall"><?php echo elgg_echo('viewall') ?></a>
    </div>
</div> </div></div>

<?php } //closing groups enable condition ?>