<?php 
/**
 * Elgg riverdashboard friends element sidebar box
 * 
 * @package Riverdashboard Reloaded
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Deepak Bansal
 * @copyright Curverider Ltd 2008-2010
 * @link http://www.trendz.tk/
 * 
 */

?>

<div class="collapsable_box">
	<div class="collapsable_box_header">
	<a href="javascript:void(0);" class="toggle_box_contents">-</a>
    <h5><?php echo elgg_echo('friends') ?></h5></div>
    <div class="collapsable_box_content">
<div class="sidebarBox">
    <div class="membersWrapper">
        <?php
           // Get the number of friends to display
            $friendsToDisplay = get_plugin_setting('friendsToDisplay','riverdashboard');
                
        $friends = get_entities_from_relationship('friend',$_SESSION['guid'],false,'user','',0,'',$friendsToDisplay);
        
        foreach($friends as $friend) {
        echo "<div class=\"recentMember\" >";
        echo elgg_view("profile/icon",array('entity' => get_user($friend->guid), 'size' => 'small')) . "<br>";
        echo $entity->name;
        echo "</div>";
        }
        ?>
    
    <div class="clearfloat"></div>
    <a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>" class="viewall"><?php echo elgg_echo('viewall') ?></a>
    </div>
</div>
</div>
</div>


<br />
