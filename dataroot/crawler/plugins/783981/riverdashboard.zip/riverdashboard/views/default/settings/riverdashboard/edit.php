<?php
/**
 * iShouvik Riverdashboard view setings
 *
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider Ltd <info@elgg.com> and Shouvik Mukherjee <contact@ishouvik.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://ishouvik.com
 */
?>

<p>
	<?php echo elgg_echo('riverdashboard:useasdashboard'); ?>
	<select name="params[useasdashboard]">
		<option value="yes" <?php if ($vars['entity']->useasdashboard == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->useasdashboard != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
</p>
<p>
	<?php echo elgg_echo('riverdashboard:avataricon'); ?>
	<select name="params[avatar_icon]">
		<option value="icon" <?php if ($vars['entity']->avatar_icon == 'icon') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:icon'); ?></option>
		<option value="avatar" <?php if ($vars['entity']->avatar_icon == 'avatar') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:avatar'); ?></option>
	</select><br />


<!-- friends settings -->
<p>
        <?php echo elgg_echo('option:left:friends'); ?> 
        <select name="params[show_friends]">
                <option value="yes" <?php if ($vars['entity']->show_friends == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_friends != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select> &#xbb; 
        <?php echo elgg_echo('option:left:friends_num'); ?> 
        <select name="params[friendsToDisplay]">
		<option value="5" <?php if ($friendsToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="10" <?php if ($friendsToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
		<option value="15" <?php if ($friendsToDisplay == 15 || empty($friendsToDisplay)) echo " selected=\"yes\" "; ?>>15</option>
		<option value="20" <?php if ($friendsToDisplay == 20) echo " selected=\"yes\" "; ?>>20</option>
		<option value="25" <?php if ($friendsToDisplay == 25) echo " selected=\"yes\" "; ?>>25</option>
		<option value="30" <?php if ($friendsToDisplay == 30) echo " selected=\"yes\" "; ?>>30</option>
		<option value="35" <?php if ($friendsToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
		<option value="40" <?php if ($friendsToDisplay == 40) echo " selected=\"yes\" "; ?>>40</option>
		<option value="45" <?php if ($friendsToDisplay == 45) echo " selected=\"yes\" "; ?>>45</option>
		<option value="50" <?php if ($friendsToDisplay == 50) echo " selected=\"yes\" "; ?>>50</option>
	</select>
</p>
<!-- iZap profile visitors -->
<?php if(is_plugin_enabled('izap-profile-visitors')){ ?>
<p>
        <?php echo elgg_echo('option:left:recentvisitors'); ?> 
        <select name="params[recent_visitors]">
                <option value="yes" <?php if ($vars['entity']->recent_visitors == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->recent_visitors != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select> &#xbb; 
        <?php echo elgg_echo('option:left:recentvisitors_num'); ?> 
        <select name="params[visitorsToDisplay]">
		<option value="5" <?php if ($visitorsToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="10" <?php if ($visitorsToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
		<option value="15" <?php if ($visitorsToDisplay == 15 || empty($visitorsToDisplay)) echo " selected=\"yes\" "; ?>>15</option>
		<option value="20" <?php if ($visitorsToDisplay == 20) echo " selected=\"yes\" "; ?>>20</option>
		<option value="25" <?php if ($visitorsToDisplay == 25) echo " selected=\"yes\" "; ?>>25</option>
		<option value="30" <?php if ($visitorsToDisplay == 30) echo " selected=\"yes\" "; ?>>30</option>
		<option value="35" <?php if ($visitorsToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
		<option value="40" <?php if ($visitorsToDisplay == 40) echo " selected=\"yes\" "; ?>>40</option>
		<option value="45" <?php if ($visitorsToDisplay == 45) echo " selected=\"yes\" "; ?>>45</option>
		<option value="50" <?php if ($visitorsToDisplay == 50) echo " selected=\"yes\" "; ?>>50</option>
	</select>
<br />
</p>
<?php } // closing if iZap profile visitors enabled condition ?>

<?php if(is_plugin_enabled('polls')){ ?>
<p>
        <?php echo elgg_echo('option:left:polls'); ?> 
        <select name="params[show_polls]">
                <option value="yes" <?php if ($vars['entity']->show_polls == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->show_polls != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select> &#xbb; 
        <?php echo elgg_echo('option:left:polls_num'); ?> 
        <select name="params[pollsToDisplay]">
		<option value="5" <?php if ($pollsToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="10" <?php if ($pollsToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
		<option value="15" <?php if ($pollsToDisplay == 15 || empty($pollsToDisplay)) echo " selected=\"yes\" "; ?>>15</option>
		<option value="20" <?php if ($pollsToDisplay == 20) echo " selected=\"yes\" "; ?>>20</option>
		<option value="25" <?php if ($pollsToDisplay == 25) echo " selected=\"yes\" "; ?>>25</option>
		<option value="30" <?php if ($pollsToDisplay == 30) echo " selected=\"yes\" "; ?>>30</option>
		<option value="35" <?php if ($pollsToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
		<option value="40" <?php if ($pollsToDisplay == 40) echo " selected=\"yes\" "; ?>>40</option>
		<option value="45" <?php if ($pollsToDisplay == 45) echo " selected=\"yes\" "; ?>>45</option>
		<option value="50" <?php if ($pollsDisplay == 50) echo " selected=\"yes\" "; ?>>50</option>
	</select>

</p>

<br />
<?php } // closing if polls plugin enabled settings ?>
<hr color="silver" />

<?php if(is_plugin_enabled('thewire')){ ?>
<!-- The Wire -->
<p>
        <?php echo elgg_echo('option:middle:thewire'); ?>
        <select name="params[show_thewire]">
                <option value="yes" <?php if ($vars['entity']->show_thewire == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_thewire != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select>
</p>
<br />
<?php } // closing the wire enabled condition ?>

<p>
        <?php echo elgg_echo('option:middle:alltab'); ?>
        <select name="params[show_alltab]">
                <option value="yes" <?php if ($vars['entity']->show_alltab == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:middle:alltab:everyone'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_alltab != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:middle:alltab:admins'); ?></option>
        </select>
</p>
<br />
<!-- recent members -->
<p>
        <?php echo elgg_echo('option:right:newestmembers'); ?>
        <select name="params[show_newestmembers]">
                <option value="yes" <?php if ($vars['entity']->show_newestmembers == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_newestmembers != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select> &#xbb; 
        <?php echo elgg_echo('optiomn:right:newestmembers_num'); ?>
        <select name="params[memToDisplay]">
		<option value="7" <?php if ($memToDisplay == 7) echo " selected=\"yes\" "; ?>>7</option>
		<option value="14" <?php if ($memToDisplay == 14) echo " selected=\"yes\" "; ?>>14</option>
		<option value="21" <?php if ($memToDisplay == 21) echo " selected=\"yes\" "; ?>>21</option>
		<option value="28" <?php if ($memToDisplay == 28 || empty($memToDisplay)) echo " selected=\"yes\" "; ?>>28</option>
        <option value="35" <?php if ($memToDisplay == 35) echo " selected=\"yes\" "; ?>>35</option>
        <option value="42" <?php if ($memToDisplay == 42) echo " selected=\"yes\" "; ?>>42</option>
        <option value="49" <?php if ($memToDisplay == 49) echo " selected=\"yes\" "; ?>>49</option>
        <option value="56" <?php if ($memToDisplay == 56) echo " selected=\"yes\" "; ?>>56</option>
        <option value="63" <?php if ($memToDisplay == 63) echo " selected=\"yes\" "; ?>>63</option>
        <option value="70" <?php if ($memToDisplay == 70) echo " selected=\"yes\" "; ?>>70</option>
	</select>
</p>
<br />
<?php if(is_plugin_enabled('bookmarks')){ ?>
<p>
        <?php echo elgg_echo('option:right:bookmarks'); ?>
        <select name="params[show_bookmarks]">
                <option value="yes" <?php if ($vars['entity']->show_bookmarks == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->show_bookmarks != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
        </select> &#xbb; 
        <?php echo elgg_echo('option:right:bookmarks_num'); ?>
        <select name="params[bookmarksToDisplay]">
		<option value="3" <?php if ($bookmarksToDisplay == 3) echo " selected=\"yes\" "; ?>>3</option>
		<option value="5" <?php if ($bookmarksToDisplay == 5) echo " selected=\"yes\" "; ?>>5</option>
		<option value="10" <?php if ($bookmarksToDisplay == 10) echo " selected=\"yes\" "; ?>>10</option>
		<option value="15" <?php if ($bookmarksToDisplay == 15 || empty($memToDisplay)) echo " selected=\"yes\" "; ?>>15</option>
	</select>
</p>
<br />
<?php } // closing bookmark enable condition ?>


<!-- site messages -->
<p>
        <?php echo elgg_echo('option:left:siteaccountements'); ?> 
        <select name="params[site_messages]">
                <option value="yes" <?php if ($vars['entity']->site_messages == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->site_messages != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
 </p>
<br />


<!-- right advert box settings -->
<p>
       	<?php echo elgg_echo('option:right:advertbox'); ?> 
        <select name="params[display_rightadvert]">
                <option value="yes" <?php if ($vars['entity']->display_rightadvert == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
                <option value="no" <?php if ($vars['entity']->display_rightadvert != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
                </select>
         <br/><?php echo elgg_echo('option:right:advertbox:postcode') . elgg_view("riverdashboard/input/longtext", array("internalname"=>"params[rightadvert_content]", "value"=>$vars['entity']->rightads_code));?>
</p>
<br />

