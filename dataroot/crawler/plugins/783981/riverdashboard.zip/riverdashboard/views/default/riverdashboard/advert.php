<?php
		
$rightadvert_content = get_plugin_setting('rightadvert_content','riverdashboard');
	    echo $rightadvert_content;
?>

