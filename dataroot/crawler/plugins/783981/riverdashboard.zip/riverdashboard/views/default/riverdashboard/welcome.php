<?php

/**
 * Elgg Riverdashboard welcome message
 * 
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.com/
 * 
 */
 
?>

	<?php if(is_plugin_enabled('thewire')){ ?>
	
    	<?php

	/**
	 * Elgg thewire edit/add page
	 * 
	 * @package ElggTheWire
	 * 
	 */

		$wire_user = get_input('wire_username');
		if (!empty($wire_user)) { $msg = '@' . $wire_user . ' '; } else { $msg = ''; }

?>
<div class="dash_wire">
<div class="post_to_wire">

<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>

	<form action="<?php echo $vars['url']; ?>action/riverdashboard/wireadd" method="post" name="noteForm">
			<?php
			    $display .= "<textarea name='note' rows='1' cols='66' value='What's on your mind?' onKeyDown=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" onKeyUp=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" id=\"thewire_medium-textarea\">{$msg}</textarea>";
            $display .= "<div class='thewire_characters_remaining'><input readonly type=\"text\" name=\"remLen1\" size=\"3\" maxlength=\"3\" value=\"140\" class=\"thewire_characters_remaining_field\">";
                echo $display;
                echo elgg_echo("thewire:charleft") .     "</div>";
				echo elgg_view('input/securitytoken');
			?>&nbsp;
			<input type="hidden" name="method" value="site" />
			<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
	</form>

<?php echo elgg_view('input/urlshortener'); ?>
	
	<?php } // closing thewire enable condition ?>&nbsp;
	<div class="contentWrapper">
	<div id="elgg_horizontal_tabbed_nav">
	<ul>
	<?php if(is_plugin_enabled('messages')){ ?>
        <?php	 
    //need to be logged in to send a message
    gatekeeper();
    
    //get unread messages
    $num_messages = count_unread_messages();
    if($num_messages){
    	$num = $num_messages;
    }
    else {
    	$num = 0;
    }
    if($num == 0){
    ?>
    
    	<li><a href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo $_SESSION['user']->username; ?>">Messages</a></li>
        
    <?php }else{ ?>
    
    	<li><a href="<?php echo $vars['url']; ?>pg/messages/inbox/<?php echo $_SESSION['user']->username; ?>">Messages <span style="color:#33339F"><b>[<?php echo $num; ?>]</b></span></a></li>
        
    <?php } ?><?php } ?>
    <?php if(is_plugin_enabled('friend_request')){ 
    //need to be logged in to see friend requests
    gatekeeper();
    $user = get_loggedin_user();
    $count = get_entities_from_relationship('friendrequest', $user->guid, true, "", "", 0, "", 0, 0, true);
    if(empty($count)){
    ?>    
        
    <?php }else { ?>
    	
        <li><a href="<?php echo $vars['url']; ?>pg/friend_request/"> <span style="color:#33339F"><b>[<?php echo $count ?> <?php echo elgg_echo('friend_request:new') ?>]</b></span></a></li>
        
	<?php } ?><?php } ?><li><a href="<?php echo $vars['url']; ?>pg/settings/">
<?php echo elgg_echo('settings'); ?></a></li>
<?php if(is_plugin_enabled('groups')){ ?>
<li><a href="<?php echo $vars['url']; ?>pg/groups/member/<?php echo $_SESSION['user']->username; ?>"><?php echo elgg_echo('groups') ?></a>
</li><?php } ?>
<?php if(is_plugin_enabled('favorites')){ ?>
<li><a href="<?php echo $vars['url']; ?>pg/favorites/owner/<?php echo $_SESSION['user']->username; ?>"><?php echo elgg_echo('favorites') ?></a>
</li><?php } ?>

</ul></div></div></div></div>
<?php echo elgg_view_layout("two_column_left_sidebar_maincontent_boxes", '', $area2); ?>