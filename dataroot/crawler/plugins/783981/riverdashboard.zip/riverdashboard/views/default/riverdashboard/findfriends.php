<div class="collapsable_box">
    	<div class="collapsable_box_header">
	<a href="javascript:void(0);" class="toggle_box_contents">-</a>
	<h5><?php echo elgg_echo('friends:find') ?></h5></div>
	 <div class="collapsable_box_content">
<div class="sidebarBox">
    <div class="membersWrapper"><br />
    <?php

	/**
	 * Simple member search
	 **/

$tag_string = elgg_echo('members:search:tags');
$name_string = elgg_echo('members:search:name');

?>

<div class="sidebarBox">

<h3><?php echo elgg_echo('members:searchtag'); ?></h3>
<form id="memberssearchform" action="<?php echo $vars['url']; ?>pg/members/all/?" method="get">
	<input type="text" name="tag" value="<?php echo $tag_string; ?>" onclick="if (this.value=='<?php echo $tag_string; ?>') { this.value='' }" class="search_input" />
	<input type="hidden" name="filter" value="search_tags" />	
	<input type="submit" value="<?php echo elgg_echo('search:go'); ?>" />
</form>

<h3><?php echo elgg_echo('members:searchname'); ?></h3>
<form id="memberssearchform" action="<?php echo $vars['url']; ?>pg/members/all/?" method="get">
	<input type="text" name="tag" value="<?php echo $name_string; ?>" onclick="if (this.value=='<?php echo $name_string; ?>') { this.value='' }" class="search_input" />
	<input type="hidden" name="subtype" value="" />
	<input type="hidden" name="object" value="user" />
	<input type="hidden" name="filter" value="search" />	
	<input type="submit" value="<?php echo elgg_echo('search:go'); ?>" />
</form>
<?php if(is_plugin_enabled('invitefriends')){ ?><b>
<a href="<?php echo $vars['url']; ?>pg/invitefriends/" title="Invite Friends via E-mail"><?php echo elgg_echo('friends:invite') ?></a></b><?php } ?>
</div>
</div>
</div>
</div>
</div>