<?php if(is_plugin_enabled('event_calendar')){ ?>
<div class="collapsable_box">
	
	<div class="collapsable_box_header"><a href="javascript:void(0);" class="toggle_box_contents">-</a>
	
    <h5><?php echo elgg_echo('event_calendar:upcoming_events_title') ?></h5></div>
   <div class="collapsable_box_content"><div class="sidebarBox">
    <div class="membersWrapper">
    <?php

/**
 * Elgg event calendar widget
 *
 * @package event_calendar
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 *
 */

	// Load event calendar model
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/event_calendar/models/model.php");

    //the number of events to display
	$num = (int) $vars['entity']->num_display;
	if (!$num)
		$num = 5;
		
    // Get the events

	$events = event_calendar_get_personal_events_for_user(page_owner(),$num);
		
	// If there are any events to view, view them
	if (is_array($events) && sizeof($events) > 0) {

		echo "<div id=\"widget_calendar\">";

		foreach($events as $event) {
			echo elgg_view("object/event_calendar",array('entity' => $event));
		}

		echo "</div>";
			
    }
	
?>
<a href="<?php echo $vars['url']; ?>pg/event_calendar" class="viewall"><?php echo elgg_echo('viewall') ?></a><b>
<span style="font-size:7pt"> <a href="<?php echo $vars['url']; ?>pg/event_calendar/new/"><?php echo elgg_echo('event_calendar:new_event') ?></a></span>
</b>
</div>
</div>
</div>
</div>
<?php } ?>
