<?php if(is_plugin_enabled('bookmarks')){ ?>
<div class="collapsable_box">
	<div class="collapsable_box_header">
	<a href="javascript:void(0);" class="toggle_box_contents">-</a>
<h5><?php echo elgg_echo('bookmarks') ?></h5></div>
<div class="collapsable_box_content">
<div class="sidebarBox">
    <div class="membersWrapper">
<?php
$guid = $vars['entity']->guid;
?>
	<?php

		//get the num of shares the user want to display
		$num = $vars['entity']->num_display;

		//if no number has been set, default to 4
		if(!$num)
			$num = get_plugin_setting('bookmarksToDisplay','riverdashboard');;

		//grab the users bookmarked items
		$shares = elgg_get_entities(array('types' => 'object', 'subtypes' => 'bookmarks', 'container_guid' => $vars['entity']->owner_guid, 'limit' => $num, 'offset' =>  0));

		if($shares){

			foreach($shares as $s){

				//get the owner
				$owner = $s->getOwnerEntity();

				//get the time
				$friendlytime = elgg_view_friendly_time($s->time_created);

				//get the user icon
				$icon = elgg_view(
						"profile/icon", array(
										'entity' => $owner,
										'size' => 'tiny',
									)
					);

				//get the bookmark title
				$info = "<p class=\"shares_title\"><a href=\"{$s->getURL()}\">{$s->title}</a></p>";

				//get the user details
				$info .= "<p class=\"shares_timestamp\"><small><a href=\"{$owner->getURL()}\">{$owner->name}</a> {$friendlytime}</small></p>";

				//get the bookmark description
				if($s->description)
				//display
				echo "<div class=\"shares_widget_wrapper\">";
				echo "<div class=\"shares_widget_icon\">" . $icon . "</div>";
				echo "<div class=\"shares_widget_content\">" . $info . "</div>";
				echo "</div>";

			}

		}

	?>
  <a href="<?php echo $vars['url']; ?>pg/bookmarks/all/" class="viewall"><?php echo elgg_echo('viewall') ?></a> <span style="color:#33339F;font-size:7pt"><b><a href="<?php echo $vars['url']; ?>pg/bookmarks/add/<?php echo $_SESSION['user']->username; ?>"><?php echo elgg_echo('bookmarks:add'); ?></a></b></span>

</div>
 </div></div>
</div>
<?php } ?>
