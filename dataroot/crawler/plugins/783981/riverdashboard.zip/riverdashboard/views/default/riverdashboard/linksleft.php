<?php 
/**
 * Elgg riverdashboard links sidebar box
 * 
 * @package riverdashboard reloaded v1.3
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Deepak Bansal <www.trendz.tk>
 * @copyright Curverider Ltd 2008-2010
 * 
 */

?>
<div id="dashboard1">
<div id="dashboard_navigation">
<?php if (isadminloggedin()) { ?>
<ul>
<li><a href="<?php echo $vars['url']; ?>pg/admin/">Administration</a></li>
<?php } ?>
<?php if(is_plugin_enabled('faq')){ ?>
<li><a href="<?php echo $vars['url']; ?>pg/faq/">Help</a></li>
<?php } ?>
<li><a href="<?php echo $vars['url']; ?>action/logout">Sign Out</a></li>
</ul>
</div>
</div>