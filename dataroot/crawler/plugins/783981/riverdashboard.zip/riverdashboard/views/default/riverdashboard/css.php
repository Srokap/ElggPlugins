<?php

/**
 * Elgg riverdashboard CSS
 * 
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.org/
 */

?>
a.viewall {
	font-weight:bold;
}
.sidebarBox #thewire_sidebarInputBox {
	width:178px;
}
.sidebarBox .last_wirepost {
	margin:20px 0 20px 0;
}
.sidebarBox .last_wirepost .thewire-singlepage {
	margin:0;
}
.sidebarBox .last_wirepost .thewire-singlepage .thewire_options {
	display:none;
}
.sidebarBox .last_wirepost .thewire-singlepage .note_date {
	line-height: 1em;
	padding:3px 0 0 0;
	width:142px;
}
.sidebarBox .last_wirepost .thewire-singlepage .note_body {
	color:#666666;
	line-height: 1.2em;
}
.sidebarBox .last_wirepost .thewire-singlepage .thewire-post {
	background-position: 130px bottom;
}
.sidebarBox .thewire_characters_remaining {
	float:right;
}
.sidebarBox input.thewire_characters_remaining_field {
	background: #dedede;
}
.sidebarBox input.thewire_characters_remaining_field:focus {
	background: #dedede;
	border:none;
}
.sidebarBox input#thewire_submit_button {
	margin:2px 0 0 0;
	padding:2px 2px 1px 2px;
	height:auto;
}
.sidebarBox .membersWrapper {
	margin-bottom:20px;
	background: white;
	-webkit-border-radius: 5px; 
	-moz-border-radius: 5px;
	borer-radius: 5px;
	padding:7px;
    border:2px solid #dedede;	
}
.membersWrapper h3 {
	font-size:13px;
    font-weight:bold;
    border-bottom:8px;
}
.sidebarBox .membersWrapper .recentMember {
	margin:2px;
	float:left;
}
.sidebarBox .membersWrapper .recentMember .usericon img {
	width:25px;
	height:25px;
}
/* br necessary for ie6 & 7 */
.sidebarBox .membersWrapper br {
	height:0;
	line-height:0;
}
.welcomemessage {
	background:white;
}
.riverdashboard_filtermenu {
	margin:10px 0 10px 0;
}

.river_pagination .forward,
.river_pagination .back {
	display:block;
	float:left;
	border:1px solid #cccccc;
	color:#4690d6;
	text-align: center;
	font-size: 12px;
	font-weight: normal;
	margin:0 6px 0 0;
	padding:0 4px 1px 4px;
	cursor: pointer;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	border-radius: 4px;
}
.river_pagination .forward:hover,
.river_pagination .back:hover {
	background:#4690d6;
	color:white;
	text-decoration: none;
	border:1px solid #4690d6;
}
.river_pagination .back {
	margin:0 20px 0 0;
}
/* IE6 */
* html .river_pagination { margin-top:17px; }
/* IE7 */
*:first-child+html .river_pagination { margin-top:17px; }

/* activity widget */
.collapsable_box_content .river_item p {
	color:#333333;
}
.river_item {
	padding:20px 0 20px 0;
    border-bottom:1px solid #D8D8D8;
}

.collapsable_box_content .content_area_user_title h2 {
	font-size:1.25em;
	line-height:1.2em;
	margin:0;
	padding:0 0 2px 0;
	color:#4690d6;
}
.river_content img {
	margin:2px 0 2px 20px;
}

.river_content_display {
	border-left:1px solid #ddd;
	padding:2px 10px 0 10px;
	font-size:90%;
	margin:4px 0 2px 30px;
}

.river_content_display p {
	padding:0;
	margin:0;
}

.following_icon {
	width:20px;
	height:40px;
	margin:0 2px 0 2px;
	background: url(<?php echo $vars['url']; ?>mod/riverdashboard/graphics/follow_icon.png) no-repeat left top;
}
.river_content_display div.usericon a.icon img {
	width:40px;
	height:40px;
}


/* reply form */

#dash_wire {
	padding: 5px;
	margin: 0 0 15px 0;
}

textarea#thewire_large-textarea_dash {
	margin-top: 10px;
	width: 468px;
	height: 50px;
	padding: 6px;
	font-family: Arial, 'Trebuchet MS','Lucida Grande', sans-serif;
	font-size: 100%;
	color:#666666;
}
/* IE 6 fix */
* html textarea#thewire_large-textarea_dash { 
	width: 468px;
}
input.thewire_characters_remaining_field {
	background: transparent;
}
.post_to_wire {
	margin-left: 5px;
	padding: 5px;
	-webkit-border-radius: 0; 
	-moz-border-radius: 0;
    background: #F2F2F2;
    border-bottom: 1px solid #DBDBDB;
}
#dashboard1 {
	margin-bottom:20px;
}
#river_avatar {
	text-align:center;
    margin-bottom:20px;
}
img.river_avatar {
	padding:3px;
	border:1px solid #cccccc;
    text-align:center;
}
#lastloggedin {
	color:#777777;
    font-size:12px;
    font-weight:bold;
    text-align:center;
}
#dashboard_navigation {
	margin-top:20px;
    width:100%;
    font-size:12px;
}
#dashboard_navigation ul {
	margin:0 0 15px 0;
    padding:0;
}
#dashboard_navigation ul li {
	list-style:none;
	float:none;
	padding:5px;
    font-weight:bold;
    border-bottom:1px solid #cccccc;
    text-decoration:none;
}
#dashboard_navigation ul li:hover {
	background:#E5F6FF;
}

#dashboard_navigation ul li a {
    font-weight:bold;
    text-decoration:none;
}
.riverwire {
	margin:-18px 0 0 30px; padding:15px 15px 15px 30px;
    background: #fff7d3 url(<?php echo $vars['url']; ?>mod/riverdashboard/graphics/riverwire.gif) top left no-repeat;
}

#two_column_right_river_boxes {
	width:200px;
	margin:0 0 20px 0;
	min-height:360px;
	float:right;
	padding:0;
}
#two_column_left_river_maincontent_boxes {
	margin:0 0 20px 20px;
	padding:0 0 5px 0;
	width:518px;
	float:left ;
    background: white;
}
#two_column_left_river_boxes {
	width:200px;
	margin:0 0 20px 0px;
	min-height:360px;
	float:left;
	padding:0;
}

#system_messages {
	background:#ccffcc;
	color:#000000;
	padding:5px;
	margin-top:20px;
	width:inherit;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
    border-radius: 4px;
	border:4px solid #00CC00;
}

/* Activity Tabs */

#elgg_horizontal_tabbed_nav {
	border-bottom: 0;
}
#elgg_horizontal_tabbed_nav li {
	float: left;
	border: 0px solid #cccccc;
	border-bottom-width: 0;
	background: #eeeeee;
	margin: 0 0 0 10px;
	-moz-border-radius-topleft:0px;
	-moz-border-radius-topright:0px;
	-webkit-border-top-left-radius:0px;
	-webkit-border-top-right-radius:0px;
}
#elgg_horizontal_tabbed_nav a {
	color: #333333;
}
#elgg_horizontal_tabbed_nav .selected a, #elgg_horizontal_tabbed_nav a:hover {
	position: relative;
	top: 0px;
	background: #333333;
	color: white;
}
/* IE6 fix */
* html #elgg_horizontal_tabbed_nav .selected a { top: 1px; }

