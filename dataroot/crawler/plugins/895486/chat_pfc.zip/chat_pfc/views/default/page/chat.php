<?php

$chat = elgg_get_plugins_path() . 'chat_pfc/vendors/phpfreechat/index.php';

include $chat;

?>
