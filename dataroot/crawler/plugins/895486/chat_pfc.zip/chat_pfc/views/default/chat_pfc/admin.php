<?php

/*
 * Satheesh PM, BARC Mumbai
 * www.satheesh.anushaktinagar.net
 */

/*
 *  Admin CSS
 */


?>


/* ***************************************
	SETTINGS
*****************************************/

#chat_pfc-settings .elgg-input-text {
	width: 210px;
        margin-left:8px;
}
#chat_pfc-settings .elgg-input-tags {
	width: 350px;
        margin-left:8px;

        }


