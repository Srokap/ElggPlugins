<?php
/*
 * Satheesh PM, BARC Mumbai
 * www.satheesh.anushaktinagar.net
*/



$english = array(
'chat_pfc' => "Chat Room",
'chat_pfc:chat' => "Chat Room",
'chat_pfc:commands' => "Chat Commands",
'chat_pfc:list' =>'Chat Room List',
'chat_pfc:yes' => "Yes",
'chat_pfc:no' => "No",
'chat_pfc:title' => "Enter the title for your Chat Room ",
'chat_pfc:nikname' => "Allow Users to change their nick name while chatting",
'chat_pfc:theme' => "Please select a theme for Chat Room",
'chat_pfc:blune' => 'blune',
'chat_pfc:cerutti' => 'cerutti' ,
'chat_pfc:default' => 'default',
'chat_pfc:green' => 'green',
'chat_pfc:msn' => 'msn',
'chat_pfc:phoenity' =>  'phoenity',
'chat_pfc:phpbb2' => 'phpbb2',
'chat_pfc:zilveer' =>  'zilveer',
'chat_pfc:img' =>'Show Chat user avatar on click of the username',
'chat_pfc:maxlength' => "Enter the maximum text length for the chat message (Eg. 140)",
'chat_pfc:refresh' => "Enter the refresh delay for the chat room in milliseconds (Eg. 2000)",
'chat_pfc:max_msg' => "Maximum number of chat messages to display in the chat room (Eg. 15)",
'chat_pfc:max_room' => "Maximum number of chat rooms in which an user can chat simultainously (Eg. 10)",
'chat_pfc:max_pvt' => "Maximum number of private chat allowed per user (Eg. 5)",
'chat_pfc:rooms' =>'Enter the Room Names you want to list (Comma separated) (Eg. My Chat, Friends Chat, ect)',
'chat_pfc:hight' => "Enter the height of chat room (Eg. 300)",
'chat_pfc:isadmin' => "Should the first logged in user in chat room be an admin (only for chat) other than the normal ELGG Admins",
'chat_pfc:chat_info' => '<b>Please do the settings before you proceed to chat rooom</b><br />If you change the parameters later and to get changed parameters to work you need to enter the command "/rehash" in the chat room so that all cache will be removed and new parameter will be taken' ,
'chat_pfc:support' => '<font color="red">If this pluggin is useful for you, Please do a <a href="http://community.elgg.org/plugins/883207/1.8.5" target="_blank">recommendation for this pluggin</a> in Elgg community so that others can also find this plugin easily.</font> For Support please send a Message Through My <a href="http://satheesh.anushaktinagar.net" target="_blank"><font color="blue"><b>Personal website</b></font></a>'

);

add_translation("en",$english);
