<?php
/**
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 */

function customize_css_init() {
    $priority = 1000;
	elgg_extend_view('css/elgg','morgantitan_css/css', $priority);
							}
							
elgg_register_event_handler('init','system','customize_css_init');
?>