Theme: Morgantitan
 @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 @author Henner
 @copyright Henner 2012
  
This plugin comprises all changes I did to the default theme and some custom graphics. 
Matt Becket's Plugin "Customize CSS" served as a template for this Theme.

I modified the walled garden login page, which CSS is kept seperate. All other changes are done in the views/default/customize_css/css.php as suggested by Matt.

My thanks go out to:

Matt Beckett "http://community.elgg.org/pg/plugins/project/839775/developer/Beck24/customize-css"

Bryan Haapakangas (for the tile used as the top banner) "http://mitschwimmer.deviantart.com/#/d1fnxv"