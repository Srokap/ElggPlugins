<?php
/**
 * Walled garden CSS
 */

$url = elgg_get_site_url();

?>

.elgg-body-walledgarden {
	background: url(<?php echo elgg_get_site_url(); ?>/mod/morgantitan/_graphics/one_sidebar_background.jpg) repeat-y left top;	
	width: 950px;
	margin: 40px
}

.elgg-module-walledgarden {
	position: left;
	top: 50;
	left: 50;
	width: 860px;

}
.elgg-module-walledgarden > .elgg-head {
	height: 40px;
}
.elgg-module-walledgarden > .elgg-body {
	padding: 60 1px;
}
.elgg-module-walledgarden > .elgg-foot {
	height: 160px;
}

.elgg-col > .elgg-inner {
	margin: 0 0 0 5px;
}
.elgg-col:first-child > .elgg-inner {
	margin: 5 5px 0 0;
}
.elgg-col > .elgg-inner {
	padding: 0 8px;
}

.elgg-walledgarden-single > .elgg-body > .elgg-inner {
	padding: 0 8px;
}

.elgg-module-walledgarden-login {
	margin: 0;

}
.elgg-body-walledgarden h3 {
	color: #FFFFFF;
	font-size: 1em;
	line-height: 1.1em;
	padding-top: 120px;
	padding-bottom: 7px;
}

.elgg-heading-walledgarden {
	font-size: 3em;
	color: #666666;
	padding-top: 5px;
	margin-top: 0px;
	line-height: 1em;
}
