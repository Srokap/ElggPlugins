<?php
/**
 * Elgg Market Plugin
 * @author slyhne
 */

?>

.market-admin-input {
	width: 50px;
}

