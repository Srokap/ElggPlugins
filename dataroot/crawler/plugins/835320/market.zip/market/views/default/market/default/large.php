<?php
	echo elgg_get_site_url() . "mod/market/graphics/noimagelarge.png";
?>
