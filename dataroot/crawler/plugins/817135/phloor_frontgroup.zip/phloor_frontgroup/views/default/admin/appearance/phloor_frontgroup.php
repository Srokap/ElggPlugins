<?php

// only admins are allowed to see the page
admin_gatekeeper();

$title = elgg_view_title(elgg_echo('phloor_frontgroup:title')); 
$description = elgg_echo('phloor_frontgroup:description'); 

// get frongroups
$frontgroups = phloor_frontgoup_get_frontgroups();

$params = array(
	'list_class' => 'elgg-list-entity',
	'full_view' => false,
	'pagination' => true,
	'list_type' => 'list',
	'list_type_toggle' => true,
);

// list frontgroups
$frontgroup_list = elgg_view_entity_list($frontgroups, $params);

$content = $frontgroup_list;

// show a message if no frontgroups have been created
if(empty($content)) {
	$content = elgg_echo('phloor_frontgroup:nofrontgroup');
}

echo <<<___HTML
{$title}
<p>{$description}</p>
<div id="phloor-frontgroup-frontgroup-list">
{$content}
</div>
___HTML;











