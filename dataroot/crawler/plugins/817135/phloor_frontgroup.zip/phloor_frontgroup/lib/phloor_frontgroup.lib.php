<?php
include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

/**
 * determine if group is frontgroup
 * 
 * @return true if a group is a frontgroup
 */
function phloor_frontgoup_is_frontgroup($group) {
	return elgg_instanceof($group, 'group') && 
	       $group->phloor_frontgroup_enable == "yes";
}

/**
 * get all frontgroups
 * 
 * for now, lets restrict it to 999
 */
function phloor_frontgoup_get_frontgroups() {
	$frontgroups = elgg_get_entities_from_metadata(array(
			'type' => 'group',
			'metadata_name' => 'phloor_frontgroup_enable',
			'metadata_value' => "yes",
			'limit' =>	999,
	));
	
	return $frontgroups;
}

/**
 * determine if a user is member of a frontgroup
 * by looping through an array
 */
function phloor_frontgroup_is_member_of_frontgroup($user, $exclude_groups) {
	if(elgg_instanceof($user, 'user')) {
		$frontgroups = phloor_frontgoup_get_frontgroups();
		
		if(is_array($exclude_groups)) {
			$frontgorups = array_diff($frontgroups, $exclude_groups);
		}
		
		if($frontgroups) {
			foreach ($frontgroups as $group) {
				if(elgg_instanceof($group, 'group') && $group->isMember($user)) {
					return true;
				}
			}
		}
	}
	
	return false;
}

