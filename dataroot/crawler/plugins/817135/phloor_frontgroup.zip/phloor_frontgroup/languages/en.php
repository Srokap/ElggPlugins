<?php

$english = array(
	'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
	'phloor_frontgroup' => 'Phloor Frontgroup',
	'admin:appearance:phloor_frontgroup' => 'Frontgroups',

	'phloor_frontgroup:title' => 'Frontgroups',
	'phloor_frontgroup:description' => 'This is the Frontgroup overview page. ',

	'phloor_frontgroup:enablefrontgroup' => 'Make this group a \'Frontgroup\'',
	'phloor_frontgroup:nofrontgroup' => 'Currently there is no group defined as \'Frontgroup\'. ',
);

add_translation("en", $english);