<?php

$german = array(
	'admin:plugins:category:PHLOOR' => 'PHLOOR Plugins',
	'phloor_frontgroup' => 'Phloor Frontgroup',
	'admin:appearance:phloor_frontgroup' => 'Frontgroups',
	
	'phloor_frontgroup:title' => 'Frontgroups',
	'phloor_frontgroup:description' => 'Dies ist die Frontgroup-Überlickseite. ',

	'phloor_frontgroup:enablefrontgroup' => 'Diese Gruppe zu einer \'Frontgroup\' machen? ',
	'phloor_frontgroup:nofrontgroup' => 'Momentan ist keine Gruppe als \'Frontgroup\' definiert. ',
);

add_translation("de", $german);