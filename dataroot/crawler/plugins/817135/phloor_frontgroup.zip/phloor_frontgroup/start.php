<?php
/** 
 * Phloor Frontgroup
 *
 * @package Phloor
 */

elgg_register_event_handler('init',  'system', 'phloor_frontgroup_init', 1);

/**
 * 
 */
function phloor_frontgroup_init() {
	/**
	 * LIBRARY
	 * register a library of helper functions
	 */
	$lib_path = elgg_get_plugins_path() . 'phloor_frontgroup/lib/';
	elgg_register_library('phloor-frontgroup', $lib_path . 'phloor_frontgroup.lib.php');
	elgg_load_library('phloor-frontgroup');
	
	/**
	 * Admin menu
	 */
	elgg_register_admin_menu_item('configure', 'phloor_frontgroup', 'appearance');
	
	/**
	 * Group option
	 * activate frontgroup feature just for admins
	 */
	if(elgg_is_admin_logged_in()) {
		add_group_tool_option('phloor_frontgroup', elgg_echo('phloor_frontgroup:enablefrontgroup'), false);
	}

	/**
	 * Event handler
	 */
	elgg_register_event_handler('join', 'group', 'phloor_frontgroup_join_group');
	elgg_register_event_handler('leave', 'group', 'phloor_frontgroup_leave_group');
	elgg_register_event_handler('create', 'member', 'phloor_frontgroup_prevent_user_without_invite_from_joining');

	/**
	 * Plugin hooks
	 */
	elgg_register_plugin_hook_handler('access:collections:write', 'user', 'phloor_frontgroup_access_collections_write_user_hook');
}
	

/**
 * set attribute "phloor_frontgroup_user" to "yes" when a user
 * joins a frontgroup
 * 
 * @param unknown_type $event
 * @param unknown_type $type
 * @param unknown_type $params
 */
function phloor_frontgroup_join_group($event, $type, $params) {
	if($event == "join" && $type == "group") {
		$user = $params['user'];
		$group = $params['group'];

		if(elgg_instanceof($group, 'group') && elgg_instanceof($user, 'user')) {
			// if it is a "featured group" (only admin can set this)
			if(phloor_frontgoup_is_frontgroup($group) &&
			   $user->phloor_frontgroup_user != "yes") {
				$user->phloor_frontgroup_user = "yes";
			}
		}
	}
	
	return true;
}

/**
 * set attribute "phloor_frontgroup_user" to "no" when a user
 * leaves a frontgroup (except he is in other frontgroups as well)
 * 
 * @param unknown_type $event
 * @param unknown_type $type
 * @param unknown_type $params
 */
function phloor_frontgroup_leave_group($event, $type, $params) {
	if($event == "leave" && $type == "group") {
		$user = $params['user'];
		$group = $params['group'];

		if(elgg_instanceof($group, 'group') && elgg_instanceof($user, 'user')) {
			// if its a frontgroup and the user is a frontgroup user (obviously yes)..
			if(phloor_frontgoup_is_frontgroup($group) &&
			   $user->phloor_frontgroup_user == "yes") {
			   	// see if user is member of another frontgroup
			   	$exclude_groups = array($group);
				$memberOfAnotherFrontgroup = phloor_frontgroup_is_member_of_frontgroup($user, $exclude_groups);
			   	
				// if user is not member of another frongroup.. delete attribute
				if(!$memberOfAnotherFrontgroup) {
					$user->phloor_frontgroup_user = "no";
				}
			}
		}
	}
	
	return true;
}

/**
 * This function aborts the group join process
 * when i user tries to join a featured group without
 * an invitation.
 * 
 * @param unknown_type $event
 * @param unknown_type $type
 * @param unknown_type $object
 */
function phloor_frontgroup_prevent_user_without_invite_from_joining($event, $type, $object) {
	if($event == 'create' && $type == 'member') {
		if($object instanceof ElggRelationship) {
			$user_guid = $object->guid_one;
			$group_guid = $object->guid_two;
			
			$user = get_entity($user_guid);
			$group = get_entity($group_guid);
			
			if(phloor_frontgoup_is_frontgroup($group) &&
			   elgg_instanceof($user, 'user')) {
				$invited = check_entity_relationship($group->guid, 'invited', $user->guid);
				
				// if user is not invited and is not an admin
				// let the relationship be deleted by returning 'false'
				if (!$invited && !$user->isAdmin()) {
					return false;
				}
			}
		}
	}
	
	return true;
}

/**
 * unset public access for ordinary user
 * this is only allowed for frontgroup users
 * 
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_frontgroup_access_collections_write_user_hook($hook, $type, $return, $params) {	
	$user = get_user($params['user_id']);
	if(elgg_instanceof($user, 'user') && isset($return[ACCESS_PUBLIC])) {
		if(!$user->isAdmin() && $user->phloor_frontgroup_user != "yes") {
			// unset public access for ordinary user
			unset($return[ACCESS_PUBLIC]);
			return $return;
		}
	}
}