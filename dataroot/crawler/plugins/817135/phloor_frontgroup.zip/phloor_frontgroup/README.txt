/**
 * Phloor Frontgroup
 * 
 * @package phloor_frontgroup
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 11.11.16
Requires: Elgg 1.8 or higher


/**
 * Description
 */
This plugins lets administrators set groups as "Frontgroup".
Only user which are members of a frontgroup are able to post 
public stuff. For every other user the creation of object with 
access level 'public' is prohibited - thus they can only choose
between 'pivate', 'loggedin' or the groups ('group: <name>').

Please note, that a group has to be OPEN so that guests can see
their public content. If you are concerned about people just joining
this groups you can calm down: Although frontgroups may be 'open', users
can only join if they got an invitation.


/**
 * Languages
 */
English
German


