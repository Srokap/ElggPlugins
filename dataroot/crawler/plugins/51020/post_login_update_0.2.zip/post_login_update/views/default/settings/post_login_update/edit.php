<?php
	$auto_friend = $vars['entity']->auto_friend;
	if (!$auto_friend) $auto_friend = "admin"; //default is admin
?>
<p>
	<?php echo elgg_echo('Automatic Friend Username'); ?>
	<?php echo elgg_view('input/text', array('internalname' => 'params[auto_friend]', 'value' => $auto_friend)); ?>
</p>

<?php
	$login_message = $vars['entity']->login_message;
	if (!$login_message) $login_message = ""; //default is empty
?>
<p>
  <?php echo elgg_echo('Custom Login Message'); ?>
  <?php echo elgg_view('input/longtext', array('internalname' => 'params[login_message]', 'value' => $login_message)); ?>
</p>
