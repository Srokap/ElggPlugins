<?php
    /**
    * Post User Login Update Plugin
    *
    * @package ElggPostLoginUpdate
    * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
    * @author Prashant Juvekar
    * @copyright SocialTrak, 2009
    * @link http://www.socialtrak.com
    */
		
	function post_login_update_init(){
		global $CONFIG;
		register_elgg_event_handler('login', 'user', 'post_login_update_handler', 501);
	}

	function post_login_update_handler($event, $object_type, $object) {

		$user = $object;
		$username = $user->username;

		// read the plugin setting
		$auto_friend = get_plugin_setting( 'auto_friend','post_login_update' );
		if ( $auto_friend === false || empty($auto_friend) ) {
			$auto_friend = "admin"; //default is admin
		}
		$login_message = get_plugin_setting( 'login_message','post_login_update' );
		if ( $login_message === false ) {
			$login_message = ""; //default is empty
		}
		
		// ensure configured user is a friend for all site users
		if ( ($username != $auto_friend) && ($admin = get_user_by_username ($auto_friend)) ) {
		
			global $CONFIG;
			if(isset($CONFIG->events['create']['friend'])) {
				$oldEventHander = $CONFIG->events['create']['friend'];
				$CONFIG->events['create']['friend'] = array();			//Removes any event handlers
			}

			try {
				$user->addFriend ( $admin->guid );
			} catch(Exception $e) {}
			try {
				$admin->addFriend ( $user->guid );
			} catch(Exception $e) {}
			//system_message ( "Added " . $auto_friend . " as friend" );

			if(isset($CONFIG->events['create']['friend'])) {
				$CONFIG->events['create']['friend'] = $oldEventHander;
			}
		}
        
		// display configured login message
		system_message ( $login_message );
	}

	//register plugin initialization handler
	register_elgg_event_handler('init', 'system', 'post_login_update_init');

?>
