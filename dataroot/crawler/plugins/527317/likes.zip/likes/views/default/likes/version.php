<?php
	/**
	* likes
	*
	* @author Pedro Prez
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	*/

	$version = likes_get_version();
	$release = likes_get_version(true);
?>	

	<meta name="likes_comment_release" content="<?php echo $release; ?>" />
	<meta name="likes_comment_version" content="<?php echo $version; ?>" />