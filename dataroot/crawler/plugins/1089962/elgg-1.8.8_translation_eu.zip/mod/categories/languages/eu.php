<?php
$basque=array (
  'categories' => 'Atalak',
  'categories:settings' => 'Ezarri guneko atalak',
  'categories:explanation' => 'Gune osoan erabiliko diren atalak definitzeko, sartu hemen, komaz bananduta. Atal hauek, bateragarriak diren tresnek erakutsiko dituzte erabiltzaileak edukiak sortu edo editatzean dituenean.',
  'categories:save:success' => 'Guneko atalak ondo gorde dira.',
  'categories:results' => 'Gune atalarentzat emaitzak: %s',
  'categories:on_activate_reminder' => 'Gune atalak ez dira bistaratuko atalak sortu ezean. <a href="%s">Gehitu atalak orain.</a>',
);

add_translation("eu", $basque);