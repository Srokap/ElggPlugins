<?php
$basque=array (
  'expages' => 'Gune orriak',
  'admin:appearance:expages' => 'Gune orriak',
  'expages:about' => 'Honi buruz',
  'expages:terms' => 'Baldintzak',
  'expages:privacy' => 'Pribatutasuna',
  'expages:contact' => 'Kontaktua',
  'expages:notset' => 'Orri honek ez du ezarpenik oraindik.',
  'expages:posted' => 'Zure orria ongi eguneratu da.',
  'expages:error' => 'Ezin izan da orri hau gorde.',
);

add_translation("eu", $basque);