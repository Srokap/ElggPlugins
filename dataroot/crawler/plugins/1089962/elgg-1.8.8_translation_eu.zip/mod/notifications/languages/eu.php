<?php
$basque=array (
  'friends:all' => 'Lagun guztiak',
  'notifications:subscriptions:personal:description' => 'Jakinarazpenak jaso zure edukietan ekintzarik gertatuz gero.',
  'notifications:subscriptions:personal:title' => 'Jakinarazpen pertsonalak',
  'notifications:subscriptions:friends:title' => 'Lagunak',
  'notifications:subscriptions:friends:description' => 'Hurrengoa zure lagunekin automatikoki osatutako bilduma da. Jakinarazpenak jasotzeko, hautatu azpian. Honek orriaren azpialdean erakusten den jakinarazpen arbel nagusian eragina izango du hautatutako erabiltzaileengan. ',
  'notifications:subscriptions:collections:edit' => 'Zure partekatutako jakinarazpenak editatzeko, klik egin hemen.',
  'notifications:subscriptions:changesettings' => 'Jakinarazpenak',
  'notifications:subscriptions:changesettings:groups' => 'Talde jakinarazpenak',
  'notifications:subscriptions:title' => 'Jakinarazpenak erabiltzaileko',
  'notifications:subscriptions:description' => 'Zure lagunek eduki berria sortzean jakinarazpenak jaso nahi badituzu, bilatu itzazu hemen eta aukeratu jakinarazpenak jasotzeko modua.',
  'notifications:subscriptions:groups:description' => 'Taldekide zaren talde batean eduki berria gehitzean jakinarazpenak jaso nahi badituzu, bilatu taldea eta aukeratu jakinarazpenak jasotzeko modua.',
  'notifications:subscriptions:success' => 'Zure jakinarazpen ezarpenak gorde dira.',
);

add_translation("eu", $basque);