<?php
$basque=array (
  'logrotate:period' => 'Zein maiztasunez artxibatu behar da sistemaren loga?',
  'logrotate:weekly' => 'Astean behin',
  'logrotate:monthly' => 'Hilean behin',
  'logrotate:yearly' => 'Urtean behin',
  'logrotate:logrotated' => 'Loga biratua
',
  'logrotate:lognotrotated' => 'Errorea loga biratzean
',
  'logrotate:delete' => 'Ezabatu hau baino zaharrado diren artxibatutako logak: ',
  'logrotate:week' => 'astea',
  'logrotate:month' => 'hilabetea',
  'logrotate:year' => 'urtea',
  'logrotate:logdeleted' => 'Loga ezabatua
',
  'logrotate:lognotdeleted' => 'Errorea loga ezabatzean
',
);

add_translation("eu", $basque);