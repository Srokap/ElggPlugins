<?php
$basque=array (
  'twitter:title' => 'Twitter',
  'twitter:info' => 'Erakutsi zure azken tweetak',
  'twitter:username' => 'Zure twitter erabiltzailea sartu.',
  'twitter:num' => 'Erakutsiko diren tweet kopurua.',
  'twitter:visit' => 'Nire twitter bisitatu',
  'twitter:notset' => 'Twitter widget hau ez dago prest oraindik. Zure azken twitter mezuak erakusteko, editatu botoian klik egin eta bete zure datuak',
);

add_translation("eu", $basque);