<?php
$basque=array (
  'embed:embed' => 'Txertatu',
  'embed:media' => 'Edukia txertatu',
  'embed:instructions' => 'Klik egin edozein fitxategitan zure edukian txertatzeko.',
  'embed:upload' => 'Media igo',
  'embed:upload_type' => 'Igotzeko modua:',
  'embed:no_upload_content' => 'Ez igo edukirik!',
  'embed:no_section_content' => 'Ez da elementurik aurkitu.',
  'embed:no_sections' => 'Txertatzeko pluginik ez da aurkitu. Eskatu iezaiozu gune kudeatzaileari txertatzeko euskarria duen plugin bat aktibatzeko.',
);

add_translation("eu", $basque);