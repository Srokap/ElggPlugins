<?php
$basque=array (
  'members:label:newest' => 'Berrienak',
  'members:label:popular' => 'Ezagunenak',
  'members:label:online' => 'Online',
  'members:searchname' => 'Erabiltzaileak izenez bilatu',
  'members:searchtag' => 'Erabiltzaileak etiketa bidez bilatu',
  'members:title:searchname' => 'Erabiltzaile bilaketa %s-(r)entzat',
  'members:title:searchtag' => '%s etiketa duten erabiltzaileak',
);

add_translation("eu", $basque);