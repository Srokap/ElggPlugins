<?php
$basque=array (
  'messageboard:board' => 'Mezu-taula',
  'messageboard:messageboard' => 'mezu-taula',
  'messageboard:viewall' => 'Ikusi dena',
  'messageboard:postit' => 'Bidali',
  'messageboard:history:title' => 'Historia',
  'messageboard:none' => 'Oraindik ez dago ezer mezu-taula honetan',
  'messageboard:num_display' => 'Erakutsiko diren mezu kopurua',
  'messageboard:desc' => 'Hau zure profilean ipini dezakezun mezu-taula da, non beste erabiltzaileek iruzkinak idazteko aukera duten.',
  'messageboard:user' => '%s-(r)en mezu-taula',
  'messageboard:replyon' => 'Erantzuna hemen',
  'messageboard:history' => 'historikoa',
  'messageboard:owner' => '%s-(r)en mezu-taula',
  'messageboard:owner_history' => '%s-(r)en mezuak %s-(r)en mezu-taulan',
  'river:messageboard:user:default' => '%s-(e) mezua jarri du %s-(r)en mezu-taulan',
  'messageboard:posted' => 'Zure mezua mezu-taulara bidali da.',
  'messageboard:deleted' => 'Mezua ezabatu duzu.',
  'messageboard:email:subject' => 'Iruzkin berria duzu mezu-taulan!',
  'messageboard:email:body' => '%-(e)k iruzkin berria idatzi du zure mezu-taulan. Hau dio:

			
%s


Zure mezu-tauleko iruzkinak ikusteko egin klik hemen:

	%s

%s-(r)en profila ikusteko egin klik hemen:

	%s

Ez erantzun posta elektroniko honi.',
  'messageboard:blank' => 'Barkatu; zerbait idatzi behar duzu mezu gunean gorde ahal izateko.',
  'messageboard:notfound' => 'Barkatu; ezin izan dugu emandako elementua aurkitu.',
  'messageboard:notdeleted' => 'Barkatu; ezin izan dugu mezu hau ezabatu.',
  'messageboard:somethingwentwrong' => 'Zerbait gaizki joan da zure mezua gordetzerakoan, ziurtatu mezua ondo idatzi duzula.',
  'messageboard:failure' => 'Espero ez zen errore bat gertatu da mezua gehitzerakoan. Saiatu berriro, mesedez.',
);

add_translation("eu", $basque);