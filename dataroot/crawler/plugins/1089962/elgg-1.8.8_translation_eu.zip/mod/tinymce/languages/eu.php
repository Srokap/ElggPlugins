<?php
$basque=array (
  'tinymce:remove' => 'Editorea kendu',
  'tinymce:add' => 'Editorea jarri',
  'tinymce:word_count' => 'Hitz kopurua: ',
  'tinymce:lang_notice' => 'Zuren gunearen hizkuntza %s da baina ez dago instalaturik TinyMCEremtzat. Lortu <a target="_blank" href="%s">hemen</a> eta kopiatu hona %s. Ondoren, <a href="%s">katxeak hustu</a>. Irakurri TinyMCEren README fitxategia xehetasun gehiago jasotzeko.',
);

add_translation("eu", $basque);