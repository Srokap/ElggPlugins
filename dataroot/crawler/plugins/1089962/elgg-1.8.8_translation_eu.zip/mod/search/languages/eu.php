<?php
$basque=array (
  'search:enter_term' => 'Sartu bilaketarako hitza:',
  'search:no_results' => 'Emaitzarik ez.',
  'search:matched' => 'Aurkituak:',
  'search:results' => 'Emaitzak honentzat: %s',
  'search:no_query' => 'Mesedez, sartu bilatzeko hitza.',
  'search:search_error' => 'Errorea',
  'search:more' => '+%s gehiago %s',
  'search_types:tags' => 'Etiketak',
  'search_types:comments' => 'Iruzkinak',
  'search:comment_on' => 'Iruzkinak "%s"-(r)entzat',
  'search:comment_by' => 'egilea:',
  'search:unavailable_entity' => 'Enitate ez erabilgarria',
);

add_translation("eu", $basque);