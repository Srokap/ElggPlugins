<?php
$basque=array (
  'friends:invite' => 'Lagunak gonbidatu',
  'invitefriends:registration_disabled' => 'Erabiltzaile berrien erregistroa ezgaitu egin da gune honetan; ezin duzu erabiltzaile berririk gonbidatu.',
  'invitefriends:introduction' => 'Sare honetara lagunak gonbidatzeko, sartu beraien posta elektronikoak azpian (helbide bat lerroko):',
  'invitefriends:message' => 'Sartu zure lagunek jasoko duten gonbidapen testua:',
  'invitefriends:subject' => '%s-(e)n sartzeko gonbidapena',
  'invitefriends:success' => 'Zure lagunek gonbidatuak izan dira.',
  'invitefriends:invitations_sent' => 'Bidalitako gonbidapenak: %s. Arazo hauek eman dira:',
  'invitefriends:email_error' => 'Ondorengo helbide hauek ez dira egokiak: %s',
  'invitefriends:already_members' => 'Ondorengo hauek dagoeneko taldekide dira: %s',
  'invitefriends:noemails' => 'Ez da e-posta helbiderik sartu.',
  'invitefriends:message:default' => '
Kaixo,

Nire sarea den %s-(e)n sartzeko gonbida luzatu nahi dizut.',
  'invitefriends:email' => '
%s sarean sartzeko gonbidapena luzatu dizu %s -(e)k. Mezu hau bidali nahi dizu:

%s

Sartzeko, egin klik esteka honetan:

%s

Automatikoki zure lagun moduan ageriko da kontua sortzen duzunean.',
);

add_translation("eu", $basque);