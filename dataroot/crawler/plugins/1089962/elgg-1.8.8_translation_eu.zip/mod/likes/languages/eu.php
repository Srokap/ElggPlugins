<?php
$basque=array (
  'likes:this' => 'Gustokoa du',
  'likes:deleted' => 'Zure gustokoa ezabatu da',
  'likes:see' => 'Ikusi nork duen hau gustoko',
  'likes:remove' => 'Gustokoa kendu',
  'likes:notdeleted' => 'Zure gustokoa kentzerakoan arazoa egon da',
  'likes:likes' => 'Item hau gustokoa duzu orain',
  'likes:failure' => 'Item hau gustokoa duzula ezartzean arazoa egon da',
  'likes:alreadyliked' => 'Dagoeneko gustokoa duzu item hau',
  'likes:notfound' => 'Gustokoa bihurtu nahi duzun itema ezin da aurkitu',
  'likes:likethis' => 'Gustokoa egin',
  'likes:userlikedthis' => '%s-(e)k gustokoa du',
  'likes:userslikedthis' => '%s-(e)k gustokoa du',
  'likes:river:annotate' => 'gustokoak',
  'likes:delete:confirm' => 'Ziur zaude hau ez duzula jada gustuko?',
  'river:likes' => 'gustokoa %s %s',
  'likes:notifications:subject' => '%s-(e)k gustokoa du zure mezua: "%s"',
  'likes:notifications:body' => 'Kaixo %1$s,
  
%2$s-(e)k gustokoa du zure mezua: "%3$s" %4$s-(e)n

Ikusi zure jatorrizko mezua hemen:

%5$s

edo ikusi %2$s-(r)en profila hemen:

%6$s

Eskerrik asko,
%4$s
',
);

add_translation("eu", $basque);