<?php
$basque=array (
  'custom:bookmarks' => 'Azken laster-markak',
  'custom:groups' => 'Azken taldeak',
  'custom:files' => 'Azken fitxategiak',
  'custom:blogs' => 'Azken blog mezuak',
  'custom:members' => 'Erabiltzaile berrienak',
);

add_translation("eu", $basque);