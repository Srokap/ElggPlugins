<?php
$basque=array (
  'profile' => 'Profila',
  'profile:notfound' => 'Barkatu. Ezin izan dugu eskatutako profila aurkitu.',
);

add_translation("eu", $basque);