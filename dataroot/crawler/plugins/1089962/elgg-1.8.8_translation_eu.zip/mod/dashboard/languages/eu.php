<?php
$basque=array (
  'dashboard:widget:group:title' => 'Talde jarduera',
  'dashboard:widget:group:desc' => 'Zure talde batean eman den jarduna ikusi',
  'dashboard:widget:group:select' => 'Hautatu talde bat',
  'dashboard:widget:group:noactivity' => 'Ez dago jardunik talde honetan',
  'dashboard:widget:group:noselect' => 'Widget hau editatu talde bat hautatzeko',
);

add_translation("eu", $basque);