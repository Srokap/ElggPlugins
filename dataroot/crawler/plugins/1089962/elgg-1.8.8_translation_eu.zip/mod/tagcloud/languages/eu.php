<?php
$basque=array (
  'tagcloud:widget:title' => 'Etiketa Lainoa',
  'tagcloud:widget:description' => 'Etiketa lainoa',
  'tagcloud:widget:numtags' => 'Erakutsiko diren etiketa kopurua',
);

add_translation("eu", $basque);