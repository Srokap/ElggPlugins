<?php
$basque=array (
  'admin:administer_utilities:diagnostics' => 'Sistema Diagnostikoa',
  'diagnostics' => 'Sistema diagnostikoak',
  'diagnostics:report' => 'Diagnostiko Txostena',
  'diagnostics:description' => 'Ondorengo diagnostiko txostena erabilgarria da Elgg-en edozein arazo diagnostikatzeko eta akatsen baten berri ematen duzunean txertatzeko.',
  'diagnostics:download' => 'Deskargatu',
  'diagnostics:header' => '========================================================================
Elgg Diagnostiko Txostena
%s sotua %s-(e)k egina
========================================================================
			
',
  'diagnostics:report:basic' => '
Elgg %s argitalpena, %s bertsioa

------------------------------------------------------------------------',
  'diagnostics:report:php' => '
PHP informazioa:
%s
------------------------------------------------------------------------',
  'diagnostics:report:plugins' => '
Instalatutako pluginak eta xehetasunak:

%s
------------------------------------------------------------------------',
  'diagnostics:report:md5' => '
Instalatutako fitxategiak eta kontroleko baturak:

%s
------------------------------------------------------------------------',
  'diagnostics:report:globals' => '
Aldagai globalak:

%s
------------------------------------------------------------------------',
);

add_translation("eu", $basque);