<?php
$basque=array (
  'garbagecollector:period' => 'Zer maiztasunarekin exekutatu behar da Elgg-en zabor biltzailea?',
  'garbagecollector:weekly' => 'Astean behin',
  'garbagecollector:monthly' => 'Hilean behin',
  'garbagecollector:yearly' => 'Urtean behin',
  'garbagecollector' => 'ZABOR BILTZAILEA
',
  'garbagecollector:done' => 'EGINDA
',
  'garbagecollector:optimize' => '%s optimizatzen ',
  'garbagecollector:error' => 'ERROREA',
  'garbagecollector:ok' => 'ONDO',
  'garbagecollector:gc:metastrings' => 'Lotuta ez dauden metastring-ak garbitzen: ',
);

add_translation("eu", $basque);