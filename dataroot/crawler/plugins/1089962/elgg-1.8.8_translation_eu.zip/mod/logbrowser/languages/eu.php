<?php
$basque=array (
  'admin:administer_utilities:logbrowser' => 'Log nabigatzailea',
  'logbrowser' => 'Log nabigatzailea',
  'logbrowser:browse' => 'Sistemaren logean zehar nabigatu',
  'logbrowser:search' => 'Emaitzak findu',
  'logbrowser:user' => 'Bilaketarako erabiltzaile izena',
  'logbrowser:starttime' => 'Hasiera-data (adibidez "pasa den astelehenean", "orain dela ordu 1")',
  'logbrowser:endtime' => 'Bukaera-data',
  'logbrowser:explore' => 'Loga esploratu',
  'logbrowser:date' => 'Data eta ordua',
  'logbrowser:ip_address' => 'IP helbidea',
  'logbrowser:user:name' => 'Erabiltzailea',
  'logbrowser:user:guid' => 'Erabiltzailearen GUID',
  'logbrowser:object' => 'Objektu mota',
  'logbrowser:object:guid' => 'Objektuaren GUID',
  'logbrowser:action' => 'Ekintza',
  'logbrowser:no_result' => 'Emaitzik ez',
);

add_translation("eu", $basque);