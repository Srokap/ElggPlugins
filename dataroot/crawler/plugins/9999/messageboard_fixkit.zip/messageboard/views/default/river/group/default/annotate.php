<?php

   	$statement = $vars['statement'];
	$performed_by = $statement->getSubject();
	$owner = $statement->getObject();
    	
	$posterurl = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>"; 
	$ownerurl = "<a href=\"{$owner->getURL()}\">{$owner->name}</a>"; 
	$string = sprintf(elgg_echo("messageboard:river:posted"),$posterurl, $ownerurl) . " "; 

	echo $string; 
		
?>