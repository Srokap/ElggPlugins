<?php
	/**
	 * Elgg Message board: add message action
	 * 
	 * @package ElggMessageBoard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
	 */

	// Make sure we're logged in; forward to the front page if not
		if (!isloggedin()) forward();
		
	// Get input
		$message_content = get_input('message_content'); // the actual message
		$page_owner = get_input("pageOwner"); // the message board owner
		$object = get_entity($page_owner); // the message board owner's details
		
	// Let's see if we can get a user entity from the specified page_owner
		if ($object && !empty($message_content)) {
    		
			// If posting the comment was successful, say so
				if ($object->annotate('messageboard', $message_content,$object->access_id, $_SESSION['user']->getGUID())) {
					
					if ($object instanceof ElggGroup) {
					
						// We have a group. Notify the group-owner
						if ($object->guid != $_SESSION['user']->guid) {
							notify_user($object->owner_guid, $_SESSION['user']->guid, elgg_echo('messageboard:email:subject'), 
								sprintf(
										elgg_echo('messageboard:email:body'),
										$_SESSION['user']->name,
										$message_content,
										$CONFIG->wwwroot . "pg/messageboard/" . $object->username,
										$_SESSION['user']->name,
										$_SESSION['user']->getURL()
										)
						
							); 
							
						}
					} else {
						
						// We have an user. Notify the user
						if ($object->guid != $_SESSION['user']->guid) {
							notify_user($object->guid, $_SESSION['user']->guid, elgg_echo('messageboard:email:subject'), 
								sprintf(
										elgg_echo('messageboard:email:body'),
										$_SESSION['user']->name,
										$message_content,
										$CONFIG->wwwroot . "pg/messageboard/" . $object->username,
										$_SESSION['user']->name,
										$_SESSION['user']->getURL()
										)
						
							); 
						
						}
					}
					
					system_message(elgg_echo("messageboard:posted"));
					
			} else {
    				
				register_error(elgg_echo("messageboard:failure"));
					
			}
				
		//set the url to return the user to the correct message board
			$url = "pg/messageboard/" . $object->username;
				
		} else {
		
			register_error(elgg_echo("messageboard:blank"));
			
			//set the url to return the user to the correct message board
				$url = "pg/messageboard/" . $object->username;
			
		}
		
	// Forward back to the messageboard
		forward($url);

?>