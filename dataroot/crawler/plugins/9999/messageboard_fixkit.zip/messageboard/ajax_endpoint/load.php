<?php
    /**
	 * Elgg message board widget ajax logic page
	 *
	 * @package ElggMessageBoard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

    // Load Elgg engine will not include plugins
		require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
    
    
   	// Get input
		$message_content = get_input('messageboard_content'); // the actual message
		$page_owner = get_input("pageOwner"); // the message board owner
		$numToDisplay = get_input('numToDisplay'); // the number of messages to display
		$object = get_entity($page_owner); // the message board owner's details
		
	// Let's see if we can get a user entity from the specified page_owner
		if ($object && !empty($message_content)) {
    		
			// If posting the comment was successful, say so
				if ($object->annotate('messageboard', $message_content, $object->access_id, $_SESSION['user']->getGUID())) {
					
					global $CONFIG;
					
					if ($object instanceof ElggGroup) {
					
					
						// We have a group. Notify the group-owner
						if ($object->guid != $_SESSION['user']->guid) {
							notify_user($object->owner_guid, $_SESSION['user']->guid, elgg_echo('messageboard:email:subject'), 
								sprintf(
										elgg_echo('messageboard:email:body'),
										$_SESSION['user']->name,
										$message_content,
										$CONFIG->wwwroot . "pg/messageboard/" . $object->username,
										$_SESSION['user']->name,
										$_SESSION['user']->getURL()
										)
						
							); 
							
						}
					} else {
						
						// We have an user. Notify the user
						if ($object->guid != $_SESSION['user']->guid) {
							notify_user($object->guid, $_SESSION['user']->guid, elgg_echo('messageboard:email:subject'), 
								sprintf(
										elgg_echo('messageboard:email:body'),
										$_SESSION['user']->name,
										$message_content,
										$CONFIG->wwwroot . "pg/messageboard/" . $object->username,
										$_SESSION['user']->name,
										$_SESSION['user']->getURL()
										)
						
							); 
						
						}
					}
			} else {
    				
				register_error(elgg_echo("messageboard:failure"));
					
			}
		} else {
		
			register_error(elgg_echo("messageboard:blank"));
			
		}

    
    //step two - grab the latest messageboard contents, this will include the message above, unless an issue 
    //has occurred.
		$contents = $object->getAnnotations('messageboard', $numToDisplay, 0, 'desc'); 
    
    //step three - display the latest results
		if($contents){
        
			foreach($contents as $content) {
				
				echo elgg_view("messageboard/messageboard_content", array('annotation' => $content));
				
			}
        
		}

?>