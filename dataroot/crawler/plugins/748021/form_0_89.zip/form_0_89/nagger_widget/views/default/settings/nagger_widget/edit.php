<?php
$nagger_widget_fields = get_plugin_setting('fields', 'nagger_widget');
$body .= elgg_echo('nagger_widget:settings:fields:title');
$body .= '<br />';
$body .= elgg_view('form/input/longtext',array('internalname'=>'params[fields]','value'=>$nagger_widget_fields));

echo $body;
?>