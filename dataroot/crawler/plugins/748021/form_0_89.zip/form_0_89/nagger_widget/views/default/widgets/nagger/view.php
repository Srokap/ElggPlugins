<?php

/**
 * Elgg nagger widget
 *
 * @package workshops
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2010
 * @link http://radagast.biz/
 *
 */

// Load flexprofile model
require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))."/flexprofile/models/model.php");
$fields = trim(get_plugin_setting('fields', 'nagger_widget'));
$user = get_user($vars['entity']->owner_guid);
$form = flexprofile_get_profile_form($user);
$content = '';

if ($form && $fields && $user) {
		// make sure that we are using Unix line endings
		$fields = str_replace("\r\n","\n",$fields);
		$fields = str_replace("\r","\n",$fields);
		foreach(explode("\n",$fields) as $field) {
			$field = trim($field);
			if ($field == "_icon") {
				if (!$user->icontime) {
					$content .= '<li>'.elgg_echo('nagger_widget:icon').'</li>';
				}
			} else {
				$f = form_get_field_from_name($field);
				$value = trim($user->$field);
				if (!$value) {
					$content .= '<li>'.form_field_t($form,$f,'title').'</li>';
				}
			}
		}
}
echo "<div class=\"contentWrapper\">";
if ($content) {
	echo '<p>'.elgg_echo('nagger_widget:missing_intro').'</p>';
	echo '<ul>'.$content.'</ul>';
	if ($user->canEdit()) {

	?>
		<p class="profile_info_edit_buttons">
			<a href="<?php echo $vars['url']; ?>pg/profile/<?php echo $user->username; ?>/edit/"><?php echo elgg_echo("profile:edit"); ?></a>
		</p>
		<br />
	<?php

		}
	
} else {
	echo '<p>'.elgg_echo('nagger_widget:no_missing').'</p>';
}

echo "</div>";
	
?>