<?php

function nagger_widget_init() {
	add_widget_type('nagger',elgg_echo('nagger_widget:title'),elgg_echo('nagger_widget:description'));
}

register_elgg_event_handler('init','system','nagger_widget_init');
