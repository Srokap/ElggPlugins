<?php
$english = array(
	'nagger_widget:missing_intro' => "The following fields are missing from your profile. "
		."Please click on the edit profile button below and complete this information when you can.",
	'nagger_widget:no_missing' => "Your profile is now complete. Thank you for providing this information.",
	'nagger_widget:title' => "Profile reminder",
	'nagger_widget:description' => "Get reminders on profile fields to complete.",
	'nagger_widget:settings:fields:title' => "Internal names of fields to remind the user about (one per "
		." line). Use \"_icon\" to refer to the user profile image.",
	'nagger_widget:icon' => "Profile icon",
);
				
add_translation("en",$english);
?>
