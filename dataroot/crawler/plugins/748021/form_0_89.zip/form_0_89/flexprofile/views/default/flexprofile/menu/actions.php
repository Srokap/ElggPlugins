<?php
	echo "<p><a href=\"{$vars['url']}pg/flexprofile/{$vars['entity']->username}\">" . elgg_echo("form:extended_profile_link_text") . "</a></p>";
?>