/**
 * Manage registration form
 * 
 * @package flexreg
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2010
 * @link http://radagast.biz/
 * 
 */
 
 The flexreg plugin replaces the standard Elgg registration system with one 
 that works with the form and flexprofile plugins. You must have both the
 form and flexprofile plugins activated and above flexreg in plugin sequence
 in order to use it.
 
 If you have already used the form and flexprofile plugins to create a profile
 form, you can then create a related registration form.
 
 You can add fields to the registration form by using the "Existing field name"
 form in the "Add field" section when managing your registration form.
 
 These registration fields will then be added to the standard Elgg registration 
 fields (eg. email and password). The form description will also be added to
 the registration page if you choose to provide one.
 
 You can optionally provide a template for your registration form to allow
 a more elaborate design than is supported by the standard display. The
 templating language is described below.
 
 You can also specify that certain registration fields are required. If a user
 fails to provide values for these fields, the registration form will be
 redisplayed with a message explaining that these fields are required.
 
 (Note that required fields are only enforced on the registration form 
 currently, not on the user profile form, so that users will be able to delete 
 information which they provide at registration time.)
 
 Flexreg provides a number of additional features: registration moderation, 
 automatic groups, optional groups, automatic generation of user names from 
 display names (useful if your users  login using their email addresses and 
 don't care what their usernames are) and replacing the display name field on 
 the registration form with separate first name and last name fields.
 
 You can activate these features in the flexreg plugin area.
 
 More detailed descriptions of these features follow.
 
 *Registration moderation*
 
 If enabled, registrants are asked to confirm their email addresses and then
 are told that their account application has been submitted for approval by
 a moderator. A link is added to the left column in the admin area for
 reviewing the registration provided and either approving or rejecting these 
 applications. In the flexreg plugin settings you can optionally set an email
 address to alert a moderator to new account applications, as well as a
 detailed standard welcome message to be sent to approved users to orient them
 to your site.
 
 *Automatic groups*
 
 You can automatically sign users up to groups when they register by specifying
 their guids in the automatic groups box in the flexreg plugin settings.
 
 *Optional groups*
 
 You can add a checkbox list of optional groups to your register by specifying
 their guids in the optional groups box in the flexreg plugin settings. Users
 will be signed up to the groups they select.
 
 *Automatic generation of user names*
 
 Only use this if your users do not use their usernames to login.
 
 *First name and last name*
 
 The display name is constructed automatically by concatenating these
 fields with a space in between. Useful for a professional site that 
wants to encourage people to use their real names.

*Registration form templates*

The standard Elgg registration form is a bit plain, and you may want to
have a more elaborate layout, especially if you have a number of questions.

You can specify a full blown XHTML template when managing your registration
form by entering it in the Templates section.

If you have a field called "profile_field", you can then display its
associated values in the following way:

{$profile_field:t}

The title of your field.

{$profile_field:d}

The description of your field.

{$profile_field:i}

The input element of your field (text box, pulldown, etc.)

As with other form plugin templates, you also embed your own text or use

{@string_handle}

in your template to embed the text that would be produced by

elgg_echo('string_handle')

There are seven special fields:

_name
_email
_username
_password
_password2
_first_name
_last_name

You can access them in exactly the same way as your profile fields and the
standard text and form elements will be displayed.

You need to have activated the first name, last name feature to use the last
two special fields.

If you are creating a registration form template, don't forget to include
required fields (like _email, _password and _password2) or the registration will
always fail.
 
 
 
 