<?php

	$english = array(
	
	'flexreg:namemissing' => "You must supply a name.",
	'flexreg:email:confirm:success' => "You have confirmed your email address! A site moderator will review your application and you will be informed when your application is approved.",
	'flexreg:moderate_users_title' => "Moderate users",
	'flexreg:user:strapline' => "%s (%s) registered %s with email: %s",
	'flexreg:no_users_to_moderate' => "There are no users to moderate.",
	'flexreg:approve' => "Approve",
	'flexreg:reject' => "Reject",
	'flexreg:review' => "Review",
	'flexreg:extended_profile_title' => "Data for %s (%s)",
	'flexreg:error:body' => "An error has occurred. Please check the URL and try again.",
	'flexreg:error:title' => "Error",
	'flexreg:approve:confirm' => "You have approved this account.",
	'flexreg:reject:confirm' => "You have rejected this account.",
	'flexreg:moderate_title:approve' => "Approve account for %s (%s)",
	'flexreg:moderate_title:reject' => "Reject account for %s (%s)",
	'flexreg:moderate_description' => "Click the button below to confirm your decision. An email will be sent to notify this user.",
	'flexreg:moderate_description2' => "You can optionally add some additional text to the email message by entering it into the box below.",
	'flexreg:optional_groups' => "You can join any of the groups below by ticking the boxes next to their names.",
	'flexreg:notification_subject' => "%s has a new account application",
	'flexreg:notification_message' => "%s applied for an account for %s at %s.\n\nYou can review account applications by logging in as a site admin and visiting\n\n%s",
	'flexreg:first_name' => "First name",
	'flexreg:last_name' => "Last name",
	'flexreg:error:missing_code' => "Error: you have a missing or invalid registration code.",
	'flexreg:login_welcome' => "Welcome to %s!",
	'flexreg:initial_group_text' => "After registration you will be automatically subscribed to the group \"%s\".",
	
	// settings
	
	'flexreg:settings:optional_groups' => "Optional groups. You can provide registrants with checkboxes listing groups that they can subscribe to with one click when they register. "
	."Enter one group guid per line below.",
	
	'flexreg:settings:automatic_groups' => "Automatic groups. You can list one or more groups that registrants will automatically be subscribed to. "
	."Enter one group guid per line below.",
	
	'flexreg:settings:splitnames' => "Ask for first name and last name at registration time instead of display name.",
	'flexreg:settings:autousername' => "Automatically generate the username from the screen name rather than explicitly asking for one. (Best if the user is logging in using an email address.)",
	'flexreg:settings:unique_code:title' => "Require a unique registration code",
	'flexreg:settings:moderation' => "Registration moderation. If yes, accounts need to be approved by a site admin before they are activated.",
	
	'flexreg:settings:notifications_email' => "Notification address. If this is set below and registration moderation is turned on, "
		."this email address will be notified of every membership application.",
	'flexreg:settings:welcome_blurb' => "Welcome blurb. If registration moderation is turned on, the standard text below will "
		."be included in the welcome message sent to the user notifying them that their account application has been approved. ",
	
	// email messages
	
	'flexreg:approve:subject' => "Your account for %s has been approved!",
	'flexreg:approve:body' => "Hi %s,

Your account at %s has been approved and you can now login using the username and password you supplied.",

	'flexreg:reject:subject' => "Your account for %s has not been approved",
	'flexreg:reject:body' => "Hi %s,

Your account at %s has not been approved.",
	
	);
					
	add_translation("en",$english);

?>