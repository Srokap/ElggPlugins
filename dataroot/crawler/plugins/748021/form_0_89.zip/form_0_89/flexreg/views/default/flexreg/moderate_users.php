<?php
/**
 * View to list unmoderated users
 * 
 * @package flexreg
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2009
 * @link http://radagast.biz/
 */

$user_list = $vars['user_list'];
$nav = elgg_view('navigation/pagination',array(
	
			'baseurl' => $vars['baseurl'],
			'offset' => $vars['offset'],
			'count' => $vars['count'],
			'limit' => $vars['limit'],
	
));

echo $nav;
if ($user_list) {
	foreach ($user_list as $user) {
		$icon = elgg_view(
				'graphics/icon', array(
				'entity' => $user,
				'size' => 'small',
			));
		$usertxt = "<b>" . $user->name ."</b>";
		$reviewbit = '<br /><a href="'.$vars['url'].'mod/flexreg/profile.php?username='.$user->username.'">'.elgg_echo('flexreg:review').'</a>';
		
		$info = "<div>".sprintf(elgg_echo("flexreg:user:strapline"),
						$usertxt,
						$user->username,
						friendly_time($user->time_created),
						$user->email
		).$reviewbit."</div>";
		
		echo elgg_view_listing($icon, $info);

	}
} else {
	echo elgg_echo('flexreg:no_users_to_moderate');
}
echo $nav;
?>