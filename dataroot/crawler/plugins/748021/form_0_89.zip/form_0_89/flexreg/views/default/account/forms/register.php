<?php

     /**
	 * Elgg register form
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 */

// Load plugin model
require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/models/model.php");

// the invite_code and the registration code are treated differently as the registration code 
// is about restricting registration to certain people and the invite code is about friends
$registration_code = '';
$flexreg_unique_code = get_plugin_setting('unique_code', 'flexreg') == 'yes';
if ($flexreg_unique_code) {
	$error = true;
	$code = trim(get_input('code'));
	if ($code) {
		$entities = get_entities_from_metadata('code',$code,'object','registration_code');
		if ($entities) {
			$error = false;
		}
	}
	
	if ($error) {
		register_error(elgg_echo('flexreg:error:missing_code'));
		forward();
		exit;
	}
}

// get the guid for the initiating group, if any
$initial_group_guid = 0;
$initial_group_text = '';
$mid = (int) get_input('mid',0);
if ($mid) {
	$message = get_entity($mid);
	if ($message && $message->getSubtype() == 'bulk_invite_message') {
		$autogroup_guid = $message->group_guid;
		if ($autogroup_guid) {
			$autogroup = get_entity($autogroup_guid);
			if ($autogroup && $autogroup instanceOf ElggGroup) {
				$initial_group_guid = $autogroup_guid;
				$initial_group_text = sprintf(elgg_echo('flexreg:initial_group_text'),$autogroup->name);
				$initial_group_text = "<p>$initial_group_text</p>";
			}
		}
	}
}

$reg_html = '';
$reg_description = '';
$reg_form = flexreg_get_registration_form();
if ($reg_form) {
	if (trim($reg_form->description)) {
		$reg_description = '<p>'.$reg_form->description.'</p>';
	}
	$data = $vars['data'];
	if ($data) {
		// this is a form redisplay (because of an error), so pre-populate the form
		$reg_html = flexreg_get_html_from_registration_form($reg_form,$data);
	} else {
		$reg_html = flexreg_get_html_from_registration_form($reg_form);
	}
	$reg_html .= elgg_view('input/hidden', array('internalname' => 'form_id', 'value' => $reg_form->getGUID()));
}

// add initial group notification, if any
$reg_html .= $initial_group_text;

// Add checkboxes for optional groups, if defined

$flexreg_optional_groups = get_plugin_setting('optional_groups', 'flexreg');
if (trim($flexreg_optional_groups)) {
	// make sure that we are using Unix line endings
	$flexreg_optional_groups = str_replace("\r\n","\n",$flexreg_optional_groups);
	$flexreg_optional_groups = str_replace("\r","\n",$flexreg_optional_groups);
	$group_list = explode("\n",trim($flexreg_optional_groups));
	$options = array();
	foreach($group_list as $group_guid) {
		// the user is automatically added to an initiating group, so don't list it here
		if ($group_guid != $initial_group_guid) {
			$group = get_entity($group_guid);
			if ($group) {
				$options[$group->name] = $group_guid;
			}
		}
	}
	$reg_html .= '<label>'. elgg_echo('flexreg:optional_groups').'<br /><br />';
	$reg_html .= elgg_view('input/checkboxes',array('internalname'=>'optional_groups','options'=>$options,'value'=>$vars['optional_groups']));
	$reg_html .= '</label>';
}
	
// add extra fields if any
$form_body = $reg_html;

// Add captcha hook
$form_body .= elgg_view('input/captcha');

$admin_option = false;
if (($_SESSION['user']->admin) && ($vars['show_admin'])) 
	$admin_option = true;

if ($admin_option)
	$form_body .= elgg_view('input/checkboxes', array('internalname' => "admin", 'options' => array(elgg_echo('admin_option'))));

$form_body .= elgg_view('input/hidden', array('internalname' => 'mid', 'value' => $mid));
$form_body .= elgg_view('input/hidden', array('internalname' => 'friend_guid', 'value' => $vars['friend_guid']));
$form_body .= elgg_view('input/hidden', array('internalname' => 'code', 'value' => $code));
$form_body .= elgg_view('input/hidden', array('internalname' => 'invitecode', 'value' => $vars['invitecode']));
$form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'register'));
$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('register'))) . "</p>";

$content = '<div id="register-box">';
$content .= '<h2>'.elgg_echo('register').'</h2>';
$content .= $reg_description;
$content .= elgg_view('input/form', array('action' => "{$vars['url']}action/register", 'body' => $form_body));
$content .= '</div> <!-- /register-box -->';

echo $content;