<?php
/**
 * Elgg flexreg profile review view
 * 
 * @package flexreg
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2009
 * @link http://radagast.biz/
 */

$decision = $vars['decision'];
$body = elgg_view('input/hidden',array('internalname'=>'user_guid','value'=>$vars['user_guid']));
$body .= elgg_view('input/hidden',array('internalname'=>'decision','value'=>$decision));
$body .= elgg_view('form/input/longtext',array('internalname'=>'extra_message'));
$body .= elgg_view('input/submit',array('value'=>elgg_echo('flexreg:'.$decision)));

$body = elgg_view('input/form',array('action'=>$vars['url'].'action/flexreg/moderate','body'=>$body));

$md = '<p>'.elgg_echo('flexreg:moderate_description').'</p>';
$md2 = '<p>'.elgg_echo('flexreg:moderate_description2').'</p>';
echo $md.$md2.$body;
?>