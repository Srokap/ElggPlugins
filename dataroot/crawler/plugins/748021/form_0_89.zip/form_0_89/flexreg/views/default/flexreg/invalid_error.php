<?php

/**
    * Elgg display invalid fields message
    * 
    * @package Elgg
    * @subpackage Form
    * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
    * @author Kevin Jardine <kevin@radagast.biz>
    * @copyright Radagast Solutions 2008
    * @link http://radagast.biz/
    */
    
    $missing = $vars['invalid'];
    $labels = array();
    foreach($missing as $field) {
        $labels[] = $field->title;
    }    
    
    print sprintf(elgg_echo('form:error_missing_fields'),implode(', ',$labels));
?>