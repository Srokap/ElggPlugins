<?php
$options = array(elgg_echo('form:yes')=>'yes',
	elgg_echo('form:no')=>'no',
);

$flexreg_optional_groups = get_plugin_setting('optional_groups', 'flexreg');

$body .= elgg_echo('flexreg:settings:optional_groups');
$body .= '<br /><br />';
$body .= elgg_view('form/input/longtext',array('internalname'=>'params[optional_groups]','value'=>$flexreg_optional_groups));

$body .= '<br /><br />';

$flexreg_automatic_groups = get_plugin_setting('automatic_groups', 'flexreg');

$body .= elgg_echo('flexreg:settings:automatic_groups');
$body .= '<br /><br />';
$body .= elgg_view('form/input/longtext',array('internalname'=>'params[automatic_groups]','value'=>$flexreg_automatic_groups));

$body .= '<br /><br />';

$flexreg_splitnames = get_plugin_setting('splitnames', 'flexreg');

if (!$flexreg_splitnames) {
	$flexreg_splitnames = 'no';
}

$body .= elgg_echo('flexreg:settings:splitnames');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[splitnames]','value'=>$flexreg_splitnames,'options'=>$options));

$body .= '<br />';

$flexreg_autousername = get_plugin_setting('autousername', 'flexreg');

if (!$flexreg_autousername) {
	$flexreg_autousername = 'no';
}

$body .= elgg_echo('flexreg:settings:autousername');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[autousername]','value'=>$flexreg_autousername,'options'=>$options));

$body .= '<br />';

$flexreg_unique_code = get_plugin_setting('unique_code', 'flexreg');
if (!$flexreg_unique_code) {
	$flexreg_unique_code = 'no';
}

$body .= elgg_echo('flexreg:settings:unique_code:title');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[unique_code]','value'=>$flexreg_unique_code,'options'=>$options));

$body .= '<br />';

$flexreg_moderation = get_plugin_setting('moderation', 'flexreg');

if (!$flexreg_moderation) {
	$flexreg_moderation = 'no';
}

$body .= elgg_echo('flexreg:settings:moderation');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[moderation]','value'=>$flexreg_moderation,'options'=>$options));

$body .= '<br />';

$flexreg_notifications_email = get_plugin_setting('notifications_email', 'flexreg');

$body .= elgg_echo('flexreg:settings:notifications_email');
$body .= '<br /><br />';
$body .= elgg_view('input/text',array('internalname'=>'params[notifications_email]','value'=>$flexreg_notifications_email));

$body .= '<br /><br />';

$flexreg_welcome_blurb = get_plugin_setting('welcome_blurb', 'flexreg');

$body .= elgg_echo('flexreg:settings:welcome_blurb');
$body .= '<br /><br />';
$body .= elgg_view('form/input/longtext',array('internalname'=>'params[welcome_blurb]','value'=>$flexreg_welcome_blurb));

echo $body;
?>