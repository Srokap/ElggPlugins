<?php
/**
 * Elgg flexreg profile review page
 * 
 * @package flexreg
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2009
 * @link http://radagast.biz/
 */

// Get the Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

global $CONFIG;

admin_gatekeeper();

// Get the username
$username = get_input('username');

$access_status = access_get_show_hidden_status();
access_show_hidden_entities(true);

// Define context
set_context('flexreg');

$user = get_user_by_username($username);
add_submenu_item(elgg_echo('flexreg:approve'),$CONFIG->wwwroot.'mod/flexreg/moderate.php?guid='.$user->guid.'&decision=approve');
add_submenu_item(elgg_echo('flexreg:reject'),$CONFIG->wwwroot.'mod/flexreg/moderate.php?guid='.$user->guid.'&decision=reject');
add_submenu_item(elgg_echo('flexreg:moderate_users_title'),$CONFIG->wwwroot.'mod/flexreg/moderate_users.php');

$body = elgg_view('flexprofile/extended',array('entity'=>$user));

$title = sprintf(elgg_echo('flexreg:extended_profile_title'),$user->name, $username);

page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));
		
access_show_hidden_entities($access_status);
		
?>