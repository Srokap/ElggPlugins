<?php
require_once(dirname(dirname(dirname(__FILE__))).'/form/models/form_types.php');

function flexreg_get_registration_form() {
    $form_array = get_entities_from_metadata('profile',FORM_REGISTRATION,'object','form:form');
    if ($form_array) {
    	return $form_array[0];
    } else {
    	return false;
    }
}

function flexreg_get_html_from_registration_form($form,$data=null) {
	$html = '';
	if ($form->form_template) {
		$results = form_get_data_for_templated_edit_form($form,$data,true);
		//TODO: figure out what to do with $results['extra']
		return form_render_form_template($form,$results['fields']);
		//$html = form_apply_template_to_form_fields($form,$results);
	} else {
		// we currently don't support tabs on the registration form, so just 
		// concatenate the html for each tab
		$form_tabs = form_get_data_for_edit_form($form,$data,true);
		$tabs = $form_tabs['main'];
		if ($tabs) {
			$html = '';
			foreach ($tabs as $tab) {
				$html .= $tab;
			}
		}
		if (isset($form_tabs['extra']) && is_array($form_tabs['extra'])) {
			foreach ($form_tabs['extra'] as $tab) {
				$html .= $tab;
			}
		}
		$html = flexreg_get_standard_fields(true).$html;
	}
	
	return $html;
}

function flexreg_validate_form() {
	$form_field_types = form_get_form_field_types();	
	$data = array();
	$result = new StdClass();
    $result->error_status = false;
	$result->missing = array();
	$result->invalid = array();
	$form_id = get_input('form_id',0);
	if ($form_id) {
		$fields = form_get_fields($form_id);
		if ($fields) {
			foreach($fields as $field) {
				$internal_name = $field->internal_name;
				$item = new StdClass();
				$item->access_id = form_get_default_access($field);
				$value = get_input('form_data_'.$internal_name,'');
				if ($value) {
					if ($field->field_type == 'tags') {
						$item->value = string_to_tag_array($value);
					} else {
						$item->value = $value;
					}
				}
				$vf = $form_field_types[$field->field_type]->validation_function;
				if ($field->required && (trim($value) === '')) {
	                $result->error_status = true;
	                $result->missing[] = $field;
	            } else if ($vf && function_exists($vf)) {
	            	$vf_result = $vf($value);
	            	if (!$vf_result) {
	            		$result->invalid[] = $field;
	            		$result->error_status = true;
	            	} else if ($vf_result !== true) {
	            		// an error message
	            		register_error($vf_result);
	            		$result->error_status = true;
	            	}
	            }
	            $data[$internal_name] = $item;
			}			
		}
	}
	
	$result->form_data = $data;
	
	if ($result->error_status) {
		$bad_fields = array_merge($result->missing,$result->invalid);
		register_error(elgg_view('flexreg/invalid_error',array('invalid'=>$bad_fields)));
	}
	
	return $result;
}

// the following function was created to do better error reporting
// than register_user (plus we can validate the information separately before registration)

function flexreg_validate_basic_user_data($username, $password, $name, $email, $allow_multiple_emails = false) {
	global $CONFIG;
	
	$username = trim($username);
	$password = trim($password);
	$name = trim($name);
	$email = trim($email);
	
	$valid = true;
		
	if (empty($name)) {
		register_error(elgg_echo('flexreg:namemissing'));
		$valid = false;
	}	
	
	// Need to be able to compare with potentially disabled users
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);
		
	try {
		// Validate email address
		if (empty($email) || !validate_email_address($email)) {
			register_error(elgg_echo('registration:emailnotvalid'));
			$valid = false;
		}
	
		// Validate password
		if (empty($password) || !validate_password($password)) {
			register_error(elgg_echo('registration:passwordnotvalid'));
			$valid = false;
		}
		
		// Validate the username if not autousername
		$autousername = get_plugin_setting('autousername', 'flexreg') == 'yes';
		if (!$autousername) {
			if (empty($username) || !validate_username($username)) {
				register_error(elgg_echo('registration:usernamenotvalid'));
				$valid = false;
			}
		}
	} catch (RegistrationException $r) {
		register_error($r->getMessage());
		$valid = false;
	}
		
	// Check to see if $username exists already
	if ($valid && ($user = get_user_by_username($username))) {
		//return false;
		register_error(elgg_echo('registration:userexists'));
		$valid = false;
	}
	
	// If we're not allowed multiple emails then see if this address has been used before
	if ($valid && (!$allow_multiple_emails) && (get_user_by_email($email)))
	{
		register_error(elgg_echo('registration:dupeemail'));
		$valid = false;
	}
	
	access_show_hidden_entities($access_status);
	
	return $valid;
}

/**
 * A function that returns a maximum of $limit unmoderated users.
 * These are defined to be users who are validated but disabled.
 *
 * @param int $limit Limit, default 10.
 * @param int $offset Offset, default 0.
 */
function flexreg_get_unmoderated_users($limit = 10, $offset = 0) {
	global $CONFIG;
	
	$meta_n = get_metastring_id('validated_method');
	$value_n = get_metastring_id('email');
	
	if (!$meta_n || !$value_n) return false;
	
	$query =<<<END
SELECT DISTINCT e.* FROM 
{$CONFIG->dbprefix}entities e 
JOIN {$CONFIG->dbprefix}users_entity u ON (e.guid = u.guid)
JOIN {$CONFIG->dbprefix}metadata md ON (e.guid = md.entity_guid)
WHERE e.enabled = 'no'
AND md.name_id = $meta_n
AND md.value_id = $value_n
ORDER BY e.guid DESC
limit {$offset},{$limit}
END;
	
	return get_data($query, "entity_row_to_elggstar");
}

function flexreg_count_unmoderated_users() {
	
		global $CONFIG;
		
		$meta_n = get_metastring_id('validated_method');
		$value_n = get_metastring_id('email');
	
	if (!$meta_n || !$value_n) return 0;
	
	$query =<<<END
SELECT count(DISTINCT e.guid) AS count FROM 
{$CONFIG->dbprefix}entities e 
JOIN {$CONFIG->dbprefix}users_entity u ON (e.guid = u.guid)
JOIN {$CONFIG->dbprefix}metadata md ON (e.guid = md.entity_guid)
WHERE e.enabled = 'no'
AND md.name_id = $meta_n
AND md.value_id = $value_n
END;
		$result = get_data($query);
		if ($result) {
			return $result[0]->count;
		} else {
			return 0;
		}
}

function flexreg_notify($user_data) {
	global $CONFIG;
	//print 'in flexreg_notify';
	$to = trim(get_plugin_setting('notifications_email', 'flexreg'));
	if ($to) {
		//print 'preparing to send message';
		$recipient = new stdClass();
		$recipient->email = $to;
		$site = get_entity($CONFIG->site_guid);
    	$subject = sprintf(elgg_echo('flexreg:notification_subject'),$site->name);
    	$url = $CONFIG->wwwroot.'mod/flexreg/moderate_users.php';
    	$message = sprintf(elgg_echo('flexreg:notification_message'),$user_data,$site->name,date('r'),$url);

        email_notify_handler( $site, $recipient, $subject, $message);
        //print 'sent message';
    }
}

function flexreg_get_standard_fields($as_html=true) {
	$splitnames = get_plugin_setting('splitnames', 'flexreg') == 'yes';
	$unique_code = get_plugin_setting('unique_code', 'flexreg') == 'yes';
	$autousername = get_plugin_setting('autousername', 'flexreg') == 'yes';
	
	$code_name = '';
	$code_email = '';
	$code_lastname = '';
	$code_firstname = '';
	
	if ($unique_code) {
		$code = get_input('code','');
		$entities = get_entities_from_metadata('code',$code,'object','registration_code');
		if ($entities) {
			$obj = $entities[0];
			$code_name = $obj->name;
			$code_email = $obj->email;
			if ($splitnames) {
				$name_bits = explode(' ',$code_name);
				if (count($name_bits > 1)) {
					$code_lastname = array_pop($name_bits);
					$code_firstname = implode(' ',$name_bits);
				} else {
					$code_lastname = $code_name;
					$code_firstname = '';
				}
			}
		}
	}
	
	$username = get_input('u');
	$email = get_input('e',$code_email);
	
	if ($splitnames) {
		$first_name = get_input('fn',$code_firstname);
		$last_name = get_input('ln',$code_lastname);
		$first_name_title = elgg_echo('flexreg:first_name');
		$last_name_title = elgg_echo('flexreg:last_name');
		$first_name_input = elgg_view('input/text' , array('internalname' => 'first_name', 'class' => "general-textarea", 'value' => $first_name));
		$last_name_input = elgg_view('input/text' , array('internalname' => 'last_name', 'class' => "general-textarea", 'value' => $last_name));
		if ($as_html) {
			$form_body = "<p><label>" . $first_name_title . "<br />" . $first_name_input . "</label><br />";
			$form_body .= "<label>" . $last_name_title . "<br />" . $last_name_input . "</label><br />";
		} else {
			$tvars = array();
			$tvars['_first_name:t'] = $first_name_title;
			$tvars['_last_name:t'] = $last_name_title;
			$tvars['_first_name:i'] = $first_name_input;
			$tvars['_last_name:i'] = $last_name_input;
		}
	} else {
		$name = get_input('n',$code_name);
		$name_title = elgg_echo('name');
		$name_input = elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name));
		if ($as_html) {
			$form_body = "<p><label>" . $name_title. "<br />" . $name_input . "</label><br />";
		} else {
			$tvars = array();
			$tvars['_name:t'] = $name_title;
			$tvars['_name:i'] = $name_input;
		}
	}
	
	if ($unique_code) {
		// don't let users with a registration code change their email address
		$email_input = elgg_view('input/hidden' , array('internalname' => 'email', 'value' => $email));
	} else {
		$email_title = elgg_echo('email');
		$email_input = elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email));
	}
	if (!$autousername) {
		$username_title = elgg_echo('username');
		$username_input = elgg_view('input/text' , array('internalname' => 'username', 'class' => "general-textarea", 'value' => $username));
	}
	$password_title = elgg_echo('password');
	$password_input = elgg_view('input/password' , array('internalname' => 'password', 'class' => "general-textarea"));
	$password2_title = elgg_echo('passwordagain');
	$password2_input = elgg_view('input/password' , array('internalname' => 'password2', 'class' => "general-textarea"));
	
	if ($as_html) {
		if ($unique_code) {
			$form_body .= $email_input;
		} else {
			$form_body .= "<label>" . $email_title . "<br />" . $email_input . "</label><br />";
		}
		if (!$autousername) {
			$form_body .= "<label>" . $username_title . "<br />" . $username_input . "</label><br />";
		}
		$form_body .= "<label>" . $password_title . "<br />" . $password_input . "</label><br />";
		$form_body .= "<label>" . $password2_title . "<br />" . $password2_input . "</label><br />";
		
		return $form_body;
	} else {
		$tvars['_email:t'] = $email_title;
		$tvars['_email:i'] = $email_input;
		$tvars['_username:t'] = $username_title;
		$tvars['_username:i'] = $username_input;
		$tvars['_password:t'] = $password_title;
		$tvars['_password:i'] = $password_input;
		$tvars['_password2:t'] = $password2_title;
		$tvars['_password2:i'] = $password2_input;
		
		return $tvars;
	}
	
}
?>