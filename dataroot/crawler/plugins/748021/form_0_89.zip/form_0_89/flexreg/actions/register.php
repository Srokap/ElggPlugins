<?php
require_once(dirname(dirname(__FILE__)) . "/models/model.php");
require_once(dirname(dirname(dirname(__FILE__))).'/flexprofile/models/model.php');
	
global $CONFIG;

action_gatekeeper();

$splitnames = get_plugin_setting('splitnames', 'flexreg') == 'yes';
$autousername = get_plugin_setting('autousername', 'flexreg') == 'yes';
$unique_code = get_plugin_setting('unique_code', 'flexreg') == 'yes';

// Get variables
$mid = (int) get_input('mid',0);
$password = get_input('password');
$password2 = get_input('password2');
$email = get_input('email');
if ($splitnames) {
	$first_name = trim(get_input('first_name',''));
	$last_name = trim(get_input('last_name',''));
	if ($first_name || $last_name) {
		$name = $first_name . ' '.$last_name;
	}
} else {
	$name = get_input('name');
}
if($autousername && $name) {
	// convert the supplied name to lowercase ascii and split it into pieces
	$name_bits = explode(' ',strtolower(iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name)));
	$c = count($name_bits);
	$username = '';
	$i = 1;
	// concatenate the first letter from each piece plus the entire last bit
	// to create a user name like jmsmith
	foreach($name_bits as $bit) {
		if ($i == $c) {
			$username .= trim($bit);
		} else {
			$username .= substr(trim($bit),0,1);
		}
		$i += 1;
	}
	if (strlen($username) < 4) {
		$username .= 'xxxx';
	}
	
	// ok, we have a candidate username
	// make sure that it is not already in use,
	// even by disabled users
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);
	if(get_user_by_username($username)) {
		// oops, already in use, so try adding numbers to the end
		// this tries about 100 times, so in theory it could fail
		// TODO - do something reasonable upon failure
		for ($i=2;$i<100;$i++) {
			if (!get_user_by_username($username.$i)) {
				$username .= $i;
				break;
			}
		}
	}
	access_show_hidden_entities($access_status);
} else {
	$username = get_input('username');
}
$friend_guid = (int) get_input('friend_guid',0);
$invitecode = get_input('invitecode');
$optional_groups = get_input('optional_groups','');

$admin = get_input('admin');
if (is_array($admin)) $admin = $admin[0];		

if ((!$CONFIG->disable_registration) || $unique_code) {
	$result = flexreg_validate_form();
	if (flexreg_validate_basic_user_data($username, $password, $name, $email)) {
		if (!$result->error_status) {

			try {
				if (
					(
						(trim($password)!="") &&
						(strcmp($password, $password2)==0) 
					) &&
					($guid = register_user($username, $password, $name, $email, false, $friend_guid, $invitecode))
				) {
					
					$new_user = get_entity($guid);
					if (($guid) && ($admin))
					{
						admin_gatekeeper(); // Only admins can make someone an admin
						$new_user->admin = 'yes';
					}
					//TODO - remove this dependency (just duplicate the function)
					flexprofile_set_data($new_user,$result->form_data);
					
					// subscribe to optional groups
					if($optional_groups) {
						foreach($optional_groups as $group_guid) {
							join_group($group_guid, $guid);
						}
					}
					
					//subscribe to automatic groups
					$flexreg_automatic_groups = get_plugin_setting('automatic_groups', 'flexreg');
					if (trim($flexreg_automatic_groups)) {
						// make sure that we are using Unix line endings
						$flexreg_automatic_groups = str_replace("\r\n","\n",$flexreg_automatic_groups);
						$flexreg_automatic_groups = str_replace("\r","\n",$flexreg_automatic_groups);
						$group_list = explode("\n",trim($flexreg_automatic_groups));
						foreach($group_list as $group_guid) {
							join_group($group_guid, $guid);
						}
					}
					
					// if this registration is through a group, there may be an 
					// automatic group registration that way as well
					if ($mid) {
						$message = get_entity($mid);
						if ($message && $message->getSubtype() == 'bulk_invite_message') {
							$autogroup_guid = $message->group_guid;
							if ($autogroup_guid) {
								$autogroup = get_entity($autogroup_guid);
								if ($autogroup && $autogroup instanceOf ElggGroup) {
									join_group($autogroup_guid, $guid);
								}
							}
						}
					}
					
					trigger_elgg_event('registercomplete','user',array('entity'=>$new_user,'data'=>$result->form_data));
					
					// Send user validation request on register only
					global $registering_admin;
					if (!($registering_admin || $unique_code)) {
						request_user_validation($guid);
					}
					
					// Now disable if not an admin or not a unique registration code
					if ($unique_code) {
						// delete the registration code and log the user in immediately with
						// a welcome message
						$code = get_input('code','');
						$entities = get_entities_from_metadata('code',$code,'object','registration_code');
						if ($entities) {
							// got a valid code
							
							// delete the code as this is one time use
							$obj = $entities[0];
							$obj->delete();
							
							// make sure the user is validated
							create_metadata($guid, 'validated', 1,'', 0, ACCESS_PUBLIC);
							create_metadata($guid, 'validated_method', 'registration_code','', 0, ACCESS_PUBLIC);
							
							// and log them straight in
							login($new_user);
							system_message(sprintf(elgg_echo('flexreg:login_welcome'),$CONFIG->site->name));
							forward($CONFIG->wwwroot.'pg/dashboard');
							exit;
						} else {
							// oops no valid code
							// this shouldn't be happening at this point
							// for now, I will send out an error message and disable the user
							register_error(elgg_echo('flexreg:error:missing_code'));
							// TODO: perhaps we should delete this user?
							$new_user->disable('new_user', false);
						}
					} else if (!$new_user->admin) {
						$new_user->disable('new_user', false);	
					}
					
					//system_message(sprintf(elgg_echo("registerok"),$CONFIG->sitename));
					
					forward(); // Forward on success, assume everything else is an error...
				} else {
					register_error(elgg_echo("registerbad"));
				}
			} catch (RegistrationException $r) {
				register_error($r->getMessage());
			}
		}
	}
} else {
	register_error(elgg_echo('registerdisabled'));
}
	
// registration failed so redisplay form

set_input('u',$username);
set_input('e',$email);
if ($splitnames) {
	set_input('fn',$first_name);
	set_input('ln',$last_name);
} else {
	set_input('n',$name);
}
	
$body = elgg_view('account/forms/register',array('data'=>$result->form_data,'friend_guid' => $friend_guid, 'invitecode' => $invitecode,'optional_groups'=>$optional_groups));
page_draw(elgg_echo('register'), $body);	

?>