<?php
/**
 * Elgg flexreg profile review action
 * 
 * @package flexreg
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2009
 * @link http://radagast.biz/
 */

global $CONFIG;

admin_gatekeeper();

$extra_message = trim(get_input('extra_message',''));
$user_guid = get_input('user_guid',0);
$decision = get_input('decision','');

$access_status = access_get_show_hidden_status();
access_show_hidden_entities(true);

$user = get_user($user_guid);

if ($decision == 'approve' ) {
	system_message(elgg_echo('flexreg:approve:confirm'));
	$notify_subject = sprintf(elgg_echo('flexreg:approve:subject'),$CONFIG->site->name);
	$notify_message = sprintf(elgg_echo('flexreg:approve:body'), $user->name,$CONFIG->site->name);
	if ($extra_message) {
		$notify_message .= "\n\n".$extra_message."\n";
	}
	$welcome_blurb = trim(get_plugin_setting('welcome_blurb', 'flexreg'));
	if ($welcome_blurb) {
		$notify_message .= "\n\n".$welcome_blurb."\n";
	}
	$user->enable();
	notify_user($user_guid, $CONFIG->site->guid, $notify_subject, $notify_message, NULL, 'email');
} else if ($decision == 'reject') {
	system_message(elgg_echo('flexreg:reject:confirm'));
	$notify_subject = sprintf(elgg_echo('flexreg:reject:subject'),$CONFIG->site->name);
	$notify_message = sprintf(elgg_echo('flexreg:reject:body'), $user->name,$CONFIG->site->name);
	if ($extra_message) {
		$notify_message .= "\n\n".$extra_message."\n";
	}
	notify_user($user_guid, $CONFIG->site->guid, $notify_subject, $notify_message, NULL, 'email');
	$user->delete();
}

access_show_hidden_entities($access_status);

forward($CONFIG->wwwroot.'mod/flexreg/moderate_users.php');

?>