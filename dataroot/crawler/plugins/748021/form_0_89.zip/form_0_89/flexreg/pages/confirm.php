<?php
	/**
	 * Action which confirms an email when it is registered or changed, based on a code.
	 * Modified from the version in uservalidationbyemail
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @author 
	 * @link http://elgg.org/
	 */

	// Load flexreg model
    require_once(dirname(dirname(__FILE__))."/models/model.php");

	global $CONFIG;
	
	$flexreg_moderation = get_plugin_setting('moderation', 'flexreg');

	// Get user id
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);
	
	$user_guid = (int)get_input('u');
	$user = get_entity($user_guid);
	
	// And the code
	$code = sanitise_string(get_input('c'));
	
	if ( ($code) && ($user) ) {
		if ($code == uservalidationbyemail_generate_code($user_guid, $user->email)) {
			if (!$user->isEnabled() && ($flexreg_moderation == 'yes')) {
				// the user is disabled, so presumably this is an inital
				// email address confirmation during registration
				// the moderation code currently has an ugly permissions work around, 
				// so safe to validate now
				// TODO: find a better way
				set_user_validation_status($user_guid, true, 'email');
				flexreg_notify($user->name.' ('.$user->username.')');
				system_message(elgg_echo('flexreg:email:confirm:success'));
			} else {
				system_message(elgg_echo('email:confirm:success'));
				$notify_subject = sprintf(elgg_echo('email:validate:success:subject'), $user->username);
				$notify_message = sprintf(elgg_echo('email:validate:success:body'), $user->name);
				// enable before validation
				$user->enable();
				// TODO: this validate bit may not work because of permissions problems
				// does it matter given that they are activated?
				set_user_validation_status($user_guid, true, 'email');
				notify_user($user_guid, $CONFIG->site->guid, $notify_subject, $notify_message, NULL, 'email');
			}
			
		} else
			register_error(elgg_echo('email:confirm:fail'));
	} else {
		register_error(elgg_echo('email:confirm:fail'));
	}
		
	access_show_hidden_entities($access_status);
	
	forward();
	exit;

?>