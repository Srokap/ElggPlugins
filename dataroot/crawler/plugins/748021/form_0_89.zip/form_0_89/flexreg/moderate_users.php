<?php
/**
 * Allows admins to moderate users
 * 
 * @package flexreg
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2009
 * @link http://radagast.biz/
 * 
 */
 
// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// Load model
require_once(dirname(__FILE__) . "/models/model.php");

admin_gatekeeper();

set_context('admin');

$limit = get_input('limit', 10);
$offset = get_input('offset', 0);

$access_status = access_get_show_hidden_status();
access_show_hidden_entities(true);

$body = elgg_view('flexreg/moderate_users',array(
	'user_list' => flexreg_get_unmoderated_users($limit,$offset),
	'limit' => $limit,
	'offset' => $offset,
	'count' => flexreg_count_unmoderated_users(),
	'baseurl' => $_SERVER['REQUEST_URI']
));
$body = elgg_view('page_elements/contentwrapper',array('body' =>$body));
access_show_hidden_entities($access_status);
$title = elgg_echo('flexreg:moderate_users_title');
page_draw($title,elgg_view_layout("two_column_left_sidebar", '', elgg_view_title($title) . $body));

?>