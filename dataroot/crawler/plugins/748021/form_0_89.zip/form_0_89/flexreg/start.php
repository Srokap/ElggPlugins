<?php

function flexreg_init() {
	global $CONFIG;
		
	// need to put this here because the original "register" action is set up in
	// users_init
	
	register_action("register",true,$CONFIG->pluginspath . "flexreg/actions/register.php");
	
	//This is for pre Elgg 1.7
	register_action("email/confirm",true, $CONFIG->pluginspath . "flexreg/actions/confirm.php");
	
	// This is for Elgg 1.7 and higher	
	// Register page handler to validate users
	// This isn't an action because security is handled by the validation codes.
	register_page_handler('uservalidationbyemail', 'flexreg_uservalidationbyemail_page_handler');
	
	register_action("flexreg/moderate",false, $CONFIG->pluginspath . "flexreg/actions/moderate.php");
	
}

/**
 * Get security token, forward to action.
 *
 * @param unknown_type $page
 * @return unknown_type
 */
function flexreg_uservalidationbyemail_page_handler($page) {
	if (isset($page[0]) && $page[0] == 'confirm') {
		include(dirname(__FILE__) . "/pages/confirm.php");
	} else if (isset($page[0]) && $page[0] == 'admin') {
		set_context('admin');
		admin_gatekeeper();
		$content = elgg_view('uservalidationbyemail/admin/users/unvalidated');
		$title = elgg_echo('uservalidationbyemail:admin:unvalidated');

		$body = elgg_view_layout('two_column_left_sidebar', '', elgg_view_title($title) . $content);

		page_draw($title, $body);
		return TRUE;
	} else {
		register_error(elgg_echo('email:confirm:fail'));
	}

	forward();
}

function flexreg_pagesetup() {
	global $CONFIG;
	
	$flexreg_moderation = get_plugin_setting('moderation', 'flexreg');

	if ((get_context() == 'admin') && ($flexreg_moderation == 'yes')) {
		add_submenu_item(elgg_echo('flexreg:moderate_users_title'), $CONFIG->wwwroot."mod/flexreg/moderate_users.php");
	}
}

function flexreg_can_edit($hook_name, $entity_type, $return_value, $parameters) {
	$entity = $parameters['entity'];
	if ($entity->getSubtype() == "registration_code") {
		// should be able to delete registration codes
		return true;
	}
	return null;  
}

// Make sure flexreg_init is called after uservalidationbyemail
// to over-write that action
register_elgg_event_handler('init','system','flexreg_init',700);
register_elgg_event_handler('pagesetup','system','flexreg_pagesetup');
register_plugin_hook('permissions_check','object','flexreg_can_edit');
?>