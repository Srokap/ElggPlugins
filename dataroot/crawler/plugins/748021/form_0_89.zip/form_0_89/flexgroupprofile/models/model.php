<?php
/**
	 * Elgg flex group profile model
	 * Functions to save and display profile data
	 * 
	 * @package Elgg
	 * @subpackage FlexGroupProfile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Kevin Jardine <kevin@radagast.biz>
	 * @copyright Radagast Solutions 2008
	 * @link http://radagast.biz/
	 */

// Load form model
require_once(dirname(dirname(dirname(__FILE__))) . "/form/models/model.php");
// Load form profile model
require_once(dirname(dirname(dirname(__FILE__))) . "/form/models/profile.php");

function flexgroupprofile_get_profile_form($entity='',$group_profile_category='') {
    return form_get_latest_public_profile_form(FORM_GROUP_PROFILE,$group_profile_category);
}

// a stub for future use

function flexgroupprofile_get_profile_config($group_profile_category) {
	$group_config = new stdClass();
	return $group_config;
}

function flexgroupprofile_get_configuration($group_profile_category,$tool_name) {
	$md = array('tool_setting'=>$tool_name,'category'=>$group_profile_category);
	$config = get_entities_from_metadata_multi($md,'object','group_configure');
	if ($config) {
		return $config[0]->tool_option;
	}
	
	return false;
}

function flexgroupprofile_set_configuration($group_profile_category,$tool_name,$tool_option) {
	$md = array('tool_setting'=>$tool_name,'category'=>$group_profile_category);
	$config = get_entities_from_metadata_multi($md,'object','group_configure');
	if ($config) {
		$config = $config[0];
		$config->tool_option = $tool_option;
	} else {
		$config = new ElggObject();
		$config->subtype = 'group_configure';
		$config->access_id = ACCESS_PUBLIC;
		$config->tool_setting = $tool_name;
		$config->category = $group_profile_category;
		$config->tool_option = $tool_option;
		$config->save();
	}
}

function flexgroupprofile_move_group_icon($group_guid,$old_group_owner_guid,$new_group_owner_guid) {
	
	// get the group icon data and delete it on the file system
	
	$sizes = array('','tiny','small','medium','large');
	
	foreach ($sizes as $size) {
		
		$prefix = "groups/".$group_guid.$size;
	
		$filehandler = new ElggFile();
		$filehandler->owner_guid = $old_group_owner_guid;
		$filehandler->setFilename($prefix . ".jpg");
		$filehandler->open("read");
		$data = $filehandler->grabFile();
		$filehandler->close();
		$filehandler->delete();
		
		// save the group icon to the new location
		
		$filehandler = new ElggFile();
		$filehandler->owner_guid = $new_group_owner_guid;
		$filehandler->setFilename($prefix . ".jpg");
		$filehandler->open("write");
		$filehandler->write($data);
		$filehandler->close();
	}
}

function flexgroupprofile_group_icon_exists($group) {
	$size = 'medium';
	$filehandler = new ElggFile();
	$filehandler->owner_guid = $group->owner_guid;
	$filehandler->setFilename("groups/" . $group->guid . $size . ".jpg");

	if ($filehandler->open("read")) {
		if ($contents = $filehandler->read($filehandler->size())) {
			return true;
		} 
	}
	return false;
}

?>