<?php
$yn_options = array(elgg_echo('flexgroupprofile:settings:yes')=>'yes',
	elgg_echo('flexgroupprofile:settings:no')=>'no',
);

$membership_options = array(elgg_echo('flexgroupprofile:settings:membership:open')=>'open',
	elgg_echo('flexgroupprofile:settings:membership:closed')=>'closed',
	elgg_echo('flexgroupprofile:settings:membership:set_per_group')=>'set_per_group',
);

$body = '';

$flexgroupprofile_membership = get_plugin_setting('membership', 'flexgroupprofile');
if (!$flexgroupprofile_membership) {
	$flexgroupprofile_membership = 'set_per_group';
}

$body .= elgg_echo('flexgroupprofile:settings:membership:title');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[membership]','value'=>$flexgroupprofile_membership,'options'=>$membership_options));

$body .= '<br />';

$flexgroupprofile_image_required = get_plugin_setting('image_required', 'flexgroupprofile');
if (!$flexgroupprofile_image_required) {
	$flexgroupprofile_image_required = 'no';
}

$image_options = array(elgg_echo('flexgroupprofile:settings:yes')=>'yes',
	elgg_echo('flexgroupprofile:settings:no')=>'no',
	elgg_echo('flexgroupprofile:settings:hide_image')=>'hide'
);

$body .= elgg_echo('flexgroupprofile:settings:image_required:title');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[image_required]','value'=>$flexgroupprofile_image_required,'options'=>$image_options));

$body .= '<br />';

$flexgroupprofile_description_required = get_plugin_setting('description_required', 'flexgroupprofile');
if (!$flexgroupprofile_description_required) {
	$flexgroupprofile_description_required = 'no';
}

$body .= elgg_echo('flexgroupprofile:settings:description_required:title');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[description_required]','value'=>$flexgroupprofile_description_required,'options'=>$yn_options));

echo $body;
?>