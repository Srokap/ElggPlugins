<?php
/**
 * Elgg flex group profile edit action
 * Allows user to edit profile
 * 
 * @package Elgg
 * @subpackage FlexGroupProfile
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008
 * @link http://radagast.biz/
 */

// Load form profile model
require_once(dirname(dirname(dirname(__FILE__))) . "/form/models/profile.php");

// Load flexgroupprofile model
require_once(dirname(dirname(__FILE__)) . "/models/model.php");

$user_guid = get_input('user_guid');
$group_owner_username = get_input('group_owner_username','');
$membership = get_input('membership');

$user = NULL;
if (!$user_guid) $user = $_SESSION['user'];
else
$user = get_entity($user_guid);

$group_guid = get_input('group_guid','');
$group = new ElggGroup($group_guid); // load if present, if not create a new group
if (($group_guid) && (!$group->canEdit()))
{
	register_error(elgg_echo("groups:cantedit"));
	
	forward($_SERVER['HTTP_REFERER']);
	exit;
}

// Set access - all groups are public from elgg's point of view, unless the override is in place

if (get_plugin_setting('hidden_groups', 'groups') == 'yes')
{
	$visibility = (int)get_input('vis','',false);
	
	$group->access_id = $visibility;
	
	$group->access_id;
}
else
	$group->access_id = 2;

$group_profile_category = get_input('group_profile_category',null);
if (isset($group_profile_category)) {
	$group->group_profile_category = $group_profile_category;
}

$has_icon = isset($_FILES['icon']) && substr_count($_FILES['icon']['type'],'image/');

$group->name = trim(get_input('name',''));
$group->description = trim(get_input('description',''));
$data = form_get_profile_data_from_form_post();

$description_required = get_plugin_setting('description_required', 'flexgroupprofile');
$image_required = get_plugin_setting('image_required', 'flexgroupprofile');

// Validate create
//TODO: rework to properly handle missing data by redisplaying form
if (	(!$group->name)
		|| (($description_required == 'yes') && !$group->description)
		|| (($image_required == 'yes') && !$has_icon && !flexgroupprofile_group_icon_exists($group))
)
{
	// need to redisplay the form
	register_error(elgg_echo('flexgroupprofile:missing_error'));
	if ($group_guid) {
		set_page_owner($group_guid);
		$title = elgg_echo("groups:edit");
	} else {
		$title = elgg_echo("groups:new");
	}
	
	set_context('groups');

	$body = elgg_view_title($title);
	
	$body .= elgg_view("forms/groups/edit", 
		array('entity' => $group, 'group_name'=>$group->name, 'description'=>$group->description, 
		'group_guid'=>$group_guid, 'group_owner_username'=>$group_owner_username,
		'membership'=>$membership, 'visibility'=>$visibility, 
		'group_profile_category'=>$group_profile_category, 'data' => $data));
	
	$body = elgg_view_layout('two_column_left_sidebar', '', $body);
	
	page_draw($title, $body);
	exit;
}

// Group membership
switch ($membership)
{
	case 2: $group->membership = ACCESS_PUBLIC; break;
	default: $group->membership = ACCESS_PRIVATE; 
}

// Set group tool options
if (isset($CONFIG->group_tool_options)) {
	foreach($CONFIG->group_tool_options as $group_option) {
		$group_option_toggle_name = $group_option->name."_enable";
		if ($group_option->default_on) {
			$group_option_default_value = 'yes';
		} else {
			$group_option_default_value = 'no';
		}
		$group->$group_option_toggle_name = get_input($group_option_toggle_name, $group_option_default_value);
	}
}	

if ($group_owner_username
	&& ($user = get_user_by_username($group_owner_username) )) {
		
	$new_group_owner_guid = $user->getGUID();
	if ($group->owner_guid) {
		$old_group_owner_guid = $group->owner_guid;
	} else {
		$old_group_owner_guid = get_loggedin_userid();
	}
	
	if ($new_group_owner_guid != $old_group_owner_guid) {
		$group->owner_guid = $new_group_owner_guid;
		$group->container_guid = $new_group_owner_guid;
		if (!$has_icon) {
			flexgroupprofile_move_group_icon($group->getGUID(),$old_group_owner_guid,$new_group_owner_guid);
		}
	}
}

if (!trigger_elgg_event('groupprofile_preupdate','group',array('entity'=>$group,'data'=>$data))) {
	// need to redisplay the form, counting on whatever plugin stopped the save
	// to set an appropriate message
	if ($group_guid) {
		set_page_owner($group_guid);
		$title = elgg_echo("groups:edit");
	} else {
		$title = elgg_echo("groups:new");
	}
	
	set_context('groups');

	$body = elgg_view_title($title);
	
	$body .= elgg_view("forms/groups/edit", 
		array('entity' => $group, 'group_name'=>$group->name, 'description'=>$group->description, 
		'group_guid'=>$group_guid, 'group_owner_username'=>$group_owner_username,
		'membership'=>$membership, 'visibility'=>$visibility, 
		'group_profile_category'=>$group_profile_category, 'data' => $data));
	
	$body = elgg_view_layout('two_column_left_sidebar', '', $body);
	
	page_draw($title, $body);
	exit;
}

$group->save();

if (!$group->isMember($user))
	$group->join($user); // Owner is always a member

form_set_data($group,$data);

// Now see if we have a file icon
if ($has_icon)
{
	$prefix = "groups/".$group->guid;
	
	$filehandler = new ElggFile();
	$filehandler->owner_guid = $group->owner_guid;
	$filehandler->setFilename($prefix . ".jpg");
	$filehandler->open("write");
	$filehandler->write(get_uploaded_file('icon'));
	$filehandler->close();
	
	$thumbtiny = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),25,25, true);
	$thumbsmall = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),40,40, true);
	$thumbmedium = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),100,100, true);
	$thumblarge = get_resized_image_from_existing_file($filehandler->getFilenameOnFilestore(),200,200, false);
	if ($thumbtiny) {
		
		$thumb = new ElggFile();
		$thumb->owner_guid = $group->owner_guid;
		$thumb->setMimeType('image/jpeg');
		
		$thumb->setFilename($prefix."tiny.jpg");
		$thumb->open("write");
		$thumb->write($thumbtiny);
		$thumb->close();
		
		$thumb->setFilename($prefix."small.jpg");
		$thumb->open("write");
		$thumb->write($thumbsmall);
		$thumb->close();
		
		$thumb->setFilename($prefix."medium.jpg");
		$thumb->open("write");
		$thumb->write($thumbmedium);
		$thumb->close();
		
		$thumb->setFilename($prefix."large.jpg");
		$thumb->open("write");
		$thumb->write($thumblarge);
		$thumb->close();
		
		$group->icontime = $time();
			
	}
}

trigger_elgg_event('groupprofileupdate','group',$group);

system_message(elgg_echo("groups:saved"));

// Forward to the group's profile
forward($group->getUrl());
exit;

?>