<?php

	$english = array(
	
	'flexgroupprofile:owner_label' => "Group owner",
	'flexgroupprofile:owner_description' => "You can transfer group ownership by changing the above username to one for another user.",
	'flexgroupprofile:settings:yes' => "Yes",
	'flexgroupprofile:settings:no' => "No",
	'flexgroupprofile:settings:membership:title' => "Group membership options",
	'flexgroupprofile:settings:membership:open' => "Always open",
	'flexgroupprofile:settings:membership:closed' => "Always closed",
	'flexgroupprofile:settings:membership:set_per_group' => "Set per group",
	'flexgroupprofile:settings:image_required:title' => "Mandatory group icon",
	'flexgroupprofile:settings:description_required:title' => "Mandatory group description",
	'flexgroupprofile:missing_error' => "You were missing required information. Please try again.",
	'flexgroupprofile:new_group_description' => "Please enter the information below to create a new group.",
	'flexgroupprofile:edit_group_description' => "You can change the information for this group below.",
	'flexgroupprofile:settings:hide_image' => "Hide image upload form",
	);
					
	add_translation("en",$english);

?>