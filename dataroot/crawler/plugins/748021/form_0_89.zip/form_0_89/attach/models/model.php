<?php

// shows an attachment list for attachments created before the object they are attached to
// TODO: make this a view

function attach_show_temporary_attachment_listing($dir,$fn,$ofn,$mime_type,$guid) {
	global $CONFIG;
	
	$title_bit = " title = \"$ofn\" alt=\"$ofn\" ";
	
	if (substr_count($mime_type,'image/')) {
		$left = '<img class="attachment_image" '.$title_bit.'src="'.$CONFIG->wwwroot.'mod/attach/show_temporary_image.php?username='.$username.'&fn='.$fn.'">';
	} else {
		//TODO: make this less generic based on the mime type
		$left = '<img class="attachment_image" '.$title_bit.'src="'.$CONFIG->wwwroot.'mod/file/graphics/icons/general.gif">';
	}
	$delete_link = $CONFIG->wwwroot."mod/attach/remove_temporary_attachment.php?username=$username&fn=$fn";
	return implode('||',array($delete_link,$left,implode(',',array('local',$fn,$ofn,$mime_type,$guid))));
}

function attach_attachment_listing($entity_guid,$annotation) {
	global $CONFIG;
	
	$body = '';
	$token = $annotation->value;
	
	if ($token) {
		$a = explode(',',$token);
		$attachment_type = $a[0];
		$fn = $a[1];
		$ofn = $a[2];
		$mime_type = $a[3];
		$guid = $a[4];
		
		if ($attachment_type == 'local') {
	
			$title_bit = " title = \"$ofn\" alt=\"$ofn\" ";
			$body = '<div class="attachment_listing_item">';
			
			if (substr_count($mime_type,'image/')) {
				$image = '<img class="attachment_image" '.$title_bit.'src="'.$CONFIG->wwwroot.'mod/attach/show_attachment_image.php?id='.$annotation->id.'">';
			} else {
				//TODO: make this less generic based on the mime type
				$image = '<img class="attachment_image" '.$title_bit.'src="'.$CONFIG->wwwroot.'mod/file/graphics/icons/general.gif">';
			}
			$body .= '<a href="'.$CONFIG->wwwroot.'mod/attach/download.php?id='.$annotation->id.'">'.$image.'</a>';
			$body .= '</div>';	
			$body .= '<br clear="both" /><br />';		
		}
	}
	
	echo $body;
}

/**
 * Send an internal message
 *
 * @param string $subject The subject line of the message
 * @param string $body The body of the mesage
 * @param int $send_to The GUID of the user to send to
 * @param int $from Optionally, the GUID of the user to send from
 * @param int $reply The GUID of the message to reply from (default: none)
 * @param true|false $notify Send a notification (default: true)
 * @param true|false $add_to_sent If true (default), will add a message to the sender's 'sent' tray
 * @return true|false Depending on success
 * 
 * Modified by Kevin Jardine <kevin@radagast.biz> to support message attachments
 * 
 */
function attach_messages_send($subject, $body, $send_to, $from = 0, $reply = 0, $notify = true, $add_to_sent = true) {
	
		global $messagesendflag;
		$messagesendflag = 1;
		
		global $messages_pm;
		if ($notify) {
			$messages_pm = 1;
		} else {
			$messages_pm = 0;
		}
		
	// If $from == 0, set to current user
			if ($from == 0)
				$from = (int) get_loggedin_user()->guid;
				
    // Initialise a new ElggObject
			$message_to = new ElggObject();
			$message_sent = new ElggObject();
	// Tell the system it's a message
			$message_to->subtype = "messages";
			$message_sent->subtype = "messages";
	// Set its owner to the current user
			// $message_to->owner_guid = $_SESSION['user']->getGUID();
			$message_to->owner_guid = $send_to;
			$message_to->container_guid = $send_to;
			$message_sent->owner_guid = $from;
			$message_sent->container_guid = $from;
	// For now, set its access to public (we'll add an access dropdown shortly)
			$message_to->access_id = ACCESS_PUBLIC;
			$message_sent->access_id = ACCESS_PUBLIC;
	// Set its description appropriately
			$message_to->title = $subject;
			$message_to->description = $body;
			$message_sent->title = $subject;
			$message_sent->description = $body;
    // set the metadata
            $message_to->toId = $send_to; // the user receiving the message
            $message_to->fromId = $from; // the user receiving the message
            $message_to->readYet = 0; // this is a toggle between 0 / 1 (1 = read)
            $message_to->hiddenFrom = 0; // this is used when a user deletes a message in their sentbox, it is a flag
            $message_to->hiddenTo = 0; // this is used when a user deletes a message in their inbox
            $message_sent->toId = $send_to; // the user receiving the message
            $message_sent->fromId = $from; // the user receiving the message
            $message_sent->readYet = 0; // this is a toggle between 0 / 1 (1 = read)
            $message_sent->hiddenFrom = 0; // this is used when a user deletes a message in their sentbox, it is a flag
            $message_sent->hiddenTo = 0; // this is used when a user deletes a message in their inbox
            
            $message_to->msg = 1;
            $message_sent->msg = 1;
            
	    // Save the copy of the message that goes to the recipient
			$success = $message_to->save();
			
		// Save the copy of the message that goes to the sender
			if ($add_to_sent) $success2 = $message_sent->save();
			
			$message_to->access_id = ACCESS_PRIVATE;
			$message_to->save();
			
			if ($add_to_sent) {
				$message_sent->access_id = ACCESS_PRIVATE;
				$message_sent->save();
			}
			
	    // if the new message is a reply then create a relationship link between the new message
	    // and the message it is in reply to
	        if($reply && $success){
    	        $create_relationship = add_entity_relationship($message_sent->guid, "reply", $reply);		    	        
	        }
	        
	        
	        global $CONFIG;
			$message_contents = strip_tags($body);
			if ($send_to != get_loggedin_user() && $notify)
			notify_user($send_to, get_loggedin_user()->guid, elgg_echo('messages:email:subject'), 
				sprintf(
							elgg_echo('messages:email:body'),
							get_loggedin_user()->name,
							$message_contents.attach_list_attachments($message_to),
							$CONFIG->wwwroot . "pg/messages/" . $user->username,
							get_loggedin_user()->name,
							$CONFIG->wwwroot . "mod/messages/send.php?send_to=" . get_loggedin_user()->guid
						)
			);
			
	    	$messagesendflag = 0;    
	        return $success;
	
}

function attach_list_attachments($message) {
	global $CONFIG;
	
	$list = '';
	$entity_guid = $message->getGUID();
	$attachments = get_annotations($entity_guid,'','','attachment');
	if ($attachments) {
		$list .= "\n\n".elgg_echo('attach:attachments:title');
		foreach($attachments as $attachment) {
			$token = $attachment->value;
			$a = explode(',',$token);
			$ofn = $a[2];
			$list .= "\n\n".$ofn.":\n\n\t".$CONFIG->wwwroot.'mod/attach/download.php?id='.$attachment->id;
		}
	}
	
	return $list;
}

function attach_get_image($entity,$size) {
	global $CONFIG;
	
	$entity_guid = $entity->getGUID();
	$attachments = get_annotations($entity_guid,'','','attachment');
	if ($attachments) {
		$id = $attachments[0]->id;
		$url = $CONFIG->wwwroot.'mod/attach/download.php?id='.$id.'&size='.$size;
		return '<img src="'.$url.'">';
	}
}

/**
 * Get a web file (HTML, XHTML, XML, image, etc.) from a URL.  Return an
 * array containing the HTTP server response header fields and content.
 */
function attach_get_file_from_url( $url )
{
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
    );

    $ch      = curl_init( $url );
    curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch );
    curl_close( $ch );

    $header['errno']   = $err;
    $header['errmsg']  = $errmsg;
    $header['content'] = $content;
    //error_log("\n\nFile download results for $url:\n\n".print_r($header,true));
    return $header;
}

function attach_handle_single_file($entity,$fieldname='attachment') {
	//error_log("attach_handle_single_file($entity,$fieldname='attachment')");
	//error_log(print_r($_FILES,true));
	global $CONFIG;
	$entity_guid = $entity->getGUID();
	// handle the attachment, deleting any existing one
	$attachment_type = get_input($fieldname.'_type','local');
	$attachment_image_size = get_input($fieldname.'_image_size','thumb');
	$is_attachment = false;
	if ($attachment_type == 'url') {
		$attachment = get_input($fieldname,'');
		if ($attachment) {
			$curl_result = attach_get_file_from_url($attachment);
			if (!$curl_result['errno'] && $curl_result['content']) {
				$is_attachment = true;
				$content = $curl_result['content'];
				$mime_type = $curl_result['content_type'];
			}
		}
	} else if ($attachment_type == 'local') {
		if ($_FILES[$fieldname]['name']) {
			$is_attachment = true;
		}
	}
	
	// TODO: get rid of guid in the annotation
	// this should always be $guid = $entity->getOwner();
	if ($is_attachment) {
		$attachment_dir = '';
		// we have a new attachment, so delete the old one, if any
		$user = get_loggedin_user();
		if (!$user) {
			return false;
		}
		$as = get_annotations($entity_guid,'','','attachment');
		if ($as) {
			foreach($as as $a) {
				$vs = explode(",",$a->value);
				if (count($vs) == 6) {
					$type = $vs[0];
					$fn = $vs[1];
					$ofn = $vs[2];
					$mime_type = $vs[3];
					$this_fieldname = $vs[4];
					$guid = $vs[5];
					if ('form_data_'.$this_fieldname == $fieldname) {
						$a->delete();
						$attachment_dir = $CONFIG->dataroot . attach_make_file_matrix($guid).'attachments/';
						attach_delete_files($attachment_dir,$fn);	
					}				
				} else if (count($vs) == 5) {
					// old style, just delete
					$fn = $vs[1];
					$guid = $vs[4];
					$a->delete();
					$attachment_dir = $CONFIG->dataroot . attach_make_file_matrix($guid).'attachments/';
					attach_delete_files($attachment_dir,$fn);
				}
			}
		}
		if (!$attachment_dir) {
			// no previous attachment, so make sure that the
			// attachment directory structure is in place
			$guid = $user->guid;
			$user_dir = $CONFIG->dataroot . attach_make_file_matrix($guid);
			if (!attach_setup_directory($user_dir)) {
				return false;
			}
			$attachment_dir = $user_dir .'attachments/';
			if (!attach_setup_directory($attachment_dir)) {
				return false;
			}
		}			
		if ($attachment_type == 'url') {
			$path_start = strrpos($attachment,'/');
			$original_name = substr($attachment,$path_start+1);
		} else {
			$original_name = $_FILES[$fieldname]['name'];
		}
		$filestorename = strtolower(time().$original_name);
				
		$location = $attachment_dir . $filestorename;
		//error_log("Opening $location for writing.");
		$fd = fopen($location,'wb');
		
		if ($attachment_type == 'local') {
			$content = get_uploaded_file($fieldname);
			$mime_type = $_FILES[$fieldname]['type'];
		}
		fwrite($fd,$content);
		fclose($fd);
		unset($content);
		//TODO: figure out what to do about non-image thumbnails
		if (substr_count($mime_type,'image/')) {
			attach_write_thumbs($attachment_dir,$filestorename,$attachment_image_size);
		}
		
		$token = implode(',',array($attachment_type,$filestorename,$original_name,$mime_type,$fieldname,$guid));
		$entity->annotate('attachment',$token,ACCESS_PUBLIC,$entity->owner_guid,'text');
		
		return true;
	}
	return false;
}

function attach_delete_files($dir,$fn) {
	$fullname = $dir.$fn;
	unlink($fullname);
	// remove the thumbnails
	$fullname = $dir.'thumb'.$fn;
	unlink($fullname);
	$fullname = $dir.'smallthumb'.$fn;
	unlink($fullname);
	$fullname = $dir.'largethumb'.$fn;
	unlink($fullname);
	$fullname = $dir.'xlargethumb'.$fn;
	unlink($fullname);
}

function attach_write_thumbs($dir,$fn,$attachment_image_size) {
	if ($attachment_image_size) {
		$a = explode('x',$attachment_image_size);
		$thumb_width = (int) $a[0];
		if (count($a) == 2) {
			$thumb_height = (int) $a[1];
		} else {
			$thumb_height = $thumb_width;
		}
		$thumbnail = get_resized_image_from_existing_file($dir.$fn,$thumb_width,$thumb_height,false);
		$fd = fopen($dir.'thumb'.$fn,'wb');
		fwrite($fd,$thumbnail);
		fclose($fd);
	} else {
		$thumbnail = get_resized_image_from_existing_file($dir.$fn,46,46, true);
		$fd = fopen($dir.'thumb'.$fn,'wb');
		fwrite($fd,$thumbnail);
		fclose($fd);
		
		$thumbsmall = get_resized_image_from_existing_file($dir.$fn,60,60, true);
		$fd = fopen($dir.'smallthumb'.$fn,'wb');
		fwrite($fd,$thumbsmall);
		fclose($fd);
		
		$thumblarge = get_resized_image_from_existing_file($dir.$fn,195,130, false);
		$fd = fopen($dir.'largethumb'.$fn,'wb');
		fwrite($fd,$thumblarge);
		fclose($fd);
		
		$thumbxlarge = get_resized_image_from_existing_file($dir.$fn,267,178, false);
		$fd = fopen($dir.'xlargethumb'.$fn,'wb');
		fwrite($fd,$thumbxlarge);
		fclose($fd);
	}
}

function attach_setup_directory($dir) {
	if (!file_exists($dir)) {
		return @mkdir($dir, 0700, true); 
	} else {
		return true;
	}
}

//function attach_make_file_matrix($filename)	{
//	$matrix_depth = 5;
//	$invalid_fs_chars = '*\'\\/"!$%^&*.%(){}[]#~?<>;|¬`@-+=';
//	
//	$matrix = "";
//	
//	$name = $filename;
//	$filename = attach_mb_str_split($filename);
//	if (!$filename) return false;
//	
//	$len = count($filename);
//	if ($len>$matrix_depth)
//		$len = $matrix_depth;
//	
//	for ($n = 0; $n < $len; $n++) {
//		
//		// Prevent a matrix being formed with unsafe characters
//		$char = $filename[$n];
//		if (strpos($invalid_fs_chars, $char)!==false)
//			$char = '_';
//		
//		$matrix .= $char . "/";
//	}	
//
//	return $matrix.$name."/";
//}

// TODO: I probably need to do something intelligent if a username is passed
// instead of a guid to support older versions of this plugin

function attach_make_file_matrix($guid) {
	// lookup the entity
	$user = get_entity($guid);
	if ($user->type != 'user')
	{
		// only to be used for user directories
		return FALSE;
	}

	$time_created = date('Y/m/d', $user->time_created);
	return "$time_created/$user->guid/";
}

function attach_mb_str_split($string, $charset = 'UTF8') {
	if (is_callable('mb_substr'))
	{
		$length = mb_strlen($string);
		$array = array();
		
		while ($length)
		{
			$array[] = mb_substr($string, 0, 1, $charset);
			$string = mb_substr($string, 1, $length, $charset);
			
			$length = mb_strlen($string);
		}
		
		return $array;
	}
	else
		return str_split($string);
	
	return false;
}

// if an object is created and has attachments, add the attachment tokens as annotations
// TODO - get this to work properly if updating an entity

function attach_object_creation($event,$entity_type,$entity) {
	$number_of_attachments = (int) get_input('number_of_attachments',0);
	if ($number_of_attachments > 0) {
		for($i=0;$i<$number_of_attachments;$i++) {
			$token = get_input('attachment_'.$i,'');
			if ($token) {
				/*$a = explode(',',$token);
				$dir = $a[0];
				$fn = $a[1];
				$ofn = $a[2];
				$mime_type = $a[3];
				$guid = $a[4];*/
				$entity->annotate('attachment',$token,ACCESS_PUBLIC,$entity->owner_guid,'text');
			}
		}
	}
	
	return true;
}

function attach_get_token_dict($guid,$internalname) {
	$as = get_annotations($guid,'','','attachment');
	if ($as) {
		foreach($as as $a) {
			$vs = explode(",",$a->value);
			if (count($vs) == 6) {
				$type = $vs[0];
				$fn = $vs[1];
				$ofn = $vs[2];
				$mime_type = $vs[3];
				$this_fieldname = $vs[4];
				$guid = $vs[5];
				if ($this_fieldname == $internalname) {
					return array(
						'id'=>$a->id,
						'type'=>$type,
						'fn'=>$fn,
						'ofn'=>$ofn,
						'mime_type' => $mime_type,
						'fieldname' => $this_fieldname,
						'user_guid' => $guid
					);
				}
			}
		}
	}
	return array();
}
?>