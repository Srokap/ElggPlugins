<?php

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
// load plugin model
require_once(dirname(__FILE__)."/models/model.php");

global $CONFIG;

$size = get_input('size','thumb');
if ($size == 'full') {
	$size = '';
}
$id = get_input('id');
$annotation = get_annotation($id);
if ($annotation) {
	$entity_guid = $annotation->entity_guid;
	
	// the Elgg API does not seem to enforce entity access for annotations, so we check here
	// to make sure that the user really does have the right to see the object with this
	// attachment annotation
	
	if (get_entity($entity_guid)) {
		$token = $annotation->value;
		$a = explode(',',$token);
		if (count($a) == 5) {
			$attachment_type = $a[0];
			$fn = $a[1];
			$ofn = $a[2];
			$mime_type = $a[3];
			$username = $a[4];
		} else {
			$attachment_type = $a[0];
			$fn = $a[1];
			$ofn = $a[2];
			$mime_type = $a[3];
			$username = $a[5];
		}
		header("Content-Disposition: inline; filename=\"$fn\"");
		header("Content-type: ".$mime_type);
		$content = file_get_contents($CONFIG->dataroot.attach_make_file_matrix($username).'attachments/'.$size.$fn);
		header("Content-Length: " . strlen($content));
		$splitString = str_split($content, 8192);
		foreach($splitString as $chunk) {
			echo $chunk;
		}
	}
}
exit;
	
?>