<?php

	/**
	 * Elgg media attach plugin
	 * 
	 * @package attach
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Kevin Jardine <kevin@radagast.biz>
	 * @copyright Radagast Solutions 2008-2009
	 * @link http://radagast.biz/
	 */

	// load plugin model
	require_once(dirname(__FILE__)."/models/model.php");

	/**
	 * Init function
	 *
	 */
		function attach_init() {
			
			extend_view('css','attach/css');
				
			// Page handler for attach
			register_page_handler('attach','attach_page_handler');
			
			// add attachment support to form plugin
			if (is_plugin_enabled('form')) {
				form_custom_field_type_manager('attachment',elgg_echo('attach:form_element_label'),'input/attachment','output/attachment');
			}
			
		}
		
	/**
	 * Runs the 'attach' script
	 *
	 */
		function attach_page_handler($page) {
			
		switch($page[0]) {
				case 'form':		require_once(dirname(__FILE__) . '/form.php');
									exit;
									break;
				default:			require_once(dirname(__FILE__) . '/media.php');
									exit;
									break;			
			}			
		}
		

	// Register the init action
		register_elgg_event_handler('init','system','attach_init');
		
	// respond to create and update actions
		register_elgg_event_handler('create','object','attach_object_creation');
		
	// Register actions
		global $CONFIG;
		register_action("attach/add",false,$CONFIG->pluginspath . "attach/actions/add.php");
		register_action("messages/send",false,$CONFIG->pluginspath . "attach/actions/messages_send.php");

?>