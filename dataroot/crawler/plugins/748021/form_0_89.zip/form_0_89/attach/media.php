<?php
global $CONFIG;

echo '<h1>'.elgg_echo('attach:content').'</h1>';
// support file attachments
// TODO: add Flickr/Youtube support
$body = elgg_view('input/file',array('internalname'=>'attachment'));
$body .= elgg_view('input/hidden',array('internalname'=>'owner_guid','value'=>get_input('owner_guid',0)));
$body .= '<br /><br />'.elgg_view('input/submit',array('value'=>elgg_echo("attach:button")));
$form = elgg_view('input/form',array('internalid'=>'contentUpload','body'=>$body,'action'=>$CONFIG->wwwroot.'action/attach/add'));

echo $form;
?>
<script type="text/javascript"> 
	// wait for the DOM to be loaded 
    //$(document).ready(function() { 
            // bind 'myForm' and provide a simple callback function 
            $('#contentUpload').submit(function() { 
            var options = {  
			    success: function(response) {
			    	var number_of_attachments = parseInt($('#number_of_attachments').val());
			    	var bits = response.split("||");
			    	var token_bits = bits[2].split(",");
			    	
			    	var delete_title = '<?php echo elgg_echo('attach:delete:title'); ?>';
					var title_bit = ' title = "'+delete_title+'" alt="'+delete_title+'" ';
					var js_bit = ' onclick="javascript:attach_delete_temporary_attachment('+number_of_attachments+',\''+bits[0]+'\')"';
					var c = '<div class="attachment_name">';
					c += token_bits[2];
					c += '</div>';
					c += '<div class="attachment_controls">';
					c += '<img '+title_bit+js_bit+'src="<?php echo $CONFIG->wwwroot; ?>_graphics/icon_customise_remove.gif" />'
					c += '</div>';
			    	
			        var h = $('#messages_attachments').html();
			        h += '<div class="attachment_temporary_form_listing" id="attachment_container_'+number_of_attachments+'">';
			        h += bits[1]+c;
					h += '<input type="hidden" name="attachment_'+number_of_attachments+'" value="'+bits[2]+'">';
					h += '<br clear="both" />';
					h += '</div>';
					$('#number_of_attachments').val(number_of_attachments+1);
			        $('#messages_attachments').html(h);
			        $.facebox.close();
			    } 
			}; 
            $(this).ajaxSubmit(options);
                return false; 
            }); 
        //}); 
</script>
