<?php

	$english = array(
	
		'attach:content' => "Attach content",
		'attach:button' => "Attach",
		'attach:message_label' => "Attachments:",
		'attach:delete:title' => "Delete attachment",
		'attach:attachments:title' => "Attachments",
		'attach:downloadfailed' => "Download failed",
		'attach:upload:local:label' => "Local file upload",
		'attach:upload:local:description' => "Upload a file from your local computer.",
		'attach:upload:url:label' => "Url file upload",
		'attach:upload:url:description' => "Upload a file by giving its Internet URL (for example, from Flickr).",
		'attach:settings:messages:title' => "Support attachments in private messages system",
		'attach:settings:url_upload:title' => "Support attaching through URLs (requires libcurl)",
		'attach:settings:yes' => "yes",
		'attach:settings:no' => "no",
		'attach:form_element_label' => "File attachment",
		'attach:none' => "No attachment",
		
	);
					
	add_translation("en",$english);

?>