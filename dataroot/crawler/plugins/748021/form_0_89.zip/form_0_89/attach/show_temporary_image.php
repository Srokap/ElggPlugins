<?php

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
// load plugin model
require_once(dirname(__FILE__)."/models/model.php");

// TODO - add security check to make sure that either an admin is logged-in or
// the username is for the current logged-in user

$username = get_input("username");
$fn = get_input('fn');
header("Content-Disposition: inline; filename=\"$fn\"");
$content = file_get_contents($CONFIG->dataroot.attach_make_file_matrix($username).'attachments/thumb'.$fn);
$splitString = str_split($content, 8192);
foreach($splitString as $chunk) {
	echo $chunk;
}
exit;
	
?>