<?php

$guid = $vars['value'];
$internalname = $vars['internalname'];
if (isset($vars['size'])) {
	$size = $vars['size'];
} else {
	$size = 'largethumb';
}
$t = attach_get_token_dict($guid,'form_data_'.$internalname);
//error_log("attach_get_token_dict($guid,$internalname)");
//error_log(print_r($t,true));
$mime = $t['mime_type'];
$ofn = $t['ofn'];
$id = $t['id'];

$title_bit = " title = \"$ofn\" alt=\"$ofn\" ";
$body = '<div class="attachment_listing_item">';

if (substr_count($mime,'image/')) {
	$image = '<img src="'.$vars['url'].'mod/attach/show_attachment_image.php?id='.$id.'&size='.$size.'">';
} else {
	// TODO: copy the file icon view directory so that this will work even if
	// the file plugin is turned off
	$image = elgg_view("file/icon", array("mimetype" => $mime, 'size' => $size));
}
$body .= '<a '.$title_bit.'href="'.$CONFIG->wwwroot.'mod/attach/download.php?id='.$id.'">'.$image.'</a>';
$body .= '</div>';	
$body .= '<br clear="both" /><br />';	

echo $body;

?>