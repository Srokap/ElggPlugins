<script type="text/javascript">
function attach_delete_temporary_attachment(an,link) {
	// remove the attachment container div and run the delete link
	$('#attachment_container_'+an).remove();
	$.get(link);
} 
</script>
<label><?php echo elgg_echo('attach:message_label'); ?><br /></label>
<div id="messages_attachments"></div>
<br />
<a href="<?php echo $vars['url'] . 'pg/attach/media?owner_guid='.page_owner(); ?>" rel="facebox"><?php echo elgg_echo('attach:content'); ?></a><br />
<input type="hidden" id="number_of_attachments" name="number_of_attachments" value="0" />