<?php
$yn_options = array(elgg_echo('attach:settings:yes')=>'yes',
	elgg_echo('attach:settings:no')=>'no',
);

$body = '';

$attach_message_attachments = get_plugin_setting('message_attachments', 'attach');
if (!$attach_message_attachments) {
	$attach_message_attachments = 'no';
}

$body .= elgg_echo('attach:settings:messages:title');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[message_attachments]','value'=>$attach_message_attachments,'options'=>$yn_options));

$body .= '<br />';

$attach_url_upload = get_plugin_setting('url_upload', 'attach');
if (!$attach_url_upload) {
	$attach_url_upload = 'no';
}

$body .= elgg_echo('attach:settings:url_upload:title');
$body .= '<br />';
$body .= elgg_view('input/radio',array('internalname'=>'params[url_upload]','value'=>$attach_url_upload,'options'=>$yn_options));


echo $body;
?>