<?php
/**
 * Single attachment view for entity creation forms
 * 
 * @package attach
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008-2009
 * @link http://radagast.biz/
 * 
 */
$attach_url_upload = get_plugin_setting('url_upload', 'attach') == 'yes';
if (isset($vars['internalname'])) {
	$internalname = $vars['internalname'];
} else {
	$internalname = 'attachment';
}

echo elgg_view('input/hidden',array('internalname'=>$internalname.'_image_size','value'=>$vars['image_size']));

$local_upload = elgg_view('input/file',array('internalname'=>$internalname));
if ($attach_url_upload) {
	$local_upload .= '<p class="attachment_description">'.elgg_echo('attach:upload:local:description').'</p>';
}
$local_upload .=  elgg_view('input/hidden',array('internalname'=>$internalname.'attachment_type','value'=> 'local'));

if ($attach_url_upload) {
	$url_upload = elgg_view('input/text',array('internalname'=>$internalname));
	$url_upload .= '<p class="attachment_description">'.elgg_echo('attach:upload:url:description').'</p>';
	$url_upload .=  elgg_view('input/hidden',array('internalname'=>$internalname.'attachment_type','value'=> 'url'));
}

if ($attach_url_upload) {
?>
<div class="attach_horizontal_tabbed_nav">
	<ul>
		<li>
			<a id="attachment_local_tab" class="selected" href="#" onclick="javascript:attachment_select_local_upload(); return false;"><?php echo elgg_echo('attach:upload:local:label'); ?></a>
		</li>
		<li>
			<a id="attachment_url_tab" class="unselected" href="#" onclick="javascript:attachment_select_url_upload(); return false;"><?php echo elgg_echo('attach:upload:url:label'); ?></a>
		</li>

	</ul>
</div>
<div class="clearfloat"></div>
<?php } ?>
<div id="attachment_upload">
<?php echo $local_upload; ?>
</div> <!-- /attachment_upload -->
<script type="text/javascript">
function attachment_select_local_upload() {
	$('#attachment_upload').html('<?php echo trim($local_upload); ?>');
	$('#attachment_local_tab').addClass('selected');
	$('#attachment_local_tab').removeClass('unselected');
	$('#attachment_url_tab').addClass('unselected');
	$('#attachment_url_tab').removeClass('selected');
}
function attachment_select_url_upload() {
	$('#attachment_upload').html('<?php echo trim($url_upload); ?>');
	$('#attachment_local_tab').addClass('unselected');
	$('#attachment_local_tab').removeClass('selected');
	$('#attachment_url_tab').addClass('selected');
	$('#attachment_url_tab').removeClass('unselected');	
}
</script>