<?php
/**
 * List attachments for the given entity
 * 
 * @package attach
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2008-2009
 * @link http://radagast.biz/
 * 
 * TODO: add the ability to delete attachments
 * 
 */

$entity = $vars['entity'];
$entity_guid = $entity->getGUID();
$attachments = get_annotations($entity_guid,'','','attachment');
if ($attachments) {
	echo '<p><b>'.elgg_echo('attach:attachments:title').'</b></p>';
	foreach ($attachments as $attachment) {
		echo attach_attachment_listing($entity_guid,$attachment);
	}
}
?>