.attachment_temporary_form_listing {
	padding: 5px;
	width: 400px;
	height: 60px;
}

.attachment_image {
	width: 60px;
	float:left;
}

.attachment_name {
	display:inline;
	padding: 10px;
}

.attachment_controls {
	width: 130px;
	float:right;
}