<?php

// load plugin model
require_once(dirname(dirname(__FILE__))."/models/model.php");

// save the attachment to the user's attachment directory
// and return the filestore name

$owner = get_user(get_input('owner_guid',0));

if ($owner) {
	$username = $owner->username;
	$original_name = $_FILES['attachment']['name'];
	$filestorename = strtolower(time().$original_name);
	$mime_type = $_FILES['attachment']['type'];
	$user_dir = $CONFIG->dataroot . attach_make_file_matrix($username);
	if (attach_setup_directory($user_dir)) {
		$attachment_dir = $user_dir .'attachments/';
		if (attach_setup_directory($attachment_dir)) {
			$location = $attachment_dir . $filestorename;
			$fd = fopen($location,'wb');
			$content = get_uploaded_file('attachment');
			fwrite($fd,$content);
			fclose($fd);
			unset($content);
			if (substr_count($mime_type,'image/')) {
				attach_write_thumbs($attachment_dir,$filestorename);
			}
			$response = attach_show_temporary_attachment_listing($attachment_dir,$filestorename,$original_name,$mime_type,$username);
			echo $response;
		} else {
			echo '';
		}
	} else {
		echo '';
	}
} else {
	echo '';
}

exit;
?>