<?php
$english = array(
	'workshops:admin_title' => "Manage workshop settings",
	'workshops:submit' => "Submit",
	'workshops:description' => "Enter a list of short descriptions for each available"
		." time slot (one per line). Include the maximum number of workshops after each"
		." timeslot description, separated by a comma.",
	'workshops:timeslots:label' => "Time slot descriptions",
	'workshops:workshops_per_timeslot:label' => "Workshops per time slot",
	'workshops:response' => "Your workshop settings have been saved.",
	'workshops:timeslots_dropdown' => "Workshops dropdown",
	'workshops:error:timeslot_full' => "Error: there are already too many workshops"
		." scheduled for this time slot. Please choose another time slot.",
	'workshops:workshop_full' => "This workshop is full and is not currently accepting new participants.",
	'workshops:widget:none_for_timeslot' => "You have not yet chosen a workshop in this time slot.",
	'workshops:widget:none_chosen' => "You have not chosen any workshops.",
	'workshops:widget:conflict' => "You have more than one workshop in the same time slot! This may be"
		." because some of the workshop time slots have changed. Please adjust your schedule.",
	'workshops:widget:mine_title' => "My program",
	'workshops:widget:mine_description' => "See your workshops by time slot.",
	'workshops:widget:edit:description:display' => "Time slots to show",
	'workshops:widget:option:booked_timeslots' => "my current workshop timeslots",
	'workshops:widget:option:all_timeslots' => "all time slots",
	'workshops:host'=> "Coordinator:",
	'workshops:timeslot_used' => "You cannot join this workshop because you have another workshop in the same time slot.",
	'workshops:all' => "All",
	'workshops:filter_by_category' => "Filter by category",
	'workshops:filter_by_timeslot' => "Filter by time slot",
	'workshops:search_by_host' => "Search by coordinator",
	'workshops:host_search:description' => "(Enter 2-3 letters.)",
	'workshops:host_search:submit' => "Search",
	'workshops:search:none' => "No workshops found.",
	'workshops:admin_email:label' => "Email address for workshop full notifications",
	'workshops:email:full:subject' => "Workshop full notice",
	'workshops:email:full:body' => "The workshop \"%s\" is full.
	
You can visit the workshop page here:

%s",
		
	// over-ride a lot strings so that they refer to workshops and participants
	
	// from group_fans plugin
	
	'group_fans:joined' => "You are now a fan of this workshop.",
	'group_fans:cantjoin' => "Error: unable to make you a fan of this workshop.",
	'group_fans:left' => "You are no longer a fan of this workshop.",
	'group_fans:cantleave' => "Error: cannot remove you as a fan of this workshop.",
		
	// from files plugin
	
	'file:group' => "Workshop files",
		
	// from groupriver plugin
	
	'groupriver' => 'Workshop activity',
    'groupriver:widget:title' => 'Workshop activity',
    'groupriver:widget:description' => 'Workshop activity',
		
	// from groups plugin

	'groups' => "Workshops",
	'groups:owned' => "Workshops you own",
	'groups:yours' => "Your workshops",
	'groups:user' => "%s's workshops",
	'groups:all' => "All site workshops",
	'groups:new' => "Create a new workshop",
	'groups:edit' => "Edit workshop",
	'groups:delete' => 'Delete workshop',
	'groups:membershiprequests' => 'Manage join requests',
	'groups:invitations' => 'Workshop invitations',

	'groups:icon' => 'Workshop icon (leave blank to leave unchanged)',
	'groups:name' => 'Workshop name',
	'groups:username' => 'Workshop short name (displayed in URLs, alphanumeric characters only)',
	'groups:members' => 'Participants',
	'groups:membership' => "Workshop participant permissions",
	'groups:widget:num_display' => 'Number of workshops to display',
	'groups:widget:membership' => 'Workshop membership',
	'groups:widgets:description' => 'Display the workshops you are a member of on your profile',
	'groups:noaccess' => 'No access to workshop',
	'groups:cantedit' => 'You can not edit this workshop',
	'groups:saved' => 'Workshop saved',
	'groups:featured' => 'Featured workshops',
	'groups:makeunfeatured' => 'Unfeature',
	'groups:makefeatured' => 'Make featured',
	'groups:featuredon' => 'You have made this workshop a featured one.',
	'groups:unfeature' => 'You have removed this workshop from the featured list',
	'groups:joinrequest' => 'Request membership',
	'groups:join' => 'Join workshop',
	'groups:leave' => 'Leave workshop',
	'groups:invite' => 'Invite friends',
	'groups:inviteto' => "Invite friends to '%s'",
	'groups:nofriends' => "You have no friends left who have not been invited to this workshop.",
	'groups:viagroups' => "via groups",
	'groups:group' => "Workshop",
	'groups:search:tags' => "tag",

	'groups:notfound' => "Workshop not found",
	'groups:notfound:details' => "The requested workshop either does not exist or you do not have access to it",

	'groups:count' => "workshops created",
	'groups:open' => "open workshop",
	'groups:closed' => "closed workshop",
	'groups:member' => "participants",
	'groups:searchtag' => "Search for workshops by tag",
		
	'groups:owner' => "Coordinator",

	/*
	 * Access
	 */
	'groups:access:private' => 'Closed - Participants must be invited',
	'groups:access:public' => 'Open - Any participant may join',
	'groups:closedgroup' => 'This workshop has a closed membership. To ask to be added, click the "request participation" menu link.',
	'groups:visibility' => 'Who can see this workshop?',

	/*
	Group tools
	*/
	'groups:enablepages' => 'Enable workshop pages',
	'groups:enableforum' => 'Enable workshop discussion',
	'groups:enablefiles' => 'Enable workshop files',
	'groups:yes' => 'yes',
	'groups:no' => 'no',

	'groups:pages' => 'Workshop pages',
	'groups:files' => 'Workshop files',

	/*
	Group forum strings
	*/

	'groups:forum' => 'Workshop discussion',
	'grouptopic:error' => 'Your workshop topic could not be created. Please try again or contact a system administrator.',
	'groups:privategroup' => 'This workshop is private, requesting membership.',
	'groups:notitle' => 'Workshop must have a title',
	'groups:cantjoin' => 'Can not join workshop',
	'groups:cantleave' => 'Could not leave workshop',
	'groups:addedtogroup' => 'Successfully added the user to the workshop',
	'groups:joinrequestnotmade' => 'Could not request to join workshop',
	'groups:joinrequestmade' => 'Requested to join workshop',
	'groups:joined' => 'Successfully joined workshop!',
	'groups:left' => 'Successfully left workshop',
	'groups:notowner' => 'Sorry, you are not the coordinator of this workshop.',
	'groups:notmember' => 'Sorry, you are not a participant in this workshop.',
	'groups:alreadymember' => 'You are already a participant in this workshop!',
	'groups:userinvited' => 'This participant has been invited.',
	'groups:usernotinvited' => 'This participant could not be invited.',
	'groups:useralreadyinvited' => 'This participant has already been invited',

	'groups:invite:body' => "Hi %s,

%s invited you to join the '%s' workshop. Click below to confirm:

%s",

	'groups:welcome:subject' => "Welcome to the %s workshop!",
	'groups:welcome:body' => "Hi %s!

You are now a member of the '%s' workshop! Click below to begin posting!

%s",

	'groups:request:subject' => "%s has requested to join %s",
	'groups:request:body' => "Hi %s,

%s has requested to join the '%s' workshop. Click below to view their profile:

%s

or click below to confirm request:

%s",

	/*
		Forum river items
	*/

	'groups:river:member' => '%s is now a participant in',
	'groups:river:togroup' => 'to the group',

	'groups:nowidgets' => 'No widgets have been defined for this workshop.',


	'groups:widgets:members:title' => 'Participants',
	'groups:widgets:members:description' => 'List the participants in a workshop.',
	'groups:widgets:members:label:displaynum' => 'List the participants in a workshop.',
	'groups:widgets:members:label:pleaseedit' => 'Please configure this widget.',

	'groups:widgets:entities:title' => "Workshop content",
	'groups:widgets:entities:description' => "List the content associated with a workshop.",
	'groups:widgets:entities:label:displaynum' => 'List the content associated with a workshop.',

	'groups:allowhiddengroups' => 'Do you want to allow private (invisible) workshops?',

	/**
	 * Action messages
	 */
	'group:deleted' => 'Workshop and workshop contents deleted',
	'group:notdeleted' => 'Workshop could not be deleted',

	'grouppost:deleted' => 'Workshop posting successfully deleted',
	'grouppost:notdeleted' => 'Workshop posting could not be deleted',
	'groups:deletewarning' => "Are you sure you want to delete this workshop? There is no undo!",
		
	/*
	 * Members
	 */
		
	'members:members' => "Participants",

);
				
add_translation("en",$english);
?>
