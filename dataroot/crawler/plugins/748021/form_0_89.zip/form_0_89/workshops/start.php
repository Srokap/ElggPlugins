<?php
// Load model
require_once(dirname(__FILE__) . "/models/model.php");

function workshops_init() {
	// Register a page handler, so we can have nice URLs
	register_page_handler('workshops','workshops_page_handler');
	register_page_handler('groups','workshops_groups_page_handler');
	if (is_plugin_enabled('form')) {
		form_custom_field_type_manager('workshops_timeslots',elgg_echo('workshops:timeslots_dropdown'),'workshops/input/timeslots','form/output/choice');
	}
	add_widget_type('workshops_mine',elgg_echo('workshops:widget:mine_title'),elgg_echo('workshops:widget:mine_description'));
}

function workshops_pagesetup() {
	
	global $CONFIG;
	    	
    if (get_context() == 'admin' && isadminloggedin()) {
    	add_submenu_item(elgg_echo('workshops:admin_title'), $CONFIG->wwwroot . 'pg/workshops/admin');
    }
    
    $page_owner = page_owner_entity();
    
    if ((get_context() == 'groups') && ($page_owner instanceof ElggGroup) ) {
    	$user = get_loggedin_user();
    	if (!workshops_join_check($page_owner,$user)) {
	    	// remove the join link if it exists
			if (isset($CONFIG->submenu) && isset($CONFIG->submenu['1groupsactions'])) {
				foreach($CONFIG->submenu['1groupsactions'] as $k=>$sm) {
					if (strpos($sm->value,'action/groups/join?') != false) {
						unset($CONFIG->submenu['1groupsactions'][$k]);
					}
				}
			}
    	}
    }
}

function workshops_page_handler($page) {
	if (isset($page[0]) && ($page[0] == 'admin')) {
		include(dirname(__FILE__) . "/pages/admin.php");
	} else {
		include(dirname(__FILE__) . "/pages/all.php");
	}
	return true;
}

function workshops_groups_page_handler($page) {
	if (isset($page[0]) && ($page[0] == 'world')) {
		include(dirname(__FILE__) . "/pages/all.php");
		return true;
	} else {
		groups_page_handler($page);
	}
}

register_elgg_event_handler('groupprofile_preupdate','group','workshops_check_timeslot');
register_plugin_hook('description','group','workshops_join_message');

register_elgg_event_handler('init','system','workshops_init');
register_elgg_event_handler('pagesetup','system','workshops_pagesetup');

register_elgg_event_handler('join', 'group', 'workshops_join');
register_elgg_event_handler('leave', 'group', 'workshops_leave');

// Register actions
global $CONFIG;
register_action("workshops/admin",false,$CONFIG->pluginspath . "workshops/actions/admin.php");
