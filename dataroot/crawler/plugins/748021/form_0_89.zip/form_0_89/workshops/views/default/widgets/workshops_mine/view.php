<?php

/**
 * Elgg workshops widget
 *
 * @package workshops
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Kevin Jardine <kevin@radagast.biz>
 * @copyright Radagast Solutions 2010
 * @link http://radagast.biz/
 *
 */

// Load workshops model
require_once(dirname(dirname(dirname(dirname(dirname(__FILE__)))))."/models/model.php");
$content = '';
$workshops = workshops_for_user($vars['entity']->owner_guid);
if ($workshops) {	
	$timeslots = array_keys(workshops_get_timeslot_data());
	foreach($timeslots as $timeslot) {
		if (!isset($workshops[$timeslot])) {
			if ($vars['entity']->display == 'all_timeslots') {					
				// empty timeslot
				$content .= '<h3>'.$timeslot.'</h3>';
				$content .= '<p>'.elgg_echo('workshops:widget:none_for_timeslot').'</p>';
			}
		} else {
			$content .= '<h3>'.$timeslot.'</h3>';
			foreach ($workshops[$timeslot] as $workshop) {
				$icon = elgg_view(
					"groups/icon", array(
										'entity' => $workshop,
										'size' => 'small',
									  )
					);
					
				$host = get_user($workshop->owner_guid);
				$host_bit = '<a href="'.$host->getUrl().'">'.$host->name.'</a>';
					
				$content .= "<div class=\"search_listing\"><div class=\"search_listing_icon\">" . $icon . "</div><div class='search_listing_info'><p><span>" . $workshop->name . "</span><br />";
				$content .= elgg_echo('workshops:host')." ".$host_bit."</p></div></div>";				
			}
			if (count($workshops[$timeslot]) > 1) {
				$content .= '<p class="workshops_conflict">'.elgg_echo('workshops:widget:conflict').'</p>';
			}
		}
	}	
} else {
	$content = '<p>'.elgg_echo('workshops:widget:none_chosen').'</p>';
}
echo "<div class=\"contentWrapper\">";
echo $content;
echo "</div>";
	
?>