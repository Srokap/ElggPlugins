<?php
$options = array();
$timeslot_data = workshops_get_timeslot_data();
foreach(array_keys(workshops_get_timeslot_data()) as $timeslot_name) {
	$count = get_entities_from_metadata('workshops_timeslots',$timeslot_name,'group','',0,10,0,'',0,true);
	if ($count < $timeslot_data[$timeslot_name]) {
		// only show available time slots
		$options[$timeslot_name] = $timeslot_name;
	}
}
$vars['options'] = $options;
echo elgg_view('input/pulldown',$vars);
?>