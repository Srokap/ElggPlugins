<?php
$url_start = $vars['url']."pg/workshops/world?filter=".$vars['filter'];
if (function_exists('form_get_group_profile_categories')) {
	$category_list = trim(form_get_group_profile_categories());
	if ($category_list) {
		$c_options_values = array('-' =>elgg_echo('workshops:all'));
		foreach(explode("\n",$category_list) as $category_item) {
			$category_item = trim($category_item);
			$c_options_values[urlencode($category_item)] = $category_item;
		}
		$cjs = "onchange=\"javascript:$('#workshop_list').load('".$url_start."&amp;callback=true&amp;timeslot='+$('#timeslot').val()+'&amp;category='+$('#category').val());\"";
	}
}

$timeslots = array_keys(workshops_get_timeslot_data());
if ($timeslots) {
	$t_options_values = array('-' =>elgg_echo('workshops:all'));
	foreach($timeslots as $timeslot) {
		$timeslot = trim($timeslot);
		$t_options_values[urlencode($timeslot)] = $timeslot;
	}
	$tjs = "onchange=\"javascript:$('#workshop_list').load('".$url_start."&amp;callback=true&amp;category='+$('#category').val()+'&amp;timeslot='+$('#timeslot').val());\"";
}
	 
?>
<div class="sidebarBox">
<h3><?php echo elgg_echo('workshops:filter_by_timeslot'); ?></h3>
<?php echo elgg_view("input/pulldown",array('internalid' => 'timeslot','js'=>$tjs,'value'=>$vars['timeslot'],'options_values'=>$t_options_values)); ?>
</div>
<div class="sidebarBox">
<h3><?php echo elgg_echo('workshops:filter_by_category'); ?></h3>
<?php echo elgg_view("input/pulldown",array('internalid' => 'category','js'=>$cjs,'value'=>$vars['category'],'options_values'=>$c_options_values)); ?>
</div>
<div class="sidebarBox">
<h3><?php echo elgg_echo('workshops:search_by_host'); ?></h3>
<form id="host_search_form" action="<?php echo $vars['url']; ?>pg/groups/world"  method="post">
	<?php echo elgg_view('input/members_complete',array('minChars'=>2,'internalname'=>'host','internalid'=>'host','value'=>$vars['host'],'width'=>300)); ?>
	<br /><?php echo elgg_echo('workshops:host_search:description'); ?>
	<?php echo elgg_view('input/submit', array('internalname'=>'submit','value'=>elgg_echo('workshops:host_search:submit'))); ?>
</form>
</div>