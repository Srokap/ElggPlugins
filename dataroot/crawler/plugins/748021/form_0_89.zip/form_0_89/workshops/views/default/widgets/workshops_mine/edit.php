<?php
if (!$vars['entity']->display) {
	$display = 'booked_timeslots';
} else {
	$display = $vars['entity']->display;
}
$options = array(
	'booked_timeslots'=>elgg_echo('workshops:widget:option:booked_timeslots'),
	'all_timeslots'=>elgg_echo('workshops:widget:option:all_timeslots')
	);
?>

<p>
	<?php echo elgg_echo("workshops:widget:edit:description:display"); ?>:
	<?php echo elgg_view("input/pulldown",array('internalname' => 'params[display]','value'=>$display,'options_values'=>$options)); ?>
</p>