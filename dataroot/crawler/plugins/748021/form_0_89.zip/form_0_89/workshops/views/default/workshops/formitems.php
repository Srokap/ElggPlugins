<?php

$timeslots = get_plugin_setting('timeslots','workshops');
$admin_email = get_plugin_setting('admin_email','workshops');

if ($vars['error']) {
	$error = '<p>'.$error.'</p>';
} else {
	$error = '';
}

?>
<?php echo $error; ?>
<p><?php echo elgg_echo('workshops:description'); ?></p>
<p><label>
	<?php echo elgg_echo('workshops:timeslots:label'); ?>
</label>
</p>
<p><textarea class="input-textarea" name="timeslots" ><?php echo $timeslots; ?></textarea></p>

<p><label>
	<?php echo elgg_echo('workshops:admin_email:label'); ?>
</label>
<?php echo elgg_view('input/text', array('internalname'=>'admin_email','value'=>$admin_email)); ?>
</p>