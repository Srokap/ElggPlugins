<?php
$body = elgg_view('workshops/formitems',$vars);
$body .= elgg_view('input/submit',array('value'=>elgg_echo('workshops:submit')));
$body = elgg_view('page_elements/contentwrapper',array('body'=>$body));

echo elgg_view('input/form', array(
		'action' => $vars['url'] . 'action/workshops/admin',
		'body' => $body,
		'method' => 'post'
	)
);