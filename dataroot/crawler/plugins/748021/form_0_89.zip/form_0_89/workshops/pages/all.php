<?php
/**
 * Elgg groups plugin
 * 
 * @package ElggGroups
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider Ltd
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.com/
 */


$limit = get_input("limit", 10);
$offset = get_input("offset", 0);
$callback = get_input("callback");
$tag = get_input("tag");
$filter = get_input("filter","default");
$category = get_input("category","-");
$timeslot = get_input("timeslot","-");
$host = get_input("host","");
if ($host) {
	$host_guid = autocomplete_member_to_user_guid($host);
}

// Get objects
$context = get_context();

set_context('search');
if ($tag != "")
	$objects = list_entities_from_metadata('tags',$tag,'group',"","", $limit, false);
else{
	switch($filter){
		case "newest":
		$objects = elgg_list_entities(array('types' => 'group', 'owner_guid' => 0, 'limit' => $limit, 'offset' => $offset, 'full_view' => false));
		break;
		case "pop":
		$objects = list_entities_by_relationship_count('member', true, "", "", 0, $limit, false);
		break;
		case "active":
		$objects = list_entities_from_annotations("object", "groupforumtopic", "group_topic_post", "", 40, 0, 0, false, true);
		break;
		case 'default':
			if ($host_guid) {
				$objects = elgg_list_entities(array('owner_guid' => $host_guid,'types' => 'group', 'limit' => $limit,'offset' => $offset, 'full_view' => FALSE));
			} else if (($category != '-') && ($timeslot != '-')) {
				$conditions = array('group_profile_category' => $category, 'workshops_timeslots' => $timeslot);
				$objects = list_entities_from_metadata_multi($conditions, "group","",0,$limit,false,false,true);
			} else if ($category != '-') {
				$objects = list_entities_from_metadata("group_profile_category", $category, "group","",0,$limit,false,false,true);
			} else if ($timeslot != '-') {
				$objects = list_entities_from_metadata("workshops_timeslots", $timeslot, "group","",0,$limit,false,false,true);
			} else {
				$objects = elgg_list_entities(array('types' => 'group', 'limit' => $limit, 'offset' => $offset,'full_view' => FALSE));
			}
		break;
	}
}

if (!$objects) {
	$objects = elgg_echo('workshops:search:none');
}

if ($callback) {
	echo $objects;
} else {
	$objects = '<div id="workshop_list">'.$objects.'</div>';
	
	//get a group count
	$group_count = elgg_get_entities(array('types' => 'group', 'limit' => 10, 'count' => TRUE));
		
	//find groups
//	$workshops_tag_search = get_plugin_setting('tag_search','workshops') != 'no';
//	if ($workshops_tag_search) {
//		$area1 = elgg_view("groups/find");
//	} else {
		$area1 = '';
//	}
	
	$area1 .= elgg_view('workshops/side_menu',array('filter'=>$filter,'category'=>$category,'timeslot'=>$timeslot,'host'=>$host));
	
	//menu options
	$area1 .= elgg_view("groups/side_menu");
	
	//featured groups
	$featured_groups = elgg_get_entities_from_metadata(array('metadata_name' => 'featured_group', 'metadata_value' => 'yes', 'types' => 'group', 'limit' => 10));
	$area1 .= elgg_view("groups/featured", array("featured" => $featured_groups));
		
		
	set_context($context);
	
	$title = sprintf(elgg_echo("groups:all"),page_owner_entity()->name);
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('groups/contentwrapper', array('body' => $objects));
	$body = elgg_view_layout('sidebar_boxes',$area1, $area2);
	
	// Finally draw the page
	page_draw($title, $body);
}

?>