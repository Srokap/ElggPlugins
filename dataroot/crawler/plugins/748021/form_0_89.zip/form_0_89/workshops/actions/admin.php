<?php
global $CONFIG;

set_plugin_setting('timeslots',get_input('timeslots'),'workshops');
set_plugin_setting('admin_email',get_input('admin_email'),'workshops');

system_message(elgg_echo('workshops:response'));

forward($CONFIG->wwwroot.'pg/admin');
?>