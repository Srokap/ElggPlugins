<?php
function workshops_check_timeslot($event, $event_type, $params) {
	$entity = $params['entity'];
	$data = $params['data'];
	if ($data && isset($data['workshops_timeslots'])) {
		$timeslot = $data['workshops_timeslots']->value;
		//$workshops_per_timeslot = get_plugin_setting('workshops_per_timeslot','workshops');
		$timeslot_data = workshops_get_timeslot_data();
		if (!isset($timeslot_data[$timeslot]) || ($timeslot_data[$timeslot] == 0)) {
			// do nothing if this not set (or zero)
			return true;
		} else if ($entity instanceof ElggGroup) {
			$current_timeslot = $entity->workshops_timeslots;
			if ($current_timeslot == $timeslot) {
				// don't complain if the time slot has not changed
				return true;
			}
		}
		$count = get_entities_from_metadata('workshops_timeslots',$timeslot,'group','',0,10,0,'',0,true);
		if ($count >= $timeslot_data[$timeslot]) {
			// oops, time slot is full, so refuse to make this change
			register_error(elgg_echo('workshops:error:timeslot_full'));
			return false;
		}
	}
	
	return true;
}

function workshops_join_check($group,$user) {
	if (!$group->isMember($user)) {
		
		// check enrollment
		$maximum_enrollment = (int) $group->workshops_maximum_enrollment;
	    if ($maximum_enrollment) {
	    	$member_count = $group->getMembers(10,0,true);
	    	if ($member_count >= $maximum_enrollment) {
	    		return false;
	    	} else if ($member_count == ($maximum_enrollment-1)) {
	    		$admin_email = get_plugin_setting('admin_email','workshops');
	    		if ($admin_email) {
	    			$subject = elgg_echo('workshops:email:full:subject');
	    			$message = sprintf(elgg_echo('workshops:email:full:body'),$group->name, $group->getUrl());
	    			//error_log("workshops_join_check: sending email to {$admin_email}");
	    			workshops_email_user('', $admin_email, $subject, $message);
	    		}
	    	}
	    }
	    
	   	// check scheduling	    
	    $timeslot = $group->workshops_timeslots;
	    $user_guid = $user->guid;
	    
		// get the user's groups
	    $groups = get_entities_from_relationship('member', $user_guid, false,'','',0,'',500);
	    foreach ($groups as $g) {
	    	if ($g->workshops_timeslots == $timeslot) {
	    		// this user is already signed up for a workshop in this timeslot
	    		return false;
	    	}	    		
	    }
	}
	
	return true;
}

function workshops_join_message($hook, $entity_type, $returnvalue, $params) {
	$group = $params['entity'];

	$user = get_loggedin_user();
	
	$user_guid = $user->guid;
	
	if (!$group->isMember($user)) {	
		// check maximum enrollment condition
		$maximum_enrollment = $group->workshops_maximum_enrollment;
	    if ($maximum_enrollment) {
	    	$member_count = $group->getMembers(10,0,true);
	    	if ($member_count >= (int)$maximum_enrollment) {
		    	$msg = '<p>'.elgg_echo('workshops:workshop_full').'</p>';
		    	if ($returnvalue) {
		    		// append if another plugin has already called this hook
		    		return $returnvalue.$msg;
		    	} else {
		    		return $msg;
		    	}
	    	}
	    }
	    
	    // check scheduling situation
	    
	    $timeslot = $group->workshops_timeslots;
	    
	    // get the user's groups
	    $groups = get_entities_from_relationship('member', $user_guid, false,'','',0,'',500);
	    foreach ($groups as $g) {
	    	if (($g->workshops_timeslots == $timeslot) && ($g->guid != $group->guid)) {
	    		// this user is already signed up for another workshop in this timeslot
	    		$msg = '<p>'.elgg_echo('workshops:timeslot_used').'</p>';
		    	if ($returnvalue) {
		    		// append if another plugin has already called this hook
		    		return $returnvalue.$msg;
		    	} else {
		    		return $msg;
		    	}
		    	break;
	    	}	    		
	    }
	}
    return '';
}

function workshops_for_user($user_guid) {
	$groups = get_entities_from_relationship('member', $user_guid, false, 'group', "", 0, "", 1000);
	$timeslots = array();
	foreach ($groups as $group) {
		$timeslot = $group->workshops_timeslots;
		if (!isset($timeslots[$timeslot])) {
			$timeslots[$timeslot] = array($group);
		} else {
			$timeslots[$timeslot][] = $group;
		}
	}
	return $timeslots;
}

function workshops_join($event, $object_type, $object) {
	// currently just sets email notification
		
	$group = $object['group'];
	$user = $object['user'];
	$user_guid = $user->getGUID();
	$group_guid = $group->getGUID();
	$method = 'email';
	
	if (!check_entity_relationship($user_guid, 'notify'. $method, $group_guid)) {
		add_entity_relationship($user_guid, 'notify' . $method, $group_guid);
	}						
	return true;
}
	
function workshops_leave($event, $object_type, $object) {
	// currently just sets email notification
		
	$group = $object['group'];
	$user = $object['user'];
	$user_guid = $user->getGUID();
	$group_guid = $group->getGUID();
	$method = 'email';
	
	if (check_entity_relationship($user_guid, 'notify'. $method, $group_guid)) {
		remove_entity_relationship($user_guid, 'notify' . $method, $group_guid);
	}				
	
	return true;
}

function workshops_get_timeslot_data() {
	$result = array();
	$timeslots = trim(get_plugin_setting('timeslots', 'workshops'));

	if ($timeslots) {
		// make sure that we are using Unix line endings
		$timeslots = str_replace("\r\n","\n",$timeslots);
		$timeslots = str_replace("\r","\n",$timeslots);
		$options = array();
		foreach(explode("\n",$timeslots) as $timeslot) {
			$timeslot_data = explode(",",$timeslot);
			$timeslot_name = trim($timeslot_data[0]);
			$timeslot_maximum = trim($timeslot_data[1]);
			$result[$timeslot_name] = (int) $timeslot_maximum;
		}
	}
	
	return $result;
}

function workshops_email_user($name, $email, $subject, $message) {
	
	global $CONFIG;

	// **** this should be replaced by a core function for sending emails to people who are not members
	$site = get_entity($CONFIG->site_guid);
	if (($site) && (isset($site->email))) {
		// Has the current site got a from email address?
		$from = $site->email;
	} else {
		// If all else fails, use the domain of the site.
		$from = 'noreply@' . get_site_domain($CONFIG->site_guid);
	}

	if (is_callable('mb_internal_encoding')) {
		mb_internal_encoding('UTF-8');
	}
	$sitename = $site->name;
	if (is_callable('mb_encode_mimeheader')) {
		$sitename = mb_encode_mimeheader($sitename,"UTF-8", "B");
	}

	$header_eol = "\r\n";
	if ((isset($CONFIG->broken_mta)) && ($CONFIG->broken_mta)) {
		// Allow non-RFC 2822 mail headers to support some broken MTAs
		$header_eol = "\n";
	}

	$from_email = "\"$sitename\" <$from>";
	if (strtolower(substr(PHP_OS, 0 , 3)) == 'win') {
		// Windows is somewhat broken, so we use a different format from header
		$from_email = "$from";
	}

	$headers = "From: $from_email{$header_eol}"
		. "Content-Type: text/plain; charset=UTF-8; format=flowed{$header_eol}"
		. "MIME-Version: 1.0{$header_eol}"
		. "Content-Transfer-Encoding: 8bit{$header_eol}";
		
	if (is_callable('mb_encode_mimeheader')) {
		$subject = mb_encode_mimeheader($subject,"UTF-8", "B");
	}

	// Format message
	$message = html_entity_decode($message, ENT_COMPAT, 'UTF-8'); // Decode any html entities
	$message = strip_tags($message); // Strip tags from message
	$message = preg_replace("/(\r\n|\r)/", "\n", $message); // Convert to unix line endings in body
	$message = preg_replace("/^From/", ">From", $message); // Change lines starting with From to >From
	
	$email = "$name <$email>";

	mail($email, $subject, wordwrap($message), $headers);
}
?>