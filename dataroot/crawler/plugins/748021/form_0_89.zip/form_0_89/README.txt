There are README.txt files in most of the individual directories and
a CHANGES.txt file in the form directory.

You need to have the form plugin installed to use any of the other plugins.

The nagger_widget requires the flexprofile plugin.

The workshops plugin requires the flexgroupprofile plugin.