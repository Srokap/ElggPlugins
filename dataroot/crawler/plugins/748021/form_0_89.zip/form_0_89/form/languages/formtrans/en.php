<?php

	$english = array(

'form:formtrans:kevcontent:title' => "A non-profile form",
'form:formtrans:kevcontent:description' => "This tests a non-profile form, eg. classified ads.",
'form:formtrans:kevcontent:response_text' => "Thanks for providing this useful content!",
'form:fieldtrans:kevput2:title' => "Favourite season",
'form:fieldtrans:kevput2:description' => "What do you think?",
'form:fieldtrans:bio:title' => "About me",
'form:fieldtrans:bio:description' => "Tell everyone a bit about yourself",
'form:fieldtrans:pic:title' => "A picture",
'form:fieldtrans:pic:description' => "Upload a picture",
'form:fieldtrans:kevcal:title' => "Calendar",
'form:fieldtrans:kevcal:description' => "Select a date",
'form:sdtrans:kevcontent:classified_search_general:title' => "Search classified ads",
'form:sdtrans:kevcontent:classified_search_general:description' => "Enter your search criteria below.",
'form:sdtrans:kevcontent:testsearch1:title' => "Test search",
'form:sdtrans:kevcontent:testsearch1:description' => "This is just a way to make sure that the search works.",
'form:sdtrans:kevcontent:search1:title' => "Sample profile search",
'form:sdtrans:kevcontent:search1:description' => "Enter values in the fields below to find people on this site. If you don't enter a value for a given field, then the results will include people who set any value for that field.",
'form:tabtrans:Basic' => "Basic",
	);
					
	add_translation("en",$english);
?>