<?php
$entity = $vars['entity'];
$params = $vars['params'];
$form = get_entity($entity->form_id);
echo form_view_entities(array($entity), $form, 'search', $params['query']);
?>