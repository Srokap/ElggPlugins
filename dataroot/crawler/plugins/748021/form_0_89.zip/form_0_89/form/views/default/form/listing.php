<?php

$form_id = $vars['form_id'];
if (empty($vars['limit'])){
	$limit = 5;
} else {
	$limit = $vars['limit'];
}
$form = get_entity($form_id);
if ($form) {
	$title = $form->title;
	
	echo elgg_view_title($title);
	    
	$count = get_entities_from_metadata('form_id', $form_id, 'object', 'form_data', 0, $limit, 0, "", 0, true);
	$entities = get_entities_from_metadata('form_id', $form_id, 'object', 'form_data', 0, $limit, 0, "", 0, false);
	
	if ($entities) {
		echo '<div class="form_listing">';
	    echo form_view_entity_list($entities, $form, $count, 0, $limit, false, false);
	    echo '</div>';
	} else {
	    echo elgg_echo('form:no_search_results');
	}
	
	echo '<div class="form_listing_more"><a href="'.$vars['url'].'mod/form/my_forms.php?id='.$form_id.'&form_view=all">';
	echo elgg_echo('form:listing:view_all_link_text');
	echo '</a></div>';
}
?>