<?php
// the default view uses the standard search view

echo elgg_view('search/entity',$vars);
?>