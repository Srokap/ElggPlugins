<?php
$options = array(); 	 
$options['location'] = trim($vars['value']);
$options['zoom'] = 8;
$options['markers'] = array(array('address'=>$options['location'],
                                  'html'=>$options['location'],
                                  'type'=>'user'));

echo "<p>".$vars['value']."</p>";
echo elgg_view('google-map/view', $options);
echo "<br />";
?>