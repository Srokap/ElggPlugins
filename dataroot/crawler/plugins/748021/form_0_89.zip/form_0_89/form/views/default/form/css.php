.river_object_form_data_create {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_blog.gif) no-repeat left -1px;
}
.river_object_form_data_comment {
	background: url(<?php echo $vars['url']; ?>_graphics/river_icons/river_icon_comment.gif) no-repeat left -1px;
}

.form_listing .search_listing {
	border:2px solid #cccccc;
	margin:0 0 5px 0;
}

#groups_info_column_left .tabberlive .tabbertab {
	background-color: white;
}

#profile_info_column_middle .tabberlive .tabbertab {
	background-color: white;
}

.form_listing_more {
	margin:0;
	padding:5px;
	display:block;
	background:white;
   	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;	
}