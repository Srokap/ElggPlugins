<?php
define('FORM_CONTENT',0);
define('FORM_USER_PROFILE',1);
define('FORM_GROUP_PROFILE',2);
define('FORM_FILE',3);
define('FORM_REGISTRATION',4);
?>