<?php

// Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

admin_gatekeeper();

$sid = get_input('sid',0);
$sd = get_entity($sid);
$fd = form_get_data_from_form_submit($sd->form_id);
$form = get_entity($sd->form_id);

if ($sd && $form) {
	header('Expires: 0');
	header('Cache-control: private');
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Content-Description: File Transfer');
	header("Content-type: text/csv");
	header('Content-disposition: attachment; filename="file_name.csv"');
	
	$fields = form_get_fields($sd->form_id);
	$field_list = array();
	if ($fields) {
		foreach($fields as $field) {
			$field_list[] = $field->internal_name;
		}
	}
	
	echo implode(",",$field_list)."\n";
	
	$result = form_get_data_with_search_conditions($fd,$sd,0);
	$entities = $result[1];
	if ($entities) {
		foreach ($entities as $e) {
			$data = array();
			foreach($field_list as $fn) {
				$data[] = $e->$fn;
			}			
			echo form_to_csv_line( $data );
		}
	}
}

function form_to_csv_line( $array ) {
	 $temp = array();
	 foreach( $array as $elt ) {
	 	$temp[] = '"'.str_replace('"','""', $elt).'"';
	 }
	
	 $string = implode( ",", $temp ) . "\n";
	
	 return $string;
}
?>