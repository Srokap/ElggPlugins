<?php
/*******************************************************************************
 * accesswithfeweroptions
 *
 * @author admin
 ******************************************************************************/

	function accesswithfeweroptions_init()
	{
		global $CONFIG;

		return true;
	}






	
	register_elgg_event_handler('init', 'system', 'accesswithfeweroptions_init');
?>