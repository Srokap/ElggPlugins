<?php

	/**
	 * Elgg access level input
	 * Displays a pulldown input field
	 * 
	 * @package Elgg
	 * @subpackage Core

	 * @author Curverider Ltd

	 * @link http://elgg.org/
	 * 
	 * @uses $vars['value'] The current value, if any
	 * @uses $vars['js'] Any Javascript to enter into the input tag
	 * @uses $vars['internalname'] The name of the input field
	 * 


        This modified access view sets a limited drop-down based on main categories

        TAKEN FROM elgglib.php	 
		
 		define('ACCESS_DEFAULT',-1);
		define('ACCESS_PRIVATE',0);
		define('ACCESS_LOGGED_IN',1);
		define('ACCESS_PUBLIC',2);
		define('ACCESS_FRIENDS',-2);
	 
	 
	 */


    // Switches for which settings are allowed
	$allowACCESS_PRIVATE = false;
	$allowACCESS_LOGGED_IN = false;
	$allowACCESS_PUBLIC = true;
    $allowACCESS_FRIENDS = false;

    // Check whether or not the control should be disabled
	// from passed in parameter
    $isDisabled = false;
	if ((isset($vars['disabled'])) && ($vars['disabled']))
	{ $isDisabled = true; }
	
	// if there is one setting control will also be disabled
	// find number of options
	// and find most general option allowed
	$NoOfOptions = 0;
	$OptionIsAllowed = ACCESS_DEFAULT;
	if ($allowACCESS_PRIVATE) { $NoOfOptions = $NoOfOptions + 1; $OptionIsAllowed = ACCESS_PRIVATE;}
	if ($allowACCESS_FRIENDS) { $NoOfOptions = $NoOfOptions + 1; $OptionIsAllowed = ACCESS_FRIENDS;}
	if ($allowACCESS_LOGGED_IN) { $NoOfOptions = $NoOfOptions + 1; $OptionIsAllowed = ACCESS_LOGGED_IN;}
	if ($allowACCESS_PUBLIC) { $NoOfOptions = $NoOfOptions + 1; $OptionIsAllowed = ACCESS_PUBLIC;}
					
    // check if all options disabled!
	// if they are then PUBLIC is set as the default				
    if ($NoOfOptions == 0) 
    {
      $allowACCESS_PUBLIC = true;
	  $OptionIsAllowed = ACCESS_PUBLIC;
	  $NoOfOptions = 1;
	}
	 
	// disable if one option only 
	if ($NoOfOptions == 1) {$isDisabled = true;}
	//$isDisabled = false; // disabling seems to screw it up
	// see 
	// http://kreotekdev.wordpress.com/2007/11/08/disabled-vs-readonly-form-fields/

    // now onto the defaults
	// first try to find a default value
	if (!array_key_exists('value', $vars) || $vars['value'] == ACCESS_DEFAULT)
		$vars['value'] = get_default_access();

    // second is that default allowed
	$DefaultValue = $vars['value'];
	$isDefaultAllowed = false;
	
	if (($allowACCESS_PRIVATE) && ($DefaultValue == ACCESS_PRIVATE)) { $isDefaultAllowed = true; }
    if (($allowACCESS_FRIENDS) && ($DefaultValue == ACCESS_FRIENDS)) { $isDefaultAllowed = true; }
    if (($allowACCESS_LOGGED_IN) && ($DefaultValue == ACCESS_LOGGED_IN)) { $isDefaultAllowed = true; }
    if (($allowACCESS_PUBLIC) && ($DefaultValue == ACCESS_PUBLIC)) { $isDefaultAllowed = true; }	
	
	// if the default value is not allowed then
	// default to the most general allowed option
	if (!$isDefaultAllowed)
	{
	   $DefaultValue = $OptionIsAllowed;
	   $vars['value'] = $DefaultValue;
	}
	

	if (isset($vars['class'])) $class = $vars['class'];
	if (!$class) $class = "input-access";
	
		
if ($isDisabled)
{

// Note if disabled pass a default value
// see : http://kreotekdev.wordpress.com/2007/11/08/disabled-vs-readonly-form-fields/
?>

<input type="hidden" name="<?php echo $vars['internalname']; ?>" value="<?php echo $DefaultValue; ?>" />
<select <?php if (isset($vars['internalid'])) echo "id=\"{$vars['internalid']}\""; ?> name="<?php echo $vars['internalname']; ?>Display" <?php if (isset($vars['js'])) echo $vars['js']; ?> disabled="yes" class="<?php echo $class; ?>">

<?php 
}
else
{
?>
<select <?php if (isset($vars['internalid'])) echo "id=\"{$vars['internalid']}\""; ?> name="<?php echo $vars['internalname']; ?>" <?php if (isset($vars['js'])) echo $vars['js']; ?> class="<?php echo $class; ?>">

<?php 
}
?>

<?php


	if ($allowACCESS_PRIVATE)
	{
	   echo "<option value=\"" . ACCESS_PRIVATE . "\"";
	   if ($DefaultValue == ACCESS_PRIVATE);
	     { echo  " selected=\"selected\""; }
	   echo ">". htmlentities(elgg_echo("PRIVATE"),ENT_QUOTES, 'UTF-8') ."</option>";
	}

	if ($allowACCESS_FRIENDS)
	{
	   echo "<option value=\"" . ACCESS_FRIENDS; 
	   if ($DefaultValue == ACCESS_FRIENDS) 
	     { echo  " selected=\"selected\""; }
	   echo ">". htmlentities(elgg_echo("access:friends:label"),ENT_QUOTES, 'UTF-8') ."</option>";
	}


	if ($allowACCESS_LOGGED_IN)
	{
	   echo "<option value=\"" . ACCESS_LOGGED_IN . "\"";
	   if ($DefaultValue == ACCESS_LOGGED_IN) 
	     { echo  " selected=\"selected\""; }
	   echo ">". htmlentities(elgg_echo("LOGGED_IN"),ENT_QUOTES, 'UTF-8') ."</option>";
	}

	if ($allowACCESS_PUBLIC)
	{
	   echo "<option value=\"" . ACCESS_PUBLIC . "\""; 
	   if ($DefaultValue == ACCESS_PUBLIC) 
	     { echo  " selected=\"selected\""; }
	   echo ">". htmlentities(elgg_echo("PUBLIC"),ENT_QUOTES, 'UTF-8') ."</option>";
	}


          

    

?> 
</select>

