This is a very minimal mod but you may find it useful

If you want to limit the access options for the site then go to the sub-folder

views/default/input

and edit "access.php"

   // Switches for which settings are allowed
  $allowACCESS_PRIVATE = false;
  $allowACCESS_LOGGED_IN =false;
  $allowACCESS_PUBLIC = true;
  $allowACCESS_FRIENDS = false;

set the ones that you want as true
the default is public only

note. 

1) group access settings are ignored with this input control
this means nobody can set them
2) if there is only one option the access dropdown control is shown but disabled






