<?php

	$german = array(
	
	
			'canvasmenu:members' => "Mitglieder",
			'canvasmenu:photos' => "Fotos",
			'canvasmenu:groups' => "Gruppen",
			'canvasmenu:videos' => "Videos",
			'canvasmenu:current' => "currently has:",
			'canvasmenu:andmore' => "and more...",
			'canvasmenu:home' => "Home",
			'canvasmenu:blogs' => "Blogs",
			'canvasmenu:bookmarks' => "Lesezeichen",
			'canvasmenu:discussions' => "Beitr�ge",
			'canvasmenu:events' => "Events",
			'canvasmenu:wire' => "The Wire",
			'canvasmenu:public' => "publicly available.",
			'canvasmenu:register' => "Register now,",
			'canvasmenu:access' => "to access more.",

			
	);
	
	add_translation("de",$german);

?>
