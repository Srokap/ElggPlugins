<div class='menu_content'>
<?php 
if (isloggedin()){

	echo "<ul id='nav' class='dropdown dropdown-horizontal logged-in'>

	<li><a title='Home' href='" . $vars['url'] . "'>Home</a>

		<ul>
		<a href='" . $vars['url'] . "pg/expages/read/About/' title='About us'>About us</a>
		<a href='" . $vars['url'] . "pg/expages/read/Terms/' title='Terms'>Terms</a>
		<a href='" . $vars['url'] . "pg/expages/read/Privacy/' title='Privacy'>Privacy</a>
		<hr>
		<a href='" . $vars['url'] . "mod/invitefriends/' title='Invite friends'>Invite friends</a>
		</ul></li>
			
	<li><a title='Settings' href='" . $vars['url'] . "pg/settings/'>Settings</a>

		<ul>
		<a href='" . $vars['url'] . "pg/settings/' title='My Settings'>My Settings</a>
		<a href='" . $vars['url'] . "pg/settings/plugins/" . $_SESSION['user']->username . "/' title='My Tools'>My Tools</a>
		<a href='" . $vars['url'] . "pg/profile/" . $_SESSION['user']->username . "' title='My Profil'>Show my Profil</a>
		<a href='" . $vars['url'] . "mod/profile/edit.php?username=" . $_SESSION['user']->username . "' title='Profil settings'>Profil settings</a>
		<a href='" . $vars['url'] . "mod/profile/editicon.php?username=" . $_SESSION['user']->username . "' title='Change Profilpicture'>Change Profilpicture</a>
		
		<hr>
		<a href='" . $vars['url'] . "mod/notifications/' title='Notification'>Notification</a>
		<a href='" . $vars['url'] . "mod/notifications/groups.php' title='Group Notification'>Group Notification</a>
		</ul></li>

	<li><a title='Blog' href='" . $vars['url'] . "mod/blog/everyone.php'>Blog</a>

		<ul>
		<a href='" . $vars['url'] . "mod/blog/everyone.php' title='All Blogs'>All Blogs</a>
		<a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "' title='My Blogs'>My Blogs</a>
		<a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "/friends/' title='Blogs from Friends'>Blogs from Friends</a>
		<hr>
		<a href='" . $vars['url'] . "mod/blog/add.php' title='Write a Blog'>Write a Blog</a>
		</ul></li>

	<li><a title='Bookmarks' href='" . $vars['url'] . "mod/bookmarks/everyone.php'>Bookmarks</a>

		<ul>
		<a href='" . $vars['url'] . "mod/bookmarks/everyone.php' title='All Bookmarks'>All Bookmarks</a>
		<a href='" . $vars['url'] . "pg/bookmarks/" . $_SESSION['user']->username . "/items' title='My Bookmarks'>My Bookmarks</a>
		<a href='" . $vars['url'] . "pg/bookmarks/" . $_SESSION['user']->username . "/friends' title='Bookmarks from Friends'>Bookmarks from Friends</a>
		<hr>
		<a href='" . $vars['url'] . "mod/bookmarks/bookmarklet.php' title='New Bookmark'>New Bookmark</a>
		</ul></li>

	
	<li><a title='Events' href='" . $vars['url'] . "pg/event_calendar/'>Events</a>

		<ul>
		<a href='" . $vars['url'] . "pg/event_calendar/' title='Month Events'>Month Events</a>
		<hr>						
		<a href='" . $vars['url'] . "pg/event_calendar/new/' title='New Event'>New Event</a>
		</ul>

	<li><a title='Groups' href='" . $vars['url'] . "pg/groups/world/?filter=active'>Groups</a>

		<ul>
		<a href='" . $vars['url'] . "pg/groups/world/?filter=active' title='Last Posts'>Last Posts</a>
			<hr>
		<a href='" . $vars['url'] . "pg/groups/world/?filter=newest' title='All Groups'>All Groups</a>
		<a href='" . $vars['url'] . "pg/groups/member/" . $_SESSION['user']->username . "' title='My Groups'>My Groups</a>
		<a href='" . $vars['url'] . "pg/groups/world/?filter=pop' title='Top Groups'>Top Groups</a>
		<hr>
		<a href='" . $vars['url'] . "pg/groups/new/' title='Erstelle eine Gruppe'>Create a Group</a>
		</ul></li>

	<li><a title='Members' href='" . $vars['url'] . "mod/members/index.php?filter=newest'>Members</a>

		<ul>
		<a href='" . $vars['url'] . "mod/members/index.php?filter=newest' title='New Members'>New Members</a>
		<a href='" . $vars['url'] . "mod/members/index.php?filter=pop' title='Popular'>Popular Members</a>
		<a href='" . $vars['url'] . "mod/members/index.php?filter=active' title='Online'>Online</a>
		<hr>
		<a href='" . $vars['url'] . "pg/friends/" . $_SESSION['user']->username . "' title='My Friends'>My Friends</a>
		</ul></li>

	<li><a title='Photos' href='" . $vars['url'] . "pg/photos/mostrecent/'>Photos</a>

		<ul>
		<a href='" . $vars['url'] . "pg/photos/mostrecent/' title='All Photos'>New Photos</a>
		<a href='" . $vars['url'] . "pg/photos/owned/" . $_SESSION['user']->username . "' title='Meine Fotos'>My Photos</a>
		<a href='" . $vars['url'] . "pg/photos/friends/" . $_SESSION['user']->username . "' title='Photos from Friends'>Photos from Friends</a>
		<hr>
		<a href='" . $vars['url'] . "pg/photos/new/" . $_SESSION['user']->username . "' title='Create a Album'>Create a Album</a>
		</ul></li>

	<li><a title='The Wire' href='" . $vars['url'] . "mod/thewire/everyone.php'>The Wire</a>

		<ul>
		<a href='" . $vars['url'] . "mod/thewire/everyone.php' title='All Wireposts'>All Wireposts</a>
		<a href='" . $vars['url'] . "pg/thewire/" . $_SESSION['user']->username . "' title='My Wireposts'>My Wireposts</a>
		</ul></li>

	<li><a title='Nail Art Videos' href='" . $vars['url'] . "pg/videolist/search'>Videos</a>

		<ul>
		<a href='" . $vars['url'] . "pg/videolist/search' title='Alle Videos'>All Videos</a>
		<a href='" . $vars['url'] . "pg/videolist/owned/" . $_SESSION['user']->username . "/' title='My Videos'>My Videos</a>
		<hr>
		<a href='" . $vars['url'] . "pg/videolist/browse/" . $_SESSION['user']->username . "/add' title='Add a Video'>Add a Video</a>
		</ul></li>
	
	<div class='clearfloat'></div>
	</ul>
"; 

} else {

   echo "<ul id='nav' class='dropdown dropdown-horizontal not-logged-in'>

		<li><a href='" . $vars['url'] . "'>Home</a></li>
		<li><a title='Blog' href='" . $vars['url'] . "mod/blog/everyone.php'>Blog</a></li>
		<li><a title='Bookmarks'href='" . $vars['url'] . "mod/bookmarks/everyone.php'>Bookmarks</a></li>
		<li><a title='Events' href='" . $vars['url'] . "pg/event_calendar/'>Events</a></li>
		<li><a title='Groups' href='" . $vars['url'] . "pg/groups/world/?filter=active'>Groups</a></li>
		<li><a title='Members' href='" . $vars['url'] . "mod/members/index.php?filter=newest'>Members</a></li>
		<li><a title='The Wire' href='" . $vars['url'] . "mod/thewire/everyone.php'>The Wire</a></li>
		<li><a title='Photos' href='" . $vars['url'] . "pg/photos/mostrecent/'>Photos</a></li>
		<li><a title='Videos' href='" . $vars['url'] . "pg/videolist/search'>Videos</a></li>
		<div class='clearfloat'></div>
	</ul>
";
} 
?>
<div class='clearfloat'></div><br />
<div class="canvas_menu">

<!-- insert adsense here -->

<!-- end adsense here -->
<div class='clearfloat'></div>
</div><div class='clearfloat'></div>
	
</div>