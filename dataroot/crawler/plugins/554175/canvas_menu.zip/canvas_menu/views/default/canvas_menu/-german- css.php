<?php

	/**
	 * Profile Dropdown Menu
	 * 
	 * @ProfileDropdownMenu
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author skotmiller <skotmiller@gmail.com>
	 * @link http://bescenepromotions.com/
	 */

/**
 * Horizontal CSS Drop-Down Menu Module
 *
 * @file		dropdown.css
 * @package		Dropdown
 * @version		0.7.1
 * @type		Transitional
 * @stacks		597-599
 * @browsers	Windows: IE6+, Opera7+, Firefox1+
 *				Mac OS: Safari2+, Firefox2+
 *
 * @link		http://www.lwis.net/
 * @copyright	2006-2008 Live Web Institute. All Rights Reserved.
 *
 * Default Ultimate Linear CSS Drop-Down Menu Theme
 *
 * @file		default.ultimate.css
 * @name		Default
 * @version		0.1
 * @type		transitional
 * @browsers	Windows: IE5+, Opera7+, Firefox1+
 *				Mac OS: Safari2+, Firefox2+
 *
 * @link		http://www.lwis.net/
 * @copyright	2008 Live Web Institute. All Rights Reserved.
 *
 */
 
?>

ul.dropdown,
ul.dropdown li,
ul.dropdown ul {
 list-style: none;
 margin: 0;
 padding: 0;
}

ul.dropdown {
 position: relative;
 z-index: 597;
}

ul.dropdown li {
 float: left;
 vertical-align: middle;
 display: block;
 background: white;
 zoom: 1;
}

ul.dropdown li.hover,
ul.dropdown li:hover {
 position: relative;
 z-index: 599;
 cursor: default;
}

ul.dropdown ul {
 visibility: hidden;
 position: absolute;
 top: 100%;
 left: 0;
 z-index: 598;
 width: 155px;
}

ul.dropdown ul li {
 float: none;
}

ul.dropdown ul ul {
 top: 1px;
 left: 99%;
}

ul.dropdown li:hover > ul {
 visibility: visible;
}

ul.dropdown li.rtl ul {
 top: 100%;
 right: 0;
 left: auto;
}

ul.dropdown li.rtl ul ul {
 top: 1px;
 right: 99%;
 left: auto;
}

/*-------------------------------------------------/
 * @section		Base Style Extension
 */

ul.dropdown a,
ul.dropdown span {
 display: block;
 padding: 2px 0px 2px 0px;
	font-size: 10px;
	text-decoration: none;
}



/*-------------------------------------------------/
 * @section		Base Style Override
 */

ul.dropdown li {
 padding: 0;
 border: none;
}

ul.dropdown ul a,
ul.dropdown ul span {
	padding: 4px;
	margin: 4px;
}



/*-------------------------------------------------/
 * @section		Base Style Reinitiate: post-override activities
 */





/*-------------------------------------------------/
 *	@section	Custom Styles
 */

ul.dropdown li  {
  font: bold 10px verdana;
  background-image: url(<?php echo $vars['url']; ?>mod/canvas_menu/images/nav.png);
 
  
}
ul.dropdown li a{
  display: block;
    padding: 8px 15px;
    background-image: url(<?php echo $vars['url']; ?>mod/canvas_menu/images/nav-hover.png);
    background-repeat: no-repeat;
    background-position: 0 -50px;
    height: 100%;
    width: 70%;
}

ul.dropdown li.hover,
ul.dropdown li:hover {
    background-image: url(<?php echo $vars['url']; ?>mod/canvas_menu/images/nav-hover.png);
    background-position: top left;
    color: #fff;
  padding: 0px 0px;}

	

ul.dropdown li a:active {
}


/* Non-first level */
ul.dropdown li ul li{
	background-color: #00acf7;
}

ul.dropdown ul{
	color: white;
	background-color: #00acf7;
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	}

	ul.dropdown ul li {
	}

	ul.dropdown ul li.hover,
	ul.dropdown ul li:hover {
	background-color: #f7d2ff;
	margin-right: 5px;
	margin-left: 5px;
	-webkit-border-radius: 2px; 
	-moz-border-radius: 2px;
	font-weight: bold;
}



/* Mixed */

ul.dropdown li a,
ul.dropdown *.dir {
	color: white;
}


/*-------------------------------------------------/
 * @section		Support Class `open` Usage
 * @source		js, artificial
 *
 */

ul.dropdown li.hover *.open { 
 color: white;
}

ul.dropdown ul li.hover *.open,
ul.dropdown-vertical li.hover *.open {
 padding-left: 15px;
}

ul.dropdown-vertical-rtl li.hover *.open {
 padding-right: 15px;
}

ul.dropdown-upward li.hover *.open {
}

ul.dropdown-upward ul li.hover *.open {
}


	/* CSS2 clone */

	ul.dropdown li:hover > *.dir { 
	 color: white;
}

ul.dropdown li .top_dir { 
	 color: #333;
}

	ul.dropdown ul li:hover > *.dir,
	ul.dropdown-vertical li:hover > *.dir {
	 padding-left: 15px;
}

	ul.dropdown-vertical-rtl li:hover > *.dir {
	 padding-right: 15px;
	}

	ul.dropdown-upward li:hover > *.dir {
	}

	ul.dropdown-upward ul li:hover > *.dir {
	}

.bottomtext {
	font-size: 10px;
}

.menu_content{
}
ul#nav{
	margin: 0 auto;
}
.not-logged-in{
	width: 673px;
}
.logged-in{
	width: 780px;
}

.canvas_menu{
	text-align: center;
	margin: 0 0 10px;
}