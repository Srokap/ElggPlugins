<div class='menu_content'>
<?php 
if (isloggedin()){

	echo "<ul id='nav' class='dropdown dropdown-horizontal logged-in'>

	<li><a title='Home' href='" . $vars['url'] . "'>Home</a>

		<ul>
		<a href='" . $vars['url'] . "pg/expages/read/About/' title='Impressum'>Impressum</a>
		<a href='" . $vars['url'] . "pg/expages/read/Terms/' title='AGB'>AGB</a>
		<a href='" . $vars['url'] . "pg/expages/read/Privacy/' title='Datenschutzerkl&auml;rung'>Datenschutzerkl&auml;rung</a>
		<hr>
		<a href='" . $vars['url'] . "mod/invitefriends/' title='Freunde einladen'>Freunde einladen</a>
		</ul></li>
			
	<li><a title='Tools' href='" . $vars['url'] . "pg/settings/'>Einstellungen</a>

		<ul>
		<a href='" . $vars['url'] . "pg/settings/' title='Meine Einstellungen'>Meine Einstellungen</a>
		<a href='" . $vars['url'] . "pg/settings/plugins/" . $_SESSION['user']->username . "/' title='Meine Tools'>Meine Tools</a>
		<a href='" . $vars['url'] . "pg/profile/" . $_SESSION['user']->username . "' title='Zeige Mein Profil'>Zeige Mein Profil</a>
		<a href='" . $vars['url'] . "mod/profile/edit.php?username=" . $_SESSION['user']->username . "' title='Profil &auml;ndern'>Profil &auml;ndern</a>
		<a href='" . $vars['url'] . "mod/profile/editicon.php?username=" . $_SESSION['user']->username . "' title='Profilbild &auml;ndern'>Profilbild &auml;ndern</a>
		
		<hr>
		<a href='" . $vars['url'] . "mod/notifications/' title='Benachrichtigungen'>Emails</a>
		<a href='" . $vars['url'] . "mod/notifications/groups.php' title='Gruppen Benachrichtigungen'>Gruppen Emails</a>
		</ul></li>

	<li><a title='Blog' href='" . $vars['url'] . "mod/blog/everyone.php'>Blog</a>

		<ul>
		<a href='" . $vars['url'] . "mod/blog/everyone.php' title='Alle Blogs'>Alle Blogs</a>
		<a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "' title='Meine Blogs'>Meine Blogs</a>
		<a href='" . $vars['url'] . "pg/blog/" . $_SESSION['user']->username . "/friends/' title='Blogs von Freunden'>Blogs von Freunden</a>
		<hr>
		<a href='" . $vars['url'] . "mod/blog/add.php' title='Schreibe einen Blog'>Schreibe einen Blog</a>
		</ul></li>

	<li><a title='Lesezeichen' href='" . $vars['url'] . "mod/bookmarks/everyone.php'>Lesezeichen</a>

		<ul>
		<a href='" . $vars['url'] . "mod/bookmarks/everyone.php' title='Alle Lesezeichen'>Alle Lesezeichen</a>
		<a href='" . $vars['url'] . "pg/bookmarks/" . $_SESSION['user']->username . "/items' title='Meine Lesezeichen'>Meine Lesezeichen</a>
		<a href='" . $vars['url'] . "pg/bookmarks/" . $_SESSION['user']->username . "/friends' title='Lesezeichen von Freunden'>Lesezeichen von Freunden</a>
		<hr>
		<a href='" . $vars['url'] . "mod/bookmarks/bookmarklet.php' title='Erstell ein Lesezeichen'>Erstell ein Lesezeichen</a>
		</ul></li>

	
	<li><a title='Events' href='" . $vars['url'] . "pg/event_calendar/'>Events</a>

		<ul>
		<a href='" . $vars['url'] . "pg/event_calendar/' title='Monats Events'>Monats Events</a>
		<hr>						
		<a href='" . $vars['url'] . "pg/event_calendar/new/' title='Erstelle ein Event'>Erstelle ein Event</a>
		</ul>

	<li><a title='Gruppen' href='" . $vars['url'] . "pg/groups/world/?filter=active'>Gruppen</a>

		<ul>
		<a href='" . $vars['url'] . "pg/groups/world/?filter=active' title='Letzte Beitr&auml;ge'>Letzte Beitr&auml;ge</a>
			<hr>
		<a href='" . $vars['url'] . "pg/groups/world/?filter=newest' title='Alle Gruppen'>Alle Gruppen</a>
		<a href='" . $vars['url'] . "pg/groups/member/" . $_SESSION['user']->username . "' title='Meine Gruppen'>Meine Gruppen</a>
		<a href='" . $vars['url'] . "pg/groups/world/?filter=pop' title='Top Gruppen'>Top Gruppen</a>
		<hr>
		<a href='" . $vars['url'] . "pg/groups/new/' title='Erstelle eine Gruppe'>Erstelle eine Gruppe</a>
		</ul></li>

	<li><a title='Mitglieder' href='" . $vars['url'] . "mod/members/index.php?filter=newest'>Mitglieder</a>

		<ul>
		<a href='" . $vars['url'] . "mod/members/index.php?filter=newest' title='Neue Mitglieder'>Neue Mitglieder</a>
		<a href='" . $vars['url'] . "mod/members/index.php?filter=pop' title='Popular'>Top Mitglieder</a>
		<a href='" . $vars['url'] . "mod/members/index.php?filter=active' title='Online'>Online</a>
		<hr>
		<a href='" . $vars['url'] . "pg/friends/" . $_SESSION['user']->username . "' title='Meine Freunde'>Meine Freunde</a>
		</ul></li>

	<li><a title='Bilder' href='" . $vars['url'] . "pg/photos/mostrecent/'>Bilder</a>

		<ul>
		<a href='" . $vars['url'] . "pg/photos/mostrecent/' title='All Photos'>Neue Bilder</a>
		<a href='" . $vars['url'] . "pg/photos/owned/" . $_SESSION['user']->username . "' title='Meine Fotos'>Meine Fotos</a>
		<a href='" . $vars['url'] . "pg/photos/friends/" . $_SESSION['user']->username . "' title='Fotos von Freunden'>Fotos von Freunden</a>
		<hr>
		<a href='" . $vars['url'] . "pg/photos/new/" . $_SESSION['user']->username . "' title='Erstelle ein Album'>Erstelle ein Album</a>
		</ul></li>

	<li><a title='Tweets' href='" . $vars['url'] . "mod/thewire/everyone.php'>Tweets</a>

		<ul>
		<a href='" . $vars['url'] . "mod/thewire/everyone.php' title='Alle Nailtweets'>Alle Tweets</a>
		<a href='" . $vars['url'] . "pg/thewire/" . $_SESSION['user']->username . "' title='Meine Nailtweets'>Meine Tweets</a>
		</ul></li>

	<li><a title='Videos' href='" . $vars['url'] . "pg/videolist/search'>Videos</a>

		<ul>
		<a href='" . $vars['url'] . "pg/videolist/search' title='Alle Videos'>Alle Videos</a>
		<a href='" . $vars['url'] . "pg/videolist/owned/" . $_SESSION['user']->username . "/' title='Meine Videos'>Meine Videos</a>
		<hr>
		<a href='" . $vars['url'] . "pg/videolist/browse/" . $_SESSION['user']->username . "/add' title='Stell ein Video ein'>Stell ein Video ein</a>
		</ul></li>
	
	<div class='clearfloat'></div>
	</ul>
"; 

} else {

   echo "<ul id='nav' class='dropdown dropdown-horizontal not-logged-in'>

		<li><a href='" . $vars['url'] . "'>Home</a></li>
		<li><a title='Blog' href='" . $vars['url'] . "mod/blog/everyone.php'>Blog</a></li>
		<li><a title='Lesezeichen'href='" . $vars['url'] . "mod/bookmarks/everyone.php'>Lesezeichen</a></li>
		<li><a title='Events' href='" . $vars['url'] . "pg/event_calendar/'>Events</a></li>
		<li><a title='Gruppen' href='" . $vars['url'] . "pg/groups/world/?filter=active'>Gruppen</a></li>
		<li><a title='NMitglieder' href='" . $vars['url'] . "mod/members/index.php?filter=newest'>Mitglieder</a></li>
		<li><a title='Tweets' href='" . $vars['url'] . "mod/thewire/everyone.php'>Tweets</a></li>
		<li><a title='Galerie' href='" . $vars['url'] . "pg/photos/mostrecent/'>Bilder</a></li>
		<li><a title='Videos' href='" . $vars['url'] . "pg/videolist/search'>Videos</a></li>
		<div class='clearfloat'></div>
	</ul>
";
} 
?>
<div class='clearfloat'></div><br />
<div class="canvas_menu">

<!-- insert adsense here -->

<!-- end adsense here -->
<div class='clearfloat'></div>
</div><div class='clearfloat'></div>
	
</div>