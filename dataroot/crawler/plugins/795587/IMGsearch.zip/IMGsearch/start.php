<?php

function IMGsearch_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('IMG search'), $CONFIG->wwwroot . "mod/IMGsearch");
		}
		
	register_elgg_event_handler('init','system','IMGsearch_init');

?>