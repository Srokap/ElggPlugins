<?php
if (isloggedin()) forward('activity');
?>
<html>
<head><title>Welcome</title>
<link rel="shortcut icon" href="mod/blue+/icon.ico" type="image/x-icon"/>
<style type="text/css">
  body {
    padding-left: 11em;
    font-family: Georgia, "Times New Roman",
          Times, serif;
    color: purple;
    background-color: 	#0000A0 }
  ul.navbar {
    position: absolute;
    top: 2em;
    left: 1em;
    width: 9em }
  h1 {
    font-family: Helvetica, Geneva, Arial,
          SunSans-Regular, sans-serif }
  </style>
</head>
<body><font face="Times New Roman" color="black">
<center>
<h1><marquee behavior="alternate">This is my header</h1></marquee>
<table border="1" bordercolor="#33CCFF" style="background-color:#ADDFFF" width="800" cellpadding="3" cellspacing="3">
	<tr>
		<td>Here is a good place for a about us, terms, or register page.</td>
		<td><?php
/**
 * Elgg login box
 *
 * @package Elgg
 * @subpackage Core
 *
 * @uses $vars['module'] The module name. Default: aside
 */

$module = elgg_extract('module', $vars, 'aside');

$login_url = elgg_get_site_url();
if (elgg_get_config('https_login')) {
	$login_url = str_replace("http:", "https:", $login_url);
}

$title = elgg_echo('login');
$body = elgg_view_form('login', array('action' => "{$login_url}action/login"));

echo elgg_view_module($module, $title, $body);
?>
</td>
		<td><h3>How to edit</h3><br>Step one = Go to your file manager. <br> Step two = go to mod. <br> Step three = go to blue+. <br>Step four = open home.php. <br> Step five = edit home.php!</td>
	</tr>
</table>
<?php
//Do not code below the /center
?>
</center>
</font>
</body>
</html>
