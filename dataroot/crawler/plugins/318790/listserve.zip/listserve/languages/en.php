<?php
$english = array(
		'groupmailshot:settings:credentials' => 'Credentials',
		'notification:method:mailshot' => 'Listserve'
);
				
add_translation("en",$english);
?>