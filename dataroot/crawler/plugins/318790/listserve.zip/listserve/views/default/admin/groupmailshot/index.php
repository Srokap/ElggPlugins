<?php
elgg_echo('groupmailshot:settings:credentials') .'<br/>';

echo elgg_view('input/text',array(
																	'internalname'=> 'params['groupmailshot_username']',
																	'value' => $groupmailshot_username,
																	'class' => '',
																	'js' => "id='params[groupmailshot_username]' $auth_disabled"));

echo elgg_view('input/text',array(
																	'internalname'=> 'params['groupmailshot_password']',
																	'value' => $groupmailshot_password,
																	'class' => '',
																	'js' => "id='params[groupmailshot_password]' $auth_disabled"));
																	
echo elgg_view('input/text',array(
																	'internalname'=> 'params['groupmailshot_host']',
																	'value' => $groupmailshot_host,
																	'class' => '',
																	'js' => "id='params[groupmailshot_host]' $auth_disabled"));
?>