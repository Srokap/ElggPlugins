<?php
error_reporting(E_ALL);

require_once 'post.php';
require_once 'topic.php';
require_once 'mail.php';
require_once 'lib/Net/POP3.php';

// ListServe settings
// POP 3 Credentials
define('HOST','ADD YOUR MAIL SERVER HERE');
define('LOGIN','ADD YOUR MAILSERVER POP 3 LOGIN');
define('PASS','ADD YOUR PASSWORD HERE');


/**
* Cronjob for listserve
*
* Used by CRON to periodically retrieve our discussion posts.
*
* @param unknown_type $hook
* @param unknown_type $entity_type
* @param unknown_type $returnvalue
* @param unknown_type $params
*/
function groupmailshot_cron($hook,$entity_type,$returnvalue, $params) {
	$pop3 = new Net_POP3();

	/*
	 * Connect to localhost on usual port
	 * If not given, defaults are localhost:110
	 */
	$pop3->connect(HOST, 110);

	/*
	 * Login using username/password. APOP will
	 * be tried first if supported, then basic.
	 */
	$pop3->login(LOGIN, PASS);
	if(0 == $pop3->numMsg()) {
		$resulttext = elgg_echo("Unable to get emails");
		return $returnvalue .$resulttext;
	}
	loop_through_emails($pop3);
	$pop3->disconnect();
}

/**
 * Send a notification via email using phpmailer
 *
 * @param ElggEntity $from The from user/site/object
 * @param ElggUser $to To which user?
 * @param string $subject The subject of the message.
 * @param string $message The message body
 * @param array $params Optional parameters (not used)
 * @return bool
 */
function groupmailshot_notify_handler(ElggEntity $from, ElggUser $to, $subject, $message, array $params = NULL)
{
  global $CONFIG,$SUBJECT_TITLE;
  if (!$from)
    throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'from'));

  if (!$to)
    throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'to'));

  if ($to->email=="")
    throw new NotificationException(sprintf(elgg_echo('NotificationException:NoEmailAddress'), $to->guid));

  $topic_guid = get_topic_by_topic_name($message_info['topic'],$group_obj[0]->guid);

	if(NULL == $SUBJECT_TITLE) {
		preg_match("/topic=(\d+)/i",$message,$matches);
		$object = get_topic_by_topic_guid($matches[1],$from->guid);
		$SUBJECT_TITLE = $object->title;
	}
  $from_email = add_underscores($from->name);

  $site = get_entity($CONFIG->site_guid);
  $from_name = $from->name;

	$from_email = add_underscores($from->name);
	$header_eol = "\r\n";
	if (
		(isset($CONFIG->broken_mta)) &&
		($CONFIG->broken_mta)
	)
		$header_eol = "\n"; // Allow non-RFC 2822 mail headers to support some broken MTAs

	$headers = "From: $from_email{$header_eol}"
		. "Content-Type: text/plain; charset=UTF-8; format=flowed{$header_eol}"
  		. "MIME-Version: 1.0{$header_eol}"
  		. "Content-Transfer-Encoding: 8bit{$header_eol}";

  	if (is_callable('mb_encode_mimeheader')) {
		$subject = mb_encode_mimeheader("Re: [{$SUBJECT_TITLE}]","UTF-8", "B");
  	}

	// Format message
  	$message = strip_tags($message); // Strip tags from message
  	$message = preg_replace("/(\r\n|\r)/", "\n", $message); // Convert to unix line endings in body
  	$message = preg_replace("/^From/", ">From", $message); // Change lines starting with From to >From

	return mail($to->email, $subject, wordwrap($message), $headers);
}

/**
 * Returns a more meaningful message
 *
 * @param unknown_type $hook
 * @param unknown_type $entity_type
 * @param unknown_type $returnvalue
 * @param unknown_type $params
 */
function groupmailshot_notify_message($hook, $entity_type, $returnvalue, $params)
{
	global $SUBJECT_TOPIC, $TOPIC_MSG,$CONFIG;

	$entity = $params['entity'];
	$to_entity = $params['to_entity'];
	$method = $params['method'];
	$msg = '';
	if (($entity instanceof ElggEntity) && ($to_entity->guid != $entity->owner_guid) && ($entity->getSubtype() == 'groupforumtopic'))
	{
		$title = $entity->title;
		if(get_input('topic_post')) {
			$msg = get_input('topic_post');
		} else {
			// I hates globals but seems like the quickest way to store our topics latest message.
			$msg = $TOPIC_MSG;
		}
		$SUBJECT_TOPIC = "Re: [{$title}]";
		$name = get_user($entity->owner_guid)->get('username');
		$date = date('d-m-Y');
		$msg_body = "Topic:<b>$title</b>\n\nThe following comment was added by $name on $date\n\n$msg\n\n" . $entity->getURL();
		return $msg_body;
	}
	return null;
}

/**
* Sets our permissions so that users can post messages via email
*
* @param unknown_type $hook
* @param unknown_type $entity_type
* @param unknown_type $returnvalue
* @param unknown_type $params
*/
function groupmailshot_permissions_check($hook_name,$entity_type,$return_value,$params) {
	if('cron' == get_context()) {
		return true;
	}
	return null;
}

/**
* Sets up our plugin
*/
function groupmailshot_init() {
	register_plugin_hook('permissions_check','all','groupmailshot_permissions_check');
	register_plugin_hook('notify:entity:message', 'object', 'groupmailshot_notify_message');
	register_plugin_hook('cron','minute','groupmailshot_cron');
}

// Initialise our plugin
register_elgg_event_handler('init','system','groupmailshot_init');
// Notification hooks
register_notification_handler('mailshot', 'groupmailshot_notify_handler');
