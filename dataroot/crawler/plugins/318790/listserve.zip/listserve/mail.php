<?php
/**
* Gets all the information from an email address
*
* @return bool
*/
function get_info_from_email($message) {
	if(array_key_exists('To',$message)) {
		if(preg_match("/\<(.*)@(.*)\>$/",$message['To'],$matches)) {
			return $matches[1];
		} elseif(preg_match("/(.*)@(.*)/",$message['To'],$matches)) {
			return $matches[1];
		} else {
			return substr($message[$type],0,strpos($message['To'],'@'));
		}
	}
	return false;
}

/**
* We need to split our raw header so that we can actually the from address, 
* which will be used to verify the user belongs to the discussion
* 
* @return The actual email address the email originated form
*
*/ 
function get_email_from_raw_header($raw_header) {
	// split our header, as we only need our from line
	$split_from_array = split(" ",$raw_header);
	// Emails from line
	// get the last element in the array, this is usually the users actual email address
	$email = end($split_from_array);
	// remove < & > from the email address
	$email = substr($email, 4, -4);
	return $email;
}

/**
* Gets the email address for a POP3 Header
* @params String $header	POP3 Header
*
* @return bool
*/
function get_email_from_header($header) {
	if(array_key_exists('From',$header)) {
		if(preg_match("/^<(.*@.*)>$/",$header['From'],$matches)) {
			return $matches[1];
		} elseif(preg_match("/(.*)<(.*@.*)>$/",$header['From'],$matches)) {
			return $matches[2];
		} elseif(preg_match("/^(.*@.*)$/",$header['From'],$matches)) {
			print "Without less and greater than";
			return $matches[1];
		} 
	} else {
		return false;
	}
}

/**
* Removes underscore from a string
* Primarily used for group names which have underscores in their name
* @param String	$group_name	Name of the group
*
* @return String Group name without underscores
*/
function remove_underscores($group_name) {
	return str_replace("_"," ",$group_name);
}

/**
* Addews underscore from a string
* Primarily used for group names which need to have underscores
* @param String	$group_name	Name of the group
*
* @return String Group name without underscores
*/
function add_underscores($group_name) {
	return str_replace(" ","_",$group_name);
}
/**
* Gets the topics guid via its topic name
* @param 	String	$topic 				The topic
* @param 	Int			$group_guid 	group uid
*
* @return Int										Topic GUID
*/
function get_topic_by_topic_name($topic,$group_guid) {
	foreach(get_entities('object','groupforumtopic',$group_guid) as $entity) {
		if($topic === $entity->title) {
			return $entity['guid'];
		}
	}
	return false;
}


function get_topic_by_topic_guid($topic_guid,$group_guid) {
	foreach(get_entities('object','groupforumtopic',$group_guid) as $entity) {
		if($topic_guid === $entity->guid) {
			return $entity;
		}
	}
	return false;
}
/**
* Gets the group GUID by its group name
* @param	String		$name		The name of the group
*
* @return ELGObject					Returns ELGGroup
*/
function get_group_by_name($name)
{
	global $CONFIG;
	$query = "SELECT e.* from {$CONFIG->dbprefix}entities e join {$CONFIG->dbprefix}groups_entity u on e.guid=u.guid where name = '$name'";
	return get_data($query, 'entity_row_to_elggstar');
}

/**
* Groups the groups name and topic from the subject head
* @param	String		$subject	The subject title, which stores the topic and tags
* @return Array	Group & Topic in an associative array
*
*/
function get_topic_and_tags($subject) {
	if(preg_match("/\[(.*)\]$/",$subject,$matches)) {
	  $message = split("-",$matches[1]);
	  $result['topic'] = $message[0];
	  if(isset($message[1])) {
	    $result['tags'] = $message[1];
	  }
	  return $result;
	}	
	return false;
}

/**
* Loops through our email
* 
*/
function loop_through_emails($pop3) {
  $FOUND = false;
	for($i=1;$i<=$pop3->numMsg();$i++) {
		$email = '';
	  $pop_header = $pop3->getParsedHeaders($i);
    if(array_key_exists('Subject', $pop_header)) {
    	$subject = $pop_header['Subject'];
	    $message_info = get_topic_and_tags($subject);
	    $email_header = $pop3->getParsedHeaders($i);
	    if(false != $message_info) {
	       $group = remove_underscores(get_info_from_email($pop_header));
        if($group) {
          if(array_key_exists('Return-Path',$email_header)) {
          	$email = $email_header['Return-Path'];
          } else {
          	$email = get_email_from_header($pop_header);
          }
          $group_obj = get_group_by_name($group);
          if(is_array($group_obj) && false != $group_obj) {
          	$user_obj = get_user_by_email($email);
            $topic_guid = get_topic_by_topic_name($message_info['topic'],$group_obj[0]->guid);
            $msg = htmlspecialchars($pop3->getBody($i));
            handle_messages($user_obj,$group_obj,$topic_guid,$msg,$tags,$message_info);
            $FOUND = true;
          } else {
	          print "Not able to find group object: {$group}" .PHP_EOL;
          }
        } else {
        	print "Not able to find group: {$group}" .PHP_EOL;
        }
    	}
    }
	  $pop3->deleteMsg($i);
    if($FOUND) {
			break;
		}
	}
}
	
/**
* Handles out actual messages and determines whether the message
* should be posted or create a new topic
*/
function handle_messages($user_obj,$group_obj,$topic_guid,$message,$tags=array(),$message_info = array()) {
	if(is_array($user_obj)) {
		if($topic_guid) {		// need to verify better
			// append post
			if(add_post($user_obj[0],$group_obj[0],$topic_guid,$message)) {
				print "Added posts";
			} else {
				print "Unable to add topic - {$mesage}";
			}
		} else {
			// create post & send to forum

			// @todo create functionality to setup tags
			$tags = 'test one two three';
			
			if(add_topic($user_obj[0],$group_obj[0],$message_info['topic'],$message,$message_info['tags'])) {
				print "Added topic";
			} else {
				print "Unable to add topic - {$message_info['topic']}";
			}
		}
	} else {
		print "Unable to get user_obj";
	}
}
?>