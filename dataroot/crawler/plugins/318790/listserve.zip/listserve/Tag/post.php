<?php
function add_post($user,$group_entity,$topic_guid,$post) {
	global $TOPIC_MSG;
	$TOPIC_MSG = $post;
	// Check the user is a group member
	if(isset($group_entity)) {
		if (!$group_entity->isMember($user)) {
			return false;
		}
	}
	// Let's see if we can get an entity with the specified GUID, and that it's a group forum topic
	if ($topic = get_entity($topic_guid)) {
		if ($topic->getSubtype() == "groupforumtopic") {
    			
  		//check the user posted a message
    	if($post){
	    	// If posting the comment was successful, say so
				if ($topic->annotate('group_topic_post',$post,$topic->access_id, $user->guid)) {
					system_message(elgg_echo("groupspost:success"));
					// add to river
	      	add_to_river('river/forum/create','create',$_SESSION['user']->guid,$topic_guid);
				} else {
					    system_message(elgg_echo("groupspost:failure"));
				}
			}else{
    		system_message(elgg_echo("groupspost:nopost"));
			}	
		}			
	} else {	
		system_message(elgg_echo("groupstopic:notfound"));	
	}
	return true;
}