<?php
function get_group_from_email_old($message) {
	if(array_key_exists('To',$message)) {
		preg_match("/\<(.*)@(.*)\>$/",$message['To'],$matches);
		return strtolower($matches[1]);
	}
}

function get_group_from_email($message) {
	if(array_key_exists('To',$message)) {
		if(preg_match("/\<(.*@)\>$/",$message['To'],$matches)) {
			return $matches[1];
		} elseif(preg_match("/(.*)@(.*)/",$message['To'],$matches)) {
			return substr($matches[1],1);
		} else {
			$result = substr($message['To'],0,strpos($message['To'],'@'));
			return $result;
		}
	}
	return false;
}

function get_info_from_email($message) {
	if(array_key_exists('To',$message)) {
		if(preg_match("/\<(.*)@(.*)\>$/",$message['To'],$matches)) {
			return $matches[1];
		} elseif(preg_match("/(.*)@(.*)/",$message['To'],$matches)) {
			return $matches[1];
		} else {
			return substr($message[$type],0,strpos($message['To'],'@'));
		}
	}
	return false;
}

/**
* We need to split our raw header so that we can actually the from address, 
* which will be used to verify the user belongs to the discussion
* 
* @return The actual email address the email originated form
*
*/ 
function get_email_from_raw_header($raw_header) {
	// split our header, as we only need our from line
	$split_from_array = split(" ",$raw_header);
	// Emails from line
	// get the last element in the array, this is usually the users actual email address
	$email = end($split_from_array);
	// remove < & > from the email address
	$email = substr($email, 4, -4);
	return $email;
}

function get_email_from_header($header) {
	if(array_key_exists('From',$header)) {
		if(preg_match("/^<(.*@.*)>$/",$header['From'],$matches)) {
			return $matches[1];
		} elseif(preg_match("/(.*)<(.*@.*)>$/",$header['From'],$matches)) {
			return $matches[2];
		} elseif(preg_match("/^(.*@.*)$/",$header['From'],$matches)) {
			print "Without less and greater than";
			return $matches[1];
		} 
	} else {
		return faslse;
	}
}

function remove_underscores($group_name) {
	return str_replace("_"," ",$group_name);
}

function add_underscores($group_name) {
	return str_replace(" ","_",$group_name);
}
/**
* Gets the topics guid via its topic name
* @return int		Topic GUID
*
*/
function get_topic_by_topic_name($topic,$group_guid) {
	foreach(get_entities('object','groupforumtopic',$group_guid) as $entity) {
		if($topic === $entity->title) {
			return $entity['guid'];
		}
	}
	return false;
}

/**
* Gets the group GUID by its group name
* @return ELGObject	Returns ELGGroup
*
*/
function get_group_by_name($name)
{
	global $CONFIG;
	
	//$name = sanitise_string($name);
	$query = "SELECT e.* from {$CONFIG->dbprefix}entities e join {$CONFIG->dbprefix}groups_entity u on e.guid=u.guid where name = '$name'";
	return get_data($query, 'entity_row_to_elggstar');
}

/**
* Groups the groups name and topic from the subject head
* @return Array	Group & Topic in an associative array
*
*/
function get_group_name_and_topic($subject) {
	if(preg_match("/\[(.*) - (.*)\]$/",$subject,$matches)) {
		$result['group'] = $matches[1];
		$result['topic'] = $matches[2];

		return $result;
	}
	return false;
}

/**
* Groups the groups name and topic from the subject head
* @return Array	Group & Topic in an associative array
*
*/
function get_topic_and_tags($subject) {
	if(preg_match("/\[(.*) - (.*)\]$/",$subject,$matches)) {
		$result['topic'] = $matches[1];
		$result['tags'] = $matches[2];

		return $result;
	}
	if(preg_match("/\[(.*)\]$/",$subject,$matches)) {
		$result['topic'] = $matches[1];
		return $result;
	}
	return false;
}

/**
* Loops through our email
* 
*/
function loop_through_emails($pop3) {
	for($i=0;$i<=$pop3->numMsg();$i++) {
		$email = '';
		$pop_header = $pop3->getParsedHeaders($i);
		
		if(array_key_exists('Subject', $pop_header)) {
			$subject = $pop_header['Subject'];
			$message_info = get_topic_and_tags($subject);
			//$message_info = get_group_name_and_topic($subject);
			$email_header = $pop3->getParsedHeaders($i);
			if(false != $message_info) {
				$group = remove_underscores(get_info_from_email($pop_header));
				//$group = get_group_from_email($pop_header);
				if($group) {
					if(array_key_exists('Return-Path',$email_header)) {
						$email = $email_header['Return-Path'];
					} else {
						$email = get_email_from_header($pop_header);
					}
					$group_obj = get_group_by_name($group);
					if(is_array($group_obj)) {
						$user_obj = get_user_by_email($email);
						$topic_guid = get_topic_by_topic_name($message_info['topic'],$group_obj[0]->guid);
						$msg = htmlspecialchars($pop3->getBody($i));
						handle_messages($user_obj,$group_obj,$topic_guid,$msg,$tags,$message_info);
					} else {
						print "Not able to find group object: {$group}" .PHP_EOL;
					}
				} else {
					print "Not able to find group: {$group}" .PHP_EOL;
				}
				$pop3->deleteMsg($i);
			}
		}		
	}
}

/**
* Handles out actual messages and determines whether the message
* should be posted or create a new topic
*/
function handle_messages($user_obj,$group_obj,$topic_guid,$message,$tags=array(),$message_info = array()) {
	if(is_array($user_obj)) {
		if($topic_guid) {
			// append post
			if(add_post($user_obj[0],$group_obj[0],$topic_guid,$message)) {
				print "Added posts";
			} else {
				print "Unable to add topic - {$mesage}";
			}
		} else {
			// create post & send to forum

			// @todo create functionality to setup tags
			$tags = 'test one two three';
			
			if(add_topic($user_obj[0],$group_obj[0],$message_info['topic'],$message,$message_info['tags'])) {
				print "Added topic";
			} else {
				print "Unable to add topic - {$message_info['topic']}";
			}
		}
	} else {
		print "Unable to get user_obj";
	}
}

/**
 * Send an email using phpmailer
 *
 * @param string $from       From address 
 * @param string $from_name  From name
 * @param string $to         To address
 * @param string $to_name    To name
 * @param string $subject    The subject of the message.
 * @param string $body       The message body
 * @param array  $bcc        Array of address strings
 * @param bool   $html       Set true for html email, also consider setting 
 *                           altbody in $params array
 * @param array  $files      Array of file descriptor arrays, each file array 
 *                           consists of full path and name 
 * @param array  $params     Additional parameters
 * @return bool
 */   
function phpmailer_send($from, $from_name, $to, $to_name, $subject, $body, array $bcc = NULL, $html = false, array $files = NULL, array $params = NULL)
{
    global $CONFIG;
    
    static $phpmailer;
  
    // Ensure phpmailer object exists
    if (!is_object($phpmailer) || !is_a($phpmailer, 'PHPMailer')) 
    {
      require_once $CONFIG->pluginspath . '/groupmailshot/lib/class.phpmailer.php';
      require_once $CONFIG->pluginspath . '/groupmailshot/lib/class.smtp.php';
      $phpmailer = new PHPMailer();
    }

    if (!$from)
      throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'from'));
     
    if (!$to && !$bcc)
      throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'to'));         

    if (!$subject)
      throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'subject'));         

    // set line ending if admin selected \n (if admin did not change setting, false is returned)
    if (get_plugin_setting('nonstd_mta','phpmailer'))
      $phpmailer->LE = "\n";
    else
      $phpmailer->LE = "\r\n";
       

    ////////////////////////////////////
    // Format message
    
    $phpmailer->ClearAllRecipients();
    $phpmailer->ClearAttachments();

    // Set the from name and email
    $phpmailer->From = $from;
    $phpmailer->FromName = $from_name;

    // Set destination address
    if (isset($to))
      $phpmailer->AddAddress($to, $to_name);
    
    // set bccs if exists
    if ($bcc && is_array($bcc))
    {
      foreach ($bcc as $address)
        $phpmailer->AddBCC($address);
    }
    
    $phpmailer->Subject = $subject;

    if (!$html)
    {
      $body = strip_tags($body); 
      $phpmailer->IsHTML(false);
      if ($param && array_key_exists('altbody', $param))
        $phpmailer->AltBody = $param['altbody'];
    }
    else
    {
      $phpmailer->IsHTML(true);      
    }

    $phpmailer->Body = $body;
          
    if ($files && is_array($files))
    {
      foreach ($files as $file)
      {
        if (isset($file['path']))
          $phpmailer->AddAttachment($file['path'], $file['name']);
      }
    }

    $is_smtp   = get_plugin_setting('phpmailer_smtp','phpmailer');
    $smtp_host = get_plugin_setting('phpmailer_host','phpmailer');
    $smtp_auth = get_plugin_setting('phpmailer_smtp_auth','phpmailer');
    if ($is_smtp && isset($smtp_host))
    {
      $phpmailer->IsSMTP();
      $phpmailer->Host = $smtp_host;
      $phpmailer->SMTPAuth = false;
      if ($smtp_auth)
      {
        $phpmailer->SMTPAuth = true;
        $phpmailer->Username = get_plugin_setting('phpmailer_username','phpmailer');
        $phpmailer->Password = get_plugin_setting('phpmailer_password','phpmailer');

      //gmail support
      //$phpmailer->Host = "ssl://smtp.gmail.com";
      //$phpmailer->Port = 465;
      }
    }
    else
    {
      // use php's mail      
      $phpmailer->IsMail();         
    }
    
    $return = $phpmailer->Send();
    if (!$return )
    {
      trigger_error('PHPMailer error: ' . $phpmailer->ErrorInfo, E_USER_WARNING);
    }   
    return $return;           
}