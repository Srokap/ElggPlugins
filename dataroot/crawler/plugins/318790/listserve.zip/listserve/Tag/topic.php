<?php
function add_topic($user_guid,$group_entity,$title,$message,$tagsarray = array()) {
	global $TOPIC_MSG;
	$TOPIC_MSG = $message;
	// Check the user is a group member
	if(isset($group_entity)) {
		if (!$group_entity->isMember($user_guid)) {
			return false;
		}
	}

	// Get input data
	$access = "2";
	$user = (string)$user_guid->guid; // you need to be logged in to comment on a group forum

	// Convert string of tags into a preformatted array
	//$tagarray = string_to_tag_array($tags);
	
	// Make sure the title / message aren't blank
	if (empty($title) || empty($TOPIC_MSG)) {
		register_error(elgg_echo("grouptopic:blank"));
		return false;
	}
	
	// Initialise a new ElggObject
	$grouptopic = new ElggObject();
	// Tell the system it's a group forum topic
	$grouptopic->subtype = "groupforumtopic";
	// Set its owner to the current user
	$grouptopic->owner_guid = $user;
	// Set the group it belongs to

	$grouptopic->container_guid = $group_entity->guid;
	// For now, set its access to public (we'll add an access dropdown shortly)
	$grouptopic->access_id = $access;
	// Set its title and description appropriately
	$grouptopic->title = $title;
	
	// Before we can set metadata, we need to save the topic
	if (!$grouptopic->save()) {
		register_error(elgg_echo("grouptopic:error"));
		return false;
	}
	// Now let's add tags. We can pass an array directly to the object property! Easy.
	if (is_array($tagarray)) {
		$grouptopic->tags = $tagarray;
	}
	// add metadata
  $grouptopic->status = 'open'; // the current status i.e sticky, closed, resolved, open

  	// now add the topic message as an annotation
	$grouptopic->annotate('group_topic_post',$message,$access, $user);
  // add to river
	add_to_river('river/forum/topic/create','create',$_SESSION['user']->guid,$grouptopic->guid);

	// Success message
	system_message(elgg_echo("grouptopic:created"));
	return true;

}
