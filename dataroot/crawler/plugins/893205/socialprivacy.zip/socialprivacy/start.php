<?php
 /**
 *
 * SW Social Web LLC
 * Social Privacy for Comments
 * Elgg 1.8
 *
 */

elgg_register_event_handler('init', 'system', 'socialprivacy_init');

function socialprivacy_init() {

			global $CONFIG;
			
			elgg_extend_view('forms/comments/elgg','forms/comments/add');
}


?>