<?php
/**
 * Elgg comments add form
 *
 * @package Elgg
 * Social Privacy by SW Social Web
 * @uses ElggEntity $vars['entity'] The entity to comment on
 * @uses bool       $vars['inline'] Show a single line version of the form?
 */
 
 // Get Owner Privacy Settings
$user = get_user($vars['entity']->owner_guid);
$user_guid = $user->getGUID();
$privacy = elgg_get_plugin_user_setting('privacy', $user_guid, 'socialprivacy');

if (isset($vars['entity']) && elgg_is_logged_in()) {
	
	$inline = elgg_extract('inline', $vars, false);
	
	if ($inline) {
		echo elgg_view('input/text', array('name' => 'generic_comment'));
		echo elgg_view('input/submit', array('value' => elgg_echo('comment')));
	} else {
	
	$owner = get_user($vars['entity']->owner_guid);
	$user = $_SESSION['user']->username; 
	
	//Check owner privacy. If set to 2, it will be only for friends
	
	if ($privacy == 2)
	{
	//Check if user is a friend of the owner
	if (  $owner->username == $user || $owner->isFriendsWith(elgg_get_logged_in_user_guid()))
	{
	
	
?>
	<div>
		<label><?php echo elgg_echo("generic_comments:add"); ?></label>
		<?php echo elgg_view('input/longtext', array('name' => 'generic_comment')); ?>
	</div>
	<div class="elgg-foot">
<?php
		echo elgg_view('input/submit', array('value' => elgg_echo("generic_comments:post")));
?>
	</div>
<?php
	}
	}
	
	//If privacy set 1 or 0, comments will be for anyone
	
	else if ($privacy == 1 || $privacy == 0)
	{
	

?>
	<div>
		<label><?php echo elgg_echo("generic_comments:add"); ?></label>
		<?php echo elgg_view('input/longtext', array('name' => 'generic_comment')); ?>
	</div>
	<div class="elgg-foot">
<?php
		echo elgg_view('input/submit', array('value' => elgg_echo("generic_comments:post")));
?>
	</div>
<?php
	}
	
	
	}
	
	echo elgg_view('input/hidden', array(
		'name' => 'entity_guid',
		'value' => $vars['entity']->getGUID()
	));
}
