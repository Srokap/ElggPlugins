<?php 


$user = elgg_get_logged_in_user_entity();
$user_guid = $user->getGUID();
$privacy_setting = elgg_get_plugin_user_setting('privacy', $user_guid, 'socialprivacy');


?>

<p>
  <b>Who can comment on your posts?</b>

<?php

echo elgg_view('input/dropdown',array(
'name' => 'params[privacy]', 
'options_values'=> array( '0' => '  ', '1'=>'Anyone','2'=>'Friends Only'),
'value'=> $privacy_setting));

 ?>
</p>