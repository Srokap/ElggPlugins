
<div id="page_container">
<div id="page_wrapper">

<div id="layout_header">
<div id="wrapper_header">

	<!-- site logo -->
	<div id="logo"><a href="<?php echo $vars['url']; ?>">
		<img src="<?php echo $vars['url']; ?>mod/theme_simplebluewhite/graphics/example_logo.gif"/></a>
	</div>
	
</div><!-- /#wrapper_header -->
</div><!-- /#layout_header -->
