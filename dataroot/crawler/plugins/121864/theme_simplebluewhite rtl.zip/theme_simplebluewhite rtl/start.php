<?php

    /**
     * SimpleBlackBlueTech theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function simplebluewhite_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','simplebluewhite_init');
	
?>