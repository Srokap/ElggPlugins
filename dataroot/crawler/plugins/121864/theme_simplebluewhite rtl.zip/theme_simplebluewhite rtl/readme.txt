theme simplebluewhite rtl

my website : www.lofol.com

i just edit css file for RTL theme simplebluewhite
