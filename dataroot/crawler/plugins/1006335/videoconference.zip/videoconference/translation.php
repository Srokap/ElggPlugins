<translations>
<t text="You are viewing room" translation="You are viewing room"/>

<t text="Files" translation="Files"/>
<t text="Background" translation="Background"/>
<t text="Download" translation="Download"/>
<t text="Size" translation="Size"/>
<t text="Name" translation="Name"/>
<t text="Chat" translation="Chat"/>
<t text="You are participating in room" translation="You are participating in room"/>
<t text="Available" translation="Available"/>
<t text="Request" translation="Request"/>
<t text="Away" translation="Away"/>
<t text="Busy" translation="Busy"/>
<t text="Set Speaker" translation="Set Speaker"/>
<t text="Set Inquirer" translation="Set Inquirer"/>
<t text="Kick" translation="Kick"/>
<t text="Block" translation="Block"/>
<t text="Private Chat" translation="Private Chat"/>
<t text="UnBlock" translation="UnBlock"/>
<t text="Watch (Privately)" translation="Watch (Privately)"/>

<t text="Your connection performance:" translation="Your connection performance:"/>
<t text="Bandwidth" translation="Bandwidth"/>
<t text="Latency" translation="Latency"/>
<t text="Very Low" translation="Very Low"/>
<t text="Low" translation="Low"/>
<t text="Good" translation="Good"/>
<t text="Very Good" translation="Very Good"/>
<t text="Excellent" translation="Excellent"/>
<t text="Big Delay" translation="Big Delay"/>

</translations>