<?php
	$language_array = array(
		'file_multigroup_upload:group_selection' => '<div><h2 class="categoriestitle">Multiple Groups</h2></div>'
	);
	add_translation('en', $language_array);
?>
