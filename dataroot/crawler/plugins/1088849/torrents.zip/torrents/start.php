<?php
		function torrents_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('torrents'), $CONFIG->wwwroot . "mod/torrents");
		}
		
	register_elgg_event_handler('init','system','torrents_init');
	// Shares widget

?>