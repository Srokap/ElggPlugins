<?php
	gatekeeper();
	global $CONFIG;
	$do_delta = (int)get_input("delta");
	$odelta = '';
	if ($do_delta)
		$odelta = '&delta=1';
	$base = $CONFIG->wwwroot . 'mod/graphstats/';
	$webbase = $CONFIG->wwwroot . 'pg/graphstats';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Raphaël · Analytics</title>
        <link rel="stylesheet" href="<?php echo $base; ?>css/demo.css" type="text/css" media="screen">
        <link rel="stylesheet" href="<?php echo $base; ?>css/demo-print.css" type="text/css" media="print">
        <script src="<?php echo $base; ?>js/raphael.js" type="text/javascript" charset="utf-8"></script>
        <script src="<?php echo $base; ?>js/raphael.path.methods.js" type="text/javascript" charset="utf-8"></script>

        <script src="<?php echo $base; ?>js/jquery.js" type="text/javascript" charset="utf-8"></script>
        <script src="<?php echo $base; ?>js/analytics.js" type="text/javascript" charset="utf-8"></script>
        <style type="text/css" media="screen">
            body {
                background: #000;
            }
            #holder {
                height: 250px;
                margin: -125px 0 0 -400px;
                width: 800px;
            }
        </style>
    </head>
    <body>
	<a href="<?php echo $webbase; ?>?types=user<?php echo $odelta; ?>">users</a>
	<a href="<?php echo $webbase; ?>?types=group<?php echo $odelta; ?>">groups</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=bookmarks<?php echo $odelta; ?>">bookmarks</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=blog<?php echo $odelta; ?>">blog</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=tasks<?php echo $odelta; ?>">tasks</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=album<?php echo $odelta; ?>">photo albums</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=image<?php echo $odelta; ?>">photos</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=thewire<?php echo $odelta; ?>">thewire</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=event_calendar<?php echo $odelta; ?>">events</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=file<?php echo $odelta; ?>">files</a>
	<a href="<?php echo $webbase; ?>?types=object&subtypes=page_top<?php echo $odelta; ?>">top pages</a>
<?php
	$types = get_input("types");
	$subtypes = get_input("subtypes");
	if (!$types)
		$types = 'user';
	$typepars = '&types='.$types;
	if ($subtypes)
		$typepars .= '&subtypes='.$subtypes;

	if ($do_delta) {
?>
	[<a href="<?php echo $webbase; ?>?delta=0<?php echo $typepars; ?>">relative</a>]
<?php
	}
	else {
?>
	[<a href="<?php echo $webbase; ?>?delta=1<?php echo $typepars; ?>">absolute</a>]
<?php
	}
	$titletype = $types;
	if ($subtypes) {
		$titletype = $subtypes;
	}
	$users = elgg_get_entities(array('types' => $types,'subtypes'=>$subtypes,'limit' => 99999));
	$total = count($users);

?>
	<center><h2><?php echo $titletype; ?> - <?php echo $total ?></h2></center>
        <table id="data">
            <tfoot>

                <tr>

<?php
	$timestamps = array();
	foreach ($users as $user) {
		//echo $user->name.":".$user->time_created."<br/>";
		array_push($timestamps, $user->time_created);
	}
	sort($timestamps);
	$initial_time = $timestamps[0];
	$last_time = $timestamps[count($timestamps)-1];
	
	$initial_date = getdate($initial_time);
	$last_date = getdate($last_time);
	$start_month = mktime(0,0,0,$initial_date["mon"],1,$initial_date["year"]);

	$current_date = $start_month;
	$interval = 7*25*60*60;
	$array_index = 0;
	$nusers = 0;
	$date_users = array();
	while($current_date<($last_time+$interval)) {
		while($timestamps[$array_index]<$current_date && $array_index < count($timestamps)){
			$nusers += 1;
			$array_index += 1;
		}
		$date_users[$current_date] = $nusers;
		$current_date += $interval;
	}
	foreach ($date_users as $key => $value) {
		echo "<th>".$key."</th>\n";
	}
?>
                </tr>
            </tfoot>
            <tbody>
                <tr>

<?php
	$lastval = 0;
	foreach ($date_users as $key => $value) {
		$value = (int)$value;
		if ($do_delta) {
		    $delta = $value-$lastval;
		    $lastval = $value;
		    $value = $delta;
		}
		echo "<td>".$value."</td>\n";
	}
?>
                </tr>
            </tbody>
        </table>
        <div id="holder"></div>
        <p id="copy"> uses <a href="http://raphaeljs.com/">Raphaël</a>—JavaScript Vector Library</p>
    </body>
</html>

