Raphael entity graphs for elgg.
------------------------

Adds a pg/graphstats url to your site, where you can see evolution of different kinds of entity types.

Installation: Put inside your mod/ folder as graphstats and enjoy!!
	      Note the plugin doesn't add any links to the menu, to access the stats you have to input the url manually.

Tickets and source repository:
	http://bitbucket.org/rhizomatik/elgg_graphstats/

License: See COPYING (GPLv2)

--
devel@lorea.cc
