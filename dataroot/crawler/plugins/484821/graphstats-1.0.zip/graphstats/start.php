<?php

	function graphstats_page_handler($pages) {
		global $CONFIG;
		include($CONFIG->pluginspath . 'graphstats/graph.php');
	}

	function graphstats_init() {
                register_page_handler('graphstats','graphstats_page_handler');
	}

	register_elgg_event_handler('init','system','graphstats_init');


?>
