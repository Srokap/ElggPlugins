<?php
/**
 *	Profile Nagger Plugin
 *	@package Profile Nagger
 *	@author John Mellberg
 *	@license GNU General Public License (GPL) version 2
 *	@copyright John Mellberg (c)2009
 **/
	
	$isPgOwner = (page_owner() == $vars['user']->guid);
	
	$img_src = $vars['url'] . "mod/profile_nagger/graphics/nagger.gif";
	
	if ($vars['full'] == true) 
	{	
		if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0) {
			
			$profile = $vars['config']->profile;
			$field_count = count($profile); //total fields
			$fields_completed = 0; //completed fields
			
			
			foreach($profile as $shortname => $valtype) {
				
				//check that each profile field has a value, 
				//add to the number completed when they do.
				$value = $vars['user']->$shortname;
				
				if(!$isPgOwner)
				{
					$value = $vars['page_owner_user']->$shortname;
				}
						
				if (!empty($value)) {
					$fields_completed += 1;
				} 				
			}
			
			//arrive at percentage complete
			$percent_complete = round(100 / ($field_count / $fields_completed));			
		}
	}
?>
<div id="progress_indicator">
	<?php 
		if ($isPgOwner)
		{
			echo "Your profile is " . $percent_complete . "% complete.";
		} else {
			echo $vars['page_owner_user']->name . "'s profile is " . $percent_complete . "% complete."; 
		}
	?>
	<div id="progressBarContainer">
		<img src="<?php echo $img_src; ?>" width="<?php echo $percent_complete; ?>%" height="11px">
	</div>
	<?php
		if (($isPgOwner) && ($percent_complete < 100)) {
			echo "<p>Please complete your profile.</p>";	
		}
	?>
</div>