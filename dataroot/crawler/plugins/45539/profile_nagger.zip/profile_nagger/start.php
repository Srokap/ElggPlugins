<?php
/**
 *	Profile Nagger Plugin
 *	@package Profile Nagger
 *	@author John Mellberg
 *	@license GNU General Public License (GPL) version 2
 *	@copyright John Mellberg (c)2009
 **/


	function profile_nagger_init() {
		
		// Get config
		global $CONFIG;
		
		//add a widget
		//  
		add_widget_type('profile_nagger',"Profile Progress","This widget indicates your progress filling out your user profile");
			  
		// Extend system CSS with our own styles, which are defined in the feeds/css view
		extend_view('css','profile_nagger/css');

	}		
		
	register_elgg_event_handler('init','system','profile_nagger_init');

?>