<?php
/**
 * "Made friends" message not being added to the river
 * 
 */

elgg_register_event_handler('init', 'system', 'friends_add_not_in_river_init', 500);

function friends_add_not_in_river_init() {
	//overwrite the default action
	return register_action("friends/add", false, elgg_get_plugins_path() . 'friends_add_not_in_river/actions/friends/add.php');
}
