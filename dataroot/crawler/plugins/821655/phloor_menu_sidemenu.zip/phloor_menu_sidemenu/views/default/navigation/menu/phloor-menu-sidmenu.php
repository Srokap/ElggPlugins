<?php 
/*****************************************************************************
 * Phloor Menu Sidemenu                                                      *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 
?>

<?php 

//$vars['name'] = preg_replace('/[^a-z0-9\-]/i', '-', $vars['name']);
$vars['name'] = 'phloor-menu-sidemenu';
$headers = elgg_extract('show_section_headers', $vars, false);

$class = "elgg-menu elgg-menu-phloor-menu-sidemenu";
if (isset($vars['class'])) {
	$class .= " {$vars['class']}";
}

foreach ($vars['menu'] as $section => $menu_items) {
	echo elgg_view('navigation/menu/elements/section', array(
		'items' => $menu_items,
		'class' => "$class elgg-menu-{$vars['name']}-$section",
		'section' => $section,
		'name' => $vars['name'],
		'show_section_headers' => $headers
	));
}

/*
 <ul id="phloor-menu-sidemenu">
 <li class="run-upgrade">
 	<a href="<?php echo elgg_get_site_url() . 'upgrade.php'; ?>" title="run-upgrade"></a>
 	</li>
 <li class="dev-log"><a href="#" title="dev-log"></a></li>
</ul>
 */