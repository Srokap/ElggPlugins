<?php 
/*****************************************************************************
 * Phloor Display Var Dump                                                   *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/ 

?>
<?php 
/*
/**
 * define larger with (+24px) for menuitems with icons

$menuitems = phloor_menuitem_get_menuitems_top(array('menu_name' => 'phloor-menu-sidemenu'));

$css = '';
foreach($menuitems as $menuitem) {
	if(phloor_menuitem_instanceof($menuitem)) {
		$current_menuitems = array($menuitem);
	
		$children = $menuitem->getChildren();
		if(!empty($children)) {
			$current_menuitems = array_merge($children, $current_menuitems);
		}
		foreach($current_menuitems as $current_menuitem) {
			if($current_menuitem->hasImage()) {	
				// append to css
				$css .= <<<CSS
.elgg-menu li.elgg-menu-item-phloor-menuitem-{$current_menuitem->guid} a,
.elgg-menu li.elgg-menu-item-phloor-menuitem-{$current_menuitem->guid} a:hover {
padding-left: 1px;
}
CSS;
			}
		}
	}
}

echo $css;*/

?>
ul.elgg-menu-phloor-menu-sidemenu {
    position: fixed;
    margin: 0px;
    padding: 0px;
    top: 130px;
    left: 0px;
    list-style: none;
    z-index:9999;
}
ul.elgg-menu-phloor-menu-sidemenu > li {
    width: 140px;
}
ul.elgg-menu-phloor-menu-sidemenu > li ul li {
    width: 150px;
}

ul.elgg-menu-phloor-menu-sidemenu > li a {
	text-align: center;
	vertical-align: middle;

    display: block;
    margin-left: -2px;
    width: 140px;   
    background-color:#FFFFFF;
    background-repeat:no-repeat;
    background-position:center center;
    border:1px solid #4690D6;
    -moz-border-radius:0px 10px 10px 0px;
    -webkit-border-bottom-right-radius: 10px;
    -webkit-border-top-right-radius: 10px;
    -khtml-border-bottom-right-radius: 10px;
    -khtml-border-top-right-radius: 10px;
    -moz-box-shadow: 0px 4px 3px #000;
    -webkit-box-shadow: 0px 4px 3px #000;
   
    opacity: 0.9; 
}
ul.elgg-menu-phloor-menu-sidemenu > li ul li a {
    width: 150px;
}

ul.elgg-menu-phloor-menu-sidemenu li a:hover {
	text-decoration:none;
    background-color:#4690D6;
    color:white;
}
