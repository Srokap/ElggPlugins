/**
 * Phloor Menu Sidemenu
 * 
 * @package phloor_menu_sidemenu
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://www.13net.at/
 */
 
Version: 1.8-11.11.28
Requires: Elgg 1.8 or higher


/**
 * Description
 */
A javascript-sidemenu for your Elgg site. 

You can adapt the css/js to your own needs:
* phloor_menu_sidemenu/views/phloor_menu_sidemenu/extend/js/js.php
* phloor_menu_sidemenu/views/phloor_menu_sidemenu/extend/css/css.php

/**
 * Languages
 */
English
German


