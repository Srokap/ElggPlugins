<?php

  // Include the thickbox javascript library and associated CSS. Elgg already supplies jQuery.
  // With thanks to Alistair Young <alistair@codebrane.com>

?>
<script language="javascript" type="text/javascript" src="<?php echo $vars['url']; ?>mod/mood/vendors/msdropdown/js/jquery.dd.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $vars['url']; ?>mod/mood/vendors/msdropdown/dd.css" />
