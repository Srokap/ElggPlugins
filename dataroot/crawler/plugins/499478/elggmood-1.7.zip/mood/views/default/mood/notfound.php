<?php

	/**
	 * Elgg shout not found page
	 * 
	 * @package ElggShouts
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2010
	 * @link http://elgg.com/
	 */

?>

	<p>
		<?php

			echo elgg_echo("mood:notfound");
		
		?>
	</p>