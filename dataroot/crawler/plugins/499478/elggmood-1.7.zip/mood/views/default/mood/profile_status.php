<?php

	/**
	 * New mood post view for the activity stream
	 */
	 
	$owner = $vars['entity']->guid;
	$url_to_mood = $vars['url'] . "pg/mood/" . $vars['entity']->username;
	
	//grab the users latest from the mood
	$latest_mood = elgg_get_entities(array('types' => 'object', 'subtypes' => 'mood', 'owner_guid' => $owner, 'limit' => 1)); 

	if($latest_mood){
		foreach($latest_mood as $lw){
//
//
			$content = $lw->description;

$content = str_replace('ace','Ace <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ace.gif" />',$content);
$content = str_replace('alert','Alert <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/alert.gif" />',$content);
$content = str_replace('alien','Alien <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/alien.gif" />',$content);
$content = str_replace('angel','Angelic <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/angel.gif" />',$content);
$content = str_replace('angry','Angry <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/angry.gif" />',$content);
$content = str_replace('apple','Apples <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/apple.gif" />',$content);
$content = str_replace('bandit','Bandits <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bandit.gif" />',$content);
$content = str_replace('bat','Batty <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bat.gif" />',$content);
$content = str_replace('beard','Beards <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/beard.gif" />',$content);
$content = str_replace('beer','Beer <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/beer.gif" />',$content);
$content = str_replace('blushed','Blushed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/blush.gif" />',$content);
$content = str_replace('bored','Bored <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bored.gif" />',$content);
$content = str_replace('bulb','Bulbs <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/bulb.gif" />',$content);
$content = str_replace('calm','Calm <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/calm.gif" />',$content);
$content = str_replace('camera','Cameras <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/camera.gif" />',$content);
$content = str_replace('carrot','Carrots <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/carrot.gif" />',$content);
$content = str_replace('cat','Cats <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cat.gif" />',$content);
$content = str_replace('cheeky','Cheeky <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cheeky.gif" />',$content);
$content = str_replace('cheerful','Cheerful <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cheerful.gif" />',$content);
$content = str_replace('cherry','Cherries <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cherry.gif" />',$content);
$content = str_replace('chinese','Chinese <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/chinese.gif" />',$content);
$content = str_replace('classic','Classic <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/classic.gif" />',$content);
$content = str_replace('cobra','Cobra <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cobra.gif" />',$content);
$content = str_replace('cocktail','Cocktail <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cocktail.gif" />',$content);
$content = str_replace('coffee','Coffee <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/coffee.gif" />',$content);
$content = str_replace('confused','Confused <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/confused.gif" />',$content);
$content = str_replace('cool','Cool <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cool.gif" />',$content);
$content = str_replace('cross-eyed','Cross-eyed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cross-eyed.gif" />',$content);
$content = str_replace('crying','Crying <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cry.gif" />',$content);
$content = str_replace('cyclops','Cyclops <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/cyclops.gif" />',$content);
$content = str_replace('dead','Dead <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dead.gif" />',$content);
$content = str_replace('depressed','Depressed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/depressed.gif" />',$content);
$content = str_replace('devilish','Devilish <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/devil.gif" />',$content);
$content = str_replace('devious','Devious <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/devious.gif" />',$content);
$content = str_replace('dinosaur','Dinosaur <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dinosaur.gif" />',$content);
$content = str_replace('disappointed','Disappointed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/disappointed.gif" />',$content);
$content = str_replace('ditsy','Ditsy <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ditsy.gif" />',$content);
$content = str_replace('dog','Dog <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dog.gif" />',$content);
$content = str_replace('dragon','Dragons <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/dragon.gif" />',$content);
$content = str_replace('drink','Drinks <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/drink.gif" />',$content);
$content = str_replace('embarrassed','Embarrassed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/embarrassed.gif" />',$content);
$content = str_replace('ermm','Ermm <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ermm.gif" />',$content);
$content = str_replace('evil','Evil <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/evil.gif" />',$content);
$content = str_replace('evolved','Evolved <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/evolved.gif" />',$content);
$content = str_replace('eyerolling','Eyerolling <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/eyeRoll.gif" />',$content);
$content = str_replace('fish','Fish <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/fish.gif" />',$content);
$content = str_replace('foureyes','Foureyed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/foureyes.gif" />',$content);
$content = str_replace('gasmask','Gased <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/gasmask.gif" />',$content);
$content = str_replace('glasses','Glasses <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/glasses.gif" />',$content);
$content = str_replace('globe','Global <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/globe.gif" />',$content);
$content = str_replace('graduate','Graduated <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/graduate.gif" />',$content);
$content = str_replace('grimreaper','Grim Reaper <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/grimreaper.gif" />',$content);
$content = str_replace('grinning','Grins <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/grin.gif" />',$content);
$content = str_replace('hammer','Hammers <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/hammer.gif" />',$content);
$content = str_replace('happy','Happy <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/happy.gif" />',$content);
$content = str_replace('heart broken','Heart Broken <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/heart broken.gif" />',$content);
$content = str_replace('heart','Hearts <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/heart.gif" />',$content);
$content = str_replace('helicopter','Helicopter <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/helicopter.gif" />',$content);
$content = str_replace('house','House <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/house.gif" />',$content);
$content = str_replace('hungry','Hungry <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/hungry.gif" />',$content);
$content = str_replace('hurt','Hurt <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/hurt.gif" />',$content);
$content = str_replace('info','Informative <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/info.gif" />',$content);
$content = str_replace('jaguar','Jaguars <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/jaguar.gif" />',$content);
$content = str_replace('knocked-out','Knocked-out <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/knocked-out.gif" />',$content);
$content = str_replace('laugh','Laughs <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/laugh.gif" />',$content);
$content = str_replace('letter','Letters <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/letter.gif" />',$content);
$content = str_replace('lick','Licks <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/lick.gif" />',$content);
$content = str_replace('love','Love <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/love.gif" />',$content);
$content = str_replace('mad','Mad <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/mad.gif" />',$content);
$content = str_replace('minus','Negative <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/minus.gif" />',$content);
$content = str_replace('mischief','Mischievious <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/mischief.gif" />',$content);
$content = str_replace('mushroom','Mushrooms <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/mushroom.gif" />',$content);
$content = str_replace('music','Music <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/music.gif" />',$content);
$content = str_replace('needle','Needles <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/needle.gif" />',$content);
$content = str_replace('nervous','Nervous <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/nervous.gif" />',$content);
$content = str_replace('ninja','Ninja <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ninja.gif" />',$content);
$content = str_replace('normal','Normal <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/normal.gif" />',$content);
$content = str_replace('ogre','Ogre <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ogre.gif" />',$content);
$content = str_replace('old-man','Old <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/old-man.gif" />',$content);
$content = str_replace('paranoid','Paranoid <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/paranoid.gif" />',$content);
$content = str_replace('party','Party <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/party.gif" />',$content);
$content = str_replace('penguin','Penguin <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/penguin.gif" />',$content);
$content = str_replace('person','Person <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/person.gif" />',$content);
$content = str_replace('phone','Phones <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/phone.gif" />',$content);
$content = str_replace('pill','Pills <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/pill.png" />',$content);
$content = str_replace('pirate','Pirates <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/pirate.gif" />',$content);
$content = str_replace('plain','Plain <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/plain.gif" />',$content);
$content = str_replace('plus','Positive <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/plus.gif" />',$content);
$content = str_replace('ponder','Ponder <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/ponder.gif" />',$content);
$content = str_replace('puzzled','Puzzled <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/puzzled.gif" />',$content);
$content = str_replace('rambo','Rambo <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/rambo.gif" />',$content);
$content = str_replace('robot','Robot <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/robot.gif" />',$content);
$content = str_replace('rolleyes','Roll-eyes <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/rolleyes.gif" />',$content);
$content = str_replace('sad','Sad <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/sad.gif" />',$content);
$content = str_replace('scared','Scared <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/scared.gif" />',$content);
$content = str_replace('shocked','Shocked <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/shocked.gif" />',$content);
$content = str_replace('silly','Silly <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/silly.gif" />',$content);
$content = str_replace('skull','Skulls <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/skull.gif" />',$content);
$content = str_replace('sleeping','Sleeping <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/sleeping.gif" />',$content);
$content = str_replace('sleepy','Sleepy <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/sleepy.gif" />',$content);
$content = str_replace('smile','Smiles <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/smile.gif" />',$content);
$content = str_replace('smiley','Smileys <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/smiley.gif" />',$content);
$content = str_replace('smoker','Smoke <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/smoker.gif" />',$content);
$content = str_replace('speaker','Speakers <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/speaker.gif" />',$content);
$content = str_replace('speechless','Speechless <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/speechless.gif" />',$content);
$content = str_replace('spin','Spinning <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/spin.gif" />',$content);
$content = str_replace('square-eyed','Square-eyed <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/square-eyed.gif" />',$content);
$content = str_replace('surprised','Surprised <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/surprised.gif" />',$content);
$content = str_replace('thirsty','Thirsty <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/drink.gif" />',$content);
$content = str_replace('thumbdown','Thumbdown <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/thumbdown.gif" />',$content);
$content = str_replace('thumbup','Thumbup <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/thumbup.gif" />',$content);
$content = str_replace('tired','Tired <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/tired.gif" />',$content);
$content = str_replace('tv','TV <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/tv.gif" />',$content);
$content = str_replace('vampire','Vampire <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/vampire.gif" />',$content);
$content = str_replace('wink','Wink <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/wink.gif" />',$content);
$content = str_replace('jammin','Jammin <img src="' . $vars['url'] . 'mod/mood/graphics/emoticons/jammin.gif" />',$content);

//
//

			$time = "<span> (" . friendly_time($lw->time_created) . ")</span>";
		}
	}
	
	if($latest_mood){
		echo "<div class=\"profile_status\">";
		echo $content;
		if($owner == $_SESSION['user']->guid)
			echo " <a class=\"status_update\" href=\"{$url_to_mood}\">update</a>";
		echo $time;
		echo "</div>";
	}
?>
