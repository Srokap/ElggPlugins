<?php

	/**
	 * Elgg mood edit/add page
	 * 
	 * @package ElggMood
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 * 
	 */

		$mood_user = get_input('mood_username');
		if (!empty($mood_user)) { $msg = '@' . $mood_user . ' '; } else { $msg = ''; }

?>
<div class="post_to_mood">
<h3><?php echo elgg_echo("mood:doing"); ?></h3>
<script language="javascript">
$(document).ready(function(e) {
							$("body select").msDropDown();
						   });
</script>
<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>

	<form action="<?php echo $vars['url']; ?>action/mood/add" method="post" name="noteForm">
<?php echo elgg_view('input/securitytoken'); ?>
 <select name="note" id="mood_large-textarea" onchange="showValue(this.value)">
    <option value="ace" title="/mod/mood/graphics/emoticons/ace.gif">Ace</option>
    <option value="alert" title="/mod/mood/graphics/emoticons/alert.gif">Alert</option>
    <option value="alien" title="/mod/mood/graphics/emoticons/alien.gif">Alien</option>
    <option value="angel" title="/mod/mood/graphics/emoticons/angel.gif">Angel</option>
    <option value="angry" title="/mod/mood/graphics/emoticons/angry.gif">Angry</option>
    <option value="apple" title="/mod/mood/graphics/emoticons/apple.gif">Apple</option>
    <option value="bandit" title="/mod/mood/graphics/emoticons/bandit.gif">Bandit</option>
    <option value="bat" title="/mod/mood/graphics/emoticons/bat.gif">Bat</option>
    <option value="beard" title="/mod/mood/graphics/emoticons/beard.gif">Beard</option>
    <option value="beer" title="/mod/mood/graphics/emoticons/beer.gif">Beer</option>
    <option value="blushed" title="/mod/mood/graphics/emoticons/blush.gif">Blushed</option>
    <option value="bored" title="/mod/mood/graphics/emoticons/bored.gif">Bored</option>
    <option value="bulb" title="/mod/mood/graphics/emoticons/bulb.gif">Bulb</option>
    <option value="calm" title="/mod/mood/graphics/emoticons/calm.gif">Calm</option>
    <option value="camera" title="/mod/mood/graphics/emoticons/camera.gif">Camera</option>
    <option value="carrot" title="/mod/mood/graphics/emoticons/carrot.gif">Carrot</option>
    <option value="cat" title="/mod/mood/graphics/emoticons/cat.gif">Cat</option>
    <option value="cheeky" title="/mod/mood/graphics/emoticons/cheeky.gif">Cheeky</option>
    <option value="cheerful" title="/mod/mood/graphics/emoticons/cheerful.gif">Cheerful</option>
    <option value="cherry" title="/mod/mood/graphics/emoticons/cherry.gif">Cherry</option>
    <option value="chinese" title="/mod/mood/graphics/emoticons/chinese.gif">Chinese</option>
    <option value="classic" title="/mod/mood/graphics/emoticons/classic.gif">Classic</option>
    <option value="cobra" title="/mod/mood/graphics/emoticons/cobra.gif">Cobra</option>
    <option value="cocktail" title="/mod/mood/graphics/emoticons/cocktail.gif">Cocktail</option>
    <option value="coffee" title="/mod/mood/graphics/emoticons/coffee.gif">Coffee</option>
    <option value="confused" title="/mod/mood/graphics/emoticons/confused.gif">Confused</option>
    <option value="cool" title="/mod/mood/graphics/emoticons/cool.gif">Cool</option>
    <option value="cross-eyed" title="/mod/mood/graphics/emoticons/cross-eyed.gif">Cross-Eyed</option>
    <option value="crying" title="/mod/mood/graphics/emoticons/cry.gif">Crying</option>
    <option value="cyclops" title="/mod/mood/graphics/emoticons/cyclops.gif">Cyclops</option>
    <option value="dead" title="/mod/mood/graphics/emoticons/dead.gif">Dead</option>
    <option value="depressed" title="/mod/mood/graphics/emoticons/depressed.gif">Depressed</option>
    <option value="devilish" title="/mod/mood/graphics/emoticons/devil.gif">Devilish</option>
    <option value="devious" title="/mod/mood/graphics/emoticons/devious.gif">Devious</option>
    <option value="dinosaur" title="/mod/mood/graphics/emoticons/dinosaur.gif">Dinosaur</option>
    <option value="disappointed" title="/mod/mood/graphics/emoticons/disappointed.gif">Disappointed</option>
    <option value="ditsy" title="/mod/mood/graphics/emoticons/ditsy.gif">Ditsy</option>
    <option value="dog" title="/mod/mood/graphics/emoticons/dog.gif">Dog</option>
    <option value="dragon" title="/mod/mood/graphics/emoticons/dragon.gif">Dragon</option>
    <option value="drink" title="/mod/mood/graphics/emoticons/drink.gif">Drink</option>
    <option value="embarrassed" title="/mod/mood/graphics/emoticons/embarrassed.gif">Embarrassed</option>
    <option value="ermm" title="/mod/mood/graphics/emoticons/ermm.gif">Ermm</option>
    <option value="evil" title="/mod/mood/graphics/emoticons/evil.gif">Evil</option>
    <option value="evolved" title="/mod/mood/graphics/emoticons/evolved.gif">Evolved</option>
    <option value="eyerolling" title="/mod/mood/graphics/emoticons/eyeRoll.gif">Eye Roll</option>
    <option value="fish" title="/mod/mood/graphics/emoticons/fish.gif">Fish</option>
    <option value="foureyes" title="/mod/mood/graphics/emoticons/foureyes.gif">Four-Eyes</option>
    <option value="gasmask" title="/mod/mood/graphics/emoticons/gasmask.gif">Gasmask</option>
    <option value="glasses" title="/mod/mood/graphics/emoticons/glasses.gif">Glasses</option>
    <option value="globe" title="/mod/mood/graphics/emoticons/globe.gif">Globe</option>
    <option value="graduate" title="/mod/mood/graphics/emoticons/graduate.gif">Graduate</option>
    <option value="grimreaper" title="/mod/mood/graphics/emoticons/grimreaper.gif">Grim Reaper</option>
    <option value="grinning" title="/mod/mood/graphics/emoticons/grin.gif">Grinning</option>
    <option value="hammer" title="/mod/mood/graphics/emoticons/hammer.gif">Hammer</option>
    <option value="happy" title="/mod/mood/graphics/emoticons/happy.gif">Happy</option>
    <option value="heart broken" title="/mod/mood/graphics/emoticons/heart broken.gif">Heart Broken</option>
    <option value="heart" title="/mod/mood/graphics/emoticons/heart.gif">Heart</option>
    <option value="helicopter" title="/mod/mood/graphics/emoticons/helicopter.gif">Helicopter</option>
    <option value="house" title="/mod/mood/graphics/emoticons/house.gif">House</option>
    <option value="hungry" title="/mod/mood/graphics/emoticons/hungry.gif">Hungry</option>
    <option value="hurt" title="/mod/mood/graphics/emoticons/hurt.gif">Hurt</option>
    <option value="info" title="/mod/mood/graphics/emoticons/info.gif">Info</option>
    <option value="jaguar" title="/mod/mood/graphics/emoticons/jaguar.gif">Jaguar</option>
    <option value="jammin"  selected="selected" title="/mod/mood/graphics/emoticons/jammin.gif">Jammin</option>
    <option value="knocked-out" title="/mod/mood/graphics/emoticons/knocked-out.gif">Knocked-out</option>
    <option value="laugh" title="/mod/mood/graphics/emoticons/laugh.gif">Laughing</option>
    <option value="letter" title="/mod/mood/graphics/emoticons/letter.gif">Letter</option>
    <option value="lick" title="/mod/mood/graphics/emoticons/lick.gif">Lick</option>
    <option value="love" title="/mod/mood/graphics/emoticons/love.gif">Love</option>
    <option value="mad" title="/mod/mood/graphics/emoticons/mad.gif">Mad</option>
    <option value="minus" title="/mod/mood/graphics/emoticons/minus.gif">Minus</option>
    <option value="mischief" title="/mod/mood/graphics/emoticons/mischief.gif">Mischief</option>
    <option value="mushroom" title="/mod/mood/graphics/emoticons/mushroom.gif">Mushroom</option>
    <option value="music" title="/mod/mood/graphics/emoticons/music.gif">Music</option>
    <option value="needle" title="/mod/mood/graphics/emoticons/needle.gif">Needle</option>
    <option value="nervous" title="/mod/mood/graphics/emoticons/nervous.gif">Nervous</option>
    <option value="ninja" title="/mod/mood/graphics/emoticons/ninja.gif">Ninja</option>
    <option value="normal" title="/mod/mood/graphics/emoticons/normal.gif">Normal</option>
    <option value="ogre" title="/mod/mood/graphics/emoticons/ogre.gif">Ogre</option>
    <option value="old-man" title="/mod/mood/graphics/emoticons/old-man.gif">Old-Man</option>
    <option value="paranoid" title="/mod/mood/graphics/emoticons/paranoid.gif">Paranoid</option>
    <option value="party" title="/mod/mood/graphics/emoticons/party.gif">Party</option>
    <option value="penguin" title="/mod/mood/graphics/emoticons/penguin.gif">Penguin</option>
    <option value="person" title="/mod/mood/graphics/emoticons/person.gif">Person</option>
    <option value="phone" title="/mod/mood/graphics/emoticons/phone.gif">Phone</option>
    <option value="pill" title="/mod/mood/graphics/emoticons/pill.png">Pill</option>
    <option value="pirate" title="/mod/mood/graphics/emoticons/pirate.gif">Pirate</option>
    <option value="plain" title="/mod/mood/graphics/emoticons/plain.gif">Plain</option>
    <option value="plus" title="/mod/mood/graphics/emoticons/plus.gif">Plus</option>
    <option value="ponder" title="/mod/mood/graphics/emoticons/ponder.gif">Ponder</option>
    <option value="puzzled" title="/mod/mood/graphics/emoticons/puzzled.gif">Puzzled</option>
    <option value="rambo" title="/mod/mood/graphics/emoticons/rambo.gif">Rambo</option>
    <option value="robot" title="/mod/mood/graphics/emoticons/robot.gif">Robot</option>
    <option value="rolleyes" title="/mod/mood/graphics/emoticons/rolleyes.gif">Roll-Eyes</option>
    <option value="sad" title="/mod/mood/graphics/emoticons/sad.gif">Sad</option>
    <option value="scared" title="/mod/mood/graphics/emoticons/scared.gif">Scared</option>
    <option value="shocked" title="/mod/mood/graphics/emoticons/shocked.gif">Shocked</option>
    <option value="silly" title="/mod/mood/graphics/emoticons/silly.gif">Silly</option>
    <option value="skull" title="/mod/mood/graphics/emoticons/skull.gif">Skull</option>
    <option value="sleeping" title="/mod/mood/graphics/emoticons/sleeping.gif">Sleeping</option>
    <option value="sleepy" title="/mod/mood/graphics/emoticons/sleepy.gif">Sleepy</option>
    <option value="smile" title="/mod/mood/graphics/emoticons/smile.gif">Smile</option>
    <option value="smiley" title="/mod/mood/graphics/emoticons/smiley.gif">Smiley</option>
    <option value="smoker" title="/mod/mood/graphics/emoticons/smoker.gif">Smoker</option>
    <option value="speaker" title="/mod/mood/graphics/emoticons/speaker.gif">Speaker</option>
    <option value="speechless" title="/mod/mood/graphics/emoticons/speechless.gif">Speechless</option>
    <option value="spin" title="/mod/mood/graphics/emoticons/spin.gif">Spin</option>
    <option value="square-eyed" title="/mod/mood/graphics/emoticons/square-eyed.gif">Square-eyed</option>
    <option value="surprised" title="/mod/mood/graphics/emoticons/surprised.gif">Surprised</option>
    <option value="thirsty" title="/mod/mood/graphics/emoticons/drink.gif">Thirsty</option>
    <option value="thumbdown" title="/mod/mood/graphics/emoticons/thumbdown.gif">Thumb down</option>
    <option value="thumbup" title="/mod/mood/graphics/emoticons/thumbup.gif">Thumb up</option>
    <option value="tired" title="/mod/mood/graphics/emoticons/tired.gif">Tired</option>
    <option value="tv" title="/mod/mood/graphics/emoticons/tv.gif">TV</option>
    <option value="vampire" title="/mod/mood/graphics/emoticons/vampire.gif">Vampire</option>
    <option value="wink" title="/mod/mood/graphics/emoticons/wink.gif">Wink</option>

  </select>
			<input type="hidden" name="method" value="site" />
			<input type="submit" value="<?php echo elgg_echo('save'); ?>" />
	</form>
</div>
<?php echo elgg_view('input/urlshortener'); ?>
