<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'mood' => "Mood",
			'mood:latest' => "Mood",
			'mood:user' => "%s's mood",
			'mood:posttitle' => "%s's mood: %s",
			'mood:everyone' => "All mood posts",
	
			'mood:read' => "Mood posts",
			
			'mood:strapline' => "%s",
	
			'mood:add' => "Post my mood",
		    'mood:text' => "Mood",
			'mood:reply' => "Reply",
			'mood:via' => "via",
			'mood:moodd' => "Posted mood",
			'mood:charleft' => "characters left",
			'item:object:mood' => "Mood posts",
			'mood:notedeleted' => "note deleted",
			'mood:doing' => "How do you feel? Tell everyone your mood:",
			'mood:newpost' => 'New mood post',
			'mood:addpost' => 'Post mood',

	
        /**
	     * The mood river
	     **/
	        
	        //generic terms to use
	        'mood:river:created' => "%s's mood is ",
	        
	        //these get inserted into the river links to take the user to the entity
	        'mood:river:create' => "on Duuit! mood.",
	        
	    /**
	     * Mood widget
	     **/
	     
	        'mood:sitedesc' => 'This widget shows the latest mood posted',
	        'mood:yourdesc' => 'This widget shows your latest mood',
	        'mood:friendsdesc' => 'This widget will show the latest from your friends mood',
	        'mood:friends' => 'Your friends mood',
	        'mood:num' => 'Number of items to display',
	        
	        
	
		/**
		 * Status messages
		 */
	
			'mood:posted' => "Your message was successfully posted to the mood.",
			'mood:deleted' => "Your note was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'mood:blank' => "Sorry; you need to actually put something in the textbox before we can save it.",
			'mood:notfound' => "Sorry; we could not find the specified note.",
			'mood:notdeleted' => "Sorry; we could not delete this shout.",
	
	
		/**
		 * Settings
		 */
			'mood:smsnumber' => "Your SMS number if different from your mobile number (mobile number must be set to public for the mood to be able to use it). All phone numbers must be in international format.",
			'mood:channelsms' => "The number to send SMS messages to is <b>%s</b>",
			
	);
					
	add_translation("en",$english);

?>
