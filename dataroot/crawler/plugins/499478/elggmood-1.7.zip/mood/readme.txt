/**
	 * Elgg Mood
	 * 
	 * @package ElggMood
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Duuit! <bman@duuit.com>
	 * @copyright Duuit! 2010
	 * @link http://duuit.com/
*/

Install: Just drop it into the mod directory and that should be it.
