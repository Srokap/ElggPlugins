<div class="contentWrapper<?php

	if (isset($vars['subclass'])) echo ' ' . $vars['subclass'];

?>">
<?php
	/*
	X'Mass theme fro Elgg from Team Webgalli
	Author : Regina M @ Team Webgalli
	Website : http://webgalli.com
	For more free elgg themes/plugins : Visit webgalli.com
	Licence : GPL
	*/
	echo $vars['body'];

?>
</div>