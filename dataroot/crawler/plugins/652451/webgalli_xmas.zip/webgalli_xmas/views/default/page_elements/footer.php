<?php
	/*
	X'Mass theme fro Elgg from Team Webgalli
	Author : Regina M @ Team Webgalli
	Website : http://webgalli.com
	For more free elgg themes/plugins : Visit webgalli.com
	Licence : GPL
	*/
?></div>
<div id="webgalli_footer_wrapper">
	<div id="webgalli_footer">
        Copyright &copy 2010 <a href="#"><?php echo $vars['config']->sitename;?></a> | 
        Powered by <a href="http://www.elgg.org" target="_blank">Elgg</a> 
        & Theme by <a href="http://www.webgalli.com" target="_blank">Team Webgalli</a>
        <div class="cleaner"></div>
    </div>
</div>

</body>
</html>