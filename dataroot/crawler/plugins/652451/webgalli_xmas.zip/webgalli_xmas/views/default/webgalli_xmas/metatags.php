<?php
	/*
	X'Mass theme fro Elgg from Team Webgalli
	Author : Regina M @ Team Webgalli
	Website : http://webgalli.com
	For more free elgg themes/plugins : Visit webgalli.com
	Licence : GPL
	*/
?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/webgalli_xmas/scripts/ddsmoothmenu.js">
/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/
</script>

<script type="text/javascript">
ddsmoothmenu.init({
	mainmenuid: "webgalli_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
