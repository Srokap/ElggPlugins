<?php
	/*
	X'Mass theme fro Elgg from Team Webgalli
	Author : Regina M @ Team Webgalli
	Website : http://webgalli.com
	For more free elgg themes/plugins : Visit webgalli.com
	Licence : GPL
	*/
	 
?>
<!--<?php echo $vars['config']->sitename; ?> is proudly powered by Elgg and the theme is designed by Team Webgalli.If you are looking for any custom works with Elgg, or any hosting service for Elgg, drop us a mail at webgalli@gmail.com or visit us at www.webgalli.com. We will be there 24*7*365 for you.-->

<div id="webgalli_outer_wrapper">
	<div id="webgalli_wrapper">
    
    	<div id="webgalli_header">
            <div id="site_title"><h1><a href="#" target="_parent"></a></h1></div>
            <div id="webgalli_menu" class="ddsmoothmenu">
                <ul>
                    <li><a href="#" class="selected"><span></span>Home</a></li>
                    <li><a href=""><span></span>link2</a>
                      	<ul>
                        	<li><a href="">Item One</a></li>
                        	<li><a href="">Item Two</a></li>
                        	<li><a href="">Item Three</a></li>
                    	</ul>
                    </li>
                    <li><a href="#"><span></span>link3</a>
                      	<ul>
                            <li><a href="">Page One</a></li>
                            <li><a href="">Page Two</a></li>
                            <li><a href="">Page Three</a></li>
                            <li><a href="">Page Four</a></li>
                            <li><a href="">Page Five</a></li>
                        </ul>
                    </li>
                  	<li><a href="#"><span></span>link4</a></li>
                    <li><a href="#"><span></span>link5</a></li>
                </ul>
                <br style="clear: left" />
            </div> <!-- end of menu -->
            <div class="cleaner"></div>
            
		</div> <!-- end of header -->
      <div id="intro_text"><img src="<?php echo $vars['url']; ?>mod/webgalli_xmas/graphics/webgalli_mc.png" alt="Merry Christmas" /></div>