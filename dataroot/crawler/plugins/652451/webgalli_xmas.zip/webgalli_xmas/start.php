<?php
	/*
	X'Mass theme fro Elgg from Team Webgalli
	Author : Regina M @ Team Webgalli
	Website : http://webgalli.com
	For more free elgg themes/plugins : Visit webgalli.com
	Licence : GPL
	*/
 
    function webgalli_xmas_init()
    {
			extend_view('metatags','webgalli_xmas/metatags');
	}
 
    register_elgg_event_handler('init','system','webgalli_xmas_init');
 
?>