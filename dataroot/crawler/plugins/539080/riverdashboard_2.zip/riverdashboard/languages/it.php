<?php
/*	Aggiornamento della traduzione italiana per ELGG 1.7.1	  by    WWW.ROBOLOGY.EU	*/
	$italian = array(

        'riverdashboard'    => 'Plancia',
        'riverdashboard:default_view'   => 'Vista predefinita',

		'mine' => 'Le mie',
		'filter' => 'Filtro',
		'riverdashboard:useasdashboard' => "Sostituire la plancia di default con questa attivit&#224;?",
		'activity' => 'Attivit&#224;',
		'riverdashboard:recentmembers' => 'Ultimi iscritti',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Annunci sul sito",
		'sitemessages:posted' => "Aggiunti",
		'sitemessages:river:created' => "Gestione sito, %s,",
		'sitemessages:river:create' => "Aggiunto un nuovo sito",
		'sitemessages:add' => "Aggiungi un messaggio sul lato della pagina",
		'sitemessage:deleted' => "Messaggio del sito cancellato",
		'sitemessage:error' => "Salvataggio del messaggio non riuscito.",
		
		'river:widget:noactivity' => 'Non possiamo trovare un\'attivit&#224;.',
		'river:widget:title' => "Attivit&#224;",
		'river:widget:description' => "Mostra le ultime attivit&#224;.",
		'river:widget:title:friends' => "Attivit� degli amici",
		'river:widget:description:friends' => "Mostrare cosa dicono i tuoi amici.",
		'river:widgets:friends' => "Amici",
		'river:widgets:mine' => "Le mie",
		'river:widget:label:displaynum' => "Numero di novit&#224; da visualizzare:",
		'river:widget:type' => "Quale lato vorresti visualizzare? Uno che mostri le tue attivit&#224; o uno che mostri le attivit&#224; dei tuoi amici?",
		'item:object:sitemessage' => "Messaggi del sito",
		'riverdashboard:avataricon' => "Preferisci usare un avatar o un'immagine sul lato delle attivit�?",
		'option:icon' => 'Immagini',
		'option:avatar' => 'Avatar',
	);
					
	add_translation("it",$italian);

?>
