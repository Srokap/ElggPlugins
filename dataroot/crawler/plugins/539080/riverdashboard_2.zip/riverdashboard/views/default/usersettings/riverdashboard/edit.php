<p>
	<?php echo elgg_echo('riverdashboard:default_view'); ?>
	<select name="params[orient]">
        <?php
        foreach(array('all','friends','mine') as $view) {
            echo "<option value='$view'";
            if ($vars['entity']->orient == $view) echo ' selected="yes" ';
            echo ">".elgg_echo($view)."</option>";
        }?>
	</select>
</p>
