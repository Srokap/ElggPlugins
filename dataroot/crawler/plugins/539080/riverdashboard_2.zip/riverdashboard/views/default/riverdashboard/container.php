<?php

?>

<div id="river_container"><?php echo $vars['body']; ?></div>