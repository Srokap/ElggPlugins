<?php

/*
<script type="text/javascript">
	$(document).ready(function() {
	
		var href = $("div.river_pagination a").attr('href');
		href = href.replace("callback=true","callback=");
		$("div.river_pagination a").attr('href',href);
	
	});
</script>

*/

?>