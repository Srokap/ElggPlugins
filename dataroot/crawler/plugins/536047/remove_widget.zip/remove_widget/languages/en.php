<?php

$english = array(
	'remove_widgets' => 'Remove Widgets',
	'remove_widget:instructions' => 'Select widget for removal: ',
	'remove_widget:remove' => 'Remove',
	'remove_widgets:message' => 'Removed %s instances of the selected widget',
);
					
add_translation("en", $english);
