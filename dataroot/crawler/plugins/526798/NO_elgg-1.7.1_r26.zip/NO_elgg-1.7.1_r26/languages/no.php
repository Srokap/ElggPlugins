<?php
/**
 * Core language file
 *
 * @package Elgg
 * @subpackage Core
 * @author bitjungle and Torger Åge Sinnes
 * @link http://www.bitjungle.com
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 *
 *
 * common [Norwegian bokmål]
 *
 * This file is part of the Norwegian language package for Elgg 1.7.1
 * Copyright (c) 2010 bitjungle.com
 *
 * The package is free software; you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation, version 2 of the License.
 *
 * The Norwegian language package is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this language
 * package. If not, see <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>.
 *
 *
 * Jeg har prøvd å legge språket opp mot den som brukes på Facebook, fordi det blir lettere å kjenne
 * igjen for brukere. Eksempel: jeg har oversatt "Dashboard" med "Hjem" og "The Wire" med "Veggen".
 * Men jeg er åpen for innspill!
 *
 * Andre ord jeg har valgt (gjennomfør i alle filer):
 *
 * - Item/Entity = Enhet
 * - Enable/Disable = Aktiver/Deaktiver
 * - Widget = Innstikk
 * - Plugin = Utvidelse
 * - Site = Nettsted
 *
 */

$norwegian = array(

/**
 * Sites
 */

'item:site' => 'Nettsted',

/**
 * Sessions
 */

'login' => "Logg inn",
'loginok' => "Du har blitt logget inn.",
'loginerror' => "Vi kunne ikke logge deg inn. Årsaken kan være at du ikke har validert kontoen din ennå, detaljene du anga var feil eller at du har gjort for mange påloggingsforsøk. Forsikre deg om at alle detaljer er korrekte, og prøv igjen.",

'logout' => "Logg ut",
'logoutok' => "Du har blitt logget ut.",
'logouterror' => "Vi kunne ikke logge deg ut. Vennligst prøv igjen.",

'loggedinrequired' => "Du må være pålogget for å se den siden.",
'adminrequired' => "Du må være administrator for å se den siden.",
'membershiprequired' => "Du må være medlem av denne gruppen for å se den siden.",


/**
 * Errors
 */
'exception:title' => "Velkommen til Elgg.",

'InstallationException:CantCreateSite' => "Unable to create a default ElggSite with credentials Name:%s, Url: %s",

'actionundefined' => "Den forespurte handlingen (%s) er ikke definert på systemet.",
'actionloggedout' => "Du må være pålogget for å utføre den hendelsen.",

'SecurityException:Codeblock' => "Denied access to execute privileged code block",
'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials.",
'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",

'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",

'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",

'PluginException:MisconfiguredPlugin' => "%s is a misconfigured plugin. It has been disabled. Please see the Elgg wiki for possible causes.",

'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",

'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",

'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",

'IOException:UnableToSaveNew' => "Unable to save new %s",

'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",

'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
'IOException:NotDirectory' => "%s is not a directory.",

'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",

'ClassException:ClassnameNotClass' => "%s is not a %s.",
'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

'ImportException:ImportFailed' => "Could not import element %d",
'ImportException:ProblemSaving' => "There was a problem saving %s",
'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",

'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",

'ExportException:NoSuchEntity' => "No such entity GUID:%d",

'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
'ImportException:NotAllImported' => "Not all elements were imported.",

'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
'InvalidParameterException:MissingOwner' => "File %s (file guid:%d) (owner guid:%d) is missing an owner!",
'IOException:CouldNotMake' => "Could not make %s",
'IOException:MissingFileName' => "You must specify a name before opening a file.",
'ClassNotFoundException:NotFoundNotSavedWithFile' => "Filestore not found or class not saved with file!",
'NotificationException:NoNotificationMethod' => "No notification method specified.",
'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",

'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
'DatabaseException:NoACL' => "No access control was provided on query",

'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",

'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
'InvalidParameterException:NoDataFound' => "Could not find any data.",
'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",

'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.",
'ConfigurationException:NoSiteID' => "No site ID has been specified.",
'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()",
'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",
'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
'APIException:ParameterNotArray' => "%s does not appear to be an array.",
'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication",
'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
'CallException:InvalidCallMethod' => "%s must be called using '%s'",
'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable",
'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
'APIException:NotGetOrPost' => "Kallemetode må være GET eller POST",
'APIException:MissingAPIKey' => "Manglende API-nøkkel",
'APIException:BadAPIKey' => "Bad API key",
'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
'APIException:MissingTime' => "Missing X-Elgg-time header",
'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
'APIException:NoQueryString' => "No data on the query string",
'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
'APIException:MissingContentType' => "Missing content type for post data",
'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
'SecurityException:DupePacket' => "Packet signature already seen.",
'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",

'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",

'PluginException:NoPluginName' => "The plugin name could not be found",

'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",


'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
'InstallationException:DatarootBlank' => "You have not specified a data directory.",

'SecurityException:authenticationfailed' => "User could not be authenticated",

'CronException:unknownperiod' => '%s is not a recognised period.',

'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',

'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',

'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
/**
 * API
 */
'system.api.list' => "List alle tilgjengelige API-kall på systemet.",
'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",

/**
 * User details
 */

'name' => "Navn",
'email' => "E-postadresse",
'username' => "Brukernavn",
'password' => "Passord",
'passwordagain' => "Passord (gjenta for verifisering)",
'admin_option' => "Gjøre denne brukeren til admin?",

/**
 * Access
 */

'PRIVATE' => "Privat",
'LOGGED_IN' => "Innloggede brukere",
'PUBLIC' => "Offentlig",
'access:friends:label' => "Venner",
'access' => "Tilgang",

/**
 * Dashboard and widgets
 */

'dashboard' => "Hjem",
'dashboard:configure' => "Rediger side",
'dashboard:nowidgets' => "Din hjemmeside er inngangen til dette nettstedet. Klikk 'Rediger side' for å legge til innstikk for å følge med på innhold og på ditt liv i systemet.",

'widgets:add' => 'Legg til innstikk på din side',
'widgets:add:description' => "Velg hvilke egenskaper du vil ha på din side ved å dra dem fra <b>innstikkgalleriet</b> på høyre side til hvilken som helst av de tre innstikkområdene nedenfor, og plasser dem der du vil at de skal vises.

For å fjerne et innstikk kan du dra den tilbake til <b>innstikkgalleriet</b>.",
'widgets:position:fixed' => '(Fast plassering på side)',

'widgets' => "Innstikk",
'widget' => "Innstikk",
'item:object:widget' => "Innstikk",
'layout:customise' => "Tilpass oppsett",
'widgets:gallery' => "Innstikkgalleri",
'widgets:leftcolumn' => "Innstikk til venstre",
'widgets:fixed' => "Fast plassering",
'widgets:middlecolumn' => "Innstikk i midten",
'widgets:rightcolumn' => "Innstikk til høyre",
'widgets:profilebox' => "Profilboks",
'widgets:panel:save:success' => "Dine innstikk ble lagret.",
'widgets:panel:save:failure' => "Det oppsto et problem ved lagring av dine innstikk. Vennligst prøv igjen.",
'widgets:save:success' => "The widget was successfully saved.",
'widgets:save:failure' => "Vi kunne ikke lagre innstikket ditt. Vennligst prøv igjen.",
'widgets:handlernotfound' => 'This widget is either broken or has been disabled by the site administrator.',

/**
 * Groups
 */

'group' => "Gruppe",
'item:group' => "Grupper",

/**
 * Users
 */

'user' => "Bruker",
'item:user' => "Brukere",

/**
 * Friends
 */

'friends' => "Venner",
'friends:yours' => "Dine venner",
'friends:owned' => "%s sine venner",
'friend:add' => "Legg til venn",
'friend:remove' => "Fjern venn",

'friends:add:successful' => "Du har lagt til %s som venn.",
'friends:add:failure' => "Vi kunne ikke legge til %s som venn. Vennligst prøv igjen.",

'friends:remove:successful' => "Du har fjernet %s som venn.",
'friends:remove:failure' => "Vi kunne ikke fjerne %s som venn. Vennligst prøv igjen.",

'friends:none' => "Denne brukeren har ikke lagt til noen som venn ennå.",
'friends:none:you' => "Du har ikke lagt til noen som venn! Søk på dine interesser for å finne personer å følge.",

'friends:none:found' => "Ingen venner ble funnet.",

'friends:of:none' => "Ingen har lagt til denne brukeren som venn ennå.",
'friends:of:none:you' => "Ingen har lagt til deg som venn ennå. Begynn med å legge inn innhold og fyll ut profilen din for at andre skal finne deg!",

'friends:of:owned' => "Andre som har gjort %s til en venn",

'friends:num_display' => "Antall venner som skal vises",
'friends:icon_size' => "Ikonstørrelse",
'friends:tiny' => "minst",
'friends:small' => "liten",
'friends:of' => "Venner med",
'friends:collections' => "Samling av venner",
'friends:collections:add' => "Ny vennesamling",
'friends:addfriends' => "Legg til venner",
'friends:collectionname' => "Samlingsnavn",
'friends:collectionfriends' => "Venner i samlingen",
'friends:collectionedit' => "Rediger samlingen",
'friends:nocollections' => "Du har ikke noen samlinger enda.",
'friends:collectiondeleted' => "Samlingen din har blitt slettet.",
'friends:collectiondeletefailed' => "Kunne ikke slette samlingen. Du mangler rettigheter, eller det har oppstått et annet problem.",
'friends:collectionadded' => "Samlingen din ble opprettet",
'friends:nocollectionname' => "Du må gi samlingen din et navn før den kan bli opprettet.",
'friends:collections:members' => "Medlemmer i samlingen",
'friends:collections:edit' => "Rediger samlingen",

'friends:river:created' => "%s la til venneverktøyet.",
'friends:river:updated' => "%s oppdaterte venneverktøyet.",
'friends:river:delete' => "%s fjernet venneverktøyet.",
'friends:river:add' => "%s er nå venn med",

'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZÆØÅ',

/**
 * Feeds
 */
'feed:rss' => 'Abonner på strøm',
'feed:odd' => 'Syndicate OpenDD',

/**
 * links
 **/

'link:view' => 'se lenke',


/**
 * River
 */
'river' => "River",
'river:relationship:friend' => 'er nå venn med',
'river:noaccess' => 'Du har ikke rettigheter til å se dette elementet.',
'river:posted:generic' => '%s publiserte',
'riveritem:single:user' => 'en bruker',
'riveritem:plural:user' => 'noen brukere',

/**
 * Plugins
 */
'plugins:settings:save:ok' => "Innstillinger for utvidelsen %s er lagret.",
'plugins:settings:save:fail' => "Det oppsto et problem ved lagring av innstillinger for utvidelsen %s.",
'plugins:usersettings:save:ok' => "Brukerinnstillinger for utvidelsen %s ble lagret.",
'plugins:usersettings:save:fail' => "Det oppsto et problem ved lagring av brukerinnstillinger for utvidelsen %s.",
'admin:plugins:label:version' => "Versjon",
'item:object:plugin' => 'Konfigurasjonsinnstillinger for utvidelser',

/**
 * Notifications
 */
'notifications:usersettings' => "Meldingsinnstillinger",
'notifications:methods' => "Vennligst spesifiser hvilken metoder du vil tillate.",

'notifications:usersettings:save:ok' => "Dine meldingsinnstillinger ble lagret.",
'notifications:usersettings:save:fail' => "Det oppsto et problem ved lagring av meldingsinnstillinger.",

'user.notification.get' => 'Returner meldingsinnstillinger for en gitt bruker.',
'user.notification.set' => 'Sett meldingsinnstillinger for en gitt bruker.',
/**
 * Search
 */

'search' => "Søk",
'searchtitle' => "Søk: %s",
'users:searchtitle' => "Søker etter bruker: %s",
'groups:searchtitle' => "Søker etter grupper: %s",
'advancedsearchtitle' => "%s med treff som passer %s",
'notfound' => "Ingen treff.",
'next' => "Neste",
'previous' => "Forrige",

'viewtype:change' => "Endre listetype",
'viewtype:list' => "Listevisning",
'viewtype:gallery' => "Galleri",

'tag:search:startblurb' => "Innlegg med stikkord som passer '%s':",

'user:search:startblurb' => "Brukere som passer '%s':",
'user:search:finishblurb' => "For å vise mer, klikk her.",

'group:search:startblurb' => "Grupper som passer '%s':",
'group:search:finishblurb' => "For å vise mer, klikk her.",
'search:go' => 'Søk',
'userpicker:only_friends' => 'Bare venner',

/**
 * Account
 */

'account' => "Konto",
'settings' => "Innstillinger",
'tools' => "Verktøy",
'tools:yours' => "Dine verktøy",

'register' => "Registrer",
'registerok' => "Du har registrert konto på %s.",
'registerbad' => "Registreringen mislyktes. Brukernavnet finnes, passordene er ulike, eller brukernavn og passord er for kort.",
'registerdisabled' => "Registrering har blitt deaktivert av systemadministratoren",

'firstadminlogininstructions' => 'Your new Elgg site has been successfully installed and your administrator account created. You can now configure your site further by enabling various installed plugin tools.',

'registration:notemail' => 'E-postadressen du anga ser ikke ut til å være en gyldig e-postadresse.',
'registration:userexists' => 'Brukernavnet eksisterer allerede',
'registration:usernametooshort' => 'Brukernavnet må være minst 4 tegn.',
'registration:passwordtooshort' => 'Passordet må være minst 6 tegn.',
'registration:dupeemail' => 'Denne e-postadressen er allerede registrert.',
'registration:invalidchars' => 'Brukernavnet ditt inneholder ugyldige tegn.',
'registration:emailnotvalid' => 'Beklager men e-postadressen du la inn er ugyldig på dette systemet',
'registration:passwordnotvalid' => 'Beklager men passordet du la inn er ugyldig på dette systemet',
'registration:usernamenotvalid' => 'Beklager men brukernavnet du la inn er ugyldig på dette systemet',

'adduser' => "Legg til bruker",
'adduser:ok' => "Du har lagt til en bruker.",
'adduser:bad' => "Den nye brukeren kunne ikke opprettes.",

'item:object:reported_content' => "Rapporterte elementer",

'user:set:name' => "Navneinnstillinger for konto",
'user:name:label' => "Ditt navn",
'user:name:success' => "Endring av navn var vellykket.",
'user:name:fail' => "Kunne ikke endre navn. Forsikre deg om at navnet ikke er for langt, og prøv igjen.",

'user:set:password' => "Kontopassord",
'user:password:label' => "Ditt nye passord",
'user:password2:label' => "Ditt nye passord en gang til",
'user:password:success' => "Passord endret",
'user:password:fail' => "Kunne ikke endre passord.",
'user:password:fail:notsame' => "De to passordene er ikke like!",
'user:password:fail:tooshort' => "Passordet er for kort!",
'user:resetpassword:unknown_user' => 'Ugyldig bruker.',
'user:resetpassword:reset_password_confirm' => 'Tilbakestilling av passord vil sende et nytt passord til den registrerte e-postadressen din.',

'user:set:language' => "Språkinnstillinger",
'user:language:label' => "Ditt språk",
'user:language:success' => "Dine språkinnstillinger har blitt oppdatert.",
'user:language:fail' => "Dine språkinnstillinger kunne ikke lagres.",

'user:username:notfound' => 'Brukernavn %s ikke funnet.',

'user:password:lost' => 'Mistet passord',
'user:password:resetreq:success' => 'Din forespørsel om nytt passord er mottatt, e-post er sendt.',
'user:password:resetreq:fail' => 'Kunne ikke behandle forespørsel om nytt passord.',

'user:password:text' => 'For å generere et nytt passord må du skrive brukernavnet ditt nedenfor. Vi vli sende deg en adresse til en unik verifikasjonsside i e-post, å du må klikke på lenken i i e-posten. Deretter vil et nytt passord bli sendt til deg.',

'user:persistent' => 'Husk meg',
/**
 * Administration
 */

'admin:configuration:success' => "Dine innstillinger har blitt lagret.",
'admin:configuration:fail' => "Dine innstillinger kunne ikke lagres.",

'admin' => "Administrasjon",
'admin:description' => "The admin panel allows you to control all aspects of the system, from user management to how plugins behave. Choose an option below to get started.",

'admin:user' => "Brukeradministrasjon",
'admin:user:description' => "This admin panel allows you to control user settings for your site. Choose an option below to get started.",
'admin:user:adduser:label' => "Click here to add a new user...",
'admin:user:opt:linktext' => "Configure users...",
'admin:user:opt:description' => "Configure users and account information. ",

'admin:site' => "Nettstedadministrasjon",
'admin:site:description' => "This admin panel allows you to control global settings for your site. Choose an option below to get started.",
'admin:site:opt:linktext' => "Configure site...",
'admin:site:opt:description' => "Configure the site technical and non-technical settings. ",
'admin:site:access:warning' => "Changing the access setting only affects the permissions on content created in the future.",

'admin:plugins' => "Verktøyadministrasjon",
'admin:plugins:description' => "Dette administratorpanelet gir deg mlighet til å kontrollere og konfigurere vertøyene som er installert på nettstedet ditt.",
'admin:plugins:opt:linktext' => "Konfigurer verktøy...",
'admin:plugins:opt:description' => "Konfigurer verktøyene som er installert på dette nettstedet. ",
'admin:plugins:label:author' => "Opphavsperson",
'admin:plugins:label:copyright' => "Opphavsrett",
'admin:plugins:label:licence' => "Lisens",
'admin:plugins:label:website' => "URL",
'admin:plugins:label:moreinfo' => 'mer info',
'admin:plugins:label:version' => 'Versjon',
'admin:plugins:warning:elggversionunknown' => 'Warning: This plugin does not specify a compatible Elgg version.',
'admin:plugins:warning:elggtoolow' => 'Warning: This plugin requires a later version of Elgg!',
'admin:plugins:reorder:yes' => "Plugin %s was reordered successfully.",
'admin:plugins:reorder:no' => "Plugin %s could not be reordered.",
'admin:plugins:disable:yes' => "Plugin %s was disabled successfully.",
'admin:plugins:disable:no' => "Plugin %s could not be disabled.",
'admin:plugins:enable:yes' => "Plugin %s was enabled successfully.",
'admin:plugins:enable:no' => "Plugin %s could not be enabled.",

'admin:statistics' => "Statistikk",
'admin:statistics:description' => "This is an overview of statistics on your site. If you need more detailed statistics, a professional administration feature is available.",
'admin:statistics:opt:description' => "View statistical information about users and objects on your site.",
'admin:statistics:opt:linktext' => "View statistics...",
'admin:statistics:label:basic' => "Basic site statistics",
'admin:statistics:label:numentities' => "Entities on site",
'admin:statistics:label:numusers' => "Number of users",
'admin:statistics:label:numonline' => "Number of users online",
'admin:statistics:label:onlineusers' => "Users online now",
'admin:statistics:label:version' => "Elgg version",
'admin:statistics:label:version:release' => "Release",
'admin:statistics:label:version:version' => "Version",

'admin:user:label:search' => "Finn brukere:",
'admin:user:label:searchbutton' => "Søk",

'admin:user:ban:no' => "Can not ban user",
'admin:user:ban:yes' => "User banned.",
'admin:user:unban:no' => "Can not unban user",
'admin:user:unban:yes' => "User un-banned.",
'admin:user:delete:no' => "Can not delete user",
'admin:user:delete:yes' => "User deleted",

'admin:user:resetpassword:yes' => "Password reset, user notified.",
'admin:user:resetpassword:no' => "Password could not be reset.",

'admin:user:makeadmin:yes' => "User is now an admin.",
'admin:user:makeadmin:no' => "We could not make this user an admin.",

'admin:user:removeadmin:yes' => "User is no longer an admin.",
'admin:user:removeadmin:no' => "We could not remove administrator privileges from this user.",

/**
 * User settings
 */
'usersettings:description' => "The user settings panel allows you to control all your personal settings, from user management to how plugins behave. Choose an option below to get started.",

'usersettings:statistics' => "Din statistikk",
'usersettings:statistics:opt:description' => "Se statistikk om brukere og objekter på ditt nettsted.",
'usersettings:statistics:opt:linktext' => "Kontostatistikk",

'usersettings:user' => "Dine innstillinger",
'usersettings:user:opt:description' => "Dette gir deg mulighet til å styre brukerinnstillinger.",
'usersettings:user:opt:linktext' => "Endre dine innstillinger",

'usersettings:plugins' => "Verktøy",
'usersettings:plugins:opt:description' => "Konfigurer innstillinger (om noen) for dine verktøy.",
'usersettings:plugins:opt:linktext' => "Konfigurer dine verktøy",

'usersettings:plugins:description' => "Dette panelet gir deg mulighet til å kontrollere og konfigurere dine personlige innstillinger for verktøyene som er installert av administratoren.",
'usersettings:statistics:label:numentities' => "Ditt innhold",

'usersettings:statistics:yourdetails' => "Dine detaljer",
'usersettings:statistics:label:name' => "Fullt navn",
'usersettings:statistics:label:email' => "E-post",
'usersettings:statistics:label:membersince' => "Medlem siden",
'usersettings:statistics:label:lastlogin' => "Sist pålogget",



/**
 * Generic action words
 */

'save' => "Lagre",
'publish' => "Publiser",
'cancel' => "Avbryt",
'saving' => "Lagrer ...",
'update' => "Oppdater",
'edit' => "Rediger",
'delete' => "Slett",
'accept' => "Godkjenn",
'load' => "Last",
'upload' => "Last opp",
'ban' => "Blokker",
'unban' => "Opphev blokkering",
'enable' => "Aktiver",
'disable' => "Deaktiver",
'request' => "Forespørsel",
'complete' => "Komplett",
'open' => 'Åpne',
'close' => 'Lukke',
'reply' => "Svar",
'more' => 'Mer',
'comments' => 'Kommentarer',
'import' => 'Importer',
'export' => 'Eksporter',
'untitled' => 'Uten navn',
'help' => 'Hjelp',
'send' => 'Send',
'post' => 'Post',
'submit' => 'Send inn',
'site' => 'Nettsted',

'up' => 'Opp',
'down' => 'Ned',
'top' => 'Topp',
'bottom' => 'Bunn',

'invite' => "Inviter",

'resetpassword' => "Tilbakestill passord",
'makeadmin' => "Gjør til admin",
'removeadmin' => "Fjern admin",

'option:yes' => "Ja",
'option:no' => "Nei",

'unknown' => 'Ukjent',

'active' => 'Aktiv',
'total' => 'Total',

'learnmore' => "Klikk her for å lære mer.",

'content' => "innhold",
'content:latest' => 'Siste aktiviteter',
'content:latest:blurb' => 'Alternativt, klikk her for å vise siste innhold fra hele nettstedet.',

'link:text' => 'vis lenke',

'enableall' => 'Aktiver alle',
'disableall' => 'Deaktiver alle',

/**
 * Generic questions
 */

'question:areyousure' => 'Er du sikker?',

/**
 * Generic data words
 */

'title' => "Tittel",
'description' => "Beskrivelse",
'tags' => "Stikkord",
'spotlight' => "Spotlight",
'all' => "Alle",

'by' => 'av',

'annotations' => "Merknader",
'relationships' => "Relasjoner",
'metadata' => "Metadata",

/**
 * Input / output strings
 */

'deleteconfirm' => "Er du sikker på at du vil slette dette innholdet?",
'fileexists' => "En fil har allerede blitt lastet opp. For å erstatte den, velg den nedenfor:",

/**
 * User add
 */

'useradd:subject' => 'Brukerkonto opprettet',
'useradd:body' => '
%s,

A user account has been created for you at %s. To log in, visit:

%s

And log in with these user credentials:

Username: %s
Password: %s

Once you have logged in, we highly recommend that you change your password.
',

/**
 * System messages
 **/

'systemmessages:dismiss' => "klikk for å fjerne",


/**
 * Import / export
 */
'importsuccess' => "Import av data var vellykket",
'importfail' => "OpenDD-import av data mislyktes.",

/**
 * Time
 */

'friendlytime:justnow' => "akkurat nå",
'friendlytime:minutes' => "%s minutter siden",
'friendlytime:minutes:singular' => "ett minutt siden",
'friendlytime:hours' => "%s timer siden",
'friendlytime:hours:singular' => "en time siden",
'friendlytime:days' => "%s dager siden",
'friendlytime:days:singular' => "i går",
'friendlytime:date_format' => 'j F Y @ g:ia',

'date:month:01' => '%s januar',
'date:month:02' => '%s february',
'date:month:03' => '%s mars',
'date:month:04' => '%s april',
'date:month:05' => '%s mai',
'date:month:06' => '%s juni',
'date:month:07' => '%s juli',
'date:month:08' => '%s august',
'date:month:09' => '%s september',
'date:month:10' => '%s oktober',
'date:month:11' => '%s november',
'date:month:12' => '%s desember',


/**
 * Installation and system settings
 */

'installation:error:htaccess' => "Elgg requires a file called .htaccess to be set in the root directory of its installation. We tried to create it for you, but Elgg doesn't have permission to write to that directory.

Creating this is easy. Copy the contents of the textbox below into a text editor and save it as .htaccess

",
'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",

'installation:error:db:title' => "Database settings error",
'installation:error:db:text' => "Check your database settings again as Elgg could not connect and access the database.",
'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",

'installation' => "Installation",
'installation:success' => "Elgg's database was installed successfully.",
'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",

'installation:settings' => "System settings",
'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",

'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
'installation:settings:dbwizard:label:user' => "Database user",
'installation:settings:dbwizard:label:pass' => "Database password",
'installation:settings:dbwizard:label:dbname' => "Elgg database",
'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg_')",

'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",

'installation:sitename' => "The name of your site (eg \"My social networking site\"):",
'installation:sitedescription' => "Short description of your site (optional)",
'installation:wwwroot' => "The site URL, followed by a trailing slash:",
'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
'installation:sitepermissions' => "The default access permissions:",
'installation:language' => "The default language for your site:",
'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults. However, it can slow your system down so should only be used if you are having problems:",
'installation:debug:none' => 'Turn off debug mode (recommended)',
'installation:debug:error' => 'Display only critical errors',
'installation:debug:warning' => 'Display errors and warnings',
'installation:debug:notice' => 'Log all errors, warnings and notices',
'installation:httpslogin' => "Enable this to have user logins performed over HTTPS. You will need to have https enabled on your server for this to work.",
'installation:httpslogin:label' => "Enable HTTPS logins",
'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

'installation:siteemail' => "Site email address (used when sending system emails)",

'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
'installation:disableapi:label' => "Enable the RESTful API",

'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
'installation:allow_user_default_access:label' => "Allow user default access",

'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
'installation:simplecache:label' => "Use simple cache (recommended)",

'installation:viewpathcache:description' => "The view filepath cache decreases the loading times of plugins by caching the location of their views.",
'installation:viewpathcache:label' => "Use view filepath cache (recommended)",

'upgrading' => 'Upgrading...',
'upgrade:db' => 'Your database was upgraded.',
'upgrade:core' => 'Your elgg installation was upgraded.',

/**
 * Welcome
 */

'welcome' => "Velkommen",
'welcome:user' => 'Velkommen %s',
'welcome_message' => "Velkommen til denne Elgg-installasjonen.",

/**
 * Emails
 */
'email:settings' => "E-postinnstillinger",
'email:address:label' => "Din e-postadresse",

'email:save:success' => "Ny e-postadresse lagret, e-post for verifisering er sendt.",
'email:save:fail' => "Din e-postadresse kunne ikke lagres.",

'friend:newfriend:subject' => "%s har gjort deg til venn!",
'friend:newfriend:body' => "%s har gjort deg til venn!

To view their profile, click here:

%s

You cannot reply to this email.",



'email:resetpassword:subject' => "Password reset!",
'email:resetpassword:body' => "Hi %s,

Your password has been reset to: %s",


'email:resetreq:subject' => "Request for new password.",
'email:resetreq:body' => "Hi %s,

Somebody (from the IP address %s) has requested a new password for their account.

If you requested this click on the link below, otherwise ignore this email.

%s
",

/**
 * user default access
 */

'default_access:settings' => "Ditt standard tilgangsnivå",
'default_access:label' => "Standard tilgang",
'user:default_access:success' => "Ditt nye standard tilgangsnivå ble lagret.",
'user:default_access:failure' => "Ditt nye standard tilgangsnivå kunne ikke lagres.",

/**
 * XML-RPC
 */
'xmlrpc:noinputdata' => "Input-data mangler",

/**
 * Comments
 */

'comments:count' => "%s kommentarer",

'riveraction:annotation:generic_comment' => '%s kommentarer til %s',

'generic_comments:add' => "Legg til kommentar",
'generic_comments:text' => "Kommentar",
'generic_comment:posted' => "Kommentaren din ble lagret.",
'generic_comment:deleted' => "Kommentaren din ble slettet.",
'generic_comment:blank' => "Du må skrive inn noe i kommentarfeltet før du kan lagre.",
'generic_comment:notfound' => "Kunne ikke finne det du lette etter.",
'generic_comment:notdeleted' => "Kunne ikke slette kommentaren.",
'generic_comment:failure' => "En uventet feil oppstod. Vennligst prøv igjen.",

'generic_comment:email:subject' => 'Du har en ny kommentar!',
'generic_comment:email:body' => "Du har en ny kommentar til ditt innlegg \"%s\" fra %s. Kommentaren er:


%s


For å svare, klikk her:

%s

For å se %s sin profil, klikk her:

%s

Du kan ikke svare på denne e-posten.",

/**
 * Entities
 */
'entity:default:strapline' => 'Opprettet %s av %s',
'entity:default:missingsupport:popup' => 'Denne enheten kan ikke vises korrekt. Dette kan være fordi den krever støtte av et tilleggsverktøy som ikke lenger er installert.',

'entity:delete:success' => 'Enheten %s har blitt slettet',
'entity:delete:fail' => 'Enheten %s kunne ikke slettes',


/**
 * Action gatekeeper
 */
'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Vennligst prøv igjen.",
'actiongatekeeper:timeerror' => 'The page you were using has expired. Please refresh and try again.',
'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',

/**
 * Word blacklists
 * Dette er de 40 vanligste norske ordene
 */
'word:blacklist' => 'og, i, det, på, som, er, en, til, å, han, av, for, med, at, var, de, ikke, den, har, jeg, om, et, men, så, seg, hun, hadde, fra, vi, du, kan, da, ble, ut, skal, vil, ham, etter, over, ved',

/**
 * Tag labels
 */

'tag_names:tags' => 'Stikkord',

/**
 * Languages according to ISO 639-1
 */
"aa" => "Afar",
"ab" => "Abkhazian",
"af" => "Afrikaans",
"am" => "Amharic",
"ar" => "Arabic",
"as" => "Assamese",
"ay" => "Aymara",
"az" => "Azerbaijani",
"ba" => "Bashkir",
"be" => "Byelorussian",
"bg" => "Bulgarian",
"bh" => "Bihari",
"bi" => "Bislama",
"bn" => "Bengali; Bangla",
"bo" => "Tibetan",
"br" => "Breton",
"ca" => "Catalan",
"co" => "Corsican",
"cs" => "Czech",
"cy" => "Welsh",
"da" => "Danish",
"de" => "German",
"dz" => "Bhutani",
"el" => "Greek",
"en" => "English",
"eo" => "Esperanto",
"es" => "Spanish",
"et" => "Estonian",
"eu" => "Basque",
"fa" => "Persian",
"fi" => "Finnish",
"fj" => "Fiji",
"fo" => "Faeroese",
"fr" => "French",
"fy" => "Frisian",
"ga" => "Irish",
"gd" => "Scots / Gaelic",
"gl" => "Galician",
"gn" => "Guarani",
"gu" => "Gujarati",
"he" => "Hebrew",
"ha" => "Hausa",
"hi" => "Hindi",
"hr" => "Croatian",
"hu" => "Hungarian",
"hy" => "Armenian",
"ia" => "Interlingua",
"id" => "Indonesian",
"ie" => "Interlingue",
"ik" => "Inupiak",
//"in" => "Indonesian",
"is" => "Icelandic",
"it" => "Italian",
"iu" => "Inuktitut",
"iw" => "Hebrew (obsolete)",
"ja" => "Japanese",
"ji" => "Yiddish (obsolete)",
"jw" => "Javanese",
"ka" => "Georgian",
"kk" => "Kazakh",
"kl" => "Greenlandic",
"km" => "Cambodian",
"kn" => "Kannada",
"ko" => "Korean",
"ks" => "Kashmiri",
"ku" => "Kurdish",
"ky" => "Kirghiz",
"la" => "Latin",
"ln" => "Lingala",
"lo" => "Laothian",
"lt" => "Lithuanian",
"lv" => "Latvian/Lettish",
"mg" => "Malagasy",
"mi" => "Maori",
"mk" => "Macedonian",
"ml" => "Malayalam",
"mn" => "Mongolian",
"mo" => "Moldavian",
"mr" => "Marathi",
"ms" => "Malay",
"mt" => "Maltese",
"my" => "Burmese",
"na" => "Nauru",
"ne" => "Nepali",
"nl" => "Dutch",
"no" => "Norwegian",
"oc" => "Occitan",
"om" => "(Afan) Oromo",
"or" => "Oriya",
"pa" => "Punjabi",
"pl" => "Polish",
"ps" => "Pashto / Pushto",
"pt" => "Portuguese",
"qu" => "Quechua",
"rm" => "Rhaeto-Romance",
"rn" => "Kirundi",
"ro" => "Romanian",
"ru" => "Russian",
"rw" => "Kinyarwanda",
"sa" => "Sanskrit",
"sd" => "Sindhi",
"sg" => "Sangro",
"sh" => "Serbo-Croatian",
"si" => "Singhalese",
"sk" => "Slovak",
"sl" => "Slovenian",
"sm" => "Samoan",
"sn" => "Shona",
"so" => "Somali",
"sq" => "Albanian",
"sr" => "Serbian",
"ss" => "Siswati",
"st" => "Sesotho",
"su" => "Sundanese",
"sv" => "Swedish",
"sw" => "Swahili",
"ta" => "Tamil",
"te" => "Tegulu",
"tg" => "Tajik",
"th" => "Thai",
"ti" => "Tigrinya",
"tk" => "Turkmen",
"tl" => "Tagalog",
"tn" => "Setswana",
"to" => "Tonga",
"tr" => "Turkish",
"ts" => "Tsonga",
"tt" => "Tatar",
"tw" => "Twi",
"ug" => "Uigur",
"uk" => "Ukrainian",
"ur" => "Urdu",
"uz" => "Uzbek",
"vi" => "Vietnamese",
"vo" => "Volapuk",
"wo" => "Wolof",
"xh" => "Xhosa",
//"y" => "Yiddish",
"yi" => "Yiddish",
"yo" => "Yoruba",
"za" => "Zuang",
"zh" => "Chinese",
"zu" => "Zulu",
);

add_translation("no",$norwegian);
