<?php
/**
 * Likes plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(
			'likes:admin' => 'Like Settings',
			'likes:admin:subtitle' => 'Do you like show the "like this" button for...',
	
			'like:autodetect_items' => 'Autodetect river items to extend?',
			'like:enable_ajaxsupport' => 'Enable Ajax Support (Disable if you have something problem)',
			'like:allowdislike' => 'Would you like to enable the "dislike" functionality?',
			'like:show:thewire' => 'the wire on the river?',
			'like:show:messageboard' => 'messageboard on the river?',
			'like:show:bookmarks' => 'bookmarks on the river?',
			'like:show:blog' => 'blog on the river?',
			'like:show:file' => 'file on the river?',
			'like:show:page' => 'page on the river?',
			'like:show:topic' => 'discussion topic on the river?',

/*
 * Third party mods Like
 */
			'like:show:tidypics_image'  => 'tidypics image on the river?',
			'like:show:tidypics_album'  => 'tidypics album on the river?',
			'like:show:izap_videos'  => 'izap videos on the river?',
			'like:show:event_calendar'  => 'event calendar page on the river?',
	
			'like' => 'Liker',
			'unlike' => 'Liker ikke',
/*Like*/
			'like:youlikethis' => 'Du liker dette.',
			'like:otherlikesthis' => '%s liker dette.',

			'like:otherandyoulikethis' => 'Du og %s liker dette.',
			'like:others2likethis' => '%s og %s liker dette.',

			'like:others' => '%s others',

			'like:lotofpeoplelikethis' => '%s medlemmer liker dette.',
			'like:youandalotofpeoplelikethis' => 'Du og %s liker dette.',

/*DisLike*/
			'dislike' => 'Dislike',
			'undislike' => 'Undislike',

			'dislike:youdislikethis' => 'You dislike this.',
			'dislike:otherdislikesthis' => '%s dislikes this.',

			'dislike:otherandyoudislikethis' => 'You and %s dislike this.',
			'dislike:others2dislikethis' => '%s and %s dislike this.',

			'dislike:others' => '%s others',

			'dislike:lotofpeopledislikethis' => '%s people dislike this.',
			'dislike:youandalotofpeopledislikethis' => 'You and %s dislike this.',

			'dislike:posted' => 'Your "dislike" was successfully posted.',
			'dislike:failure' => 'An unexpected error occurred when adding your "dislike". Please try again.',

			'dislike:deleted' => 'Your "dislike" was successfully deleted.',
			'dislike:notdeleted' => 'Sorry, we could not delete this "dislike".',

/*Actions*/
			'like:posted' => 'Your "like" was successfully posted.',
			'like:failure' => 'An unexpected error occurred when adding your "like". Please try again.',

			'like:deleted' => 'Your "like" was successfully deleted.',
			'like:notdeleted' => 'Sorry, we could not delete this "like".',
);
	
add_translation("no",$norwegian);
?>