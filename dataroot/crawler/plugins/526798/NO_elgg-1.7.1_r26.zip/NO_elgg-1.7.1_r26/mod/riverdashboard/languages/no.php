<?php
/**
 * Elgg riverdashboard plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(

'mine' => 'Mine',
'filter' => 'Filter',
'riverdashboard:useasdashboard' => "Erstatt standard hjem-side med denne aktivitetsstrømmen?",
'activity' => 'Activity',
'riverdashboard:recentmembers' => 'Nye medlemmer',
/**
 * Site messages
 **/

'sitemessages:announcements' => "Kunngjøringer",
'sitemessages:posted' => "Lagt inn",
'sitemessages:river:created' => "Nettstedadmin, %s,",
'sitemessages:river:create' => "la inn en ny kunngjøring",
'sitemessages:add' => "Legg til en kunngjøring på aktivitetsstrømsiden",
'sitemessage:deleted' => "Kunngjøring slettet",
'sitemessage:error' => "Kunne ikke lagre kunngjøring.",
'river:widget:noactivity' => 'Vi kunne ikke finne noen aktiviteter.',
'river:widget:title' => "Aktivitet",
'river:widget:description' => "Vis dine siste aktiviteter.",
'river:widget:title:friends' => "Venners' aktiviteter",
'river:widget:description:friends' => "Vis hva vennene dine holder på med.",
'river:widgets:friends' => "Venner",
'river:widgets:mine' => "Mine",
'river:widget:label:displaynum' => "Antall innlegg som skal vises:",
'river:widget:type' => "Hvilken strøm vil du vise? En som viser dine aktiviteter eller en som viser dine venners aktiviteter?",
'item:object:sitemessage' => "Kunngjøringer",
'riverdashboard:avataricon' => "Vil du vise profilbilder eller ikoner i aktivitetsstrømmen til nettstedet?",
'option:icon' => 'Ikoner',
'option:avatar' => 'Profilbilder',
);
add_translation("no",$norwegian);

?>
