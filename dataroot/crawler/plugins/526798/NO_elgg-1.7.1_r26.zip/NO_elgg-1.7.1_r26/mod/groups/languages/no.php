<?php
/**
* Elgg groups plugin language pack
*
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author bitjungle
* @copyright bitjungle 
* @link http://bitjungle.com/
*/

$norwegian = array(

/**
* Menu items and titles
*/

'groups' => "Grupper",
'groups:owned' => "Grupper du eier",
'groups:yours' => "Dine grupper",
'groups:user' => "%s sine grupper",
'groups:all' => "Alle grupper på nettstedet",
'groups:new' => "Opprett en ny gruppe",
'groups:edit' => "Rediger gruppe",
'groups:delete' => 'Slett gruppe',
'groups:membershiprequests' => 'Håndter forespørsler om medlemskap',
'groups:invitations' => 'Gruppeinvitasjoner',

'groups:icon' => 'Gruppeikon (la den være tom om du ikke vil endre)',
'groups:name' => 'Gruppenavn',
'groups:username' => 'Kortnavn for gruppe (vises i URL-er, kun alfanumeriske tegn)',
'groups:description' => 'Beskrivelse',
'groups:briefdescription' => 'Kort beskrivelse',
'groups:interests' => 'Stikkord',
'groups:website' => 'Nettsted',
'groups:members' => 'Gruppemedlemmer',
'groups:membership' => "Tillatelser for gruppemedlemskap",
'groups:access' => "Adgangskontroll",
'groups:owner' => "Eier",
'groups:widget:num_display' => 'Antall grupper som skal vises',
'groups:widget:membership' => 'Gruppemeldemskap',
'groups:widgets:description' => 'Vis gruppene du er medlem av i din profil',
'groups:noaccess' => 'Ingen tilgang til gruppe',
'groups:cantedit' => 'Du kan ikke endre denne gruppa',
'groups:saved' => 'Gruppe lagret',
'groups:featured' => 'Anbefalte grupper',
'groups:makeunfeatured' => 'Fjern anbefaling',
'groups:makefeatured' => 'Gjør anbefalt',
'groups:featuredon' => 'Du har gjort denne gruppa til anbefalt gruppe.',
'groups:unfeature' => 'Du har fjernet denne gruppa fra anbefalte grupper',
'groups:joinrequest' => 'Be om medlemskap',
'groups:join' => 'Bli medlem av gruppe',
'groups:leave' => 'Avslutt medlemskap i gruppe',
'groups:invite' => 'Inviter venner',
'groups:inviteto' => "Inviter venner til '%s'",
'groups:nofriends' => "Du har ingen venner igjen som ikke har blitt invitert til denne gruppa.",
'groups:viagroups' => "via grupper",
'groups:group' => "Gruppe",
'groups:search:tags' => "stikkord",

'groups:notfound' => "Gruppe ikke funnet",
'groups:notfound:details' => "Den forespurte gruppa eksisterer ikke, eller du har ikke tilgang til den",

'groups:requests:none' => 'Det er ingen utestående forespørsler om medlemskap.',

'groups:invitations:none' => 'Det er ingen utestående invitasjoner nå.',

'item:object:groupforumtopic' => "Diskusjonstemaer",

'groupforumtopic:new' => "Nytt diskusjonsinnlegg",

'groups:count' => "grupper opprettet",
'groups:open' => "åpen gruppe",
'groups:closed' => "lukket gruppe",
'groups:member' => "medlemmer",
'groups:searchtag' => "Søk etter gruppe med stikkord",


/*
* Access
*/
'groups:access:private' => 'Lukket - Brukere må få invitasjon',
'groups:access:public' => 'Åpen - Alle brukere kan bli medlemmer',
'groups:closedgroup' => 'Denne gruppa har lukket medlemskap. For å bli medlem må du bruke lenken "Be om medlemskap".',
'groups:visibility' => 'Hvem kan se denne gruppa?',

/*
Group tools
*/
'groups:enablepages' => 'Aktiver gruppesider',
'groups:enableforum' => 'Aktiver gruppediskusjon',
'groups:enablefiles' => 'Aktiver gruppefiler',
'groups:yes' => 'ja',
'groups:no' => 'nei',

'group:created' => 'Opprettet %s med %d innlegg',
'groups:lastupdated' => 'Sist oppdatert %s av %s',
'groups:pages' => 'Gruppesider',
'groups:files' => 'Gruppefiler',

/*
Group forum strings
*/

'group:replies' => 'Svar',
'groups:forum' => 'Gruppediskusjoner',
'groups:addtopic' => 'Legg til et tema',
'groups:forumlatest' => 'Siste diskusjon',
'groups:latestdiscussion' => 'Siste diskusjon',
'groups:newest' => 'Nyeste',
'groups:popular' => 'Populær',
'groupspost:success' => 'Din kommentar ble lagt inn',
'groups:alldiscussion' => 'Siste diskusjon',
'groups:edittopic' => 'Rediger tema',
'groups:topicmessage' => 'Temamelding',
'groups:topicstatus' => 'Temastatus',
'groups:reply' => 'Legg til kommentar',
'groups:topic' => 'Tema',
'groups:posts' => 'Innlegg',
'groups:lastperson' => 'Siste person',
'groups:when' => 'Når',
'grouptopic:notcreated' => 'Ingen temaer har blitt opprettet.',
'groups:topicopen' => 'Åpen',
'groups:topicclosed' => 'Lukket',
'groups:topicresolved' => 'Løst',
'grouptopic:created' => 'Ditt tema ble opprettet.',
'groupstopic:deleted' => 'Temaet ble slettet.',
'groups:topicsticky' => 'Sticky',
'groups:topicisclosed' => 'This topic is closed.',
'groups:topiccloseddesc' => 'This topic has now been closed and is not accepting new comments.',
'grouptopic:error' => 'Your group topic could not be created. Please try again or contact a system administrator.',
'groups:forumpost:edited' => "You have successfully edited the forum post.",
'groups:forumpost:error' => "There was a problem editing the forum post.",
'groups:privategroup' => 'This group is private, requesting membership.',
'groups:notitle' => 'Groups must have a title',
'groups:cantjoin' => 'Can not join group',
'groups:cantleave' => 'Could not leave group',
'groups:addedtogroup' => 'Successfully added the user to the group',
'groups:joinrequestnotmade' => 'Could not request to join group',
'groups:joinrequestmade' => 'Requested to join group',
'groups:joined' => 'Successfully joined group!',
'groups:left' => 'Successfully left group',
'groups:notowner' => 'Sorry, you are not the owner of this group.',
'groups:notmember' => 'Sorry, you are not a member of this group.',
'groups:alreadymember' => 'You are already a member of this group!',
'groups:userinvited' => 'User has been invited.',
'groups:usernotinvited' => 'User could not be invited.',
'groups:useralreadyinvited' => 'User has already been invited',
'groups:updated' => "Last comment",
'groups:invite:subject' => "%s you have been invited to join %s!",
'groups:started' => "Started by",
'groups:joinrequest:remove:check' => 'Are you sure you want to remove this join request?',
'groups:invite:remove:check' => 'Are you sure you want to remove this invite?',
'groups:invite:body' => "Hi %s,

%s invited you to join the '%s' group. Click below to view your invitations:

%s",

'groups:welcome:subject' => "Velkommen til gruppa %s!",
'groups:welcome:body' => "Hei %s!

You are now a member of the '%s' group! Click below to begin posting!

%s",

'groups:request:subject' => "%s has requested to join %s",
'groups:request:body' => "Hi %s,

%s has requested to join the '%s' group. Click below to view their profile:

%s

or click below to view the group's join requests:

%s",

/*
Forum river items
*/

'groups:river:member' => 'er nå medlem av',
'groupforum:river:updated' => '%s har oppdatert',
'groupforum:river:update' => 'dette diskusjonstemaet',
'groupforum:river:created' => '%s har opprettet',
'groupforum:river:create' => 'et nytt diskusjonstema med tittelen',
'groupforum:river:posted' => '%s har lagt inn en ny kommentar',
'groupforum:river:annotate:create' => 'på dette diskusjonstemaet',
'groupforum:river:postedtopic' => '%s har startet et nytt diskusjonstema med tittelen',
'groups:river:member' => '%s er nå medlem av',
'groups:river:togroup' => 'til gruppa',

'groups:nowidgets' => 'Ingen innstikk har blitt definert for denne gruppa..',


'groups:widgets:members:title' => 'Gruppemedlemmer',
'groups:widgets:members:description' => 'List opp medlemmer av en gruppe.',
'groups:widgets:members:label:displaynum' => 'List medlemmer av gruppe.',
'groups:widgets:members:label:pleaseedit' => 'Vennligst konfigurer dette innstikket.',

'groups:widgets:entities:title' => "Objects in group",
'groups:widgets:entities:description' => "List the objects saved in this group",
'groups:widgets:entities:label:displaynum' => 'List the objects of a group.',
'groups:widgets:entities:label:pleaseedit' => 'Please configure this widget.',

'groups:forumtopic:edited' => 'Forum topic successfully edited.',

'groups:allowhiddengroups' => 'Do you want to allow private (invisible) groups?',

/**
* Action messages
*/
'group:deleted' => 'Group and group contents deleted',
'group:notdeleted' => 'Group could not be deleted',

'grouppost:deleted' => 'Group posting successfully deleted',
'grouppost:notdeleted' => 'Group posting could not be deleted',
'groupstopic:deleted' => 'Topic deleted',
'groupstopic:notdeleted' => 'Topic not deleted',
'grouptopic:blank' => 'No topic',
'grouptopic:notfound' => 'Could not find the topic',
'grouppost:nopost' => 'Empty post',
'groups:deletewarning' => "Are you sure you want to delete this group? There is no undo!",

'groups:invitekilled' => 'The invite has been deleted.',
'groups:joinrequestkilled' => 'The join request has been deleted.',
);

add_translation("no",$norwegian);
?>

