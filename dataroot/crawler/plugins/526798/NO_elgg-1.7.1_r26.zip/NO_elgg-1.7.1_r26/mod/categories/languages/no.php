<?php
/**
 * Elgg categories plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(
'categories' => 'Kategorier',
'categories:settings' => 'Sett kategorier for nettsted',
'categories:explanation' => 'For å sette noen forhåndsdefinerte kategorier for hele nettstedet, skriv dem inn som en kommaseparert liste nedenfor. Kompatible verktøy vil vise dem når brukere oppretter eller endrer innhold.',
'categories:save:success' => 'Kategorier for nettsted ble lagret.',
'categories:results' => "Resultat for kategori: %s",
);
add_translation("no",$norwegian);

?>