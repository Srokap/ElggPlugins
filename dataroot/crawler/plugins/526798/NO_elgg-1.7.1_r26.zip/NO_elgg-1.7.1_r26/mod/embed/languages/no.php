<?php
/**
 * Elgg embed plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(
'media:insert' => 'Sett inn / last opp media',
'embed:instructions' => 'Klikk på fila du vil sette inn.',
'embed:media' => 'Sett inn media',
'upload:media' => 'Last opp media',
'embed:file:required' => 'No file upload facilities were found. The system administrator may need to upload the file plugin or similar.',
);
add_translation("no",$norwegian);

?>