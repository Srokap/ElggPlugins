<?php
/**
* Elgg friends plugin language pack
* 
* @package ElggFriends
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author bitjungle
* @copyright bitjungle 2010
* @link http://bitjungle.com/
*/

$norwegian = array(
/**
* Friends widget
*/
'friends:widget:description' => "Viser noen av dine venner.",
       
);
add_translation("no",$norwegian);

?>
