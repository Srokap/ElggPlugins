<?php
/**
 * Elgg reported content plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(
/**
 * Menu items and titles
 */
'item:object:reported_content' => 'Rapportert innhold',
'reportedcontent' => 'Rapportert innhold',
'reportedcontent:this' => 'Rapporter dette',
'reportedcontent:none' => 'Det er ikke noe rapportert innhold',
'reportedcontent:report' => 'Rapporter til admin',
'reportedcontent:title' => 'Sidetittel',
'reportedcontent:deleted' => 'Det rapporterte innholdet ble slettet',
'reportedcontent:notdeleted' => 'We were not able to delete that report',
'reportedcontent:delete' => 'Slett den',
'reportedcontent:areyousure' => 'Er du sikker på at du vil slette?',
'reportedcontent:archive' => 'Arkiver den',
'reportedcontent:archived' => 'The report has been archived',
'reportedcontent:visit' => 'Visit reported item',
'reportedcontent:by' => 'Rapportert av',
'reportedcontent:objecttitle' => 'Objekt tittel',
'reportedcontent:objecturl' => 'Objekt url',
'reportedcontent:reason' => 'Årsak til rapporten',
'reportedcontent:description' => 'Hvorfor rapporterer du denne?',
'reportedcontent:address' => 'Location of the item',
'reportedcontent:success' => 'Din rapport har blitt sendt til nettstedadministratoren',
'reportedcontent:failing' => 'Din rapport kunne ikke sendes',
'reportedcontent:report' => 'Rapporter dette', 
'reportedcontent:moreinfo' => 'Mer info',
'reportedcontent:failed' => 'Beklager, fosøket på å rapportere dette innholdet gikk galt.',
'reportedcontent:notarchived' => 'We were not able to archive that report',
);
add_translation("no",$norwegian);
?>

