<?php
/**
 * Elgg blog plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(
/**
 * Menu items and titles
 */
'blog' => "Blogg",
'blogs' => "Blogger",
'blog:user' => "%s sin blogg",
'blog:user:friends' => "%s sine venners blogger",
'blog:your' => "Din blogg",
'blog:posttitle' => "%s sin blogg: %s",
'blog:friends' => "Venners blogger",
'blog:yourfriends' => "Dine venners siste blogginnlegg",
'blog:everyone' => "Alle blogger",
'blog:newpost' => "Nytt blogginnlegg",
'blog:via' => "via blogg",
'blog:read' => "Les blogg",
'blog:addpost' => "Skriv et blogginnlegg",
'blog:editpost' => "Rediger blogginnlegg",
'blog:text' => "Bloggtekst",
'blog:strapline' => "%s",
'item:object:blog' => 'Blogginnlegg',
'blog:never' => 'aldri',
'blog:preview' => 'Forhåndsvis',
'blog:draft:save' => 'Lagre kladd',
'blog:draft:saved' => 'Kladd sist lagret',
'blog:comments:allow' => 'Tillat kommentarer',
'blog:preview:description' => 'Dette er en forhåndsvisning av ditt blogginnlegg som ikke er lagret.',
'blog:preview:description:link' => 'For å fortsette redigering eller lagring av ditt blogginnlegg, klikk her.',
'blog:enableblog' => 'Aktiver gruppeblogg',
'blog:group' => 'Gruppeblogg',

/**
 * Blog widget
 */
'blog:widget:description' => 'This widget displays your latest blog entries.',
'blog:moreblogs' => 'Flere blogginnlegg',
'blog:numbertodisplay' => 'Antall blogginnlegg som skal vises',
/**
 * Blog river
 **/
 
//generic terms to use
       'blog:river:created' => "%s skrev",
       'blog:river:updated' => "%s oppdaterte",
       'blog:river:posted' => "%s publiserte",
 
//these get inserted into the river links to take the user to the entity
       'blog:river:create' => "et nytt blogginnlegg med tittelen",
       'blog:river:update' => "et blogginnlegg med tittelen",
       'blog:river:annotate' => "en kommentar til dette blogginnlegget",
/**
 * Status messages
 */
'blog:posted' => "Ditt blogginnlegg ble lagt inn.",
'blog:deleted' => "Ditt blogginnlegg ble slettet.",
/**
 * Error messages
 */
'blog:error' => 'Noe gikk galt. Vennligst prøv igjen.',
'blog:save:failure' => "Ditt blogginnlegg kunne ikke publiseres. Vennligst prøv igjen.",
'blog:blank' => "Beklager, men du må fylle ut både tittel og bloggtekst før du kan publisere.",
'blog:notfound' => "Sorry; we could not find the specified blog post.",
'blog:notdeleted' => "Sorry; we could not delete this blog post.",
);
add_translation("no",$norwegian);

?>