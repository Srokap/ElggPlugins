<?php
/**
 * Elgg custom_index plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(
'custom:bookmarks' => "Nyeste bokmerker",
'custom:groups' => "Nyeste grupper",
'custom:files' => "Nyeste filer",
'custom:blogs' => "Nyeste blogginnlegg",
'custom:members' => "Nyeste medlemmer",
'custom:nofiles' => "Det er ingen filer ennå",
'custom:nogroups' => "Det er ingen grupper ennå",
);
add_translation("no",$norwegian);

?>