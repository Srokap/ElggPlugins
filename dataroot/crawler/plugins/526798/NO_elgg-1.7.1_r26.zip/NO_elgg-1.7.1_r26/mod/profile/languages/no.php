<?php
/**
 * Elgg profile plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(

/**
 * Profile
 */

'profile' => "Profil",
'profile:edit:default' => 'Erstatt profilfelter',
'profile:preview' => 'Forhåndsvisning',

/**
 * Profile menu items and titles
 */

'profile:yours' => "Din profil",
'profile:user' => "%s sin profil",

'profile:edit' => "Rediger profil",
'profile:profilepictureinstructions' => "Profilbildet er bildet som vises på din profilside. <br /> Du kan endre det så ofte du vil. (Filformater som aksepteres: GIF, JPG or PNG)",
'profile:icon' => "Profilbilde",
'profile:createicon' => "Lag ditt ikon",
'profile:currentavatar' => "Nåværende ikon",
'profile:createicon:header' => "Profilbilde",
'profile:profilepicturecroppingtool' => "Profilbilde beskjæringsverktøy",
'profile:createicon:instructions' => "Klikk og dra en kvadrat nedenfor for å angi hvordan du vil ha bildet ditt beskjært. En forhåndsvisning av det beskjærte bildet vil vises i boksen til høyre. Når du er fornøyd med forhåndsvisningen klikker du 'Lag ditt ikon'. Det beskjærte bildet vil brukes på hele nettstadet som ditt ikon. ",

'profile:editdetails' => "Rediger detaljer",
'profile:editicon' => "Rediger ditt profilbilde",

'profile:aboutme' => "Om meg",
'profile:description' => "Om meg",
'profile:briefdescription' => "Kort beskrivelse",
'profile:location' => "Bosted",
'profile:skills' => "Ferdigheter",
'profile:interests' => "interesser",
'profile:contactemail' => "E-post",
'profile:phone' => "Telefon",
'profile:mobile' => "Mobil",
'profile:website' => "Nettsted",

'profile:banned' => 'Denne brukerkontoen har blitt deaktivert.',
'profile:deleteduser' => 'Slettet bruker',

'profile:river:update' => "%s oppdaterte profilen sin",
'profile:river:iconupdate' => "%s oppdaterte profilikonet sitt",

'profile:label' => "Profiletikett",
'profile:type' => "Profiltype",

'profile:editdefault:fail' => 'Default profile could not be saved',
'profile:editdefault:success' => 'Item successfully added to default profile',


'profile:editdefault:delete:fail' => 'Removed default profile item field failed',
'profile:editdefault:delete:success' => 'Default profile item deleted!',

'profile:defaultprofile:reset' => 'Default system profile reset',

'profile:resetdefault' => 'Reset default profile',
'profile:explainchangefields' => 'You can replace the existing profile fields with your own using the form below. First you give the new profile field a label, for example, \'Favourite team\'. Next you need to select the field type, for example, tags, url, text and so on. At any time you can revert back to the default profile set up.',


/**
 * Profile status messages
 */

'profile:saved' => "Your profile was successfully saved.",
'profile:icon:uploaded' => "Your profile picture was successfully uploaded.",

/**
 * Profile error messages
 */

'profile:noaccess' => "You do not have permission to edit this profile.",
'profile:notfound' => "Sorry, we could not find the specified profile.",
'profile:icon:notfound' => "Sorry, there was a problem uploading your profile picture.",
'profile:icon:noaccess' => 'You cannot change this profile icon',
'profile:field_too_long' => 'Cannot save your profile information because the "%s" section is too long.',

);

add_translation("no",$norwegian);
