<?php
/**
 * Elgg twitter service plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

	$norwegian = array(
		'twitterservice' => 'Twitter-tjeneste',
		'twitterservice:postwire' => 'Ved å aktivere følgende innstilling vil alle meldinger du legger inn på veggen også bli sendt til din twitter-konto. Vil du at alle meldinger på veggen skal sendes til twitter?',
		'twitterservice:twittername' => 'Twitter brukernavn',
		'twitterservice:twitterpass' => 'Twitter passord',
	);
					
	add_translation("no",$norwegian);
?>