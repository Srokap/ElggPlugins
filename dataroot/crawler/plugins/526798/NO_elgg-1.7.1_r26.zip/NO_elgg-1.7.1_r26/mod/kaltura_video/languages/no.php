<?php
/**
* Kaltura video client plugin language pack
* @license http://www.gnu.org/licenses/gpl.html GNU Public License version 3
* @author bitjungle
* @copyright bitjungle 2010
* @link http://bitjungle.com/
**/

$norwegian = array(
'kalturavideo:label:partner_id' => "Partner-ID",
'kalturavideo:error:misconfigured' => "Feilkonfigurert utvidelse eller autorisasjonsfeil med Kaltura!",
'kalturavideo:error:notconfigured' => "Utvidelsen er ikke konfigurert!",
'kalturavideo:error:missingks' => 'Du har antakelig gjort en feil i konfigurasjonen av "Administrator Secret" eller "Web Service Secret".',
'kalturavideo:error:partnerid' => "This error normaly appears if you are not a partner of Kaltura. Please read the README file and configure this plugin!",
'kalturavideo:error:readme' => "Please read the README file and configure this plugin!",
'kalturavideo:label:closewindow' => "Lukk vindu",
'kalturavideo:label:select_size' => "Velg størrelse på avspiller",
'kalturavideo:label:large' => "Stor",
'kalturavideo:label:small' => "Liten",
'kalturavideo:label:insert' => "Sett inn video",
'kalturavideo:label:edit' => "Rediger video",
'kalturavideo:label:edittitle' => "rediger videotittel",
'kalturavideo:label:miniinsert' => "Sett inn",
'kalturavideo:label:miniedit' => "Rediger",
'kalturavideo:label:cancel' => "Avbryt",
'kalturavideo:label:gallery' => "Galleri",
'kalturavideo:label:next' => "Neste",
'kalturavideo:label:prev' => "Forrige",
'kalturavideo:label:start' => "Start",
'kalturavideo:label:newvideo' => "Lag en ny video",
'kalturavideo:label:gotoconfig' => "Please configure properly the Kaltura Video Plugin under ",

//title of the menu, put whatever you want, for example 'Kaltura videos'
'kalturavideo:label:adminvideos' => "Video",
'kalturavideo:label:myvideos' => "Mine videoer",
'kalturavideo:label:length' => "Lengde:",
'kalturavideo:label:plays' => "Avspillinger:",
'kalturavideo:label:created' => "Opprettet:",
'kalturavideo:label:details' => "Vis detaljer",
'kalturavideo:label:view' => "Vis video",
'kalturavideo:label:delete' => "Slett video",
'kalturavideo:prompt:delete' => "Er dus ikker på at du vil slette denne videoen permanent?",
'kalturavideo:action:deleteok' => "Videoen med id %ID% ble slettet.",
'kalturavideo:action:deleteko' => "Videoen med id %ID% kan ikke slettes!",
'kalturavideo:action:updatedok' => "Videoen med id %ID% ble oppdatert.",
'kalturavideo:action:updatedko' => "Videoen med id %ID% kan ikke oppdateres!",
'kalturavideo:label:thumbnail' => "Ikon url:",
'kalturavideo:label:sharel' => "HTML delingskode (stor applet):",
'kalturavideo:label:sharem' => "HTML delingskode (liten applet):",
'kalturavideo:text:statusnotchanged' => "Personvernstatusen for videoen %1% kan ikke endres!",
'kalturavideo:text:novideos' => "Beklager, men du har ingen videoer ennå!",
'kalturavideo:text:nopublicvideos' => "Beklager, det er ingen offentlige videoer ennå!",
'kalturavideo:label:author' => "Opphavsperson:",
'kalturavideo:text:nofriendsvideos' => "Dine venner har ingen videoer ennå",
'kalturavideo:text:nouservideos' => "Denne brukeren har ingen videoer ennå",
'kalturavideo:label:showvideo' => "Vis videoen",
'kalturavideo:show:advoptions' => "Vis deling",
'kalturavideo:hide:advoptions' => "Skjul deling",

'kalturavideo:text:widgetdesc' => "This widget allows you to show automatically your latest public video from Kaltura video plugins.",
'kalturavideo:error:edittitle' => "Error! This title can not be changed!",
'kalturavideo:error:objectnotavailable' => "Object not available. Please reload the page.",
'kalturavideo:label:recreateobjects' => "Gjenopprett alle video-objekter",
'kalturavideo:edit:notallowed' => "Du kan ikke redigere denne videoen!",
'kalturavideo:river:created' => "%s opprettet",
'kalturavideo:river:annotate' => "%s kommenterte på",
'kalturavideo:river:item' => "en video",
'kalturavideo:river:shared' => "Video",
'kalturavideo:label:videosfrom' => "Videoer av %s",
'kalturavideo:user:showallvideos' => "Vis alle videoer fra denne brukeren",
'kalturavideo:strapline' => "%s",

/**
     * kaltura_video rating system
**/
'kalturavideo:rating' => "Vurdering",
'kalturavideo:yourrate' => "Din vurdering:",
'kalturavideo:rate' => "Stem!",
'kalturavideo:votes' => "stemmer",
'kalturavideo:ratesucces' => "Din vurdering har blitt lagret.",
'kalturavideo:rateempty' => "Vennligst velg en verdi før du stemmer!",
'kalturavideo:notrated' => "Du har allerede vurdert denne!",

/**
* Groups
**/
'kalturavideo:groupprofile' => "Samarbeidsvideoer",
'kalturavideo:text:nogroupvideos' => "Denne gruppa har ingen videoer ennå",
'kalturavideo:label:collaborative' => "Samarbeid",
'kalturavideo:text:collaborative' => "Dette gjør det mulig for andre medlemmer av gruppa å redigere denne videoen!",
'kalturavideo:text:collaborativechanged' => "Samarbeidsstatus for videoen %1% ble endret!",
'kalturavideo:text:collaborativenotchanged' => "Samarbeidsstatus for videoen %1% kan ikke endres!",
'kalturavideo:text:iscollaborative' => "Dette er en samarbeidsvideo, du kan redigere den!",
'kalturavideo:userprofile' => "Samarbeidsvideoer",

//New after version 1.0

//default title for a new created video, you can put 'New video' for example
'kalturavideo:title:video' => "New Collaborative Video",
//elgg notification
'kalturavideo:newvideo' => "Ny samarbeidsvideo",

'kalturavideo:label:friendsvideos' => "Videoer laget av venner",
'kalturavideo:label:allgroupvideos' => "Videoer fra grupper",
'kalturavideo:label:allvideos' => "Alle videoer på nettstedet",
'kalturavideo:clickifpartner' => "Click here if you already have a Partner ID",
'kalturavideo:clickifnewpartner' => "Click here if you don't have a Partner ID",
'kalturavideo:notpartner' => "Not a Kaltura user?",
'kalturavideo:forgotpassword' => "forgot password?",
'kalturavideo:enterkmcdata' => "Please enter your Kaltura Management Console (KMC) Email & password",
'kalturavideo:label:sitename' => "Elgg Site Name",
'kalturavideo:label:name' => "Enter Name",
'kalturavideo:label:email' => "Enter Email",
'kalturavideo:label:websiteurl' => "Website URL",
'kalturavideo:label:description' => "Description",
'kalturavideo:label:phonenumber' => "Phone Number",
'kalturavideo:label:contenttype' => "Content Type",
'kalturavideo:label:adultcontent' => "Do you plan to display adult content?",
'kalturavideo:label:iagree' => "I Accept %s",
'kalturavideo:label:termsofuse' => "Terms of Use",
'kalturavideo:wizard:description' => "Please describe how you plan to use Kaltura's video platform",
'kalturavideo:wizard:phonenumber' => "Enter phone number for contact",
'kalturavideo:mustaggreeterms' => "You must agree to the Kaltura Terms of Use",
'kalturavideo:mustenterfields' => "You must fill all fields!",
'kalturavideo:registeredok' => "Kaltura server are contacted and registered successfully!",
'kalturavideo:error:noid' => "The object requested is not available!",
'kalturavideo:logintokaltura' => "%s to the Kaltura Management Console (KMC) for advanced media management",
'kalturavideo:login' => "Login",
'kalturavideo:text:nogroupsvideos' => "Sorry, there are not videos from groups yet!",
'kalturavideo:label:defaultplayer' => "Default video player",
'kalturavideo:editpassword' => "Click here to change this data",
'kalturavideo:text:recreateobjects' => "Try to do this if you are upgrading the Kaltura plugin from any older version prior 1.0 or some videos are deleted outside this Elgg installation.
All Elgg video objects will be checked and recreated, this can be a slow process.

Note that the metadata stored in Kaltura servers will be updated in order to match the Elgg data.
Objects not created by the Kaltura Elgg Plugin will not be touched.",
'kalturavideo:text:statuschanged' => 'Access status for the video %2% changed to "%1%"',
'kalturavideo:howtoimportkaltura' => 'You can import any video from Kaltura CMS created outside Elgg, to do that login into your Kaltura CMS acount (%URLCMS%) and put the admin tags to "<b>%TAG%</b> <em>elgg_username_to_import</em>". Then run "Recreate all video objects" again.',
'kalturavideo:num_display' => "Number of videos to display",
'kalturavideo:start_display' => "Start with the video number",
'kalturavideo:label:addvideo' => "Sett inn en video",
'kalturavideo:label:addbuttonlongtext' => "Append the button %s to textareas",
'kalturavideo:option:simple' => "Simple (a button on top of the textareas)",
'kalturavideo:option:tinymce' => "Try to integrate into tinyMCE",
'kalturavideo:note:addbuttonlongtext' => "If you choose to add this button, then users can put &lt;object&gt; html tags into text boxes. Even if htmlawed is enabled.",
'kalturavideo:enablevideo' => "Enable collaborative videos for this group",
'kalturavideo:label:groupvideos' => "Gruppevideoer",
'kalturavideo:user' => "%s sine videoer",
'kalturavideo:user:friends' => "%s sine venners videoer",
'kalturavideo:notfound' => "Sorry; we could not find the specified video post. ",
'kalturavideo:posttitle' => "%s sin video: %s",
'kalturavideo:label:editdetails' => "Rediger tittel &amp; beskrivelse",
'ingroup' => "i gruppa",

//new from 10-12-2009
'item:object:kaltura_video' => "Samarbeidsvideoer",
'kalturavideo:thumbnail' => "Miniatyrbilde",
'kalturavideo:comments:allow' => "Tillat kommentarer",
'kalturavideo:rating:allow' => "Tillat vurdering",
//these get inserted into the river links to take the user to the entity
'kalturavideo:river:updated' => "%s oppdaterte",
'kalturavideo:river:create' => "en ny video med tittelen",
'kalturavideo:river:update' => "en video med tittelen",
//the river search the translation with the object label (kaltura_video)
'kaltura_video:river:annotate' => "en kommentar til denne videoen",
'kalturavideo:river:rates' => "%s vurderte denne videoen",
//widget title label
'kalturavideo:label:latest' => "Nyeste videoer",
//widget options
'kalturavideo:showmode' => "Listevisning",
'kalturavideo:showmode:thumbnail' => "Ikonliste",
'kalturavideo:showmode:embed' => "Sett inn mini-avspiller",
'kalturavideo:label:morevideos' => "Flere videoer",
'kalturavideo:more' => "Mer",
//donate button in tools administrations
'kalturavideo:note:donate' => "Do you like this plugin? Please consider donating:",

//new from  11-21-2009
'kalturavideo:error:curl' => "Extension CURL not loaded!\nPlease be sure to enable this extension in order to use this plugin!\nPlease read the README file for more information.",

//new from version 1.1
'kalturavideo:menu:server' => "Server",
'kalturavideo:menu:custom' => "Player &amp; Editor",
'kalturavideo:menu:behavior' => "Plugin behavior",
'kalturavideo:menu:advanced' => "Advanced",
'kalturavideo:menu:credits' => "Credits",
'kalturavideo:admin' => "Kaltura Video Admin",
'kalturavideo:admin:serverpart' => "Streaming Server",
'kalturavideo:admin:partnerpart' => "Partner ID Configuration",
'kalturavideo:admin:wizardpart' => "Kaltura Online Video Platform Registration",
'kalturavideo:admin:player' => "Video Player Options",
'kalturavideo:admin:editor' => "Online Video Editor Options",
'kalturavideo:admin:textareas' => "Textareas Integration",
'kalturavideo:admin:credits' => "Credits",
'kalturavideo:admin:suport' => "Suport",

'kalturavideo:server:info' => "To use the Kaltura Platform features, you need to have a valid Partner ID with the Kaltura Server.",
'kalturavideo:server:type' => "Choose your Kaltura Server",
'kalturavideo:server:kalturacorp' => "Kaltura.com hosted edition",
'kalturavideo:server:kalturace' => "Kaltura Community Edition (CE)",
'kalturavideo:server:corpinfo' => "Signing up with the Kaltura.com hosted edition, provide you with a free trial account.
Your trial account includes 10GB of free hosting and streaming.",
'kalturavideo:server:ceinfo' => "Kaltura Community Edition is a self-hosted, community supported version of Kaltura's Open Source Online Video Platform.",
'kalturavideo:server:moreinfo' => "Find more information about",
'kalturavideo:server:ceurl' => "Kaltura CE Server URL",
'kalturavideo:server:alertchange' => "WARNING: By changing this data will lose your existing videos!
Are you sure?
Probably you want to recreate objects after this action.",
'kalturavideo:wizard:cannot' => "You cannot use this page with your current configuration!",
'kalturavideo:advanced:recreateobjects' => "I agree, please recreate all video objects now!",
'kalturavideo:recreate:initiating' => "Retrieving information from Kaltura server...",
'kalturavideo:recreate:stepof' => "Retrieving videos (step %NUM% of %TOTAL%)...",
'kalturavideo:recreate:processedvideos' => "Processed videos %NUMRANGE% of %TOTAL%...",
'kalturavideo:recreate:done' => "All videos successfully processed!",
'kalturavideo:recreate:donewitherrors' => "Videos processed with errors!",
'kalturavideo:changeplayer' => "Here you can change the default player for the new created videos (old videos will not be affected).",
'kalturavideo:generic' => "Generic",
'kalturavideo:customplayer' => "My Own Customized Player",
'kalturavideo:customkcw' => "My Own Contribution Wizard",
'kalturavideo:customeditor' => "My Own Editor",
'kalturavideo:uiconf1' => "Kaltura's Application Studio Player ID",
'kalturavideo:text:uiconf1' => '%s to the Kaltura Management Console (KMC) to create your own players.<br />
With your own custom player, you can change the default size of the player besides of many more features.<br />
Custom players are defined in "Application Studio" sub menu in KMC',
'kalturavideo:uiconf2' => "Kaltura's Contribution Wizard (KCW) ID",
'kalturavideo:uiconf3' => "Kaltura's Editor (KSE) ID",
'kalturavideo:error:uiconf1' => "Error! Wrong Player ID.",
'kalturavideo:error:uiconf2' => "Error! Wrong KCW ID.",
'kalturavideo:error:uiconf3' => "Error! Wrong KSE ID.",
'kalturavideo:uiconf:getlist' => "Get a list of them",
'kalturavideo:uiconf1:notfound' => "No custom players found!",
'kalturavideo:uiconf2:notfound' => "No custom KCW found!",
'kalturavideo:uiconf3:notfound' => "No custom KSE found!",
'kalturavideo:playerupdated' => "Player &amp; editor options successfully updated.",
'kalturavideo:label:defaulteditor' => "Default video editor",
'kalturavideo:editor:light' => "Editor in light color schemes",
'kalturavideo:editor:dark' => "Editor in dark color schemes",
'kalturavideo:label:defaultkcw' => "Default uploader (Contribution Wizard)",
'kalturavideo:kcw:light' => "Uploader in light color schemes",
'kalturavideo:kcw:dark' => "Uploader in dark color schemes",

'kalturavideo:admin:videoeditor' => "Video Editor",
'kalturavideo:admin:rating' => "Video Rating",

'kalturavideo:behavior:alloweditor' => "Allow users to edit his videos",
'kalturavideo:alloweditor:full' => "Yes, show the uploader and then the editor when creating a video",
'kalturavideo:alloweditor:simple' => "Yes, but do not show the editor when creating a video (users can edit it after)",
'kalturavideo:alloweditor:no' => "No, do not allow video editing at all",
'kalturavideo:alloweditor:notallowed' => "Video editing is not allowed!",

'kalturavideo:behavior:enablerating' => "Enable the built-in video rating",

//new from 1.2
'kalturavideo:admin:others' => "Other options",
'kalturavideo:behavior:widget' => "Include videos widget on index page (custom_index must be enabled)",
'kalturavideo:behavior:numvideos' => "Number of videos to display",
'kalturavideo:option:single' => "Yes, a simple list (like latest blogs)",
'kalturavideo:option:multi' => "Yes, a tab list with Latest, Top played, Top Commented, Top rated (like latest iZAP Videos)",

'kalturavideo:index:toplatest' => "Mest populære samarbeidsvideoer",
'kalturavideo:index:latest' => "Nyeste",
'kalturavideo:index:played' => "Avspilt",
'kalturavideo:index:commented' => "Kommentert",
'kalturavideo:index:rated' => "Vurdert"

);

add_translation("no", $norwegian);

?>