<?php
/**
 * Elgg diagnostics language pack.
 *
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(

		'captcha:entercaptcha' => 'Skriv inn teksten fra bildet',
		'captcha:captchafail' => 'Beklager, teksten du skrev stemte ikke med teksten i bildet.',

);
	
add_translation("no",$norwegian);
?>