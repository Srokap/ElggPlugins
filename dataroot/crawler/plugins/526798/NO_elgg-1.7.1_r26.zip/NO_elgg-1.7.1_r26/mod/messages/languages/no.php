<?php
/**
 * Elgg messages plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(
/**
 * Menu items and titles
 */
'messages' => "Meldinger",
            'messages:back' => "tilbake til meldingene",
'messages:user' => "Din innboks",
'messages:sentMessages' => "Sendte meldinger",
'messages:posttitle' => "%s sine meldinger: %s",
'messages:inbox' => "Innboks",
'messages:send' => "Send en melding",
'messages:sent' => "Sendte meldinger",
'messages:message' => "Meldinger",
'messages:title' => "Tittel",
'messages:to' => "Til",
            'messages:from' => "Fra",
'messages:fly' => "Send",
'messages:replying' => "Melding med svar til",
'messages:inbox' => "Innboks",
'messages:sendmessage' => "Send en melding",
'messages:compose' => "Skriv en melding",
'messages:sentmessages' => "Sendte meldinger",
'messages:recent' => "Nylige meldinger",
            'messages:original' => "Opprinnelig melding",
            'messages:yours' => "Din melding",
            'messages:answer' => "Svar",
'messages:toggle' => 'Toggle all',
'messages:markread' => 'Merk som lest',
'messages:new' => 'Ny melding',
'notification:method:site' => 'Nettsted',
'messages:error' => 'Det oppsto et problem ved lagring av meldingen din. Vennligst prøv igjen.',
'item:object:messages' => 'Meldinger',
/**
 * Status messages
 */
'messages:posted' => "Meldingen din ble sendt.",
'messages:deleted' => "Meldingen din ble slettet.",
'messages:markedread' => "Meldngene dine ble merket som lest.",
/**
 * Email messages
 */
'messages:email:subject' => 'Du har en ny melding!',
'messages:email:body' => "Du har en ny melding fra %s. Innholdet er:

%s


For å vise meldingen din, klikk her:

%s

For å sende %s en melding, klikk her:

%s

Det er ikke mulig å svare på denne e-posten.",
/**
 * Error messages
 */
'messages:blank' => "Beklager, du må skrive en meldingstekst før vi kan lagre den.",
'messages:notfound' => "Beklager, vi kunne ikke finne den spesifiserte meldingen.",
'messages:notdeleted' => "Beklager, vi kunne ikke slette denne meldingen.",
'messages:nopermission' => "Du har ikke tilgang til å endre den meldingen.",
'messages:nomessages' => "Det er ingen meldinger å vise.",
'messages:user:nonexist' => "Vi kunne ikke finne mottakeren i brukerdatabasen.",
'messages:user:blank' => "Du har ikke valgt noen mottaker.",
);
add_translation("no",$norwegian);

?>
