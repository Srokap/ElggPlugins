<?php
/**
 * Elgg thewire plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(
/**
* Menu items and titles
*/
'thewire' => "Veggen",
'thewire:user' => "%s sin vegg",
'thewire:posttitle' => "%s sine innlegg på veggen: %s",
'thewire:everyone' => "Alle vegginnlegg",
'thewire:read' => "Vegginnlegg",
'thewire:strapline' => "%s",
'thewire:add' => "Del på veggen",
   'thewire:text' => "Et innlegg på veggen",
'thewire:reply' => "Svar",
'thewire:via' => "via",
'thewire:wired' => "Delt på veggen",
'thewire:charleft' => "tegn igjen",
'item:object:thewire' => "Vegginnlegg",
'thewire:notedeleted' => "innlegg slettet",
'thewire:doing' => "Hva tenker du på? Fortell alle på veggen:",
'thewire:newpost' => 'Ny veggmelding',
'thewire:addpost' => 'Del på veggen',
'thewire:by' => "Veggmeldinger av %s",

        /**
    * The wire river
    **/
       
       //generic terms to use
       'thewire:river:created' => "%s delte",
       
       //these get inserted into the river links to take the user to the entity
       'thewire:river:create' => "på veggen.",
       
   /**
    * Wire widget
    **/
    
       'thewire:sitedesc' => 'Dette innstikket viser de siste innleggene fra alle som er delt på veggen',
       'thewire:yourdesc' => 'Dette innstikket viser dine siste innlegg på veggen',
       'thewire:friendsdesc' => 'Dette innstikket viser de siste innleggene fra dine venner som er delt på veggen',
       'thewire:friends' => 'Dine venner på veggen',
       'thewire:num' => 'Antall innlegg som skal vises',
       'thewire:moreposts' => 'Flere vegginnlegg',
       
/**
* Status messages
*/
'thewire:posted' => "Ditt innlegg ble delt på veggen.",
'thewire:deleted' => "Ditt vegginnlegg ble slettet.",
/**
* Error messages
*/
'thewire:blank' => "Beklager, men du må skrive noe i tekstboksen før vi kan lagre det.",
'thewire:notfound' => "Beklager, vi kunne ikke finne det angitte vegginnlegget.",
'thewire:notdeleted' => "Beklager, vi kunne ikke slette dette vegginnlegget.",
/**
* Settings
*/
'thewire:smsnumber' => "Ditt SMS-nummer er forskjellig fra ditt mobilnummer (mobilnummer må settes til offentlig for at veggen skal kunne bruke det). Alle nummer må angis i internasjonalt format (husk +47 for Norge).",
'thewire:channelsms' => "Nummeret for å sende SMS er <b>%s</b>",
);
add_translation("no",$norwegian);

?>
