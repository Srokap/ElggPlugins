<?php
/**
* Elgg external pages plugin language pack
* 
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author bitjungle
* @copyright bitjungle 
* @link http://bitjungle.com/
*/

$norwegian = array(
/**
* Menu items and titles
*/
'expages' => "Eksterne sider",
'expages:frontpage' => "Forside",
'expages:about' => "Om",
'expages:terms' => "Betingelser",
'expages:privacy' => "Personvern",
'expages:analytics' => "Analyse",
'expages:contact' => "Kontakt",
'expages:nopreview' => "Ingen forhåndsvisning tilgjengelig ennå",
'expages:preview' => "Forhåndsvisning",
'expages:notset' => "Denne siden har ikke blitt skrevet ennå.",
'expages:lefthand' => "Venstre informasjonspanel",
'expages:righthand' => "Høyre informasjonspanel",
'expages:addcontent' => "You can add content here via your admin tools. Look for the external pages link under admin.",
'item:object:front' => 'Elementer på forside',
/**
* Status messages
*/
'expages:posted' => "Siden ble lagret.",
'expages:deleted' => "Siden ble slettet.",
/**
* Error messages
*/
'expages:deleteerror' => "Det oppsto et problem ved sletting av siden",
'expages:error' => "Det oppsto et problem, vennligst prøv igjen. Kontakt administrator om feilen dukker opp igjen.",
);
add_translation("no",$norwegian);

?>
