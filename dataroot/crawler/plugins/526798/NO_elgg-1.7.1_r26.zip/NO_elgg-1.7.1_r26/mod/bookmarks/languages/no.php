<?php
/**
 * Elgg bookmarks plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(
/**
 * Menu items and titles
 */
'bookmarks' => "Bokmerker",
'bookmarks:add' => "Legg til bokmerke",
'bookmarks:read' => "%s sine bokmerkede elementer",
'bookmarks:friends' => "Venners bokmerker",
'bookmarks:everyone' => "Bokmerker for hele nettstedet",
'bookmarks:this' => "Bokmerk dette",
'bookmarks:this:group' => "Bokmerket i %s",
'bookmarks:bookmarklet' => "Hent bookmarklet",
'bookmarks:bookmarklet:group' => "Hent gruppe-bookmarklet",
'bookmarks:inbox' => "Bokmerker innboks",
'bookmarks:morebookmarks' => "Flere bokmerker",
'bookmarks:more' => "Flere",
'bookmarks:shareditem' => "Bokmerkede enheter",
'bookmarks:with' => "Dele med",
'bookmarks:new' => "En ny bokmerket enhet",
'bookmarks:via' => "via bokmerker",
'bookmarks:address' => "Adressen til ressursen du vil bokmerke",
'bookmarks:delete:confirm' => "Er du sikker på at du vil slette denne ressursen?",
'bookmarks:numbertodisplay' => 'Antall bokmerkede enheter som skal vises',
'bookmarks:shared' => "Bokmerket",
'bookmarks:visit' => "Besøk ressurs",
'bookmarks:recent' => "Nye bokmerker",
'bookmarks:river:created' => '%s bokmerket',
'bookmarks:river:annotate' => 'en kommentar til denne bokmerkede enheten',
'bookmarks:river:item' => 'en enhet',
'item:object:bookmarks' => 'Bokmerkede enheter',
'bookmarks:group' => 'Gruppebokmerker',
'bookmarks:enablebookmarks' => 'Aktiver gruppebokmerker',
/**
 * More text
 */
 
   'bookmarks:widget:description' => 
           "Dette innstikket viser dine nyeste bokmerker.",
'bookmarks:bookmarklet:description' =>
"The bookmarks bookmarklet allows you to share any resource you find on the web with your friends, or just bookmark it for yourself. To use it, simply drag the following button to your browser's links bar:",

       'bookmarks:bookmarklet:descriptionie' =>
"If you are using Internet Explorer, you will need to right click on the bookmarklet icon, select 'add to favorites', and then the Links bar.",

'bookmarks:bookmarklet:description:conclusion' =>
"You can then save any page you visit by clicking it at any time.",
/**
 * Status messages
 */
'bookmarks:save:success' => "Your item was successfully bookmarked.",
'bookmarks:delete:success' => "Your bookmarked item was successfully deleted.",
/**
 * Error messages
 */
'bookmarks:save:failed' => "Your bookmarked item could not be saved. Please try again.",
'bookmarks:delete:failed' => "Your bookmarked item could not be deleted. Please try again.",
);
add_translation("no",$norwegian);

?>
