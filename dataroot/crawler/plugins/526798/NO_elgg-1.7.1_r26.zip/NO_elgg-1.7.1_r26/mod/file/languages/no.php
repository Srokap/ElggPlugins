<?php
/**
* Elgg file plugin language pack
* 
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author bitjungle
* @copyright bitjungle 
* @link http://bitjungle.com/
*/

$norwegian = array(
/**
* Menu items and titles
*/
'file' => "Filer",
'files' => "Filer",
'file:yours' => "Dine filer",
'file:yours:friends' => "Dine venners filer",
'file:user' => "%s sine filer",
'file:friends' => "%s sine venners filer",
'file:all' => "Alle filer for nettstedet",
'file:edit' => "Rediger filer",
'file:more' => "Flere filer",
'file:list' => "listevisning",
'file:group' => "Gruppefiler",
'file:gallery' => "gallerivisning",
'file:gallery_list' => "Galleri- eller listevisning",
'file:num_files' => "Antall filer som skal vises",
'file:user:gallery'=>'Vis %s galleri', 
       'file:via' => 'via filer',
'file:upload' => "Last opp en fil",
'file:replace' => 'Erstatt fil (la stå tom om du ikke vil endre fila)',
'file:newupload' => 'Opplasting av ny fil',
'file:file' => "Fil",
'file:title' => "Tittel",
'file:desc' => "Beskrivelse",
'file:tags' => "Stikkord",
'file:types' => "Filtyper",
'file:type:all' => "Alle filer",
'file:type:video' => "Videoer",
'file:type:document' => "Dokumenter",
'file:type:audio' => "Lyd",
'file:type:image' => "Bilder",
'file:type:general' => "Generell",
'file:user:type:video' => "%s sine videoer",
'file:user:type:document' => "%s sine dokumenter",
'file:user:type:audio' => "%s sine lydfiler",
'file:user:type:image' => "%s sine bilder",
'file:user:type:general' => "%s sine generelle filer",
'file:friends:type:video' => "Dine venners videoer",
'file:friends:type:document' => "Dine venners dokumenter",
'file:friends:type:audio' => "Dine venners lydfiler",
'file:friends:type:image' => "Dine venners bilder",
'file:friends:type:general' => "Dine venners generelle filer",
'file:widget' => "Filinnstikk",
'file:widget:description' => "Vis frem dine siste filer",
'file:download' => "Last ned denne",
'file:delete:confirm' => "Er du sikker på at du vil slette denne fila?",
'file:tagcloud' => "Stikkordsky",
'file:display:number' => "Antall filer som skal vises",
'file:river:created' => "%s lastet opp",
'file:river:item' => "en fil",
'file:river:annotate' => "en kommentar til denne fila",

'item:object:file' => 'Filer',
   /**
* Embed media
**/
 
   'file:embed' => "Sett inn media",
   'file:embedall' => "Alle",
/**
* Status messages
*/
'file:saved' => "Filen din ble lagret.",
'file:deleted' => "Filen din ble slettet.",
/**
* Error messages
*/
'file:none' => "Ingen filer ble lastet opp.",
'file:uploadfailed' => "Beklager, vi kunne ikke lagre filen din.",
'file:downloadfailed' => "Beklager, filen din er ikke tilgjengelig nå.",
'file:deletefailed' => "Filen din kunne ikke slettes nå.",
'file:noaccess' => "Du har ikke rettigheter til å slette denne fila",
'file:cannotload' => "Det oppsto en feil ved åpning av fila",
'file:nofile' => "Du må velge en fil",
);
add_translation("no",$norwegian);
?>
