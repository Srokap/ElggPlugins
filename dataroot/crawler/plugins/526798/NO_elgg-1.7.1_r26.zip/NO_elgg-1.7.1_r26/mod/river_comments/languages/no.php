<?php
/**
 * River comments plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(
'river_comments:admin' => 'River Comments Settings',
'river_comments:enable_ajaxsupport' => 'If you have problems with ajax, please disable this option',
'river_comments:admin:subtitle' => 'Do you like show the "comment" feature for...',

'river_comments:comment' => 'Kommenter',	
'river_comments:writeacomment' => 'Skriv en kommentar...',
'river_comments:viewallcomments' => 'Vis alle %s kommentarer',
'river_comments:allcommentsof' => 'Alle kommentarer fra "%s"',
'river_comments:notloginerror' => 'You are not logged in, please refresh the page.',

'river_comments:show:thewire' => 'the wire on the river?',
'river_comments:show:blog' => 'blog on the river?',
'river_comments:show:page' => 'page on the river?',
'river_comments:show:topic' => 'discussion topic on the river?',

'river_comments:show:tidypics_image'  => 'tidypics image on the river?',
'river_comments:show:tidypics_album'  => 'tidypics album on the river?',
'river_comments:show:izap_videos'  => 'izap videos on the river?',
'river_comments:show:event_calendar'  => 'event calendar page on the river?',
);

add_translation("no",$norwegian);
?>