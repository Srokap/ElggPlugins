<?php
/**
 * Elgg search plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(
'search:enter_term' => 'Skriv inn søkeord:',
'search:no_results' => 'Ingen resultater.',
'search:matched' => 'Passet: ',
'search:results' => 'Resultater for %s',
'search:no_query' => 'Vennligst legg inn søkeord.',
'search:search_error' => 'Feil',

'search:more' => '+%s flere %s',

'search_types:tags' => 'Stikkord',

'search_types:comments' => 'Kommentarer',
'search:comment_on' => 'Kommentarer til "%s"',
'search:comment_by' => 'av',
'search:unavailable_entity' => 'Unavailable Entity',
);

add_translation('no', $norwegian);
