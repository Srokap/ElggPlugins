<?php
/**
* Elgg members plugin language pack
* 
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author bitjungle
* @copyright bitjungle 
* @link http://bitjungle.com/
*/

$norwegian = array(
'members:members' => "Medlemmer",
   'members:online' => "Medlemmer som er aktive nå",
   'members:active' => "nettstedets medlemmer",
   'members:searchtag' => "Medlemsøk med stikkord",
   'members:searchname' => "Medlemsøk med navn",
  
'members:label:newest' => 'Nyeste',
'members:label:popular' => 'Populær',
'members:label:active' => 'Aktiv',
'members:search:name' => 'Medlemnavn',
'members:search:tags' => 'Stikkord',
);
add_translation("no",$norwegian);

?>
