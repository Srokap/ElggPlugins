<?php
/**
 * Elgg pages plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle 
 * @link http://bitjungle.com/
 */

$norwegian = array(
/**
 * Menu items and titles
 */
'pages' => "Sider",
'pages:yours' => "Dine sider",
'pages:user' => "Hovedside",
'pages:group' => "Gruppesider",
'pages:all' => "Sider for hele nettstedet",
'pages:new' => "Ny side",
'pages:groupprofile' => "Gruppesider",
'pages:edit' => "Rediger denne siden",
'pages:delete' => "Slett denne siden",
'pages:history' => "Sidehistorikk",
'pages:view' => "Vis side",
'pages:welcome' => "Rediger velkomstmelding",
'pages:welcomemessage' => "Velkommen til sideverktøyet for %s. Dette verktøyet gir deg mulighet til å lage sider om et hvilket som helst tema, og du kan bestemme hvem skom skal kunne lese og redigere dem.",
'pages:welcomeerror' => "Det oppsto et problem ved lagring av velkomstmelding",
'pages:welcomeposted' => "Din velkomstmelding ble lagret",
'pages:navigation' => "Sidenavigasjon",
       'pages:via' => "via sider",
'item:object:page_top' => 'Sider på toppnivå',
'item:object:page' => 'Sider',
'item:object:pages_welcome' => 'Velkomstblokker for sider',
'pages:nogroup' => 'Denne gruppen har ingen sider ennå',
'pages:more' => 'Flere sider',
/**
 * River
 **/
   'pages:river:annotate' => "en kommentar til denne siden",
   'pages:river:created' => "%s skrev",
       'pages:river:updated' => "%s oppdaterte",
       'pages:river:posted' => "%s la inn",
'pages:river:create' => "en ny side med tittel",
       'pages:river:update' => "en side med tittel",
       'page:river:annotate' => "en kommentar til denne siden",
       'page_top:river:annotate' => "en kommentar til denne siden",
/**
 * Form fields
 */
'pages:title' => 'Sidetittel',
'pages:description' => 'Ditt sideinnhold',
'pages:tags' => 'Stikkord',
'pages:access_id' => 'Tilgang',
'pages:write_access_id' => 'Skrivetilgang',
/**
 * Status and error messages
 */
'pages:noaccess' => 'No access to page',
'pages:cantedit' => 'You can not edit this page',
'pages:saved' => 'Pages saved',
'pages:notsaved' => 'Page could not be saved',
'pages:notitle' => 'You must specify a title for your page.',
'pages:delete:success' => 'Siden ble slettet.',
'pages:delete:failure' => 'Siden kunne ikke slettes.',
/**
 * Page
 */
'pages:strapline' => 'Sist oppdatert %s av %s',
/**
 * History
 */
'pages:revision' => 'Revidert den %s av %s',
/**
 * Widget
 **/

   'pages:num' => 'Number of pages to display',
'pages:widget:description' => "Dette er en liste over dine sider.",
/**
 * Submenu items
 */
'pages:label:view' => "Vis side",
'pages:label:edit' => "Rediger side",
'pages:label:history' => "Sidehistorikk",
/**
 * Sidebar items
 */
'pages:sidebar:this' => "Denne siden",
'pages:sidebar:children' => "Undersider",
'pages:sidebar:parent' => "Hovedside",
'pages:newchild' => "Lag en underside",
'pages:backtoparent' => "Tilbake til '%s'",
);
add_translation("no",$norwegian);
?>
