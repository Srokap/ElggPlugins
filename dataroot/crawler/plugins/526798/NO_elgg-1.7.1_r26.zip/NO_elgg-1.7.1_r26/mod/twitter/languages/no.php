<?php
/**
 * Elgg twitter plugin language pack
 *
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author bitjungle
 * @copyright bitjungle
 * @link http://bitjungle.com/
 */

$norwegian = array(

/**
 * twitter widget details
 */


		'twitter:username' => 'Skriv inn ditt twitter brukernavn.',
		'twitter:num' => 'Antall tvitringer som skal vises.',
		'twitter:visit' => 'gå til min twitter',
		'twitter:notset' => 'This Twitter widget is not yet set to go. To display your latest tweets, click on - edit - and fill in your details',


/**
 * twitter widget river
 **/
 
//generic terms to use
	        'twitter:river:created' => "%s added the twitter widget.",
	        'twitter:river:updated' => "%s updated their twitter widget.",
	        'twitter:river:delete' => "%s removed their twitter widget.",
 

);
	
add_translation("no",$norwegian);

?>