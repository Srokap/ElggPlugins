<?php
		function mp3_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('mp3'), $CONFIG->wwwroot . "mod/mp3");
		}
		
	register_elgg_event_handler('init','system','mp3_init');
	// Shares widget

?>