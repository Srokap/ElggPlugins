<?php

    /**
	 * Elgg Online
	 * Friend widget options
	 * 
	 * @package ElggOnline
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Johnny Storm
	 * @
	 * @link http://pervertedconcepts.com/
	 */
		$users = find_active_users(600,30);
        $totonline = count($users);

        if($users){
	echo "<div id=\"widget_friends_list\">";
		echo "Total online: ".$totonline."<br> ";
            foreach($users as $user){
                echo "<div class=\"member_icon\">";
                echo elgg_view("profile/icon",array('entity' => $user, 'size' => 'small')) . "</div>";
            }
			
	
	echo "</div>";
			
    }
	
?>