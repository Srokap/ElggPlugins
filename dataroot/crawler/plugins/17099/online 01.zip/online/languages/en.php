<?php

	$english = array(
	
		/**
		 * Friends widget
		 */
			'friends:widget:description' => "Displays online users.",
	        
		
	);
					
	add_translation("en",$english);

?>