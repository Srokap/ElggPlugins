<?php

	/**
	 * Elgg Online widget
	 * This pluginlist users that are online.
	 * 
	 * @package ElggOnline
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @Johnny Storm
	 * 
	 * @link http://pervertedconcepts.com/
	 */
	
		function online_init() {
    		
    		// Load system configuration
				global $CONFIG;
				
						// Load the language file
				register_translations($CONFIG->pluginspath . "online/languages/");
    		
    		//add a widget
			    add_widget_type('online',elgg_echo("Users online"),elgg_echo('online:widget:description'));
			
		}
		
		register_elgg_event_handler('init','system','online_init');
        
?>