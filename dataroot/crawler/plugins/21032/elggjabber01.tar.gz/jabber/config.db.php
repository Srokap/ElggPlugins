<?php
/**
 * Set the database connection to you're jabber servers database here
 * You could set the dbms engine in admin interface
 */
define('JABBER_DB_HOST', '');
define('JABBER_DB_USER', '');
define('JABBER_DB_PASS', '');
define('JABBER_DB_NAME', '');
?>
