/**
 * Does the communication with jwchat.
 * Gets login informations via ajax
 */
function jabber_init() {
    jQuery.getJSON(
      ELGG_ROOT + "mod/jabber/ajax.php",
      function(data) {
        // define global variables needed by jwchat
        JABBERSERVER = data.server;
        BACKEND_TYPE = data.httptype;
        HTTPBASE = data.httpbase;
        register = false;
        jid = data.jid;
        pass = data.pass;
        window.open(
          ELGG_ROOT + 'mod/jabber/jwchat/jwchat.html',
          'Jabber Chat',
          'width=180,height=390,resizable=yes'
        );
    });
}
