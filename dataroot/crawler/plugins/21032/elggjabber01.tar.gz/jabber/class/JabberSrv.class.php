<?php
 /**
  * Interface for jabber server implementations.
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggjabber
  * @see http://blog.jwchat.org/jwchat/
  */

include_once('JabberSrv' . get_plugin_setting('srvengine', 'jabber') . '.class.php');

abstract class JabberSrv {

    /**
     * DB Connection
     * @var JabberDb* $db
     */
    protected $db;

    /**
     * Sole constructor
     */
    public function JabberSrv($db) {
        $this->db = $db;
    }

    /**
     * Register a new user if he isn't registrated yet.
     * Additionally the password is adjusted if its changed
     *
     * @param string $user Username
     * @param string $pass Password
     */
    abstract public function register($user, $pass);

    /**
     * Add users to ones buddy list if they are not there yet.
     *
     * @param string $user username
     * @param array $buddies usernames of buddies to add
     */
    abstract public function roster($user, $buddies);
}

?>
