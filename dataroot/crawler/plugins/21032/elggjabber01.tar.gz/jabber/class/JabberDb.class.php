<?php
 /**
  * Interface for dbms modules of the jabber plugin
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggjabber
  * @see http://blog.jwchat.org/jwchat/
  */

include_once(dirname(__FILE__) . '/JabberDb' . get_plugin_setting('dbmsengine', 'jabber') . '.class.php');

abstract class JabberDb {
    /**
     * Sends a query.
     *
     * @param string $query the query
     * @param array $params parameters which replace placeholders
     * @return array with selected rows
     */
    public function query($query, $params) {
        return $this->sendQuery($this->parseQuery($query, $params));
    }

    /**
     * Abstract function to send query to DBMS.
     *
     * @param $query
     * @return array with selected rows
     */
    abstract protected function sendQuery($query);

    /**
     * Replace placeholder %s and %d
     * 
     * @param string $query Unparsed query
     * @param array $vars Variables used to replace the placeholder
     * @return string Returns the parsed query
     */
    private function parseQuery($query, $vars) {
        $pos = 0;
        if (!is_array($vars)) {
            return $query;
        }
        array_unshift($vars, '');
        reset($vars);
        while (FALSE !== ($pos = strpos($query, '%', $pos))) {
            $var = next($vars);
            switch ($query[$pos+1]) {
                case 'd': // numeric
                    if (!is_numeric($var)) {
                        return false;
                    }
                    break;
                case 's': // string
                    if ($var) {
                        $var = $this->escape($var);
                    }
                    break;
                case '%': // escape-sequence
                    $var = '%';
                    prev($vars);
                    break;
                default: // unknown
                    return false;
            }
            if ($var === false) {
                return false;
            }
            $query = substr_replace($query, $var, $pos, 2);
            $pos += strlen($var);
        }
        return $query;
    }

    /**
     * Escape an string to prevent sql injection.
     *
     * @param string $str string
     * @return escaped string
     */
    abstract public function escape($str);
}
?>
