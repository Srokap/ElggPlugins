<?php
 /**
  * Implements MySQL support for jabber plugin
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggjabber
  * @see http://blog.jwchat.org/jwchat/
  */

class JabberDbMysql extends JabberDb {
    
    private $id;

    /**
     * Constructor establish the MySQL-Connection and select the DB
     */
    function __construct($host, $user, $pass, $db) {
        $this->id = @mysql_connect($host, $user, $pass);
        mysql_select_db($db, $this->id);
    } 
    
    /** {@inheritDoc} */
    protected function sendQuery($query) {
        if (!($res = @mysql_query($query, $this->id))) {
            return false;
        }
        if ($res === true) {
            return true;
        }
        
        $return = array();
        while ($row = mysql_fetch_array($res)) {
            $add = array();
            foreach ($row as $key => $val) {
                if (!is_numeric($key)) {
                    $add[$key] = $val;
                }
            }
            $return[] = $add;
        }
        return $return;
    }
    
    /** {@inheritDoc} */
    public function escape($str) {
        return mysql_real_escape_string($str, $this->id);
    }
}
?>
