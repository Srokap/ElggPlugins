<?php
 /**
  * Implements support for ejabberd.
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggjabber
  * @see http://blog.jwchat.org/jwchat/
  */

class JabberSrvEjabberd extends JabberSrv {

    /** {@inheritDoc} */
    public function register($user, $pass) {
        if (count(
          $res = $this->db->query("select username, password from users where username = '%s'", array($user))
        ) > 0) { // User is already registrated
            if ($res[0]['password'] != $pass) {// Password have to be updated
                $this->db->query("update users set password = '%s' where username = '%s'",
                  array($pass, $user));
            }

        } else { // Registrate user
            $this->db->query("insert into users (username, password)
              values ('%s', '%s')", array($user, $pass));
        }
    }

    /** {@inheritDoc} */
    public function roster($user, $buddies) {
        // Select only users who already registrated
        $buddies = $this->db->query('select username from users where username in
            (' . implode(',', array_fill(0, count(buddies), "'%s'")) . ')', $buddies);
        foreach ($buddies as $buddy) {
            $this->rosterRaw($user, $buddy['username']);
            $this->rosterRaw($buddy['username'], $user);
        }
    }

    /**
     * Add a row to roastersusers if there isn't one yet
     *
     * @param $user username
     * @param $buddy username of buddy
     */
    private function rosterRaw($user, $buddy) {
        $srv = get_plugin_setting('server', 'jabber');
        if (current(current($this->db->query(
        "select count(*) from rosterusers where username = '%s' and jid = '%s'",
        $user, $buddy . '@' . $srv))) == 0) {// There is no entry. add one
            $this->db->query("insert into rosterusers
              (username, jid, nick, subscription, ask, server, type)
              values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')",
            array($user, $buddy . '@' . $srv, $buddy, 'B', 'N', 'N', 'item'));
        }
    }
}

?>
