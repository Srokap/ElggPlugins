<?php
 /**
  * Ajax handler to get the jabber connection data
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggjabber
  * @see http://blog.jwchat.org/jwchat/
  */

// Start Elgg Engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
if (!isloggedin()) {
    die ("You are not logged in!");
}

// Include mod own abstract class definitions
include_once('config.db.php');
include_once(dirname(__FILE__) . '/class/JabberDb.class.php');
include_once(dirname(__FILE__) . '/class/JabberSrv.class.php');

// Establish a connection to servers database
$classname = 'JabberDb' . get_plugin_setting('dbmsengine', 'jabber');
$db = new $classname(
    JABBER_DB_HOST,
    JABBER_DB_USER,
    JABBER_DB_PASS,
    JABBER_DB_NAME
);
// Start jabber server engine
$classname = 'JabberSrv' .  get_plugin_setting('srvengine', 'jabber');
$srv = new $classname($db);

// Register user if he isn't registered yet
$srv->register($_SESSION['user']->username, $_SESSION['user']->password);

// Check/complete  buddy list
$buddies = array();
foreach ($_SESSION['user']->getFriends() as $buddy) {
    $buddies[] = $buddy->username;
}
$srv->roster($_SESSION['user']->username, $buddies);

// Send required data to js
echo json_encode(array(
    'server' =>     get_plugin_setting('server', 'jabber'),
    'httpbase' =>   get_plugin_setting('httpbase', 'jabber'),
    'httptype' =>   get_plugin_setting('httptype', 'jabber'),
    'jid' =>        $_SESSION['user']->username . '@' .
        get_plugin_setting('server', 'jabber') . '/jwchat',
    'pass' =>       $_SESSION['user']->password
));
?>
