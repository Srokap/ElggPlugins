<?php
 /**
  * Elgg Jabber plugin
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggjabber
  * @see http://blog.jwchat.org/jwchat/
  */

function jabber_init() {
    global $CONFIG;
    register_translations($CONFIG->pluginspath . "jabber/languages/");
    if (isloggedin()) {
        add_menu(elgg_echo('Jabber'), "javascript:jabber_init()");
    }
    // Add javascript stuff
    extend_view('metatags','jabber/metatags');
}

register_elgg_event_handler('init', 'system', 'jabber_init');

?>
