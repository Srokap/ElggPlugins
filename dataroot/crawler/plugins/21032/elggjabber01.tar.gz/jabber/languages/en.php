<?php

	$english = array(
	
		/**
		 * Administration
		 */
	
			'jabber:settings:server' => "Server Domain",
            'jabber:settings:httpbase' => "HTTP Base",
			'jabber:settings:httptype' => "HTTP Type",
			'jabber:settings:dbmsengine' => "DBMS Engine",
            'jabber:settings:srvengine' => "Server Engine",
        /**
         * Misc
         */
            'Jabber' => 'Jabber'
	
	);
					
	add_translation("en", $english);

?>
