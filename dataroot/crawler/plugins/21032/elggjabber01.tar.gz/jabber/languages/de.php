<?php

	$deutsch = array(
	
		/**
		 * Administration
		 */
	
			'jabber:settings:server' => "Server Domain",
            'jabber:settings:httpbase' => "HTTP Base",
			'jabber:settings:httptype' => "HTTP Typ",
			'jabber:settings:dbmsengine' => "DBMS Engine",
            'jabber:settings:srvengine' => "Server Engine",
        /**
         * Misc
         */
            'Jabber' => 'Jabber'
	
	);
					
	add_translation("de", $deutsch);

?>
