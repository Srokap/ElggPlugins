<p>
    <?php echo elgg_echo('jabber:settings:server'); ?>
    <input type="text" name="params[server]" value="<?php echo $vars['entity']->server ?>" />
</p>
<p>
    <?php echo elgg_echo('jabber:settings:httpbase'); ?>
    <input type="text" name="params[httpbase]" value="<?php echo $vars['entity']->httpbase ?>" />
</p>
<p>
    <?php echo elgg_echo('jabber:settings:httptype'); ?>
    <select name="params[httptype]">
        <option value="binding" <?php if ($vars['entity']->httptype == 'binding') echo " selected=\"selected\" "; ?>>binding</option>
        <option value="polling" <?php if ($vars['entity']->httptype == 'polling') echo " selected=\"selected\" "; ?>>polling</option>
    </select>
</p>
<p>
    <?php echo elgg_echo('jabber:settings:dbmsengine'); ?>
    <select name="params[dbmsengine]">
        <option value="Mysql" <?php if ($vars['entity']->dbmsengine == 'Mysql') echo " selected=\"selected\" "; ?>>MySQL</option>
    </select>
</p>
<p>
    <?php echo elgg_echo('jabber:settings:srvengine'); ?>
    <select name="params[srvengine]">
        <option value="Ejabberd" <?php if ($vars['entity']->srvengine == 'Ejabberd') echo " selected=\"selected\" "; ?>>ejabberd</option>
    </select>
</p>
