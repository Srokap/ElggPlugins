<?php
 /**
  * Elgg Chat plugin - common js includes
  *
  * @license GNU Public License version 3
  * @author Felix Stahlberg <fstahlberg@gmail.com>
  * @link http://www.xilef-software.de/en/projects/scripts/elggjabber
  * @see http://blog.jwchat.org/jwchat/
  */

// Why the hell there is no fucking JS API in Elgg?? I feel so dirty doing this!
echo '<script type="text/javascript">ELGG_ROOT = "' . $CONFIG->wwwroot . '";</script>';
?>

<script type="text/javascript" src="<?php echo $CONFIG->wwwroot ?>mod/jabber/common.js"></script>
