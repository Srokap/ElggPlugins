<?php

	/**
	 * Elgg invitations plugin
	 * Invite friends to this elgg site. With integrated walledgarden
	 * 
	 * @package Elgg Invitations plugin
	 * @license: GNU Public License version 2
	 * @author: Ralf Heinrich
	 * @copyright: Ralf Heinrich 
	 * @link: http://www.daten-punk.de/
	 * ****************************************
     * @Italian Language Pack
     * @Plugin System: Invitations plugin
     * @version: 0.2 
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

		
		$italian = array(
	
		
		/**
		 * Settings and Status  ###Settaggi e Stato###
		 */
		
			'invitations:default:expdays' => "Per quanti giorni dovrebbe essere valido un Invito? ",
			'invitations:default:walledgarden' => "Abilita il Walledgarden",
			'invitations:default:label:enable' => "Abilita",
			'invitations:default:label:disable' => "Disabilita",
			'invitations:default:enableforgottenpassword' => "Se il Walledgarden è abilitato: Abilita l'accesso alle pagine della Password dimenticata",
			'invitations:default:enableregistration' => "Se il Walledgarden è abilitato: Abilita la registrazione predefinita e il link sotto il modulo login",
			'invitations:default:email' => "Invia i messaggi con l'indirizzo Email predefinito<br />(Utilizza il sistema di base del sito)",
			
			'invitations:default:allowedusers' => "A chi permetteresti di inviare gli Inviti?",
			'invitations:default:label:all' => "<b>Tutti</b>",
			'invitations:default:label:none' => "<b>Nessuno</b>",
			'invitations:default:label:admin' => "<b>Amministratore</b>",
			'invitations:default:desc:all' => "Tutti gli utenti vengono abilitati ad eccezione di quelli che sono stati esplicitamente disabilitati.",
			'invitations:default:desc:none' => "Non viene abilitato nessun utente ad eccezione di quelli esplicitamente abilitati.",
			'invitations:default:desc:admin' => "Vengono abilitati solo gli Amministratori.",
			
			//admin actions: give permission to users, if restriction is set in plugin settings
		 	'invitations:usersetting:label:allow' => "Abilita gli Inviti",
		 	'invitations:usersetting:label:disallow' => "Disabilita gli Inviti",	 	
		 	'invitations:usersetting:allow:yes' => "L'utente è ora abilitato a inviare gli Inviti.",
			'invitations:usersetting:allow:no' => "Non possiamo permettere a questo utente di inviare gli Inviti.",
			'invitations:usersetting:disallow:yes' => "Ora all'utente non è permesso di inviare gli Inviti.",
			'invitations:usersetting:disallow:no' => "Non possiamo permettere a questo utente di inviare le registrazioni.",
					
			'invitations:status' => "Stato",
			'invitations:status:pending' => "in attesa",
			'invitations:status:expired' => "scaduto",
			'invitations:status:used' => "accettato",
			'invitations:status:usedby' => "accettato da",
			'invitations:status:usednotconfirmed' => "accettato, non ancora confermato",
		
		/**
		 * Widget  ###Widget###
		 */
		 
		 	'invitations:widget:moreinfo' => "Altri",
		 	'invitations:widget:label:status' => "Stato: ",
		 	'invitations:widget:label:invitee' => "Destinatario: ",
		 	'invitations:widget:label:inviteemail' => "E-Mail del Destinatario: ",
		 	'invitations:widget:label:message' => "Messaggio: ",
		 	'invitations:widget:label:sentas' => "Inviato come: ",
		 	'invitations:widget:label:sentby' => "Inviato da: ",
		 	'invitations:widget:label:registered' => "registrato come: ",
		 	'invitations:widget:label:delete' => "Cancella",
		 	'invitations:widget:delete:confirm' => "Sei sicuro di voler cancellare questo Invito?",
		 	'invitations:widget:delete:deleted' => "L'Invito è stato cancellato.",
		 	'invitations:widget:delete:deleted:error' => "E' accaduto un errore. L'Invito non può essere cancellato.",
		 	'invitations:widget:link:yourinvitations' => "I tuoi Inviti",

		 	
		/**
		 * Object list and single view elements   ###Lista degli oggetti e le visualizzazioni dei singoli elementi###
		 */
		 
		 	'invitations:moreinfo' => "Altri",
		 	'invitations:label:status' => "Stato: ",
		 	'invitations:label:invitee' => "Destinatario: ",
		 	'invitations:label:inviteemail' => "E-Mail del Destinatario: ",
		 	'invitations:label:message' => "Messaggio: ",
		 	'invitations:label:sentas' => "Inviato come: ",
		 	'invitations:label:sentby' => "Inviato da: ",
		 	'invitations:label:registered' => "Registrato come: ",
		 	'invitations:label:delete' => "Cancella",
		 	

		 
		 /**
		 * Plugin button, menu title, page title  ###Bottoni del plugin, titoli del menu, titolo della pagina###
		 */
	
			'invitation' => "Invito",
			'invitations:invitation' => "Invito",
			'invitations:plugin:name' => "Inviti",
			'invitations:page:title' => "Invita gli Amici su questa Rete Sociale",			
			'invitations:button:send' => "Invia",
			'invitations:widget:description' => "Questo Widget è pensato per la tua Dashboard e visualizzerà gli Inviti che hai inviato per invitare gli amici a questa rete sociale.",
			
			'invitations:submenu:yours' => "I tuoi Inviti",
			'invitations:submenu:new' => "Crea un nuovo Invito",
			'invitations:submenu:admin' => "Tutti gli Inviti",
		 	'invitations:list:title:yours' => "I tuoi Inviti",
		 	'invitations:entity:notallowed' => "Non hai il permesso di vedere further contents",
			
		
		/**
		 * E-Mail elements   ###Elementi dell'Email###
		 */
			
			'invitations:email:subject' => "%s ti ha invitato su %s",
			
			'invitations:email:mailbody' => "Ciao %s,
			
%s ti ha invitato su %s .
se vuoi partecipare al sito, clicca il seguente link: 
%s

Questa email è stata generata automaticamente. Non puoi rispondere ad essa.

",

			
			'invitations:email:mailbodyuser:message' => "Qui c'è un messaggio di un utente che ti ha invitato:

%s",
			
			
			
		/**
		 * Errors  ###Errori###
		 */
		 
		 	'invitations:register:error:expired' => "Il tuo Invito è scaduto. Era valido solo per %s giorni.",
		 	'invitations:register:error:coderror' => "C'è un problema con il codice di invito. Assicurati di aver utilizzato il link completo che è stato inviato con l'email di Invito.",
		 	'invitations:register:error:used' => "Questo Invito è stato già utilizzato e quindi non è più valido.",
			'invitations:error:notallowed' => "Non sei abilitato a inviare gli Inviti.",
			
			
			
		/**
		 * Input Form elements  ###Elementi da immettere nel modulo###
		 */
			
			'invitations:formintrotrext' => "Qui puoi invitare gli Amici su questa Rete Sociale. Basta riempire il modulo con il nome e l'email del tuo amico. Puoi aggiungere un proprio messaggio oltre a quello che sarà inviato come predefinito.",
			'invitations:label:fromname' => "Il tuo Nome",
			'invitations:label:toname' => "Nome del Destinatario",
			'invitations:label:mailto' => "Indirizzo Email del Destinatario",
			'invitations:label:subject' => "Oggetto",
			'invitations:label:message' => "Messaggio (opzionale)",
		
		
		
		/**
		 * Plugin action feedback   ###Feedback sull'azione del plugin###
		 */
			
			'invitations:send:successful' => "Il tuo Invito è stato inviato con successo. Grazie.",
			'invitations:send:unsuccessful' => "Il tuo Invito non può essere inviato. Assicurati che tutti i campi siano stati riempiti correttamente.",
			'invitations:email:invalid' => "Il nostro sistema non può accettare l'email che hai inserito. Per favore riprova con un valido indirizzo email.",
			

		/**
		 * Registration Form content elements  ###Elementi del contenuto del modulo di registrazione ###
		 */
		 
			'invitations:register:content:headline' => "Benvenuto",
			'invitations:register:content:body:invitedby' => "Sei stato invitato da %s",
			'invitations:register:content:body:knownas' => "username su questo sito: %s",
			'invitations:register:content:body:confirmationmail' => "Dopo aver riempito questo modulo, un email con il link di conferma ti sarà inviato. Clicca questo link per accertare che noi abbiamo un indirizzo email corretto e per attivare il tuo account.",
	
         
			
		/**
		 * Not used yet
		 */
		 	
		 	
			
	
	);
					
	add_translation("it",$italian);

?>