<?php
	/**
	 * Elgg customspotlight plugin
	 * This plugin substitutes the spotlight with a custom one
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Chris Hide
	 */

if (isloggedin()) {
add_menu(elgg_echo('Link Title'), "http://www.link-address.com");
}
?>
