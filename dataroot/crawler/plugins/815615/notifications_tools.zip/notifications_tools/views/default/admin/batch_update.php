<?php 
echo elgg_view_form("batch_update");
?>