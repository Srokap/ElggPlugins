Simply (and lean) MP3 Player Widget.

Original Flash player from: http://flash-mp3-player.net/
Just unzip to your mod folder and activate the plugin.
It became avaliable as a widget from the user panel.
It search for any "audio/mpeg" file avaliable at user files and creates a playlist for.

For additional info on customizing the flash player, see http://flash-mp3-player.net/
