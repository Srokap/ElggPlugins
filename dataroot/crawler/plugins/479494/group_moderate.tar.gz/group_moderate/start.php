<?php
/**
 *	Group Moderate Plugin
 *
 *	@package group moderate
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

global $CONFIG;

/**
 *	requires plugin functions
 */
require_once(dirname(__FILE__)."/models/model.php");

/**
 *	group_moderate_plugin_init
 *	
 *	performs plugin initialization function calls
 */
function group_moderate_plugin_init() {
	global $CONFIG;
	
	register_elgg_event_handler('create','group','group_moderate_group_create_eventhandler', 1500);

	// page handler for admin menu
	register_elgg_event_handler('pagesetup','system','group_moderate_adminmenu');
	// register a page handler for the /pg/ urls
	register_page_handler('group_moderate','group_moderate_page_handler');
	
}

/**
 * recommendations page handler
 *
 * @param array $page Array of page elements, forwarded by the page handling mechanism
 */
function group_moderate_page_handler($page) {
	global $CONFIG;
	
	// URLs $page array:
	//		0 = <username>
	//		1 = <action>
	//		2 = <entityId>
	//		3 = <recommendationId>
	
	// The second component of the URL is the action
	if (isset($page[0]) && $page[0]) {
		switch ($page[0]) {
			case "admin":
				set_input('tab', $page[1]);
				include(dirname(__FILE__) . "/admin.php");
				break;
			case "message":
				include(dirname(__FILE__) . "/message.php");
				break;
		}
		
	}
	
}

function group_moderate_adminmenu()
{
	global $CONFIG;
	if (get_context() == 'admin' && isadminloggedin()) {
		add_submenu_item(elgg_echo('group_moderate:administration'), $CONFIG->url . "pg/group_moderate/admin");
	}
}

function group_moderate_group_create_eventhandler($event, $object_type, $object) {
	
	if (($object) && ($object instanceof ElggGroup)) {
		
		$group_guid = $object->getGUID();
		disable_entity($group_guid, "group moderation by admin");
		include(dirname(__FILE__) . "/message.php");
		
	} 
	
	return (true);
	
	
}

// plugin init hook
register_elgg_event_handler('init','system','group_moderate_plugin_init');

// register CRUD actions
register_action("group_moderate/enable", false, $CONFIG->pluginspath . "group_moderate/actions/enable.php", true);
