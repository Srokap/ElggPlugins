<?php
/**
 *	Group Moderate Plugin
 *
 *	@package group moderate
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

gatekeeper();
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

// required admin to be logged-in
admin_gatekeeper();

global $CONFIG;

set_context('admin');
set_page_owner($_SESSION['guid']);


//$tab = get_input('tab', 'listgroups');

$body = elgg_view_title(elgg_echo('group_moderate:administration'));

$body .= elgg_view("group_moderate/admin/group_moderate", array('tab' => 'listgroups'));

page_draw(elgg_echo('group_moderate:administration'), elgg_view_layout("two_column_left_sidebar", '', $body));
