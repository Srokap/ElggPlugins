<?php
/**
 *	Group Moderate Plugin
 *
 *	@package group moderate
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

	$english = array(
	
		// General Items
			'group_moderate' => "Group Moderate",
			'group_moderate:administration' => "Group Moderate Administration",
			'group_moderate:Group Name' => "Group name",
			'group_moderate:Group Description' => "Group Description",
			'group_moderate:Group Creator Username' => "Group Creator Username",
			'group_moderate:Group Creator Name' => "Group Creator Name",
			'group_moderate:Group Created on' => "Created on",
			'group_moderate:created_group_user_text' => "
			Thank you for creating a group, <br/>
			We will review the group details and enable it if appropriate.<br/>
			",

		// plugin settings
			'group_moderate:settings' => "Settings",
			'group_moderate:listgroups' => "List Groups",
			'group_moderate:' => "Administration",
	
		// plugin messages
			'group_moderate:successfully_enabled_group' => "Successfully enabled group",
			
	);
					
	add_translation("en", $english);
