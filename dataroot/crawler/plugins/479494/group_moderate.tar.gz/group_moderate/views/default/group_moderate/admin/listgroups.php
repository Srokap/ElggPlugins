<?php


function draw_entity($groupEntity) {
	
	$entity = $groupEntity;
	
	$owner = get_entity($entity->owner_guid);
	
	$icon = elgg_view(
			"groups/icon", array(
									'entity' => $entity,
									'size' => 'small',
								  )
		);
	
	$info .= "<div class=\"contentWrapper\"><p>";
	$info .= "<b>".elgg_echo('group_moderate:Group Name')."</b>: ".$entity->name."<br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Description')."</b>: ".$entity->description."<br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Creator Username')."</b>: <a href='".$owner->getURL()."' />".$owner->username."</a><br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Creator Name')."</b>: ".$owner->name."<br/>";
	$info .= "<b>".elgg_echo('group_moderate:Group Created on')."</b>: ".friendly_time($entity->time_created)."<br/>";
	
	// create the enable button form
	$action = "group_moderate/enable";
	$form_body = elgg_view('input/hidden', array('internalname' => 'entity_guid', 'value' => $entity->getGUID()));
	$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('enable')));
	$info .= elgg_view('input/form', array('action' => "/action/$action", 'body' => $form_body));
	//
	
	$info .= "</p></div>";
	echo elgg_view_listing($icon, $info);
	
}

	global $CONFIG; 
		
	$plugin = find_plugin_settings('group_moderate');
	
	$access_status = access_get_show_hidden_status();
	access_show_hidden_entities(true);

	$entities = array();
	$disabled_groups_guids = get_disabled_groups_guids();
	foreach($disabled_groups_guids as $group) {
		$groupEntity = get_entity($group->guid);
		array_push($entities, $groupEntity);
		draw_entity($groupEntity);
	}
	
	//var_dump($entities);
	access_show_hidden_entities($access_status);
	