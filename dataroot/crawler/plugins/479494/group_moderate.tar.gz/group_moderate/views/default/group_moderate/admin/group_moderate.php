<?php
/**
 *	Group Moderate Plugin
 *
 *	@package group moderate
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

	global $CONFIG;
	
	$tab = $vars['tab'];
	
?>
<div class="contentWrapper">
	<div id="elgg_horizontal_tabbed_nav">
		<ul>
			<li <?php if ($tab == "settings") echo "class='selected'" ?>><a href="<?php echo $CONFIG->wwwroot . 'pg/group_moderate/admin/settings'; ?>"><?php echo elgg_echo('group_moderate:settings'); ?></a></li>
			<li <?php if ($tab == "listgroups") echo "class='selected'" ?>><a href="<?php echo $CONFIG->wwwroot . 'pg/group_moderate/admin/listgroups'; ?>"><?php echo elgg_echo('group_moderate:listgroups'); ?></a></li>
		</ul>
	</div>
<?php
	switch($tab) {
		case 'settings':
			echo elgg_view("group_moderate/admin/settings");
			break;
		case 'listgroups':
			echo elgg_view("group_moderate/admin/listgroups");
			break;
	}
?>
</div>
