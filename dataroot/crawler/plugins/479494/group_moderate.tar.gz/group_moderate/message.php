<?php
/**
 *	Group Moderate Plugin
 *
 *	@package group moderate
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

gatekeeper();
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

global $CONFIG;

set_context('group_moderate');

$title = elgg_echo('Created Group');
$body = elgg_echo('group_moderate:created_group_user_text');

$body = elgg_view_layout('two_column_left_sidebar', '', elgg_view_title($title) . $body);
page_draw($title, $body);
