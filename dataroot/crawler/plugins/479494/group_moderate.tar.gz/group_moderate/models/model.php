<?php
/**
 *	Group Moderate Plugin
 *
 *	@package group moderate
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

function get_disabled_groups_guids() {
	
	global $CONFIG;
	
	$query = "SELECT ".
				" distinct(a.guid) ".
			" FROM ".
				" {$CONFIG->dbprefix}entities a ".
			" WHERE ".
				" a.enabled = 'no' ".
			" ORDER BY a.time_created DESC";
	
	//return get_data($query, "entity_row_to_elggstar");
	return get_data($query);
	
}