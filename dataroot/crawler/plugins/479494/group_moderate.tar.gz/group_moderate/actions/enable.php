<?php
/**
 *	Group Moderate Plugin
 *
 *	@package group moderate
 *	@author Liran Tal <liran.tal@gmail.com>
 *	@license GNU General Public License (GPL) version 2
 *	@copyright (c) Liran Tal of Enginx 2009
 *	@link http://www.enginx.com
 */

global $CONFIG;

// making sure the user is logged in
gatekeeper();
admin_gatekeeper();

set_context('group_moderate');

// get object details
$entity_guid = get_input('entity_guid');

// enable the entity
if ($entity_guid) 
	enable_entity($entity_guid);

system_message(elgg_echo('group_moderate:successfully_enabled_group'));
forward($_SERVER['HTTP_REFERER']);

?>
