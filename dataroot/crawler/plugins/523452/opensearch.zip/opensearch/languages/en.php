<?php

$english = array(
	'opensearch:title' => "Search: %s",
	'opensearch:description' => "Search results for \"%s\"",
	
);

add_translation("en", $english);
