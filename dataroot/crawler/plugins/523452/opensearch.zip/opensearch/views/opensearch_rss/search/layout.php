<?php
echo $vars['body'];