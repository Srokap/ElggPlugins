<?php
/**
 * To support Elgg 1.7
 */

require_once(dirname(dirname(__FILE__)) . "/page_shells/default.php");
