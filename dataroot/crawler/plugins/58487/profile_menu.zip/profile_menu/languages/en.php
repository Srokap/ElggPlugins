<?php

	$english = array(

			'topbar:topprofile' => "My Profile",

	);
	
	add_translation("en",$english);

?>
