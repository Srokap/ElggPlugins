<?php
	echo $vars['url'] . "mod/theme_elgg_example/graphics/group_icons/defaulttiny.gif";
?>