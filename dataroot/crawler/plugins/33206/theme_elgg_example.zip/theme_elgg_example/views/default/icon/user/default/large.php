<?php
	echo $vars['url'] . "mod/theme_elgg_example/graphics/user_icons/defaultlarge.gif";
?>