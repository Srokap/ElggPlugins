<?php 
	$english = array(
		'customsearch' => "Full Text Search",
		
		'customsearch:search:title' => "Search results for: %s",
		'customsearch:search:found' => "Results found: %s",
		'customsearch:search:no_result' => "No search parameter(s) provided",
		'customsearch:search:too_short' => "Search parameter is too short (min length: %s)",
	);
	
	add_translation("en", $english);
?>