<?php
	/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */



function multisites_init($event, $object_type, $object) {
			
			global $CONFIG;
			register_plugin_hook('siteid','system','multisite_switch_site',500);
			
			
			return true;
		}
		
	// Register event handlers

		register_elgg_event_handler('boot','system','multisites_init',1);



function multisite_switch_site($hook_name, $entity_type, $return_value, $parameters) {
		global $CONFIG;
    
    
		$localsite = get_site_by_url("http://" . $_SERVER['SERVER_NAME']."/");
		if (!$localsite) {
    $localsite = get_site_by_url("http://www." . $_SERVER['SERVER_NAME']."/");
      if (!$localsite) {
      //at least see if this is a subfolder installation
      $folder = datalist_get('multisite_folder');
      $localsite = get_site_by_url("http://" . $_SERVER['SERVER_NAME']."/".$folder);
      }
      
    }
    $sid = $localsite->guid;

		//Load the site guid in the SESSION
		$_SESSION['sid'] = $sid;
		

          	return $sid;
		}


?>
