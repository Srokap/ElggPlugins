<?php

	/**
	 * Simple cache viewer for multisite
	 * Bypasses the engine to view simple cached CSS views.
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.org/
	 * Multisite implementation	 :
	 * Author Fabrice Collette fabrice.collette@free.fr
	 * $link http://www.meleze-conseil.com       
	 */

	// Get DB settings, connect
		require_once(dirname(dirname(__FILE__)). '/engine/settings.php');
		
		global $CONFIG, $viewinput, $override;
		if (!isset($override)) $override = false;
		
		$contents = '';
		if (!isset($viewinput)) $viewinput = $_GET;
		
     
		
		if ($mysql_dblink = @mysql_connect($CONFIG->dbhost,$CONFIG->dbuser,$CONFIG->dbpass, true)) {
		
      if (@mysql_select_db($CONFIG->dbname,$mysql_dblink)) {
  		$result = mysql_query("select value from {$CONFIG->dbprefix}datalists where name='multisite_folder'",$mysql_dblink);
  		$row = mysql_fetch_object($result);
      $folder = $row->value;
  
      $url = "http://" . $_SERVER['SERVER_NAME']."/".$folder;
    
      $result = mysql_query("select guid from {$CONFIG->dbprefix}sites_entity where url='$url'",$mysql_dblink);
			$row = mysql_fetch_object($result);	
			$id = $row->guid;
     }

			$view = $viewinput['view'];
			$viewtype = $viewinput['viewtype'];
			if (empty($viewtype)) $viewtype = 'default';
			
			if (@mysql_select_db($CONFIG->dbname,$mysql_dblink)) {
				// get dataroot and simplecache_enabled in one select for efficiency
				$simplecache_enabled = true;
				if (!isset($dataroot)) {
					if ($result = mysql_query("select name, value from {$CONFIG->dbprefix}datalists where name in ('dataroot','simplecache_enabled')",$mysql_dblink)) {
						$row = mysql_fetch_object($result);
						
						while ($row) {
							if ($row->name == 'dataroot') {
								$dataroot = $row->value;
							} else if ($row->name == 'simplecache_enabled') {
								$simplecache_enabled = $row->value;
							}
							$row = mysql_fetch_object($result);
						}
					}
				}
				
				if ($simplecache_enabled || $override) {
					$filename = $dataroot . 'views_simplecache_' . $id . '/' . md5($viewtype . $view);
					if (file_exists($filename)) {
						$contents = file_get_contents($filename);
						header("Content-Length: " . strlen($contents));
					 } else {
					 	mysql_query("INSERT into {$CONFIG->dbprefix}datalists set name = 'simplecache_lastupdate_'.$id, value = '0' ON DUPLICATE KEY UPDATE value='0'");
			
					 	echo ''; exit;
					 }
				} else {
					mysql_close($mysql_dblink);
					require_once(dirname(dirname(__FILE__)) . "/engine/start.php");    
					$contents = elgg_view($view);
					header("Content-Length: " . strlen($contents));
				}
			}
		}
		
		$split_output = str_split($contents, 1024);

    	foreach($split_output as $chunk)
        	echo $chunk; 


?>
