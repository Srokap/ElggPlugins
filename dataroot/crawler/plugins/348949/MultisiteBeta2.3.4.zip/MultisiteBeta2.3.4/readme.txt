multisite Beta 2.3 for elgg 1.5 and elgg 1.6


Content =

folder multisite

folder elgg15

folder elgg16



IMPORTANT

This plugin is based on the dynamic creation of subdomains.
So you have to :

- in your vhost : add an alias
- in your dns : add * A

If you are using wamp, you wont be able do create subdomains dynamicly so you have to pre-declare you subdomains in your windows/system32/drivers/etc/hosts file


Now go :

1) unzipp the multisitebeta23 folder somewhere on your local pc

2) unzipp the multisite folder in your mod directory and enable the plugin

If you run elgg 1.5 you should use the files il the elgg15 folder (folder elgg16 if you run elgg 1.6.1)

then

3) copy the files : multisite.php, elgglib.php, notification.php from the engine/lib folder to your site engine/lib folder


4) copy the files : start.php from the engine folder to your site engine folder

5) Replace simplecache/view.php with the simplecache/view.php provided with the plugin

Now the multisite feature should work and the caches (elgg_views and simplecache) are splitted in different directories, one simple_cache and one elgg_view cache by community


The following step are mandatory only if you want to split the logs and river data for each community(site).

6) add a new row to your river table, call it site_guid (bigint)
7)add a new row to your system_log table, call it site_guid (bigint)

8) copy the files : river2.php and system_log.php from engine/river$log_lib folder to your site's engine/lib folder


Now the river will give to a community the events that have been created in that community, and no other ones.



Then go to your site and :

9) go to admin->communities menu -> init multisite and init the plugin with your default value


10) go to admin->communities menu -> Plugin setting and set your installed plugins as global, local, theme or hidden

Have fun and join the multisite group on elgg.org to share your experience

Fabrice Collette (fabrice.collette@free.fr)