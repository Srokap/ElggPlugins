<?php
		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */


require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
gatekeeper();

// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}
$_SESSION['user']->multilogin_code = md5($_SESSION['user']->name . time() . rand());

//Add submenu
set_context('multisite');

$body = elgg_view_title(elgg_echo('multisite:yours'));
$body .= "<br />";
$offset = 0;
$count = get_entities("site","",0,"",999,0,true,-1,null);
$entities = get_entities("site","",0,"",$count,0,false,-1,null);
foreach ($entities as $entities){
	if ( check_entity_relationship($_SESSION['guid'],'member_of_site', $entities->guid)){
		$body .= "<div class=\"search_listing\">";
		$body .= "<div class=\"search_listing_icon\"><div class=\"usericon\">";
		$body .= "<a href=\"".$entities->url."mod/multisite/multilogin.php?id=".$_SESSION['user']->multilogin_code."\" class=\"icon\"><img src=\"".get_entity_icon_url ($entities,'large')."\" border=\"0\"></a></div></div>";
		$body .= "<div class=\"search_listing_info\">";
		$body .= "<p><h3><a href=\"".$entities->url."mod/multisite/multilogin.php?id=".$_SESSION['user']->multilogin_code."\">".$entities->name."</a></h3></p>";
		$body .= "<p>".$entities->description."</p>";
		$body .= "<p><a href=\"".$_SESSION['user']->username."/unregister/".$entities->guid."\">".elgg_echo('multisite:unregister')."</a> / <a href=\"".$entities->url."mod/multisite/multilogin.php?id=".$_SESSION['user']->multilogin_code."\">".elgg_echo('multisite:login')."</a>";
		$body .= "</p></div></div>";
	}
}
				


$area2 = $body;

// Format
	$body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	// Draw page
	echo page_draw(elgg_echo('this will be the page title'),$body);

?>