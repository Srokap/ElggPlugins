<?php

		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */
	
		function multisite_init() {
    		
			// Load system configuration
				global $CONFIG;
				$_SESSION['sid'] = $CONFIG->site_guid;
				$GLOBALS['multisite_set'] = true;
				
			// Load the language file
			register_translations($CONFIG->pluginspath . "multisite/languages/");
			// Extend system CSS with our own styles, which are defined in the ad/css view
			extend_view('css','multisite/css');

		//register various actions
		register_action("multisite/addsite",false,$CONFIG->pluginspath . "multisite/actions/addsite.php");
		register_action("multisite/settingsite",false,$CONFIG->pluginspath . "multisite/actions/setting_sites.php");
		register_action("multisite/localsetting",false,$CONFIG->pluginspath . "multisite/actions/localsetting.php");
		register_action("multisite/makelocaladmin",false,$CONFIG->pluginspath . "multisite/actions/admin/user/makelocaladmin.php");
		register_action("multisite/removelocaladmin",false,$CONFIG->pluginspath . "multisite/actions/admin/user/removelocaladmin.php");

		//override useradd, ban, unban, resetpassword and update_basic actions
		register_action("admin/site/update_basic",false,$CONFIG->pluginspath . "multisite/actions/update_basic.php");
		register_action("admin/user/ban",false,$CONFIG->pluginspath . "multisite/actions/admin/user/ban.php");
		register_action("admin/user/unban",false,$CONFIG->pluginspath . "multisite/actions/admin/user/unban.php");
		register_action("admin/user/resetpassword",false,$CONFIG->pluginspath . "multisite/actions/admin/user/resetpassword.php");
		register_action("useradd",false,$CONFIG->pluginspath . "multisite/actions/admin/useradd.php");

		//register a pam handler to handle loggin priviledges
		register_pam_handler("multisite_authenticate", "required");
		
		//register an algg event to manage intersite roaming
    register_elgg_event_handler('login', 'user', 'multisite_session_handler');
    
    //register an algg event to add a member_of_site relationship
    register_elgg_event_handler('create', 'user', 'multisite_membership_handler');
    
  // Register a plugin hook for multisite admin permissions
	register_plugin_hook('permissions_check','all','multisite_admin_permissions');
	register_plugin_hook('container_permissions_check','all','multisite_admin_permissions');
	
    
			

		// register plugin object
		add_subtype('object','community_plugin');


		// Register a page handler, so we can have nice URLs
		register_page_handler('multisite','multisite_page_handler');
		
		//override friends page handler
	  register_page_handler('friends','multisite_friends_page_handler');


		// Extend the elgg topbar for community admin
		if (is_community_creator()) {
			extend_view('elgg_topbar/extend','multisite/topbar');
		}
		
		//add multisite menu to the tools menu
		if (isloggedin()) {
              add_menu(elgg_echo('multisite:title'), $CONFIG->wwwroot . "pg/multisite/" . $_SESSION['user']->username);
		}
		
		 // Extend profile menu	
		extend_view('profile/menu/links','multisite/menu/user',950);
		extend_view('profile/menu/adminlinks','multisite/menu/admin');
	
	}

            function multisite_pagesetup() {
			
		global $CONFIG;
		
	  if (get_context() == 'admin' && isadminloggedin()) {
				add_submenu_item(elgg_echo('multisite:title'), $CONFIG->wwwroot . "pg/multisite/admin/adminmultisite");
				}
    if (get_context() == 'settings') {
              add_submenu_item(elgg_echo('multisite:title'), $CONFIG->wwwroot . "pg/multisite/" . $_SESSION['user']->username);
		}
		if (get_context() == 'localmultisite'){
		if (is_community_creator()){
			add_submenu_item(elgg_echo('multisite:localadmin:setting'), $CONFIG->wwwroot ."pg/multisite/admin/local/".$_SESSION['sid']);
			add_submenu_item(elgg_echo('multisite:localadmin:plugins'), $CONFIG->wwwroot ."pg/multisite/admin/localplugins/".$_SESSION['sid']);
			add_submenu_item(elgg_echo('multisite:localadmin:themes'), $CONFIG->wwwroot ."pg/multisite/admin/localthemes/".$_SESSION['sid']);
			add_submenu_item(elgg_echo('multisite:localadmin:users'), $CONFIG->wwwroot ."pg/multisite/admin/localusers/".$_SESSION['sid']);
			}
		}
		if (get_context() == 'multisite'){
		if (isloggedin()) {
 			add_submenu_item(elgg_echo('multisite:mysite'), $CONFIG->wwwroot ."pg/multisite/" . $_SESSION['user']->username);
			add_submenu_item(elgg_echo('multisite:allsites'), $CONFIG->wwwroot ."pg/multisite/" . $_SESSION['user']->username."/allsites");
			add_submenu_item(elgg_echo('multisite:createsites'), $CONFIG->wwwroot ."pg/multisite/" . $_SESSION['user']->username."/createsite");
			}
		}
		if (get_context() == 'adminmultisite'){
		if (isadminloggedin()){
			add_submenu_item(elgg_echo('multisite:update'), $CONFIG->wwwroot ."pg/multisite/admin/update");
			add_submenu_item(elgg_echo('multisite:plugins'), $CONFIG->wwwroot ."pg/multisite/admin/plugin");
			add_submenu_item(elgg_echo('multisite:manage:communities'), $CONFIG->wwwroot ."pg/multisite/admin/adminmultisite");
			add_submenu_item(elgg_echo('multisite:createsites'), $CONFIG->wwwroot ."pg/multisite/" . $_SESSION['user']->username."/createsite");
			}
		}
	}
		
		
		register_elgg_event_handler('init','system','multisite_init');
		register_elgg_event_handler('pagesetup','system','multisite_pagesetup');
		


		function multisite_page_handler($page) {
			
			// The first component is the username
			if (isset($page[0])) {
				
					set_input('username',$page[0]);
				} 
			
					// The second part dictates what we're doing
					if (isset($page[1])) {
					switch($page[1]) {
						case "allsites":			include(dirname(__FILE__) . "/list_sites.php"); return true;
											break;
						case "createsite":		include(dirname(__FILE__) . "/admin/create_site.php"); return true;
											break;
						case "unregister":		set_input('site',$page[2]);
											include(dirname(__FILE__) . "/unregister_to_site.php"); return true;
											break;
						case "register":			set_input('site',$page[2]);
											include(dirname(__FILE__) . "/register_to_site.php"); return true;
											break;
						case "login":			set_input('site',$page[2]);
											include(dirname(__FILE__) . "/multilogin.php"); return true;
											break;
						case "adminmultisite":		include(dirname(__FILE__) . "/admin/admin.php"); return true;
											break;
						case "update":			include(dirname(__FILE__) . "/update.php"); return true;
											break;
						case "plugin":			include(dirname(__FILE__) . "/admin/plugins.php"); return true;
											break;
						case "delete":			set_input('site',$page[2]);
											include(dirname(__FILE__) . "/admin/delete_sites.php"); return true;
											break;
						case "disable":			set_input('site',$page[2]);
											include(dirname(__FILE__) . "/admin/disable_sites.php"); return true;
											break;
						case "enable":			set_input('site',$page[2]);
											include(dirname(__FILE__) . "/admin/enable_sites.php"); return true;
											break;
						case "setting":			set_input('site',$page[2]);
											include(dirname(__FILE__) . "/admin/setting_sites.php"); return true;
											break;
						case "setplugin":			set_input('status',$page[2]);
											set_input('plugin',$page[3]);
											include(dirname(__FILE__) . "/admin/set_plugin.php"); return true;
											break;
						case "local":			set_input('site',$page[2]);
											include(dirname(__FILE__) . "/localadmin/localsetting.php"); return true;
											break;
						case "localplugins":		set_input('site',$page[2]);
											include(dirname(__FILE__) . "/localadmin/localplugins.php"); return true;
											break;
						case "localthemes":		set_input('site',$page[2]);
											include(dirname(__FILE__) . "/localadmin/localthemes.php"); return true;
											break;
						case "setlocalplugin":		set_input('setting',$page[2]);
											set_input('plugin',$page[3]);
											include(dirname(__FILE__) . "/localadmin/pluginsetting.php"); return true;
											break;
						case "setlocaltheme":		set_input('setting',$page[2]);
											set_input('plugin',$page[3]);
											include(dirname(__FILE__) . "/localadmin/themesetting.php"); return true;
											break;

						case "localusers":		set_input('site',$page[2]);
											include(dirname(__FILE__) . "/localadmin/localusers.php"); return true;
											break;




						}
					// If the URL is just 'multisite/username', or just 'multisite/', load the standard page
					
					}else {
						@include(dirname(__FILE__) . "/multisite.php"); return true;
						return true;
					}
			
			
			return false;
			
		}

		function multisite_friends_page_handler($page) {
			if (isset($page[0]) && $user = get_user_by_username($page[0])) {
			set_page_owner($user->getGUID());
        		}
        		 if ($_SESSION['guid'] == page_owner()) {
             		collections_submenu_items();
         		}
         		@include(dirname(__FILE__) . "/friends.php");
	
		}



		function is_community_creator($user_guid =0){
		if ($user_guid == 0) {
        $user_guid = $_SESSION['user']->guid;
        }
    $user = get_entity($user_guid);
		$cummunity_creator = get_entities_from_metadata('site_creator', $user_guid, 'site','', 0, 99, 0, '', -1, false);
		if (($cummunity_creator[0]->guid === $_SESSION['sid']) ||($user->admin)) 
			{
      return true;}
		else
			{
      return false;}
		}



		function multisite_authenticate($credentials = NULL) {
			global $CONFIG;
            	
	            if ($user = get_user_by_username($credentials['username'])) {
	            		            	
	            	if (($user->site_guid != $CONFIG->site_guid) && !check_entity_relationship($user->guid,'member_of_site', $CONFIG->site_guid)) {
							return false; }
      							if ($user->password == generate_user_password($user, $credentials['password'])){
      		        	return true;
      		        	}
      		    return false;
			}
			
		return false;
		}
		
		function is_member_of_site($user_id) {
		global $CONFIG;
		$user = get_entity($user_id);
		if (check_entity_relationship($user->guid,'member_of_site', $CONFIG->site_guid)) {
							return true; }
    return false;
    }
		
	//Roaming management - Thanks to vince
		function multisite_session_handler($event, $object_type, $user)
	{
	  
    		if (($user) && ($user instanceof ElggUser))
    		{
    			 
            if($user->code!= ''){
                $code=$user->code2;

            }
            else {
                $code = (md5($user->name . $user->username . time() . rand()));
            $user->code = md5($code);
                $user->code2 = $code;
            }
    		}
    
		return true;
	}



	//add a member_of_site relationship at user creation time
		function multisite_membership_handler($event, $object_type, $user)
	{
	  
    		if (($user) && ($user instanceof ElggUser))
    		{
    			 add_entity_relationship($user->guid,'member_of_site',$_SESSION['sid']);
    		}
    
		return true;
	}
	
	//give the multisite creator admin permissions so it is just a matter of giving him specific adminsite views
	function multisite_admin_permissions($hook, $type, $returnval, $params) {
		
		if (is_array($params) && !empty($params['user']) && $params['user'] instanceof ElggUser) {
			if (is_community_creator($params['user']->guid))
			{return true;}
		}
		
	}
	
	//make a specific multisite admin gatekeeper for local admin tools
	function multisite_admin_gatekeeper()
		{
			gatekeeper();
			if (!is_community_creator()) {
				$_SESSION['last_forward_from'] = current_page_url();
				forward();
			}
		}

?>