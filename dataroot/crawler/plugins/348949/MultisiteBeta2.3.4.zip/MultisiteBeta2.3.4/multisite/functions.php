<?php

	/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
global $CONFIG;

//This function return a formated associative array with all the site options
function get_multisite_option($value){
$settings = explode ('|', $value);
foreach ($settings as $s){
  $key = explode (':',$s);
  switch ($key[0]) {
    case "r": $r=$key[1]; break;
    case "t": $t=$key[1]; break;
    case "d": $d=$key[1]; break;
    case "f": $f=$key[1]; break;
    case "m": $m=$key[1]; break;
    case "n": $n=$key[1]; break;
    case "domain": $domain=$key[1]; break;
    case "o": $o=$key[1]; break;
  }
}

$return_value = array(
			registering => $r,
			membership => $t,
			date_end => $d,
			fee => $f,
			maxusers => $m,
			nbrusers => $n,
			domain => $domain, 
			icn => $o
			);


return $return_value;
}

function close_community($community_guid){

$community = get_entity ($community_guid);
$community_setting = $community->site_setting;
$options = get_multisite_option($community_setting);

$r = $options['registering'];
$t = $options['membership'];
$d = $options['date_end'];
$f = $options['fee'];
$m = $options ['maxusers'];
$n = $options['nbrusers'];
$domain = $options['domain']; 
$o = $options['icn'];

//set to close
$site_setting = "r:c|t:".$t."|d:".$d."|f:".$f."|m:".$m."|n:".$n."|domain:".$domain."|o:".$o;
$community->site_setting = $site_setting;

return true;
}


function open_community($community_guid){
$community = get_entity ($community_guid);
$community_setting = $community->site_setting;
$options = get_multisite_option($community_setting);

$r = $options['registering'];
$t = $options['membership'];
$d = $options['date_end'];
$f = $options['fee'];
$m = $options ['maxusers'];
$n = $options['nbrusers'];
$domain = $options['domain']; 
$o = $options['icn'];

//set to open
$site_setting = "r:o|t:".$t."|d:".$d."|f:".$f."|m:".$m."|n:".$n."|domain:".$domain."|o:".$o;
$community->site_setting = $site_setting;

return true;
}

function is_community_open($community_guid){
$community = get_entity ($community_guid);
$community_setting = $community->site_setting;
$options = get_multisite_option($community_setting);

if ($options['registering'] != "o") { $return_value = 1; }else{$return_value = 0;}

return $return_value;
}


function update_plugin_list() {

//check if a plugin list has already been generated. If not, create plugin objects

global $CONFIG;

//Get the installed plugin 
$plugin = array();
						
	if ($handle = opendir($CONFIG->pluginspath)) {
				while ($mod = readdir($handle)) {
					if (!in_array($mod,array('.','..','.svn','CVS')) && is_dir($CONFIG->pluginspath . "/" . $mod)) {
						$plugin[] = $mod;
						}
					}
				}

if (!datalist_get("plugin_list")) {

	datalist_set("plugin_list",1);
	//$plugin = get_plugin_list();

	//create an object plugin
	foreach ($plugin as $p) {
	// Initialise a new ElggObject
			$obj = new ElggObject();
			$obj->subtype = "community_plugin";
			$obj->owner_guid = 1;
			$obj->access_id = 2;
			$obj->title = $p;
			$obj->description = $p;
			$obj->save();

		//initialise plugin status to hidden
			$obj->plugin_status = "hidden";
		}
   }else {
	
	//update the plugin object list
	$count = get_entities("object", "community_plugin", 0, "", 99, 0, true, -1, null);
	$community_plugin = get_entities("object", "community_plugin", 0, "", $count, 0, false, -1, null);
	
	//add a new plugin object if a new plugin has been added
	foreach ($plugin as $p) {

		$find = 0;	
		foreach ($community_plugin as $c) {
			if ($p == $c->title) {
				$find = 1;
				break;
				}
			}
		if ($find != 1) {
		// Initialise a new ElggObject
			$obj = new ElggObject();
			$obj->subtype = "community_plugin";
			$obj->owner_guid = 1;
			$obj->access_id = 2;
			$obj->title = $p;
			$obj->description = $p;
			$obj->save();
		//initialise plugin status to hidden
			$obj->plugin_status = "hidden";
		}
	}

	
	//delete plugin object if no more in the plugin list
	foreach ($community_plugin as $c) {
		$find = 0;
		foreach ($plugin as $p) {
			if ($p == $c->title) {
				$find = 1; 
        break;
			}
		}
		if (!($find == 1)) {
		// delete plugin object
			//$res = delete_data("DELETE from {$CONFIG->dbprefix}entities where guid={$c->guid}");
			delete_entity($c->getGUID(), false);
		}
	}
}

return true;

}	



function set_plugin_status($plugin_guid, $status){
$plugin_guid = (int)$plugin_guid;
$plugin = get_entity ($plugin_guid);
//if status is set to global enable plugin in all communities
	if ($status == "global") {
		$count = get_entities("site", "", 0, "", 999, 0, true, -1, null);
		$communities = get_entities("site", "", 0, "", $count, 0, false, -1, null);
		foreach ($communities as $c) {
			if (!is_plugin_enabled($plugin->title,$c->getGUID())) {enable_plugin($plugin->title,$c->getGUID());}
		}
	}

	if ($status == "hidden") {
		//assume site 1 is the main site and dont change any plugin setting there
		$main_site_guid = 1;
		$count = get_entities("site", "", 0, "", 999, 0, true, -1, null);
		$communities = get_entities("site", "", 0, "", $count, 0, false, -1, null);
		foreach ($communities as $c) {
			$c_guid = $c->guid;
			if ($c->guid != $main_site_guid) {
				if (is_plugin_enabled($plugin->title,$c->getGUID())) {disable_plugin($plugin->title,$c->getGUID());}
			}
		}
	}


$plugin->plugin_status = $status;
return true;
}

function get_plugin_status($plugin_guid){
$plugin = get_entity ($plugin_guid);
$status = get_metadata_byname ((int)$plugin_guid,"plugin_status");
if ($status != false) { $status = $plugin->plugin_status;}
return $status;
}

function is_multiplugin_enabled ($plugin, $site_id) {

$plugin_enabled = get_multisite_metadata_byname($site_id,  'enabled_plugins', $site_id);

	foreach($plugin_enabled as $p){
		if ($p == $plugin){return true;}
	}
return false;
}

function get_multisite_metadata_byname($entity_guid, $meta_name, $site_guid = 0)
	{
		global $CONFIG;
	
		$meta_name = get_metastring_id($meta_name);
		
		if (empty($meta_name)) return false;
		
		$entity_guid = (int)$entity_guid;
		//start hack multisite
		$access = get_multisite_access_sql_suffix("e", $site_guid);
		$md_access = get_multisite_access_sql_suffix("m", $site_guid);
		//end hack multisite
		// If memcache is available then cache this (cache only by name for now since this is the most common query)
		$meta = null;
		static $metabyname_memcache;
		if ((!$metabyname_memcache) && (is_memcache_available()))
			$metabyname_memcache = new ElggMemcache('metabyname_memcache');
		if ($metabyname_memcache) $meta = $metabyname_memcache->load("{$entity_guid}:{$meta_name}");
		if ($meta) return $meta;	

		$result = get_data("SELECT m.*, n.string as name, v.string as value from {$CONFIG->dbprefix}metadata m JOIN {$CONFIG->dbprefix}entities e ON e.guid = m.entity_guid JOIN {$CONFIG->dbprefix}metastrings v on m.value_id = v.id JOIN {$CONFIG->dbprefix}metastrings n on m.name_id = n.id where m.entity_guid=$entity_guid and m.name_id='$meta_name' and $access and $md_access", "row_to_elggmetadata");
		if (!$result) 
			return false;
			
		// Cache if memcache available
		if ($metabyname_memcache)
		{ 
			if (count($result) == 1) $r = $result[0]; else $r = $result;
			$metabyname_memcache->setDefaultExpiry(3600); // This is a bit of a hack - we shorten the expiry on object metadata so that it'll be gone in an hour. This means that deletions and more importantly updates will filter through eventually.
			$metabyname_memcache->save("{$entity_guid}:{$meta_name}", $r);
			
		}
		if (count($result) == 1)
			return $result[0];
			
		return $result;
	}

function get_multisite_access_sql_suffix($table_prefix = "", $site_id=0){

			global $ENTITY_SHOW_HIDDEN_OVERRIDE;  
			
			$sql = "";
			
			if ($table_prefix)
					$table_prefix = sanitise_string($table_prefix) . ".";
			
				//start multisite hack
				$access = get_access_list(0, $site_id);
				//end multisite hack
				
				$owner = get_loggedin_userid();
				if (!$owner) $owner = -1;
				
				global $is_admin;
				
				if (isset($is_admin) && $is_admin == true) {
					$sql = " (1 = 1) ";
				}

				if (empty($sql))
					$sql = " ({$table_prefix}access_id in {$access} or ({$table_prefix}access_id = 0 and {$table_prefix}owner_guid = $owner))";

			if (!$ENTITY_SHOW_HIDDEN_OVERRIDE)
				$sql .= " and {$table_prefix}enabled='yes'";
			
			return $sql;
		}


		
?>