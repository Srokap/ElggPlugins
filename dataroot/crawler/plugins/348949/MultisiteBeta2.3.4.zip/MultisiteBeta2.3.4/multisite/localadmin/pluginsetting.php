<?php
	/**
	 * Elgg Multisite 2.3.5
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com
	 */
require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require_once (dirname(dirname(__FILE__)) . "/functions.php");

global $CONFIG;

multisite_admin_gatekeeper();

update_plugin_list();

$setting = get_input('setting');
$plugin_id = (int)get_input('plugin');
$plugin = get_entity($plugin_id);

switch ($setting) {
	case "enable" : 	if (!is_plugin_enabled($plugin->title,$CONFIG->site_guid)) {enable_plugin($plugin->title); system_message(elgg_echo('multisite:localplugin:enable_ok'));}
				break;
	case "disable" : 	if (is_plugin_enabled($plugin->title,$CONFIG->site_guid)) {disable_plugin($plugin->title); system_message(elgg_echo('multisite:localplugin:disable_ok'));}
				break;
}



elgg_view_regenerate_simplecache();

//regenerate plugin caches. thanks to Chris Ghere

$cache = elgg_get_filepath_cache();
$cache->delete('view_paths');

forward("pg/multisite/admin/localplugins/".$CONFIG->site_guid);

?>