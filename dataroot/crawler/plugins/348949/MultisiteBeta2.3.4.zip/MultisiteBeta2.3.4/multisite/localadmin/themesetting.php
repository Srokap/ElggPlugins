<?php
		/**
	 * Elgg Multisite 2.3.5
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com
	 */
require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require_once (dirname(dirname(__FILE__)) . "/functions.php");

global $CONFIG;

multisite_admin_gatekeeper();

update_plugin_list();

$setting = get_input('setting');
$plugin_id = (int)get_input('plugin');
$plugin = get_entity($plugin_id);

switch ($setting) {
	case "enable" : 	if (!is_plugin_enabled($plugin->title,$CONFIG->site_guid)) {enable_theme($plugin);system_message(elgg_echo('multisite:localplugin:enable_ok'));}
				break;
	case "disable" : 	if (is_plugin_enabled($plugin->title,$CONFIG->site_guid)) {disable_plugin($plugin->title); system_message(elgg_echo('multisite:localplugin:disable_ok'));}
				break;
}


elgg_view_regenerate_simplecache();


//regenerate plugin caches. thanks to Chris Ghere  
$cache = elgg_get_filepath_cache();
$cache->delete('view_paths');

forward("pg/multisite/admin/localthemes/".$CONFIG->site_guid);

function enable_theme($theme) {
    $count = get_entities("object","community_plugin",0,"",999,0,true,-1,null);
    $entities = get_entities("object","community_plugin",0,"",$count,0,false,-1,null);
    foreach ($entities as $entity){
      if (get_plugin_status($entity->guid) == "theme"){
            if (is_plugin_enabled($entity->title,$CONFIG->site_guid)) {disable_plugin($entity->title);}
            }
    }
    enable_plugin($theme->title);
    return true;
}


?>