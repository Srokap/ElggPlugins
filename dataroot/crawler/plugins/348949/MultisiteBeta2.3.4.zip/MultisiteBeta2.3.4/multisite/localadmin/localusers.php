<?php

	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */
		

	// Get the Elgg framework
		require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
		global $CONFIG;

	// Make sure only valid admin users can see this
		gatekeeper();
		
	// Set admin user for user block
	//	set_page_owner($_SESSION['guid']);

	// Are we performing a search
		$search = get_input('s');
		$limit = get_input('limit', 10);
		$offset = get_input('offset', 0);
		
		set_context('localmultisite');
		
		$title = elgg_view_title(elgg_echo('admin:user'));
		
		set_context('search');
		
		//list members of site
		//$result = list_entities('user');
		//$result = list_entities_from_relationship('member_of_site',$CONFIG->site_guid,true,'user','',0,99999,false,false, true, 0);
		$limit = 99999;
		$offset = 0;
		$count = get_entities_from_relationship('member_of_site', $CONFIG->site_guid, true, 'user', '', 0, "", $limit, $offset, true, -1);
		$entities = get_entities_from_relationship('member_of_site', $CONFIG->site_guid, true, 'user', '', 0, "", $limit, $offset, false, -1);

		$result = elgg_view_entity_list($entities, $count, $offset, $limit, false, false, true);

		
		set_context('admin');
			
	// Display main admin menu
		page_draw(elgg_echo("admin:user"),
						elgg_view_layout("two_column_left_sidebar", 
										'', 
										$title . elgg_view("multisite/localuser") . $result)
										);

?>