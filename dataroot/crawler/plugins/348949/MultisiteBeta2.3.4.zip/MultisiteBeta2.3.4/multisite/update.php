<?php
		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */


require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
admin_gatekeeper();

// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}


//Add submenu
set_context('adminmultisite');

$body = elgg_view_title(elgg_echo('multisite:update_title'));
$body .= elgg_view('multisite/forms/update');

				


$area2 = $body;

// Format
	$body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	// Draw page
	echo page_draw(elgg_echo('multisite:update_title'),$body);

?>