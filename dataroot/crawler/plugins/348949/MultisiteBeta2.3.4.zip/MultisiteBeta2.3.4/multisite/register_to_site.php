<?php
		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */


require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
gatekeeper();

//include multisite functions
require_once (dirname(__FILE__) . "/functions.php");


$dest_site = (int)get_input('site');

$user_guid = $_SESSION['guid'];

if (is_community_open($dest_site) == 0) {
	add_entity_relationship($user_guid,'member_of_site',$dest_site);
	system_message(elgg_echo('multisite:register_ok'));
	} else {
	system_message(elgg_echo('multisite:register_close'));
	}
	


forward("pg/multisite/".$_SESSION['user']->username);

?>