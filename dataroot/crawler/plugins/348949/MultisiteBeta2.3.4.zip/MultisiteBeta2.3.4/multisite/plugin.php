<?php
		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
gatekeeper();

	require_once (dirname(__FILE__) . "/functions.php");


// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}


//Add submenu
set_context('multisite');

$body = elgg_view_title(elgg_echo('multisite:yours'));
$body .= "<br />";
$offset = 0;
$plugins = get_plugin_list();
				
	foreach($plugins as $mod) {
		if (is_plugin_enabled($mod,$CONFIG->site_guid)) {
			$body .= $mod."<br />";
		}		
	}

$area2 = $body;

// Format
	$body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	// Draw page
	echo page_draw(elgg_echo('this will be the page title'),$body);

?>