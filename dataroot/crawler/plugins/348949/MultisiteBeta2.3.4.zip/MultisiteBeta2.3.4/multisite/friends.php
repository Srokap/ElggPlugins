<?php

		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */
		global $CONFIG;
		if (!$owner = page_owner_entity()) {
			gatekeeper();
			set_page_owner($_SESSION['user']->getGUID());
			$owner = $_SESSION['user'];
		}
		//$area1 = elgg_view_title(elgg_echo('friends'));
		//$area2 = list_entities_from_relationship('friend',$owner->getGUID(),false,'user','',0,10,false);
		$community_guid = $CONFIG->site_guid;
		
		set_input('community',$community_guid);
		set_input('owner_guid',$owner->getGUID());
		$area2 = elgg_view('multisite/forms/friends');
		$body = elgg_view_layout('two_column_left_sidebar', '', $area2);
		
		echo page_draw(elgg_echo("friends:owned"),$body);

?>