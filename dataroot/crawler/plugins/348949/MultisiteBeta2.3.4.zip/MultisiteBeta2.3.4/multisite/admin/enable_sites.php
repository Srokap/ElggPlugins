<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */
require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require_once (dirname(dirname(__FILE__)) . "/functions.php");

$dest_site = get_input('site');


open_community((int)$dest_site);
system_message(elgg_echo('multisite:enable_ok'));

forward("pg/multisite/admin/adminmultisite");

?>