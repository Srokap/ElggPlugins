<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */


	require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

	gatekeeper();
	set_context('adminmultisite');
	// Set admin user for user block
	set_page_owner($_SESSION['guid']);
	$title = elgg_view_title(elgg_echo('multisite:create_site_title'));
	$body = elgg_view('multisite/forms/addsite');
	//$body = "hello";	
	$area2 = $title.$body;
	$area1 = "";
	
	
	echo page_draw('titre de la page',elgg_view_layout("two_column_left_sidebar", $area1, $area2));
?>