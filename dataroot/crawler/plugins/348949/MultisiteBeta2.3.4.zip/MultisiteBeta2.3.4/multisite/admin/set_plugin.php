<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */
require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require_once (dirname(dirname(__FILE__)) . "/functions.php");

$status = get_input('status');
$plugin_guid = get_input('plugin');

set_plugin_status($plugin_guid, $status);

system_message(elgg_echo('multisite:plugin:update_ok'));

forward("pg/multisite/admin/plugin");

?>