<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */


require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require_once (dirname(dirname(__FILE__)) . "/functions.php");

admin_gatekeeper();

//get data
$domain = get_input('domain_name');
$network = get_input('network');
$folder = get_input('folder');

//Make sure that $domain has been set
if (empty($domain)) {
  system_message(elgg_echo("multisite:configuration:mandatorydomain"));
	$forward = "pg/multisite/" . $_SESSION['user']->username."/update";
	forward($forward);
}

$multisite_default_data = "r:o|t:a|d:0|f:0|m:0|n:0|domain:".$domain."|o:out";

datalist_set("multisite_default_data", $multisite_default_data);
datalist_set("multisite_default_network", $network);
if (!empty($folder)){
      datalist_set("multisite_folder", $folder);
      }


//update sites - manage several site just in case ... Only one site should be updated cause this is the first step of multisite installation
$offset = 0;
$count = get_entities("site","",0,"",999,0,true,-1,null);
$entities = get_entities("site","",0,"",$count,0,false,-1,null);

foreach ($entities as $entities){
	if ($entities->site_setting == "") {$entities->site_setting = datalist_get("multisite_default_data");}
	if ($entities->community_network == "") {$entities->community_network = $network;}

}

//update users - add a member_of_site relationship which is the basis of membership in multisite

$offset = 0;
$count = get_entities("user","",0,"",99999,0,true,-1,null);
$entities = get_entities("user","",0,"",$count,0,false,-1,null);

foreach ($entities as $entities){
if (!check_entity_relationship($entities->guid,'member_of_site',$entities->site_guid)){
	add_entity_relationship($entities->guid,'member_of_site',$entities->site_guid);
	}
}

//create or update plugin list
update_plugin_list();

	
system_message(elgg_echo('multisite:update_ok'));

forward("pg/multisite/admin/adminmultisite");			

?>