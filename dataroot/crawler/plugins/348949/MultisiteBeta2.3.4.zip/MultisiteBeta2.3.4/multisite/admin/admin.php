<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */


require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require_once (dirname(dirname(__FILE__)) . "/functions.php");

admin_gatekeeper();

// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}


//Add submenu
set_context('adminmultisite');

$body = elgg_view_title(elgg_echo('multisite:manage:communities'));
$body .= "<br />";
$offset = 0;
$count = get_entities("site","",0,"",999,0,true,-1,null);
$entities = get_entities("site","",0,"",$count,0,false,-1,null);
foreach ($entities as $entities){

$body .= "<div class=\"search_listing\">";
$body .= "<div class=\"search_listing_icon\"><div class=\"usericon\">";
$body .= "<a href=\"".$entities->url."\" class=\"icon\"><img src=\"".get_entity_icon_url ($entities,'large')."\" border=\"0\"></a></div></div>";
$body .= "<div class=\"search_listing_info\">";
$body .= "<p><h3><a href=\"".$entities->url."\">".$entities->name."</a></h3></p>";
$body .= "<p>".$entities->description."</p>";



if (is_community_open($entities->guid) == 0){
	$body .= "<a href=\"disable/".$entities->guid."\">".elgg_echo('multisite:disable')."</a> | <a href=\"delete/".$entities->guid."\">".elgg_echo('multisite:delete')."</a> | <a href=\"setting/".$entities->guid."\">".elgg_echo('multisite:setting')."</a>"; 
	} else {
	$body .= "<a href=\"enable/".$entities->guid."\">".elgg_echo('multisite:enable')."</a> | <a href=\"delete/".$entities->guid."\">".elgg_echo('multisite:delete')."</a> | <a href=\"setting/".$entities->guid."\">".elgg_echo('multisite:setting')."</a>"; 
	}

$body .= "</p></div></div>";

}
				


$area2 = $body;

// Format
	$body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	// Draw page
	echo page_draw(elgg_echo('multisite:manage:communities'),$body);

?>