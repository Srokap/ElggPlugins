<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */


require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
require_once (dirname(dirname(__FILE__)) . "/functions.php");

//get data
$domain = get_input('domain_name');
$network = get_input('network');

$multisite_default_data = "r:o|t:a|d:0|f:0|m:0|n:0|domain:".$domain."|o:out";

datalist_set("multisite_default_data", $multisite_default_data);

//create or update plugin list
update_plugin_list();


//update sites
$offset = 0;
$count = get_entities("site","",0,"",999,0,true,-1,null);
$entities = get_entities("site","",0,"",$count,0,false,-1,null);

foreach ($entities as $entities){
	if ($entities->site_setting == "") {$entities->site_setting = datalist_get("multisite_default_data");}
	if ($entities->community_network == "") {$entities->community_network = $network;}
	//Register site creator metadata
	if ($entities->owner_guid != 0) {$entities->site_creator = $entities->owner_guid; update_entity($entities->guid, 0, 2);}

}

//Set all global plugins
$main_site_guid = 1;
$plugin = get_plugin_list();
$count = get_entities("object", "community_plugin", 0, "", 99, 0, true, -1, null);
$community_plugin = get_entities("object", "community_plugin", 0, "", $count, 0, false, -1, null);
$offset = 0;
$count = get_entities("site","",0,"",999,0,true,-1,null);
$entities = get_entities("site","",0,"",$count,0,false,-1,null);
foreach ($entities as $e){
	if ($e->guid != $main_site_guid) {
		foreach ($community_plugin as $p) {
			if ($p->plugin_status == "global") {
				if (!is_multiplugin_enabled ($p->title, $e->getGUID())) {enable_plugin($p->title,$e->getGUID());}
			}
		}
	}
}


//update users

$offset = 0;
$count = get_entities("user","",0,"",99999,0,true,-1,null);
$entities = get_entities("user","",0,"",$count,0,false,-1,null);

foreach ($entities as $entities){
if (!check_entity_relationship($entities->guid,'member_of_site',$entities->site_guid)){
	add_entity_relationship($entities->guid,'member_of_site',$entities->site_guid);
	}
}



	
system_message(elgg_echo('multisite:update_ok'));

forward("pg/multisite/admin/adminmultisite");			

?>