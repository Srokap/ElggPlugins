<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */
require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

$dest_site = get_input('site');

//avoid to delete the site n�1 and the site you are currently logged in

if (!($dest_site == 1) && !($_SESSION['sid'] == $dest_site)) {
delete_entity((int)$dest_site);
system_message(elgg_echo('multisite:delete_ok'));
}
else {
system_message(elgg_echo('multisite:delete_not_ok'));
}

forward("pg/multisite/admin/adminmultisite");

?>