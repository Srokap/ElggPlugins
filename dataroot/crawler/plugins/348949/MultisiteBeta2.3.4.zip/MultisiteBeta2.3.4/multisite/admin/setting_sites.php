<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */


	require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

	admin_gatekeeper();
	set_context('adminmultisite');
	// Set admin user for user block
	set_page_owner($_SESSION['guid']);

	$dest_site = (int)get_input('site');
	set_input('site',$dest_site);

	$community = get_entity($dest_site);
	$community_name = $community->name;
	$title = elgg_echo('multisite:setting_site_title')." : ".$community_name;

	$title = elgg_view_title($title);

	$body = elgg_view('multisite/forms/setting_sites');
	$area2 = $title.$body;
	$area1 = "";
	
	
	echo page_draw('titre de la page',elgg_view_layout("two_column_left_sidebar", $area1, $area2));
?>