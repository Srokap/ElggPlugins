<?php

	/**
	 * Elgg recommandation plugin
	 * 
	 * @founded by Fondation Maison des Sciences de l'Homme - Paris
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 * 	 
	 */
	 
	 if (!is_community_creator($vars['entity']->guid)) { 
						echo elgg_view('output/confirmlink', array('text' => elgg_echo("makelocaladmin"), 'href' => "{$vars['url']}action/multisite/makelocaladmin?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts"));
				} else {
					echo elgg_view('output/confirmlink', array('text' => elgg_echo("removelocaladmin"), 'href' => "{$vars['url']}action/multisite/removelocaladmin?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts"));
				}

?>
