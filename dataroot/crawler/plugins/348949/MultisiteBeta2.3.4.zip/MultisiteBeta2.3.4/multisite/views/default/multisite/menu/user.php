<?php
	/**
	 * Profile multisite admin context links
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 * 	 
	 * @uses $vars['entity'] The user entity
	 */
      
			if (!isadminloggedin() && is_community_creator() && !$vars['entity']->admin){
				if ($_SESSION['id']!=$vars['entity']->guid){
					
					$ts = time();
					$token = generate_action_token($ts);
					$site = get_entity($_SESSION['sid']);
					
?>
				<p class="user_menu_admin">
        <a href="<?php echo $vars['url']; ?>pg/settings/user/<?php echo $vars['entity']->username; ?>/"><?php echo elgg_echo('profile:editdetails'); ?></a>
				<?php 
				if (!$vars['entity']->isBanned()) {
					echo elgg_view('output/confirmlink', array('text' => elgg_echo("ban"), 'href' => "{$vars['url']}action/admin/user/ban?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts"));
				} else {
					echo elgg_view('output/confirmlink', array('text' => elgg_echo("unban"), 'href' => "{$vars['url']}action/admin/user/unban?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts")); 
				}
				
				echo elgg_view('output/confirmlink', array('text' => elgg_echo("resetpassword"), 'href' => "{$vars['url']}action/admin/user/resetpassword?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts"));
				
				if (!is_community_creator($vars['entity']->guid)) { 
						echo elgg_view('output/confirmlink', array('text' => elgg_echo("makelocaladmin"), 'href' => "{$vars['url']}action/multisite/makelocaladmin?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts"));
				} else {
					echo elgg_view('output/confirmlink', array('text' => elgg_echo("removelocaladmin"), 'href' => "{$vars['url']}action/multisite/removelocaladmin?guid={$vars['entity']->guid}&__elgg_token=$token&__elgg_ts=$ts"));
				}
			}
		}
?>
      </p>