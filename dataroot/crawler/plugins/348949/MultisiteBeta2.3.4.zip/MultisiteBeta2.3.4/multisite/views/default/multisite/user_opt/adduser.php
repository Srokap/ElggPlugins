<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */

?>

<div class="admin_adduser_link">
	<a href="#" onclick="$('#add_user_showhide').toggle()"><?php echo elgg_echo('admin:user:adduser:label'); ?></a>
</div>
<div id="add_user_showhide" style="display:none" >
<?php echo elgg_view('multisite/forms/useradd', array('show_admin'=>true)); ?>
</div>