<?php

?>
<div id="topmargin" style="min-height:15px;"></div>
<div class="contentWrapper">
<big><span style="font-weight: bold;">This is a sandbox to test the multisite feature of the <a href="http://www.elgg.org"
 target="_blank">Elgg open source social network</a> :</span></big><br>
The multisite plugin in use here is brought to the elgg community by Fabrice Collette at <a href="http://www.meleze-conseil.com"
 target="_blank">Meleze Conseil</a>
<br><br>
<big><span style="font-weight: bold;">Vous êtes sur un bac à sable de test des fonctionalités multisite du <a href="http://www.elgg.org"
 target="_blank">réseau social open source Elgg</a> :</span></big><br>
Le module multisite utilisé ici est apporté à la communauté Elgg par Fabrice Collette de <a href="http://www.meleze-conseil.com"
 target="_blank">Meleze Conseil</a>
<br>
</div>