<?php
	/**
	 * Elgg multisite plugin
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net/
	 */

	global $CONFIG;

	//include multisite functions
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/functions.php");

	// set actual values
	$domain = "";
	$network = "no";
	//$community = get_entity($CONFIG->site_guid);
	$multisite_default_data = datalist_get("multisite_default_data");
	$multisite_default_network = datalist_get("multisite_default_network");
	$folder = datalist_get("multisite_folder");
		$options = get_multisite_option($multisite_default_data);
		$domain = $options['domain'];
		$network = $multisite_default_network;
	
	$form_body = "<div class=\"contentWrapper\">";
  $form_body .= elgg_echo('multisite:update_message');
	$form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:defaultsetting:message')."</h3>";
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= elgg_echo('multisite:defaultsetting:domain')." : ";
	$form_body .= "<input type=\"text\" size=\"80\" name=\"domain_name\" value=$domain>";
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= elgg_echo('multisite:defaultsetting:folder')." : ";
	$form_body .= "<input type=\"text\" size=\"80\" name=\"folder\" value=$folder>";
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= elgg_echo('multisite:defaultsetting:network')." : ";
	$form_body .= "<input type=\"text\" size=\"80\" name=\"network\" value=$network>";
	$form_body .= "</p>";

	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('multisite:submit_update')));
	$form_body .= "<div>";
	
	echo elgg_view('input/form', array('body' => $form_body, 'action' => $vars['url'].'mod/multisite/admin/update.php'));
?>