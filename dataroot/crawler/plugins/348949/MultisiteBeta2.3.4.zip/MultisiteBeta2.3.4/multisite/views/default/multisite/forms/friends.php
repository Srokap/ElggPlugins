<?php
	/**
	 * Elgg multisite plugin
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net/
	 */

require_once(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/engine/start.php");


//include multisite functions
require_once (dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/functions.php");
global $CONFIG;

//get the community
$community = get_input('community');
$owner_guid = get_input('owner_guid');
$owner = get_entity($owner_guid);

//$action = $vars['url'].'pg/friends/actions/'.$_SESSION['user']->username.'/friends.php';


// get communities where the user is registered to
$count = get_entities_from_relationship("member_of_site",$owner->getGUID(),false,"site","",0,"",999,0,true, -1);
$communities = get_entities_from_relationship('member_of_site',$owner->getGUID(),false,'site','',0,'',$count,0,false, -1);

//check if the page has been called from the form
if (isset ($_POST['liste_communities'])) {
	$community = $_POST['liste_communities'];
	if (!$owner = page_owner_entity()) {
			gatekeeper();
			set_page_owner($_SESSION['user']->getGUID());
			$owner = $_SESSION['user'];
		}
	if ($_SESSION['guid'] == page_owner()) {
             		collections_submenu_items();
		}

}
$title = elgg_echo('multisite:friends:title');
$title .= get_entity($community)->name;
$body = elgg_view_title($title);
echo $body;

?>

<form action="friends.php" method="POST">
<?php echo elgg_echo('multisite:friends:select'); ?>
<select name="liste_communities">
<?php
foreach ($communities as $c) {
?>
  <option value="<?php echo $c->guid; ?>"><?php echo $c->name; ?></option>
<?php
}
?>
</select>
<input type="submit" value="Go"> 
</form>
<br />


<?php

	// get the friends list in this community
	$count = get_entities_from_relationship("friend",$owner->getGUID(),false,"user","",0,"",999,0,true, -1);
	$friends = get_entities_from_relationship('friend',$owner->getGUID(),false,'user','',0,'',$count,0,false, -1);

	$local_friends = array();


	foreach ($friends as $f) {
		if (check_entity_relationship($f->guid,'member_of_site',$community)) {$local_friends[] = $f;}
	}
	
	$body = elgg_view_entity_list($local_friends, sizeof($local_friends), 0, 99999, true, false);

	echo $body;
?>