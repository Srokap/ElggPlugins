<?php
	/**
	 * Elgg multisite plugin
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net/
	 */
	//include multisite functions
	require_once (dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/functions.php");
	global $CONFIG;

	
	//get the community options
	$community = get_entity($CONFIG->site_guid);
	$community_setting = $community->site_setting;
	$options = get_multisite_option($community_setting);
	


	if (is_community_open($CONFIG->site_guid) == 0) {

		$form_body = "<br /><p>";
		$form_body .= elgg_echo('multisite:sitestatus:open');
		$form_body .= " ---> ";
		$form_body .= elgg_echo('multisite:sitestatus:changestatus');
		$form_body .= elgg_view('input/pulldown', array('internalname' => 'sitestatus', 'options' => array ('Open','Close')));
		$form_body .="</p>";

	} else {
		
		$form_body = "<br /><p>";
		$form_body .= elgg_echo('multisite:sitestatus:close');
		$form_body .= " ---> ";
		$form_body .= elgg_echo('multisite:sitestatus:changestatus');
		$form_body .= elgg_view('input/pulldown', array('internalname' => 'sitestatus', 'options' => array ('Close','Open')));
		$form_body .="</p>";
	}

		
		$form_body .= "";
		foreach(array('sitename','sitedescription') as $field) {
			$form_body .= "<p>";
			$form_body .= "<h4>" . elgg_echo('installation:' . $field) . "</h4>";
			$warning = elgg_echo('installation:warning:' . $field);
			if ($warning != 'installation:warning:' . $field) echo "<b>" . $warning . "</b><br />";
			$value = $vars['config']->$field;
			$form_body .= elgg_view("input/text",array('internalname' => $field, 'value' => $value));
			$form_body .= "</p>";
		}
		
		
	
		
		$languages = get_installed_translations();
		$form_body .= "<p></p><p>" . elgg_echo('installation:language') . elgg_view("input/pulldown", array('internalname' => 'language', 'value' => $vars['config']->language, 'options_values' => $languages)) . "</p>";		
		
		
		$form_body .= elgg_view('input/hidden', array('internalname' => 'settings', 'value' => 'go'));
		
		$form_body .= elgg_view('input/submit', array('value' => elgg_echo("save")));

// Set action appropriately
		$action = $vars['url'] . "action/multisite/localsetting";

?>

<div class="contentWrapper">
<br /><h4><?php echo elgg_echo('multisite:localadmin:setting_message'); ?></h4>

<?php	echo elgg_view('input/form', array('action' => $action, 'body' => $form_body)); ?>

</div>
		