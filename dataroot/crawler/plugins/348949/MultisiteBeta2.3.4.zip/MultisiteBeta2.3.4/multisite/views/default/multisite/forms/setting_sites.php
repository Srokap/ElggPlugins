<?php
	/**
	 * Elgg multisite plugin
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net/
	 */

//include multisite functions
require_once (dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/functions.php");

//get site settings
$dest_site = (int)get_input('site');
$community = get_entity($dest_site);
$community_setting = $community->site_setting;
$options = get_multisite_option($community_setting);

$registering = $options['registering']; // "o" (open), "c" (close)
$type_membership = $options['membership']; // "a" (average) "f" (full membership)
$date_end = $options['date_end']; //  $date_end (0 = non relevant, date end de l'abonnement � full membership pour tous les membres enregistr�s)
$fee = $options['fee']; // $cost (0 = non relevant, >0 = $cost)
$maxuser = $options['maxusers']; // maxuser (0 = non relevant, >0 = users max)
$nbre_users = $options['nbrusers']; // number registered users
$domain = $options['domain']; // domain name (every community created from this site will be a sub-domain of that domain)
$oicn = $options['icn']; // $ oicn ("in" = in open and interconnected communities network or "out") 

$community_url = $community->url;
$network = $community->community_network;

	$form_body = "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:setting:site_url')."</h3>";
	$form_body .= elgg_view('input/text', array('internalname' => 'site_url', 'value'=>$community_url));
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:setting:site_domain')."</h3>";
	$form_body .= (elgg_view('input/text', array('internalname' => 'domain', 'value'=>$domain)));
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:setting:site_network')."</h3>";
	$form_body .= (elgg_view('input/text', array('internalname' => 'network', 'value'=>$network)));
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:site_oicn')."</h3>";
	$form_body .= $oicn." -->  ".elgg_echo('multisite:change_site_oicn')." ";
	if ($oicn == "out") {
			$form_body .= elgg_view('input/pulldown', array('internalname' => 'oicn', 'value'=>$oicn, 'options' => array ('out','in')));
			} else {
			$form_body .= elgg_view('input/pulldown', array('internalname' => 'oicn', 'value'=>$oicn, 'options' => array ('in','out')));
			}
	$$form_body .= "</p>";
	$form_body .= (elgg_view('input/hidden', array('internalname' => 'dest_site', 'value' => $dest_site)));
	$form_body .= "<p>";	
	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('multisite:submit')));
	$$form_body .= "</p>";
	
	echo elgg_view('input/form', array('body' => $form_body, 'action' => $vars['url'].'action/multisite/settingsite'));
?>