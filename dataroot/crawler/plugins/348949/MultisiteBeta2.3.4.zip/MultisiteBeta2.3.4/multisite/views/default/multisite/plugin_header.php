<h3><p>
<?php
echo elgg_echo('multisite:plugin:message:header');
?>
</p></h3>
<ul><li>
<?php
echo elgg_echo('multisite:plugin:message:global');
?>
</li>
<li>
<?php
echo elgg_echo('multisite:plugin:message:local');
?>
</li>
<li>
<?php
echo elgg_echo('multisite:plugin:message:theme');
?>
</li>
<li>
<?php
echo elgg_echo('multisite:plugin:message:hidden');
?>
</li></ul>
<br />
