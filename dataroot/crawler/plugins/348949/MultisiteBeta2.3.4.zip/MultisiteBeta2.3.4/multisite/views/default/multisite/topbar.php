<?php

	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */

	 
	 //need to be logged in to send a message
	 gatekeeper();

	
?>
	<a href="<?php echo $vars['url']; ?>pg/multisite/admin/local/<?php echo $_SESSION['sid'] ?>" class="adminsite">&nbsp;</a>
	