<?php

?>

#elgg_topbar_container_left a.adminsite {
	background:transparent url(<?php echo $vars['url']; ?>mod/multisite/graphics/adminsite_icon.png) no-repeat left;
	padding:0 0 0 18px;
	margin:0 15px 0 5px;
	color:white;
}
