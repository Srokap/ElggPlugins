<?php
	/**
	 * Elgg multisite plugin
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net/
	 */

//include multisite functions
require_once (dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/functions.php");
global $CONFIG;

//get the domain name
$community = get_entity($CONFIG->site_guid);
$community_setting = $community->site_setting;
$options = get_multisite_option($community_setting);
$network = $community->community_network;
$folder = datalist_get("multisite_folder");
$domain = $options['domain']; // domain name (every community created from this site will be a sub-domain of that domain)

  $form_body = "<div class=\"contentWrapper\">";
  $form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:site_name')."</h3>";
	$form_body .= (elgg_view('input/text', array('internalname' => 'site_name')));
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:site_description')."</h3>";
	$form_body .= (elgg_view('input/text', array('internalname' => 'site_description')));
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:site_url')."</h3>";
	$form_body .= "http://<input type=\"text\" size=\"40\" name=\"subdomain_name\">";
	$form_body .= ".";
	$form_body .= $domain.$folder;
	$form_body .= (elgg_view('input/hidden', array('internalname' => 'domain_name', 'value' => $domain)));
	$form_body .= "</p>";
	$form_body .= "<p>";
	$form_body .= "<h3>".elgg_echo('multisite:site_email')."</h3>";
	$form_body .= (elgg_view('input/text', array('internalname' => 'site_email')));
	$form_body .= "</p>";
	$form_body .= "</div>";
	
	$form_body .= (elgg_view('input/hidden', array('internalname' => 'network', 'value' => $network)));


	$form_body .= elgg_view('input/submit', array('value' => elgg_echo('multisite:submit')));
	
	echo elgg_view('input/form', array('body' => $form_body, 'action' => $vars['url'].'action/multisite/addsite'));
?>