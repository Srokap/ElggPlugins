<?php

	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */


	// Description of what's going on
		echo "<div class = \"contentWrapper\"><p>" . autop(elgg_echo("admin:user:description")) . "</p></div>";
	
		echo elgg_view("multisite/user_opt/adduser");
		
		echo elgg_view("multisite/user_opt/search");
		
		if ($vars['list']) echo $vars['list'];
		
		
?>