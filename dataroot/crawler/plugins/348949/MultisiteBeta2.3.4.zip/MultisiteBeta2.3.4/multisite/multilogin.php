<?php

   	/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

	 

require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

//generate new simple cache files
elgg_view_regenerate_simplecache();

//regenerate plugin caches. thanks to Chris Ghere
$cache = elgg_get_filepath_cache();
$cache->delete('view_paths');

$multilogin_id = $_GET['id'];

$entities = get_entities_from_metadata('multilogin_code', $multilogin_id, "user", "", "", 1, 0, "", -1, false);
if ($entities) {
$id = $entities[0]->guid;
} else {system_message('multisite:login:notallowed');forward();}

if (isloggedin() && is_member_of_site($id)) {
forward();} else {

if (is_member_of_site($id)) {
    $user = get_entity($id);
    
    login($user);
    //reset multilogin code
    $user->multilogin_code = 0;
    forward('pg/dashboard');
  } else {forward($_SERVER['HTTP_REFERER']);system_message('multisite:login:notallowed');}
}



?>
