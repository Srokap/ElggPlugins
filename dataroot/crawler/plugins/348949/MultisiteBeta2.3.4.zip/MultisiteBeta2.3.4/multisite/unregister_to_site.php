<?php
		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
gatekeeper();

$dest_site = (int)get_input('site');

$user_guid = $_SESSION['guid'];

remove_entity_relationship($user_guid,'member_of_site',$dest_site);

system_message(elgg_echo('multisite:unregister_ok'));

forward("pg/multisite/".$_SESSION['user']->username);

?>
