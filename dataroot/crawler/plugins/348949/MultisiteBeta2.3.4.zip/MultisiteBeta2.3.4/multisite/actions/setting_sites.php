<?php
		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */
	/**
       * Start the Elgg engine
       */
                require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
                global $CONFIG;
        
admin_gatekeeper(); // Only admins can do this
		
//Get the data

$community_url = get_input('site_url');
$domain = get_input('domain');
$site_url = get_input('subdomain_name');
$network = get_input('network');
$oicn = get_input('oicn');
$dest_site = (int)get_input('dest_site');


//include multisite functions
require_once (dirname(dirname(__FILE__)) . "/functions.php");


//get site settings

$community = get_entity($dest_site);
$community_setting = $community->site_setting;
$options = get_multisite_option($community_setting);


//update community setting metadata
$site_setting = "r:".$options['registering']."|t:".$options['membership']."|d:".$options['date_end']."|f:".$options['fee']."|m:".$options['maxusers']."|n:".$options['nbrusers']."|domain:".$domain."|o:".$oicn;
$community->site_setting = $site_setting;

//set network metadata
$community->community_network = $network;

//set url
$community->url = $community_url;
if ($community->save()) {
//if (create_site_entity($dest_site, $community->name, $community->description, $community_url)) {
$forward = "pg/multisite/admin/setting/".$dest_site;
} else {
system_message(elgg_echo('multisite:community:notupdated'));
$forward = "pg/multisite/admin/setting/".$dest_site;
}

forward($forward);

?>