<?php
	/**
	 * Elgg ban user
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @author Curverider Ltd
	 * @link http://elgg.org/
	 * 	 
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");
	
	// block non-admin users
	multisite_admin_gatekeeper();
	action_gatekeeper();
	
	// Get the user 
	$guid = get_input('guid');
	$obj = get_entity($guid);
	
	if ( ($obj instanceof ElggUser) && ($obj->canEdit()))
	{
		// Now actually disable it
		if ($obj->ban('banned')) {
			system_message(elgg_echo('admin:user:ban:yes'));
		}
		else
			register_error(elgg_echo('admin:user:ban:no'));
	} else {
		$canedit = $obj->canEdit();
		$isinstance = ($obj instanceof ElggUser);
		register_error(elgg_echo('admin:user:ban:no'));
	}
		
	forward('pg/admin/user/');
	exit;
?>