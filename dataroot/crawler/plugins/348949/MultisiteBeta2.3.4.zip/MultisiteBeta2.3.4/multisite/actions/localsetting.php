<?php

	/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

	//include multisite functions
	require_once (dirname(dirname(__FILE__)) . "/functions.php");

	global $CONFIG;
	
	multisite_admin_gatekeeper(); // Only admins and localadmins can do this
	action_gatekeeper();

	//get data
	$sitestatus = get_input('sitestatus');

	if ($sitestatus == "Open") {$r = "o";} else {$r = "c";}

	$options = get_multisite_option($community_setting);

	// update community metadata
	$community = get_entity($CONFIG->site_guid);
	$site_setting = "r:".$r."|t:".$options['membership']."|d:".$options['date_end']."|f:".$options['fee']."|m:".$options['maxusers']."|n:".$options['nbrusers']."|domain:".$options['domain']."|o:".$oicn;
	$community->site_setting = $site_setting;


	//update 		
	$site = get_entity($CONFIG->site_guid);
			
		if (!($site instanceof ElggSite)) 
		 throw new InstallationException(elgg_echo('InvalidParameterException:NonElggSite'));
			
	$site->description = get_input('sitedescription');
	$site->name = get_input('sitename');
				
	set_config('language', get_input('language'), $site->getGUID());
				
	if ($site->save())
				system_message(elgg_echo("admin:configuration:success"));
			else
				register_error(elgg_echo("admin:configuration:fail"));
			
	forward("pg/multisite/admin/local");
				
?>