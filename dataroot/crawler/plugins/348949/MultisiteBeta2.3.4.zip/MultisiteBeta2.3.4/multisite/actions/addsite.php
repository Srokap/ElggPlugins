<?php

		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */



        /**
         * Start the Elgg engine
         */
          require_once (dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
          global $CONFIG;
          
gatekeeper(); 

	//include multisite functions
	require_once (dirname(dirname(__FILE__)) . "/functions.php");

		
//Get the data

$site_name = get_input('site_name');
$site_description = get_input('site_description');
$site_url = get_input('subdomain_name');
$domain_name = get_input('domain_name');
$site_email = get_input('site_email');
$network = get_input('network');

$folder = datalist_get("multisite_folder");

//Make sure that multisite init has been run
if (empty($domain_name)) {
  system_message(elgg_echo("multisite:configuration:noinit"));
	$forward = "pg/multisite/" . $_SESSION['user']->username."/createsite";
	forward($forward);
}

// Build the site url as subdomain.mydomain.com
//see if this is a subfolder installation
if (!empty($folder)){
      $site_url = "http://".$site_url.".".$domain_name.$folder;
      } else {
      $site_url = "http://".$site_url.".".$domain_name;
      }


//check if url does already exist
if ( get_site_by_url($site_url) != false ) {

	system_message(elgg_echo("multisite:configuration:wrongurl"));
	$forward = "pg/multisite/" . $_SESSION['user']->username."/createsite";
	forward($forward);
} 
else {

	$site = new ElggSite();
	$site->name = $site_name;
	$site->url = $site_url;
	$site->description = $site_description;
	$site->email = $site_email;
	$site->access_id = 2; // The site is public
	$site->owner_guid = 0;
	$site->container_guid = 0;
	$guid = $site->save();


	// Register site creator to the site
	$user_guid = $_SESSION['user']->guid;
	add_entity_relationship($user_guid,'member_of_site',$site->getGUID());

	//Register site creator metadata to give special priviledges
	$site->site_creator = $user_guid;

	//Set community metadata
	$multisite_default_data = datalist_get('multisite_default_data');
	$options = get_multisite_option($multisite_default_data);
	$r = $options['registering'];
	$t = $options['membership'];
	$d = $options['date_end'];
	$f = $options['fee'];
	$m = $options ['maxusers'];
	$n = $options['nbrusers'];
	//$domain = $options['domain']; 
	$o = $options['icn'];
 	$site_metadata = "r:".$r."|t:".$t."|d:".$d."|f:".$f."|m:".$m."|n:".$n."|domain:".$domain_name."|o:".$o;
	$site->site_setting = $site_metadata;
	$site->community_network = $network;


	//Get some default valuès from the current site and apply them to the new one
	$default_access = get_config('default_access');
	$view = get_config('view');
	$lang = get_config('language');
	set_config('language',$lang,$site->getGUID());
	set_config('view', $view, $site->getGUID());
	set_config('default_access', $default_access, $site->getGUID());
	
	//In case of global plugins are not set, make sure that basic plugins are set
  enable_plugin('profile', $site->getGUID());
	enable_plugin('river', $site->getGUID());
	enable_plugin('logbrowser', $site->getGUID());
	enable_plugin('diagnostics', $site->getGUID());
	enable_plugin('uservalidationbyemail', $site->getGUID());
	enable_plugin('htmlawed', $site->getGUID());
	enable_plugin('multisite', $site->getGUID());

	//enable global plugins
	$count = get_entities("object", "community_plugin", 0, "", 99, 0, true, -1, null);
	$community_plugin = get_entities("object", "community_plugin", 0, "", $count, 0, false, -1, null);
		
	foreach ($community_plugin as $c) {
		if ($c->plugin_status == "global") {
		  if (!is_plugin_enabled($c->title, $site->getGUID())){enable_plugin($c->title, $site->getGUID());}
			}
		}
	
	system_message(elgg_echo("multisite:configuration:success"));
	forward("pg/multisite/");
}

?> 