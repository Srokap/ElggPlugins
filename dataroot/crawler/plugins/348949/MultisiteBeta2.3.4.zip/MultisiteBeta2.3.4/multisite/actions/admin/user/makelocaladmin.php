<?php
	/**
	 * Make another user an admin.
	 * 
	 * @package Elgg
	 * @subpackage Core
	 * @author Curverider Ltd
	 * @link http://elgg.org/
	 * 	 
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

	require_once(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/engine/start.php");
	global $CONFIG;
	
	// block non-admin users
	multisite_admin_gatekeeper();
	action_gatekeeper();
	
	// Get the user 
	$guid = get_input('guid');
	$obj = get_entity($guid);
	$site = get_entity($CONFIG->site_guid);
	
	if ( ($obj instanceof ElggUser) && ($obj->canEdit()))
	{
	  create_metadata($CONFIG->site_guid, 'site_creator', $guid, '', $CONFIG->site_guid, 2, true);
		if (is_community_creator($guid))
			system_message(elgg_echo('multisite:user:makelocaladmin:yes'));
		else
			register_error(elgg_echo('multisite:user:makelocaladmin:no'));
	}
	else
		register_error(elgg_echo('multisite:user:makelocaladmin:no'));
	
	forward($_SERVER['HTTP_REFERER']);

?>