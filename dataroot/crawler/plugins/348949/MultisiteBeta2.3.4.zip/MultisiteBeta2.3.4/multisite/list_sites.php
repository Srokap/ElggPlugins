<?php
		/**
	 * Elgg multisite 2.3.5
	 * 
	 * 
	 * @package multisite
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */


require_once (dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
gatekeeper();

//include multisite functions
	require_once (dirname(__FILE__) . "/functions.php");


// Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($_SESSION['guid']);
		}
// Get the current site's domain and network

$community_id = (int)$CONFIG->site_guid;
$community = get_entity($community_id);
$localsetting = $community->site_setting;
$options = get_multisite_option($localsetting);
$local_domain = $options['domain'];
$local_network = $community->community_network;

$_SESSION['user']->multilogin_code = md5($_SESSION['user']->name . time() . rand());



//Add submenu
set_context('multisite');

$body = elgg_view_title(elgg_echo('multisite:allsite_title'));
$body .= "<br />";
$body = elgg_view('multisite/pme/info');
$offset = 0;
$count = get_entities("site","",0,"",999,0,true,-1,null);
$entities = get_entities("site","",0,"",$count,0,false,-1,null);
foreach ($entities as $entities){
$entities_setting = $entities->site_setting;
$options = get_multisite_option($entities_setting);
$domain = $options['domain'];
$network = $entities->community_network;
set_input('id',$_SESSION['user']->guid);
 	if (($local_domain == $domain) || ($local_network == $network)) {

		$body .= "<div class=\"search_listing\">";
		$body .= "<div class=\"search_listing_icon\"><div class=\"usericon\">";
		$body .= "<a href=\"".$entities->url."mod/multisite/multilogin.php?id=".$_SESSION['user']->multilogin_code."\" class=\"icon\"><img src=\"".get_entity_icon_url ($entities,'large')."\" border=\"0\"></a></div></div>";
		$body .= "<div class=\"search_listing_info\">";
		$body .= "<p><h3><a href=\"".$entities->url."mod/multisite/multilogin.php?id=".$_SESSION['user']->multilogin_code."\">".$entities->name."</a></h3></p>";
		$body .= "<p>".$entities->description."</p>";
			if ( check_entity_relationship($_SESSION['id'],'member_of_site', $entities->guid)){
				$body .= "<p><a href=\"".$CONFIG->wwwroot . "pg/multisite/".$_SESSION['user']->username."/unregister/".$entities->guid."\">".elgg_echo('multisite:unregister')."</a> / <a href=\"".$entities->url."mod/multisite/multilogin.php?id=".$_SESSION['user']->multilogin_code."\">".elgg_echo('multisite:login')."</a>";
				} else {
				$body .= "<a href=\"register/".$entities->guid."\">".elgg_echo('multisite:register')."</a>"; 
	    		}
		$body .= "</p></div></div>";
	}
}
				


$area2 = $body;

// Format
	$body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);

	// Draw page
	echo page_draw(elgg_echo('this will be the page title'),$body);

?>