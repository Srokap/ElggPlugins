<?php
	/**
	 * Elgg Multisite
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-online.net
	 */



	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
				
			'multisite:title' => 'Communities',
			'multisite:mysite' => 'My communities',
			'multisite:allsites' => 'All communities',
			'multisite:createsites' => 'Create a new community',
			'multisite:yours' => "Communities that you belong to",
			'multisite:allsite_title' => 'All communities',
			'multisite:unregister' => 'unregister',
			'multisite:login' => 'connect',
			'multisite:register' => 'register',
			'multisite:register_ok' => 'you have been correctly registered to the community',
			'multisite:register_not_ok' => 'you have not been registered to the community',
			'multisite:unregister_ok' => 'you have been correctly unregistered from the community',
			'multisite:create_site_title' => 'Create a new community',
			'multisite:site_name' => 'Name - This will be the name of your new community',
			'multisite:site_description' => 'Description - Please describe your community',
			'multisite:site_url' => 'Url : this is the prefix of the full url - example http://community.domain.com',
			'multisite:site_email' => 'Email - Your Contact Email',
			'multisite:submit' => 'Save',
			'multisite:configuration:success' => 'Your new community has been succesfully created and saved',
			'multisite:configuration:noinit' => 'Unable to create a new community. You must run the init multisite first',
			'multisite:security_message' => 'You are about to connect to one of your communities. According to safety rules, and for a better protection of your account, you have to confirm your username and password.',
			'multisite:delete' => 'delete',
			'multisite:disable' => 'close',
			'multisite:enable' => 'open',
			'multisite:disable_ok' => 'The community has been successfully closed',
			'multisite:enable_ok' => 'The community has been successfully opened',
			'multisite:setting' => 'settings',
			'multisite:delete:menu' => 'Suppress communities',
			'multisite:delete_ok' => 'The community has successfully been deleted',
			'multisite:delete_not_ok' => 'You cannot delete this community',
			'multisite:option:domain_name' => 'Domain Name',
			'multisite:option:message' => 'Should display your domain name without http:// .... All the sites will be created with an url looking like http://subdomain.domain_name.com. DONT FORGET TO SAVE even if you keep the default value otherwise it wont work',
			'multisite:manage:users' =>  'Manage users',
			'multisite:manage:communities' => 'Communities setting',
			'multisite:plugins' => 'Plugins setting',
			'multisite:update' => 'Init multisite',
			'multisite:update_title' => 'Multisite initialization',
			'multisite:update_message' => 'You have to init the plugin multisite to make it works. This will add some various metadata to sites and users, 
								and create a specific object for each plugin found on your system. This will be use for the tools and theme setting at the community level',
			'multisite:submit_update' => 'Initialize multisite',

			'multisite:register_close' => 'Sorry This community is closed - You cannot register - Please choose another community to connect to',

			'multisite:manage:plugin' => 'Plugin management',
			'multisite:plugin:global' => 'global',
			'multisite:plugin:local' => 'local',
			'multisite:plugin:theme' => 'theme',
			'multisite:plugin:hidden' => 'hidden',
			'multisite:plugin:message:header' => 'Set the installed plugin :',
			'multisite:plugin:message:global' => 'Global : The tool will be enabled for all communities',
			'multisite:plugin:message:local' => 'Local : The tool will be enabled / disabled by the local admin at the community level', 
			'multisite:plugin:message:theme' => 'Theme : The theme activation / desactivation will be available at the community level',
			'multisite:plugin:message:hidden' => 'Hidden : Only the global admin will be abble to enable / disable the plugin (with the standard elgg tools admin)',
			

			'multisite:localadmin:themes_title' => 'Theme selector',
			'multisite:localadmin:themes_message' => 'Select one of the themes beyond and then reload your browser page. 
									(Warning : sometimes you will have to empty your browser cache before reloading the new theme)',
			'multisite:localadmin:disable_plugin' => 'disable',
			'multisite:localadmin:enableplugin' => 'enable',
			'multisite:localadmin:setting' => 'Community settings',
			'multisite:localadmin:plugins' => 'Tools selector',
			'multisite:localadmin:themes' => 'Theme selector',
			'multisite:localadmin:users' => 'Manage users',
			'multisite:localadmin:plugin_title' => 'Tools selector',
			'multisite:localadmin:plugin_message' => 'Select the tools you want to add to your community.',
			'multisite:top:admin' => 'AdminSite',
			'multisite:localadmin:setting' => 'Community global settings',
			'multisite:localadmin:setting_message' => 'You need to open your community to allow member registering :',
			'multisite:localadmin:title' => 'Community setting',
			'multisite:localadmin:submit_close' => 'close community',
			'multisite:localadmin:submit_open' => 'open community',
			'multisite:localplugin:enable_ok' => 'The plugin has been succesfully enabled',
			'multisite:localplugin:disable_ok' => 'The plugin has been succesfully disabled',

			'multisite:sitestatus:close'=> 'Registering status is : close',
			'multisite:sitestatus:open' => 'Registering status is : open',
			'multisite:sitestatus:changestatus' => 'Change status',

			'multisite:setting_site_title' => 'Setting',
			'multisite:setting:site_url' => 'url (ending by "/")',
			'multisite:setting:site_domain' => 'Domain (ending by "/")',
			'multisite:setting:site_network' => 'Network',
			'multisite:site_oicn' => 'in / out Interconnected Communities Network',
			'multisite:change_site_oicn' => 'Change',
			
			'multisite:defaultsetting:message' => 'Set initial default values',
			'multisite:defaultsetting:domain' => 'Default domain name (ending with "/")',
			'multisite:defaultsetting:folder' => 'Subfolder name (ending with "/"). Leave it blank if you have your installation under the root otherwise give the subfolder name of your elgg installation',
			'multisite:defaultsetting:network' => 'Default network name ("no"=no network, "all"= all networks)',
			'multisite:configuration:wrongurl' => 'Subdomain already exists, please try again with another subdomain name',

			'multisite:friends:title' => 'Your friends on ',
			'multisite:friends:select' => 'Select a community ',

	);
					
	add_translation("en",$english);
?>