<?php

    $english = array(
    
        'profile:user_type' => 'User type',
        'profile:usertype:none' => 'default',
        'profile:usertype:' . USER_TYPE_CUSTOMER    => 'customer',
        'profile:usertype:' . USER_TYPE_PROVIDER    => 'provider',
        
    );
                    
    add_translation("en",$english);

?>