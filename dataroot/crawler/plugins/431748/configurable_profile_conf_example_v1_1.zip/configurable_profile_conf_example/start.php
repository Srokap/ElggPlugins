<?php

define ('USER_TYPE_CUSTOMER', 'customer');
define ('USER_TYPE_PROVIDER', 'provider');


function configurable_profile_conf_example_init()
{
    global $CONFIG;
    register_plugin_hook('profile:fields',                  'profile', 'configurable_profile_conf_example_fields_init');
    register_plugin_hook('profile:fields:options',          'profile', 'configurable_profile_conf_example_fields_options_init');
    register_plugin_hook('profile:fields:access:default',   'profile', 'configurable_profile_conf_example_fields_access_default_init');
    register_plugin_hook('profile:fields:access:user',      'profile', 'configurable_profile_conf_example_fields_access_user_init');
    register_plugin_hook('profile:fields:groups',           'profile', 'configurable_profile_conf_example_fields_groups_init');
    register_plugin_hook('profile:fields:filter',           'profile', 'configurable_profile_conf_example_fields_filter_init');
        
    extend_view('css', 'configurable_profile/css');
}



function configurable_profile_conf_example_fields_init($hook, $entity_type, $return_value, $params)
{
    if ( is_array($return_value) )
    {
        $return_value = array ( 
                'user_type'         => 'radio',
                'description'       => 'longtext', 
                'briefdescription'  => 'text', 
                'location'          => 'text', 
                'interests'         => 'text', 
                'skills'            => 'text', 
                'contactemail'      => 'email', 
                'phone'             => 'text', 
                'mobile'            => 'text', 
                'website'           => 'url', 
        );
    }
    return $return_value;
}



function configurable_profile_conf_example_fields_options_init($hook, $entity_type, $return_value, $params)
{
    $return_value = array(
                'user_type'                 => array (
                                                  elgg_echo('profile:usertype:'.USER_TYPE_CUSTOMER)    => USER_TYPE_CUSTOMER,
                                                  elgg_echo('profile:usertype:'.USER_TYPE_PROVIDER)    => USER_TYPE_PROVIDER,
                                                  elgg_echo('profile:usertype:none') => '',
                                        ),
    );
    return $return_value;
}

function configurable_profile_conf_example_fields_access_default_init($hook, $entity_type, $return_value, $params)
{
    $return_value = array(
        'user_type'         => ACCESS_LOGGED_IN, 
        'description'       => ACCESS_DEFAULT, 
        'briefdescription'  => ACCESS_DEFAULT, 
        'location'          => ACCESS_DEFAULT, 
        'interests'         => ACCESS_DEFAULT, 
        'skills'            => ACCESS_DEFAULT, 
        'contactemail'      => ACCESS_LOGGED_IN, 
        'phone'             => ACCESS_LOGGED_IN, 
        'mobile'            => ACCESS_LOGGED_IN, 
        'website'           => ACCESS_DEFAULT,         
    );
    return $return_value;
}

function configurable_profile_conf_example_fields_access_user_init($hook, $entity_type, $return_value, $params)
{
    $return_value = array ('contactemail', 'phone', 'mobile', 'website');
    return $return_value;
}

function configurable_profile_conf_example_fields_groups_init($hook, $entity_type, $return_value, $params)
{
    global $CONFIG;
    $return_value = array(
        'main'          => array ('user_type', 'description', 'briefdescription'),
        'customer'      => array ('interests', 'skills', 'mobile'),
        'provider'      => array ('location', 'contactemail', 'phone', 'website'),
    );
    return $return_value;
}

function configurable_profile_conf_example_fields_filter_init($hook, $entity_type, $return_value, $params)
{
    
    global $CONFIG;
    $return_value = array(
        'user_type' => array (
            // default user type, default profile
            ''                  => array( 'user_type', 'description', 'briefdescription' ),
            // customer profile
            USER_TYPE_CUSTOMER  => array ( 'user_type', 'description', 'briefdescription', 'interests', 'skills', 'mobile', ),
            // provider profile
            USER_TYPE_PROVIDER  => array ( 'user_type', 'description', 'briefdescription', 'location', 'contactemail', 'phone', 'website'),
        ),
    );
    return $return_value;
}


register_elgg_event_handler('init','system','configurable_profile_conf_example_init',2);


?>