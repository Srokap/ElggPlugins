/**

    README.txt, part of configurable_profile_conf_example
    Copyright (C) 2010, Web100 Net technology Center,Ltd
    Author: Bogdan Nikovskiy, bogdan@web100.com.ua
        
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
                
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
                        
    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.

    Elgg version: 1.6.1
    Title: Configurable profile configuration example
    Intro: Configarable profile configuration example is example of profile fields configuration for 
    configurable_profile plugin.
    Description:   Configarable profile configuration example provide example of profile fields
    configuration for configurable_profile plugin.
    
    Plugin is developed by Web100 Net Technology Center, Ltd. http://web100.com.ua under the assignment of Lorinthe,BV.
    Dependencies: configurable_profile
    Version: 1.1
    Licence: GPL v.2

                                
 */



*Activating the configurable_profile_conf_example plugin*

Simply extract the plugin into the mod directory and
activate it as usual using the Elgg 1.x tool administration.


*Plugin settings*

Review the start.php file for example how to setup configurable profile fields engine.

