<?php
    $image_url = elgg_get_site_url().'mod/worldview/graphics/bing4.png';
?>

<div id="container"> 
    <div id="input_box"> 
        <img src="<?php echo $image_url;?>" /><br/> 
        <input type="text" class='search_input'  />&nbsp; 
        <br/> <br/> 
    </div>
    <div id="result"> 
    </div> 
</div> 