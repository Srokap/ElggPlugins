<?php
/*******************************************************************************
 * Ggames
 *
 * @author mybook
 ******************************************************************************/

	function Ggames_init()
	{
		global $CONFIG;





		register_page_handler('ggames','Ggames_page_handler');


		add_menu(Ggames, $CONFIG->wwwroot . 'pg/ggames/Gplay/');


		register_elgg_event_handler('pagesetup','system','Ggames_submenus');


		register_action('Ggames/gplay', false, '/var/www/gillardg.net/htdocs/my/mod/Ggames/actions/gplay.php');
		
		
		return true;
	}


	function Ggames_page_handler($page)
	{
		global $CONFIG;

		
		switch ($page[0])
		{
			case 'Gplay':
				include $CONFIG->pluginspath . 'Ggames/pages/Gplay.php';
				break;
		
		}
		
		return true;
	}


	function Ggames_submenus()
	{
		global $CONFIG;

		
		if (get_context() == 'ggames')
		{
			add_submenu_item('Gplay', $CONFIG->wwwroot . 'pg/ggames/Gplay/');
		}
		
	}


	
	register_elgg_event_handler('init', 'system', 'Ggames_init');
?>