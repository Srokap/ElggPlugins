<?php
$english = array(
	'Ggames:pagetitle'	=> 'Ggames',
	'Ggames:success'	=> 'successful',
	'Ggames:failure'	=> 'failed',

);

add_translation("en",$english);
?>