<?php

	// must be logged in
	gatekeeper();
	
	// must have security token 
	action_gatekeeper();
	
	// get parameters that were posted
	$param = get_input('param');

	
	// do something
	
	
	// now see if it worked
	if ($error) {
		register_error(elgg_echo('Ggames::failure'));
		forward();
	}
	
	// we had success so forward the user somewhere and display success message
	system_message(elgg_echo('Ggames:success'));
	forward();
?>