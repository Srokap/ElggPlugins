<?php

	/**
	 * Planphoria Elgg SiteIndex Generator 
	 * This siteindex generator attempts to provide search engines as much searchable content while
	 * protecting site user rights of privacy to their content.
	 * 
	 * @package SiteIndex
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Planphoria, LLC
	 * @copyright Planphoria, LLC 2009
	 * @link http://www.planphoria.com
	 */

#####################USER CONFIGURATION###############################

#FILL IN LOOSE PAGES THAT YOU WANT INDEXED
$page = array();
#$page[0] = "http://www.example.com/page1.html";
#$page[1] = "http://www.example.com/page2.html";

#PATH TO YOUR ELGG INSTALL BASE
$path = "<path of your Elgg Install>";

# Do you want compressed sitemap output? (0 = no, 1 = yes)
# Typically you want to say yes here. Say no when debugging.
# Though it will work in Firefox, there is an issue with the way that 
# Google (and Lynx for that matter) works with my Apache mod_rewrite, 
# going .gz when submitting the sitemap seems to fix it. 

$gzip = 1;

# You can tweak the last two parameters of the makeURLrec() function for 
# better SEO (or use my defaults) where the second to last parameter is 
# the frequency of how oftenthe content changes.  It can be one of the following:
#
#    * always
#    * hourly
#    * daily
#    * weekly
#    * monthly
#    * yearly
#    * never
#
#  The last parameter is the priority which can be a value between
#  0.0 and 1.0
#

###################END OF USER CONFIGURATION########################### 

require_once($path . "/engine/settings.php");


if(!isset($_GET['g'])==''){
	$gzip = 0;
}
elseif(isset($_GET['g'])=='.gz'){
	$gzip = 1;
}



$sqlsite = "SELECT url FROM " . $CONFIG->dbprefix . "sites_entity";

$sqlprofiles = "SELECT username, last_action FROM " . $CONFIG->dbprefix . "users_entity";

$sqlgroups = "SELECT " . $CONFIG->dbprefix . "entities.guid AS guid, " . $CONFIG->dbprefix . "entities.time_updated AS time_updated, " . $CONFIG->dbprefix . "groups_entity.name AS name FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "groups_entity) ON (" . $CONFIG->dbprefix . "groups_entity.guid=" . $CONFIG->dbprefix . "entities.guid) where type='group' AND enabled='yes' AND access_id=2";

$sqlblogs = "SELECT " . $CONFIG->dbprefix . "entities.guid AS guid, " . $CONFIG->dbprefix . "entities.time_updated AS time_updated, " . $CONFIG->dbprefix . "objects_entity.title AS title, " . $CONFIG->dbprefix . "users_entity.username AS username FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "objects_entity," . $CONFIG->dbprefix . "users_entity) ON (" . $CONFIG->dbprefix . "objects_entity.guid=" . $CONFIG->dbprefix . "entities.guid AND " . $CONFIG->dbprefix . "users_entity.guid=" . $CONFIG->dbprefix . "entities.owner_guid) where subtype=5 and access_id=2 and enabled='yes'";

$sqlevents="SELECT " . $CONFIG->dbprefix . "entities.guid AS guid, " . $CONFIG->dbprefix . "entities.time_updated AS time_updated, " . $CONFIG->dbprefix . "objects_entity.title AS title FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "objects_entity) ON (" . $CONFIG->dbprefix . "objects_entity.guid=" . $CONFIG->dbprefix . "entities.guid) where subtype=6 and access_id=2 and enabled='yes'";

$sqlfiles="SELECT " . $CONFIG->dbprefix . "entities.guid AS guid, " . $CONFIG->dbprefix . "entities.time_updated AS time_updated, " . $CONFIG->dbprefix . "objects_entity.title AS title FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "objects_entity) ON (" . $CONFIG->dbprefix . "objects_entity.guid=" . $CONFIG->dbprefix . "entities.guid) where subtype=1 and access_id=2 and enabled='yes'";

$sqlbookmark="SELECT " . $CONFIG->dbprefix . "entities.guid AS guid, " . $CONFIG->dbprefix . "entities.time_updated AS time_updated, " . $CONFIG->dbprefix . "objects_entity.title AS title, " . $CONFIG->dbprefix . "users_entity.username AS username FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "objects_entity, " . $CONFIG->dbprefix . "users_entity) ON (" . $CONFIG->dbprefix . "objects_entity.guid=" . $CONFIG->dbprefix . "entities.guid AND " . $CONFIG->dbprefix . "users_entity.guid=" . $CONFIG->dbprefix . "entities.owner_guid) where subtype=1 and access_id=2 and enabled='yes'";

$sqlpages="SELECT " . $CONFIG->dbprefix . "entities.guid AS guid, " . $CONFIG->dbprefix . "entities.time_updated AS time_updated, " . $CONFIG->dbprefix . "objects_entity.title AS title, " . $CONFIG->dbprefix . "users_entity.username AS username FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "objects_entity," . $CONFIG->dbprefix . "users_entity) ON (" . $CONFIG->dbprefix . "objects_entity.guid=" . $CONFIG->dbprefix . "entities.guid AND " . $CONFIG->dbprefix . "users_entity.guid=" . $CONFIG->dbprefix . "entities.owner_guid) where subtype=15 and access_id=2 and enabled='yes'";

$sqlcategories="SELECT " . $CONFIG->dbprefix . "metastrings.string AS string FROM " . $CONFIG->dbprefix . "metadata LEFT JOIN (" . $CONFIG->dbprefix . "metastrings) ON (" . $CONFIG->dbprefix . "metastrings.id=" . $CONFIG->dbprefix . "metadata.value_id) where " . $CONFIG->dbprefix . "metadata.name_id=34 OR " . $CONFIG->dbprefix . "metadata.name_id=132 AND enabled='yes'";

$sqlblogarchive="SELECT " . $CONFIG->dbprefix . "entities.time_created AS time_created, " . $CONFIG->dbprefix . "users_entity.username AS username FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "users_entity) ON (" . $CONFIG->dbprefix . "users_entity.guid=" . $CONFIG->dbprefix . "entities.owner_guid) where " . $CONFIG->dbprefix . "entities.owner_guid=" . $CONFIG->dbprefix . "entities.container_guid and " . $CONFIG->dbprefix . "entities.subtype=5 and " . $CONFIG->dbprefix . "entities.access_id=2 and " . $CONFIG->dbprefix . "entities.enabled='yes' order by " . $CONFIG->dbprefix . "entities.time_created";

$sqlgrblogarchive="SELECT " . $CONFIG->dbprefix . "entities.time_created AS time_created, " . $CONFIG->dbprefix . "groups_entity.guid AS username FROM " . $CONFIG->dbprefix . "entities LEFT JOIN (" . $CONFIG->dbprefix . "groups_entity) ON (" . $CONFIG->dbprefix . "groups_entity.guid=" . $CONFIG->dbprefix . "entities.container_guid) where " . $CONFIG->dbprefix . "entities.owner_guid != " . $CONFIG->dbprefix . "entities.container_guid and " . $CONFIG->dbprefix . "entities.subtype=5 and " . $CONFIG->dbprefix . "entities.access_id=2 and " . $CONFIG->dbprefix . "entities.enabled='yes' order by " . $CONFIG->dbprefix . "entities.time_created";


if(isset($_GET['m'])){
	$m = $_GET['m'];
}
elseif(isset($argv)){
	$m = $argv[0];
}


$conn = mysql_connect($CONFIG->dbhost, $CONFIG->dbuser, $CONFIG->dbpass);
if (!$conn) {
    echo "Unable to connect to DB: " . mysql_error();
    exit;
}
  
if (!mysql_select_db($CONFIG->dbname)) {
    echo "Unable to select $CONFIG->dbname: " . mysql_error();
    exit;
}

$collect = '';
$site = querydb($sqlsite);
$res = mysql_fetch_assoc($site);
$URL = $res['url'];



if($m == 'index'){	
	$parts = array('sitemain'=>$sqlsite, 'siteprofiles'=>$sqlprofiles, 'sitepages'=>$sqlpages, 'sitegroups'=>$sqlgroups, 'siteblogs'=>$sqlblogs, 'siteevents'=>$sqlevents, 'sitefiles'=>$sqlfiles,'sitebookmarks'=>$sqlbookmark, 'sitecategories'=>$sqlcategories, 'siteblogarchive'=>$sqlblogarchive, 'sitegrblogarchive'=>$sqlgrblogarchive);
	$site = '';
	foreach($parts as $key=>$part){
		$test = querydb($part);
		$num_rows = mysql_num_rows($test);
		if($num_rows >> 0){
			$site .= makeSite($key);
		}
	}
	$sitelist = sitelist_wrapper($site);
	sendit($sitelist);
}



#MAIN SITE AND STRAGGLE PAGES

if($m == 'main'){

	$collect .= makeURLrec($URL,'','hourly',1.0);
	$collect .= makeURLrec($URL . "mod/blog/everyone.php", '','daily',1.0);
	$collect .= makeURLrec($URL . "mod/bookmarks/everyone.php", '','daily',1.0);
	$collect .= makeURLrec($URL . "mod/blog/everyone.php?view=rss", '','daily',1.0);
	$collect .= makeURLrec($URL . "mod/bookmarks/everyone.php?view=rss", '','daily',1.0);
	$collect .= makeURLrec($URL . "mod/file/world.php", '','daily',1.0);
	$collect .= makeURLrec($URL . "mod/file/world.php?view=rss", '','daily',1.0);	
	$collect .= makeURLrec($URL . "mod/pages/world.php", '','daily',1.0);
	$collect .= makeURLrec($URL . "mod/pages/world.php?view=rss", '','daily',1.0);	
	$collect .= makeURLrec($URL . "mod/members/index.php", '','daily',1.0);
	$collect .= makeURLrec($URL . "mod/members/index.php?view=rss", '','daily',1.0);	
	$collect .= makeURLrec($URL . "pg/groups/world", '','daily',1.0);	
	$collect .= makeURLrec($URL . "pg/groups/world?view=rss", '','daily',1.0);
	$i=0;
	while ($i <= count($page)-1){
		$collect .= makeURLrec($page[$i],'','weekly', 0.5);
		$i++;
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}


if($m == 'profiles'){
	$profiles = querydb($sqlprofiles);
	while ($profile = mysql_fetch_assoc($profiles)) {
		$collect .= makeURLrec($URL . "pg/profile/" . $profile['username'], $profile['last_action'],'daily',0.8);
		$collect .= makeURLrec($URL . "pg/profile/" . $profile['username'] . "?view=rss", $profile['last_action'],'daily',0.8);	
		$collect .= makeURLrec($URL . "pg/blog/" . $profile['username'], '','daily',0.8);
		$collect .= makeURLrec($URL . "pg/blog/" . $profile['username'] . "?view=rss", '','daily',0.8);
		$collect .= makeURLrec($URL . "pg/blog/" . $profile['username'] . "/friends", '','daily',0.8);
		$collect .= makeURLrec($URL . "pg/blog/" . $profile['username'] . "/friends?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/bookmarks/" . $profile['username'] . "/inbox", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/bookmarks/" . $profile['username'] . "/inbox?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/bookmarks/" . $profile['username'] . "/items", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/bookmarks/" . $profile['username'] . "/items?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/bookmarks/" . $profile['username'] . "/friends", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/bookmarks/" . $profile['username'] . "/friends?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/file/" . $profile['username'], '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/file/" . $profile['username'] . "?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/file/" . $profile['username'] . "/friends", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/file/" . $profile['username'] . "/friends?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/pages/owned/" . $profile['username'], '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/pages/owned/" . $profile['username'] . "?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/friends/" . $profile['username'], '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/friends/" . $profile['username'] . "?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/friendsof/" . $profile['username'], '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/friendsof/" . $profile['username'] . "?view=rss", '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/groups/member/" . $profile['username'], '', 'daily', 0.8);
		$collect .= makeURLrec($URL . "pg/groups/member/" . $profile['username'] . "?view=rss", '', 'daily', 0.8);
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}




if($m == 'pages'){
	$pages = querydb($sqlpages);
	if(!empty($pages)){
		while ($page = mysql_fetch_assoc($pages)) {
			$collect .= makeURLrec($URL . "pg/pages/view/" . $page['guid'], $page['last_action'],'daily',0.6);
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}

if($m == 'groups'){
	$groups = querydb($sqlgroups);
	if(!empty($groups)){
		while ($group = mysql_fetch_assoc($groups)) {
			$name = goodtitle($group['name']);
			$collect .= makeURLrec($URL . "pg/groups/" . $group['guid'] . "/" . $name, $group['time_updated'],'daily',0.9);	
			$collect .= makeURLrec($URL . "pg/groups/forum/" . $group['guid'], '','daily',0.9);
			$collect .= makeURLrec($URL . "pg/blog/group:" . $group['guid'], '','daily',0.9);
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}

if($m == 'blogs'){
	$blogs = querydb($sqlblogs);
	if(!empty($blogs)){
		while ($blog = mysql_fetch_assoc($blogs)) {
			$title = goodtitle($blog['title']);
			$collect .= makeURLrec($URL . "pg/blog/" . $blog['username'] . "/read/" . $blog['guid'] . "/" . $title, $blog['time_updated'],'daily',0.7);
			$collect .= makeURLrec($URL . "pg/blog/" . $blog['username'] . "/read/" . $blog['guid'] . "/" . $title . "?view=rss",$blog['time_updated'],'daily',0.7);
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}


if($m == 'events'){
	$events = querydb($sqlevents);
	if(!empty($events)){
		while ($event = mysql_fetch_assoc($events)) {
			$title = goodtitle($event['title']);
			$collect .= makeURLrec($URL . "pg/event_calendar/view/" . $event['guid'], $event['time_updated'],'hourly',0.5);
			$collect .= makeURLrec($URL . "pg/event_calendar/view/" . $event['guid'] . "?view=rss", $event['time_updated'] ,'hourly',0.5);
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}


if($m == 'files'){
	$files = querydb($sqlfiles);
	if(!empty($files)){
		while ($file = mysql_fetch_assoc($files)) {
			$title = goodtitle($files['title']);
			$collect .= makeURLrec($URL . "pg/file/" . $file['username'] . "/read/" . $files['guid'] . "/" . $title, $files['time_updated'],'hourly',0.4);
			$collect .= makeURLrec($URL . "pg/file/" . $file['username'] . "/read/" . $files['guid'] . "/" . $title . "?view=rss", $files['time_updated'],'hourly',0.4);
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}


if($m == 'bookmarks'){
	$bookmarks = querydb($sqlbookmark);
	if(!empty($bookmarks)){
		while ($bookmark = mysql_fetch_assoc($bookmarks)) {
			$title = goodtitle($bookmarks['title']);
			$collect .= makeURLrec($URL . "pg/bookmarks/" . $bookmark['username'] . "/read/" . $bookmark['guid'] . "/" . $title, $bookmark['time_updated'],'daily',0.3);
			$collect .= makeURLrec($URL . "pg/bookmarks/" . $bookmark['username'] . "/read/" . $bookmark['guid'] . "/" . $title . "?view=rss", $bookmark['time_updated'],'daily',0.3);
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}


if($m == 'categories'){
	$categories = querydb($sqlcategories);
	if(!empty($categories)){
		while ($category = mysql_fetch_assoc($categories)) {
			$tag = goodtag($category['string']);
			$collect .= makeURLrec($URL . "search/?tag=" . $tag , '','daily',0.2);
			$collect .= makeURLrec($URL . "search/?tag=" . $tag . "&amp;view=rss" , '','daily',0.2);
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}

if($m == 'blogarchive'){
	$blogarchives = querydb($sqlblogarchive);
	$exists = array();
	if(!empty($blogarchives)){
		while ($blogarchive = mysql_fetch_assoc($blogarchives)) {
			list($start, $end, $month) = monthspan($blogarchive);
			if(!array_key_exists($month, $exists)){
				$exists[$month] = 1;
				$collect .= makeURLrec($URL . "pg/blog/" . $blogarchive['username'] . "/archive/" . $start . "/" . $end, '','hourly',0.1);
				$collect .= makeURLrec($URL . "pg/blog/" . $blogarchive['username'] . "/archive/" . $start . "/" . $end . "?view=rss", '','hourly',0.1);
			}		
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}

if($m == 'grblogarchive'){
	$exists = array();
	$grblogarchives = querydb($sqlgrblogarchive);
	if(!empty($grblogarchives)){
		while ($grblogarchive = mysql_fetch_assoc($grblogarchives)) {
			list($start, $end, $month) = monthspan($grblogarchive);
			if(!array_key_exists($month, $exists)){
				$exists[$month] = 1;
				$collect .= makeURLrec($URL . "pg/blog/group:" . $grblogarchive['username'] . "/archive/" . $start . "/" . $end, '','hourly',0.1);
				$collect .= makeURLrec($URL . "pg/blog/group:" . $grblogarchive['username'] . "/archive/" . $start . "/" . $end . "?view=rss", '','hourly',0.1);
			}
		}
	}
	$wrap = siteindex_wrapper($collect);
	sendit($wrap);
}


##################Functions###################

function monthspan($data){
	$year = date('Y', $data['time_created']);
	$month = date('m', $data['time_created']);
	$monthdays = date('t', $data['time_created']);
	$monthyear = $year . "-" . $month;
	$start = mktime(0, 0, 0, $month, 1, $year);
	$end = mktime(23, 59, 59, $month, $monthdays, $year);
	return array($start, $end, $data['username'] . ":" . $monthyear);
}

function goodtag($tag){	
	$pattern1 = '/[ ]/';
	$tag = preg_replace($pattern1,'+', $tag);
	$tag = strtolower($tag);
	return $tag;
}




function goodtitle($title){	
	$title = preg_replace('/[^ \w]/','', $title);
	$title = strtolower($title);
	$title = preg_replace('/\s/', '-', $title);
	return $title;
}

function querydb($sql){
	$result = mysql_query($sql);
	if (!$result) {
	    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
	    exit;
	}

        return $result;
}



function makeURLrec($in, $lastmod, $freq, $pri){
	global $URL;

	if($lastmod){
        	$date = date('Y-m-d',$lastmod);
	}else{
		$date = date('Y-m-d');
	}

	$collect="   <url>\n";
	$collect.="      <loc>$in</loc>\n";
	$collect.="      <lastmod>$date</lastmod>\n";
	$collect.="      <changefreq>$freq</changefreq>\n";
	$collect.="      <priority>$pri</priority>\n";
	$collect.="   </url>\n";
	return $collect;
}

function siteindex_wrapper($collect){
		$out = '<?xml version="1.0" encoding="UTF-8"?>'. "\n";
		$out .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'. "\n";
		$out .= $collect;
		$out .= '</urlset>'. "\n"; 
		return $out;
}

function makeSite($name){
	global $gzip;
	global $URL;
	#http://www.example.com/sitemap2.xml.gz
	$g = '';
	if($gzip == '.gz'){
		$g = ".gz";
	}
	$out = '<sitemap>'. "\n";
      	$out .= "<loc>$URL" . "$name.xml" . $g . "</loc>\n";
      	$out .= '  <lastmod>' . date('Y-m-d') . '</lastmod>'. "\n";
   	$out .= '</sitemap>'. "\n";
	return $out;
}


function sitelist_wrapper($collect){
	$out = '<?xml version="1.0" encoding="UTF-8"?>'. "\n";
	$out .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'. "\n";
	$out .= $collect;
	$out .= '</sitemapindex>'. "\n";
	return $out;
}

function normal_out($out){
	echo header("content-type: text/xml");
	echo $out;
}

function gzip_out($out){
	$compressed = gzencode($out, 9);
	echo header("Content-type: gzip");
	echo $compressed;
}

function sendit($in){
	global $gzip;
	if($gzip == ''){
		normal_out($in);
	}elseif($gzip == '.gz'){
		gzip_out($in);
	}
}



?>
