<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Add/Remove editor",
		'vazco_tinymce:settings:option' => 'Choose the way tinymce should be displayed',
		'vazco_tinymce:option:emoticons' => 'Simple version (with emoticons)',
		'vazco_tinymce:option:full' => 'Full version',
		'vazco_tinymce:option:plain' => 'Simple version (without emoticons)',
	
	);
					
	add_translation("en",$english);

?>