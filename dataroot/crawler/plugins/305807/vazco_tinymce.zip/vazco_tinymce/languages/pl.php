<?php

	$polish = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "W�acz/wy��cz edytor",
	
	);
					
	add_translation("pl",$polish);

?>