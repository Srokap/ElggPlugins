<?php 

$mode = get_plugin_setting('option','vazco_tinymce');
if ($mode == null)
	$mode = 'plain';
	
if (isset($vars['tinymce_mode'])){
	$mode = $vars['tinymce_mode'];
}

	echo elgg_view('vazco_tinymce/input/'.$mode,$vars);
?>