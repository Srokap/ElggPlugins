<?php 
$entity = $vars['entity'];
?>
	<p>
	    <?php echo elgg_echo('vazco_tinymce:settings:option'); ?> 
	    <select name="params[option]">
	        <option value="emoticons" <?php if ($entity->option == 'emoticons') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('vazco_tinymce:option:emoticons'); ?></option>
	        <option value="full" <?php if ($entity->option == 'full') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('vazco_tinymce:option:full'); ?></option>
			<option value="plain" <?php if ($entity->option == 'plain') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('vazco_tinymce:option:plain'); ?></option>
	    </select> 
	</p>