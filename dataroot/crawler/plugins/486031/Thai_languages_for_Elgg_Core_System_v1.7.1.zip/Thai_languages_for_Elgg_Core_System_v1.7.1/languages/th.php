<?php
/**
 * Activity viewer
 *
 * @package Elgg
 * @subpackage Core
 * @author Pisan Chueachatchai
 * @link http://elgg.in.th/
 */

	$thai = array(

		/**
		 * Sites
		 */
	
			'item:site' => 'ไซต์',
	
		/**
		 * Sessions
		 */
			
			'login' => "เข้าสู่ระบบ",
			'loginok' => "คุณได้เข้าสู่ระบบแล้ว",
			'loginerror' => "เราไม่สามารถเข้าสู่ระบบซึ่งอาจเป็นเพราะคุณยังไม่ได้ตรวจสอบบัญชีของคุณ หรือรายละเอียดของคุณไม่ถูกต้อง. ตรวจสอบให้แน่ใจว่ารายละเอียดของคุณถูกต้องโปรดลองอีกครั้ง",
	
			'logout' => "ออกจากระบบ",
			'logoutok' => "คุณได้ออกจากระบบ",
			'logouterror' => "คุณไม่สามารถออกจากระบบ โปรดลองอีกครั้ง",

	                'loggedinrequired' => "คุณต้องเข้าสู่ระบบก่อนถึงจะดูหน้านี้ได้.",
	                'adminrequired' => "เฉพาะผู้ดูแลเท่านั้นถึงจะดูหน้านี้ได้",
	                'membershiprequired' => "คุณต้องเป็นสมาชิกในกลุ่มนี้ก่อน",


		/**
		 * Errors
		 */
			'exception:title' => "ยินดีต้อนรับ",
	
			'InstallationException:CantCreateSite' => "ไม่สามารถสร้างใบรับรอง ชื่อ:%s, Url: %s",
		
			'actionundefined' => "การร้องขอ (%s) ไม่มีในระบบ",
			'actionloggedout' => "ขออภัยคุณไม่สามารถดำเนินการกระทำนี้ในขณะที่ออกจากระบบ",

			'SecurityException:Codeblock' => "ถูกปฏิเสธการเข้าถึง",
			'DatabaseException:WrongCredentials' => "Elgg ไม่สามารถเชื่อมต่อกับฐานข้อมูลการใช้ให้ใบรับรอง %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Elgg ไม่สามารถใช้ฐานข้อมูล '%s', โปรดตรวจสอบว่าข้อมูลจะถูกสร้างขึ้นและคุณสามารถเข้าถึงมัน",
			'SecurityException:FunctionDenied' => "การเข้าถึง '%s' ถูกปฏิเสธ",
			'DatabaseException:DBSetupIssues' => "จำนวนปัญหา: ",
			'DatabaseException:ScriptNotFound' => "Elgg ไม่พบฐานข้อมูลสคริปต์ที่ %s.",
			
			'IOException:FailedToLoadGUID' => "ไม่สามารถโหลด %s จาก GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d ไม่ใช่ %s",
			
			'PluginException:MisconfiguredPlugin' => "%s ไม่สามารถตั้งค่าปลั๊กอินได้เนื่องจากหาไฟล์ไม่เจอ",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "ไม่สามารถบันทึก %s",
			
			'InvalidParameterException:GUIDNotForExport' => "GUID ยังไม่ได้รับการส่งออกที่ระบุในขั้นตอนนี้ไม่ควรเกิดขึ้น",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "ที่เก็บแคชไม่ได้ตั้งไว้!",
			'IOException:NotDirectory' => "%s ไม่ใช่ไดเรคทอรี่.",
			
			'IOException:BaseEntitySaveFailed' => "ไม่สามารถบันทึกการทำงานได้!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",
			
			'ClassException:ClassnameNotClass' => "%s ไม่ใช่ %s.",
			'ClassNotFoundException:MissingClass' => "คลาส '%s' ไม่พบ, ปลั๊กอินหายไป?",
			'InstallationException:TypeNotSupported' => "ประเภท %s ไม่ได้รับการสนับสนุน. นี้แสดงข้อผิดพลาดในการติดตั้งอาจเกิดจากการปรับรุ่นที่ไม่สมบูรณ์.",

			'ImportException:ImportFailed' => "ไม่สามารถนำเข้าองค์ประกอบ %d",
			'ImportException:ProblemSaving' => "เกิดปัญหาในการบันทึก %s",
			'ImportException:NoGUID' => "สร้างใหม่ Entity แต่ไม่มี GUID, สิ่งนี้ไม่ควรเกิดขึ้น.",
			
			'ImportException:GUIDNotFound' => "Entity '%d' ไม่พบ.",
			'ImportException:ProblemUpdatingMeta' => "มีปัญหาในการปรับปรุง '%s' บน '%d'",
			
			'ExportException:NoSuchEntity' => "ไม่มี entity GUID:%d",
			
			'ImportException:NoODDElements' => "ไม่ OpenDD องค์ประกอบที่พบในการนำเข้าข้อมูลการนำเข้าล้มเหลว",
			'ImportException:NotAllImported' => "องค์ประกอบทั้งหมดไม่ได้นำเข้า.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
			'InvalidParameterException:MissingOwner' => "ไฟล์ทั้งหมดจะต้องมีเจ้าของ!",
			'IOException:CouldNotMake' => "ไม่สามารถสร้าง %s",
			'IOException:MissingFileName' => "คุณต้องระบุชื่อก่อนเปิดไฟล์.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "ไม่พบหรือคลาสไม่ได้บันทึกกับไฟล์!",
			'NotificationException:NoNotificationMethod' => "ไม่มีการแจ้ง",
			'NotificationException:NoHandlerFound' => "ไม่มีการดำเนินการสำหรับ'%s' หรือไม่ได้ เรียกใช้",
			'NotificationException:ErrorNotifyingGuid' => "มีข้อผิดพลาดในขณะที่แจ้งให้ทราบ %d",
			'NotificationException:NoEmailAddress' => "ไม่ได้รับที่อยู่อีเมลสำหรับ GUID:%d",
			'NotificationException:MissingParameter' => "พารามิเตอร์ไม่ครบ, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
			'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
			'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
			'InvalidParameterException:NoDataFound' => "Could not find any data.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
			
                        'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			'ConfigurationException:NoSiteID' => "No site ID has been specified.",
						'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()",
	                'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",
	                'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
			'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
			'APIException:ParameterNotArray' => "%s does not appear to be an array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
	'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s must be called using '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
	'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
	'APIException:MissingAPIKey' => "Missing API key",
	'APIException:BadAPIKey' => "Bad API key",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
			'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
			'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
			'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",
	
			'PluginException:NoPluginName' => "The plugin name could not be found",
	
			'ConfigurationException:BadDatabaseVersion' => "The database backend you have installed doesn't meet the basic requirements to run Elgg. Please consult your documentation.",
			'ConfigurationException:BadPHPVersion' => "You need at least PHP version 5.2 to run Elgg.",
			'configurationwarning:phpversion' => "Elgg requires at least PHP version 5.2, you can install it on 5.1.6 but some features may not work. Use at your own risk.",
	
	
			'InstallationException:DatarootNotWritable' => "Your data directory %s is not writable.",
			'InstallationException:DatarootUnderPath' => "Your data directory %s must be outside of your install path.",
			'InstallationException:DatarootBlank' => "You have not specified a data directory.",
	
			'SecurityException:authenticationfailed' => "User could not be authenticated",
	
			'CronException:unknownperiod' => '%s is not a recognised period.',
	
			'SecurityException:deletedisablecurrentsite' => 'You can not delete or disable the site you are currently viewing!',
	
			'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
			'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
			'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
			'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',
	
			'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',
	
			'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
		/**
		 * API
		 */
			'system.api.list' => "List all available API calls on the system.",
			'auth.gettoken' => "This API call lets a user log in, returning an authentication token which can be used in leu of a username and password for authenticating further calls.",
	
		/**
		 * User details
		 */

            'name' => "ชื่อที่ใช้แสดง(ทุกคนจะเห็น)",
            'email' => "อีเมล์",
			'username' => "ชื่อล๊อคอิน(ภาษาอังกฤษเท่านั้น)",
			'password' => "รหัสผ่าน",
			'passwordagain' => "รหัสผ่านอีกครั้ง (เพื่อยืนยัน)",
			'admin_option' => "ให้สามาชิกเป็นผู้ดูแล?",
	
		/**
		 * Access
		 */
	
			'PRIVATE' => "ส่วนตัว",
			'LOGGED_IN' => "สมาชิกในเว็บ",
			'PUBLIC' => "ทั่วไป",
			'access:friends:label' => "เฉพาะเพื่อนฉัน",
			'access' => "การเข้าถึง",
	
		/**
		 * Dashboard and widgets
		 */
	
			'dashboard' => "กระดานข้อมูล",
            'dashboard:configure' => "แก้ไขหน้านี้",
			'dashboard:nowidgets' => "กระดานข้อมูลของคุณเป็นที่สามารถมาดูความเคลือนไหวของในเว็บไซต์. คลิกที่ 'แก้ไขหน้านี้' เพื่อเพิ่มเครื่องมือเพื่อติดตามเนื้อหาของคุณและภายในระบบ",

			'widgets:add' => 'เพิ่มวิดเก็ตไปยังหน้านี้',
			'widgets:add:description' => "เลือกวิดเก็ตที่คุณต้องการเพิ่มไปยังหน้าเว็บของคุณโดยการลากได้จากคลังที่ <b>คลังวิดเก็ต</b>จากด้านขวามือ โดยลากไปวางในช่องสามช่องที่เห็น โดยสามารจัดได้ตามต้องการ <b>หากต้องการลบ</b>ให้ลากวิดเก็ตกลับไปที่ <b>คลังวิดเก็ต</b>.",

            'widgets:position:fixed' => '(คงตำแหน่งในเพจ)',
	
			'widgets' => "วิดเก็ต",
			'widget' => "วิดเก็ต",
			'item:object:widget' => "วิดเก็ต",
			'layout:customise' => "ปรับรูปแบบ",
			'widgets:gallery' => "คลังวิดเก็ต",
			'widgets:leftcolumn' => "วิดเก็ตซ้าย",
			'widgets:fixed' => "คงตำแหน่งในเพจ",
			'widgets:middlecolumn' => "วิดเก็ตกลาง",
			'widgets:rightcolumn' => "วิดเก็ตขวา",
			'widgets:profilebox' => "กล่องโปรไฟล์",
			'widgets:panel:save:success' => "วิดเก็ตของคุณถูกบันทึกเรียบร้อยแล้ว",
			'widgets:panel:save:failure' => "เกิดปัญหาในการบันทึกวิดเก็ตของคุณ โปรดลองอีกครั้ง",
			'widgets:save:success' => "วิดเก็ตของคุณถูกบันทึกเรียบร้อยแล้ว",
			'widgets:save:failure' => "เกิดปัญหาในการบันทึกวิดเก็ตของคุณ โปรดลองอีกครั้ง",
		        'widgets:handlernotfound' => 'This widget is either broken or has been disabled by the site administrator.',

		/**
		 * Groups
		 */
	
			'group' => "กลุ่ม",
			'item:group' => "กลุ่ม",
	
/**
 * Users
 */

	'user' => "สมาชิก",
	'item:user' => "สมาชิก",

		/**
		 * Friends
		 */
	
			'friends' => "เพื่อน",
			'friends:yours' => "เพื่อนของคุณ",
			'friends:owned' => "%s's เพื่อน",
			'friend:add' => "เพิ่มเพื่อน",
			'friend:remove' => "ลบเพื่อน",
	
			'friends:add:successful' => "เพิ่ม %s เป็นเพื่อนแล้ว",
			'friends:add:failure' => "ไม่สามารถเพิ่ม %s เป็นเพื่อนได้ โปรดลองอีกครั้ง",
	
			'friends:remove:successful' => "ลบ %s ออกจากการเป็นเพื่อนแล้ว",
			'friends:remove:failure' => "ไม่สามารถลบ %s ออกจากการเป็นเพื่อนได้ โปรดลองอีกครั้ง",
	
			'friends:none' => "สมาชิกผู้นี้ยังไม่มีเพื่อน",
			'friends:none:you' => "คุณยังไม่ได้เพิ่มใครเป็นเพื่อน! ค้นหาความสนใจของคุณเพื่อเริ่มต้นการค้นหาเพื่อนต่อไป",
	
			'friends:none:found' => "ไม่พบเพื่อนเลย",
	
			'friends:of:none' => "ไม่มีใครได้เพิ่มผู้ใช้รายนี้เป็นเพื่อน.",
			'friends:of:none:you' => "ไม่มีใครได้เพิ่มคุณเป็นเพื่อน เริ่มต้นการเพิ่มเนื้อหาและการกรอกข้อมูลลงในโปรไฟล์ของคุณให้ผู้อื่นได้เห็นข้อมูลคุณ!",
	
			'friends:of:owned' => "มีคนเพิ่ม %s เป็นเพื่อน",

			 'friends:num_display' => "จำนวนเพื่อนที่จะแสดง",
			 'friends:icon_size' => "ขนาดของไอคอน",
			 'friends:tiny' => "เล็กสุดๆ",
			 'friends:small' => "เล็ก",
			 'friends:of' => "เป็นเพื่อนของ",
			 'friends:collections' => "ประเภทของเพื่อน",
			 'friends:collections:add' => "เพิ่มประเภทของเพื่อน",
			 'friends:addfriends' => "เพิ่มเพื่อน",
			 'friends:collectionname' => "ชื่อประเภท",
			 'friends:collectionfriends' => "เพื่อนในประเภท",
			 'friends:collectionedit' => "แก้ไขประเภทนี้",
			 'friends:nocollections' => "คุณยังไม่มีการรวบรวมเพื่อนเป็นประเภท",
			 'friends:collectiondeleted' => "ลบประเภทแล้ว",
			 'friends:collectiondeletefailed' => "เราไม่สามารถลบประเภท. หรือคุณไม่ได้รับอนุญาตหรือมีปัญหาอื่นๆที่เกิดขึ้น.",
			 'friends:collectionadded' => "สร้างประเภทของคุณแล้ว",
			 'friends:nocollectionname' => "คุณต้องใส่ชื่อของประเภทก่อน.",
			'friends:collections:members' => "ประเภทสมาชิก",
			'friends:collections:edit' => "แก้ไขประเภท",
		
	        'friends:river:created' => "%s เพิ่มวิดเก็ตเพื่อน",
	        'friends:river:updated' => "%s อัปเดตวิดเก็ตเพื่อน",
	        'friends:river:delete' => "%s ลบวิดเก็ตเพื่อน",
	        'friends:river:add' => "%s เพิ่มใครบางคนเป็นเพื่อน",
	
			'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
	
		/**
		 * Feeds
		 */
			'feed:rss' => 'สมัครรับฟีด',
			'feed:odd' => 'Syndicate OpenDD',
			
		/**
          * links
		 **/

			'link:view' => 'ดูลิ้งค์',

	
		/**
		 * River
		 */
			'river' => "River",			
			'river:relationship:friend' => 'ตอนนี้เป็นเพื่อนของ',
			'river:noaccess' => 'คุณไม่มีสิทธิเข้าดูหน้านี้.',
			'river:posted:generic' => '%s โพส',
	                'riveritem:single:user' => 'คน',
	                'riveritem:plural:user' => 'บางคน',

		/**
		 * Plugins
		 */
			'plugins:settings:save:ok' => "การตั้งค่าสำหรับปลั๊กอิน %s ถูกบันทึกเรียบร้อยแล้ว",
			'plugins:settings:save:fail' => "เกิดปัญหาในการบันทึกการตั้งค่าสำหรับปลั๊กอิน %s ",
			'plugins:usersettings:save:ok' => "การตั้งค่าของผู้ใช้สำหรับปลั๊กอิน %s  ถูกบันทึกเรียบร้อยแล้ว",
			'plugins:usersettings:save:fail' => "เกิดปัญหาในการบันทึกการตั้งค่าผู้ใช้สำหรับปลั๊กอิน %s ",
                        'admin:plugins:label:version' => "รุ่น",
			'item:object:plugin' => 'การกำหนดค่าคอนฟิก ปลั๊กอิน',
			
		/**
		 * Notifications
		 */
			'notifications:usersettings' => "การตั้งค่าระบบแจ้งเตือน",
			'notifications:methods' => "กรุณาระบุวิธีการที่คุณต้องการอนุญาต",
	
			'notifications:usersettings:save:ok' => "ตั้งค่าการแจ้งเตือนถูกบันทึกเรียบร้อยแล้ว",
			'notifications:usersettings:save:fail' => "กิดปัญหาในการบันทึกการตั้งค่าการแจ้งเตือนของท่าน",
	
			'user.notification.get' => 'กลับไปตั้งค่าการแจ้งสำหรับสมาชิก',
			'user.notification.set' => 'ตั้งค่าการแจ้งเตือนสำหรับสมาชิก',
		/**
		 * Search
		 */
	
			'search' => "ค้นหา",
			'searchtitle' => "ค้นหา: %s",
			'users:searchtitle' => "ค้นหาสมาชิก: %s",
			'groups:searchtitle' => "ค้นหาสำหรับกลุ่ม: %s",
			'advancedsearchtitle' => "%s ผลลัพธ์การค้น %s",
			'notfound' => "ไม่พบผลลัพธ์",
			'next' => "ต่อไป",
			'previous' => "ย้อนกลับ",
	
			'viewtype:change' => "เปลี่ยนหารแสดงผล",
			'viewtype:list' => "รายการ",
			'viewtype:gallery' => "แกลลอรี่",
	
			'tag:search:startblurb' => "รายการที่มีแท็กที่ตรงกัน '%s':",

			'user:search:startblurb' => "สมาชิกที่พบ '%s':",
			'user:search:finishblurb' => "ดูเพิ่มเติมคลิก",

			'group:search:startblurb' => "กลุ่มที่ตรงกับ '%s':",
			'group:search:finishblurb' => "เพื่อดูข้อมูลเพิ่มเติมคลิกที่นี่.",
			'search:go' => 'ไป',
	                'userpicker:only_friends' => 'เฉพาะเพื่อน',
	
		/**
		 * Account
		 */
	
			'account' => "บัญชี",
			'settings' => "ตั้งค่า",
                        'tools' => "เครื่องมือ",
                        'tools:yours' => "เครื่องมือของคุณ",
	
			'register' => "สมัครสมาชิก",
			'registerok' => "คุณได้ลงทะเบียนสำหรับ %s แล้ว",
			'registerbad' => "การลงทะเบียนของคุณไม่สำเร็จ ชื่อผู้ใช้อาจมีอยู่แล้ว รหัสผ่านอาจไม่เหมือนกันหรือชื่อผู้ใช้หรือรหัสผ่านอาจสั้นเกินไป.",
			'registerdisabled' => "ลงทะเบียนถูกระงับการใช้งานโดยผู้ดูแลระบบ",
	
			'firstadminlogininstructions' => 'Elgg ได้ถูกติดตั้งแล้วและได้สร้างผู้ดูแลแล้ว ตอนนี้คุณสามารถเข้าไปติดตั้งปลั๊กอินต่างๆได้',
	
			'registration:notemail' => 'อีเมลไม่ถูกต้อง',
			'registration:userexists' => 'ชื่อล๊อคอินนี้มีคนใช้แล้ว',
			'registration:usernametooshort' => 'ชื่อล๊อคอินของคุณต้องมีอย่างน้อย 4 ตัวอักษร',
			'registration:passwordtooshort' => 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร',
			'registration:dupeemail' => 'ที่อยู่อีเมลนี้ได้รับการจดทะเบียนแล้ว',
			'registration:invalidchars' => 'ขออภัย ชื่อล๊อคอินของคุณมีอักขระไม่ถูกต้อง.',
			'registration:emailnotvalid' => 'ขออภัย ที่อยู่อีเมลที่คุณป้อนไม่ถูกต้อง',
			'registration:passwordnotvalid' => 'ขออภัย รหัสผ่านที่คุณป้อนไม่ถูกต้อง',
			'registration:usernamenotvalid' => 'ขออภัย ชื่อล๊อคอินที่คุณป้อนไม่ถูกต้อง',
	
			'adduser' => "เพิ่มสมาชิก",
			'adduser:ok' => "คุณได้เพิ่มสมาชิกใหม่",
			'adduser:bad' => "สมาชิกใหม่ไม่สามารถสร้างได้",
			
			'item:object:reported_content' => "แจ้งผู้ดูแล",
	
			'user:set:name' => "การตั้งค่าชื่อ",
			'user:name:label' => "ชื่อของคุณ",
			'user:name:success' => "ได้ทำการการเปลี่ยนชื่อของคุณในระบบแล้ว",
			'user:name:fail' => "ไม่สามารถเปลี่ยนชื่อของคุณในระบบได้",
	
			'user:set:password' => "ตั้งค่ารหัสผ่าน",
			'user:password:label' => "รหัสผ่านใหม่ของคุณ",
			'user:password2:label' => "ใส่รหัสผ่านใหม่ของคุณอีกครั้ง",
			'user:password:success' => "เปลี่ยนรหัสผ่านแล้ว",
			'user:password:fail' => "ไม่สามารถเปลี่ยนรหัสผ่านได้",
			'user:password:fail:notsame' => "รหัสผ่านสองรายการไม่เหมือนกัน!",
			'user:password:fail:tooshort' => "รหัสผ่านสั้นเกินไป!",
		        'user:resetpassword:unknown_user' => 'ไม่รู้จักสมาชิกคนนี้',
	                'user:resetpassword:reset_password_confirm' => 'การเปลี่ยนรหัสผ่านใหม่ กรุณาไปตรวจสอบอีเมลที่คุณสมัครไว้',

			'user:set:language' => "ตั้งค่าภาษา",
			'user:language:label' => "ภาษาที่เลือก",
			'user:language:success' => "การตั้งค่าภาษาของคุณได้รับการอัปเดท",
			'user:language:fail' => "การตั้งค่าภาษาของคุณไม่สามารถบันทึก",
	
			'user:username:notfound' => 'ชื่อล๊อคอิน %s ไม่มี',
	
			'user:password:lost' => 'ลืมรหัสผ่าน',
			'user:password:resetreq:success' => 'การขอรหัสผ่านใหม่สำเร็จ และถูกส่งไปที่อีเมลของคุณ',
			'user:password:resetreq:fail' => 'ไม่สามารถขอรหัสผ่านใหม่ได้',
	
			'user:password:text' => 'เพื่อสร้างรหัสผ่านใหม่ให้ป้อนชื่อล๊อคอินของคุณด้านล่างนี้. เราจะส่งที่อยู่ของหน้าการยืนยันไปให้คุณผ่านทางอีเมล คลิกที่ลิงค์ในเนื้อหาของข้อความและรหัสผ่านใหม่จะส่งถึงคุณ',
	
			'user:persistent' => 'อยู่ในระบบตลอด',
		/**
		 * Administration
		 */

			'admin:configuration:success' => "การตั้งค่าของคุณถูกบันทึก",
			'admin:configuration:fail' => "การตั้งค่าของคุณบันทึกไม่ได้",
	
			'admin' => "ส่วนของผู้ดูแล",
			'admin:description' => "ส่วนของผู้ดูแลสามารถควบคุมทุกๆด้านของระบบ การจัดการสมาชิก ปลั๊กอิน เลือกตัวเลือกด้านล่างเพื่อเริ่มต้น",
			
			'admin:user' => "สมาชิกที่เป็นผู้ดูแลระบบ",
			'admin:user:description' => "ส่วนผู้ดูแลระบบนี้ช่วยให้คุณสามารถควบคุมการตั้งค่าสำหรับสมาชิกเว็บไซต์ของคุณ. เลือกตัวเลือกด้านล่างเพื่อเริ่มต้น.",
			'admin:user:adduser:label' => "คลิกเพื่อมเพิ่มสมาชิกใหม่...",
			'admin:user:opt:linktext' => "กำหนดค่าสมาชิก...",
			'admin:user:opt:description' => "กำหนดค่าสมาชิกและข้อมูล ",
			
			'admin:site' => "ตั้งค่าเว็บ",
			'admin:site:description' => "This admin panel allows you to control global settings for your site. Choose an option below to get started.",
			'admin:site:description' => "ส่วนผู้ดูแลระบบนี้ช่วยให้คุณสามารถควบคุมการตั้งค่าทั่วไปสำหรับเว็บไซต์ของคุณ. เลือกตัวเลือกด้านล่างเพื่อเริ่มต้น.",
			'admin:site:opt:linktext' => "ตั้งค่าเว็บ...",
			'admin:site:opt:description' => "ตั้งค่าเว็บไซต์",
			
			'admin:plugins' => "จัดการปลั๊กอิน",
			'admin:plugins:description' => "ส่วนผู้ดูแลระบบนี้ จะช่วยให้คุณสามารถควบคุมและกำหนดค่าเครื่องมือติดตั้งอยู่บนเว็บไซต์ของท่าน.",
			'admin:plugins:opt:linktext' => "จัดการปลั๊กอิน...",
			'admin:plugins:opt:description' => "ตั้งค่าปลั๊กอินที่ติดตั้งอยู่ในเว็บไซต์. ",
			'admin:plugins:label:author' => "ผู้สร้าง",
			'admin:plugins:label:copyright' => "ลิขสิทธิ์",
			'admin:plugins:label:licence' => "ใบอนุญาต",
			'admin:plugins:label:website' => "URL",
			"admin:plugins:label:moreinfo" => 'ข้อมูลเพิ่มเติม',
			'admin:plugins:label:version' => 'รุ่น',
			'admin:plugins:warning:elggversionunknown' => 'คำเตือน: ปลั๊กอินนี้อาจไม่รองรับ ELGG ที่คุณใช้',
			'admin:plugins:warning:elggtoolow' => 'คำเตือน: ปลั๊กอินนี้ต้องการ ELGG รุ่นล่าสุด!',
			'admin:plugins:reorder:yes' => "ปลั๊กอิน %s เปลี่ยนลำดับแล้ว",
			'admin:plugins:reorder:no' => "ปลั๊กอิน %s ไม่สามารถเปลี่ยนลำดับ.",
			'admin:plugins:disable:yes' => "ปลั๊กอิน %s ถูกปิดการใช้งานเรียบร้อยแล้ว",
			'admin:plugins:disable:no' => "ปลั๊กอิน %s ไม่สามารถปิดการใช้งานได้",
			'admin:plugins:enable:yes' => "ปลั๊กอิน %s ถูกเปิดการใช้งานเรียบร้อยแล้ว",
			'admin:plugins:enable:no' => "ปลั๊กอิน %s ไม่สามารถเปิดใช้งานได้",
	
			'admin:statistics' => "สถิติ",
			'admin:statistics:description' => "นี่เป็นภาพรวมของสถิติในเว็บไซต์ของคุณ หากท่านต้องการรายละเอียดเพิ่มเติม ",
			'admin:statistics:opt:description' => "ดูสถิติเกี่ยวกับผู้ใช้และออบเจกต์บนเว็บไซต์ของท่าน",
			'admin:statistics:opt:linktext' => "ดูสถิติ...",
			'admin:statistics:label:basic' => "สถิติพื้นฐานของเว็บไซต์",
			'admin:statistics:label:numentities' => "กลุ่มข้อมูล",
			'admin:statistics:label:numusers' => "จำนวนสมาชิก",
			'admin:statistics:label:numonline' => "จำนวนสมาชิกออนไลน์",
			'admin:statistics:label:onlineusers' => "สมาชิกออนไลน์ตอนนี้",
			'admin:statistics:label:version' => "Elgg รุ่น",
			'admin:statistics:label:version:release' => "รีรีส",
			'admin:statistics:label:version:version' => "รุ่น",
	
			'admin:user:label:search' => "ค้นหาสมาชิก:",
			'admin:user:label:seachbutton' => "ค้นหา",
	
			'admin:user:ban:no' => "ไม่สามารถแบนสมาชิกได้",
			'admin:user:ban:yes' => "สมาชิกโดนแบน",
			'admin:user:unban:no' => "ไม่สามารถถอนการแบนสมาชิกได้",
			'admin:user:unban:yes' => "สมาชิกถูกถอนจากการแบน",
			'admin:user:delete:no' => "ไม่สามารรถลบสมาชิกได้",
			'admin:user:delete:yes' => "ลบสมาชิก",
	
			'admin:user:resetpassword:yes' => "รีเซ็ตรหัสผ่าน และแจ้งไปยังสมาชิก",
			'admin:user:resetpassword:no' => "ไม่สามารถรีเซ็ตรหัสผ่าน",
	
			'admin:user:makeadmin:yes' => "สมาชิกเป็นผู้ดูแล",
			'admin:user:makeadmin:no' => "เราไม่สามรถให้สมาชิกผู้นี้เป็นผู้ดูแลได้",
	
			'admin:user:removeadmin:yes' => "ผู้ใช้ไม่เป็นผู้ดูแลระบบ",
			'admin:user:removeadmin:no' => "เราไม่สามารถลบสิทธิ์ผู้ดูแลระบบจากผู้ใช้รายนี้",
			
		/**
		 * User settings
		 */
			'usersettings:description' => "แผงควบคุมการตั้งค่าช่วยให้คุณสามารถควบคุมการตั้งค่าส่วนตัวทั้งหมดของคุณ",
	
			'usersettings:statistics' => "สถิติของคุณ",
			'usersettings:statistics:opt:description' => "ดูสถิติเกี่ยวกับผู้ใช้และออบเจกต์บนเว็บไซต์ของท่าน.",
			'usersettings:statistics:opt:linktext' => "สถิติ",
	
			'usersettings:user' => "ตั้งค่าส่วนตัว",
			'usersettings:user:opt:description' => "ส่วนนี้ช่วยให้คุณสามารถควบคุมการตั้งค่าสมาชิก",
			'usersettings:user:opt:linktext' => "เปลี่ยนแปลงการตั้งค่า",
	
			'usersettings:plugins' => "เครื่องมือ",
			'usersettings:plugins:opt:description' => "กำหนดค่าการตั้งค่าของคุณสำหรับการใช้งานเครื่องมือ.",
			'usersettings:plugins:opt:linktext' => "ตั้งค่าเครื่องมือของคุณ",
	
			'usersettings:plugins:description' => "แผงควบคุมนี้จะช่วยให้คุณสามารถควบคุมและกำหนดค่าส่วนบุคคล การตั้งค่าเครื่องมือที่ติดตั้งโดยผู้ดูแลระบบของคุณ.",
			'usersettings:statistics:label:numentities' => "ข้อมูลการใช้งาน",
	
			'usersettings:statistics:yourdetails' => "รายละเอียดของคุณ",
			'usersettings:statistics:label:name' => "ชื่อจริง",
			'usersettings:statistics:label:email' => "อีเมล์",
			'usersettings:statistics:label:membersince' => "เป็นสมาชิกเมื่อ",
			'usersettings:statistics:label:lastlogin' => "เข้าสู่ระบบครั้งสุดท้ายเมื่อ",
	
			
	
		/**
		 * Generic action words
		 */
	
			'save' => "บันทึก",
			'publish' => "แผยแพร่",
			'cancel' => "ยกเลิก",
			'saving' => "กำลังบันทึก ...",
			'update' => "อัปเดต",
			'edit' => "แก้ไข",
			'delete' => "ลบ",
			'accept' => "ยอมรับ",
			'load' => "โหลด",
			'upload' => "อัปโหลด",
			'ban' => "แบน",
			'unban' => "ไม่แบน",
			'enable' => "ทำงาน",
			'disable' => "ไม่ทำงาน",
			'request' => "ต้องการ",
			'complete' => "สำเร็จ",
			'open' => 'เปิด',
			'close' => 'ปิด',
			'reply' => "ตอบกลับ",
			'more' => 'อิ่นๆ',
			'comments' => 'ความคิดเห็น',
			'import' => 'นำเข้า',
			'export' => 'ส่งออก',
	                'untitled' => 'ไม่ระบุ',
	                'help' => 'ช่วยเหลือ',
	                'send' => 'ส่ง',
	                'post' => 'โพส',
	                'submit' => 'บันทึก',
	                'site' => 'เว็บ',
	
			'up' => 'บน',
			'down' => 'ล่าง',
			'top' => 'บนสุด',
			'bottom' => 'ล่างสุด',
	
			'invite' => "คำเชิญ",
	
			'resetpassword' => "ตั้งค่ารหัสผ่านใหม่",
			'makeadmin' => "ให้เป้นผู้ดูแล",
			'removeadmin' => "ยกเลิกการเป็นผู้ดูแล",
	
			'option:yes' => "ใช่",
			'option:no' => "ไม่",
	
			'unknown' => 'ไม่รู้',
	
			'active' => 'ทำงาน',
			'total' => 'ทั้งหมด',
	
			'learnmore' => "คลิกที่นี่เพื่อเรียนรู้เพิ่มเติม",
	
			'content' => "เนื้อหา",
			'content:latest' => 'กิจกรรมล่าสุด',
			'content:latest:blurb' => 'คลิกที่นี่เพื่อดูเนื้อหาล่าสุดจากทั้งเว็บไซต์',
	
			'link:text' => 'ดูลิ้งค์',
	
			'enableall' => 'สั่งให้ทำงานทั้งหมด',
			'disableall' => 'ยกเลิกการทำงานทั้งหมด',
	
		/**
		 * Generic questions
		 */
	
			'question:areyousure' => 'แน่ใจแล้วหรือ?',
	
		/**
		 * Generic data words
		 */
	
			'title' => "ชื่อ",
			'description' => "รายละเอียด",
			'tags' => "แท็ก",
			'spotlight' => "Spotlight",
			'all' => "ทั้งหมด",
	
			'by' => 'โดย',
	
			'annotations' => "บันทึกย่อ",
			'relationships' => "ความสัมพันธ์",
			'metadata' => "เมตาดาต้า",
	
		/**
		 * Input / output strings
		 */

			'deleteconfirm' => "คุณแน่ใจหรือไม่ว่าต้องการลบรายการนี้?",
			'fileexists' => "ไฟล์ได้ถูกอัปโหลด. หากต้องการใช้แทนที่ เลือกด้านล่าง:",
			
		/**
		 * User add
		 */

			'useradd:subject' => 'สมาชิกใหม่',
			'useradd:body' => '
%s,

คุณได้เป็นสมาชิกที่ี่  %s. หากต้องการเข้าสู่ระบบให้ไปที่:

	%s

โดยใช้ข้อมูลด้านล่าง:

	Username: %s
	Password: %s
	
	
เมื่อคุณเข้าสู่ระบบเราขอแนะนำให้คุณเปลี่ยนรหัสผ่าน',
			
	    /**
         * System messages
         **/

			'systemmessages:dismiss' => "คลิกเพื่อละทิ้ง",

	
		/**
		 * Import / export
		 */
			'importsuccess' => "นำเข้าข้อมูลสำเร็จแล้ว",
			'importfail' => "OpenDD นำเข้าข้อมูลไม่สำเร็จ",
	
		/**
		 * Time
		 */
	
			'friendlytime:justnow' => "ตอนนี้",
			'friendlytime:minutes' => "%s นาทีที่แล้ว",
			'friendlytime:minutes:singular' => "นาทีนี้",
			'friendlytime:hours' => "%s ชั่วโมงที่แล้ว",
			'friendlytime:hours:singular' => "ชัวโมงนี้",
			'friendlytime:days' => "%s วันที่แล้ว",
			'friendlytime:days:singular' => "เมื่อวาน",
	          'friendlytime:date_format' => 'j F Y @ g:ia',
	
			'date:month:01' => 'มกราคม %s',
			'date:month:02' => 'กุมภาพันธ์%s',
			'date:month:03' => 'มีนาคม %s',
			'date:month:04' => 'เมษายน %s',
			'date:month:05' => 'พฤษภาคม %s',
			'date:month:06' => 'มิถุนายน %s',
			'date:month:07' => 'กรกฎาคม %s',
			'date:month:08' => 'สิงหาคม %s',
			'date:month:09' => 'กันยายน %s',
			'date:month:10' => 'ตุลาคม %s',
			'date:month:11' => 'พฤศจิกายน %s',
			'date:month:12' => 'ธันวาคม %s',
	
	
		/**
		 * Installation and system settings
		 */
	
			'installation:error:htaccess' => "Elgg ต้องการใช้ไฟล์ .htaccess ในการติดตั้ง. เราสามารถสร้างไฟล์ให้ได้หากไฟล์สามารถเขียนลงไปได้.

หรือสร้างง่ายๆ. คัดลอกข้อมูลด้านล่างแล้วบีนทึกเป็นไฟล์ .htaccess

",
			'installation:error:settings' => "Elgg couldn't find its settings file. Most of Elgg's settings will be handled for you, but we need you to supply your database details. To do this:

1. Rename engine/settings.example.php to settings.php in your Elgg installation.

2. Open it with a text editor and enter your MySQL database details. If you don't know these, ask your system administrator or technical support for help.

Alternatively, you can enter your database settings below and we will try and do this for you...",
	
	'installation:error:db:title' => "Database settings error",
	'installation:error:db:text' => "Check your database settings again as Elgg could not connect and access the database.",
			'installation:error:configuration' => "Once you've corrected any configuration issues, press reload to try again.",
	
			'installation' => "Installation",
			'installation:success' => "Elgg's database was installed successfully.",
			'installation:configuration:success' => "Your initial configuration settings have been saved. Now register your initial user; this will be your first system administrator.",
	
			'installation:settings' => "System settings",
			'installation:settings:description' => "Now that the Elgg database has been successfully installed, you need to enter a couple of pieces of information to get your site fully up and running. We've tried to guess where we could, but <b>you should check these details.</b>",
	
			'installation:settings:dbwizard:prompt' => "Enter your database settings below and hit save:",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (usually 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (usually 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "We were unable to save the new settings.php. Please save the following file as engine/settings.php using a text editor.",
	
			'installation:sitename' => "ชื่อเว็บ (เช่น \"My social networking site\"):",
			'installation:sitedescription' => "รายละเอียดย่อของเว็บ (optional)",
			'installation:wwwroot' => "The site URL, followed by a trailing slash:",
			'installation:path' => "The full path to your site root on your disk, followed by a trailing slash:",
			'installation:dataroot' => "The full path to the directory where uploaded files will be stored, followed by a trailing slash:",
			'installation:dataroot:warning' => "You must create this directory manually. It should sit in a different directory to your Elgg installation.",
			'installation:sitepermissions' => "The default access permissions:",
			'installation:language' => "The default language for your site:",
			'installation:debug' => "Debug mode provides extra information which can be used to diagnose faults, however it can slow your system down so should only be used if you are having problems:",
			'installation:debug:none' => 'Turn off debug mode (recommended)',
	                'installation:debug:error' => 'Display only critical errors',
	                'installation:debug:warning' => 'Display errors and warnings',
	                'installation:debug:notice' => 'Log all errors, warnings and notices',
	                'installation:usage' => "This option lets Elgg send anonymous usage statistics back to Curverider.",
			'installation:usage:label' => "Send anonymous usage statistics",
			'installation:view' => "Enter the view which will be used as the default for your site or leave this blank for the default view (if in doubt, leave as default):",

			'installation:siteemail' => "Site email address (used when sending system emails)",
	
			'installation:disableapi' => "The RESTful API is a flexible and extensible interface that enables applications to use certain Elgg features remotely.",
			'installation:disableapi:label' => "Enable the RESTful API",
			
			'installation:allow_user_default_access:description' => "If checked, individual users will be allowed to set their own default access level that can over-ride the system default access level.",
			'installation:allow_user_default_access:label' => "Allow user default access",
	
			'installation:simplecache:description' => "The simple cache increases performance by caching static content including some CSS and JavaScript files. Normally you will want this on.",
			'installation:simplecache:label' => "Use simple cache (recommended)",
	
			'installation:viewpathcache:description' => "The view filepath cache decreases the loading times of plugins by caching the location of their views.",
			'installation:viewpathcache:label' => "Use view filepath cache (recommended)",
	
			'upgrading' => 'Upgrading',
			'upgrade:db' => 'Your database was upgraded.',
			'upgrade:core' => 'Your elgg installation was upgraded',
	
		/**
		 * Welcome
		 */
	
			'welcome' => "ยินดีต้อนรับ",
			'welcome:user' => 'ยินดีต้อนรับ %s',
			'welcome_message' => "หน้าติดตั้ง",
	
		/**
		 * Emails
		 */
			'email:settings' => "ตั้งค่าอีเมล",
			'email:address:label' => "อีมเล์ของคุณ",
			
			'email:save:success' => "อีเมลใหม่บันทึก, ต้องทำการตรวจสอบ",
			'email:save:fail' => "อีเมลของคุณไม่สามารถบันทึก.",
	
			'friend:newfriend:subject' => "%s ขอเป็นเพื่อนคุณ!",
			'friend:newfriend:body' => "%s ขอเป็นเพื่อนคุณ!

ดูโปรไฟลิ คลิก:

	%s

ไม่จำเป็นต้องตอบกลับอีเมลนี้",
	
	
	
			'email:resetpassword:subject' => "รีเซ็ตรหัสผ่าน!",
			'email:resetpassword:body' => "สวัสดี %s,
			
รหัสผ่านของคุณได้รับการรีเซ็ตเป็น: %s",
	
	
			'email:resetreq:subject' => "ขอรหัสผ่านใหม่.",
			'email:resetreq:body' => "สวัสดี %s,
			
มีบางคน (จาก IP  %s) ได้ขอรหัสผ่านใหม่

หากคุณร้องขอมาคลิกที่ลิงก์ด้านล่าง หากไม่ใช่โปรดลบอีเมลนี้

%s
",

		/**
		 * user default access
		 */
	
		'default_access:settings' => "ค่าเริ่มต้นการเข้าถึง",
		'default_access:label' => "ค่าเริ่มต้นการเข้าถึง้",
		'user:default_access:success' => "ค่าเริ่มต้นการเข้าถึงบันทึกแล้ว",
		'user:default_access:failure' => "ค่าเริ่มต้นการเข้าถึงไม่สามารถบันทึกได้",
	
		/**
		 * XML-RPC
		 */
			'xmlrpc:noinputdata'	=>	"ข้อมูลสูญหาย",
	
		/**
		 * Comments
		 */
	
			'comments:count' => "%s ความคิดเห็น",
			
			'riveraction:annotation:generic_comment' => '%s ความคิดเห็นใน %s',
	
			'generic_comments:add' => "เพิ่มความคิดเห็น",
			'generic_comments:text' => "ความคิดเห็น",
			'generic_comment:posted' => "ความคิดเห็นของคุณถูกโพสต์เรียบร้อยแล้ว.",
			'generic_comment:deleted' => "ความคิดเห็นของคุณถูกลบเรียบร้อยแล้ว.",
			'generic_comment:blank' => "ขออภัย คุณต้องใส่ความคิดเห็นของคุณก่อนที่จะบันทึก",
			'generic_comment:notfound' => "ขออภัย เราไม่พบรายการที่ระบุ",
			'generic_comment:notdeleted' => "ขออภัย เราไม่สามารถลบความคิดเห็นนี้.",
			'generic_comment:failure' => "เกิดข้อผิดพลาดที่ไม่คาดหมายในการเพิ่มความคิดเห็นของคุณ. โปรดลองอีกครั้ง.",
	
			'generic_comment:email:subject' => 'มีความคิดเห็นใหม่มาถึงคุณ!',
			'generic_comment:email:body' => "มีความคิดเห็นใหม่มาถึงคุณ ใน \"%s\" จาก%s. ไปอ่าน:

			
%s


หากต้องการตอบกลับคลิก:

	%s

กากต้องการดูโปรไฟล์ของ %s, คลิก:

	%s

ไม่จำเป็นต้องตอบกลับอีเมลนี้",
	
		/**
		 * Entities
		 */
			'entity:default:strapline' => 'สร้าง %s โดย %s',
			'entity:default:missingsupport:popup' => 'ไม่สามารถแสดงอย่างถูกต้อง อาจจะเพราะไม่มีการติดตั้งปลั๊กอิน',
	
			'entity:delete:success' => 'Entity %s ถูกลบ',
			'entity:delete:fail' => 'Entity %s ไม่สามารถลบได้',
	
	
		/**
		 * Action gatekeeper
		 */
			'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
			'actiongatekeeper:tokeninvalid' => "We encountered an error (token mismatch). This probably means that the page you were using expired. Please try again.",
			'actiongatekeeper:timeerror' => 'The page you were using has expired. Please refresh and try again.',
			'actiongatekeeper:pluginprevents' => 'A extension has prevented this form from being submitted.',
	
		/**
		 * Word blacklists
		 */
			'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever, และ, หรือ  ',
	      
/**
 * Tag labels
 */

	'tag_names:tags' => 'แท๊ก',

		/**
		 * Languages according to ISO 639-1
		 */
			"aa" => "Afar ",
			"ab" => "Abkhazian ",
			"af" => "Afrikaans ",
			"am" => "Amharic ",
			"ar" => "Arabic ",
			"as" => "Assamese ",
			"ay" => "Aymara ",
			"az" => "Azerbaijani ",
			"ba" => "Bashkir ",
			"be" => "Byelorussian ",
			"bg" => "Bulgarian ",
			"bh" => "Bihari ",
			"bi" => "Bislama ",
			"bn" => "Bengali; Bangla ",
			"bo" => "Tibetan ",
			"br" => "Breton ",
			"ca" => "Catalan ",
			"co" => "Corsican ",
			"cs" => "Czech ",
			"cy" => "Welsh ",
			"da" => "Danish ",
			"de" => "German ",
			"dz" => "Bhutani ",
			"el" => "Greek ",
			"en" => "English ",
			"eo" => "Esperanto ",
			"es" => "Spanish ",
			"et" => "Estonian ",
			"eu" => "Basque ",
			"fa" => "Persian ",
			"fi" => "Finnish ",
			"fj" => "Fiji ",
			"fo" => "Faeroese ",
			"fr" => "French ",
			"fy" => "Frisian ",
			"ga" => "Irish ",
			"gd" => "Scots / Gaelic ",
			"gl" => "Galician ",
			"gn" => "Guarani ",
			"gu" => "Gujarati ",
			"he" => "Hebrew ",
			"ha" => "Hausa ",
			"hi" => "Hindi ",
			"hr" => "Croatian ",
			"hu" => "Hungarian ",
			"hy" => "Armenian ",
			"ia" => "Interlingua ",
			"id" => "Indonesian ",
			"ie" => "Interlingue ",
			"ik" => "Inupiak ",
			//"in" => "Indonesian",
			"is" => "Icelandic ",
			"it" => "Italian ",
			"iu" => "Inuktitut ",
			"iw" => "Hebrew (obsolete) ",
			"ja" => "Japanese ",
			"ji" => "Yiddish (obsolete) ",
			"jw" => "Javanese ",
			"ka" => "Georgian ",
			"kk" => "Kazakh ",
			"kl" => "Greenlandic ",
			"km" => "Cambodian ",
			"kn" => "Kannada ",
			"ko" => "Korean ",
			"ks" => "Kashmiri ",
			"ku" => "Kurdish ",
			"ky" => "Kirghiz ",
			"la" => "Latin ",
			"ln" => "Lingala ",
			"lo" => "Laothian ",
			"lt" => "Lithuanian ",
			"lv" => "Latvian/Lettish ",
			"mg" => "Malagasy ",
			"mi" => "Maori ",
			"mk" => "Macedonian ",
			"ml" => "Malayalam ",
			"mn" => "Mongolian ",
			"mo" => "Moldavian ",
			"mr" => "Marathi ",
			"ms" => "Malay ",
			"mt" => "Maltese ",
			"my" => "Burmese ",
			"na" => "Nauru ",
			"ne" => "Nepali ",
			"nl" => "Dutch ",
			"no" => "Norwegian ",
			"oc" => "Occitan ",
			"om" => "(Afan) Oromo ",
			"or" => "Oriya ",
			"pa" => "Punjabi ",
			"pl" => "Polish ",
			"ps" => "Pashto / Pushto ",
			"pt" => "Portuguese ",
			"qu" => "Quechua ",
			"rm" => "Rhaeto-Romance ",
			"rn" => "Kirundi ",
			"ro" => "Romanian ",
			"ru" => "Russian ",
			"rw" => "Kinyarwanda ",
			"sa" => "Sanskrit ",
			"sd" => "Sindhi ",
			"sg" => "Sangro ",
			"sh" => "Serbo-Croatian ",
			"si" => "Singhalese ",
			"sk" => "Slovak ",
			"sl" => "Slovenian ",
			"sm" => "Samoan ",
			"sn" => "Shona ",
			"so" => "Somali ",
			"sq" => "Albanian ",
			"sr" => "Serbian ",
			"ss" => "Siswati ",
			"st" => "Sesotho ",
			"su" => "Sundanese ",
			"sv" => "Swedish ",
			"sw" => "Swahili ",
			"ta" => "Tamil ",
			"te" => "Tegulu ",
			"tg" => "Tajik ",
			"th" => "Thai ",
			"ti" => "Tigrinya ",
			"tk" => "Turkmen ",
			"tl" => "Tagalog ",
			"tn" => "Setswana ",
			"to" => "Tonga ",
			"tr" => "Turkish ",
			"ts" => "Tsonga ",
			"tt" => "Tatar ",
			"tw" => "Twi ",
			"ug" => "Uigur ",
			"uk" => "Ukrainian ",
			"ur" => "Urdu ",
			"uz" => "Uzbek ",
			"vi" => "Vietnamese ",
			"vo" => "Volapuk ",
			"wo" => "Wolof ",
			"xh" => "Xhosa ",
			//"y" => "Yiddish",
			"yi" => "Yiddish ",
			"yo" => "Yoruba ",
			"za" => "Zuang ",
			"zh" => "Chinese ",
			"zu" => "Zulu ",
	);
	
	add_translation("th",$thai);