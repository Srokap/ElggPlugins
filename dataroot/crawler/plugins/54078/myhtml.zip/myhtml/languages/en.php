<?php

	$english = array(
	
		/**
		 * My HTML details
		 */
		
	        
	        'myhtml:title' => "My HTML",
	        'myhtml:description' => "Allows to add specific HTML Code"
	        
		
	);
					
	add_translation("en",$english);

?>