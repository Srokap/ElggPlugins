<?php
/**
 * Magic Topbar CSS
 *
 * @package ElggMagicTopbar
*/
?>

/* Magic Topbar Plugin */

.elgg-page-topbar{
	position: fixed;
	width:100%;
}
.elgg-page-header {
	margin-top: 0px;
	padding-top: 24px;
}
