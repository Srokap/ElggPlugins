<?php

$english = array(
	'lmawidget:widget' => 'Live Music Archive',
	'lmawidget:description' => 'Add a Live Music Archive recently uploaded concerts widget to your profile',
);

add_translation("en", $english);

