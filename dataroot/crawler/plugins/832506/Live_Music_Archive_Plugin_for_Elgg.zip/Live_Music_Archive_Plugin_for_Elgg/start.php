<?php
/**
 * Live Music Archive Recently Uploaded Concerts Widget
 *
 * Add the Live Music Archive widgetbox widget to your Profile page.
 */

elgg_register_event_handler('init', 'system', 'live_music_archive_init');       

function live_music_archive_init() {        
    elgg_register_widget_type(
			'lmawidget',
			elgg_echo('lmawidget:widget'),
			elgg_echo('lmawidget:description')
			);
}
 
?>
