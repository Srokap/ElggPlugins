<?php

	$english = array(
	
		'akismet:nowordpresskey' => 'Wordpress key not defined, please configure Akismet in your admin tools',
	
		'akismet:wordpress_key' => 'Wordpress key',
	
		'akismet:spam' => 'Sorry, you message could not be posted as Akismet thinks that it is spam!',
		'akismet:ham' => 'Message passed Akismet spam check',
	);
					
	add_translation("en", $english);

?>