<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Jazz:title' => "Jazz Radio",

	        'myhtml_Jazz:description' => "Jazz Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>