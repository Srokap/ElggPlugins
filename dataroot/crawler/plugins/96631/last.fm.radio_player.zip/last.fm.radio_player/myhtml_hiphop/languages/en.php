<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_hiphop:title' => "Hip Hop Radio",

	        'myhtml_hiphop:description' => "Hib Hop Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>