<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Punk:title' => "Punk Radio",

	        'myhtml_Punk:description' => "Punk Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>