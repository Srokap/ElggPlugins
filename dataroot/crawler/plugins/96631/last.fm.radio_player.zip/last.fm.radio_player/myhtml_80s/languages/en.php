<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_80s:title' => "80s Radio",

	        'myhtml_80s:description' => "80s Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>