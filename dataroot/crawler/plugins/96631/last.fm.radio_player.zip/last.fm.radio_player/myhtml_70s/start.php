<?php

	/**
	 * Elgg MyHTML Plugin
	 * 
	 * @package MyHtml
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dirk Pelzer aka HiTo81
	 * @copyright Dirk Pelzer 2009
	 * @link http://elgg.org/
	 * 
	 */
	
		function myhtml_70s_init() {
    		
    		
			
    		//add a widget
			    add_widget_type('myhtml_70s',elgg_echo("myhtml_70s:title"),elgg_echo("myhtml_70s:description"));
			
		}
		
		register_elgg_event_handler('init','system','myhtml_70s_init');

?>