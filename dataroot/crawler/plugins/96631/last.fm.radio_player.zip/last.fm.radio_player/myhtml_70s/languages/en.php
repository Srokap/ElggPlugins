<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_70s:title' => "70s Radio",

	        'myhtml_70s:description' => "70s Radio"

	        

		

	);

					

	add_translation("en",$english);



?>