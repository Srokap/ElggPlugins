<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_90s:title' => "90s Radio",

	        'myhtml_90s:description' => "90s Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>