<?php

	$german = array(
	
		/**
		 * My HTML details
		 */
		
	        
	        'myhtml:title' => "Mein HTML",
	        'myhtml:description' => "Erlaubt das Posten von HTML Code."
	        
		
	);
					
	add_translation("de",$german);

?>