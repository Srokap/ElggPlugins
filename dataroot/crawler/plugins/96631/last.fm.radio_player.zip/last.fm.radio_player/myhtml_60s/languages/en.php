<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_60s:title' => "60s Radio",

	        'myhtml_60s:description' => "60s Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>