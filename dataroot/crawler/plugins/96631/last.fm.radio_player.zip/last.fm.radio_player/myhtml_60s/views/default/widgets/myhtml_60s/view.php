<?php

    

	/**

	 * Elgg MyHTML Plugin

	 * 

	 * @package MyHtml

	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2

	 * @author Dirk Pelzer aka HiTo81

	 * @copyright Dirk Pelzer 2009

	 * @link http://elgg.org/

	 * 

	 */

	 



?>

<div class="contentWrapper user_settings">

  <p><?php echo $vars['entity']->myhtml_60s; ?></p>



  <p>
<center><style type="text/css">table.lfmWidgetradio_0fa074fafb95a3d8bf660777c6dcae80 td {margin:0 !important;padding:0 !important;border:0 !important;}table.lfmWidgetradio_0fa074fafb95a3d8bf660777c6dcae80 tr.lfmHead a:hover {background:url(http://cdn.last.fm/widgets/images/en/header/radio/regular_black.png) no-repeat 0 0 !important;}table.lfmWidgetradio_0fa074fafb95a3d8bf660777c6dcae80 tr.lfmEmbed object {float:left;}table.lfmWidgetradio_0fa074fafb95a3d8bf660777c6dcae80 tr.lfmFoot td.lfmConfig a:hover {background:url(http://cdn.last.fm/widgets/images/en/footer/black_np.png) no-repeat 0px 0 !important;;}table.lfmWidgetradio_0fa074fafb95a3d8bf660777c6dcae80 tr.lfmFoot td.lfmView a:hover {background:url(http://cdn.last.fm/widgets/images/en/footer/black_np.png) no-repeat -85px 0 !important;}table.lfmWidgetradio_0fa074fafb95a3d8bf660777c6dcae80 tr.lfmFoot td.lfmPopup a:hover {background:url(http://cdn.last.fm/widgets/images/en/footer/black_np.png) no-repeat -159px 0 !important;}</style>
<table class="lfmWidgetradio_0fa074fafb95a3d8bf660777c6dcae80" cellpadding="0" cellspacing="0" border="0" style="width:184px;"><tr class="lfmHead"><td><a title="60s Tag Radio" href="http://www.last.fm/listen/globaltags/60s" target="_blank" style="display:block;overflow:hidden;height:20px;width:184px;background:url(http://cdn.last.fm/widgets/images/en/header/radio/regular_black.png) no-repeat 0 -20px;text-decoration:none;border:0;"></a></td></tr><tr class="lfmEmbed"><td><object type="application/x-shockwave-flash" data="http://cdn.last.fm/widgets/radio/22.swf" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" id="lfmEmbed_201581921" width="184" height="140"> <param name="movie" value="http://cdn.last.fm/widgets/radio/22.swf" /> <param name="flashvars" value="lfmMode=radio&amp;radioURL=globaltags%2F60s&amp;title=60s+Tag+Radio&amp;theme=black&amp;lang=en&amp;widget_id=radio_0fa074fafb95a3d8bf660777c6dcae80" /> <param name="allowScriptAccess" value="always" /> <param name="allowNetworking" value="all" /> <param name="allowFullScreen" value="true" /> <param name="quality" value="high" /> <param name="bgcolor" value="000000" /> <param name="wmode" value="transparent" /> <param name="menu" value="true" /> </object></td></tr><tr class="lfmFoot"><td style="background:url(http://cdn.last.fm/widgets/images/footer_bg/black.png) repeat-x 0 0;text-align:right;"><table cellspacing="0" cellpadding="0" border="0" style="width:184px;"><tr><td class="lfmConfig"><a href="http://www.last.fm/widgets/?url=globaltags%2F60s&amp;colour=black&amp;size=regular&amp;autostart=0&amp;from=code&amp;widget=radio" title="Get your own widget" target="_blank" style="display:block;overflow:hidden;width:85px;height:20px;float:right;background:url(http://cdn.last.fm/widgets/images/en/footer/black_np.png) no-repeat 0px -20px;text-decoration:none;border:0;"></a></td><td class="lfmView" style="width:74px;"><a href="http://www.last.fm/" title="Visit Last.fm" target="_blank" style="display:block;overflow:hidden;width:74px;height:20px;background:url(http://cdn.last.fm/widgets/images/en/footer/black_np.png) no-repeat -85px -20px;text-decoration:none;border:0;"></a></td><td class="lfmPopup"style="width:25px;"><a href="http://www.last.fm/widgets/popup/?url=globaltags%2F60s&amp;colour=black&amp;size=regular&amp;autostart=0&amp;from=code&amp;widget=radio&amp;resize=1" title="Load this radio in a pop up" target="_blank" style="display:block;overflow:hidden;width:25px;height:20px;background:url(http://cdn.last.fm/widgets/images/en/footer/black_np.png) no-repeat -159px -20px;text-decoration:none;border:0;" onclick="window.open(this.href + '&amp;resize=0','lfm_popup','height=240,width=234,resizable=yes,scrollbars=yes'); return false;"></a></td></tr></table></td></tr></table></center>
  </p>
