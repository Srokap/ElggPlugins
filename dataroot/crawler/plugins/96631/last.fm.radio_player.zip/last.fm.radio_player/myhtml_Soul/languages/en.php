<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Soul:title' => "Soul Radio",

	        'myhtml_Soul:description' => "Soul Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>