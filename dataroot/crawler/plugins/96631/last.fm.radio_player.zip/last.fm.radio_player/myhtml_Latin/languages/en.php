<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Latin:title' => "Latin Radio",

	        'myhtml_Latin:description' => "Latin Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>