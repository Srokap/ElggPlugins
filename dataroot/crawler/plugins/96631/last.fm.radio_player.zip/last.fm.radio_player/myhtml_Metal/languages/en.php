<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Metal:title' => "Metal Radio",

	        'myhtml_Metal:description' => "Metal Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>