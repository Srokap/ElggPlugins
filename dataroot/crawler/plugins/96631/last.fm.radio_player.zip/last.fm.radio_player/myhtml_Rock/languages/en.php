<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Rock:title' => "Rock Radio",

	        'myhtml_Rock:description' => "Rock Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>