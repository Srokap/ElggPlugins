<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Blues:title' => "Blues Radio",

	        'myhtml_Blues:description' => "Blues Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>