<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Hardcore:title' => "Hardcore Radio",

	        'myhtml_Hardcore:description' => "Hardcore Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>