<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Electronic:title' => "Electronic Radio",

	        'myhtml_Electronic:description' => "Electronic Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>