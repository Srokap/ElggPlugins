<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Classical:title' => "Classical Radio",

	        'myhtml_Classical:description' => "Classical Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>