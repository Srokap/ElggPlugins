<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Reggae:title' => "Reggae Radio",

	        'myhtml_Reggae:description' => "Reggae Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>