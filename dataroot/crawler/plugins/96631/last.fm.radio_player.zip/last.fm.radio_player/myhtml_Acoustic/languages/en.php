<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Acoustic:title' => "Acoustic Radio",

	        'myhtml_Acoustic:description' => "Acoustic Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>