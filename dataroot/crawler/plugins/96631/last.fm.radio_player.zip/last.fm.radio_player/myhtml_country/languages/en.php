<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_country:title' => "Country Radio",

	        'myhtml_country:description' => "Country Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>