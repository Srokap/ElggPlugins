<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Indie:title' => "Indie Radio",

	        'myhtml_Indie:description' => "Indie Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>