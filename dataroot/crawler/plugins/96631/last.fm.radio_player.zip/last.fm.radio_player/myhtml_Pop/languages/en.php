<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Pop:title' => "Pop Radio",

	        'myhtml_Pop:description' => "Pop Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>