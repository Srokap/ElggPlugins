<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Folk:title' => "Folk Radio",

	        'myhtml_Folk:description' => "Folk Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>