<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Rnb:title' => "Rnb Radio",

	        'myhtml_Rnb:description' => "Rnb Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>