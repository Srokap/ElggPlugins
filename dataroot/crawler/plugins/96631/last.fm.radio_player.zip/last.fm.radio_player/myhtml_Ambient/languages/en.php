<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_Ambient:title' => "Ambient Radio",

	        'myhtml_Ambient:description' => "Ambient Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>