<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_poppunk:title' => "Pop punk Radio",

	        'myhtml_poppunk:description' => "Pop punk Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>