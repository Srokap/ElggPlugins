<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_emo:title' => "Emo Radio",

	        'myhtml_emo:description' => "Emo Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>