<?php



	$english = array(

	

		/**

		 * My HTML details

		 */

		

	        

	        'myhtml_World:title' => "World Radio",

	        'myhtml_World:description' => "World Radio WIDGET"

	        

		

	);

					

	add_translation("en",$english);



?>