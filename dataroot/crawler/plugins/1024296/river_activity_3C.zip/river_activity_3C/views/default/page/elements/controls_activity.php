<?php
        /*
	 * 3 Column River Acitivity
	 *
	 * @package ElggRiverDash
	 * Full Creadit goes to ELGG Core Team for creating a beautiful social networking script
	 *
         * Modified by Satheesh PM, BARC, Mumbai, India..
         * http://satheesh.anushaktinagar.net
         *
	 * @author ColdTrick IT Solutions
	 * @copyright Coldtrick IT Solutions 2009
	 * @link http://www.coldtrick.com/
	 * @version 1.0
         *
         */

?>
    <script type="text/javascript">
    	$(document).ready(function(){ $('#site_messages_activity').jshowoff({

        changeSpeed:800,        //Speed of transition in milliseconds.
        speed:5000,             //Time each slide is shown in milliseconds.
        //animatePause:true,    //Whether to use 'Pause' animation text when pausing.
        //autoPlay:true,        //Whether to start playing immediately.
        controls:false,         //Whether to create & display controls (Play/Pause, Previous, Next).
        links:false             //Whether to create & display numeric links to each slide.
        //hoverPause:true,      //Whether to pause on hover.
        //effect:'fade',        //Type of transition effect: 'fade', 'slideLeft' or 'none'.
        //controlText:{ play:'Play', pause:'Pause', previous:'Previous', next:'Next' } 	//Text to use for controls (Play/Pause, Previous, Next).

        }); });
    </script>
