<?php
if (0): ?><style><?php endif; ?>
<?php readfile(dirname(dirname(dirname(dirname(__DIR__)))) . '/lib/jquery.oembed.min.css'); ?>
