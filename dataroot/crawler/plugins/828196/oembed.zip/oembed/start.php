<?php
/**
 * Note: previously I'd based embedding on the classname, but that required enabling classes
 * to be set on A elements in both htmlawed and tinyMCE. Considering Elgg's built-in tinyMCE
 * config doesn't even expose class, using the title attribute seemed easier for users and requires
 * less hacking.
 */

elgg_register_event_handler('init', 'system', 'oembed_init');

function oembed_init() {
    elgg_extend_view('js/elgg',  'oembed/js/elgg_after' , 501);
    elgg_extend_view('css/elgg', 'oembed/css/elgg_after', 501);

    // alter the output of views
    //elgg_register_plugin_hook_handler('view', 'js/tinymce', 'oembed_alter_views');

    // allow the damn class attribute
    //elgg_register_plugin_hook_handler('config', 'htmlawed', 'oembed_htmlawed_config_hook');
}

/*
function oembed_alter_views($hook, $type, $returnValue, $params) {
    if ($params['viewtype'] !== 'default') {
        return $returnValue;
    }
    switch ($type) { // $type is view name
        case 'js/tinymce':
            // allow the "class" attribute client-side
            $returnValue = str_replace(
                'extended_valid_elements : "a[name',
                'extended_valid_elements : "a[class|name',
                $returnValue
            );
            return $returnValue;
    }
    return $returnValue;
}

function oembed_htmlawed_config_hook($hook, $type, $returnValue, $params) {
    // allow the "class" attribute server-side
*/
    //$pieces = preg_split('/\\s*,\\s*/', $returnValue['deny_attribute'], PREG_SPLIT_NO_EMPTY);
/*
    $classIndex = array_search('class', $pieces);
    if ($classIndex !== false) {
        unset($pieces[$classIndex]);
    }
    $returnValue['deny_attribute'] = implode(', ', $pieces);
    return $returnValue;
}
*/