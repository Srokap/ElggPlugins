	<div style=" width: 315px;">
    
    <?php echo elgg_echo("music-mixpod-description"); ?>
    <br><br>
     <?php echo elgg_echo("music-mixpod-code"); ?>
    <input type="text" name="params[playlist]" value="<?php echo htmlentities($vars['entity']->playlist); ?>" /><br><br>
    
     <?php echo elgg_echo("music-mixpod-example"); ?> <b>82335312</b>
		
            
   </div>