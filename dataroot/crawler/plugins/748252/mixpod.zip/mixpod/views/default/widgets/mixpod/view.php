<?php
	 $Playlist = $vars['entity']->playlist;
	 $swf= 'mixpod.swf';
	 $width = '315';
	 $height = '311';

	 // if the mixpod id is empty, then do not show player
    if($Playlist){	 
print
	 "<style type=\"text/css\">
      #images img { 
          border:none;
      }
	  .clear {
		  clear:both;
	  }
</style>

<div style=\"margin: -10px -10px -15px -10px;\">
<center>
<object type=\"application/x-shockwave-flash\" data=\"http://assets.myflashfetish.com/swf/mp3/$swf\" height=\"$height\" width=\"$width\" style=\"width:$widthpx;height:$height px\">
<param name=\"movie\" value=\"http://assets.myflashfetish.com/swf/mp3/$swf\" />
<param name=\"quality\" value=\"high\" />
<param name=\"scale\" value=\"noscale\" />
<param name=\"bgcolor\" value=\"5b9cd4\" />
<param name=\"salign\" value=\"TL\" />
<param name=\"salign\" value=\"TL\" />
<param name=\"wmode\" value=\"transparent\"/>
<param name=\"flashvars\" value=\"myid=$Playlist\"/></object>
</center></div>"; ?>






<?php 

    }else{
        
        echo "Click edit to embed your <a href=\"http://www.mixpod.com\" target=\"_blank\">mixpod.com</a> playlist";
        
    }
?>