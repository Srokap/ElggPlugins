<?php
  function mixpod_init() {        
    add_widget_type('mixpod', 'mixpod', 'Mixpod.com');
  }
 
  register_elgg_event_handler('init','system','mixpod_init');       
?>