<?php

$spanish = array(

	'music-mixpod-description' => "
	Aqu&iacute; puedes a&ntilde;adir tus listas de m&uacute;sica de Mixpod.com, a tu perfil siguiendo los siguientes pasos. <br><br>
	<b>1.</b> Accede a Mixpod.com y create o busca tu lista de m&uacute;sica favorita. <br><br>
	<b>2.</b> Busca en el c&oacute;digo EMBED o INCRUSTADO, myid=<b>XXXXX</b>, copia el c&oacute;digo de n&uacute;meros que aparece en el cuadro de abajo. <br><br>
	<b>3.</b> Una vez copiado, guardar y clica en mi perfil o actualiza la p&aacute;gina para que carque el contenido. <br><br>
	
	Si necesitas ayuda, contacta con nosotros a trav&eacute;s de soporte@oranyero.com",
	
	'music-mixpod-code' => "C&oacute;digo aqu&iacute;:",
	
	'music-mixpod-example' => "C&oacute;deigo de ejemplo:",

);
		
add_translation("es", $spanish);