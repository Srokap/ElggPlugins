<?php

$english = array(

	'music-mixpod-description' => "
	Here you can add your music list Mixpod.com a your profile by following these steps. <br><br>
<b>1.</b> Mixpod.com access and create a List or Find your favorite music. <br><br>
<b>2.</b> Search the EMBED code, myid=<b>XXXXX</b>, copy the code numbers listed in table below. <br><br>
<b>3.</b> Once copied, saved and click on my profile page or paragraph carque updating the content. <br><br>

If you need help, contact us soporte@oranyero.com",

'music-mixpod-code' => "Code here:",

'music-mixpod-example' => "Example code:",


);
		
add_translation("en", $english);