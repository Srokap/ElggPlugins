<?php
if (isloggedin()) forward('pg/dashboard/');
global $CONFIG;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Your own page title</title>

<link rel="stylesheet" type="text/css" href="mod/swtheme/css2/style2.css" />
<link rel="stylesheet" href="mod/swtheme/css2/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />

</head>

<body>
	
<!-- BEGIN YOUR CONTENT -->


<div id="content">

<h1>My Portfolio<br />

</h1>

<div id="slider">
	
<ul>
<li>
<div class="inner">		
<h2>Registrate</h2>
<div class="left">
<?php
								$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
								$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
								$form_body .= "<p><a href=\"". $vars['url'] ."account/register.php\">" . elgg_echo('register') . "</a> | <a href=\"". $vars['url'] ."account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></p>";

								echo elgg_view('input/form', array('body' => $form_body, 'action' => "". $vars['url'] ."action/login"));

					  ?>
</div>
<div class="right">
<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
</div>
</div>

</li>

</ul>
</div>

<div class="copyright"><a href="index.php">Home</a> | Copyright 20xx <a href="#sitename">Your Sitename</a> | Original Design by <a href="http://www.milocker.com/sitioempresa">SocialWeb</a></div>


</div>



</body>

</html>
