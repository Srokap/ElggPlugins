<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'canvasmenu:members'  =>  "メンバー" , 
	 'canvasmenu:groups'  =>  "グループ" , 
	 'canvasmenu:current'  =>  "現在、" , 
	 'canvasmenu:andmore'  =>  "もっと見る" , 
	 'canvasmenu:home'  =>  "ホーム" , 
	 'canvasmenu:blogs'  =>  "ブログ" , 
	 'canvasmenu:bookmarks'  =>  "ブックマーク" , 
	 'canvasmenu:discussions'  =>  "グループへの投稿" , 
	 'canvasmenu:events'  =>  "イベント情報" , 
	 'canvasmenu:public'  =>  "を見ることができます." , 
	 'canvasmenu:register'  =>  "すぐに登録," , 
	 'canvasmenu:access'  =>  "詳細はこちら." , 
	 'canvasmenu:photos'  =>  "写真" , 
	 'canvasmenu:videos'  =>  "ビデオ" , 
	 'canvasmenu:ads'  =>  "分類" , 
	 'canvasmenu:wire'  =>  "つぶやき..."
); 

add_translation('ja', $japanese); 

?>