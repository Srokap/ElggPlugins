<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'media:insert'  =>  "組み込み／ファイルのアップロード" , 
	 'embed:instructions'  =>  "あなたの文章に組み込むために、いずれかのファイルをクリックしてください。" , 
	 'embed:media'  =>  "ファイルの組み込み" , 
	 'upload:media'  =>  "ファイルのアップロード" , 
	 'embed:file:required'  =>  "アップロードするファイルが見つかりませんでした。システム管理者が同様のプラグインをアップロードする必要があるかもしれません。"
); 

add_translation('ja', $japanese); 

?>