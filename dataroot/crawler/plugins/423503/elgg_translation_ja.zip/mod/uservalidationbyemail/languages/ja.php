<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'email:validate:subject'  =>  "%s さん、あなたの電子メールアドレスを承認してください。" , 
	 'email:validate:body'  =>  "こんにちは %s さん。

あなたが登録したことを確認するために、以下のリンクをクリックして、自身の電子メールアドレスを承認してください。:

%s


承認後は、ログイン名とパスワードの入力によりログインすることができます。

以上の手続きは、いたずらで第三者により登録作業が行われてしまうことを防止するための措置です。" , 
	 'email:validate:success:subject'  =>  "%s さんの電子メールアドレスが承認されました。" , 
	 'email:validate:success:body'  =>  "こんにちは %s さん,
			
あなたの電子メールアドレスは、無事承認されました。" , 
	 'email:confirm:success'  =>  "あなたの電子メールアドレスが承認されました。" , 
	 'email:confirm:fail'  =>  "何らかの理由で、あなたの電子メールアドレスを確認できませんでした。" , 
	 'uservalidationbyemail:registerok'  =>  "あなたが登録したアカウントを有効にするためには、あなたが登録した電子メールアドレスの承認作業が必要です。承認作業の案内をあなたが登録したメールアドレス宛に送信したので、内容を確認の上、承認作業を完了してください。　あなたのログインをお待ちしています。"
); 

add_translation('ja', $japanese); 

?>