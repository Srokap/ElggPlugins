<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'members:members'  =>  "登録メンバー" , 
	 'members:online'  =>  "現在アクティブなメンバー" , 
	 'members:active'  =>  "登録メンバー" , 
	 'members:searchtag'  =>  "タグでメンバーを検索" , 
	 'members:searchname'  =>  "名前でメンバーを検索" , 
	 'members:label:newest'  =>  "新しいメンバー" , 
	 'members:label:popular'  =>  "注目度の高いメンバー" , 
	 'members:label:active'  =>  "ログイン中のメンバー"
); 

add_translation('ja', $japanese); 

?>