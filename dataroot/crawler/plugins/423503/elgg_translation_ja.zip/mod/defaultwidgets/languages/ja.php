<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'item:object:moddefaultwidgets'  =>  "ウィジェットの設定" , 
	 'defaultwidgets:menu:profile'  =>  "プロフィールのウィジェット設定" , 
	 'defaultwidgets:menu:dashboard'  =>  "ダッシュボードのウィジェット設定" , 
	 'defaultwidgets:update:success'  =>  "あなたのウィジェット設定は保存されました。" , 
	 'defaultwidgets:profile:title'  =>  "プロフィールページに既定のウィジェットを設定" , 
	 'defaultwidgets:dashboard:title'  =>  "ダッシュボードページに既定のウィジェットを設定" , 
	 'defaultwidgets:admin:error'  =>  "エラー：　あなたは管理者としてログインしていません。" , 
	 'defaultwidgets:admin:notfound'  =>  "エラー：　ページが見つかりません。" , 
	 'defaultwidgets:admin:loginfailure'  =>  "警告：　あなたは現在、管理者としてログインしていません。" , 
	 'defaultwidgets:update:failed'  =>  "エラー：　設定は保存されませんでした。" , 
	 'defaultwidgets:update:noparams'  =>  "エラー：　フォーム・パラメーターが間違っています。"
); 

add_translation('ja', $japanese); 

?>