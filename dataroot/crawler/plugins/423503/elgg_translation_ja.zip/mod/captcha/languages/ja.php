<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'captcha:entercaptcha'  =>  "画像に表示されたテキストを入力してください。" , 
	 'captcha:captchafail'  =>  "申し訳ありませんが"
); 

add_translation('ja', $japanese); 

?>