<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'customsearch'  =>  "全文検索" , 
	 'customsearch:search:title'  =>  "%s の検索結果" , 
	 'customsearch:search:found'  =>  "該当件数 : %s" , 
	 'customsearch:search:no_result'  =>  "検索文字列を入力してください。" , 
	 'customsearch:search:too_short'  =>  "検索文字列が短すぎます（ 半角で %s 文字以上入力してください。）"
); 

add_translation('ja', $japanese); 

?>