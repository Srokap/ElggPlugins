<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'blog'  =>  "ブログ" , 
	 'blogs'  =>  "ブログ" , 
	 'blog:user'  =>  "%s のブログ" , 
	 'blog:user:friends'  =>  "%s さんが「関心のある人」のブログ" , 
	 'blog:your'  =>  "あなたのブログ" , 
	 'blog:posttitle'  =>  "%s さんのブログ: %s" , 
	 'blog:friends'  =>  "関心がある人のブログ" , 
	 'blog:yourfriends'  =>  "関心がある人の最新のブログ" , 
	 'blog:everyone'  =>  "サイト内の全ブログ" , 
	 'blog:newpost'  =>  "新しいブログ" , 
	 'blog:via'  =>  "ブログより" , 
	 'blog:read'  =>  "ブログを読む" , 
	 'blog:addpost'  =>  "ブログを投稿する" , 
	 'blog:editpost'  =>  "ブログを編集する" , 
	 'blog:text'  =>  "ブログの本文" , 
	 'blog:strapline'  =>  "%s  " , 
	 'item:object:blog'  =>  "ブログ投稿" , 
	 'blog:never'  =>  "まだ" , 
	 'blog:preview'  =>  "プレビュー" , 
	 'blog:draft:save'  =>  "一時保存" , 
	 'blog:draft:saved'  =>  "最後の一時保存" , 
	 'blog:comments:allow'  =>  "コメントを許可" , 
	 'blog:conversation'  =>  "コメント" , 
	 'blog:preview:description'  =>  "これはまだ保存されていないプレビューです。" , 
	 'blog:preview:description:link'  =>  "再編集はここをクリック" , 
	 'blog:river:created'  =>  "%s 記入済み" , 
	 'blog:river:updated'  =>  "%s 更新済み" , 
	 'blog:river:posted'  =>  "%s 投稿済み" , 
	 'blog:river:create'  =>  "新しい投稿" , 
	 'blog:river:update'  =>  "ブログのタイトル" , 
	 'blog:river:annotate'  =>  "ブログに対するコメント" , 
	 'blog:posted'  =>  "投稿が保存されました。" , 
	 'blog:deleted'  =>  "ブログ投稿を削除しました。" , 
	 'blog:error'  =>  "なにかうまくいかなかったようです。もう一度お願いします。" , 
	 'blog:save:failure'  =>  "あなたの投稿は保存されませんでした。もう一度お願いします。" , 
	 'blog:blank'  =>  "申し訳ありません。投稿のためにはタイトルと本文の両方を入力してください。" , 
	 'blog:notfound'  =>  "申し訳ありません。その投稿を見つけることができません。" , 
	 'blog:notdeleted'  =>  "申し訳ありません。この投稿を削除できません。" , 
	 'blog:enableblog'  =>  "グループ・ブログを許可" , 
	 'blog:group'  =>  "グループ・ブログ"
); 

add_translation('ja', $japanese); 

?>