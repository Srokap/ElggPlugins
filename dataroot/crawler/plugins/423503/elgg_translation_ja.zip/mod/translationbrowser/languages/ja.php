<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'translationbrowser'  =>  "翻訳ブラウザ" , 
	 'translationbrowser:translate'  =>  "翻訳" , 
	 'translationbrowser:exporttranslations'  =>  "翻訳ファイルのエクスポート" , 
	 'translationbrowser:selectlanguage'  =>  "言語を選択" , 
	 'translationbrowser:selecttypeexport'  =>  "エクスポート形式を選択" , 
	 'translationbrowser:languagebase'  =>  "基本言語" , 
	 'translationbrowser:yourselectedlanguage'  =>  "あなたの選択した言語" , 
	 'translationbrowser:youwilltranslate'  =>  "翻訳は" , 
	 'translationbrowser:to'  =>  "から" , 
	 'translationbrowser:languagecore'  =>  "- システム言語" , 
	 'translationbrowser:selectmodule'  =>  "翻訳作業を行いたいモジュールをクリックし、「翻訳」ボタンをクリックしてください。" , 
	 'translationbrowser:updatefile'  =>  "内部ファイルを更新する。" , 
	 'translationbrowser:generatefile'  =>  "phpファイルを生成する。" , 
	 'translationbrowser:highlight'  =>  "未翻訳のフィールドをハイライト" , 
	 'translationbrowser:canyouedit'  =>  "このフィールドの内容を編集できます。" , 
	 'translationbrowser:blankmodule'  =>  "少なくとも一つのモジュールを選択してください。" , 
	 'translationbrowser:languageerror'  =>  "選択した言語は間違っています。もう一度他の言語を選択してみてください。" , 
	 'translationbrowser:blanklang'  =>  "少なくとも一つの言語を選択してください。" , 
	 'translationbrowser:emptyfields'  =>  "少なくとも一つのフィールドを入力してください。" , 
	 'translationbrowser:error'  =>  "内部エラー。　あとでもう一度やってみてください。" , 
	 'translationbrowser:problem:permiss'  =>  "フォルダーへのアクセスに失敗しました。権限を確認してください。" , 
	 'translationbrowser:error:filecreate'  =>  "ファイルの作成に失敗しました。権限を確認してください。" , 
	 'translationbrowser:success'  =>  "翻訳は成功しました。" , 
	 'translationbrowser:generatedby'  =>  "Generate By translationbrowser." , 
	 'translationbrowser:save'  =>  "翻訳" , 
	 'translationbrowser:downloadallinzip'  =>  "すべての翻訳ファイルをzipファイルでダウンロード" , 
	 'translationbrowser:userscanedit'  =>  "ユーザーが編集できます。" , 
	 'translationbrowser:exportdescription'  =>  "翻訳結果をエクスポートしたいなら、言語を選択してエクスポートボタンをクリックしてください。" , 
	 'translationbrowser:export'  =>  "エクスポート" , 
	 'translationbrowser:infotxt'  =>  "This file created by Translation Browser Elgg
@author Mariusz Bulkowski http://seo4you.pl/
@author v2 Pedro Prez http://www.pedroprez.com.ar/
@Japanese　translation  Yoshi Ikeda http://suisankaiyo.com/pf1/
"
); 

add_translation('ja', $japanese); 

?>