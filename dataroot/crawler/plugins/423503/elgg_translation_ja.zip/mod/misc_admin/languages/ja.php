<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'misc_admin:menu'  =>  "その他のユーティリティ" , 
	 'misc_admin:title'  =>  "その他の管理用ユーティリティ" , 
	 'misc_admin:rescue_users:label'  =>  "[+] %sの停滞しているユーザーアカウントを有効化するにはここをクリックしてください。" , 
	 'misc_admin:date:label'  =>  "日付" , 
	 'misc_admin:name:label'  =>  "表示名" , 
	 'misc_admin:uname:label'  =>  "ユーザー名" , 
	 'misc_admin:email:label'  =>  "電子メールアドレス" , 
	 'misc_admin:cdate:label'  =>  "登録時期" , 
	 'misc_admin:user:enable'  =>  "有効" , 
	 'misc_admin:user:delete'  =>  "削除" , 
	 'misc_admin:user:enable:none'  =>  "有効化するユーザーが選択されていません。" , 
	 'misc_admin:user:delete:none'  =>  "削除するユーザーが選択されていません。" , 
	 'misc_admin:user:enable:success'  =>  "選択したユーサーが有効になりました。" , 
	 'misc_admin:user:delete:success'  =>  "選択したユーザーの削除が成功しました。" , 
	 'misc_admin:user:signup_stats:label'  =>  "[+] ユーザーの登録傾向を見るにはここをクリックしてください。" , 
	 'misc_admin:user:last_login_stats:label'  =>  "[+] ユーザーの最終ログインの傾向を見るにはここをクリックしてください。" , 
	 'misc_admin:nusers:label'  =>  "ユーザー数"
); 

add_translation('ja', $japanese); 

?>