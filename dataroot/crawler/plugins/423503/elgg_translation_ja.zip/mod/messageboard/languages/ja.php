<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'messageboard:board'  =>  "メッセージボード" , 
	 'messageboard:messageboard'  =>  "メッセージボード" , 
	 'messageboard:viewall'  =>  "全部見る" , 
	 'messageboard:postit'  =>  "投稿する" , 
	 'messageboard:history'  =>  "履歴" , 
	 'messageboard:none'  =>  "このメッセージボードにはまだなにもありません。" , 
	 'messageboard:num_display'  =>  "表示するメッセージ数" , 
	 'messageboard:desc'  =>  "このメッセージボードは、他のユーザーがコメントできるあなたのプロフィールに設置することが出来ます。" , 
	 'messageboard:user'  =>  "%s のメッセージボード" , 
	 'messageboard:replyon'  =>  "返信する。" , 
	 'messageboard:river:annotate'  =>  "%s はメッセージボードに新しいコメントをしました。" , 
	 'messageboard:river:create'  =>  "%s がメッセージボードウィジェットを追加しました。" , 
	 'messageboard:river:update'  =>  "%s がメッセージボードウィジェットを更新しました。" , 
	 'messageboard:river:added'  =>  "%s が投稿されました。" , 
	 'messageboard:river:messageboard'  =>  "メッセージボード" , 
	 'messageboard:posted'  =>  "メッセージボードへの投稿に成功しました。" , 
	 'messageboard:deleted'  =>  "あなたはメッセージの削除に成功しました。" , 
	 'messageboard:email:subject'  =>  "あなたのメッセージボードにコメントがあります。" , 
	 'messageboard:email:body'  =>  "あなたのメッセージボードに %s さんから新しいコメントが追加されました。新しいコメントは以下の通り：


%s


メッセージボードのコメントを見るには、次のリンクをクリックしてください。：


%s


%s さんのプロフィールを見るには、次のリンクをクリックしてください。


%s


なお、このメールあてに返信はできません。" , 
	 'messageboard:blank'  =>  "申し訳ありません。　保存する前にメッセージ記入欄に何か書き込んでください。" , 
	 'messageboard:notfound'  =>  "申し訳ありません。　指定のアイテムを見つけられませんでした。" , 
	 'messageboard:notdeleted'  =>  "申し訳ありません。　このメッセージを削除できませんでした。" , 
	 'messageboard:somethingwentwrong'  =>  "あなたのメッセージを保存しようとしたときにうまく動作しませんでした。メッセージを書いたか確認してください。" , 
	 'messageboard:failure'  =>  "あなたのメッセージを追加するときに、予期せぬエラーが発生しました。もう一度やってみてください。"
); 

add_translation('ja', $japanese); 

?>