<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'expages'  =>  "特別ページ" , 
	 'expages:frontpage'  =>  "フロントページ" , 
	 'expages:about'  =>  "アバウト" , 
	 'expages:terms'  =>  "規約" , 
	 'expages:privacy'  =>  "プライバシー" , 
	 'expages:analytics'  =>  "解析" , 
	 'expages:contact'  =>  "コンタクト" , 
	 'expages:nopreview'  =>  "プレビューはまだ利用できません。" , 
	 'expages:preview'  =>  "プレビュー" , 
	 'expages:notset'  =>  "このページはまだセットアップされていません" , 
	 'expages:lefthand'  =>  "左側の情報領域" , 
	 'expages:righthand'  =>  "右側の情報領域" , 
	 'expages:addcontent'  =>  "あなたは管理ツール経由でコンテンツを追加できます。管理者メニューから「特別ページ」を探してください。" , 
	 'item:object:front'  =>  "フロントページ・アイテム" , 
	 'expages:posted'  =>  "ページの更新に成功しました。" , 
	 'expages:deleted'  =>  "ページの削除に成功しました。" , 
	 'expages:deleteerror'  =>  "古いページの削除で問題が発生しました。" , 
	 'expages:error'  =>  "なにか問題が発生したようです。もう一度試行してもだめなら、管理者に連絡してみてください。"
); 

add_translation('ja', $japanese); 

?>