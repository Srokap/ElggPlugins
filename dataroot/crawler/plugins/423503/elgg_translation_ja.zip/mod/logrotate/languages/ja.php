<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'logrotate:period'  =>  "システムログのアーカイブ頻度は？" , 
	 'logrotate:weekly'  =>  "週に一回" , 
	 'logrotate:monthly'  =>  "月に一回" , 
	 'logrotate:yearly'  =>  "年に一回" , 
	 'logrotate:logrotated'  =>  "ログローテートしました。" , 
	 'logrotate:lognotrotated'  =>  "ログローテート失敗"
); 

add_translation('ja', $japanese); 

?>