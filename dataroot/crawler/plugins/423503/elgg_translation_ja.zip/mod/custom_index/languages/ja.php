<?php

	$japanese = array(
	
			'custom:bookmarks' => "最新のブックマーク",
			'custom:groups' => "新しいグループ",
			'custom:files' => "新しいファイル",
			'custom:blogs' => "最近のブログ投稿",
			'custom:members' => "新しいメンバー",
			'custom:nofiles' => "まだファイルがありません",
			'custom:nogroups' => "まだファイルがありません",	
	
	);
					
	add_translation("ja",$japanese);

?>