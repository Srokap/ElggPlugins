<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'diagnostics'  =>  "システム診断" , 
	 'diagnostics:unittester'  =>  "ユニット・テスト" , 
	 'diagnostics:description'  =>  "以下の診断レポートはElgg内の諸問題の診断に役立ちます。そしてバグレポートに添付されるべきです。" , 
	 'diagnostics:unittester:description'  =>  "登録されたプラグインの診断結果" , 
	 'diagnostics:test:executetest'  =>  "テストを実行" , 
	 'diagnostics:test:executeall'  =>  "すべてを実行" , 
	 'diagnostics:unittester:notests'  =>  "申し訳ありません。ユニットテストのモジュールは現在インストールされていません。" , 
	 'diagnostics:unittester:testnotfound'  =>  "申し訳ありません。テスト結果が見あたらないためレポートを生成できません。" , 
	 'diagnostics:unittester:testresult:nottestclass'  =>  "失敗 - Result not a test class" , 
	 'diagnostics:unittester:testresult:fail'  =>  "失敗" , 
	 'diagnostics:unittester:testresult:success'  =>  "成功" , 
	 'diagnostics:unittest:example'  =>  "ユニットテスト例は、デバッグモードでのみ有効です。" , 
	 'diagnostics:unittester:report'  =>  "%s のテストレポート" , 
	 'diagnostics:download'  =>  "Download .txt" , 
); 

add_translation('ja', $japanese); 

?>