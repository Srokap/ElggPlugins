<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'mine'  =>  "私" , 
	 'filter'  =>  "フィルター" , 
	 'riverdashboard:useasdashboard'  =>  "アクティビティリバーで、規定のダッシュボードを置き換える。" , 
	 'activity'  =>  "アクティビティ" , 
	 'sitemessages:announcements'  =>  "サイトからのお知らせ" , 
	 'sitemessages:posted'  =>  "投稿" , 
	 'sitemessages:river:created'  =>  "サイト管理者, %s " , 
	 'sitemessages:river:create'  =>  "サイト全体へのメッセージを投稿しました。" , 
	 'sitemessages:add'  =>  "あたらしいサイト全体へのメッセージを投稿しました。" , 
	 'sitemessage:deleted'  =>  "際とメッセージを削除しました。" , 
	 'river:widget:noactivity'  =>  "アクティビティが見つかりません。" , 
	 'river:widget:title'  =>  "アクティビティ" , 
	 'river:widget:description'  =>  "あなたの最後のアクティビティを知らせてください。" , 
	 'river:widget:title:friends'  =>  "関係者のアクティビティ" , 
	 'river:widget:description:friends'  =>  "「関心がある人」がどうしているか示す。" , 
	 'river:widgets:friends'  =>  "関係者" , 
	 'river:widgets:mine'  =>  "私の" , 
	 'river:widget:label:displaynum'  =>  "表示するエントリーの数" , 
	 'river:widget:type'  =>  "どちらを表示しますか。あなたのアクティビティか、関心がある人のアクティビティを表示できます。" , 
	 'item:object:sitemessage'  =>  "サイト・メッセージ" , 
	 'riverdashboard:recentmembers'  =>  "最近のメンバー"
); 

add_translation('ja', $japanese); 

?>