<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'friends:all'  =>  "全ての「関心がある人」" , 
	 'notifications:subscriptions:personal:description'  =>  "あなたのコンテンツが更新されたとき（コメントなど）、お知らせを受信する。" , 
	 'notifications:subscriptions:personal:title'  =>  "あなたに関する更新通知" , 
	 'notifications:subscriptions:collections:title'  =>  "「関心がある人」リスト" , 
	 'notifications:subscriptions:changesettings'  =>  "更新通知設定" , 
	 'notifications:subscriptions:changesettings:groups'  =>  "グループの更新通知設定" , 
	 'notification:method:email'  =>  "電子メール" , 
	 'notifications:subscriptions:title'  =>  "「関心がある人」に関する更新通知" , 
	 'notifications:subscriptions:success'  =>  "あなたの「通知」設定は保存されました。" , 
	 'notifications:subscriptions:collections:edit'  =>  "「関心がある人」を整理する。" , 
	 'notifications:subscriptions:description'  =>  "「関心がある人」のコンテンツが更新された時、通知を受信することができます。更新を受信したいときは以下のリストから「関心がある人」を選択してチェックを入れてください。（日本語のユーザー名は、＊をクリックすると表示されます）" , 
	 'notifications:subscriptions:groups:description'  =>  "あなたが参加するグループのコンテンツが更新されたとき、通知を受信することができます。更新を受信したいときは以下のリストから更新を受信するグループを選択してチェックを入れてください。" , 
	 'notifications:subscriptions:collections:description'  =>  "「関心がある人」リストを活用して通知設定ができます。リストの作成には次のリンクをクリックしてください。"
); 

add_translation('ja', $japanese); 

?>