<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'bookmarks'  =>  "ブックマーク" , 
	 'bookmarks:add'  =>  "ブックマークする" , 
	 'bookmarks:read'  =>  "ブックマークアイテム" , 
	 'bookmarks:friends'  =>  "関係者のブックマーク" , 
	 'bookmarks:everyone'  =>  "サイト内の全ブックマーク" , 
	 'bookmarks:this'  =>  "これをブックマーク" , 
	 'bookmarks:bookmarklet'  =>  "ブックマークレットをゲット" , 
	 'bookmarks:inbox'  =>  "ブックマーク" , 
	 'bookmarks:more'  =>  "もっと見る" , 
	 'bookmarks:shareditem'  =>  "ブックマーク済みのアイテム" , 
	 'bookmarks:with'  =>  "共有：" , 
	 'bookmarks:new'  =>  "新しいブックマーク・アイテム" , 
	 'bookmarks:via'  =>  "ブックマーク経由" , 
	 'bookmarks:address'  =>  "ブックマークするアドレスのリソース" , 
	 'bookmarks:delete:confirm'  =>  "このリソースを削除していいですか？" , 
	 'bookmarks:numbertodisplay'  =>  "表示するブックマークの数" , 
	 'bookmarks:shared'  =>  "ブックマーク済み" , 
	 'bookmarks:visit'  =>  "リンクを見る" , 
	 'bookmarks:recent'  =>  "最近のブックマーク" , 
	 'bookmarks:river:created'  =>  "%s ブックマーク済み" , 
	 'bookmarks:river:annotate'  =>  "%s コメント有り" , 
	 'bookmarks:river:item'  =>  "アイテム" , 
	 'item:object:bookmarks'  =>  "ブックマーク済みアイテム" , 
	 'bookmarks:widget:description'  =>  "このウィジェットはダッシュボードのために設計され、ブックマーク・受信トレイに、最新のアイテムが表示されます。" , 
	 'bookmarks:bookmarklet:description'  =>  "ブックマークのブックマークレットあなたの友人、または単に自分がブックマークをウェブ上で検索すると任意のリソースを共有することができます。それを使用するには、ブラウザのリンクバーには、次のボタンをドラッグします：" , 
	 'bookmarks:bookmarklet:descriptionie'  =>  "Internet Explorerを使用している場合は、ブックマークレットのアイコンを右クリックし、 [お気に入り]をクリックし、リンクバーに追加]を選択する必要があります" , 
	 'bookmarks:bookmarklet:description:conclusion'  =>  "いつでも任意のページをクリックして保存すると、アクセスすることができます。" , 
	 'bookmarks:save:success'  =>  "あなたのアイテムはブックマークされました。" , 
	 'bookmarks:delete:success'  =>  "あなたブックマークアイテムは削除されました。" , 
	 'bookmarks:save:failed'  =>  "あなたのブックマークアイテムは保存できませんでした。再度行ってみてください。" , 
	 'bookmarks:delete:failed'  =>  "あなたのブックマークアイテムは削除できませんでした。もう一度実行してみてください。" , 
	 'bookmarks:this:group'  =>  "%s のブックマーク" , 
	 'bookmarks:bookmarklet:group'  =>  "グループ用のブックマークレットをゲット" , 
	 'bookmarks:group'  =>  "グループ・ブックマーク" , 
	 'bookmarks:enablebookmarks'  =>  "グループ・ブックマークを許可"
); 

add_translation('ja', $japanese); 

?>