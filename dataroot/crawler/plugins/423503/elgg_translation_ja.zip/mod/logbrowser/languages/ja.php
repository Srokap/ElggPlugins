<?php

// Generate By translationbrowser. 

$japanese = array( 
	 'logbrowser'  =>  "ログ・ブラウザ" , 
	 'logbrowser:browse'  =>  "システムログを閲覧" , 
	 'logbrowser:search'  =>  "結果を抽出" , 
	 'logbrowser:user'  =>  "ユーザーネームで抽出" , 
	 'logbrowser:starttime'  =>  "開始時期（例えば　\"last monday\", \"1 hour ago\"）" , 
	 'logbrowser:endtime'  =>  "終了時期" , 
	 'logbrowser:explore'  =>  "ログを調査"
); 

add_translation('ja', $japanese); 

?>