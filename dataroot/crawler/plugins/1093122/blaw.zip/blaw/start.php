<?php
		function blaw_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('blaw'), $CONFIG->wwwroot . "mod/blaw");
		}
		
	register_elgg_event_handler('init','system','blaw_init');
	// Shares widget

?>