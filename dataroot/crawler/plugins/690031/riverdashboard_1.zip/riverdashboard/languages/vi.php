<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard Language Files
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author lieu<nguyenlieu1987@gmail.com>
 * @copyright mangxahoi.org
 * @link http://www.mangxahoi.org
 *
 ******************************************************************************/
?>
<?php

	$vietnamese= array(
		/***  for comments  ***/
		'river:item:toggle_comments' => 'Bình luận',
		/***  end comments  ***/
		/*
		 *Fusion Mod
		 */
		 'river:viewall' => 'Xem tất cả',
		 'river:groups:mygroup' => 'Những nhóm của tôi',
		 'river:share' => 'Chia sẻ',
		 'river:recent' => 'Những thảo luận gần đây',
		 'riverdashboard:randommembers' => 'Thành viên ngẫu nhiên',
		 'river:next' => 'Tiếp theo &gt;&gt;',
         'river:previous' => '&lt;&lt; Trở lại',
		 'river:mini:welcome' => 'Chào mừng',
		 'recent:visitors' => 'Khách viếng thăm gần đây',
		 'thewire:latest' => 'Tin mới nhất',
		 /*
		  *Activity_view
		  */
		 'river:activity:add' => 'Chia sẻ:',
		 'river:activity:post' => 'Đăng',
		 'river:newpost' => 'Bạn đang nghĩ gì ?',
		 'river:created' => 'Nói:',
		 /** Tips **/
		 'river:tips:title' => 'Trợ giúp',
		 /*
		  *Share a link
		  */
		 'river:bookmarks:river:created' => '%s shared a link',
		 'river:bookmark:title' => 'Tiêu đề',
		 'river:bookmarks:address' => 'Địa chỉ liên kết.. http://somesite.com',
		 'river:bookmark:description' => 'Liên kết',
		 'river:bookmark:tags' => 'Enter relevant search tags',
		 'river:bookmark:share' => 'Chia sẻ',
		 'river:bookmarks' => 'Bookmarks',
		 'river:save:success' => 'Bạn đã chia sẻ thành công một liên kết trang',
		 'river:save:failed' => 'Liên kết trang chưa được lưu thành công..  Vui lòng thử lại lần nữa.',
		 /*
		  * videos
		  */
		 'river:video:upload' => 'Tải lên một đoạn Video',
		 'river:video:videos' => 'Videos',
		 'river:video:add' => 'Thêm một đoạn Video',
	     'river:video:supported' => 'Hỗ trợ từ sites',
   	     'river:video:harddrive' => 'Từ ổ đĩa của bạn',
		 'river:latestvideos' => '<b>Latest</b>',
		 'river:topViewed' => '<b>Top Views</b>',
		 'river:topCommented' => '<b>Top Comments</b>',
		 /*
	      *photos
	      */
		  'river:photo:latest' => 'Latest Images',
		  'river:photo:photos' => 'Hình ảnh',
		  'river:photo:create' => 'Tạo một Album',
		  'river:photo:many' => 'With many photos', 
		  'river:photo:upload' => 'Tải hình ảnh lên',
		  'river:mostviewed' => 'Most Viewed Photos',
		 /*
		  *polls
		  */
		  'river:poll:create' => 'Create a poll',
		  'river:poll' => 'Recent Site Polls',
		 /*
		  *events
		  */
		  'river:events:new' => 'Những sự kiện mới nhất',
		 /*
		  *gifts
		  */
		  'river:gifts' => "%s gửi a %s đến %s",
		  'river:gift:gifts' => 'Gửi quà',
		 /*
          * Mini Profile
          */
		 'river:stats:currentcount' => "Xem hồ sơ cá nhân: %s",
         'river:mini:hi' => 'Xin chào',
         'river:mini:edit' => 'Chỉnh sửa/Tải lên',
         'river:mini:blog' => 'Quản lý Blog',
         'river:mini:groups' => 'Quản lý Nhóm',
         'river:mini:invite' => 'Mời bạn bè',
         'river:mini:manage' => 'Quản lý tài khoản',
         'river:mini:account' => 'Customize Account',
         'river:mini:custom_profile' => 'Thiết lập hồ sơ cá nhân',
         'river:mini:profile_image' => 'Thay đổi ảnh đại diện',
         'river:mini:edit_account' => 'Chỉnh sửa tài khoản',
         'river:mini:account_settings' => 'Thiết lập tài khoản',
         'river:mini:notifications' => 'Thông báo',
         'river:mini:edit_profile' => 'Chỉnh sửa hồ sơ cá nhân',
		 'river:mini:tools' => 'Cấu hình',

		 /* Settings */
         'riverdashboard:settings:newestmembers' => 'Những thành viên mới nhất?',
		 'riverdashboard:newestmembers:num' => 'Số lượng thành viên?',
         'riverdashboard:settings:featured_groups' => 'Đặc điểm nhóm?',
		 'riverdashboard:groups:num' => 'Số lượng nhóm ?',
         'riverdashboard:settings:mygroups' => 'Những Nhóm của tôi?',
         'riverdashboard:settings:sidebarTagcloud' => 'Show SidebarTagcloud?',
         'riverdashboard:settings:friends' => 'Show Friends?',
		 'riverdashboard:friends:num' => 'Số lượng bạn bè ?',
         'riverdashboard:settings:birthdaymembers' => 'Ngày sinh nhật của thành viên?',
         'riverdashboard:settings:polls' => 'Show Polls?',
		 'riverdashboard:polls:num' => 'Number of polls to show?',
         'riverdashboard:settings:photocumulus' => 'Show Photo Cumulus?',
         'riverdashboard:settings:videos' => 'Hiện Videos?',
		 'riverdashboard:video:num' => 'Number of videos to show?',
         'riverdashboard:settings:recentview' => 'Show Recent Profile Views?',
		 'riverdashboard:recentv:num' => 'Number of recent visitors to show?',
		 'riverdashboard:settings:bookmarks' => 'Show Bookmarks?',
		 'riverdashboard:bookmarks:num' => 'Number of bookmarks to show?',
		 'riverdashboard:settings:events' => 'Show Events?',
		 'riverdashboard:settings:vanilla' => 'Show Recent Vanilla Forum Discussions?',
		 'riverdashboard:settings:topad' => 'Show Top Adverts? Size 468x60',
		 'riverdashboard:settings:leftad' => 'Show Left Adverts Box?',
		 'riverdashboard:settings:rightad' => 'Show Right Adverts Box?',
		 'riverdashboard:settings:adcode' => 'Enter your Advertisement code here',
		 'riverdashboard:settings:photos' => 'Hiện Photos?',
		 'photos:num:display' => 'Số lượng hình ảnh?',
		 'riverdashboard:settings:site' => 'Show Site Messages?',
		 'riverdashboard:settings:tips' => 'Show Helpful Hints?',
		 /* feeds */
		 'riverdashboard:feeds:show' => 'Show a Feed',
		 'riverdashboard:feeds:allow' => 'Allow user feeds on dashboard?',
		 'riverdashboard:feeds:userallow' => 'Show a feed on dashboard?',
		 'riverdashboard:feed:url' => 'Enter the url for a feed you want to display.',
		 'riverdashboard:feed:items' => 'How many items from feed to display?',
		 'riverdashboard:feed:excerpt' => 'Show excerpts?',
		 /*** notifications ***/
		 'river:requests' => 'Thông báo',
         /*
		  *End Fusion Mod
		  */

		/*
		 * MOD START by Snow
		 */
		'river:post:toolong' => 'Your post reached length limit',
		'generic_comment:empty' => 'Please input comment content',	
		'river:doing' => "What are you doing? Tell everyone on the river:",
		'riverpost' => 'River Post',
		'river:post:charleft' => 'characters left',
		'river:post:posted' => 'Disussion posted',
		'river:post:failure' => 'Failed to post discussion.This may cause by an internal error.Please report to the admin.',
		'river:comment' => 'Want to say something?',
		'river:item:toggle_comments' => "Hiện/ẩn các bình luận",
		'river:comment:post' => 'Bình luận',
		'sidebox:recent_members' => 'Recent Members',
		'sidebox:birthday_members' => 'Birthdays',
		'today' => 'Hôm nay',
		'tomorrow' => 'Ngày mai',
		'aftertomorrow' => 'The day after tommorrow',
		'riverdashboard:welcome' => 'Chào mừng %s',
	
		'river:image:goto_full' => 'View full size',
		'river:image:toggle_size' => 'Toggle size',
		/*
		 * MOD END by Snow
		 */ 
		'mine' => 'Bài của tôi',
		'filter' => 'Bộ lọc',
		'riverdashboard:useasdashboard' => "Replace the default dashboard with this activity river?",
		'activity' => 'Activity',
		'riverdashboard:recentmembers' => 'Recent members',
		
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "Thông báo website",
		'sitemessages:posted' => "Đăng",
		'sitemessages:river:created' => "Site admin, %s,",
		'sitemessages:river:create' => "posted a new site wide message",
		'sitemessages:add' => "Add a site-wide message to the river page",
		'sitemessage:deleted' => "Site message deleted",
		
		'river:widget:noactivity' => 'We could not find any activity.',
		'river:widget:title' => "Activity",
		'river:widget:description' => "Show your latest activity.",
		'river:widget:title:friends' => "Friends' activity",
		'river:widget:description:friends' => "Show what your friends are up to.",
		'river:widgets:friends' => "Bạn bè",
		'river:widgets:mine' => "Bài của tôi",
		'river:widget:label:displaynum' => "Number of entries to display:",
		'river:widget:type' => "Which river would you like to display? One that shows your activity or one that shows your friends activity?",
		'item:object:sitemessage' => "Site messages",
		'riverdashboard:avataricon' => "Would you like to use user avatars or icons on your site activity stream?",
		'option:icon' => 'Biểu tượng',
		'option:avatar' => 'Ảnh đại diện',
	);
					
	add_translation("vi",$vietnamese);

?>
