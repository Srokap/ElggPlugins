<?php 
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard autorefresh fix for ie
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Christian Heckelmann
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
        require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
        global $CONFIG;
?>
refreshinit('<?php  echo $CONFIG->wwwroot; ?>');