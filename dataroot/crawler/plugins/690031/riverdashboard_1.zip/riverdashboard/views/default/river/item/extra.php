<?php
    /**
     * extra view of river item
     * replaces the default wrappers inner div
     * performer and time,maybe comment of a river item
     *
     * @package ImprovedRiverDashboard
     */
    /**
     * @author Snow.Hellsing <snow.hellsing@firebloom.cc>
     * @copyright FireBloom Studio
     * @link http://firebloom.cc
     */
    $performed_by = $vars['performed_by'];
    $object = $vars['object'];
    $body = $vars['body'];
    $show_comment = $vars['show_comment'];
   
    //echo '</div>';//break from basic_river_item_view
?>
<script type="text/javascript">
function addComment(entityId)
{
  var cText = "itemCommentForm"+entityId;
  document.getElementById(cText).style.display = '';
}

function displayMoreComments(cId,numRows) {

var idName = 'showMore'+cId;
 document.getElementById(idName).style.display = 'none';
 
var i=1;
var rows = parseInt(numRows);
rows = rows - 1;
for (i=1;i<=rows;i++){
      cName = 'comment';
     cName = cName+cId;
    cName = cName+i;
    document.getElementById(cName).style.display = '';
 }

}
</script>

    <table >
        <tr>
        <td valign="top" align="left">
            <?php
		/*
	    	echo elgg_view("profile/icon",
                    array(
                        'entity' => $performed_by,
                        'size' => 'small'));
	    	*/
            ?>
            </td>
        <td>
            <table valign="top" align="left">
              <tr valign="top">
                <b><a href="<?php echo $performed_by->getURL(); ?>"><?php echo $performed_by->name; ?></a></b>
                <?php echo $body; ?>
		<?php 
			if ( $show_comment )
			{
		?>
		<!--  <div><a href="" onclick="$('#river_item_comments-<?php echo $object->guid ?>').toggle();return false;"><?php echo sprintf(elgg_echo('river:item:toggle_comments'),count_annotations($object->guid,'','','generic_comment'));?></a></div> -->

		<?php
			}
		?>
              </tr>
              <tr>
                <div align="left">
                    <span class="riverTime" color="#808080"><?php echo friendly_time($object->time_created); ?> &#149;</span>           
                    <!-- <span class="riverComment"> <a href="nojava.html" onclick="document.getElementById('itemCommentForm<?php echo $object->guid; ?>').style.display = '';return false"> Comment </span> -->
                    <br />               
                </div>
              </tr>
       


    <?php
                //$entityItem = $object->getContainerEntity();
                $count = $object->countAnnotations('generic_comment');
                $commentArray = $object->getAnnotations('generic_comment',100,0,"asc");
                //$count = sizeof($commentArray);
                if ($count == 0) {
                    ;//do nothing
                }
                else // if ($count <= 3) 
		{ //show all comments
                        print("<tr align=\"left\"><td>");

		echo "<div class=\"item_comments\" id=\"river_item_comments-".$object->guid."\" style=\"display:;\">";
                        echo list_annotations($object->guid,'generic_comment',100);
			echo "\n";
			echo "</div>";
                        print("</td></tr>");
                }
		/*
                else { //display first and last comment, with an "show # more comments" option in the middle
                $annotation = $commentArray[0];
                 print("<tr align=\"left\"><td>");
                 echo  elgg_view_annotation($annotation, "", false);
                 print("</td></tr>");
                   $moreCommentNum = $count - 2;
                 print("<tr align=\"left\"><td id=\"showMore".$object->guid."\" class=\"generic_commentText\">");
                 print("  <a href=\"#\" onclick=\"javascript:displayMoreComments(".$object->guid.",".$count.");return false\">Show $moreCommentNum more comments...</a>");
                 print("</td></tr>");


                $i = 1;
                for ($i = 1; $i < ($count - 1); $i++) {
                  $annotation = $commentArray[$i];
                    print("<tr align=\"left\"><td style=\"display: none\" id=\"comment".$object->guid.$i."\" >");
                    echo elgg_view_annotation($annotation,"",false);
                    print("</td></tr>");
                }

                $annotation = $commentArray[$count - 1];
                 print("<tr align=\"left\"><td>");
                 echo  elgg_view_annotation($annotation, "", false);
                 print("</td></tr>");
           
   

                }
		*/
            ?>

              <tr align="left">
        <?php
                print("<td align=\"left\" id=\"itemCommentForm".$object->guid."\"");
	    /*
            if ($count > 0) {
                print("<td align=\"left\" id=\"itemCommentForm".$object->guid."\"");
            }
            else {
                print("<td align=\"left\" id=\"itemCommentForm".$object->guid."\" style=\"display: none;\">");
            }
	    */
        ?>


                       <?php echo elgg_view('river/forms/comment',array('entity' => $object));?>
                </td>
              </tr>



            </table>
        </td>
      </tr>
    </table>
