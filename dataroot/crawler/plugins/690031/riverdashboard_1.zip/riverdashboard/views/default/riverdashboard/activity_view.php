<script src="<?php echo $CONFIG->wwwroot; ?>mod/riverdashboard/js/refresh.js" onload="javascript:refreshload('<?php  echo $vars['url'] ?>');" ></script>
<!--[if IE]><script defer src="<?php echo $CONFIG->wwwroot; ?>mod/riverdashboard/js/ie_onload.php"></script><![endif]-->
<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard activity view
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/

	 //grab the users latest from the wire
	 
	$latest_wire = get_entities("object", "thewire", $_SESSION['user']->guid, "", 1, 0, false, 0, null); 
	if($latest_wire){
		foreach($latest_wire as $lw){
			$content = $lw->description;
			$time = "<span> (" . friendly_time($lw->time_created) . ")</span>";
		}
	}
	$wire_user = get_input('wire_username');
	if (!empty($wire_user)) { $msg = '@' . $wire_user . ' '; } else { $msg = ''; }

?>

<script>
function textCounter(field,cntfield,maxlimit) {
    // if too long...trim it!
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    } else {
        // otherwise, update 'characters left' counter
        cntfield.value = maxlimit - field.value.length;
    }
}
</script>
<script type = "text/javascript">
var count = 0;
function changeCol(which) {
which.style.color = '#000000';
if(count == 0) {
which.value = "";  // erase text only on first focus
count ++;
}
}
</script>
<div id="river_container2">
<div class="dash_pad">
<div class="sidebarBox">

	<form action="<?php echo $vars['url']; ?>action/riverdashboard/shout" method="post" name="noteForm">
		<?php echo "<div class='thewire_latest1'><b>" . elgg_echo('thewire:latest') .":</b> " . $content . " " . $time . "</div><div class='clearfloat'></div>"; ?>	
		<?php
			$display .= "<div class='thewire_characters_remaining'><input readonly type=\"text\" name=\"remLen1\" size=\"3\" maxlength=\"3\" value=\"140\" class=\"thewire_characters_remaining_field\">";
		    $display .= elgg_echo("thewire:charleft") . "</div>";
            //$display .= "<h3>" . elgg_echo('river:newpost') . "</h3>";
		
		    $display .= "<textarea name='note' value='' onKeyDown=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" onKeyUp=\"textCounter(document.noteForm.note,document.noteForm.remLen1,140)\" id=\"thewire_sidebarInputBox\" onfocus =\"changeCol(this)\">{$msg}".elgg_echo('river:newpost')."</textarea>";
			
		    echo $display;
                    
            echo elgg_view('input/securitytoken');
			
		?>
			<input type="hidden" name="method" value="site" />
			<input type="hidden" name="location" value="activity" />
            <div style="float:right; width:40px;">
            <input type="submit" value="<?php echo elgg_echo('river:activity:post'); ?>" id="thewire_submit_button" />
            </div>
            </form>
            <div id="atticons">
            <div id="tooltip" style="float:left;">
            <h4 style="float:left; padding:3px 3px 0 0; color:#666666;"><?php echo elgg_echo('river:activity:add'); ?></h4>
            <?php if (is_plugin_enabled('tidypics')){ ?>
            <a href="javascript:ajaxpage('<?php echo $vars['url'];?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/image.php','load_content');">
            <a href="javascript:ajaxpage('<?php echo $vars['url']; ?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/newalbum.php','load_content');"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/icon_image.png" title="Photos" /></a> 
            <?php } ?>
            
            <?php if (is_plugin_enabled('izap_videos')){ ?>
            <a href="javascript:ajaxpage('<?php echo $vars['url'];?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/video.php','load_content');"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/icon_video.png" title="Videos" /></a>
            <?php } ?>
            
            
            <a href="javascript:ajaxpage('<?php echo $vars['url']; ?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/addlink.php','load_content');"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/link.png" title="Links" /></a>
            
         
            <?php if (is_plugin_enabled('poll')){ ?>
            <a href="javascript:ajaxpage('<?php echo $vars['url']; ?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/addpoll.php','load_content');"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/polls.png" title="Polls" /></a>
            <?php } ?>
            </div>
            
        
            <ul class="cssMenu cssMenum">
	<li class=" cssMenui"><a class="  cssMenui" href="#"><span>More</span><![if gt IE 6]></a><![endif]><!--[if lte IE 6]><table><tr><td><![endif]-->
	<ul class=" cssMenum">
        <?php if (is_plugin_enabled('event_calendar')){ ?>
		<li class=" cssMenui"><a class="  cssMenui" href="<?php echo $vars['url']; ?>pg/event_calendar/new/"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/icon_event.png" /> Events </a></li>
        <?php } ?>
    
        <?php if (is_plugin_enabled('gifts')){ ?>
		<!--<li class=" cssMenui"><a class="  cssMenui" href="javascript:ajaxpage('<?php echo $vars['url']; ?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/sendgift.php','load_content');"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/icon_gift.png" /> Gifts </a></li>-->
        <li class=" cssMenui"><a class="  cssMenui" href="<?php echo $vars['url']; ?>pg/gifts/<?php echo $_SESSION['user']->username; ?>/sendgift"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/icon_gift.png" /> Gifts </a></li>
        <?php } ?>
        
	</ul>
	<!--[if lte IE 6]></td></tr></table></a><![endif]--></li>
</ul>
        
            </div><!-- /atticons -->
        
            <div class="clearfloat"></div>
</div><!-- /sidebar box -->
<div id="load_content"></div><!-- load the ajax content in this div-->

<?php echo elgg_view('input/urlshortener'); ?>
</div><!-- /dashpad -->
</div><!-- / rivercontainer2 -->
