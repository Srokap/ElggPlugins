<div id="river_container2">


<?php
// On inclue lastRSS.php
require_once '' .$CONFIG->pluginspath. 'riverdashboard/lastRSS.php'; //the relative path to the file,
// Options de base
$feed_url = get_plugin_usersetting("feed_url", "riverdashboard");
$url_flux_rss = $feed_url;
$feedItems = get_plugin_usersetting("feedItems", "riverdashboard");
$limit       = $feedItems; 
$rss = new lastRSS;

$rss->cache_dir   = ''. $CONFIG->pluginspath. 'riverdashboard/temp'; 
$rss->cache_time  = 1200;      
//$rss->date_format = date();     
$rss->CDATA       = 'content';
    
if ($rs = $rss->get($url_flux_rss)) 
{
	echo '<div class="collapsable_box_header">';
	echo "<h1><a href=\"$rs[link]\">$rs[title]</a></h1></div>";
	echo '<div class="collapsable_box_content">';
	echo '<div class="contentWrapper">';
  for($i=0;$i<$limit;$i++)
  {
	// show title
    echo '<a href="'.$rs['items'][$i]['link'].'" target="_blank">'.$rs['items'][$i]['title'].'</a>';
	//show timestamp
	echo '<div class="pubdate" style="padding-bottom:8px;">'.$rs['items'][$i]['pubDate'].'</div>'; 
	// if theres an excerpt then show it
if(get_plugin_usersetting("feedExcerpt", "riverdashboard") != "no"){
	echo $rs['items'][$i]['description'].'<br /><br />';
}
  }
}
?>
</div>
</div>

