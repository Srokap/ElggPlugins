<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard video links
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
require_once(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . "/engine/start.php");
?>
<div id="river_container2" style="margin-top:3px;">
<div class="dash_pad">

<div style="border-bottom:1px solid silver; margin:0 auto 5px auto;" >
<div style="float:left; width:49%;">
<img style="float:left;" src="<?php echo $CONFIG->wwwroot; ?>mod/riverdashboard/graphics/icon_video.png"> <span style="padding:0 0 0 3px;"><?php echo elgg_echo('river:video:videos'); ?></span>
</div>
<div align="right" style="float:right; width:49%;">
<input style="border:none; padding:0 0 2px 0;" type="image" src="<?php echo $CONFIG->wwwroot; ?>mod/riverdashboard/graphics/close.png" onClick="document.getElementById('load_content').innerHTML=''">
</div>
<div class="clearfloat"></div>

</div>
<div style="float:left; width:49%; padding:5px 0; border:1px solid silver">
<center>
<a href="<?php echo $CONFIG->wwwroot; ?>pg/izap_videos/<?php echo $_SESSION['user']->username; ?>/add">
<a href="javascript:ajaxpage('<?php echo $CONFIG->wwwroot; ?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/addvideo.php','load_content');"><h2><?php echo elgg_echo('river:video:add'); ?></h2></a>
<span style="font-size:11px; color:#666666;"><?php echo elgg_echo('river:video:supported'); ?></span>
</center>
</div>

<div style="float:right; width:49%; padding:5px 0; border:1px solid silver;">
<center>
<a href="<?php echo $CONFIG->wwwroot; ?>pg/izap_videos/<?php echo $_SESSION['user']->username; ?>/add?option=IZAP_FILE">
<a href="javascript:ajaxpage('<?php echo $CONFIG->wwwroot; ?>mod/riverdashboard/views/default/riverdashboard/ajaxpage/uploadvideo.php','load_content');"><h2><?php echo elgg_echo('river:video:upload'); ?></h2></a>
<span style="font-size:11px; color:#666666;"><?php echo elgg_echo('river:video:harddrive'); ?></span>
</center>
</div>
<div class="clearfloat"></div>
</div>
</div>