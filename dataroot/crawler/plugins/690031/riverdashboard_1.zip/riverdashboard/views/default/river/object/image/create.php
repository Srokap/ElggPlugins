<?php
	/**
	 * @author Snow.Hellsing <snow.hellsing@firebloom.cc>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */

	$performed_by = get_entity($vars['item']->subject_guid);
	$object = get_entity($vars['item']->object_guid);
	$url = $vars['url'];	
	$mime = $object->mimetype;	
	
	// $summary .= elgg_echo("image:river:created");
	// $url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$album = get_entity($object->container_guid);
	$lien_album = "<a href=".$album->getURL().">".$album->title."</a>";
	$lien_photo = "<a href=".$object->getURL().">".$object->title."</a>";
	$summary = sprintf(elgg_echo('image:river:created'),$performed_by->name,$lien_photo,$lien_album);
	// $object->container_guid;
	
	$goto_full = "<a href=\"{$object->getURL()}\" target=\"_blank\" class=\"goto_full\" id=\"image_toggle-{$object->guid}\">".elgg_echo('river:image:goto_full')."</a>";

	// $goto_full .=" - <a href=\"\" class=\"toggle_comment\">(<span class=\"comment_cnt\">". count_annotations($object->guid,'','','generic_comment')."</span>)&nbsp;".elgg_echo('river:item:toggle_comments')."</a>";
if ( count_annotations($object->guid,'','','generic_comment') != 0 )
$comments ="<br><a href=\"\" class=\"toggle_comment\">".elgg_echo('river:item:toggle_comments')." (<span class=\"comment_cnt\">". count_annotations($object->guid,'','','generic_comment')."</span>)</a>";
else
$comments = "";
	
	$thumb = "<img src=\"{$url}mod/tidypics/thumbnail.php?file_guid={$object->guid}&size=small\" border=\"0\" alt=\"thumbnail\"/>";
	
	echo elgg_view('river/item/extra',
					array('performed_by'=>$performed_by,
						'object'=>$object,
						'body'=>$summary.' - '.$goto_full.'<br />'.$thumb.$comments,
						'show_comment'=>TRUE)
					);
	
?>
