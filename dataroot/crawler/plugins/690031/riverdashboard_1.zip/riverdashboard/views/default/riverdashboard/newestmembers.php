<?php
/*******************************************************************************
 * 3 column dashboard
 * view for newest members
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
   // Get the number of events to display
    
	
?>
<div id="river_container2">
    
<div class="collapsable_box_header">        
<h1><?php echo elgg_echo('Friends Online') ?></h1>
</div>
<div class="collapsable_box_content">
<div class="contentWrapper">
<?php 
	//foreach($newest_members as $mem){
		//echo "<div class=\"recentMember\">" . elgg_view("profile/icon",array('entity' => $mem, 'size' => 'tiny')) . "</div>";
	//}
         $friends = $_SESSION['user']->getFriends("",1000);

$friends_online = 0;
	if (count($friends) > 0) 
	{
		foreach ($friends as $friend) 
		{
			if ($friend->last_action > time() - 200) 
			{		
				$icon = elgg_view("profile/icon", array('entity' => get_user($friend->guid), 'size' => 'tiny'));
				echo "<div class=\"friends_online\">\n";     
				echo $icon;
				echo "</div>\n";
				$friends_online++;
			} 
		} 
	}
?>
<div class="clearfloat"></div>
</div>
        

    </div><!-- /dash_pad -->
</div><!-- / river_container2 -->
