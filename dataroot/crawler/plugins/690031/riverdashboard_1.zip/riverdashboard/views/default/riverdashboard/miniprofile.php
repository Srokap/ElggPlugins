<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column replacement riverdashboard miniprofile
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
if (isloggedin()){
?>
<div id="river_container2">
<div class="collapsable_box_content" style="-moz-border-radius-topleft:8px;-moz-border-radius-topright:8px;">
<div class="contentWrapper">



<div align="center" style="padding-top:20px;">

     
 <?php

        // Get entity
                if (empty($vars['entity']))
                        $vars['entity'] = $vars['user'];

                if ($vars['entity'] instanceof ElggUser) {
                        
                $name = htmlentities($vars['entity']->name, ENT_QUOTES, 'UTF-8');
                $username = $vars['entity']->username;
                
                if ($icontime = $vars['entity']->icontime) {
                        $icontime = "{$icontime}";
                } else {
                        $icontime = "default";
                }
                        
        // Get size
                if (!in_array($vars['size'],array('small','medium','large','tiny','master','topbar')))
                        $vars['size'] = "large";
                        
        // Get any align and js
                if (!empty($vars['align'])) {
                        $align = " align=\"{$vars['align']}\" ";
                } else {
                        $align = "";
                }

        // Override
                if (isset($vars['override']) && $vars['override'] == true) {
                        $override = true;
                } else $override = false;
                
                if (!$override) {
                
?>
<div class="usericon">

        
        <?php
                if ((isadminloggedin()) || (!$vars['entity']->isBanned())) {
         ?><a href="<?php echo $vars['entity']->getURL(); ?>" class="icon" ><?php 
                }
                
        } 
        
        ?><img src="<?php echo $vars['entity']->getIcon($vars['size']); ?>" border="0" width="160"<?php echo $align; ?> title="<?php echo htmlentities($vars['entity']->username, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $vars['js']; ?> /><?php

                if (!$override) {
        
        ?></a><div class="sub_menu">
                <a href="<?php echo $vars['entity']->getURL(); ?>"><h3><?php echo $vars['entity']->username; ?></h3></a>
                <?php
                        if (isloggedin()) {
                                $actions = elgg_view('profile/menu/actions',$vars);
                                if (!empty($actions)) {
                                        
                                        echo "<div class=\"item_line\">{$actions}</div>";
                                        
                                }
                                if ($vars['entity']->getGUID() == $vars['user']->getGUID()) {
                                        echo elgg_view('profile/menu/linksownpage',$vars);
                                } else {
                                        echo elgg_view('profile/menu/links',$vars);
                                }                                       
                        } else {
                                echo elgg_view('profile/menu/links',$vars);
                        }
                ?>
        </div>  
</div>

<?php

        }
                }

?>
</div>

<?php
    echo "<div align='center'>";
        echo "<h2 style=\"font-size:12px; margin-top:3px; color:#0000CD\">" . elgg_echo('river:mini:hi') . " ";
    echo $vars['user']->username;
    echo "</h2>";
        echo "</div>";
        //date
        echo "<div align='center' style='font-size:9px;color:#0000CD;'>";
        print(Date("l F d, Y"));
        echo "</div>";

   // profile stats
    $current_count = get_loggedin_user()->getAnnotations("profilecount");
        
        if(!$current_count){
                $current_count = 0;
        } else {
                $current_count = $current_count[0]->value;
        }
        echo "<div align='center' style='font-size:11px; font-weight:bold;color:#0000CD;'>" .sprintf(elgg_echo('river:stats:currentcount'),$current_count). "</div>";
        
   // start user points
    if (is_plugin_enabled('userpoints')){ 
            echo "<div align='center' style='font-size:11px;color:#0000CD;'><b>";
                $upperplural = get_plugin_setting('upperplural', 'userpoints');
        echo $upperplural . ': ' . $vars['entity']->userpoints_points. "</b></div>";
        }
   // end of user points 
   
// start of vazco karma
    if (is_plugin_enabled('vazco_karma')) { 
        echo "<div align='center' style='font-size:11px; font-weight:bold;color:#0000CD;'>";
    global $CONFIG;
        if ($vars['size'] == 'large'){ 
                $karma = new vazco_karma();
                $user = $vars['entity'];
            if ($karma->showPointsOnProfile()){
                    $points = $karma->getUserPoints($user);
                    $rank = $karma->getUserRank($user);
        echo "<div class='karma_profile_points1'>";
        echo "<div><span class='karma_profile_header'>" .elgg_echo('vazco_karma:profile:points'). "</span> <span>" .$points. "</span></div>";
        echo "<div><span class='karma_profile_header'>" .elgg_echo('vazco_karma:profile:rank'). "</span> <span>" .$rank. "</span></div>";
            if (isadminloggedin() || $user->guid == get_loggedin_userid()){
                        echo "<div class='vazco_points_history'><a href='" .$CONFIG->wwwroot. "pg/vazco_karma/history/" .$user->username. "'>" .elgg_echo('vazco_karma:history:menu'). "</a></div>";
                }
                echo "</div>";
                }
                }
                echo "</div";
        }
        // end vazco karma
        
 // start user menu
    echo "<div align='center' style='width:185px; margin:0 auto;'>";
	if (is_plugin_enabled('requestnotifications')){
        echo "<hr />";
		echo elgg_view('requestnotifications/shortlist', $vars);
		echo '<a href="' .$vars['url']. 'pg/requestnotifications/" class="requestnotifications_viewall">' .elgg_echo('requestnotifications:viewall'). '</a><br />';
	}
		echo "<hr />";
        if (is_plugin_enabled('tidypics')) {
            echo "<div>Photos: <a href='" .$vars['url']. "pg/photos/owned/" .$_SESSION['user']->username. "'>" .elgg_echo("river:mini:edit"). "</a></div>";
        }
        if (is_plugin_enabled('izap_videos')) {
                echo "<div>Videos: <a href='" .$vars['url']. "pg/izap_videos/" .$_SESSION['user']->username. "'>" .elgg_echo("river:mini:edit"). "</a></div>";
        }
        if (is_plugin_enabled('blog')) {
                echo "<div><a href='" .$vars['url']. "pg/blog/" .$_SESSION['user']->username. "'>" .elgg_echo("river:mini:blog"). "</a></div>";
        }
        if (is_plugin_enabled('groups')) {
                echo "<div><a href='" .$vars['url']. "pg/groups/member/" .$_SESSION['user']->username. "'>" .elgg_echo("river:mini:groups"). "</a></div>";
        }
        if (is_plugin_enabled('omni_inviter')) {
                echo "<div><a href='" .$vars['url']. "pg/omni_inviter/invite/'>" .elgg_echo("river:mini:invite"). "</a></div>";
        }else{
			if (is_plugin_enabled('invitefriends')) {
                echo "<div><a href='" .$vars['url']. "mod/invitefriends/'>" .elgg_echo("river:mini:invite"). "</a></div>";
        }else{
		}
		}
			
        // user account admin - collapsible div using jquery
        echo "<div class='msg_list'>";
        echo "<h3 class='msg_header'>" .elgg_echo('river:mini:manage'). "</h3>";
        echo "<div class='msg_body2'>";
        echo "<div style='margin-left:-35px'><h3 style='font-size:15px; width:62%;'>" .elgg_echo('river:mini:account'). "</h3>";
        echo "<div  align='center'>";
        if (is_plugin_enabled('customstyle')) {
            echo "<div><a href='" .$vars['url']. "pg/customstyle/'>" .elgg_echo('river:mini:custom_profile'). "</a></div>";
        }
        echo "<div><a href='" .$vars['url']. "mod/profile/editicon.php'>" .elgg_echo('river:mini:profile_image'). "</a></div>";
        echo "</div>";
        echo "<h3 style='font-size:15px; width:62%;'>" .elgg_echo('river:mini:edit_account'). "</h3>";
        echo "<div  align='center'>";
        echo "<div><a href='" .$vars['url']. "pg/settings/'>" .elgg_echo('river:mini:account_settings'). "</a></div>";
		echo "<div><a href='" .$vars['url']. "pg/settings/plugins/" .$_SESSION['user']->username. "'>" .elgg_echo('river:mini:tools'). "</a></div>";
        if (is_plugin_enabled('notifications')) {
                echo "<div><a href='" .$vars['url']. "mod/notifications/'>" .elgg_echo("river:mini:notifications"). "</a></div>";
        }
        echo "<div><a href='" .$vars['url']. "mod/profile/edit.php?username=" .$_SESSION['user']->name. "'>" .elgg_echo('river:mini:edit_profile'). "</a></div>";
        echo "</div>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
}
?>
