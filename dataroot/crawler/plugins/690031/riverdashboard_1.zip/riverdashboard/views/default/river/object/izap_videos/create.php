<?php
/**
* iZAP izap_videos
*
* @package Elgg videotizer, by iZAP Web Solutions.
* @license GNU Public License version 3
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version 1.6.1-2.5
*/
     // include $CONFIG->pluginspath . 'izap_videos/classes/izapLib.php';

	 $item  = $vars['item'];
	
	$performed_by = get_entity($item->subject_guid); // $statement->getSubject();
	$object = get_entity($item->object_guid);
	$url = $object->getURL();
	$videoTitle .= '<a href="' . $url . '">' . $object->title . '</a>';
	$url = "<a href=\"{$performed_by->getURL()}\">{$performed_by->name}</a>";
	$string .= sprintf(elgg_echo('izap_videos:river:titled'),$url,$videoTitle);
	
	// checks the video src is it onserver or off server
    $video = new IzapVideos($item->object_guid);
    $video_src = $object->videosrc;
    if(!$video_src)
      $video_src = $CONFIG->wwwroot . "pg/izap_videos/izap/video/" . $object->getGUID() . '/' . friendly_title($object->title) . '.flv';

    // gets back the player code
    if( ! $object->converted ){
    // if(izapVideoNotConverted_izap_videos($object)){
      //$playerClass = 'class="notConvertedWrapper"';
      $player = '<h3>'.elgg_echo('izap_videos:processed').'</h3>';
    }else{
      $player = $video->getPlayer(356,216);
      // $player = izapGetPlayer_izap_videos($object->videotype, $video_src, $object->autoplay, 365, 216);
	  //$player = izapGetPlayer_izap_videos($object->videotype, $video_src, $object->autoplay, 270, 180);
      //$playerClass = 'class="izap_videos_selected"';
      }

    $showvideo = '<div class="resize_div">' . $player . '</div>';
if ( count_annotations($object->guid,'','','generic_comment') != 0 )
$comments =" <a href=\"\" class=\"toggle_comment\">".elgg_echo('river:item:toggle_comments')." (<span class=\"comment_cnt\">". count_annotations($object->guid,'','','generic_comment')."</span>)</a>";
else
$comments = "";


echo elgg_view('river/item/extra',
	array('performed_by'=>$performed_by,
	'object'=>$object,
	'body'=>$string.$showvideo.$comments,
	'show_comment'=>TRUE));

	 //echo $string;
	 //echo $showvideo;
	
  
?>
