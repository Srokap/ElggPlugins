<?php
/*******************************************************************************
 * 3 column dashboard
 * welcome view for dashboard
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
 
?>
<div id="river_container2">
<div class="dash_pad">

<div id="welcome_left">
<h3 style="float:left;"><?php
        echo elgg_echo('river:mini:welcome'). " "; 
        echo $_SESSION['user']->name; ?>
</h3>
&nbsp;<a style="font-size:9px; padding-left:10px;" href='<?php echo $vars['url'];?>mod/profile/edit.php?username=<?php echo $_SESSION['user']->name; ?>'><?php //echo elgg_echo('Edit Profile'); ?></a>
<div class="clear"></div>

<div id="welcome_left_url">
<img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/url.gif" border="0" />&nbsp;<b><a href='<?php echo $vars['url'];?>mod/profile/edit.php?username=<?php echo $_SESSION['user']->username; ?>'><?php echo $vars['url']; ?><?php echo $_SESSION['user']->username; ?></a></b>
</div>

</div>

<div id="welcome_right">
<MARQUEE WIDTH=100% BEHAVIOR=SCROLL onmousemove="this.stop()" onmouseout="this.start()">
<a href="http://www.elgg.com"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/g1.jpg" border="0" /></a>
   <a href="http://www.twitter.com"> <img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/g2.jpg" border="0" /></a>
  <a href="http://www.drupal.com"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/g5.jpg" border="0" /></a>
   <a href="http://www.facebook.com"><img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/g3.jpg" border="0" /></a>
    <a href="http://www.pligg.com">    <img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/g4.jpg" border="0" /></a>
</MARQUEE>
<center>
<?php
		//allow people to extend this top menu
/*		echo elgg_view('welcome/extend', $vars);
		
if(get_plugin_setting("show_topads", "riverdashboard") != "no") {
	$topads_code = get_plugin_setting('topads_code','riverdashboard');
	    echo $topads_code;
}*/
?>
</center>
</div>

<div class="clearfloat"></div>

</div>
</div>
