<?php if (is_plugin_enabled('poll')){ ?>
<div id="river_container2">

<?php
   // Get the number of events to display
    $pollsToDisplay = get_plugin_setting('pollsToDisplay','riverdashboard');
        //$limit = 5;

        ?>
        <div class="collapsable_box_header">
		<h1><?php echo elgg_echo("river:poll"); ?></h1>
        </div>
        <div class="collapsable_box_content">
        <div class="contentWrapper">
<?php
		$polls = get_entities('object','poll',0,'time_created desc',$pollsToDisplay,$offset,false,0);
		
		$count = get_entities('object','poll',0,'time_created desc',999,0,true);
		
		
		set_context('search');
		
		$mypolls .= elgg_view_entity_list($polls,$count,$offset,$pollsToDisplay,false,false,false);
		echo $mypolls;
		

		
?>
<div align="right"><a href="<?php echo $vars['url']; ?>mod/poll/everyone.php"><?php echo elgg_echo("river:viewall"); ?></a></div>

</div>
</div>
</div>
<?php } ?>
