<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column layout
 *
 * @package 3 column fluid dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
?>
<style>
#rivcontainer {
  padding-left: 220px;   /* LC width */
  padding-right: 240px;  /* RC width */
}
#rivcontainer .column {
  float: left;
  position: relative;
}
#center {
  width: 100%;
}
#left {
  width: 220px;  /* LC width */
  margin-left: -100%;
  right: 220px;        /* LC width */
}
#right {
  width: 240px;  /* RC width */
  margin-right: -240px;  /* RC width */
  
}

*html, #left {
  left: 295px;  /* RC width */
}
</style>
<div id="riverwrap">
<div id="river_welcome">
<div class="dash_pad">
<?php if (isset($vars['area4'])) echo $vars['area4']; ?>
</div>
</div>

<div id="rivcontainer">

  <div id="center" class="column">
  <div class="dash_pad">
  <?php if (isset($vars['area2'])) echo $vars['area2']; ?>
  </div>
  </div>

  <div id="left" class="column">
  <div class="dash_pad">
  <?php if (isset($vars['area1'])) echo $vars['area1']; ?>
  </div>
  </div>
  
  <div id="right" class="column">
  <div class="dash_pad">
  <?php if (isset($vars['area3'])) echo $vars['area3']; ?>
  </div>
  </div>

</div>
<div class="clear"></div>
</div>