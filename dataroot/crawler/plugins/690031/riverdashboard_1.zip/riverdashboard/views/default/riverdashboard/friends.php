<?php
/*******************************************************************************
 * 3 column dashboard
 * 3 column riverdashboard Friends View
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
          
?>

<div id="river_container2">




<div class="collapsable_box_header">
<h1>People You Might Know</h1>
</div>

<div class="collapsable_box_content">

<div class="contentWrapper">
<div class="sidebarBox">
<div class="membersWrapper">
<?php
gatekeeper();

$widget = $vars['entity'];

$friends = $widget->look_in_friends == 'no' ? 0 : 2;
$groups = $widget->look_in_groups == 'no' ? 0 : 2;
$num_display = $widget->num_display != null ? $widget->num_display : 2;

$people = people_from_the_neighborhood_get_people(get_loggedin_userid(), 2, $groups);

echo elgg_view('people_from_the_neighborhood/people', array('people' => $people)); ?>
<div class="clearfloat"></div>
<div class="widget_more_wrapper"><a href="<?php echo $vars['url']; ?>pg/pftn"><?php echo elgg_echo('pftn:see:more'); ?></a></div>



</div>
</div>
</div>
</div>
</div>

