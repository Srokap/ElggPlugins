<?php
/*******************************************************************************
 * 3 column dashboard
 * custom wrapper for avatars on dashboard
 *
 * @package 3 column dashboard
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fusion <contact@donkeydesigns.us>
 * @copyright TheFloridaCircle.com 2008-2009
 * @link http://www.thefloridacircle.com/
 *
 ******************************************************************************/
    $object_guid = $vars['item']->object_guid;
	$posted = $vars['item']->posted;
?>

	<div class="river_item">
                 
		<div class="river_<?php echo $vars['item']->type; ?>">
                      
			<div class="river_<?php echo $vars['item']->subtype; ?>">
				<div class="river_<?php echo $vars['item']->action_type; ?>">				
					<div class="river_<?php echo $vars['item']->type; ?>_<?php if($vars['item']->subtype) echo $vars['item']->subtype . "_"; ?><?php echo $vars['item']->action_type; ?>">
                    
					 
                            <div id="1" style="padding:12px 0;">
                                <div id="2" style="width:40px; float:left;">
					                <?php  $performed_by = get_entity($vars['item']->subject_guid); echo elgg_view("profile/icon", array('entity' => $performed_by, 'size' => 'small')); ?>
					            </div>	
						<div class="basic_river_item_view">
                                    <div style="margin-left:55px;">
                                        <div id="riverbody" style="padding-bottom:7px;">
                                            <?php 
						                      echo $vars['body']; 
						                     ?>
                                        </div>
						                <span class="river_item_time" style="font-size:11px;">
							                <img src="<?php echo $vars['url']; ?>mod/riverdashboard/graphics/clock_icon.gif" width="11px" height="11px" /> <?php echo friendly_time($vars['item']->posted); ?>
                                        </span>
                                   </div><!-- / 2 -->
                        
                              </div><!-- / 1 -->                        
					    </div><!-- /basic_river_item_view -->
					</div>
                               

				</div>				
			</div>
		</div>
	</div>
