<?php
	/**
	 * Elgg GoogleMaps plugin
	 * This simple plugin will display your location in google map
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://webgalli.com/
	 * Proversion available at http://www.webgalli.com/elgg_plugins/profile/5056/google-maps-plugin-for-elgg-18x
	 */

$owneruser = elgg_get_page_owner_entity();
if (!isset($vars['entity']->location) || !$vars['entity']->location) {
  $location = GMAP_DEFAULT_LOCATION;
  if (isset($owneruser->location)) {
    if (is_array($owneruser->location)) {
      $location = implode(',', $owneruser->location);
    }
    else {
      $location = $owneruser->location;
    }
  }
}
else {
  $location = $vars['entity']->location;
}

$zoom = isset($vars['entity']->zoom) ? $vars['entity']->zoom : GMAP_DEFAULT_ZOOM;

echo elgg_view('galliGoogleMaps/map',array('location'=>$location , 'zoom' => $zoom,));
?>