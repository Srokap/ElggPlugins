<?php
	/**
	 * Elgg GoogleMaps plugin
	 * This simple plugin will display your location in google map
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @link http://webgalli.com/
	 * Proversion available at http://www.webgalli.com/elgg_plugins/profile/5056/google-maps-plugin-for-elgg-18x
	 */
	
	elgg_register_event_handler('init', 'system', 'galliGoogleMaps_init');
	
	define('GMAP_DEFAULT_LOCATION', 'Elgg, Switzerland');
	define('GMAP_DEFAULT_ZOOM', 8);

	function galliGoogleMaps_init() {
		elgg_register_widget_type('galliGoogleMaps',elgg_echo("galliGoogleMaps:wg:title"),elgg_echo("galliGoogleMaps:wg:detail"));
		$js_url = "http://maps.google.com/maps/api/js?sensor=false";
		elgg_register_js('elgg:gmaps', $js_url, 'head');		
	}	
?>