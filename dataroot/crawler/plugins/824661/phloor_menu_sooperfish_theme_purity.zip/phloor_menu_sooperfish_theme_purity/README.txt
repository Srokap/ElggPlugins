/**
 * Phloor Menu Sooperfish Theme Purity
 * 
 * @package phloor_menu_sooperfish_theme_purity
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author void <void@13net.at>
 * @copyright 13net
 * @link http://phloor.13net.at/
 */
 
Version: 1.8-11.12.05
Requires: Elgg 1.8 or higher



