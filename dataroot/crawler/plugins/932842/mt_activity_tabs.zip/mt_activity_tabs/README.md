Activity-Tabs-1.8.x
===================

Allows users to create custom tabs of activity based on groups and access collections for Elgg 1.8

Plugin should reside at mod/mt_activity_tabs