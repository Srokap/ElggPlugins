.activity_tabs_table tr td {
  padding: 2px 6px;
  vertical-align: middle;
}

.activity_tabs_table tr.odd {
  background-color: #e4e4e4;
}