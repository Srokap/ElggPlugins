<?php

	$swedish = array(

		'visuland:visuland' => 'Visuland 3D',
		'visuland:enter' => 'Stig in till Visuland',
		'visuland:welcome' => '
			<h3>V&auml;lkommen till gemensamma Visuland 3D!</h3>
			<span>Eftersom detta &auml;r f&ouml;rsta g&aring;ngen du anv&auml;nder gemensamma Visuland, ber vi dig om ett par fr&aring;gor till...</span>
			<span>N&auml;r du g&aring;r in, kommer du att kunna interagera med dina v&auml;nner och andra samh&auml;llsmedborgare p&aring;ett helt nytt s&auml;tt.</span>
			<span>V&auml;nligen, gl&ouml;m inte att acceptera licensavtalet genom att kryssa i rutan l&auml;ngst ner p&aring;sidan.</span>
		',
		'visuland:register:nick' => 'Nick (Detta kommer att bli ditt visningsnamn):',
		'visuland:register:gender' => 'K&ouml;n:',
		'visuland:register:male' => 'Man',
		'visuland:register:female' => 'Kvinna',
		'visuland:register:birthdate' => 'F&ouml;delsedag (YYYY.MM.DD format):',
		'visuland:register:city' => 'Stad:',
		'visuland:register:country' => 'Land:',
		'visuland:register:licence' => 'Licensavtal',
		'visuland:register:licence_text' => 'Se p&aring;<a href="http://visuland.biz/policies/" target="_blank">visuland.biz</a>',

		'visuland:register:licence_accept' => 'Kryssa i denna ruta f&ouml;r att acceptera licensavtalet',
			
		'visuland:register:success' => 'Du har nu registrerats p&aring; visuland servern.',
		'visuland:register:failure' => 'Det g&aring;r inte att registrera ditt konto p&aring;visuland servern. Server svar: ',
	
		'visuland:admin:settings' => 'Inst&auml;llningar',
		'visuland:admin:select_world' => 'V&auml;lj v&auml;rld',
		'visuland:admin:enable_guests' => 'Till&aring;t icke-registrerade anv&auml;ndare att komma &aring;t Visulands virtuella v&auml;rldar?',
		'visuland:admin:access' => '&Aring;tkomstniv&aring;',
		'visuland:admin:private' => 'Privat (l&aring;st till din Elgg installation)',
		'visuland:admin:public' => 'Offentlig (anv&auml;ndare accepteras fr&aring;n 3: e parts anl&auml;ggningar',
		'visuland:admin:domain_password' => 'Dom&auml;n l&ouml;senord',
		'visuland:admin:unmask' => "Don't mask",
		'visuland:admin:info' => '<ul><li>F&ouml;r att f&aring;ditt unika dom&auml;n l&ouml;senord, v&auml;nligen kontakta oss p&aring;<a href="http://visuland.biz/contact-us/?domain=:domain:" target="_blank">visuland.biz</a>.</li>
			<li>Servern beh&ouml;ver l&ouml;senordet f&ouml;r att h&auml;mta tillg&auml;ngliga platser. Platserna kommer inte att visas i listan tills du har st&auml;llt in ditt l&ouml;senord och sparat.</li>
			<li>F&ouml;r att kolla in v&aring;ra live Elgg integrationer, v&auml;nligen logga in p&aring;<a href="http://elgg.visuland.com/" target="_blank">elgg.visuland.com</a>.</li>
			<li>Denna plugin kr&auml;ver <a href="http://community.elgg.org/pg/plugins/project/461662/developer/jeabakker/country-selector">Country Selector</a>
			plugin som ska installeras.</li>
		</ul>',
	
		'visuland:browser:not_supported' => '<h3>Din webbl&auml;sare st&ouml;ds inte f&ouml;r tillf&auml;llet.</h3><p>Vi &auml;r mycket ledsna, men v&aring;r plugin st&ouml;ds bara med MS Internet Explorer 7 + och Mozilla Firefox webbl&auml;sare. Vi f&ouml;resl&aring;r att antingen byter till n&aring;gon av de n&auml;mnda webbl&auml;sarna f&ouml;r att anv&auml;nda Visuland eller &aring;terkomma senare. Vi ut&ouml;kar kontinuerligt v&aring;r lista med webbl&auml;sare som st&ouml;ds, s&aring;det finns en god chans att din kommer att st&ouml;djas snart ocks&aring;.</p>',

		'visuland:plugin:not_installed' => 'Visuland 3D samfundet kr&auml;ver installation av en plugin. Acceptera installationsbeg&auml;ran fr&aring;n webbl&auml;saren.',
		'visuland:plugin:installed' => 'Visuland plugin har installerats. Starta om Firefox f&ouml;r att slutf&ouml;ra installationen.',
	);
					
	add_translation('sv', $swedish);

?>