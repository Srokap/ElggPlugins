<?php
    /**
	 * superid customed login action
	 * 
	 * @package superid
	 * @author snow@firebloom.cc
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */	
	 
	// Safety first
		action_gatekeeper();

    // Get mobile and password    
        
		$id = get_input("id");
        $password = get_input("password");
        $persistent = get_input("persistent", false);    	
        /*
         * MOD START by Snow
         */
    	if (!empty($id) && !empty($password)) {
    		/**
    		 * detect and order login methods
    		 */
        	$methodorder = detect_login_method($id);
        	/**
        	 * now,try every method to login the user
        	 */
        	$result = false;
        	foreach ($methodorder as $method) {
        		switch ($method) {
        			case 'username':
        				$username = $id;
        			break;
        			
        			case 'email':
	        			$r = get_user_by_email($id);
	        			$user = $r[0];
	        			$username = $user->username;
        			break;
        			
        			default:
        				$user = get_user_by_meta($method,$id);
        				$username = $user->username;
        			break;
        		}
        		
        		if ($user = authenticate($username,$password)) {
	        		$result = login($user, $persistent);
	        	}
	        	
	        	if ($result) {
	        		break;
	        	}
        	}
        }
        /*
         * MOD END by Snow
         */
       
    // Set the system_message as appropriate
        
        if ($result) {
            system_message(elgg_echo('loginok'));
            if ($_SESSION['last_forward_from'])
            {
            	$forward_url = $_SESSION['last_forward_from'];
            	$_SESSION['last_forward_from'] = "";
            	forward($forward_url);
            }
            else
            {
            	if (
            		(isadminloggedin()) &&
            		(!datalist_get('first_admin_login'))
            	) 
            	{
            		system_message(elgg_echo('firstadminlogininstructions'));
            		
            		datalist_set('first_admin_login', time());
            		
            		forward('pg/admin/plugins');
            	} else	
            		forward("pg/dashboard/");
            }
        } else {
        	$error_msg = elgg_echo('loginerror');
        	// figure out why the login failed
        	if (!empty($username) && !empty($password)) {
        		// See if it exists and is disabled
				$access_status = access_get_show_hidden_status();
				access_show_hidden_entities(true);
        		if (($user = get_user_by_username($username)) && !$user->validated) {
        			// give plugins a chance to respond
        			if (!trigger_plugin_hook('unvalidated_login_attempt','user',array('entity'=>$user))) {
        				// if plugins have not registered an action, the default action is to
        				// trigger the validation event again and assume that the validation
        				// event will display an appropriate message
						trigger_elgg_event('validate', 'user', $user);
        			}
        		} else {
        			 register_error(elgg_echo('loginerror'));
        		}
        		access_show_hidden_entities($access_status);
        	} else {
            	register_error(elgg_echo('loginerror'));
        	}
        }
      
?>