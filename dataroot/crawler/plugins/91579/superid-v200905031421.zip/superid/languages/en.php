<?php
	/**
	 * superid language file
	 *
	 * @package superid
	 * @author snow@firebloom.cc
	 * @copyright FireBloom Studio 2009
	 * @link http://firebloom.cc
	 */

	$english = array(
		'superid:id_tip' => 'QQ,email,website,mobile or username',
		'superid:id' => 'Login ID',		
	);

	add_translation("en",$english);
?>