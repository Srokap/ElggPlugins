<?php
	/**
	 * superid language file
	 *
	 * @package superid
	 * @author snow@firebloom.cc
	 * @copyright FireBloom Studio 2009
	 * @link http://firebloom.cc
	 */

	$chinese = array(
		'superid:id_tip' => '输入QQ,手机,电子邮箱地址,甚至你的博客地址都可以哦',
		'superid:id' => '登录帐号',		
	);

	add_translation("zh",$chinese);
?>