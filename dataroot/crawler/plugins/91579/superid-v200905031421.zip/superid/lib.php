<?php
	/**
	 * function lib for register and login with mobile
	 * 
	 * @package superid
	 * @author snow@firebloom.cc
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */
	
	/**
	 * Return a list of users who own the given metadata.
	 * 
	 * @param string $meta_name	 
	 * @param string $meta_value
	 * 
	 * @return user.null when not found.
	 */
	function get_user_by_meta($meta_name,$meta_value)
	{
		global $is_admin;
		$is_she_or_him_really_admin = $is_admin;
		$is_admin = TRUE;
		$result = get_entities_from_metadata($meta_name, $meta_value,'user');
		$is_admin = $is_she_or_him_really_admin;
		
		if ($result) {
			if ( sizeof($result) > 1) {
				throw new BusinessLogicException(elgg_echo('BusinessLogicException:unique_meta_duple'));
			}
			return $result[0];				
		}else {
			return FALSE;
		}
	}
	
	/**
	 * determin login id is a email,url,mobile or something else
	 * 
	 * @param string $id
	 * @return array contains login meta names in order
	 */	
	function detect_login_method($id){
		$methodorder = trigger_plugin_hook('superid:detect_method','user',$id,FALSE);
		
		if (!$methodorder) {
			if (is_numeric($id)) {
				$methodorder = array('mobile','username');
			}else{
				$methodorder = array('username');
			}
			
			global $CONFIG;
			$methodorder = array_unique(array_merge($methodorder,$CONFIG->superids));
		}

		return $methodorder;
	}
?>