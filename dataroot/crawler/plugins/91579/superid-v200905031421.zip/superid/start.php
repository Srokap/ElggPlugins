<?php
	/*
	 * use some metadata to identify an user besides of username
	 * email,mobile and qq are supported for now
	 *
	 * @package superid
	 */
	/*
	 * @author Snow.Hellsing <snow@g7life.com>
	 * @copyright FireBloom Studio
	 * @link http://firebloom.cc
	 */

	function superid_init() {
		global $CONFIG;
		
		require_once(dirname(__FILE__).'/lib.php');
		
		//setup all fields use for id here
		$CONFIG->superids = trigger_plugin_hook('superid:conf','profile',null,array('username','email','mobile','website'));
	}
    
    register_elgg_event_handler("init","system","superid_init",900);
	register_action("superid/login",true,dirname(__FILE__)."/actions/login.php");
?>