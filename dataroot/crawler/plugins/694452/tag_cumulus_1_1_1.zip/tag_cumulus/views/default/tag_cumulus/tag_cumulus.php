<?php
	$context = get_context();
   if(($context != 'admin') && ($context != 'shops') && ($context != 'event_calendar')&& ($context != 'messages')&& ($context != 'friends')&& ($context != 'settings')&& ($context != 'thewire')&& ($context != 'search')&& ($context != 'messageboard')&& ($context != 'walltowall')&& ($context != 'bookmarklets')){
	$page_owner = page_owner_entity();
	if ($page_owner instanceof ElggGroup){
	$owner = $page_owner->guid;
	$is_group = 'yes';
	}
	else
	{
	$owner = '';
	}

	if (($context != 'groups') && ($context != 'profile') && ($context != 'dashboard')){
	$subtype = $context;
	}
	else
	{
		$subtype = '';
	}

	switch ($subtype) {
    	case 'pages':
        	$subtype = 'page_top';
        	break;
    	case 'videos':
        	$subtype = 'izap_videos';
        	break;
	case 'photos':
		$subtype = 'image';
		break;
    	default: break;
	}



    	echo '<div id="tag_cumulus_container">';// . elgg_view_title('tags');
// 	echo 'subtype = ' . $sub_type;
// 	echo '<br/>entity subtype = ' . $vars['entity_subtype'];
// 	var_dump($vars);
// 	echo '<br/>context = ' . $context;
    	$tag_cumulus = display_tag_cumulus(0,50,'tags','object', $subtype, $owner,'', '', $context, $is_group) . '</div>';
	if ($tag_cumulus != FALSE)
	  echo $tag_cumulus;
   }
?>
