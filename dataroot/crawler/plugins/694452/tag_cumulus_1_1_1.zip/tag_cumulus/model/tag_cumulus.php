<?php
	
	/**
	 * Tag Cumulus
	 * 
	 * @package tag_cumulus
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Pedro Prez
	 * @copyright 2009
	 * @link http://www.pedroprez.com.ar/
 	*/

	function display_tag_cumulus($threshold = 1, $limit = 10, $metadata_name = "", $entity_type = "object", $subtype = "", $owner_guid = "", $site_guid = -1, $width, $context, $is_group) {

	
	if ($context){
	switch ($context) {
    	case 'pages':
        	$header_focus .= 'page';
        	break;
    	case 'videos':
        	$header_focus = 'video';
        	break;
	case 'photos':
		$header_focus = 'photo';
		break;
    	case 'groups':
        	$header_focus = 'group';
        	break;
    	case 'file':
        	$header_focus = 'file';
        	break;
	case 'event_calendar':
		$header_focus = 'event';
		break;
    	case 'blog':
        	$header_focus = 'blog';
        	break;
	case 'bookmarks':
		$header_focus = 'bookmark';
		break;
    	default:$header_focus = elgg_echo('tag_cumulus:all'); 
		break;
	}
		
	}

	if ($is_group == 'yes'){
		$header = elgg_echo('groups:group') . ' ';
		if ($context != 'groups'){
			$header .= $header_focus;
		}
		$header .= ' ' .elgg_echo('tag_cumulus:tags');
	}
	else 
	{
		if ($context != ''){
		$header = $header_focus;
		$header .= ' ' .elgg_echo('tag_cumulus:tags');
		}
	}
	
		if ($header != ''){
		$tag_view = "<h3 style='padding-left: 14px;'>" . $header . "</h3>";
		}
		$tags = get_tags($threshold, $limit, $metadata_name, $entity_type, $subtype, $owner_guid, $site_guid);
		if ($tags)
		{
		
		$tag_view .= elgg_view("output/tagcumulus",array('value' => get_tags($threshold, $limit, $metadata_name, $entity_type, $subtype, $owner_guid, $site_guid),'object' => $entity_type, 'subtype' => $subtype, 'width' => $width));
		return $tag_view;}
		else
		{			
		return FALSE;
		}
	}
?>
