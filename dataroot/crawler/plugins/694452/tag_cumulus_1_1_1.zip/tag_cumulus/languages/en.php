<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'tag_cumulus:all' => "All",
			'tag_cumulus:tags' => "Tags"
		   
	);
					
	add_translation("en",$english);

?>