<?php
	/**
	* likes
	*
	* @author likes
	* @link http://community.elgg.org/pg/profile/pedroprez
	* @copyright (c) Keetup 2010
	* @link http://www.keetup.com/
	* @license GNU General Public License (GPL) version 2
	/**
	 * Polish lang to LIKES plugin by Rogal
	 */
	$polish = array(
			'likes:admin' => 'Łatka Lubie- Ustawienia ',
			'likes:admin:subtitle' => 'Czy chcesz pokazać przycisk "Dobre" dla modułów...',
			
			'like:show:thewire' => 'wire w aktywności?',
			'like:show:messageboard' => 'messageboard w aktywności?',
			'like:show:bookmarks' => 'bookmarks waktywności?',
			'like:show:blog' => 'blog w aktywności?',
			'like:show:file' => 'file w aktywności?',
			'like:show:page' => 'page won aktywności?',
			'like:show:topic' => 'temat dyskusji w aktywności?',
			
			'like' => 'Dobre',
			'unlike' => 'zmień',
	
			'like:youlikethis' => 'Przykleiłeś łatkę Dobre.',
			'like:otherlikesthis' => '%s przykleiło łatkę Dobre.',
	
			'like:otherandyoulikethis' => 'Ty oraz  %s  zaznaczyliście ten wpis jako dobre.',
			'like:others2likethis' => '%s oraz %s zaznaczyło jako Dobre.',
	
			'like:others' => '%s innych',
	
			'like:lotofpeoplelikethis' => '%s użytkowników  zaznaczyło jako dobre.',
			'like:youandalotofpeoplelikethis' => 'Ty oraz %s zaznaczyliście jako Dobre.',
	
			/*Actions*/
			'like:posted' => 'Twoja łatka  "Dobre" przyklejona.',
			'like:failure' => 'Wystąpił nieoczekiwany błąd w czasie oznaczania jako "Dobry wpis". Może później.',

			'like:deleted' => 'Twoja łatka "Dobra zawartość" została usunięta.',
			'like:notdeleted' => 'Przepraszamy nie moglismy usunąc łatki "Dobre".',
	
	);
					
	add_translation("pl",$polish);
?>