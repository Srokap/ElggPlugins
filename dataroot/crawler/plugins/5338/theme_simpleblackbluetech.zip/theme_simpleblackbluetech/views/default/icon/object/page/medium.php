<?php
	echo $vars['url'] . "mod/theme_simpleblackbluetech/graphics/file_icons/pages_lrg.gif";
?>