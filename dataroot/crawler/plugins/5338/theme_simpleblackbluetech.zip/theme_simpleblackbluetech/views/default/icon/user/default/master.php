<?php
	echo $vars['url'] . "mod/theme_simpleblackbluetech/graphics/user_icons/defaultmaster.gif";
?>