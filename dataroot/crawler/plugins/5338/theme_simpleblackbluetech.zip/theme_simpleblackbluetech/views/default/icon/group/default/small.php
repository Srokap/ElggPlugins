<?php
	echo $vars['url'] . "mod/theme_simpleblackbluetech/graphics/group_icons/defaultsmall.gif";
?>