<?php

    /**
     * SimpleBlackBlueTech theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function simpleblackbluetech_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','simpleblackbluetech_init');
	
?>