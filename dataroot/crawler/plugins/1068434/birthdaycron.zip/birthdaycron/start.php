<?php

date_default_timezone_set('UTC');

elgg_register_event_handler('init', 'system', 'birthday_init');

function birthday_init() {
    elgg_register_plugin_hook_handler('cron', 'fiveminute','birthday_bday_mailer');
}
function birthday_bday_mailer($hook, $entity_type, $returnvalue, $params){
$bday = elgg_get_plugin_setting('birth_day', 'river_activity_3C');

    $from = 'deepan.palaniappan@treeshore.com';

            $options = array(
            'metadata_names' => $bday,
            'types' => 'user',
    'limit' => false,
    'full_view' => false,
    'pagination' => false,
    'list_type' => 'gallery',
    'gallery_class' => 'elgg-gallery-users',
                        );
            $options1 = array(
            'metadata_names' => $bday,
            'types' => 'user',
    'limit' => false,
    'full_view' => false,
    'pagination' => false,
    'list_type' => 'gallery',
    'gallery_class' => 'elgg-gallery-users',
                        );
                      $siteurl=elgg_get_site_url();
        $bd_users = elgg_get_entities_from_metadata($options);
        $wusers = elgg_get_entities_from_metadata($options1);
       
        $bd_today = date('m/d');
        $sitename="RMDAlumni";
        $siteaddress="http://experimentsite.in/rmdalumini";
       
        foreach ($bd_users as $bd_user){
            $bd_name = $bd_user->name;
            $bd_email = $bd_user->email;
            $bd = $bd_user->$bday;
            $bd_day = date('m/d',strtotime($bd));
            $bd_mobile="mobile";
            $bd_phone="phone";
            
           if($bd_mobile=="")
           {
           $bd_contactno=$bd_phone;
           }elseif($bd_phone=="")
           {
           $bd_contactno=$bd_mobile;
           }
           else
           {
           $bd_contactno="Not mentioned any contact no";
           }
           
        if ($bd_day == $bd_today){
           //$message = sprintf(elgg_echo('Today yours friend Birthday'),$bd_name,$bd_day, $sitename, $siteaddress);          
            elgg_send_email($from, $bd_email, elgg_echo('Birthday wishes from RMDALUMNI site'),"Wish you many more happy returns of the Day"); 
             
            foreach($wusers as $rec_user)
            {
            $rec_email = $rec_user->email;
            if(check_entity_relationship($bd_user->guid,'friend',$rec_user->guid))
            {
            $mess = "Today your friend`s Birthday,\n".$bd_user->name."\n"."Make a wish : in email"."\n".$bd_user->email."\n Mobile/phone:".$bd_contactno."\n"."siteaddress:". $siteurl;
            elgg_send_email($from,$rec_email,elgg_echo('Birthday Remainder from RMDALUMNI site'),$mess);
            }
            }
        }
    }
    return true;
}
?>