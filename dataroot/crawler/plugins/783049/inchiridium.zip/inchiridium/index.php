<?php
if (isloggedin()) forward('pg/dashboard/');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My Network</title>
		<meta charset="UTF-8" />
        <meta name="description" content="Sliding Background Image Menu with jQuery" />
        <meta name="keywords" content="jquery, background image, image, menu, navigation, panels" />
		<meta name="author" content="" />
        <link rel="stylesheet" type="text/css" href="mod/inchiridium/css/style.css" />
		<link rel="stylesheet" type="text/css" href="mod/inchiridium/css/sbimenu.css" />
		<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow' rel='stylesheet' type='text/css' />
		<link href='http://fonts.googleapis.com/css?family=News+Cycle&v1' rel='stylesheet' type='text/css' />

    </head>
	
	
	
<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
	
    <body>
		<div class="container">
			<div class="header">
				<h1 style="font-size:30px; font-weight: bold; color: black;">My Network</h1>
				
			</div>
			<div class="content">
				<div id="sbi_container" class="sbi_container">
					<div class="sbi_panel" data-bg="mod/inchiridium/images/8.jpg">
						<a href="#" class="sbi_label">Newest Members!</a>
						<div class="sbi_content">
							<ul>
								<li><?php
$users_max = 10;
        $onlyWithAvatar = "no";
if(empty($onlyWithAvatar) || $onlyWithAvatar == "no")
  {$users = get_entities('user','',null,null,$users_max,0);} 
else 
  {$users = get_entities_from_metadata('icontime', '', 'user', '', 0, $users_max);}
           $wallIconSize = "small";
shuffle($users);
foreach($users as $user){

echo elgg_view("profile/icon",array('entity' => $user, 'size' => 'small', 'override' => 'true'));

} ?> &nbsp;</li>
							</ul>
						</div>
					</div>
					<div class="sbi_panel" data-bg="mod/inchiridium/images/7.jpg">
						<a href="#" class="sbi_label">Login</a>
						<div class="sbi_content">
							<ul>							<li></li>

								<li><?php
									$form_body = 
									"
										<p>
										<label style='color: white; font-size:17px; font-weight:bold;'>"
										.elgg_echo('username')
										."<br />"
										.elgg_view
										(
											'input/text'
											,array
											(
												'internalname' => 'username'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										"<label style='color: white; font-size:17px; font-weight:bold;'>"
										.elgg_echo('password')
										."<br />" 
										.elgg_view
										(
											'input/password'
											,array
											(
												'internalname' => 'password'
												,'class' => 'login-textarea'
											)
										)
										."</label><br /><br />
									";
									$form_body .=
										elgg_view
										(
											 'input/submit'
											,array
											(
												'value' => elgg_echo('login')
											)
										)
										."</p>
									";
									echo elgg_view
									(
										'input/form'
										,array
										(
											 'body' => $form_body
											,'action' => ""
											.$vars['url']
											."action/login"
										)
									);
									?> &nbsp; </li>
							</ul>
						</div>
					</div>
					<div class="sbi_panel" data-bg="mod/inchiridium/images/6.jpg">
						<a href="#" class="sbi_label">Register</a>
						<div class="sbi_content">
							<ul>
							<li></li>
								<li><?php
								
								$form_body  = "<p><label style='color: white; font-size:17px; font-weight:bold;'>" . elgg_echo('name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
								$form_body .= "<label style='color: white; font-size:17px; font-weight:bold;'>" . elgg_echo('email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
								$form_body .= "<label style='color: white; font-size:17px; font-weight:bold;'>" . elgg_echo('username') . "<br />" . elgg_view('input/text' , array('internalname' => 'username', 'class' => "general-textarea", 'value' => $username)) . "</label><br />";
								$form_body .= "<label style='color: white; font-size:17px; font-weight:bold;'>" . elgg_echo('password') . "<br />" . elgg_view('input/password' , array('internalname' => 'password', 'class' => "general-textarea")) . "</label><br />";
								$form_body .= "<label style='color: white; font-size:17px; font-weight:bold;'>" . elgg_echo('passwordagain') . "<br />" . elgg_view('input/password' , array('internalname' => 'password2', 'class' => "general-textarea")) . "</label><br /><br />";
								$form_body .= elgg_view('register/extend');
								$form_body .= elgg_view('input/captcha');
								if ($admin_option) {
									$form_body .= elgg_view('input/checkboxes', array('internalname' => "admin", 'options' => array(elgg_echo('admin_option'))));
								}
								$form_body .= elgg_view('input/hidden', array('internalname' => 'friend_guid', 'value' => $vars['friend_guid']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'invitecode', 'value' => $vars['invitecode']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'register'));
								$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('register'))) . "</p>";
								?>
								
								<?php
								
								echo elgg_view
								(
									'input/form'
									,array
									(
										'body' => $form_body
										,'action' => "{$vars['url']}action/register"
									)
								);
								?></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<p> &nbsp; </p><p> &nbsp; </p>
			<div class="more">
				<center><ul>
					
					<li><a href="#">About</a></li>
					<li><a href="#">Privacy</a></li>
					<li><a href="#">Terms of Use</a></li>
					<li><a href="#">Register</a></li>
					
					
				</ul></center>
			</div>
			
		</div>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
		<script type="text/javascript" src="mod/inchiridium/js/jquery.easing.1.3.js"></script>
		<script type="text/javascript" src="mod/inchiridium/js/jquery.bgImageMenu.js"></script>
		<script type="text/javascript">
			$(function() {
				$('#sbi_container').bgImageMenu({
					defaultBg	: 'mod/inchiridium/images/2.jpg',
					menuSpeed	: 300,
					type		: {
						mode		: 'seqFade',
						speed		: 250,
						easing		: 'jswing',
						seqfactor	: 100
					}
				});
			});
		</script><script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
	
	

    </body>
	
	
</html>