<?php
/**
 * Elgg search listing: gallery view
 *
 * DEPRECATED VIEW: use entities/gallery_listing instead
 *
 * @package Elgg
 * @subpackage Core
 
 */


    echo elgg_view('entities/gallery_listing', $vars);

?>