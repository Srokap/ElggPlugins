<?php

	global $CONFIG;
	
	$form_body = "<p class=\"loginbox\"><label>" . elgg_view('input/text', array('value' => 'username', 'internalname' => 'username', 'class' => 'login-textarea', 'js' => 'onclick="javascript:clearContent(this);"')) . "</label>";
	$form_body .= "<label>" . elgg_view('input/password', array('value' => 'password', 'internalname' => 'password', 'class' => 'login-textarea', 'js' => 'onclick="javascript:clearContent(this);"')) . "</label>".elgg_view('input/submit', array('value' => elgg_echo('login'))) . "<br /><br />";
	$form_body .= "<div id=\"persistent_login\"><label><input type=\"checkbox\" name=\"persistent\" value=\"true\" />".elgg_echo('user:persistent')."</label> <br /><br /> ";
	$form_body .= (!isset($CONFIG->disable_registration) || !($CONFIG->disable_registration)) ? "<a href=\"{$vars['url']}account/register.php\">" . elgg_echo('register') . "</a> | " : "";
	$form_body .= "<a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></p></div>";  
	
	//<input name=\"username\" type=\"text\" class="general-textarea" /></label>
	
	$login_url = $vars['url'];
	if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
		$login_url = str_replace("http", "https", $vars['url']);
?>
	<script type="text/javascript">
		function clearContent(elem){
			elem.value="";
		}
	</script>	
	<div id="loginbox">
		<?php 
			echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$login_url}action/login"));
		?>
		
	</div>
