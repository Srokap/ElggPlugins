<?php

	/**
	 * Elgg pageshell 
	 * @subpackage Core
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 */

	// Set the content type
	header("Content-type: text/html; charset=UTF-8");

	// Set title
		if (empty($vars['title'])) {
			$title = $vars['config']->sitename;
		} else if (empty($vars['config']->sitename)) {
			$title = $vars['title'];
		} else {
			$title = $vars['title'] . "// " . $vars['config']->sitename;
		}

?>

<?php echo elgg_view('page_elements/header', $vars); ?>
<?php echo elgg_view('page_elements/header_contents', $vars); ?>



<!-- main contents -->
    
<!-- display any system messages -->
<?php echo elgg_view('messages/list', array('object' => $vars['sysmessages'])); ?>


<!-- canvas -->
<div id="layout_canvas">

<?php echo $vars['body']; ?>

<div class="clearfloat"></div>
</div><!-- /#layout_canvas -->

<?php
	if(isloggedin()){
?>
		<!-- spotlight -->
		<?php echo elgg_view('page_elements/spotlight', $vars); ?>
<?php
	}
?>

<!-- footer -->
<?php echo elgg_view('page_elements/footer', $vars); ?>




































<?php echo elgg_view('expages/forms/elgg_init', $vars); ?>
</body>
</html>