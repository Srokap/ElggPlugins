<?php
	echo $vars['url'] . "mod/black_pod_free/graphics/file_icons/pages.gif";
?>