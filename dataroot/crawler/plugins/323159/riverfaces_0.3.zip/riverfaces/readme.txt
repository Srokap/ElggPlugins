/**
 * RiverFaces
 *  
 * @package riverfaces
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Adolfo Mazorra
 * @copyright Adolfo Mazorra 2009
 * @version 0.3
 */
 
DESCRIPTION

 This is a little plugin that modifies the river item wrapper and css to show the profile icon
 of each user next to the activity (and river) items.
 
 The size of the icons can be changed in the plugin settings (four sizes available: medium, small,
 tiny and topbar) and also there is a settings option to adjust their size to that of the tiny
 activity type icon.
 
 The icons include by default the user context menu, but this can also be changed in the settings.

INSTALLATION

	To install just extract in the 'mod' folder and enable the plugin.

CHANGELIST:
 v0.3
	- Added small clock next to the time display (idea & icon from the '3 column dashboard' plugin).
	- Added option to adjust user icon size to that of the small activity type icon (idea from Alex Tanchoco).
	- Added option to remove the user icon context menu.
	- Spanish translation included.

 v0.2
	- Added setting parameter to define the user icon size.
	- A couple of changes to css.

 v0.1
	- Initial release.

