<?php
	/**
	 * Widgetlinks Settings Edit
	 * 
	 * @package widgetlinks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Adolfo Mazorra
	 * @copyright Adolfo Mazorra 2009
	 */
?>

<table>
	<tr>
	<td>
		<?php echo elgg_echo('riverfaces:settings:iconsize'); ?>&nbsp;
	</td>
	<td>
		<?php
			$iconsize = $vars['entity']->iconsize;
			if (!isset($iconsize) or $iconsize == '')
				$iconsize = 'small';
		?>
		<select name="params[iconsize]">
			<option value="medium" <?php if ($iconsize == 'medium') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('riverfaces:settings:iconsize:medium'); ?></option>
			<option value="small" <?php if ($iconsize == 'small') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('riverfaces:settings:iconsize:small'); ?></option>
			<option value="tiny" <?php if ($iconsize == 'tiny') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('riverfaces:settings:iconsize:tiny'); ?></option>
			<option value="topbar" <?php if ($iconsize == 'topbar') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('riverfaces:settings:iconsize:topbar'); ?></option>
		</select>
	</td>
	</tr>
	<tr>
	<td>
		<?php echo elgg_echo('riverfaces:settings:adjustsize'); ?>&nbsp;
	</td>
	<td>
		<select name="params[adjustsize]">
			<option value="yes" <?php if ($vars['entity']->adjustsize == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->adjustsize != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
	</td>
	</tr>
	<tr>
	<td>
		<?php echo elgg_echo('riverfaces:settings:showcontextmenu'); ?>&nbsp;
	</td>
	<td>
		<select name="params[showContextMenu]">
			<option value="yes" <?php if ($vars['entity']->showContextMenu != 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
			<option value="no" <?php if ($vars['entity']->showContextMenu == 'no') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
		</select>
	</td>
	</tr>	
</table>
