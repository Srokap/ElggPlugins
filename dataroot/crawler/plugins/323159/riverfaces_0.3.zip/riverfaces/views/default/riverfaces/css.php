<?php
	/**
	 * RiverFaces CSS
	 * 
	 * @package riverfaces
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Adolfo Mazorra
	 * @copyright Adolfo Mazorra 2009
	 */
?>

.river_item p {
	margin:0;
	padding:0 0 0 21px;
	line-height:1.1em;
	min-height:17px;
}
.river_item {
	border-bottom:1px solid #dddddd;
	padding:5px 0 5px 0;
	margin: 0px 0px 5px 5px;	
}
.river_item_padding_medium {
	margin-left: 105px;
	min-height: 100px;
}
.river_item_padding_small {
	margin-left: 45px;
	min-height: 40px;
}
.river_item_padding_tiny {
	margin-left: 30px;
	min-height: 25px;
}
.river_item_padding_topbar {
	margin-left: 25px;
	min-height: 20px;
}
.river_item_icon_float {
	float:left;
	margin:0px 4px;
}
.adjusted_user_icon_size img {
	width: 18px;
	height: 18px;
}
.river_item_time {
	display:block;
	font-size:90%;
	color:#666666;
}
