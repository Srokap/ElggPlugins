<?php

	/**
	 * Elgg river item wrapper.
	 * Wraps all river items.
	 * 
	 * @package Elgg
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider (modified by Adolfo Mazorra)
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$size = get_plugin_setting('iconsize', 'riverfaces');
	if (!isset($size) or $size == '')
		$size = 'small';
		
	$adjustSize = get_plugin_setting('adjustsize', 'riverfaces');
	if ($adjustSize != 'yes') {
		$img_size = '';
		$padding_size = $size;
	}	else {
		$img_size = " adjusted_user_icon_size";
		$padding_size = 'topbar';			
	}
	
	$showContextMenu = get_plugin_setting('showContextMenu', 'riverfaces');
	$override = false;
	if ($showContextMenu == 'no') {
		$override = true;
	}
	
	$user = get_entity($vars['item']->subject_guid);
?>	
	<div class="river_item">
		<div class="river_item_icon_float<?php echo $img_size;?>">
			<?php				
				if ($override) {
					$link_begin = '<a href="' . $user->getURL() . '" title="' . $user->name . '">';
					$link_end = '</a>';
				}
				echo $link_begin . elgg_view("profile/icon", array('entity' => $user,'size' => $size, 'override' => $override)) . $link_end;　
			?>
		</div>	
		<div class="river_item_padding_<?php echo $padding_size; ?>">	
			<div class="river_<?php echo $vars['item']->type; ?>">
				<div class="river_<?php echo $vars['item']->subtype; ?>">
					<div class="river_<?php echo $vars['item']->action_type; ?>">
						<div class="river_<?php echo $vars['item']->type; ?>_<?php if($vars['item']->subtype) echo $vars['item']->subtype . "_"; ?><?php echo $vars['item']->action_type; ?>">
						<p>
							<?php		
									echo $vars['body'];				
							?>
							<span class="river_item_time">
								<img src="<?php echo $vars['url']; ?>mod/riverfaces/graphics/clock_icon.gif" width="11px" height="11px" />
								<?php	echo friendly_time($vars['item']->posted); ?>
							</span>
						</p>
						</div>
					</div>				
				</div>
			</div>
		</div>
	</div>
	<div class="clearfloat"></div>