<?php

$spanish = array(
  'riverfaces:settings:iconsize' => 'Tamaño del icono de usuario?',
  'riverfaces:settings:iconsize:medium' => 'Mediano',	
  'riverfaces:settings:iconsize:small' => 'Pequeño',	
  'riverfaces:settings:iconsize:tiny' => 'Diminuto',	
  'riverfaces:settings:iconsize:topbar' => 'Topbar',
  
  'riverfaces:settings:adjustsize' => 'Ajustar el tamaño de icono mostrado?',
  
  'riverfaces:settings:showcontextmenu' => 'Mostrar el menu de usuario en el icono?',
);

add_translation('es', $spanish); 

?>