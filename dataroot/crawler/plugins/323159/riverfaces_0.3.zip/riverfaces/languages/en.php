<?php
$english = array(

  'riverfaces:settings:iconsize' => 'User Icon size?',
  'riverfaces:settings:iconsize:medium' => 'Medium',	
  'riverfaces:settings:iconsize:small' => 'Small',	
  'riverfaces:settings:iconsize:tiny' => 'Tiny',	
  'riverfaces:settings:iconsize:topbar' => 'Topbar',
  
  'riverfaces:settings:adjustsize' => 'Adjust icon display size?',
  
  'riverfaces:settings:showcontextmenu' => 'Show user icon context menu?',
);

add_translation("en",$english);
?>