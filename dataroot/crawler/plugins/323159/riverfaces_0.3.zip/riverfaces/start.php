<?php

	/**
	 * RiverFaces
	 *  
	 * @package riverfaces
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Adolfo Mazorra
	 * @copyright Adolfo Mazorra 2009
	 */

		function riverfaces_init() {
			extend_view('css','riverfaces/css');			
		}
		
		register_elgg_event_handler('init','system','riverfaces_init');

?>