<?php
/*
 * © Copyright by Laboratorio de Redes 2009–2010
 */

function jquerycalendar_init() {
    /* This javascript can be loaded at the end */
    extend_view('footer/analytics', 'jquerycalendar/footer');

    extend_view('css', 'jquerycalendar/css');
}

register_elgg_event_handler('init', 'system', 'jquerycalendar_init');


?>
