<?php
/*
 * © Copyright by Laboratorio de Redes 2010
 */

$galician = array(
    'jquerycalendar:dateformat' => 'dd/mm/yy',
    'jquerycalendar:locale' => 'gl',
);


add_translation('gl', $galician);
?>
