<?php
/*
 * © Copyright by Laboratorio de Redes 2010
 */

$spanish = array(
    'jquerycalendar:dateformat' => 'dd/mm/yy',
    'jquerycalendar:locale' => 'es',
);


add_translation('es', $spanish);
?>
