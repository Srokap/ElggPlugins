<?php
/*
 * © Copyright by Laboratorio de Redes 2010
 */

$english = array(
    'jquerycalendar:dateformat' => 'mm/dd/yy',
    'jquerycalendar:locale' => '',
);


add_translation('en', $english);
?>
