<?php
/*
 * © Copyright by Laboratorio de Redes 2010
 */
?>
<div class="input-text">
    <?php

    $js = 'class="jquerydatepicker_field"';

    if ($vars['js']) {
        $vars['js'] .= $js;
    } else
        $vars['js'] = $js;

    echo elgg_view('input/text', $vars);

    ?>
</div>