<?php
/*
 * © Copyright by Laboratorio de Redes 2010
 */

echo file_get_contents(dirname(dirname(dirname(dirname(__FILE__)))) . '/vendors/jquery.datepick-3.7.5/jquery.datepick.css');

?>
