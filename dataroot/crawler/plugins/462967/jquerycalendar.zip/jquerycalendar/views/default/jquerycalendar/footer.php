<?php
/*
 * © Copyright by Laboratorio de Redes 2010
*/

global $CONFIG;

?>
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot; ?>/mod/jquerycalendar/vendors/jquery.datepick-3.7.5/jquery.datepick.pack.js"></script>
<?php
if (elgg_echo('jquerycalendar:locale') != '') {
    ?>
<script type="text/javascript" src="<?php echo $CONFIG->wwwroot; ?>/mod/jquerycalendar/vendors/jquery.datepick-3.7.5/jquery.datepick-<?php echo elgg_echo('jquerycalendar:locale'); ?>.js"></script>
    <?php
}
?>
<script type="text/javascript">
    $(".jquerydatepicker_field").datepick({
        dateFormat: '<?php echo elgg_echo('jquerycalendar:dateformat'); ?>',
        alignment: 'bottomRight',
        mandatory: true
    });
</script>