<?php

function activemembers_init() {
  // Load system configuration
  global $CONFIG;
  
  // Load the language file
  register_translations($CONFIG->pluginspath . "activemembers/languages/");
  
  // Extend some view
  extend_view('css','activemembers/css');
  
  //add a widget
  add_widget_type('activemembers', elgg_echo("Most active members"), elgg_echo('activemembers:widget:description'));

  // Register for index page
  extend_view('index/activemembers', 'activemembers/indexview');
  }
  
register_elgg_event_handler('init','system','activemembers_init');

?>