<?php

function getActiveMembers() {
  $limit = 50;
  
  $entities1 = get_entities_from_metadata("tags", "", "", "", 0, $limit, 0);
  $entities2 = get_entities_from_annotations("", "", "", "", "", "", $limit, 0, "desc", false);
  $entities3 = get_entities("", "", 0, "time_created", $limit);
  
  $entities = array_merge($entities1, $entities2, $entities3);
  
  $allentities = array();
  $users = array();
  
  foreach ($entities as $entity) {
    // Ignoring users.. It is not activity
    if ($entity instanceof ElggUser) 
      continue;
    if (!in_array($entity, $allentities)) {
      array_push($allentities, $entity);
      if ($entity->owner_guid > 0)
	$users[$entity->owner_guid]++;
    }
  }
  arsort($users);
  return $users;
  }

?>