<?php

$english = array(
                 /**
                  * widget
                  */
		 'activemembers:widget:description' => "Show the most active members",
		 'activemembers:title' => "Active members",

		 );

add_translation("en",$english);

?>