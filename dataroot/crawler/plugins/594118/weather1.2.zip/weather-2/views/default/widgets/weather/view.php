<!-- some css for display -->
<style type="text/css">
    .weatherIcon { 
	float:left;
	padding: 5px;
        
     }
          
</style>
<?php

//Widget to show weather using Google weather API
//Author:J Croucher

function getWeather($loc, $tempFormat) {
	$requestAddress = "http://www.google.com/ig/api?weather=".urlencode($loc)."&hl=en&oe=utf-8";
	$xml_str = file_get_contents($requestAddress,0);
	
	// Parses XML 
	$xml = new SimplexmlElement($xml_str);
	// Loops XML
	$count = 0;
	echo '<div id="weather">';

	foreach($xml->weather as $item) {

		foreach($item->forecast_conditions as $new) {
			$lowVal = $new->low['data'];
			$hiVal = $new->high['data'];
			if($tempFormat == "Celsius")
			{
				$lowVal = round(($lowVal - 32) * 5/9);
				$hiVal = round(($hiVal - 32) * 5/9);
			}
			echo '<div class="weatherIcon">';
			echo $new->day_of_week['data'].'<br/>';
			echo '<img title="'.$new->condition['data'].'" src="http://www.google.com/' .$new->icon['data'] . '"/><br/>';
			echo 'L: '.$lowVal.'<br/>';
			echo 'H: '.$hiVal.'<br/>';
			echo '</div>';
		}
	}

	echo '</div>';
}
?>

<div class="contentWrapper">

<?php
	
	$loc = $vars['entity']->location;
	$tempFormat = $vars['entity']->tempFormat;
	echo $loc.'</br>';
	getWeather($loc, $tempFormat);

?>
<div style="clear:left;"></div>
</div>