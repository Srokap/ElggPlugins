<?php
  function weather_init() {        
    add_widget_type('weather', 'Weather', 'Widget to get the weather');
  }
 
  register_elgg_event_handler('init','system','weather_init');       
?>