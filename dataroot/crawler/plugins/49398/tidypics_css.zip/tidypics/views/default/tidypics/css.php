<?php
	/**
	 * tidypics CSS extender
	 */
?>
	/*  --- independent view for image/album SHARED --- */
	
#tidypics_title{
	font-size:1.2em;
	font-weight:bold;
	margin: 0 0 0 10px;
}
#tidypics_desc{
	padding:0 10px;
	font-style:italic;
	background: white;
	border: 1px solid #eeeeee;
	margin:10px;
	-moz-border-radius-bottomleft: 8px;
	-moz-border-radius-bottomright: 8px;
	-moz-border-radius-topleft: 8px;
	-moz-border-radius-topright: 8px;
}
#tidypics_info{
	padding:10px;
	line-height:1.5em;
	background: white;
	border: 1px solid #eeeeee;
	margin:10px;
	-moz-border-radius-bottomleft: 8px;
	-moz-border-radius-bottomright: 8px;
	-moz-border-radius-topleft: 8px;
	-moz-border-radius-topright: 8px;
}

#tidypics_controls{
	text-align:center;
	margin-bottom:10px;
}

#tidypics_controls a{
	margin:10px;
}

	/* independent album view only */
	
.album_images{
	float:left;
	width:160px; 
	height:160px;
	margin:10px;
	padding:10px;
	border:1px solid #eeeeee;	
	text-align:center;
	background: white;
	-moz-border-radius-bottomleft: 8px;
	-moz-border-radius-bottomright: 8px;
	-moz-border-radius-topleft: 8px;
	-moz-border-radius-topright: 8px;
}

	/* independent image view only */

#image_full{
	text-align:center;
	margin:10px;
	background: white;
	-moz-border-radius-bottomleft: 8px;
	-moz-border-radius-bottomright: 8px;
	-moz-border-radius-topleft: 8px;
	-moz-border-radius-topright: 8px;
}
#image_nav {
}
#image_full img{
	padding:5px;
	border:1px solid #eeeeee;
	margin:7px 0;
}

/*  --- albums gallery view --- */

.album_cover{
	padding:5px;
	border:1px solid #eeeeee;
	margin:8px;
}


/* ------ album WIDGET VIEW ------  */

#album_widget_container{
	text-align:center;
}

.album_widget_single_item{

}
.album_widget_title{

}
.album_widget_timestamp {
	color:#666666;
	margin:0;
}
.collapsable_box #album_widget_layout {
	margin:0;
}

/* ---------  image upload/edit forms  ------------   */

#image_upload_list li{
	margin:3px 0;
}
.edit_image_container{
	padding:5px;
	margin:5px 0;
	overflow:auto;
}
.edit_images{
	float:right;
	width:160px; 
	height:160px;
	margin:4px;
	padding:5px;
	border:1px solid #ccc;	
	text-align:center;
}
.image_info{
	float:left;
	width:60%;
}
.image_info label{
	font-size:1em;
}
.edit_image{
	float:right;
	border:1px solid #ccc; 
	width:153px; 
	height:153px;
}

/* ---------  tidypics river items ------------   */

.river_image_create {
	background: url(<?php echo $vars['url']; ?>mod/tidypics/graphics/icons/river_icon_image.gif) no-repeat left -1px;
}
.river_album_create {
	background: url(<?php echo $vars['url']; ?>mod/tidypics/graphics/icons/river_icon_album.gif) no-repeat left -1px;
}

.pagination {
	clear:both !important;
}
	