<?php

    /**
     * RedRounded theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function redrounded_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','redrounded_init');
	
?>