<?php
	echo $vars['url'] . "mod/theme_redrounded/graphics/user_icons/defaulttiny.gif";
?>