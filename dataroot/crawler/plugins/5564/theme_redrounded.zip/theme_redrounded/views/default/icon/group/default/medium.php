<?php
	echo $vars['url'] . "mod/theme_redrounded/graphics/group_icons/defaultmedium.gif";
?>