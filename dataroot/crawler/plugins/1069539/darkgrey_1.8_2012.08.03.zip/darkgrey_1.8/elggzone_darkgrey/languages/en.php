<?php

$english = array(

	// topbar
	'elggzone_darkgrey:guest'			=> 'Welcome Guest',
	'elggzone_darkgrey:guest:tooltip'	=> 'Go to registration',
	
	'elggzone_darkgrey:copyright' 		=> 'Elggzone &copy; 2010 - 2011',
	'elggzone_darkgrey:tooltip' 		=> 'Design by Elggzone',
		
);

add_translation("en", $english);
