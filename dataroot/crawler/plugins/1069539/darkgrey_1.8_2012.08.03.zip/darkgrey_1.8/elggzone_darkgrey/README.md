Darkgrey
========

Elggzone Darkgrey is a nice stylish Elgg template with a clean and modern design. Darkgrey has grained background and transparent boxes.

FEATURES:

- Fixed width
- Topbar on index page
- Support all default Elgg mods
- Tidypics support
- Modified icons
- Logo psd included
- W3C Validated
- Version Elgg 1.8

**Note!** This directory must be named 'elggzone_darkgrey' in your Elgg mod folder.