<?php
/**
 * User dashboard CSS
 */
?>

#dashboard-info {
	border:1px solid #59626D;
	margin-bottom: 15px;
}
