<?php

/**
 * elggzone_darkgrey css
 */

?>

/* ***************************************
	EXTRAS
*****************************************/

.topbar_line{
	/* Horizontal line: */
	height:1px;
    width:990px;
	background:#363B42;
	border-bottom:1px solid #6C7682;
	overflow:hidden;
	margin-top:32px;
	position:absolute;
}



