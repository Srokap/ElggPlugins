<?php
/**
 * The Wire CSS
 */

?>
/********************************
The Wire
*********************************/
#thewire-textarea {
	width:676px;
	height: 40px;
	padding: 6px;
}
#thewire-characters-remaining {
	text-align: right;
	float: right;
	color:#788A9A;
}
.thewire-characters-remaining {
	color:#788A9A;
	border:none;
	font-size: 100%;
	padding:0 2px 0 0;
	margin:0;
	text-align: right;
}
.thewire-parent {
	margin-left: 40px;
}
