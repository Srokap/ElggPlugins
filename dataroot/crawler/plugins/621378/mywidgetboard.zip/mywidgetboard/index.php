<?php

	/**
	 * Elgg MyWidgetBoard plugin
	 *
	 * @package ElggMyWidgetBoard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Untamed
	 * @copyright Untamed 2008-2010
	 */

	// Get the Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
		//Setup widgets area and display page
		$body = elgg_view_layout('widgets',$body);
		$title = elgg_echo("mywidgetboard");
		page_draw($title, $body);
		
?>