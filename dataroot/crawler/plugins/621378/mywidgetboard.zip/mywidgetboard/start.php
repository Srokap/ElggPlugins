<?php

	/**
	 * Elgg MyWidgetBoard plugin
	 *
	 * @package ElggMyWidgetBoard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Untamed
	 * @copyright Untamed 2008-2010
	 */

	/**
	 * My Widget Board init function; defines what to do when plugin is enabled
	 *
	 */
		function mywidgetboard_init() {

			// Get config
				global $CONFIG;

			// The following is disabled as we are not using multiple pages, just index.php
			// Register Page Handler	
			// register_page_handler('mywidgetboard','mywidgetboard_page_handler');
				
			// Add menu link
				add_menu(elgg_echo('mywidgetboard'), $CONFIG->wwwroot . "mod/mywidgetboard/index.php");

			// Define widgets for use in this context. All you need to do is use this code 
				use_widgets('mywidgetboard');
				
				}
				/*
				* The following is disabled as we are not using any pages other then index.php
					function mywidgetboard_page_handler($page)
						{
							global $CONFIG;
							switch ($page[0])
							{
								case 'index':
									include $CONFIG->pluginspath . 'mywidgetboard/index.php';
									break;	
							}
							return true;
						}
				*/
				
				//Startup stuff... links to mywidgetboard_init function
		register_elgg_event_handler('init', 'system', 'mywidgetboard_init');
?>