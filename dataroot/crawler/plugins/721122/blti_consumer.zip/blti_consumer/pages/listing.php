<?php

  // Load Elgg engine
  //require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
		
// must be logged in to see this page
gatekeeper();

// get a list of all apps
$apps = elgg_get_entities(array('types' => 'object', 'subtypes' => 'blti_consumer'));

// existing applications
$area2 = elgg_view_title(elgg_echo('blti_consumers'));
if ($apps) {
	//$text = elgg_echo('blti_consumer:register:desc');
		
	//$area2 .= elgg_view('page_elements/contentwrapper', array('body' => $text));
	$i=0;
	foreach ($apps as $app) {
		$app->set('type', 'blti_consumer');
		$apps[$i++] = $app;
	}
	$tokList = elgg_view_entity_list($apps, count($apps), 0, 0, true, true, false);
//	$tokList = lgg_view('page_elements/contentwrapper', array('body' => $apps));
	
	$area2 .= $tokList;
} else {
	$text = elgg_echo('blti_consumer:register:none');

	$area2 .= elgg_view('page_elements/contentwrapper', array('body' => $text));
}


			  
// format
$body = elgg_view_layout("two_column_left_sidebar", '', $area2);

// Draw page
page_draw(elgg_echo('blti_consumer:registered'), $body);

?>