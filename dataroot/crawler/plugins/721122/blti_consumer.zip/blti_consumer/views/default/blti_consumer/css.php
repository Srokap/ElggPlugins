<?php
/**
 * Elgg BLTI Consumer CSS
 */
?>

#blti_consumer_site_settings .text_input {
	width: 350px;
}

.blti_consumer_usersettings_desc {
	font-size: smaller;
}