<?php

	/**
	 * Elgg hoverover extender for blog
	 * 
	 * @package ElggConsumerBLTI
	 */

?>

	<p class="user_menu_blti_consumer">
		<a href="<?php echo $vars['url']; ?>pg/blti_consumer/owner/<?php echo $vars['entity']->username; ?>"><?php echo elgg_echo("blti_consumer"); ?></a>
	</p>