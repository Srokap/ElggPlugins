<?php
/**
* Kaltura video client
* @package ElggKalturaVideo
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
* @author Ivan Vergés - Ballo Microstudi SL <ivan@microstudi.net>
* @copyright Ballo Microstudi SL 2009
* @link http://microstudi.net/elgg/
**/


$spanish = array(
	
	'item:object:kaltura_video' => 'V&iacute;deos Kaltura',
	'kalturavideo:label:partner_id' => 'Partner ID',
	'kalturavideo:label:subp_id' => 'Sub-Partner ID',
	'kalturavideo:label:admin_secret' => 'Administrator Secret',
	'kalturavideo:label:secret' => 'Web Service Secret',
	'kalturavideo:title:video' => 'Viacute;deo de '.$CONFIG->sitename,
	'kalturavideo:descprefix:video' => 'Un v&iaucte;deo desde kaltura por',
	'kalturavideo:text:loginkaltura' => 'Puede conseguir los datos desde el lugar de kaltura:',
	'kalturavideo:text:buttoninfo' => '(Press the button "Account" -> "Informaci&oacute;n General")',
	'kalturavideo:text:signupkaltura' => 'Necesita ser un partner para entrar en sesi&oacute;n, puede darse de alta en su caso:',
	'kalturavideo:label:videotitle' => 'T&iacute;tulo de v&iacute;deo creado',
	'kalturavideo:label:addvideo' => 'A&ntilde;adir v&iacute;deos desde kaltura',
	'kalturavideo:label:uid_prefix' => 'Prefijo Kaltura',
	'kalturavideo:label:integratetinymce' => 'Intentar integrarlo con el plugin TinyMCE',
	
	'kalturavideo:error:misconfigured' => 'Error de autenticaci&oacute;n o falta de configuración en el plugin Kaltura!',
	'kalturavideo:error:notconfigured' => 'El plugín no ha sido configurado!',
	'kalturavideo:error:missingks' => 'Probablemente tiene un error en el "Administrator Secret" o "Web Service Secret".',
	'kalturavideo:error:partnerid' => 'Este error normalmente aparece si no es partner de kaltura. Por favor configure el plugin!',
	'kalturavideo:error:readme' => 'Por favor, configure el plugin!',
	
	'kalturavideo:label:closewindow' => 'Cerrar ventana',
	'kalturavideo:label:select_size' => 'Seleccione el tama&ntilde;o del player',
	'kalturavideo:label:large' => 'Grande',
	'kalturavideo:label:small' => 'Peque&ntilde;o',
	'kalturavideo:label:insert' => 'Inserte v&iacute;deo',
	'kalturavideo:label:edit' => 'Edite v&iacute;deo',
	'kalturavideo:label:edittitle' => 'Edite t&iacute;tulo del video',
	'kalturavideo:label:miniinsert' => 'Inserte',
	'kalturavideo:label:miniedit' => 'Edite',
	'kalturavideo:label:cancel' => 'Cancelar',
	'kalturavideo:label:publish' => 'Publicar',
	'kalturavideo:label:gallery' => 'Galer&iacute;a',
	'kalturavideo:label:next' => 'Siguiente',
	'kalturavideo:label:prev' => 'Anterior',
	'kalturavideo:label:start' => 'Inicio',
	'kalturavideo:label:newvideo' => 'Crear un nuevo v&iacute;deo',
	'kalturavideo:label:toolsadmin' => 'Administracion -> Herramientas de administraci&oacute;n(pulse "mas info")',
	'kalturavideo:label:gotoconfig' => 'Por favor configure adecuadamente Kaltura Video ',
	'kalturavideo:label:adminvideos' => 'V&iacute;deos de Kaltura',
	'kalturavideo:label:myvideos' => 'Mis v&iacute;deos',
	'kalturavideo:label:friendsvideos' => 'V&iacute;deos de las amigas',
	'kalturavideo:label:length' => 'Longitud:',
	'kalturavideo:label:plays' => 'Plays:',
	'kalturavideo:label:created' => 'Creados:',
	'kalturavideo:label:details' => 'Ver detalles',
	'kalturavideo:label:view' => 'View video',
	'kalturavideo:label:editdetails' => 'Editar detalles',
	'kalturavideo:label:delete' => 'Borrar video',
	'kalturavideo:prompt:delete' => 'Est&acute; seguro que borrar permanentemente este v&iacute;deo?',
	'kalturavideo:action:deleteok' => 'El v&iacute;deo con el id %ID% ha sido borrado.',
	'kalturavideo:action:deleteko' => 'El v&iacute;deo con el id %ID% no puede ser borado!',
	'kalturavideo:action:updatedok' => 'El v&iacute;deo con id %ID% ha sido eliminado.',
	'kalturavideo:action:updatedko' => 'El v&iacute;deo con id %ID% no puede ser actualizado!',
	'kalturavideo:label:flv' => 'URL del v&iacute;deo FLV:',
	'kalturavideo:label:thumbnail' => 'URL del Thumbnail:',
	'kalturavideo:label:sharel' => 'C&oacute;digo HTML compartido (gran applet):',
	'kalturavideo:label:sharem' => 'C&oacute;digo HTML compartido (peque&ntilde;o applet):',
	'kalturavideo:label:privateoptions' => 'Privacidad:',
	'kalturavideo:private:public' => 'Publica',
	'kalturavideo:private:me' => 'Justo a m&iacute;',
	'kalturavideo:private:friends' => 'S&oacute;lamente amigos',
	'kalturavideo:private:loggedin' => 'Usuarios logados',
	'kalturavideo:text:privatestatus' => 'Las opciones de privacidad son v&aacute;lidos para este m&oacute;dulo (p&uacute;blico significa que otras usuarias registradas puede ver el v&iacute;deo pero NO moficiarlo). Si comparte este c&oacute;digo HTML la privacidad no tendrá efectos (esto incluye cada post de v&iacute;deo).',
	'kalturavideo:text:statuschanged' => 'Estado de la privacidad para el v&iacute;deo %2% cambiado a "%1%"',
	'kalturavideo:text:statusnotchanged' => 'El estado de la privacidad del v&iacute;deo %1% no puede cambiarse!',
	'kalturavideo:label:allvideos' => 'Todos los v&iacute;deos p&uacute;blicos',
	'kalturavideo:text:novideos' => 'Lo lamento, no tiene v&iacute;deos!',
	'kalturavideo:text:nopublicvideos' => 'Lo lamento, No hay v&iacute;deos p&uacute;blicos aun!',
	'kalturavideo:label:author' => 'Autora:',
	'kalturavideo:text:nofriendsvideos' => 'Lo lamento, no hay v&iacute;deos de sus amigos aun!',
	'kalturavideo:text:nouservideos' => 'Lo lamento, no hay v&iacute;deos para esta usuaria!',
	'kalturavideo:label:showvideo' => 'Mostrar el v&iacute;deo',
	'kalturavideo:text:notfound' => 'Recurso no encontrado!',
	'kalturavideo:show:advoptions' => 'Mostrar compartir',
	'kalturavideo:hide:advoptions' => 'Ocultar compartir',
	'kalturavideo:label:latest' => '&Uacute;ltimos v&iacute;deos',
	'kalturavideo:text:widgetdesc' => 'Este componente permite mostrar autom&acute;ticamente sus &uacute;ltimos v&iacute;deos.',
	'kalturavideo:error:edittitle' => 'Error! Este pequeño no puede ser cambiado!',
	'kalturavideo:label:latestfrom' => 'Muestra los &uacute;ltimos v&iacute;deso desde:',
	'kalturavideo:label:anyvideos' => 'Alg&uacute;n v&iacute;deo permitido',
	'kalturavideo:error:objectnotavailable' => 'Objecto no disponible. Por favor recargue la p&aicute;gina.',
	'kalturavideo:label:recreateobjects' => 'Recrear todos los objetos de v&iacute;deos',
	'kalturavideo:text:recreateobjects' => 'Intente hacer esto si esta actualizando Kaltura desde alguna antigua versi&oacute;n.\n\nIMPORTANT NOTE:\nAll the Elgg objects will be deleted and recreated. Metada, comments and ratings will not be lost but the GUID of the video object will change.\nThis means that the old url for the videos will change also (could affect other plugins like bookmarks).',
	'kalturavideo:edit:notallowed' => 'No puede editar este v&iacute;deo!',
	
	'kalturavideo:river:created' => '%s creado',
	'kalturavideo:river:annotate' => '%s comentado en',
	'kalturavideo:river:item' => 'un v&iacute;deo',
	'kalturavideo:river:updated' => '%s actualizado',
	
	'kalturavideo:river:shared' => 'V&iacute;deo Kalturao',
	'kalturavideo:label:videosfrom' => 'V&iacute;deos por %s',
	
	'kalturavideo:user:showallvideos' => 'Mostrar todos los v&iacute;deos de esta usuaria',
	
	'kalturavideo:strapline' => "%s",
	
	 /**
     * kaltura_video rating system
	 **/
	'kalturavideo:rating' => "Clasificaci&oacute;n",
	'kalturavideo:yourrate' => "Sus votaciones:",
	'kalturavideo:rate' => "Vote!",
	'kalturavideo:votes' => "votos",
	'kalturavideo:ratesucces' => "Su votaci&oacute;n ha sido guardada.",
	'kalturavideo:rateempty' => "Por favor seleccione un valor antes de votar!",
	'kalturavideo:notrated' => "Ya ha votado este elemento!",
	
	/**
	 * Groups
	 **/
	'kalturavideo:groupprofile' => 'V&iacute;deos Kaltura',
	'kalturavideo:label:groupvideos' => "V&iacute;deos desde este grupo",
	'kalturavideo:label:allgroupvideos' => "V&iacute;deos de los grupos",
	'kalturavideo:text:nogroupvideos' => 'Lo lamento, no hay v&iacute;deos para este grupo aun!',
	'kalturavideo:private:thisgroup' => 'S&oacute;lamente este grupo',
	'kalturavideo:label:collaborative' => 'Colaborativo',
	'kalturavideo:text:collaborative' => 'Esto permite a otros miembros de este grupo editar el v&iacute;deo tambi&eacute;n!',
	'kalturavideo:text:collaborativechanged' => 'Estado de colaboraci&oacute;n para el v&iacute;deo %1% cambiado!',
	'kalturavideo:text:collaborativenotchanged' => 'Estado de colaboraci&oacute;n para el v&iacute;deo %1% no puede ser cambiado!',
	'kalturavideo:text:iscollaborative' => 'Este es un v&iacute;deo colaborativo, puede editarlo!',
	
	'kalturavideo:userprofile' => 'V&iacute;deos Kaltura',
);

add_translation("es", $spanish);

?>
