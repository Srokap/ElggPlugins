<?php

	/**
	 * Elgg Sitemap plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Matthias Sutter email@matthias-sutter.de
	 * @copyright CubeYoo.de
	 * @link http://cubeyoo.de
	 */


?>



<div class="contentWrapper">

    <div id="left">

    <div id="box">	
<h3><a href="<?php echo $vars['url']; ?>">Start</a></h3>
<?php if (is_plugin_enabled('externalpages')) { ?>
<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/expages/read/About/">About</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/expages/read/Terms/">Terms</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/expages/read/Privacy/">Privacy</a></li>
<?php }; ?>

<li><a href="<?php echo $vars['url']; ?>account/register.php">Rejestracja</a></li>
<li><a href="<?php echo $vars['url']; ?>account/forgotten_password.php">Zapomniałem Hasła</a></li>
</ul>
</div>


<?php if (is_plugin_enabled('profile')) { ?>

    <div id="box">
<h3><a href="<?php echo $vars['url']; ?>pg/settings/">Ustawienia</a></h3>
<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/settings/statistics/<?php echo $_SESSION['user']->username; ?>/">Statystyki uzytkownika</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/settings/plugins/<?php echo $_SESSION['user']->username; ?>">Narzedzia</a></li>
<li><a href="<?php echo $vars['url']; ?>mod/notifications/">Powiadomienia</a></li>
<li><a href="<?php echo $vars['url']; ?>mod/notifications/groups.php">Powiadomienia w grupach</a></li>
</ul>
    </div>

<?php }; ?>


<?php if (is_plugin_enabled('messages')) { ?>

    <div id="box">	

<h3><a href="<?php echo $vars['url']; ?>pg/messages/<?php echo $_SESSION['user']->username; ?>">Wiadomości</a></h3>
<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>mod/messages/send.php">Utwórz wiadomość</a></li>
<li><a href="<?php echo $vars['url']; ?>mod/messages/sent.php">Wyślij wiadomość</a></li>
</ul>
    </div>
<?php }; ?>



<?php if (is_plugin_enabled('riverdashboard')) { ?>

    <div id="box">	
<h3><a href="<?php echo $vars['url']; ?>pg/dashboard/">Twoja strona startowa</a></h3>
<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/dashboard/?type=&display=friends&content=">Aktywność znajomych</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/dashboard/?type=&display=mine&content=">Twoja aktywność</a></li>
</ul>
    </div>
<?php }; ?>


	

<?php if (is_plugin_enabled('blog')) { ?>
    <div id="box">	
<h3><a href="<?php echo $vars['url']; ?>mod/blog/everyone.php">Wszystkie blogi</a></h3>

<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>">Twój blog</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>/friends/">Blogi znajomych</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>/new/">Dodaj blog</a></li>
</ul>
    </div>

<?php }; ?>


   </div>
   

	
<div id="right">

   		<div id="fernglas">
			<img src="<?php echo $vars['url']; ?>mod/sitemap/graphics/sitemap.png" border="0" />
        </div>



<?php if (is_plugin_enabled('groups')) { ?>
    <div id="box">	
<h3><a href="<?php echo $vars['url']; ?>pg/groups/world/">Wszystkie grupy</a></h3>
<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/groups/world/?filter=pop">Popularne grupy</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/groups/world/?filter=active">Ostatnie dyskusje</a></li>

<li><a href="<?php echo $vars['url']; ?>pg/groups/owned/<?php echo $_SESSION['user']->username; ?>">Grupy które załozyłeś</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/groups/member/<?php echo $_SESSION['user']->username; ?>">Przynależność w grupach</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/groups/new/">Dodaj nową grupę</a></li>
</ul>
    </div>

<?php }; ?>



<?php if (is_plugin_enabled('file')) { ?>
    <div id="box">	
<h3><a href="<?php echo $vars['url']; ?>mod/file/world.php">All site files</a></h3>

<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/file/<?php echo $_SESSION['user']->username; ?>">Your files</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/file/<?php echo $_SESSION['user']->username; ?>/friends/">Your friends' files</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/file/<?php echo $_SESSION['user']->username; ?>/new/">Upload a file</a></li>
</ul>
    </div>

<?php }; ?>



<?php if (is_plugin_enabled('pages')) { ?>
    <div id="box">	
<h3><a href="<?php echo $vars['url']; ?>mod/pages/world.php">Strony w serwisie</a></h3>
<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/pages/owned/<?php echo $_SESSION['user']->username; ?>">Twoje strony</a></li>

<li><a href="<?php echo $vars['url']; ?>pg/pages/welcome/">Zmień wiadomośc powitalną</a></li>
</ul>
    </div>

<?php }; ?>



<?php if (is_plugin_enabled('bookmarks')) { ?>
    <div id="box">
<h3><a href="<?php echo $vars['url']; ?>mod/bookmarks/everyone.php">All site bookmarks</a></h3>

<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>pg/bookmarks/<?php echo $_SESSION['user']->username; ?>/inbox">Bookmarks inbox</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/bookmarks/<?php echo $_SESSION['user']->username; ?>/items">My bookmarked items</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/bookmarks/<?php echo $_SESSION['user']->username; ?>/friends/items">Friends' bookmarks</a></li>
<li><a href="<?php echo $vars['url']; ?>pg/bookmarks/<?php echo $_SESSION['user']->username; ?>/bookmarklet">Get bookmarklet</a></li>
</ul>
    </div>

<?php }; ?>

	


<?php if (is_plugin_enabled('members')) { ?>
    <div id="box">
<h3><a href="<?php echo $vars['url']; ?>mod/members/index.php">Użytkownicy</a></h3>
<ul class="menu">
<li><a href="<?php echo $vars['url']; ?>mod/members/index.php?filter=pop">Popularni</a></li>
<li><a href="<?php echo $vars['url']; ?>mod/members/index.php?filter=active">Aktywni</a></li>
</ul>
    </div>
<?php }; ?>




</div>



	
<div class="clearfloat"></div>
    
	</div>	
	

