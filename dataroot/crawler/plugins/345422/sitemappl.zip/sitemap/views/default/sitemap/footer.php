<?php

	/**
	 * Elgg Sitemap plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Matthias Sutter email@matthias-sutter.de
	 * @copyright CubeYoo.de
	 * @link http://cubeyoo.de
	 */
	
	global $CONFIG;
	
?>
<div class="footer_toolbar_links">
		| <a href="<?php echo $vars['url']; ?>pg/sitemap/"><?php echo elgg_echo('Mapa strony'); ?></a>&nbsp;
</div>