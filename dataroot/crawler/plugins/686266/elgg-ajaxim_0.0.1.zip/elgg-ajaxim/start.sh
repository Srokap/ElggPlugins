#!/bin/sh
NODE_ENV=production
nohup /usr/local/bin/node server/app.js 2>&1 >> /var/log/node.log &