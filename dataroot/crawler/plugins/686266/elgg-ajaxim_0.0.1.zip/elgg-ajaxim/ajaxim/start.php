<?php
    /**
     * Elgg AjaxIM plugin
     * Integrates AjaxIM Chat into Elgg
     * 
     * @package AjaxIM
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Christian Heckelmann
     * @copyright Christian Heckelmann
     * @link http://www.heckelmann.info
     */

    global $CONFIG;
    	
    /*
     * Initialize Plugin
     */
	function ajaxim_init() {
        global $CONFIG;
		if(is_callable('elgg_extend_view')) {
            $extend_view = 'elgg_extend_view';
        }else {
            $extend_view = 'extend_view';
        }
        // Set Plugin Version for Update Checks
		set_plugin_setting('version', '0.0.1', 'AjaxIM');
        //register_translations($CONFIG->pluginspath . "ajaxim/languages/");            		                            
        
        // Now set the Session Cookie for the User
        if (isloggedin()) {    
			// Add Javascript Chat Client...					
			$extend_view('metatags','ajaxim/js/javascript');
			$extend_view('footer/analytics','ajaxim/footer' ,499);		
			// Add Authentication Cookie
            setcookie("sessionid", $_SESSION['user']->getGUID(), 0 , "/");
        }
	}
       	
	register_elgg_event_handler('init','system','ajaxim_init');
    register_action("ajaxim/auth", false, $CONFIG->pluginspath . "ajaxim/actions/authenticate.php");
    register_action("ajaxim/friends", false, $CONFIG->pluginspath . "ajaxim/actions/friends.php");
?>