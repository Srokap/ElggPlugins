<?php

$body = '';

$body .= 'URL to ChatProxy (e.g. http://yoursite.com/chat)';
$body .= '<br />';
$body .= elgg_view('input/text',array('internalname'=>'params[chaturl]','value'=>get_plugin_setting('chaturl', 'ajaxim')));

echo $body;
?>