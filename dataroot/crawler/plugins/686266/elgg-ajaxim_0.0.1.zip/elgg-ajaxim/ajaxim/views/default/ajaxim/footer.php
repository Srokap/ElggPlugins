<?php
	global $CONFIG;
?>	
<div id="ajaxim"></div>
<script type="text/javascript"> 
$(function(){ 
        var im = AjaxIM.init({ 
                theme: "<?php echo $vars['url']; ?>mod/ajaxim/client/themes/default", 
                pollServer: "<?php echo get_plugin_setting('chaturl', 'ajaxim');?>" 
        }); 
}); 
</script> 