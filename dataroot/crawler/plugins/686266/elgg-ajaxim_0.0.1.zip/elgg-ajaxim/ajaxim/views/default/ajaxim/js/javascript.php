    <script src="<?php echo $vars['url']; ?>mod/ajaxim/client/js/md5.js" type="text/javascript"></script> 
    <script src="<?php echo $vars['url']; ?>mod/ajaxim/client/js/store.js" type="text/javascript"></script> 
    <script src="<?php echo $vars['url']; ?>mod/ajaxim/client/js/cookies.js" type="text/javascript"></script> 
    <script src="<?php echo $vars['url']; ?>mod/ajaxim/client/js/dateformat.js" type="text/javascript"></script> 
    <script src="<?php echo $vars['url']; ?>mod/ajaxim/client/js/im.js" type="text/javascript"></script> 