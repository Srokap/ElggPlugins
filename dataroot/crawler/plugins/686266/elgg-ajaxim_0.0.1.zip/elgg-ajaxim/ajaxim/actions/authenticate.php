<?php
    /**
     * Elgg AjaxIM plugin
     * Integrates AjaxIM Chat into Elgg
     * 
     * @package AjaxIM
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Christian Heckelmann
     * @copyright Christian Heckelmann
     * @link http://www.heckelmann.info
     */
    
    
    // Get Username from Session ID
    require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
    global $CONFIG;
	
    // Get User cookie
    $userid = $_COOKIE["sessionid"];
    $ElggUser=get_user($userid);
    
    $username = $ElggUser->get("name");    
    echo json_encode(array('username' => "$username"));
?>     