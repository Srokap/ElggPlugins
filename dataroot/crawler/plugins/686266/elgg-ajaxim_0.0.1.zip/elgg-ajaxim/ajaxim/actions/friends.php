<?php
    /**
     * Elgg AjaxIM plugin
     * Integrates AjaxIM Chat into Elgg
     * 
     * @package AjaxIM
     * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
     * @author Christian Heckelmann
     * @copyright Christian Heckelmann
     * @link http://www.heckelmann.info
     */

    // Loading elgg Engine...
    require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
    global $CONFIG;
	
    // Get User cookie
    $guid = $_COOKIE["sessionid"];
    $ElggUser=get_user($guid);

    $jsonobj = array();
    $friends = $ElggUser->getFriends('', 9999);
    foreach($friends as $friend){
        array_push($jsonobj, $friend->name);
    }
    echo json_encode($jsonobj);
	
    //$arr = array ('john', 'simon', 'harry'); 
    //echo json_encode($arr);
?>     