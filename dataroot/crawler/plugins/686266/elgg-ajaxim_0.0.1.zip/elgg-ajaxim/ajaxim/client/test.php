<?php    
    setcookie("sessionid", "Chris", time()+3600, "/");
?>
<html>
<head>

<script src="js/jquery-1.4.1.js"></script>
<script src="js/md5.js" type="text/javascript"></script> 
<script src="js/store.js" type="text/javascript"></script> 
<script src="js/cookies.js" type="text/javascript"></script> 
<script src="js/dateformat.js" type="text/javascript"></script> 
<script src="js/im.js" type="text/javascript"></script> 
</head>
<body>
<div id="ajaxim"></div>
<script type="text/javascript"> 
$(function(){ 
        var im = AjaxIM.init({ 
                theme: "themes/default", 
                pollServer: "http://www.musclegainer.net/chat" 
        }); 
}); 
</script> 
</body>
</html>