elgg-ajaxim Integration Plugin
Version 0.0.1

Project URL: http://code.google.com/p/elgg-ajaxim/

ChangeLog:
2011-01-28 (0.0.1) Christian Heckelmann
    + Initial Version

!!! NOT FOR PRODUCTIVE  SITES !!!
!!! ONLY TESTED WITH ELGG 1.6 !!!

AjaxIM works only on VPS or Dedicated Servers!

1. AjaxIM Server Installation
 - Download and install NodeJS and AjaxIM Server as described in the manual http://goo.gl/O9Gl6.
 - Replace www.yoursite.com in authentication/elgg/index.js with your site url
 - Copy authentication/elgg to /path/to/ajaxim/server/libs/authentication/elgg
 - Change the authentication lib in server/settings.js from default to elgg
 - Change the Hostname in server/settings.js if needed
 - Start the server with #node server/app.js for debug mode or with the start.sh script in Production mode

2. Configure Apache Proxy
 - Add the following proxy to your apache configuration or .htaccess
    
    ProxyPass /chat/ http://<ajaxim_server>:8000/
    ProxyPassReverse /chat/ http://<ajaxim_server>:8000/
    ProxyTimeout 310

3. Plugin Installation
 - Copy the ajaxim folder to your mod directory
 - Enable the Plugin and adjust the Ajaxim Proxy URL
