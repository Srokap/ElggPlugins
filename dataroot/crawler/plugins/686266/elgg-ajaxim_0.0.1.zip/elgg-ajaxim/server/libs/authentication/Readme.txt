This is the authentication Lib for the AjaxIM Server.
Copy to server/libs and configure the hostname in index.js