<?php
/**
 * Moderator role plugin language pack
 *
 */

$english = array(
	'roles_moderators:role:title' => 'Moderator',	
);

add_translation("en", $english);
