<script type="text/javascript" src="<?php echo $vars['url'];?>mod/folder/javascript/folder.js"></script>

<script type="text/javascript">
	var wwwroot = "<?php echo $vars['url'];?>";
</script>
