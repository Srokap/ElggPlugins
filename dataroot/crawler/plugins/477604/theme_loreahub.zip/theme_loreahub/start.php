<?php
 
    function theme_loreahub_init()
    {
			extend_view('metatags','theme_loreahub/metatags');
			extend_view('css','theme_loreahub/css');
			extend_view('page_elements/spotlight','theme_loreahub/elgg_topbar');
			extend_view('page_elements/spotlight','theme_loreahub/footer');
    }
 
    register_elgg_event_handler('init','system','theme_loreahub_init');
 
?>
