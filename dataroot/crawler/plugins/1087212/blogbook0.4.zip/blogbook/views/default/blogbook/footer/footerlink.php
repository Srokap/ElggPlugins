<div class="mts float-alt">
<a href="http://humchale.in/" id='humchalefooter'><img src="<?php echo elgg_get_site_url(); ?>mod/blogbook/views/default/blogbook/footer/humchale.ico" alt="Hc" title="HumChale"/></a>
</div>