I alwase wanted to remove Page plugin since it dont give any value addition over blog.

It was unnecesorry occuping space in index and also was not visible in profile.But I liked the Tree style relation of pages. 
So I thought of writting this plugin which binds exiting blogs into a book.

You can See my website www.humchale.in for example.


GIVE ME a favor : (CAUTION)

This plugin will create a small icon at the footer of your site. it will link to my site humchale.in
If you would like to remove that , you need to edit the sourcecode.



To the biginers.

After Installing this plugin you can see a new Sit emenu Item called 'blogbook'
Here you can  go and create new blogbook. 
After creating the blogbook you can insert your existing  blogs into it.


