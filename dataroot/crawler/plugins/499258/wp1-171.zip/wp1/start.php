<?php

                function wp1_init() {
        global $CONFIG;
                        
        // Register a page handler, so we can have nice URLs
                register_page_handler('irclnx','wp1_page_handler');
        
        // Page handler
                function wp1_page_handler($page) {
                        global $CONFIG;
                        include($CONFIG->pluginspath . "wp1/index.php");
                }
                
        // Load menu
                if (isloggedin()) {
//              add_menu(elgg_echo('LnX'),$CONFIG->wwwroot."pg/irclnx");
                }

                    //add a widget
//              add_widget_type('irclnx',elgg_echo("New LNX"),elgg_echo("A widget for displaying only new irclnx.com data."));
add_widget_type('directlinks',elgg_echo("directlinks:title"),elgg_echo("directlinks:description"));
add_widget_type('toplnx',elgg_echo("toplnx:title"),elgg_echo("toplnx:description"));
add_widget_type('irclnx2',elgg_echo("All LNX"),elgg_echo("A widget for displaying all irclnx.com data."));
add_widget_type('tips',elgg_echo("Tips - How 2 - Help"),elgg_echo("Tips - How 2 - Help"));
add_widget_type('top2ns',elgg_echo('top2ns:lastsong'),elgg_echo('top2ns:widgetinfo'));
add_widget_type('duuit2ns',elgg_echo('duuit2ns:lastsong'),elgg_echo('duuit2ns:widgetinfo'));
extend_view('css','duuit2ns/css');
add_widget_type('newmembers', 'Newest Members', 'Show the newest members');
add_widget_type('online',elgg_echo("Users online"),elgg_echo('online:widget:description'));
add_widget_type('profile_nagger',"Profile Progress","This widget indicates your progress filling out your user profile");
add_widget_type('qik', elgg_echo("qik:title"), elgg_echo("qik:description"));
add_widget_type('xgadget',"My Gadgets","Allows you to add Google Gadgets");
add_widget_type('vulcan',elgg_echo("vulcan:title"),elgg_echo("vulcan:description"));
add_widget_type('aaudio',elgg_echo("Audio Player"),elgg_echo("Audio Player"));  
add_widget_type('stickam',elgg_echo("stickam:title"),elgg_echo("stickam:description"));
add_widget_type('idlerpg',elgg_echo("idlerpg:title"),elgg_echo("idlerpg:description"));
add_widget_type('whosamungus',elgg_echo("whosamungus:title"),elgg_echo("whosamungus:description"));
add_widget_type('weather', 'Weather', 'Widget to get the weather');
add_widget_type('doodle',elgg_echo("doodle:title"),elgg_echo("doodle:description"));
elgg_extend_view('css','lastfm/css');
add_widget_type('lastfm',elgg_echo('lastfm:lastsong'),elgg_echo('lastfm:widgetinfo'));
add_widget_type('friendfeed',elgg_echo('friendfeed'),elgg_echo('friendfeed:description'));
add_widget_type('englishlevel', 'englishlevel Widget', elgg_echo("englishlevel:disc"));
add_widget_type('bloglatest', elgg_echo('bloglatest:start:widget:name'), elgg_echo('bloglatest:start:widget:name'));
add_widget_type( "tagcloud" , elgg_echo("tagcloud:widget:title"), elgg_echo("tagcloud:widget:description" ));
add_widget_type('recentdiscussions',elgg_echo("Recent discussions"),elgg_echo('recentdiscussions:widget:description'));
extend_view('index/recentdiscussions', 'recentdiscussions/indexview');
//extend_view('css','amazon/css');
//add_widget_type('amazon',elgg_echo('amazon:widget_name'), elgg_echo('amazon:widget_info'));
extend_view('css','arxiv/css');
add_widget_type('arxiv',elgg_echo('arXiv:recenteprints'),elgg_echo('arXiv:widgetinfo'));
add_widget_type('yahoo', 'Yahoo', 'Yahoo.com');
add_widget_type('anytext', elgg_echo('anytext:title'), elgg_echo('anytext:description'), 'all', true);
add_widget_type('flickr',"Flickr","This is your flickr feed");
add_widget_type('meebo', 'Meebo Widget', 'The meebo widget');
add_widget_type('meebochat',elgg_echo("My Chat"),elgg_echo("meebochat:description"));
add_widget_type('playgroud',"Playgroud","This is your Lastest playgroud feed");
add_widget_type("twitscoop","TwitScoop", "Whats hot on Twitter right now?");
add_widget_type('deviantart',"DeviantArt", "The deviantart widget");
add_widget_type('group_feed',elgg_echo('groups:widgets:feed:title'), elgg_echo('groups:widgets:feed:description'));
add_widget_type('feed_reader', elgg_echo('simplepie:widget'), elgg_echo('simplepie:description'));
extend_view('css','feed_reader/css');
add_widget_type('izapProfileVisitors', elgg_echo('izapProfileVisitor:Widget'), elgg_echo('izapProfileVisitor:WidgetDescription'));
extend_view("css","style/css");
extend_view('css', 'izapprofilevisitor/css');
add_widget_type('msnme',elgg_echo('msnme:widget:name'),elgg_echo('msnme:widget:desc'));
extend_view('profile/userdetails', 'izapprofilevisitor/userdetails', 1);
//elgg_extend_view('css','identica/css');
//add_widget_type('identica', "Identi.ca", "This is your identi.ca feed");
//extend_view('css','tagactivity/css');
//add_widget_type('tagactivity', elgg_echo("Tag activity"), elgg_echo('tagactivity:widget:description'));
//add_widget_type('myspace',"MySpace","This is your myspace feed");
//extend_view('css','myspace/css');
//add_widget_type('blog',elgg_echo('blog:widget:title'), elgg_echo('blog:widget:description'));
//add_widget_type('playlist', elgg_echo('rpplaylist:widget'), elgg_echo('rpplaylist:description'));
//add_widget_type('skypeme',"Skype Me","Skype Me Widget");
//add_widget_type('ebuddy',"eBuddy Messenger","Displays eBuddy Messenger on a widget");
//add_widget_type('opensocial_gadget',elgg_echo('opensocial:gadget:title'), elgg_echo('opensocial:gadget:description'),'all',true);
//extend_view('metatags','opensocial/metatags');
//mkdisabled bad query = Unknown column 'maxtime' in 'order clause'
//QUERY: SELECT DISTINCT e.* FROM elggentities e WHERE (e.site_guid IN (1)) AND ( (1 = 1) and e.enabled='yes') GROUP BY a.entity_guid ORDER BY maxtime desc LIMIT 0, 50
//add_widget_type('activemembers', elgg_echo("Most active members"), elgg_echo('activemembers:widget:description'));
//extend_view('css','activemembers/css');
//extend_view('index/activemembers', 'activemembers/indexview');

}
include($CONFIG->pluginspath . 'wp1/vendors/startlib.php');
                function msnme_handler($page) {
                        if (isset($page)) {
                                set_input('username',$page);
                                include(dirname(__FILE__) . "/msn.php");
                                return true;
                        }
                }

                function msnme_pagesetup()
                {
                        if (get_context() == 'admin' && isadminloggedin()) {
                                global $CONFIG;
                                add_submenu_item(elgg_echo('msnme:settings'), $CONFIG->wwwroot . 'mod/wp1/settings.php');
                        }

                }

function opensocial_standard_widget_display($widget_guid,$opensocial_owner,$url) {
    if (isloggedin()) {
        $opensocial_viewer = $_SESSION['user']->getGUID();
    } else {
        $opensocial_viewer = 0;
    }
    
    /*if ($pg_owner = page_owner_entity()) {
        $opensocial_owner = $pg_owner->getGUID();
    } else {
        $opensocial_owner = 0;
    };  */  

$body = <<<END
<div id="gadget-chrome$widget_guid" class="gadgets-gadget-chrome"></div>
<script type="text/javascript">
var gadgetUrl$widget_guid = '$url';
var viewerId = $opensocial_viewer;
var ownerId = $opensocial_owner;
    initOpenSocialGadget($widget_guid,{'url':gadgetUrl$widget_guid,'chromeIds':['gadget-chrome$widget_guid']},'{$CONFIG->wwwroot}mod/wp1/vendors/shindig/src/gadgets/');
</script>
END;
    return $body;
    }

                register_elgg_event_handler('init','system','wp1_init');
                register_elgg_event_handler('pagesetup','system','msnme_pagesetup');
                register_page_handler('msn','msnme_handler');
                register_action('msnme/save',false,$CONFIG->pluginspath . 'wp1/actions/save.php',true);
                require_once($CONFIG->pluginspath . "wp1/vendors/msnme.inc" );  
		register_action("opensocial/ifr",true,$CONFIG->pluginspath . "wp1/vendors/shindig/src/gadgets/ifr");
		register_action("opensocial/files",true,$CONFIG->pluginspath . "wp1/vendors/shindig/src/gadgets/files");

?>
