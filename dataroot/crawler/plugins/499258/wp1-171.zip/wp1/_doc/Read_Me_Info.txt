Upload a plugin, theme or language pack

File to upload
[ ]
.zip or .tar.zip only.

Title
 
MySpace 1.5-2009-03-26 (BETA)

Intro

Pulls MySpace profile comments into Elgg widget.

Description

Pulls your MySpace profile comments into Elgg widget.
Patched wrapper code from Dave Tosh's 'Twitter" pull widget 
to package MySpace grabber code.

A little bit untidy with the graphics but who's gonna notice ;-O ?

(1) Install just like any other widget into /mod.
(2) Goto settings and set your MySpace info or 
    some friends or some pubic MySpace profile or 
    try "tom" - he is public property.
(3) Edit your profile to place widget where you want it and it'll space you out.

Other: 
    Version: I am using version numbering as follows --
             1.5 -0 means I wrote it on ELGG v1.5
             2009-03-26 -- means that is the  date I released it and serves as RELEASE number
             -- you never have to ask "does it work with Elgg v1.5" or "is this the latest release"?
    License: Note the GPL license is version 3 (not 2) -- you want to to modify, etc ? 
             -- read GPL v3.

Version
1.5-2009-03-26

Plugin or theme?
Plugins

Licence

GNU General Public License (GPL) version 3

Tags

myspace plugin widget profile