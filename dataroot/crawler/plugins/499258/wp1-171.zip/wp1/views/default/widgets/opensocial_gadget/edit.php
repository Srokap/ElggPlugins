<?php
	/**
	 * Edit the widget
	 * 
	 * @package ElggRiver
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */
?>
<p>
	<?php echo elgg_echo('opensocial:edittext'); ?> <input type="text" style="width:95%;" name="params[url]" value="<?php echo $vars['entity']->url ?>">
</p>