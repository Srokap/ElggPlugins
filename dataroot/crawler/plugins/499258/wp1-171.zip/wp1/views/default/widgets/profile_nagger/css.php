<?php 
/**
 *	Profile Nagger Plugin
 *	@package Profile Nagger CSS
 *	@author John Mellberg
 *	@license GNU General Public License (GPL) version 2
 *	@copyright John Mellberg (c)2009
 **/

?>
#progress_indicator {
	width:inherit;
	padding: 10px;
}
	
#progressBarContainer {
	height:10px;
	width:100%;
	border: 1px #D9541E solid;
}