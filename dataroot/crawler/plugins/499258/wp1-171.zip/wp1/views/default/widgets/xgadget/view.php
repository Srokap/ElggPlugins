<?php
    
     /**
	 * Gadget view page
	 *
	 * @package XGadget
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico <jonathanrico@peesco.com>
	 * @copyright Peesco 2008
	 * @link http://www.peesco.com/
	 */
	 
	 //some required params
	 
	 $xgadget_code = $vars['entity']->code;
	 $xgadget_title = $vars['entity']->title;
	 $xgadget_height = (int) $vars['entity']->height;
	 
	 if (!$xgadget_height) $xgadget_height = 300;
	 
	 if (!$xgadget_code) $xgadget_code = '<script src="http://www.gmodules.com/ig/ifr?url=http://www.labpixies.com/campaigns/todo/todo.xml&amp;up_todos=&amp;up_saved_tasks=&amp;synd=open&amp;w=320&amp;h=270&amp;title=__MSG_title__&amp;lang=es&amp;country=ALL&amp;border=%23ffffff%7C0px%2C1px+solid+%23ffdd00%7C0px%2C2px+solid+%23ffdd33%7C0px%2C2px+solid+%23ffee99&amp;output=js"></script>
';


// check if the gadget code it's realy a gadget code

	//ereg(".*http://www\.gmodules\.com/ig/ifr\?url={1}(http://.*\.xml).*w=([[:digit:]]{2,3}).*h=([[:digit:]]{2,3}).*", $xgadget_id, $xgadget);
	ereg(".*(http://www\.gmodules\.com/ig/ifr\?url={1}http://.*\.xml.*)&amp;synd.*", $xgadget_code, $xgadget);

// if the flickr id is empty, then do not sure any photos

if($xgadget[1]){
	 
?>

<!-- send the xml url to the html generator frome google -->

<iframe  width="100%" height="<?php echo $xgadget_height; ?>" src="<?php echo $xgadget[1]; ?>" > No soportas frames</iframe>


<?php 

    }else{
        
        echo elgg_echo("xgadget:none");
        
    }
?>