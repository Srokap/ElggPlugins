        <p>
                <?php echo elgg_echo("stickam:username"); ?>
                <input type="text" name="params[username]" value="<?php echo htmlentities($vars['entity']->username); ?>" />    
        </p>
        
