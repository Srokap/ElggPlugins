<div class="contentWrapper">
<!--Your englishlevel Embed code below-->
<div style="width:270px">		 
		<iframe id="ifrVideoStreaming" name="ifrVideoStreaming" src="<?php echo $vars['url']; ?>/mod/wp1/vendors/plug.php"
											frameborder="0" scrolling="no"  height="250"></iframe> </div>

	 </div>
</div>
