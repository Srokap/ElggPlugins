<?php

?>

.friendfeed_item p {
	margin:0;
	padding:2px 0 0 2px;
	line-height:1.1em;
	min-height:17px;
}
.friendfeed_item {
	border-bottom:1px solid #dddddd;
	padding:2px 0 2px 0;
}
.friendfeed_stamp {
	font-size:70%;
	color:#666666;
}
