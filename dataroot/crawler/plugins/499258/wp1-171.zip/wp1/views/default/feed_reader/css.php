/*-------------------------------
SIMPLEPIE FEED WIDGET
-------------------------------*/
.simplepie_blog_title {
  text-align: center;
  margin-bottom: 15px;
}

.simplepie_item {
  margin-bottom: 12px;
}

.simplepie_title {
  margin-bottom: 4px;
}

.simplepie_excerpt {
  margin-bottom: 4px;
}

.simplepie_date {
  font-size: 70%;
}

.simplepie_excerpt img {
  width: 170px;
}
