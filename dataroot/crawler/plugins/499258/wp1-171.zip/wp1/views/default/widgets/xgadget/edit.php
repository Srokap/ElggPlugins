<?php

     /**
	 * Gadget view page
	 *
	 * @package XGadget
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico <jonathanrico@peesco.com>
	 * @copyright Peesco 2008
	 * @link http://www.peesco.com/
	 */

?>
	<p>
		<?php echo elgg_echo("xgadget:title"); ?>
        <input type="text" id="" name="params[title]" value="<?php echo htmlentities($vars['entity']->title); ?>" />
<p>
		<?php echo elgg_echo("xgadget:code"); ?>
        <textarea id="" rows="10" cols="33" name="params[code]"><?php echo htmlentities($vars['entity']->code); ?></textarea>
	</p>
	<p>
		<?php echo elgg_echo("xgadget:height"); ?>
    	<input type="text" id="" name="params[height]" value="<?php echo htmlentities($vars['entity']->height); ?>"  /> PX
	<p>

<p>
	<p><?php echo elgg_echo("xgadget:codewhere"); ?></p>
    
