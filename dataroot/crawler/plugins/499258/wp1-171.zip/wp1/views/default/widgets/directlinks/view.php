<?php
    
	/**
	 * Elgg directlinks Plugin
	 * 
	 * @package directlinks
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jayadeep P J
	 * @copyright Jayadeep P J 2009
	 * @link http://nezted.com/
	 * 
	 */
	 
if(isloggedin()){
?>

<div>
  <p align="center"><a href="<?php echo $vars['url'] . $_SESSION['user']->username; ?>"><img src="<?php echo $_SESSION['user']->getIcon('large'); ?>" style="border: 1px solid #cccccc;padding:3px;" /></a></p>
  
<p align="center">
<script>
var timeZoneOff=((new Date()).getTimezoneOffset())/(-60);

function setCookie( name, value, expires/*days*/, path, domain, secure )
{
var today = new Date();
today.setTime( today.getTime() );
if ( expires ){ expires = expires * 1000 * 60 * 60 * 24; }
var expires_date = new Date( today.getTime() + (expires) );
document.cookie = name + "=" +escape( value ) +
( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
( ( path ) ? ";path=" + path : "" ) +
( ( domain ) ? ";domain=" + domain : "" ) +
( ( secure ) ? ";secure" : "" );
}
setCookie("tzoff",timeZoneOff,100,"/","","");
</script>
<?
if(isset($_COOKIE['tzoff']))
{
  echo gmdate('D F j, Y g:i A',time(0)+((double)$_COOKIE['tzoff'])*3600);
}
else echo "Please refresh the dashboard.";
?>
</p>

<div style="padding-left: 10px; padding-right: 10px; padding-bottom: 20px;">

<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/1.png) no-repeat center left; padding-top: 5px; padding-left: 25px; padding-bottom: 5px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>mod/profile/edit.php?username=<?php echo $_SESSION['user']->username; ?>">Edit Profile</a></div>

<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/2.png) no-repeat center left; padding-top: 5px; padding-left: 25px; padding-bottom: 5px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>mod/profile/editicon.php">Edit Profile Picture</a></div>

<?php if (is_plugin_enabled('customstyle')) { ?>

<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/3.png) no-repeat center left; padding-top: 5px; padding-left: 25px; padding-bottom: 5px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>mod/customstyle/colors.php">Change Profile Colours</a></div>

<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/4.png) no-repeat center left; padding-top: 5px; padding-left: 25px; padding-bottom: 5px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>mod/customstyle/background.php">Change Profile Background</a></div>

<?php }; ?>

<?php if (is_plugin_enabled('customstyle')) { ?>
<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/5.png) no-repeat center left; padding-top: 5px; padding-left: 25px; padding-bottom: 5px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>pg/photos/owned/<?php echo $_SESSION['user']->username; ?>">Manage Photos</a></div>
<?php }; ?>

<?php if (is_plugin_enabled('blog')) { ?>
<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/6.png) no-repeat center left; padding-top: 5px; padding-bottom: 5px; padding-left: 25px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>pg/blog/<?php echo $_SESSION['user']->username; ?>">Blog</a></div>
<?php }; ?>

<?php if (is_plugin_enabled('thewire')) { ?>
<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/7.png) no-repeat center left; padding-top: 5px; padding-bottom: 5px; padding-left: 25px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>pg/thewire/<?php echo $_SESSION['user']->username; ?>">The Wire</a></div>
<?php }; ?>

<?php if (is_plugin_enabled('messageboard')) { ?>
<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/8.png) no-repeat center left; padding-top: 5px; padding-bottom: 5px; padding-left: 25px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>pg/messageboard/<?php echo $_SESSION['user']->username; ?>">Messageboard</a></div>
<?php }; ?>

<?php if (is_plugin_enabled('friends')) { ?>
<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/9.png) no-repeat center left; padding-top: 5px; padding-bottom: 5px; padding-left: 25px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>pg/friends/<?php echo $_SESSION['user']->username; ?>">Friends</a></div>
<?php }; ?>


<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/10.png) no-repeat center left; padding-top: 5px; padding-bottom: 5px; padding-left: 25px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>pg/settings/user/<?php echo $_SESSION['user']->username; ?>">Settings</a></div>


<?php if (is_plugin_enabled('invitefriends')) { ?>
<div style="background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/11.png) no-repeat center left; padding-top: 5px; padding-bottom: 5px; padding-left: 25px; border-bottom: 1px solid #cccccc;"><a href="<?php echo $vars['url']; ?>mod/invitefriends/">Invite Your Friends</a></div>
<?php }; ?>

</div>
</div>

<?php } ?>
