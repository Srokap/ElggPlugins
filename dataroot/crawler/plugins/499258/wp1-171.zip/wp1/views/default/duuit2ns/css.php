<?php

	/**
	 * Elgg 2ns.duuit.com Widget
	 * 
	 * @package Elgg2ns.duuit.com
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright Sergio De Falco aka SGr33n 2009
	 * @link http://www.ircaserta.com/
	 */

?>

ul#duuit2nssonglist {
	margin: 0;
	padding: 2px 0 2px 0;
	line-height: 100%;
}
ul#duuit2nssonglist li {
	margin-left: 5px;
	margin-bottom: 4px;
}