<?php
	/**
	 * View the widget
	 * 
	 * @package OpenSocial
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Kevin Jardine
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 */

	$owner = page_owner_entity();
	if ($vars['entity']->url) {
		$url = $vars['entity']->url;
		if (!in_array(substr($url,0,6),array('http:/','https:'))) {
    		$url = $vars['url'].'mod/wp1/vendors/shindig/src/gadgets/files/samplecontainer/examples/'.$url;
		}
    		
	} else {
    	$url = $vars['url'].'mod/wp1/vendors/shindig/src/gadgets/files/samplecontainer/examples/compliancetests.xml';
	}
	
	echo opensocial_standard_widget_display($vars['entity']->getGUID(),$owner->getGUID(), $url);
	
?>