<?php
    
    /**
	* Elgg myspace view page
	*
	* @package Elggmyspace
	* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	* @author Dhrup Chand <dhrup2000@gmail.com>
	* @copyright Dhrup Chand & Curverider Ltd 2008-2009
	* @link http://www.ensci.us
	*/
	 
	//------------------------------------------------------------------------------
	/**
	* MySpace  params
	*/
	 
	$MYSPACE_username = $vars['entity']->MYSPACE_username;
	$MYSPACE_num      = $vars['entity']->MYSPACE_num;
    /*echo "<div class=\"contentWrapper\">"
	    ."MySpace::$MYSPACE_username($MYSPACE_num)"
        //echo "<br>(",$_SERVER['PHP_SELF'] 
	    ."</div>"
		;**/

	//------------------------------------------------------------------------------

	require_once($CONFIG->pluginspath . "wp1/vendors/myspace/myspace.php"); 

        $MYSPACE_url = "http://www.myspace.com/tom"; // default tom ! ;-O)
    if ( isset($MYSPACE_username) && $MYSPACE_username!="")
        $MYSPACE_url = "http://www.myspace.com/".$MYSPACE_username;
    
    $MYSPACE_profile = new MySpace($MYSPACE_url);
    
    $init_mssg="";
    $MYSPACE_mssg=$init_mssg;
    if($MYSPACE_profile->getMySpaceStatus() == 1) { $MYSPACE_mssg = "myspace:profileprivate"; }
    if($MYSPACE_profile->getMySpaceStatus() == 2) { $MYSPACE_mssg = "myspace:invalidfriendid"; }
    if ($MYSPACE_mssg!=$init_mssg)
    {
        echo "<div class=\"contentWrapper\"><p>" . elgg_echo($MYSPACE_mssg) . "!/p></div>";
    }
    else
    {

		echo "<div id=\"myspace_widget\">";
		echo "<ul  id=\"myspace_update_list\">";
		foreach ( $MYSPACE_profile->getMySpaceComments() as $k1=>$v1 ) 
		{
			if ( !is_array($v1) )
			{
			    echo "",trim($v1),""; 
			}
			else
			{
				foreach ( $v1 as $k2=>$v2 ) 
				{
				if ( $k2=="date" || $k2=="comment" ) 
					{
						if ( $k2=="comment" ) 
							echo "<li><span>";
						else
							echo "<a href=\"\" style=\"font-size: 75%;margin-left:1px;\">";
						echo "",	preg_replace
									(
										"/\<br\>/"
										,""
										,trim($v2)
									)
							 ,"";
						if ( $k2=="comment" ) 
							echo "</span></li>";
						else
							echo "</a>";
					}
				}
			}
		}
		echo "</ul>";
		//print_r($MYSPACE_profile->getMySpaceComments() );

        echo "</div>";

    } // else :: if ($MYSPACE_mssg!="") {

	//------------------------------------------------------------------------------

    echo "<p></p><p class=\"visit_myspace\" style=\";margin-left:10px;margin-right:10px;\">"
	    ."<a href=\"http://myspace.com/$MYSPACE_username\">visit mySpace</a>";
    echo "<div class=\"clearfloat\"></div>";
    
//------------------------------------------------------------------------------
       
?>
</div>
