
    <p>
		<?php echo elgg_echo("Yahoo pingbox flashvars value:"); ?>
		<input type="text" name="params[pingbox]" value="<?php echo htmlentities($vars['entity']->pingbox); ?>" />	
	</p>
    <p>Yahoo Width:<br />
    <select name="params[width]">
    <option value="294"><?php echo elgg_echo('Right 294'); ?></option>
    <option value="375"><?php echo elgg_echo('Middle 375'); ?></option>
    <option value="213"><?php echo elgg_echo('Left 213'); ?></option>
    </select>
    </p>
    
	<hr />
	<p><b>Instructions</b></p>
    
    <p>After you make your pingbox from yahoo, look in the embed code for "flashvars" value="wid=R.gmeVC_R2QfjNBUt.5pH3aGDJs-" /> and copy the value portion between the quotation marks (eg.. wid=R.gmeVC_R2QfjNBUt.5pH3aGDJs-) and paste inside the box.</p>
   <hr />