<?php
$tag = $vars['entity']->widgettitle;
if (!isset($tag)) $tag = "";
?>

<p>
<?php echo elgg_echo("tagactivity:tag"); ?>
<input type="text" onclick="this.select();" name="params[tag]" value="<?php echo htmlentities($vars['entity']->tag); ?>" />
</p>