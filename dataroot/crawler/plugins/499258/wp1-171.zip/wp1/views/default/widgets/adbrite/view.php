<?php
                $username = $vars['entity']->username;
                $numlnx = $vars['entity']->num_display;
?>

<!-- toplnx -->
<div class="contentWrapper user_settings" style="height:300px;">
<!--  <?php echo $vars['entity']->toplnx; ?> -->
<?php 
if($username == "") { 
?>
<!-- Begin: AdBrite, Generated: 2010-05-02 6:07:11  -->
<script type="text/javascript">
var AdBrite_Title_Color = '0000FF';
var AdBrite_Text_Color = '000000';
var AdBrite_Background_Color = 'FFFFFF';
var AdBrite_Border_Color = 'CCCCCC';
var AdBrite_URL_Color = '008000';
try{var AdBrite_Iframe=window.top!=window.self?2:1;var AdBrite_Referrer=document.referrer==''?document.location:document.referrer;AdBrite_Referrer=encodeURIComponent(AdBrite_Referrer);}catch(e){var AdBrite_Iframe='';var AdBrite_Referrer='';}
</script>
<script type="text/javascript">document.write(String.fromCharCode(60,83,67,82,73,80,84));document.write(' src="http://ads.adbrite.com/mb/text_group.php?sid=1620578&zs=3136305f363030&ifr='+AdBrite_Iframe+'&ref='+AdBrite_Referrer+'" type="text/javascript">');document.write(String.fromCharCode(60,47,83,67,82,73,80,84,62));</script>
<div><a target="_top" href="http://www.adbrite.com/mb/commerce/purchase_form.php?opid=1620578&afsid=1" style="font-weight:bold;font-family:Arial;font-size:13px;">Your Ad Here</a></div>
<!-- End: AdBrite -->

<div id="digg-widget">
<a href="http://digg.com/search?s=duuit.com">See more duuit.com stories on Digg.com</a>
</div>
<script type="text/javascript" src="http://widgets.digg.com/widgets.js"></script>
<script type="text/javascript">
new DiggWidget({id: "digg-widget", layout: 1, colors: {hdrBg: "#1b5790", hdrTxt: "#b3daff", tabBg: "#4684be", tabTxt: "#b3daff", tabOnTxt: "#d41717", bdyBg: "#fff", stryBrdr: "#ddd", lnk: "#105cb6", descTxt: "#999999", subHd: "#999999"}, title: "Duuit! on Digg", width: 285, requests: [{t: "duuit.com", p: {count: "5", sort: "digg_count-desc", method: "story.getPopular", domain: "duuit.com"}}], hide: {}, descriptions: "show", target: "_blank"});
</script>
echo "Edit Settings and choose your username on irclnx for this plugin to operate."; } else {
echo $username;
echo "'s top $numlnx lnx<hr>";?>
//my diggs
<div id="digg-widget">
<a href="http://digg.com/users/midkniht">See more stories dugg by midkniht on Digg.com</a>
</div>
<script type="text/javascript" src="http://widgets.digg.com/widgets.js"></script>
<script type="text/javascript">
new DiggWidget({id: "digg-widget", layout: 1, colors: {hdrBg: "#1b5790", hdrTxt: "#b3daff", tabBg: "#4684be", tabTxt: "#b3daff", tabOnTxt: "#d41717", bdyBg: "#fff", stryBrdr: "#ddd", lnk: "#105cb6", descTxt: "#999999", subHd: "#999999"}, title: "Duuit! on Digg", width: 285, requests: [{t: "midkniht", p: {count: "5", method: "user.getDugg", username: "midkniht"}}], hide: {}, descriptions: "show", target: "_blank"});
</script>
//myfriends diggs
<div id="digg-widget">
<a href="http://digg.com/users/midkniht/friends">See more dugg by my friends on Digg.com</a>
</div>
<script type="text/javascript" src="http://widgets.digg.com/widgets.js"></script>
<script type="text/javascript">
new DiggWidget({id: "digg-widget", layout: 1, colors: {hdrBg: "#1b5790", hdrTxt: "#b3daff", tabBg: "#4684be", tabTxt: "#b3daff", tabOnTxt: "#d41717", bdyBg: "#fff", stryBrdr: "#ddd", lnk: "#105cb6", descTxt: "#999999", subHd: "#999999"}, title: "Duuit! on Digg", width: 285, requests: [{t: "Friends", p: {count: "5", method: "friend.getDugg", username: "midkniht"}}], hide: {}, descriptions: "show", target: "_blank"});
</script>
<iframe id="toplnxbyuser" name="toplnxbyuser" frameborder=0 verticalborder=no horizontalborder=0 width="100%" height="95%" marginwidth=0 marginheight=0 hspace=0 vspace=0 src="http://irclnx.com/api/toplnxbyuser.php?username=<?php echo $username; ?>&numlnx=<?php echo $numlnx; ?>"/></iframe>
<!-- toplnxbyuser -->
</div>

<?php } ?>
