<?php
                $username = $vars['entity']->username;
                $numlnx = $vars['entity']->num_display;
?>

<!-- toplnx -->
<div class="contentWrapper user_settings" style="height:300px;">
<!--  <?php echo $vars['entity']->toplnx; ?> -->
<?php 
if($username == "") { 
<div id="digg-widget">
<a href="http://digg.com/search?s=duuit.com">See more duuit.com stories on Digg.com</a>
</div>
<script type="text/javascript" src="http://widgets.digg.com/widgets.js"></script>
<script type="text/javascript">
new DiggWidget({id: "digg-widget", layout: 1, colors: {hdrBg: "#1b5790", hdrTxt: "#b3daff", tabBg: "#4684be", tabTxt: "#b3daff", tabOnTxt: "#d41717", bdyBg: "#fff", stryBrdr: "#ddd", lnk: "#105cb6", descTxt: "#999999", subHd: "#999999"}, title: "Duuit! on Digg", width: 285, requests: [{t: "duuit.com", p: {count: "5", sort: "digg_count-desc", method: "story.getPopular", domain: "duuit.com"}}], hide: {}, descriptions: "show", target: "_blank"});
</script>
echo "Edit Settings and choose your username on irclnx for this plugin to operate."; } else {
echo $username;
echo "'s top $numlnx lnx<hr>";?>
//my diggs
<div id="digg-widget">
<a href="http://digg.com/users/midkniht">See more stories dugg by midkniht on Digg.com</a>
</div>
<script type="text/javascript" src="http://widgets.digg.com/widgets.js"></script>
<script type="text/javascript">
new DiggWidget({id: "digg-widget", layout: 1, colors: {hdrBg: "#1b5790", hdrTxt: "#b3daff", tabBg: "#4684be", tabTxt: "#b3daff", tabOnTxt: "#d41717", bdyBg: "#fff", stryBrdr: "#ddd", lnk: "#105cb6", descTxt: "#999999", subHd: "#999999"}, title: "Duuit! on Digg", width: 285, requests: [{t: "midkniht", p: {count: "5", method: "user.getDugg", username: "midkniht"}}], hide: {}, descriptions: "show", target: "_blank"});
</script>
//myfriends diggs
<div id="digg-widget">
<a href="http://digg.com/users/midkniht/friends">See more dugg by my friends on Digg.com</a>
</div>
<script type="text/javascript" src="http://widgets.digg.com/widgets.js"></script>
<script type="text/javascript">
new DiggWidget({id: "digg-widget", layout: 1, colors: {hdrBg: "#1b5790", hdrTxt: "#b3daff", tabBg: "#4684be", tabTxt: "#b3daff", tabOnTxt: "#d41717", bdyBg: "#fff", stryBrdr: "#ddd", lnk: "#105cb6", descTxt: "#999999", subHd: "#999999"}, title: "Duuit! on Digg", width: 285, requests: [{t: "Friends", p: {count: "5", method: "friend.getDugg", username: "midkniht"}}], hide: {}, descriptions: "show", target: "_blank"});
</script>
<iframe id="toplnxbyuser" name="toplnxbyuser" frameborder=0 verticalborder=no horizontalborder=0 width="100%" height="95%" marginwidth=0 marginheight=0 hspace=0 vspace=0 src="http://irclnx.com/api/toplnxbyuser.php?username=<?php echo $username; ?>&numlnx=<?php echo $numlnx; ?>"/></iframe>
<!-- toplnxbyuser -->
</div>

<?php } ?>
