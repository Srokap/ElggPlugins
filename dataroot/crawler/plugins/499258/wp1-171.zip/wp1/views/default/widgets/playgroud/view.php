<?
/**
	 * Elgg playgroud widget
	 * This plugin allows users to pull in their Lastest playgrouddisplay 
	 * 
	 * @package Elgg playgroud
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Bubu <webmaster@lungkao.com>
	 * @Skype konlungkao
	 * @twitter lungkao
	 * @copyright Laithai 2008-2009
	 * @link http://elgg.in.th/
	 */
	 
$pg_id        =    $vars['entity']->playgroud_id;
$photo_num    =    $vars['entity']->playgroud_num;
    if($pg_id){
$c = curl_init("http://www.pg.in.th/oapi/photos/$pg_id/$photo_num");
curl_setopt($c, CURLOPT_HEADER, 0);
curl_setopt($c, CURLOPT_VERBOSE, 0);
curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
$json_content = curl_exec($c);
curl_close($c);

$json_decode    =    json_decode($json_content);

    echo "<div class=\"contentWrapper\">";

 for ($i=0;$i<=$photo_num-1;$i++) {
    $Src                =    $json_decode->Photos[$i]->Src;
    $UploadTime            =    $json_decode->Photos[$i]->UploadTime;
    $PhotoId            =    $json_decode->Photos[$i]->PhotoId;
    $Description        =    $json_decode->Photos[$i]->Description;
    $Tags                =    $json_decode->Photos[$i]->Tags;
    $Title                =    $json_decode->Photos[$i]->Title;
    $Longitude            =    $json_decode->Photos[$i]->Longitude;
    $Place                =    $json_decode->Photos[$i]->Place;
    $Latitude            =    $json_decode->Photos[$i]->Latitude;
    $imglink            =    $Src;
    $imglink            =    str_replace("48x48","medium",$imglink);

    if ($Src !="") {

        echo "<a href='http://www.pg.in.th$imglink' target='_bank' title='$Title'><img src='http://www.pg.in.th$Src' border='0' /></a>\n";
   }
 }

 echo "</p></div>";
} else {
      echo "<div class=\"contentWrapper\"><p>" . elgg_echo("playgroud:notset") . ".</p></div>";
      
  }
 ?>