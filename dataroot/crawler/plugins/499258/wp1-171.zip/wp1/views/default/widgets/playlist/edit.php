<?php

    /**
	 * Elgg RP Playlist plugin edit page
	 *
	 * @package Radio Paradise Playlist
	 * @license GNU General Public License (GPL) version 2
	 * @author Michael Holm, Pixel Brothers Interactive <holm@pixbros.com>
	 * @copyright Pixel Brothers Interactive 2009
	 * @link http://pixbros.com/
	 */
	  
?>
	<p>
		How many songs to display? &nbsp;&nbsp;

		<select name="params[limit]">
			<option value="5" <?php if ($vars['entity']->limit == 5) echo " selected=\"yes\" "; ?>>5</option>
			<option value="10" <?php if ((!$vars['entity']->limit) || ($vars['entity']->limit == 10)) echo " selected=\"yes\" "; ?>>10</option>
			<option value="15" <?php if ($vars['entity']->limit == 15) echo " selected=\"yes\" "; ?>>15</option>
			<option value="20" <?php if ($vars['entity']->limit == 20) echo " selected=\"yes\" "; ?>>20</option>
		</select>
	</p>