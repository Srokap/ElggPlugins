<?php
/**
 * Elgg blogwidget plugin
 *
 * @package ElggBlogWidget
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Diego Andrés Ramírez <diego@somosmas.org>
 * @copyright Corporación Somos más 2008
 * @link http://www.somosmas.org/
 */

$widget_view = $vars['entity']->view;
if (!$widget_view) $widget_view = 'create';
?>
<p><?php echo elgg_echo('blog:widget:default_view'); ?> 
<?php 
  echo elgg_view('input/pulldown', array(
			'internalname' => 'params[view]',
			'options_values' => array('create' => elgg_echo('blog:widget:default'),
									  'publish' => elgg_echo('blog:widget:compact'),
             ),
			'value' => $widget_view
));
?></p>
