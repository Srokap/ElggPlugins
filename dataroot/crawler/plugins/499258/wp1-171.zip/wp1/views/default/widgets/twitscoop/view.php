<?php

    // Get the default refresh rate
    $defaultTwitScoopRefreshRate = intval(get_plugin_setting('defaultTwitScoopRefreshRate', 'twitscoop'));

    // if no value then the admin didn't set a value, so default to an hour    
    if (! $defaultTwitScoopRefreshRate)
        $defaultTwitScoopRefreshRate = 3600000;
    
    /* Set the actual refresh rate, if the user hasn't specified one, for example
     if this is the first time that they have used the widget, use the default setting */
    $actualRefreshRate = ($vars['entity']->twitscooprefreshrate)? $vars['entity']->twitscooprefreshrate : $defaultTwitScoopRefreshRate;
?>
<script language="javascript" type="text/javascript">
	
	function refreshPanel(firstTime)
	{
        if (false == firstTime) {
		    $('#twitscoopiframe')[0].src = $('#twitscoopiframe')[0].src;
        }
        
        <?php if (intval($actualRefreshRate) > 0) {
		    echo " twitscoopTimer = setTimeout('refreshPanel(false)', " . $actualRefreshRate .");";
        }
        else
        {
            echo " clearTimeout(twitscoopTimer)";
        } ?>    
	}
	
	refreshPanel(true);
    
    
	
</script>

<div align="center">

<iframe style="height:300px;width:280px;" id="twitscoopiframe" frameborder="0" src="http://www.twitscoop.com/widget.html"></iframe>
</div>

