<p>
<br />
<h3><?php echo elgg_echo('skypeme:widget:defaultrefreshrate'); ?>: </h3>
<?php
        $defaultSkypeMeRefreshRate = ($vars['entity']->defaultSkypeMeRefreshRate) ? $vars['entity']->defaultSkypeMeRefreshRate : 3600000;
        
        $defaultSkypeMeRefreshRateOptions = array(
            'internalname' => 'params[defaultSkypeMeRefreshRate]', 
            'value' => $defaultSkypeMeRefreshRate,
            'options_values' => array(-1 => elgg_echo("skypeme:widget:options:norefresh"),
                    15000 => elgg_echo("skypeme:widget:options:15seconds"),
                    30000 => elgg_echo("skypeme:widget:options:30seconds"),
                    60000 => elgg_echo("skypeme:widget:options:60seconds"),
                    3600000 => elgg_echo("skypeme:widget:options:1hour"),
                    10800000 => elgg_echo("skypeme:widget:options:3hours")
            )
        );
       
        echo elgg_view('input/pulldown', $defaultSkypeMeRefreshRateOptions);
?>
</p>
<br />