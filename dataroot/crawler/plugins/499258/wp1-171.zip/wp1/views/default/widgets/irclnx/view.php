<?php
	/**
	 * Elgg irclnx plugin
	 * This is a funny plugin which allows users to calculate love percentages. Just created it for fun :)
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author B Man <bman@duuit.com>
	 * @copyright Duuit! @ duuit.com 2008
	 * @link http://duuit.com/
	 */
$lnxurl = "http://irclnx.com/api/toplnx.php";
function getRemoteHTML($url){
        if(ini_get('allow_url_fopen')){
                $handle = fopen($url,"r");
                $html = "";
                while(!feof($handle)){
                        $html .= fgets($handle, 200);
                        //echo "$str";
                }
                fclose($handle);
                return $html;
        }
        if(function_exists('curl_init')){
                $timeout = 10000;
                $html = NULL;
                $cu = curl_init ();
                curl_setopt($cu, CURLOPT_URL, $url);
                //curl_setopt($cu, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($cu, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt ($cu, CURLOPT_HEADER, 0);
                curl_setopt ($cu, CURLOPT_TIMEOUT, $timeout);
                $html = curl_exec($cu);
                curl_close ($cu);
                return $html;
        }
        return 'Warning: unable to retrieve data, failed to use fopen and curl.';
}


	 ?>
     
<!-- irclnx -->
<div class="contentWrapper" style="height:300px;">
<?php if(isloggedin()){ ?>
<div class="irclnx-content"><?php getRemoteHTML($lnxurl); ?></div>
<iframe id="irclnx" name="irclnx" frameborder=0 verticalborder=no horizontalborder=0 width="100%" height="100%" marginwidth=0 marginheight=0 hspace=0 vspace=0 src="http://irclnx.com/api/toplnx.php"/></iframe>
<!-- irclnx -->
<?php } ?>
</div>

