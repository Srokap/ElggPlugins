<?php
    
        /**
         * Elgg whosamungus Plugin
         *
         * @package whosamungus
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author B Man
         * @copyright Duuit 2009
         * @link http://duuit.com/
         *
         */
         

?>

<!-- whosamungus -->

<div class="contentWrapper user_settings">
<?php echo '
<div style="width:266px;text-align:center;margin:0;padding:0;"><embed src="http://widgets.amung.us/flash/v2map.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="transparent" allowScriptAccess="always" allowNetworking="all" type="application/x-shockwave-flash" flashvars="wausitehash=dufpagqdmgj6&map=night&pin=spinner-red&link=no" width="266" height="133" /><div style="width:266px;height:133px;position:relative;margin:0 auto;margin-top:-133px;"><a target="_blank" href="http://whos.amung.us/stats/dufpagqdmgj6/"><img src="http://maps.amung.us/ping/dufpagqdmgj6.gif" border="0" width="266" height="133" /></a></div></div>
'; ?>
<!--  <?php echo $vars['entity']->whosamungus; ?> -->

<?php
//$input = "" . $vars['entity']->whosamungus;
   // below is the tags that you want to allow, i added the html basic tags to be allowed to use
//   echo strip_tags($input, "<h1><h2><h3><h4><h5><h6><p><a><img><font><table><tr><td><style><ul><li><ol><div><center><form><hr><i><b><u><small><span><input><textarea><input><select><option><br><caption><th><object><strike><strong><iframe><div><embed>");
   
?>

<!-- whosamungus -->

</div>

