<?php

        /**
         * Elgg whosamungus Plugin
         *
         * @package whosamungus
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author B Man
         * @copyright Duuit 2009
         * @link http://duuit.com/
         *
         */

//<p>
//Add code or text you want to appear in this box. <br /> (HTML is enabled)
//</p>

//<p><b>MyBox:</b><br />
//<textarea name="params[whosamungus]" rows="15" cols="24"><php  //echo htmlentities($vars['entity']->whosamungus); ></textarea>
//</p>
        
?>
