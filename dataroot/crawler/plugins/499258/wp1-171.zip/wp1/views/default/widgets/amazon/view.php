<?php     
    /**
     * Amazon Wish List Widget - View Widget Script
 	 * @package mod\amazon
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Robert S. Robbins <rober@williamsportwebdeveloper.com>
	 * @copyright Williamsport Web Developer 2009
	 * @link http://www.williamsportwebdeveloper.com/
	 *
	 * Requires PHP XSL  
     **/

// need a library to make a signed request
require_once('aws_signed_request.inc');
// Some required params. 
// Obtain an access key at: http://www.amazon.com/gp/aws/registration/registration-form.html
define("ACCESS_KEY", "20 digit code");
define("SECRET_KEY", "40 digit code");
// Get the list id from the web address on Amazon. 
// Example: http://www.amazon.com/gp/registry/wishlist/12S9629PIWFHP/ref=cm_wl_rlist_go
// List ID is the value after wishlist: 12S9629PIWFHP 
$ListID = $vars['entity']->ListID;

// If the ListIDis empty, then do not show the wish list    
if($ListID) { 
	$arr = array("Service" => "AWSECommerceService", "Version" => "2009-03-31", "Sort" => "DateAdded", "Operation" => "ListLookup", "ResponseGroup" => "ItemAttributes,ListItems,ListInfo,Images", "ListType" => "WishList", "ListId" => $ListID);
	$strXml = aws_signed_request("com", $arr, ACCESS_KEY, SECRET_KEY);
	
	// Load the XSL file to transform the XML from Amazon
	$xsl = new DOMDocument;
	$xsl->load($CONFIG->wwwroot . 'mod/wp1/vendors/AmazonWishList.xsl');
	// Create an XML document from the string
	$xmlDoc = new DOMDocument;
	$xmlDoc->loadXML($strXml);
	
	// Transform the XML to HTML using XSL
	$proc = new XSLTProcessor;
	$proc->importStyleSheet($xsl);
	echo $proc->transformToXML($xmlDoc);
}else{    
    elgg_echo("amazon:notset");    
}
?>
