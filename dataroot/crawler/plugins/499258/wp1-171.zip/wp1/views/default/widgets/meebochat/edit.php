<?php




	/**

	 * 

	 * @package meebochat

	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2

	 * @author Malaga Jack

	 * @copyright malagajack 2009

	 * @link http://fbfkids.com/

	 * 

	 */


?>

Put your Chat room id here
<input name="params[meeboid]" type="text" value="QhUAliCBQF">
<br><h6><a href="http://fbfkids.com" title="FBFKids" target="_blank"><span style="text-decoration:none;color:#400000;">       Courtesy of FBFKids</span></a><br></h6>
<br>
<br><br>
<a href="http://fbfkids.com/folder/mychatwidget/index.html" title="Chatroom ID" target="_blank"><span style="text-decoration:none;color:#400000;">How to get your own chatroom id</span></a><br>
<br><br><br>
<br>




	