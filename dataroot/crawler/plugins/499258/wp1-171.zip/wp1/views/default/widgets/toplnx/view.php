<?php
                $username = $vars['entity']->username;
                $numlnx = $vars['entity']->num_display;
?>

<!-- toplnx -->
<div class="contentWrapper user_settings" style="height:300px;">
<!--  <?php echo $vars['entity']->toplnx; ?> -->
<?php 
if($username == "") { echo "Edit Settings and choose your username on irclnx for this plugin to operate."; } else {
echo $username;
echo "'s top $numlnx lnx<hr>";?>

<iframe id="toplnxbyuser" name="toplnxbyuser" frameborder=0 verticalborder=no horizontalborder=0 width="100%" height="95%" marginwidth=0 marginheight=0 hspace=0 vspace=0 src="http://irclnx.com/api/toplnxbyuser.php?username=<?php echo $username; ?>&numlnx=<?php echo $numlnx; ?>"/></iframe>
<!-- toplnxbyuser -->
</div>

<?php } ?>
