<?php

	/**
	 * Elgg Last.Fm Widget
	 * 
	 * @package ElggLast.Fm
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Sergio De Falco aka SGr33n <sgr33n@ircaserta.com>
	 * @copyright Sergio De Falco aka SGr33n 2009
	 * @link http://www.ircaserta.com/
	 */

?>

ul#lastfmsonglist {
	margin: 0;
	padding: 2px 0 2px 0;
	line-height: 100%;
}
ul#lastfmsonglist li {
	margin-left: 5px;
	margin-bottom: 4px;
}