<?php
    
        /**
         * Elgg vulcan Plugin
         *
         * @package vulcan
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author B Man
         * @copyright Duuit 2009
         * @link http://duuit.com/
         *
         */
         

?>

<div class="contentWrapper">
<?php echo "<iframe id=vulcan name=vulcan width=\"100%\" scrolling=no frameborder=0 src=\"http://www.vulcanradio.nl/webplayer\" /></iframe>"; ?>
</div>

