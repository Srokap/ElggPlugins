<?php

/**
 * Elgg RP Playlist plugin edit page
 *
 * @package Radio Paradise Playlist
 * @license GNU General Public License (GPL) version 2
 * @author Michael Holm, Pixel Brothers Interactive <holm@pixbros.com>
 * @copyright Pixel Brothers Interactive 2009
 * @link http://pixbros.com/
 */

 // how many songs does the user wants to display?
 $limit = $vars['entity']->limit;
 //if no number has been set, default to 5
 if(!$limit) $limit = 5;

?>
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/radioparadise/views/default/widgets/playlist/js/jfeed/build/dist/jquery.jfeed.pack.js"></script>

<script type="text/javascript">
	jQuery.getFeed({
	       url: '<?php echo $vars['url']; ?>mod/radioparadise/views/default/widgets/playlist/js/jfeed/feed.php',
	       success: function(feed) {
			jQuery('#result').append('<h2>' + '<a href="' + feed.link + '">' + feed.title + '</a>' + '</h2>');

            var html = '';

            for(var i = 0; i < feed.items.length && i < <?php echo $limit; ?>; i++) {

                var item = feed.items[i];

                html += '<h4>' + '<a href="' + item.link + '">' + item.title + '</a>' + '</h4>';

                html += '<div>' + item.description + '</div>';
            }
				jQuery('#rpplaylist').append(html);
	       }
	   });
</script>
<div id="rpplaylist">
<h3>Last <?php echo $limit ?> songs</h3>
</div>

