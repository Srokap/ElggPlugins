<p>
<div style="text-align:center">
<div align="center" style="width: 95%; margin-top: 20px;">
<?php 
$username = $vars['username'];
$msnmeset = $vars['config']->site->msnme;
?>
<iframe src="http://settings.messenger.live.com/Conversation/IMMe.aspx?invitee=<?php echo $username[0];?>@apps.messenger.live.com&mkt=<?php echo $msnmeset[17]?>&useTheme=true&themeName=orange&foreColor=<?php echo $msnmeset[16]?>&backColor=<?php echo $msnmeset[15]?>&linkColor=<?php echo $msnmeset[14]?>&borderColor=<?php echo $msnmeset[13]?>&buttonForeColor=<?php echo $msnmeset[12]?>&buttonBackColor=<?php echo $msnmeset[11]?>&buttonBorderColor=<?php echo $msnmeset[10]?>&buttonDisabledColor=<?php echo $msnmeset[9]?>&headerForeColor=<?php echo $msnmeset[8]?>&headerBackColor=<?php echo $msnmeset[7]?>&menuForeColor=<?php echo $msnmeset[6]?>&menuBackColor=<?php echo $msnmeset[5]?>&chatForeColor=<?php echo $msnmeset[4]?>&chatBackColor=<?php echo $msnmeset[3]?>&chatDisabledColor=<?php echo $msnmeset[2]?>&chatErrorColor=<?php echo $msnmeset[1]?>&chatLabelColor=<?php echo $msnmeset[0]?>" width="100%" height="400" style="border: solid 1px black; width: 100%; height: 400px;" frameborder="0"></iframe></div></div>
</p>