<?php

    /**
	 * Elgg myspace edit page
	 *
	 * @package Elggmyspace
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dhrup Chand <dhrup2000@gmail.com>
	 * @copyright Dhrup Chand & Curverider Ltd 2008-2009
	 * @link http://www.ensci.us
	 */

?>
	<p>
		<?php echo elgg_echo("myspace:username"); ?>
		<input type="text" name="params[myspace_username]" value="<?php echo htmlentities($vars['entity']->myspace_username); ?>" />	
		<br /><?php echo elgg_echo("myspace:num"); ?>
		<input type="text" name="params[myspace_num]" value="<?php echo htmlentities($vars['entity']->myspace_num); ?>" />	
	</p>
