    <p>
    <?php echo elgg_echo('skypeme:widget:action:message'); 
    
    // if the user hasn't previously set an action, use the default of Chat.
    $skypeMeAction = ($vars['entity']->skypeMeAction) ? $vars['entity']->skypeMeAction : 'chat';
        $skypeMeActionOptions = array(
            'internalname' => 'params[skypeMeAction]', 
            'value' => $skypeMeAction,
            'options_values' => array('chat' => elgg_echo("skypeme:widget:options:action:chat"),
                    'call' => elgg_echo("skypeme:widget:options:action:call"))
        );
       
        echo elgg_view('input/pulldown', $skypeMeActionOptions);
?>
    
    </p>
    
    <p>
    
    <?php echo elgg_echo('skypeme:widget:showskypestatus'); 
    
    // if the user hasn't previously select whether to show their stats, use the default of yes.
    $skypeMeShowStatus = ($vars['entity']->skypeMeShowStatus) ? $vars['entity']->skypeMeShowStatus : 'yes';
        $skypeMeShowStatusOptions = array(
            'internalname' => 'params[skypeMeShowStatus]', 
            'value' => $skypeMeShowStatus,
            'options_values' => array('yes' => elgg_echo("skypeme:widget:showskypestatus:options:yes"),
                    'no' => elgg_echo("skypeme:widget:showskypestatus:options:no"))
        );
       
        echo elgg_view('input/pulldown', $skypeMeShowStatusOptions);
?>
    
    </p>
    
    <p>
    
    <?php echo elgg_echo("skypeme:widget:refreshratemessage");
    
    // Get the default refresh rate
    $defaultSkypeMeRefreshRate = intval(get_plugin_setting('defaultSkypeMeRefreshRate', 'skypeme'));    
    
    // if no value then neither the admin nor the user set a value, so default to an hour    
    if (! $defaultSkypeMeRefreshRate)
        $defaultSkypeMeRefreshRate = 3600000;
    
    // if the user hasn't previously set a refresh rate, use the default one.
    $skypeMeRefreshRate = ($vars['entity']->skypeMeRefreshRate) ? $vars['entity']->skypeMeRefreshRate : $defaultSkypeMeRefreshRate;
        $skypeMeRefreshRateOptions = array(
            'internalname' => 'params[skypeMeRefreshRate]', 
            'value' => $skypeMeRefreshRate,
            'options_values' => array(-1 => elgg_echo("skypeme:widget:options:norefresh"),
                    15000 => elgg_echo("skypeme:widget:options:15seconds"),
                    30000 => elgg_echo("skypeme:widget:options:30seconds"),
                    60000 => elgg_echo("skypeme:widget:options:60seconds"),
                    3600000 => elgg_echo("skypeme:widget:options:1hour"),
                    10800000 => elgg_echo("skypeme:widget:options:3hours")
            )
        );
       
        echo elgg_view('input/pulldown', $skypeMeRefreshRateOptions);
        ?>
        </p>
        <p>
        <?php 
        echo elgg_echo("skypeme:widget:showskypestatus:refreshmessage");
        
        ?>
    </p>
    <p>
	
		<label><?php echo elgg_echo("skypeme:widget:skypeusername");?></label>
        <?php 
        $skypeUserName = ($vars['entity']->skypeUserName)?$vars['entity']->skypeUserName:"";
        echo elgg_view('input/text',array(
                                'internalname' => 'params[skypeUserName]',
                                'value' => $skypeUserName)
                                );
                                
        ?> 
    </p>
    <?php echo elgg_echo("skypeme:widget:webstatuswarning")?><a href="http://www.skype.com/share/buttons/status.html" target="new">How to show your Skype status on the web</a>

    
