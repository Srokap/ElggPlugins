	<p>
	
	<?php echo elgg_echo("twitscoop:widget:refreshratemessage"); ?>
	<br />
	<br />
	
	<?php
	echo elgg_echo("twitscoop:widget:refreshrate");
    // Get the default refresh rate
    $defaultTwitScoopRefreshRate = intval(get_plugin_setting('defaultTwitScoopRefreshRate', 'twitscoop'));	
    
    // if no value then neither the admin nor the user set a value, so default to an hour    
    if (! $defaultTwitScoopRefreshRate)
        $defaultTwitScoopRefreshRate = 3600000;
    
    // if the user hasn't previously set a refresh rate, use the default one.
    $twitscooprefreshrate = ($vars['entity']->twitscooprefreshrate) ? $vars['entity']->twitscooprefreshrate : $defaultTwitScoopRefreshRate;
        $twitScoopRefreshRateOptions = array(
            'internalname' => 'params[twitscooprefreshrate]', 
            'value' => $twitscooprefreshrate,
            'options_values' => array(-1 => elgg_echo("twitscoop:widget:options:norefresh"),
                    15000 => elgg_echo("twitscoop:widget:options:15seconds"),
                    30000 => elgg_echo("twitscoop:widget:options:30seconds"),
                    60000 => elgg_echo("twitscoop:widget:options:60seconds"),
                    3600000 => elgg_echo("twitscoop:widget:options:1hour"),
                    10800000 => elgg_echo("twitscoop:widget:options:3hours")
            )
        );
       
        echo elgg_view('input/pulldown', $twitScoopRefreshRateOptions);
?>    
    </p>
    

    
