<?php

    // Get the default refresh rate
    $defaultSkypeMeRefreshRate = intval(get_plugin_setting('defaultSkypeMeRefreshRate', 'skypeme'));

    // if no value then the admin didn't set a value, so default to an hour    
    if (! $defaultSkypeMeRefreshRate)
        $defaultSkypeMeRefreshRate = 3600000;
    
    /* Set the actual refresh rate, if the user hasn't specified one, for example
     if this is the first time that they have used the widget, use the default setting */
    $actualRefreshRate = ($vars['entity']->skypeMeRefreshRate)? $vars['entity']->skypeMeRefreshRate : $defaultSkypeMeRefreshRate;
    
    // Has the user selected an action?  If not, it should be 'Skype Chat'
    $skypeMeAction = ($vars['entity']->skypeMeAction)? $vars['entity']->skypeMeAction : 'chat';
    
    //  Has the user selected an Status option? If not, it should be show status
    $skypeMeShowStatus = ($vars['entity']->skypeMeShowStatus)? $vars['entity']->skypeMeShowStatus : 'yes';
    
    $skypeme_username = ($vars['entity']->skypeUserName)? $vars['entity']->skypeUserName: "";
	 
	if ("" == $skypeme_username)
        echo "<div class=\"contentWrapper\"><p>" . elgg_echo("skypeme:widget:usernameerror") . ".</p></div>";  
	else
	{ 
        $skypeCode = getSkypeCode($skypeme_username, $skypeMeAction, $skypeMeShowStatus);
        ?>
		<div align="center">
		<!--
		Skype 'My status' button
		http://www.skype.com/go/skypebuttons
		-->
		<script type="text/javascript" src="http://download.skype.com/share/skypebuttons/js/skypeCheck.js"></script>
        <?php echo $skypeCode;?>
        </div>


<script language="javascript" type="text/javascript">
    
    function refreshSkypeMePanel(firstTime)
    {
      
        if (false == firstTime) {
            $('#skypemebutton')[0].src = "<?php echo getSkypeImageURL($skypeme_username, $skypeMeAction, $skypeMeShowStatus);?>?date=" + (new Date()).getTime();
        }
        
        <?php if (intval($actualRefreshRate) > 0) {
            echo " skypeMeTimer = setTimeout('refreshSkypeMePanel(false)', " . $actualRefreshRate .");";
        }
        else
        {
            echo " clearTimeout(skypeMeTimer)";
        } ?>    
    }
    
    <?php 
    // Only refresh if Status is shown.
    if ('yes' == $skypeMeShowStatus)
    { ?>
        refreshSkypeMePanel(true);
    <?php } ?>

</script>

<?php } ?> 