<?php

/**
 * Elgg newestmembers widget
 *
 * @package newestmembers
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License version 2
 * @author JBMc
 * @copyright Copyright (c) 2009 Innovative Computer Services & Soltuions
 * @link http://websites.icssinc.com
 *
 */
	 
?>

<p>
	<?php echo elgg_echo("newestmembers:withpicsonly"); ?>:
	<select name="params[withpicsonly]">
		<option value="0" <?php if($vars['entity']->withpicsonly == 0) echo "SELECTED"; ?>>No</option>
		<option value="1" <?php if($vars['entity']->withpicsonly == 1) echo "SELECTED"; ?>>Yes</option>
	</select>
</p>

<p>
		<?php echo elgg_echo("newestmembers:num_display"); ?>:
		<select name="params[num_display]">
			<option value="5" <?php if($vars['entity']->num_display == 5) echo "SELECTED"; ?>>5</option>
			<option value="10" <?php if($vars['entity']->num_display == 10) echo "SELECTED"; ?>>10</option>
			<option value="15" <?php if($vars['entity']->num_display == 15) echo "SELECTED"; ?>>15</option>
			<option value="20" <?php if($vars['entity']->num_display == 20) echo "SELECTED"; ?>>20</option>
			<option value="25" <?php if($vars['entity']->num_display == 25) echo "SELECTED"; ?>>25</option>
		</select>
</p>
