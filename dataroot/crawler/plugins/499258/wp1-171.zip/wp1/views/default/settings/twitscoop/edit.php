<p>
<br />
<h3><?php echo elgg_echo('twitscoop:widget:defaultrefreshrate'); ?>: </h3>
<?php
        $defaultTwitScoopRefreshRate = ($vars['entity']->defaultTwitScoopRefreshRate ? $vars['entity']->defaultTwitScoopRefreshRate : 3600000);
        $defaultTwitScoopRefreshRateOptions = array(
            'internalname' => 'params[defaultTwitScoopRefreshRate]', 
            'value' => $defaultTwitScoopRefreshRate,
            'options_values' => array(-1 => elgg_echo("twitscoop:widget:options:norefresh"),
                    15000 => elgg_echo("twitscoop:widget:options:15seconds"),
                    30000 => elgg_echo("twitscoop:widget:options:30seconds"),
                    60000 => elgg_echo("twitscoop:widget:options:60seconds"),
                    3600000 => elgg_echo("twitscoop:widget:options:1hour"),
                    10800000 => elgg_echo("twitscoop:widget:options:3hours")
            )
        );
       
        echo elgg_view('input/pulldown', $defaultTwitScoopRefreshRateOptions);
?>
</p>
<br />&nbsp;<br />