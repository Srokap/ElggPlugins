.river_item p.tags {
	background:transparent url(<?php echo $vars['url']; ?>_graphics/icon_tag.gif) no-repeat scroll left 2px;
	margin:0pt 0pt 0pt 20px;
	min-height:22px;
	padding:0pt 0pt 0pt 16px;
}