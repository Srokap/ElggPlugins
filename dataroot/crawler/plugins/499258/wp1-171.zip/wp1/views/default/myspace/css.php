<?php
 
    /**
	 * Elgg MySpace CSS
	 * 
	 * @package ElggMySpace
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 *
	 * Dhrup Chand 2009-03-26: copied from Elff Twitter CSS,
	 *                         Made minor changes for MySpace widget.
     */
     
?>

#myspace_widget {
    margin:0 10px 0 10px;
}

#myspace_widget ul {
	margin:0;
	padding:0;
}

#myspace_widget li {
	background: url(<?php echo $vars['url']; ?>mod/wp1/_graphics/thewire_speech_bubble.gif) left no-repeat;
	list-style-image:none;
	list-style-position:outside;
	list-style-type:none;
    padding:0 0 0 20px;
    margin:0;
	overflow-x: hidden;
}

#myspace_widget li span {
	color:#666666;
	background:white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding:5px;
	display:block;
}

p.visit_myspace a {
    background:url(<?php echo $vars['url']; ?>mod/wp1/_graphics/myspace.jpg) left no-repeat;
    padding:0 0 0 20px;
    margin:0;
}

.visit_myspace {
	background:white;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
	padding:2px;
	margin:0 0 5px 0;
}

#myspace_widget li a {
	display:block;
	margin:0 0 0 4px;
}

#myspace_widget li span a {
	display:inline !important;
}
