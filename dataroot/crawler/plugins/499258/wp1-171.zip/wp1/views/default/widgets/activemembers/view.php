<?php
include($CONFIG->path."/mod/wp1/vendors/lib.php") ;
$size_value = "small";
$maxusers = 18;
?>
<div class="contentWrapper">

<?php
   $users = getActiveMembers();

echo "<div>";
foreach (array_keys($users) as $userid) {
  $count++;
  echo "<div class=\"widget_friends_singlefriend\" >";
  echo elgg_view("profile/icon",array('entity' => get_user($userid), 'size' => $size_value));
  echo "</div>";
  if ($count == $maxusers)
    break;
}
echo "<div class=\"clearfloat\"></div>";
echo "</div>";

?>

</div>
