<div class="index_box">
   <h2><?php echo elgg_echo("activemembers:title"); ?></h2>
   <div class="contentWrapper">

<?php
include($CONFIG->path."/mod/wp1/vendors/lib.php") ;

$users = getActiveMembers();
$size_value = "small";
$maxusers = 18;

if($users){
  foreach(array_keys($users) as $userid){
    $count++;
    $user = get_user($userid);
    echo "<div class=\"index_members\">";
    echo elgg_view("profile/icon",array('entity' => $user, 'size' => $size_value));
    echo "</div>";
    if ($count == $maxusers)
      break;
  }
 }
?>
<div class="clearfloat"></div>
</div>
</div>
