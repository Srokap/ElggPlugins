<?php

/**
 * Elgg newestmembers widget
 *
 * @package newestmembers
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License version 2
 * @author JBMc
 * @copyright Copyright (c) 2009 Innovative Computer Services & Soltuions
 * @link http://websites.icssinc.com
 *
 */

// The number of members to display
$num = (int) $vars['entity']->num_display;
if (!$num)
	$num = 10;

// Only display members with a picture profile
$picsonly = (int) $vars['entity']->withpicsonly;
if (!$picsonly)
	$picsonly = 0;

if($picsonly)
	$users = get_entities_from_metadata('icontime', '', 'user', '', 0, $num);
else
	$users = get_entities('user', '', 0, '', $num, 0, false, 0, null);

if($users){
	echo "<div id=\"widget_friends_list\">";
	foreach($users as $user){
		echo "<div class=\"member_icon\">" . elgg_view("profile/icon",array('entity' => $user, 'size' => 'small')) . "</div>";  
	}
	echo "</div>";
}
?>
