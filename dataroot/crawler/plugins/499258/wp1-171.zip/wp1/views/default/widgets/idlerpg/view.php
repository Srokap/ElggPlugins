<?php
    
        /**
         * Elgg idlerpg Plugin
         *
         * @package idlerpg
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author B Man
         * @copyright Duuit 2009
         * @link http://duuit.com/
         *
         */
         

?>

<!-- idlerpg -->

<?php echo '
<div class="contentWrapper" style="height:430px;">
<iframe id="idlerpg" name="idlerpg" frameborder=0 verticalborder=no horizontalborder=0 width="100%" height="100%" marginwidth=0 marginheight=0 hspace=0 vspace=0 src="
http://imrryr.stonedworld.net/idlerpg/playersext.php"/></iframe>
</div>';
 ?>
<!--  <?php echo $vars['entity']->idlerpg; ?> -->

<!-- idlerpg -->

</div>

