<?php
	/**
	 * View group_feed widget
	*/

	$group_guid = $vars['entity']->group; 
	
if ($group_guid){	

 	$objects = get_entities("object", "", $group_guid , 'time_updated desc', 10, 0, false, 0,  $group_guid );
	$group_entity = get_entity($group_guid);

	echo '<div style="text-align:center;background:#ffffcc; padding:3px; margin-bottom:3px; "><a href="' . $group_entity->getURL() . '">' . $group_entity->name . '</a> Feed</div>';
    
	foreach ($objects as $bp) {
        $owner = $bp->getOwnerEntity();
        $friendlytime = friendly_time($bp->time_updated);
		$subtype = $bp->getSubType();
		
		// this array specifies the subtype in a more natural name
		$sub_array = array(
			blog => 'Blog',
			page => 'Page',
			page_top => 'Page',
			file => 'File',
			bulletin => 'Bulletin',
			groupforumtopic => 'Forum Topic',
		);
		// this array is used to show different icons to the left based on subtype
		//currently there is not unique icons for all types so i reuse "file"
		$icon_array = array(
			blog => 'blog',
			page => 'file',
			page_top => 'file',
			file => 'file',
			bulletin => 'file',
		);
		
		//for both above mentioned arrays , you will need to include any new
		//subtypes that are included in your elgg network.
		
		$info ='<div class="river_item">';
		
		if($subtype == 'groupforumtopic' )
			$info .= "<p class=\"river_forums_create\"><a href=\"/mod/groups/topicposts.php?topic={$bp->guid}&group_guid={$bp->container_guid}\">{$bp->title}</a><br>";
		else
			$info .= "<p class=\"river_{$icon_array[$subtype]}_create\"><a href=\"{$bp->getURL()}\">{$bp->title}</a><br>";
        
		$info .= "<b>{$sub_array[$subtype]}</b> by <a href=\"{$owner->getURL()}\">{$owner->name}</a> <span class=\"river_item_time\">({$friendlytime})</span></p>";
       
		$info .= "</div>\n";
		
		echo $info;
    }
}
else{
	$info = elgg_echo('groups:widgets:feed:label:pleaseedit');
	echo $info;
}

	
?>