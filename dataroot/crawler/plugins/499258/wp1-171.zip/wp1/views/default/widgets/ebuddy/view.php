<?php    
	/**
	 * Elgg eBuddy Messenger plugin
	 * 
	 * @package
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Matthias Sutter email@matthias-sutter.de
	 * @copyright CubeYoo.de
	 * @link http://cubeyoo.de
	 */
?>
<style type="text/css">
iframe.sample{
  width:210px;
  height:260px;  
  margin-left: 20px;
}
</style>
<?php 
$url=$vars['url']."mod/wp1/vendors/ebuddy.php";
?>
<div class="contentWrapper"> 
<iframe id="sample" class="sample" scrolling="No"  class="ebuddy_iframe" src='<?php echo $url;?>'></iframe>
</div>
