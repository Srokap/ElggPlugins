<?php

        /**
         * Elgg Doodle Plugin
         *
         * @package Doodle
         * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
         * @author Cim
         * @copyright DEMYX 2009
         * @link http://demyx.com/
         *
         */

?>

<p>
Add code or text you want to appear in this box. <br /> (HTML is enabled)
</p>

<p><b>MyBox:</b><br />
<textarea name="params[doodle]" rows="15" cols="24"><?php echo htmlentities($vars['entity']->doodle); ?></textarea>
</p>
        
