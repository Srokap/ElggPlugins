<?php
	 ?>
<div class="content" style="height:1525px;">
<div id="two_column_left_sidebar_maincontent" style="width:95%;">

<DIV align="center" class="contentWrapper" style="width:98%; height:1520px;">
<iframe frameborder=0 width="95%" height="95%" src="http://irclnx.com/lnxapi.php"></iframe>

  </DIV></div></div>

