<?php

    

	/**

	 * 

	 * @package meebochat

	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2

	 * @author Malaga Jack

	 * @copyright malagajack 2009

	 * @link http://fbfkids.com/

	 * 

	 */

	 



?>

<div style="width:300px"> 
<style>.mcrmeebo { display: block; background:url("http://widget.meebo.com/r.gif") no-repeat top right; } .mcrmeebo:hover { background:url("http://widget.meebo.com/ro.gif") no-repeat top right; } 
</style>
<object width="300" height="350">
<param name="movie" value="http://widget.meebo.com/mcr.swf?id=<?php echo $vars['entity']->meeboid; ?>"></param>
<embed src="http://widget.meebo.com/mcr.swf?id=<?php echo $vars['entity']->meeboid; ?>" 
type="application/x-shockwave-flash" width="300" height="350" />
</object>






