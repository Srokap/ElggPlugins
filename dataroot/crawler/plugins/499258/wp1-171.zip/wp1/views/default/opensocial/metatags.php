<?php

	/**
	 * Adds metatags to load Javascript required for OpenSocial gadgets
	 * 
	 * @package OpenSocial
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Kevin Jardine <kevin@radagast.biz>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 * 
	 */
	 
	 // all dumped in here because there is no way to pass variables when extending a view
	 
	 $xml = 'compliancetests.xml';
	 
	 $js = $vars['url'].'mod/wp1/vendors/javascript/container';
     $fjs = $vars['url'].'mod/wp1/vendors/shindig/src/gadgets/js/rpc';
	 
	 $header = <<<END
<script type="text/javascript" src="$fjs/rpc.js?c=1&debug=1"></script>
<script type="text/javascript" src="$js/util.js"></script>
<script type="text/javascript" src="$js/gadgets.js"></script>
<script type="text/javascript" src="$js/loadstuff.js"></script>
<script type="text/javascript" src="$js/cookies.js"></script>
<script type="text/javascript" src="$js/cookiebaseduserprefstore.js"></script>
END;
    echo $header;

?>
