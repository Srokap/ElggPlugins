<div class="contentWrapper user_settings" style="height:195px;">

<!-- stickam start -->

<?php // if username is not set, display the message box instead of video
if($vars['entity']->username == "") { 
	$error = elgg_echo('stickam:error'); 
	$signup = elgg_echo('stickam:signup'); 
	echo "$error<br/><a target='_blank' href='http://stickam.com/sign_up'>$signup</a>"; } else {

// display video 
// userid 178484919
// player style 11230785

$playerid1 = "11230785"; //160x160
$playerid = "11230814"; //340x290
$playerid3 = "11230885"; //160x400
$playerid4 = "11230482"; //160x400
?>
<div align=center>
<embed src="http://player.stickam.com/stickamPlayer/<?php echo $vars['entity']->username; ?>-<?php echo $playerid; ?>" type="application/x-shockwave-flash" wmode="transparent" width="160" height="160" scale="noscale" allowScriptAccess="always" allowFullScreen="true"></embed>
</div>
<!-- stickam end -->

</div>

<?php } ?>
