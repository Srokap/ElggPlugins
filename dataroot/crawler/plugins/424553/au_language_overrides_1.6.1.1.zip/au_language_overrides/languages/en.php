<?php

/**
 * AU language overrides
 * 
 * @author Brian Jorgensen (brianj@athabascau.ca)
 * @copyright 2010 Brian Jorgensen
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 */

$english = array (

// CHANGES

    // embed
    'embed:title' => 'Embed My File / Upload a File',

    // embed and welcomer
    'media:insert' => 'Embed My File / Upload a File',

    // custom_index_widgets
    'custom_index_widgets:latest_wire_index' => 'Latest wire posts',


// TYPOS

    // custom_index_widgets
    'custom_index_widgets:latest_events_index' => 'Incoming events',
	'custom_index_widgets:threshold'=> 'Threshold',
	'custom_index_widgets:rich_media_index' => 'Multimedia content',

	
	// welcomer
	'welcomer:message:switchmessage' => 'Activate / Deactivate login messages',
	'welcomer:message:desactivate' => 'Deactivate',
	'welcomer:desactivate' => 'Deactivate',
	'welcomer:message:check_message' => 'I have read the above and I agree',
	'welcomer:mandatory:message' => 'Please click the checkbox if you agree',


// MISSING

    // custom_index_widgets
    'custom_index_widgets:showdashboard' => 'Show dashboard',
    'custom_index_widgets:showdashboard_no' => 'No',
	'custom_index_widgets:showdashboard_yes' => 'Yes',

);

add_translation('en', $english);