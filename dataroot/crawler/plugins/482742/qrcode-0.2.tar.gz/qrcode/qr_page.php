<?php

  // Load Elgg engine
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

global $CONFIG;

$img = $CONFIG->wwwroot . 'mod/qrcode/qr_img.php?' . $_SERVER['QUERY_STRING'];

$dl = $img . '&download=true';

?>
<div>
<a href="<?php echo $dl; ?>">
	<img src="<?php echo $img; ?>" />
</a>
</div>
<div>
Click image to download
</div>