<?php

function qrcode_init() {

	global $CONFIG;

	// give us a link up top
	extend_view('elgg_topbar/extend', 'qrcode/topbar');
	extend_view('css', 'qrcode/css');

	// toss something in the menu
	add_menu('QR Code', $CONFIG->wwwroot . 'pg/qrcode/');

	register_page_handler('qrcode', 'qrcode_page_handler');

}

function qrcode_page_handler($page) {
	global $CONFIG;

	include($CONFIG->pluginspath . 'qrcode/index.php');

}


// Make sure the profile initialisation function is called on initialisation
register_elgg_event_handler('init','system','qrcode_init');

