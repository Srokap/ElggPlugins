/* QR Code */

#qrcodelink {
	cursor: pointer;
}

/* end QR Code */