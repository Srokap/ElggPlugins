<?php

global $CONFIG;

$img = $CONFIG->wwwroot . 'mod/qrcode/qr_img.php?d=';

$dl = $img . '&download=true';


?>
<div>
Text to encode:
<?php 
$input = elgg_view('input/text', array('internalid' => 'qrcodeinput')); 

$submit = elgg_view('input/submit', array('value' => 'Generate image'));

$form = elgg_view('input/form', array('internalid' => 'qrcodeform', 
				      'body' => $input . $submit));


echo $form;

?>

<img id="qrcodeimage" src="<?php echo $img; ?>" />

<script type="text/javascript"> 

//	$('#qrcodeinput').bind('onchange', function(event) {
	$('#qrcodeform').submit(function(event) {
					event.preventDefault();
					$('#qrcodeimage').attr('src', '<?php echo $img; ?>' + $('#qrcodeinput').attr('value'));
 	 });

</script>