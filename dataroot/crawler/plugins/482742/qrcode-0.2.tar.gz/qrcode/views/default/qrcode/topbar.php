<?php

global $CONFIG;

$uri = 'http'. ($_SERVER['HTTPS'] ? 's' : null) .'://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

$qrcode = $CONFIG->wwwroot . 'mod/qrcode/qr_page.php?d=' . urlencode($uri) . '&height=300&width=300';

$img = $CONFIG->wwwroot . 'mod/qrcode/qrcode.png';

?>
<span id="qrcodelink">
  <img src="<?php echo $img; ?>" title="Get the QR Code for this page" />
</span>
<script type="text/javascript"> 

	$('#qrcodelink').click(function() {
	   tb_show('QR Code', '<?php echo $qrcode; ?>', '');
 	 });

</script>