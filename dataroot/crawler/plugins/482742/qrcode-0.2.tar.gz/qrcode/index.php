<?php

global $CONFIG, $SESSION;

$area1 = '';
		
$area2 = elgg_view_title('QR Code');

$form = elgg_view('qrcode/form');

$area2 .= elgg_view('page_elements/contentwrapper', 
		    array('body' => $form));

$body = elgg_view_layout('two_column_left_sidebar', $area1, $area2);

page_draw('QR Code Generator', $body);


