<?php

?>
        <script type="text/javascript">
            document.forms[0].elements['username'].focus();
        </script>
