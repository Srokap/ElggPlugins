<?php
	/**
	 * Username Focus
	 * 
	 * @package username_focus
	 * @license The BSD License
	 * @author ICCNET.org
	 * @copyright ICCNET.org 2009
	 * @link http://www.iccnet.org/
	 */

	/**
	 * Initialise the kneemail plugin.
	 *
	 */
	function username_focus_init()
	{
        global $CONFIG;
        
        // extend views
		if (!isloggedin())
		{
			extend_view('page_elements/footer', 'username_focus/footer');
		}
    }
	
	// Make sure the contact_us initialisation function is called on initialisation
	register_elgg_event_handler('init','system','username_focus_init');
?>