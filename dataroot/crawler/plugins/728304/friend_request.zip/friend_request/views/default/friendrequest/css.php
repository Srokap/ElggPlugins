/*
#elgg_topbar_container_left a.new_friendrequests {
	margin:0 0 0 20px;
	color:white;
	padding:3px;
}
#elgg_topbar_container_left a.new_friendrequests:hover {
	background: #4690d6;
	text-decoration: none;
}
*/

#elgg_topbar_container_left a.new_friendrequests {
	background:transparent url(<?php echo $vars['url']; ?>mod/friend_request/graphics/icons/friendrequest.gif) no-repeat left;
	padding:0 0 0 18px;
	margin:0 15px 0 5px;
	color:white;
}

#elgg_topbar_container_left a.new_friendrequests:hover {
	text-decoration: none;
}