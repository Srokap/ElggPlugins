<?php
$english = array(
	'acceptterms:read' => "I have read the site ",
	'acceptterms:terms' => "TERMS",
	'acceptterms:accept' => " and i accept them.<br>",
	'acceptterms:required' => "You must read and accept site terms.",
);

add_translation("en",$english);