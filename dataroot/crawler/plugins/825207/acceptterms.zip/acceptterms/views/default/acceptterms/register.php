<?php
/**
 *
 */
?>
<label>
	<input type="checkbox" name="acptrms" value="true">
	<?php echo elgg_echo('acceptterms:read')."<a href=\"{$vars['url']}terms\">".elgg_echo('acceptterms:terms')."</a>".elgg_echo('acceptterms:accept'); ?>
</label><br/>