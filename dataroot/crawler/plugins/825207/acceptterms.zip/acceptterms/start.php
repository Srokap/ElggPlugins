<?php
/*******************************************************************************
 * acceptterms
 *
  ******************************************************************************/

function acceptterms_init()
{
	//global $CONFIG;

	//put the check at the very end
	elgg_extend_view('register/extend', 'acceptterms/register', 1000);

	//block user registration if they don't check the box
	elgg_register_plugin_hook_handler('action', 'register', 'acceptterms_register_hook');
}

function acceptterms_register_hook()
{
	if (get_input('acptrms',false) != 'true') {
		register_error(elgg_echo('acceptterms:required'));
		forward($_SERVER['HTTP_REFERER']);
	}
}

elgg_register_event_handler('init', 'system', 'acceptterms_init');