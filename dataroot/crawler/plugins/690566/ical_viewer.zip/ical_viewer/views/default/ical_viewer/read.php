<?php
  require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/vendors/iCalcreator.class.php');  // iCal class library
  
  if ($entity = $vars['entity']) {
    // Paramètres passés à cette vue
    $title = $entity['title'];
    $calendar = $entity['url'];
    $timeframe_before = $entity['timeframe_before'];
    $timeframe_after = $entity['timeframe_after'];
    $num_items = $entity['num_items'];
  }

  /* Paramètres par défaut du plugin */
  if (!isset($title)) { $title = "Agenda"; }
  if (!isset($calendar)) { $calendar = 'http://www.google.com/calendar/ical/e_2_en%23weeknum%40group.v.calendar.google.com/public/basic.ics'; }
  if (!isset($timeframe_before)) { $timeframe_before = 7; }
  if (!isset($timeframe_after)) { $timeframe_after = 366; }
  if (!isset($num_items)) { $num_items = 3; }
  
  // Intervalle de temps concerné pour affichage
  $startyear = date('Y', time()-$timeframe_before*24*3600);
  $startmonth = date('n', time()-$timeframe_before*24*3600);
  $startday = date('j', time()-$timeframe_before*24*3600);
  $endyear = date('Y', time()+$timeframe_after*24*3600);
  $endmonth = date('n', time()+$timeframe_after*24*3600);
  $endday = date('j', time()+$timeframe_after*24*3600);
  $event_type = "vevent";

  $vcalendar = new vcalendar();  // create a new calendar instance
  $vcalendar->setConfig( 'unique_id', $SERVER['SERVER_NAME']);  // Unique id, based on site domain (required if any component UID is missing)
  $vcalendar->setConfig( 'url', $calendar );  // Remote input file
/*
  $vcalendar->setProperty( 'method', 'PUBLISH' );
  $vcalendar->setProperty( "x-wr-calname", "Evénements" );
  $vcalendar->setProperty( "X-WR-CALDESC", $title);
  $vcalendar->setProperty( "X-WR-TIMEZONE", "Europe/Paris" );
*/
  $vcalendar->parse();
  $vcalendar->sort();  // Ensure start date order

  // Select events
  $events_arr = $vcalendar->selectComponents($startyear,$startmonth,$startday,$endyear,$endmonth,$endday,$event_type);
  
  $eventcount = 0;
  $undouble_events = array();
  $area1 = "";
  // Generate content
  foreach( $events_arr as $year => $year_arr ) {
    foreach( $year_arr as $month => $month_arr ) {
      foreach( $month_arr as $day => $day_arr ) {
        foreach( $day_arr as $event ) {
          $event_string = null;
          $startdate = $event->getProperty('dtstart');
          /* Filtrage possible mais pas utilisé car impacterait d'autres vues, + parseur variable selon les fichiers ('\n') + à implémenter dans une autre vue "déployée", et dans la configuration
          $categories = explode('\n', $event->getProperty('categories'));
          $categories = $categories[0];
          if ($categories != "Correspondants") break;
          $description = $event->getProperty('description');
          */
          $summary = $event->getProperty('summary');
          $month = $startdate['month'];
          $num_months = array('/01/', '/02/', '/03/', '/04/', '/05/', '/06/', '/07/', '/08/', '/09/', '/10/', '/11/', '/12/');
          $fr_months = array('Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre');
          $month = preg_replace($num_months, $fr_months, $month);
          // TODO : utiliser la vue d'event_calendar à la place, ou une vue spécifique ?
          $summary = makeLinksFromText($summary);
          $event_string = '<p class="vevent">' 
            . '<span class="dtstart" style="display:none;">' . "{$startdate["year"]}-{$startdate["month"]}-{$startdate["day"]}T{$startdate["hour"]}:{$startdate["min"]}:{$startdate["sec"]}" . '</span>' . $startdate['day'] . " " . $month 
            . ' : <span class="summary">' . $summary . "</span></p>\n";
          if (!in_array($event_string, $undouble_events)) { $area1 .= $event_string; }
          $undouble_events[] = $event_string; // Dédoublonnage
          $eventcount++;
          if ($eventcount >= $num_items) break;
        }
        if ($eventcount >= $num_items) break;
      }
      if ($eventcount >= $num_items) break;
    }
    if ($eventcount >= $num_items) break;
  }

  // Displays the content
  echo $area1;
