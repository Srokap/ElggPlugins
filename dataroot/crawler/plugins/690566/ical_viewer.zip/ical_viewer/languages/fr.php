<?php

$french = array(
  'ical_viewer:title' => "Agenda",
  
  'ical_viewer:configuration' => "Configuration de l'agenda public",
  'ical_viewer:settings:description' => "Configuration de l'agenda public",
  
  'ical_viewer:settings:calendartitle' => "Titre du calendrier principal",
  'ical_viewer:settings:defaulturl' => "URL du calendrier principal",
  'ical_viewer:settings:num_items' => "Nombre d'éléments à afficher au maximum (défaut = tous)",
  'ical_viewer:settings:timeframe_before' => "Nombre de jours à prendre en compte avant aujourd'hui (défaut = 7)",
  'ical_viewer:settings:timeframe_after' => "Nombre de jours à prendre en compte à partir d'aujourd'hui (défaut = 366)",
  
);
        
add_translation("fr",$french);

