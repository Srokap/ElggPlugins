<?php
?>
.language_selector {
	position: absolute;
	right: 0px;
	top: 42px;
	color: white;
}

.language_selector > a {
	color: white;
}