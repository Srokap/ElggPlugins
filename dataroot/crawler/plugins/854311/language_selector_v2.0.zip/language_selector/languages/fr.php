<?php
	$french = array(

		'language_selector:admin:settings:min_completeness' => "Quel est le pourcentage minimum d'exhaustivit� d'une langue pour qu'elle puisse appara�tre dans la language_selector (ex 30)",
		'language_selector:admin:settings:show_in_header' => "Afficher les langues disponibles dans l'en-t�te",
		'language_selector:admin:settings:autodetect' => "Activer la d�tection automatique de la langue (pour les utilisateurs non connect�s)",
		'language_selector:admin:settings:show_images' => "Afficher le drapeau du pays (si disponible)",
	
	);
					
	add_translation("fr",$french);