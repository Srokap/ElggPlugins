<?php
	$dutch = array(

		'language_selector:admin:settings:min_completeness' => 'Minimum taalcompleetheidspercentage (bijv. 30)',
		'language_selector:admin:settings:show_in_header' => 'Toon de language selector in de header?',
		'language_selector:admin:settings:autodetect' => 'Activeer automatische detectie van browser taal (voor niet aangemelde gebruikers)',
		'language_selector:admin:settings:show_images' => 'Toon afbeelding van vlag van land (indien beschikbaar)',
	
	);
					
	add_translation("nl",$dutch);