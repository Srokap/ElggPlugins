#family-tree-editor select { margin-right: 3px; }
#family-tree-editor a.plus { margin-left: 3px; }

#family_widget { text-align: center; }
#family_widget .usericon { display: inline; }

#family_widget .edit-family { float: left; }