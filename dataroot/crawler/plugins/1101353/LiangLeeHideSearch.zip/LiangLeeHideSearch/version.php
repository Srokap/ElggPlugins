<?php
/* LiangLeeHideSearch
 * FrameWork for Liang Lee Plugins
 * @website Link: http://community.elgg.org/pg/profile/arsalanlee/
 * @package LiangLeeFramework
 * @subpackage LiangLee Hide Search
 * @author Liang Lee
 * @copyright All right reserved Liang Lee 2012.
 * @File version.php
 */
$LiangLee_version = 26092012;
$LiangLee_release = '1.0.0'; 
?>