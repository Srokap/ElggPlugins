LiangLeeHideSearch
=====================
Hide Search from Non-Logged in Users

Installation

* Download LiangLeeFramework 1.1.3

* Extract to mod dir

* Enable LiangLeeFramework

* Download LiangLeeHideSearch

* Extract to mod dir

* Enable LiangLee LiangLeeHideSearch

* Go to http://yourwebsite.com/admin/plugin_settings/LiangLeeHideSearch

* Save Settings According to your need

* Run Upgrade.php


Any problem in installing or any Bug Please Report it on https://github.com/lianglee/LiangLeeHideSearch/issues

More Plugin found here http://www.sispak.org/

