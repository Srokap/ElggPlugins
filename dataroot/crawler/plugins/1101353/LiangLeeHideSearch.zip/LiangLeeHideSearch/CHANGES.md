LiangLeeHideSearch 1.0.0 <- initial release
(September 26, 2012 from https://github.com/lianglee/LiangLeeHideSearch/1.0.0)
