Notes:

* Very simple video embedder. mpg(mpeg), mov(quicktime), wmv(x-ms-wmv). Depends on browser plugins.

Instructions:

Drop into mod, enable in the admin planel and use.