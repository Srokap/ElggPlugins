<?php

/*
	ATvideo
	Very simple video embedder. mpg(mpeg), mov(quicktime), wmv(x-ms-wmv). Depends on browser plugins.
	@license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	@author Andrew Tibbetts
	@copyright Andrew Tibbetts 2009
*/
  
    function atvideo_init() { }
    register_elgg_event_handler('init','system','atvideo_init');
		
?>