<?php /*
	ATvideo
	Very simple video embedder
	@license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	@author Andrew Tibbetts
	@copyright Andrew Tibbetts 2009
*/ ?>
<div style="margin:10px 0 10px 10px;">
	<object width=320 height=286 classid="CLSID:22D6f312-B0F6-11D0-94AB-0080C74C7E95" standby="Loading Windows Media Player components..." type="application/x-mplayer2" codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,7,1112">
		<param name="filename" value="<?php echo $vars['url']; ?>action/file/download?file_guid=<?php echo $vars['entity']->getGUID(); ?>">
		<param name="Showcontrols" value="True">
		<param name="autoStart" value="False">
		<embed type="application/x-mplayer2" src="<?php echo $vars['url']; ?>action/file/download?file_guid=<?php echo $vars['entity']->getGUID(); ?>" width=320 height=240></embed>
	</object>
</div>
