<?php /*
	ATvideo
	Very simple video embedder
	@license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	@author Andrew Tibbetts
	@copyright Andrew Tibbetts 2009
*/ ?>
<div style="margin:10px 0 10px 10px;">
	<object CLASSID="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" width="320" height="256" CODEBASE="http://www.apple.com/qtactivex/qtplugin.cab">
		<param name="src" value="<?php echo $vars['url']; ?>action/file/download?file_guid=<?php echo $vars['entity']->getGUID(); ?>">
		<param name="autoplay" value="false">
		<param name="loop" value="false">
		<param name="controller" value="true">
		<embed src="<?php echo $vars['url']; ?>action/file/download?file_guid=<?php echo $vars['entity']->getGUID(); ?>" width="320" height="256" autoplay="false" loop="false" controller="true" pluginspage="http://www.apple.com/quicktime/"></embed>
	</object>
</div>
