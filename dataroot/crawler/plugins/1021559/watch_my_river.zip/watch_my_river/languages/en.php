<?php
/**
 * WMR language pack
 */

$english = array(
	'wmr:fix_items' => 'Fix River Items',
        'wmr:fixme:success' => 'Your river items, now are clean and ready to be watched by everyone',

);

add_translation('en', $english);