Watch My River
==============

Elgg Version: 1.8

Elgg module, that aims to fix the river items problems while disabling a module.

For example, if we disable the blog, river items will appear as empty and broken.

Now we have a button on the Control Panel, that says "Fix River Items".
Added a daily cronjob too.

This will copy every empty river items to an alternative created database by this module

### Your activity now is in peace and happy

Developed by Keetup http://www.keetup.com