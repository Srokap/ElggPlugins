<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

/**
 * Default attributes
 *
 * @return array with default values
 */
function phloor_menuitem_default_vars() {
    $defaults = array(
		'title'          => '',
	    'href'           => '%wwwroot%',
	    'tooltip'        => '',
	    'priority'       => 500,
	    'target'         => '_self',
		'delete_image'   => 'false',
	    'image'          => '',
	    'contexts'       => 'all',
	    'guests_only'    => 'false',
		'topentry'       => 'false',
	    'menu_name'      => 'site',
		'parent_guid'    => 0,
		'access_id'      => ACCESS_DEFAULT,
		'container_guid' => NULL,
		'guid'           => NULL,
    );

    return $defaults;
}

/**
 * Load vars from post or get requests and returns them as array
 *
 * @return array with values from the request
 */
function phloor_menuitem_get_input_vars() {
    // set defaults and required values
    $values = phloor_menuitem_default_vars();
    $values['container_guid'] = (int)get_input('container_guid', '');

    $user = elgg_get_logged_in_user_entity();
    // load from menuitem and do sanity and access checking
    foreach ($values as $name => $default) {
        $value = get_input($name, $default);
        switch ($name) {
            // get the image from $_FILES array
            case 'image':
                $values['image'] = $_FILES['image'];
                break;
            case 'container_guid':
                // this can't be empty or saving the base entity fails
                if (!empty($value)) {
                    if (can_write_to_container($user->getGUID(), $value)) {
                        $values['container_guid'] = $value;
                    }
                }
                break;
                // don't try to set the guid
            case 'guid':
                unset($values['guid']);
                break;
            default:
                $values[$name] = $value;
                break;
        }
    }

    return $values;
}

/**
 * Load vars from given site into and returns them as array
 *
 * @return array with stored values
 */
function phloor_menuitem_save_vars(PhloorMenuitem $menuitem, $params) {
    // get default params
    $defaults = phloor_menuitem_default_vars();

    // merge with given params
    $vars = array_merge($defaults, $params);

    // check for the image
    if(!phloor_elgg_image_check_vars($menuitem, $vars)) {
        return false;
    }

    // check variables
    if(!phloor_menuitem_check_vars($menuitem, $vars)) {
        return false;
    }

    // adopt variables
    foreach($vars as $key => $value) {
        $menuitem->$key = $value;
    }

    // save and return status
    return $menuitem->save();
}

/**
 * Check variables, manipulate them
 *
 * Enter description here ...
 * @param unknown_type $params
 */
function phloor_menuitem_check_vars($menuitem, &$params) {
    if(!phloor_menuitem_instanceof($menuitem)) {
        return false;
    }

    // fail if a required entity isn't set
    $required = array('title', 'href');

    // load from menuitem and do sanity and access checking
    foreach ($required as $name) {
        if (!isset($params[$name]) || empty($params[$name])) {
            register_error(elgg_echo("phloor_menuitem:error:missing:$name"));
            return false;
        }
    }

    $priority = intval($params['priority']);
    if($priority <= 0) {
        system_message(elgg_echo('phloor_menuitem:message:prioritywassetto500'));
        $params['priority'] = 500;
    }

    /* would check here if the patterns for username were not
     * used when acces level is public.. but its the fault of the
     * admin when he does so. it gets mentioned that he should not do that.
     * also he/she will see it anyways if the pattern does not get replaced.
     if($params['access_id'] = ACCESS_PUBLIC) {
     if(strstr($params['href'], '%username%') != false) {
     $params['access_id'] = ACCESS_LOGGED_IN;
     }
     }
     */

    $parent_guid = intval($params['parent_guid']);

    // if parent_guid is > 0, it is not a top entry anymore.
    if($parent_guid <= 0) {
        $params['parent_guid'] = 0;
    } else {
        //$params['menu_name'] = get_entity($parent_guid)->menu_name;
        $params['menu_name'] = ''; // no menu name
    }

    return true;
}

/**
 * Get page components to view a menuitem.
 *
 * @param int $guid GUID of a menuitem entity.
 * @return array
 */
function phloor_menuitem_get_page_content_read($guid = NULL) {
    $return = array();

    $menuitem = get_entity($guid);

    // no header or tabs for viewing an individual menuitem
    $return['filter'] = '';

    if (!phloor_menuitem_instanceof($menuitem)) {
        $return['content'] = elgg_echo('phloor_menuitem:error:menuitem_not_found');
        return $return;
    }

    $container = $menuitem->getContainerEntity();
    $crumbs_title = $container->name;
    if (elgg_instanceof($container, 'user')) {
        elgg_push_breadcrumb($crumbs_title, "menuitem/owner/$container->username");
    }

    phloor_menuitem_prepare_parent_breadcrumbs($menuitem);
    elgg_push_breadcrumb($menuitem->getTitle(true));

    // register title button to go to parent
    if($menuitem->parent_guid != 0) {
        elgg_register_menu_item('title', array(
			'name' => "phloor-menuitem-{$menuitem->guid}-back-to-parent",
			'href' => "menuitem/view/{$menuitem->parent_guid}",
			'text' => elgg_echo('phloor_menuitem:backtoparent'),
			'link_class' => 'elgg-button elgg-button-action',
		    'priority' => 100,
        ));
    }
    else {
        // register title button to view the menu
        elgg_register_menu_item('title', array(
    		'name' => "phloor-menuitem-{$menuitem->guid}-view-menu",
    		'href' => "menuitem/{$menuitem->menu_name}",
    		'text' => elgg_echo('phloor_menuitem:view_menu'),
    		'link_class' => 'elgg-button elgg-button-action',
    	    'priority' => 100,
        ));
    }

    // register title button to create child entity
    if($menuitem->canEdit() && elgg_is_logged_in()) {
        $user = elgg_get_logged_in_user_entity();
        elgg_register_menu_item('title', array(
			'name' => "phloor-menuitem-{$menuitem->guid}-addchild",
			'href' => "menuitem/add/{$user->guid}?parent_guid={$menuitem->guid}",
			'text' => elgg_echo('phloor_menuitem:newchild'),
			'link_class' => 'elgg-button elgg-button-action',
		    'priority' => 200,
        ));
    }

    $return['title']   = htmlspecialchars($menuitem->getTitle(true));
    $return['content'] = elgg_view_entity($menuitem, array('full_view' => true));

    return $return;
}

/**
 * Get page components to list a user's or all menuitems.
 *
 * @param int $owner_guid The GUID of the page owner or NULL for all menuitems
 * @return array
 */
function phloor_menuitem_get_page_content_list($container_guid = NULL, $params = array()) {
    $return = array();
    $loggedin_userid = elgg_get_logged_in_user_guid();

    $menu_name = isset($params['menu_name']) ? $params['menu_name'] : 'site';
    $return['filter_context'] = ($container_guid == $loggedin_userid) ? 'mine' : $menu_name;

    $options = array(
		'type'             => 'object',
		'subtype'          => 'phloor_menuitem',
		'full_view'        => FALSE,
		'offset'           => (int) max(get_input('offset', 0), 0),
		'limit'            => (int) max(get_input('limit', 10), 0),
		'list_type_toggle' => TRUE,
		'pagination'       => TRUE,
		'list_class'       => 'elgg-list-entity phloor-list-menuitem',
    );

    if ($container_guid) {
        group_gatekeeper();

        $options['container_guid'] = $container_guid;
        $container = get_entity($container_guid);
        if (!$container) {

        }
        $return['title'] = elgg_echo('phloor_menuitem:title:user_phloor_menuitems', array($container->name));

        $crumbs_title = $container->name;
        elgg_push_breadcrumb($crumbs_title);

        if (elgg_instanceof($container, 'group')) {
            $return['filter'] = false;
        }
    } else {
        $return['title'] = elgg_echo('phloor_menuitem:title:all_phloor_menuitems');
        elgg_pop_breadcrumb();
        elgg_push_breadcrumb(elgg_echo('phloor_menuitem:phloor_menuitems'));
    }

    // dont show button if were in admin mode.. looks stupid
    // and there is a form anyway
    if(!elgg_in_context('admin')) {
        elgg_register_title_button();
    }

    $options['menu_name'] = $menu_name;
    $menuitems_top = phloor_menuitem_get_menuitems_top($options);
    $menuitems_top = phloor_menuitem_sort_by_priority($menuitems_top);

    $list = elgg_view_entity_list($menuitems_top, $options);

    if (!$list) {
        $return['content'] = elgg_echo('phloor_menuitem:none');
    } else {
        $return['content'] = $list;
    }

    $return['filter_override'] = elgg_view('phloor_menuitem/menufilter', array(
    //'menu_name' => $container_guid,
		'filter_context' => $return['filter_context'],
	    'context' => elgg_get_context(),
    ));

    return $return;
}



/**
 * Get page components to edit/create a menuitem
 *
 * @param string  $page     'edit' or 'new'
 * @param int     $guid     GUID of phloor_menuitem post or container
 * @return array
 */
function phloor_menuitem_get_page_content_edit($page, $guid = 0) {

    $parent_guid = get_input('parent_guid', 0, true);

    $return = array(
		'filter' => '',
    );

    $vars = array();
    $vars['id']    = 'phloor_menuitem-post-edit';
    $vars['name']  = 'phloor_menuitem_post';
    $vars['class'] = 'elgg-form-alt';

    if ($page == 'edit') {
        $menuitem = get_entity((int)$guid);

        $title = elgg_echo('phloor_menuitem:edit');
        if (phloor_menuitem_instanceof($menuitem) && $menuitem->canEdit()) {
            $vars['entity'] = $menuitem;

            phloor_menuitem_prepare_parent_breadcrumbs($menuitem);
            elgg_push_breadcrumb($menuitem->getTitle(true), $menuitem->getURL());
            elgg_push_breadcrumb(elgg_echo('edit'));

            $form_vars = array(
				'enctype' => 'multipart/form-data'
			);
			$body_vars = phloor_menuitem_prepare_form_vars($menuitem, $parent_guid);

			$title .= ": \"{$menuitem->getTitle(true)}\"";
			// create form
			$content = elgg_view_form('phloor_menuitem/save', $form_vars, $body_vars);
			$sidebar = '';
        } else {
            $content = elgg_echo('phloor_menuitem:error:cannot_edit_menuitem');
            $sidebar = '';
        }
    } else {
        // push parent breadcrump
        if($parent_guid != 0) {
            $parent = get_entity($parent_guid);
            if (phloor_menuitem_instanceof($parent)) {
                phloor_menuitem_prepare_parent_breadcrumbs($parent);
                elgg_push_breadcrumb($parent->getTitle(true), $parent->getURL());
            }
        }
        elgg_push_breadcrumb(elgg_echo('phloor_menuitem:add'));

        $form_vars = array(
			'enctype' => 'multipart/form-data',
        );
        $body_vars = phloor_menuitem_prepare_form_vars(null, $parent_guid);

        $content = elgg_view_form('phloor_menuitem/save', $form_vars, $body_vars);
        $title = elgg_echo('phloor_menuitem:add');
        $sidebar = '';
    }

    $return['title'] = $title;
    $return['content'] = $content;
    $return['sidebar'] = $sidebar;
    return $return;
}


/**
 * Recurses the menu item tree and adds the breadcrumbs accordingly
 *
 * @param PhloorMenuitem $menuitem menuitem entity
 */
function phloor_menuitem_prepare_parent_breadcrumbs(PhloorMenuitem $menuitem) {
    if (phloor_menuitem_instanceof($menuitem)) {
        if($menuitem->hasParent()) {
            $parent = $menuitem->getParent();
            phloor_menuitem_prepare_parent_breadcrumbs($parent);
            elgg_push_breadcrumb($parent->getTitle(true), $parent->getURL());
        }
        else {
            // add menu name to breadcrumbs (site, topbar, footer, ...)
            elgg_push_breadcrumb(elgg_echo($menuitem->menu_name), "menuitem/{$menuitem->menu_name}");
        }
    }
}

/**
 * Pull together menuitem variables for the save form
 *
 * @param PhloorMenuitem       $menuitem
 * @return array
 */
function phloor_menuitem_prepare_form_vars($menuitem = null, $parent_guid = 0) {
    $defaults = phloor_menuitem_default_vars();

    // input names => defaults
    $params = array(
		'entity' => $menuitem,
		'parent_guid' => $parent_guid,
    );

    $values = array_merge($defaults, $params);

    if ($menuitem) {
        foreach (array_keys($values) as $field) {
            if (isset($menuitem->$field)) {
                $values[$field] = $menuitem->$field;
            }
        }
    }

    if (elgg_is_sticky_form('phloor_menuitem')) {
        $sticky_values = elgg_get_sticky_values('phloor_menuitem');
        foreach ($sticky_values as $key => $value) {
            $values[$key] = $value;
        }
    }

    elgg_clear_sticky_form('phloor_menuitem');

    return $values;
}

/**
 *
 * Enter description here ...
 * @param unknown_type $params
 */
function phloor_menuitem_get_menuitem_entities($params = array()) {
    $options = array(
		'type'    => 'object',
		'subtype' => 'phloor_menuitem',
		'offset'  => 0,
		'limit'   => 0,
    );

    $options = array_merge($params, $options);

    return elgg_get_entities($options);
}

function phloor_menuitem_instanceof($menuitem) {
    return elgg_instanceof($menuitem, 'object', 'phloor_menuitem', 'PhloorMenuitem');
}

/**
 * Get the root entities of a menu
 *
 * if no menu is given (array('menu_name')..)
 * then it defaults to the 'site' menu
 *
 * @param unknown_type $params
 */
function phloor_menuitem_get_menuitems_top($params = array()) {
    $return = array();

    $options = array(
		'type'    => 'object',
		'subtype' => 'phloor_menuitem',
		'offset'  => 0,
		'limit'   => 0,
    );

    if(is_array($params) && !empty($params['menu_name'])
    && $params['menu_name'] != 'all') {
        $menu_name_options = array(
			'metadata_names' => array('menu_name', ),
			'metadata_values' => array($params['menu_name'],),
        // ??			'metadata_names' => array('menu_name', 'parent_guid', ),
        // ??			'metadata_values' => array($params['menu_name'], 0, ),
        );
        $options = array_merge($menu_name_options, $options);
    }

    $menuitems_top = elgg_get_entities_from_metadata($options);
    //?? return $menuitems_top;

    if(is_array($menuitems_top) && !empty($menuitems_top)) {
        foreach($menuitems_top as $key => $menuitem) {
            if(phloor_menuitem_instanceof($menuitem) && $menuitem->parent_guid == 0) {
                $return[] = $menuitems_top[$key];
            }
        }
    }

    return $return;
}

function phloor_menuitem_get_children($menuitem) {
    if(!phloor_menuitem_instanceof($menuitem)) {
        return array();
    }

    $children = elgg_get_entities_from_metadata(array(
		'type'            => 'object',
		'subtype'         => 'phloor_menuitem',
		'metadata_names'  => array('parent_guid'),
		'metadata_values' => array($menuitem->getGUID()),
	    'limit'           => 0,
    ));

    return $children;
}

/**
 * Appends all menuitems in the given menu to
 * an array
 *
 * Enter description here ...
 * @param unknown_type $featured
 * @param unknown_type $menu_name
 */
function phloor_menuitem_append_menuitems(&$menu, $menu_name) {
    //$current_page_url = phloor_get_current_page_url();

    // get root elements
    $menuitems_top = phloor_menuitem_get_menuitems_top(array(
		'menu_name' => $menu_name,
    ));

    $selected = false;
    if (is_array($menuitems_top) && count($menuitems_top) > 0) {
        // sort by priority
        $menuitems_top = phloor_menuitem_sort_by_priority($menuitems_top);
        foreach ($menuitems_top as $menuitem_top) {
            $top_item = new PhloorMenuitemAdapter($menuitem_top);

            if(!$top_item->inContext(elgg_get_context())) {
                continue;
            }

            // dont add the menu item if it is for guests only!
            if (phloor_str_is_true($menuitem_top->isGuestsOnly()) &&
                elgg_is_logged_in()) {
                continue;
            }

            $priority = $top_item->getPriority();
            while(isset($menu[$priority])) {
                $priority += 1;
            }
            // add to featured
            $menu[$priority] = $top_item;
        }
    }
}

/**
 *
 * Sorts menu items by priority
 *
 * @param unknown_type $menuitems
 */
function phloor_menuitem_sort_by_priority($menuitems) {
    $array = array();

    // insert unique priority -> menuitem array
    foreach ($menuitems as $menuitem) {
        $priority = 500;

        if(isset($menuitem->priority)) {
            $priority = (int) $menuitem->priority;
        }
        // get unique priority
        while(isset($array[$priority])) {
            $priority += 1;
        }
        $array[$priority] = $menuitem;
    }

    ksort($array); // sort array by key

    return array_values($array);
}
