<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Edit form for phloor_menuitem objects
 *
 */
$guid = elgg_extract('guid', $vars, false);
$menuitem = get_entity($guid);

$action_buttons = '';
$delete_link = '';

$parent_guid = elgg_extract('parent_guid', $vars, 0);

if ($guid && phloor_menuitem_instanceof($menuitem)) {
    // add a delete button if editing
    $delete_url  = "action/phloor_menuitem/delete?guid={$guid}";
    $delete_link = elgg_view('output/confirmlink', array(
		'href'  => $delete_url,
		'text'  => elgg_echo('delete'),
		'class' => 'elgg-button elgg-button-delete elgg-state-disabled float-alt',
    ));

    if($menuitem->hasParent()) {
        $parent_guid = $menuitem->getParent()->guid;
    }
}
// parent_guid can be overwritten
$parent_guid = get_input('parent_guid', $parent_guid, true);
if(intval($parent_guid) <= 0) {
    $parent_guid = 0;
}

$save_button = elgg_view('input/submit', array(
	'value' => elgg_echo('save'),
	'name' => 'save',
));
$action_buttons = $save_button . $delete_link;

$form_content = '';
$variables = elgg_get_config('phloor_menuitem');
foreach ($variables as $name => $input_view) {
    if(!elgg_view_exists($input_view)) {
        // this should really never happen as the input_views are stored in the
        // config datastructure and its defined when the plugin is activated (start.php - run_once..)
        register_error(elgg_echo('phloor_menuitem:couldnotfindinputview', array($input_view)));
        continue;
    }
    // show 'menu_name' just at menuitem_top objects
    if(strcmp('menu_name', $name) == 0 && $parent_guid != 0) {
        continue;
    }

    // dont show the delete image input entity has no image
    if(strcmp('delete_image', $name) == 0) {
        if(!phloor_menuitem_instanceof($menuitem) || !$menuitem->hasImage()) {
            continue;// skip "delete image" input
        }
    }

    // get label
    $label = elgg_echo("phloor_menuitem:form:$name");
    $input = elgg_view($input_view, array(
		'name'  => $name,
		'value' => $vars[$name],
    ));
    $description = elgg_echo("phloor_menuitem:$name:description");

    // append to form content
    $form_content .= <<<HTML
	<div>
		<label for="$name">$label</label>
		$input
		$description
	</div>
HTML;
}

$categories_input = elgg_view('input/categories', $vars);

// hidden inputs
$container_guid_input = elgg_view('input/hidden', array(
	'name'  => 'container_guid',
	'value' => elgg_get_page_owner_guid(),
));
$guid_input = elgg_view('input/hidden', array(
	'name'  => 'guid',
	'value' => $guid,
));
$context_input = elgg_view('input/hidden', array(
	'name'  => 'context',
	'value' => elgg_get_context(),
));
$parent_guid_input = elgg_view('input/hidden', array(
	'name'  => 'parent_guid',
	'value' => $parent_guid,
));

$special_pattern_usage_information = elgg_echo('phloor_menuitem:specialpatternusage');

// create the content content
// constists of
// -> special pattern information
// -> form content
// -> (hidden) form foot
$content = <<<___HTML
$special_pattern_usage_information
$form_content
$categories_input

<div class="elgg-foot">
$context_input
$guid_input
$container_guid_input
$parent_guid_input

$action_buttons
</div>
___HTML;

// output form content
echo $content;

