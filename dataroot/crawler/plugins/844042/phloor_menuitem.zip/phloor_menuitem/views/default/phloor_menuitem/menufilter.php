<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Menu filter
 *
 * Select beetween the menues from $CONFIG->menues
 *
 * @uses $vars['filter_context']  Filter context: all, friends, mine
 * @uses $vars['context']         Page context (override)
 */

$menu_name = 'site';
if (isset($vars['filter_context'])) {
    $menu_name = $vars['filter_context'];
}

// dont show these menues
$skip_menues = array('title', 'embed', 'admin_footer');

$context = elgg_extract('context', $vars, elgg_get_context());
// if wer are in admin context -> get menu_name from GET params
if(strcmp($context, 'admin') == 0) {
    $menu_name = get_input('menu_name', 'site', true);
}

$username = elgg_get_logged_in_user_entity()->username;
$filter_context = elgg_extract('filter_context', $vars, 'site');

/*
 * Disabled "all" tab
 *
 $all_href = (isset($vars['all_link'])) ? $vars['all_link'] : "$context/all";
 if($context == 'admin') {
 $all_href = "$context/appearance/phloor_menuitem?menu_name=all";
 }
 // generate a list of default tabs
 $tabs = array(
 'all' => array(
 'text' => elgg_echo('all'),
 'href' => $all_href,
 'selected' => ($filter_context == '' || $filter_context == 'all'),
 'priority' => 1,
 ),
 );
 */
$tabs = array();

global $CONFIG;
$menus = $CONFIG->menus;
asort($menus);

$href_prefix = "$context/";
if($context == 'admin') {
    $href_prefix = "$context/appearance/phloor_menuitem?menu_name=";
}

foreach ($menus as $menu_name => $menu_object) {
    if(in_array($menu_name, $skip_menues)) { continue; }
    $href = "{$href_prefix}{$menu_name}";
    $tabs[$menu_name] = array(
		'text' => elgg_echo($menu_name),
		'href' => $href,
		'selected' => ($filter_context == $menu_name),
    );
}

foreach ($tabs as $name => $tab) {
    $tab['name'] = $name;

    elgg_register_menu_item('filter', $tab);
}

echo elgg_view_menu('filter', array('sort_by' => 'text', 'class' => 'elgg-menu-hz'));
