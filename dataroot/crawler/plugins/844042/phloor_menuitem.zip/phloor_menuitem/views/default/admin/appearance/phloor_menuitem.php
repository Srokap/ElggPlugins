<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
// check for admin
admin_gatekeeper();

$title = elgg_view_title(elgg_echo('phloor_menuitem:admin:appearance:title'));
$description = elgg_echo('phloor_menuitem:admin:appearance:description');

$count = phloor_menuitem_get_menuitem_entities(array('count' => true));
$entity_count = elgg_echo('phloor_menuitem:admin:appearance:entity_count', array($count));

// get page content list (just like in normal view)
$menu_name = get_input('menu_name', 'site', true);
$content_list = phloor_menuitem_get_page_content_list(null, array(
	'menu_name' => $menu_name,
));

$menuitem_list = $content_list['content'];
$filter        = $content_list['filter'];

if(isset($content_list['filter_override'])) {
    $filter  = $content_list['filter_override'];
}

$new_menuitem_title = elgg_view_title(elgg_echo('phloor_menuitem:admin:appearance:new_menuitem:title'));

// view form
$body_vars = phloor_menuitem_prepare_form_vars();
$body_vars['menu_name'] = $menu_name;

$vars['enctype'] = 'multipart/form-data';
$new_menuitem_form = elgg_view_form('phloor_menuitem/save', $vars, $body_vars);
unset($vars['enctype']);

echo <<<___HTML
{$title}
<p>{$description}</p>
<div>
{$filter}
{$menuitem_list}
<p>{$entity_count}</p>
</div>
<div class="phloor-menuitem-new-menuitem">
<p>{$new_menuitem_title}</p>
{$new_menuitem_form}
</div>
___HTML;

?>