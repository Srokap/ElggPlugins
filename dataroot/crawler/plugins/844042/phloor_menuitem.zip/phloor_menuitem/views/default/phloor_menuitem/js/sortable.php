<?php
?>
<script type="text/javascript">
$(document).ready(function(){
	$(function() {
		elgg.require('phloor');

		$(".phloor-list-menuitem").sortable({ opacity: 0.7, cursor: 'move', update: function() {
			var order = $(this).sortable("serialize");

			//elgg.action('phloor_menuitem/sort', {
			//	data: order,
			//	success: function(json) {
			//		elgg.system_message(elgg.echo("phloor_menuitem:sort:success"));
			//	}
			//});
			var action = elgg.security.addToken(elgg.get_site_url() + "action/phloor_menuitem/sort");
			$.post(action, order, function(response){
				elgg.system_message(elgg.echo("phloor_menuitem:sort:success"));
			});
		}
		});
	});
});
</script>
<?php
