<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Site navigation menu
 *
 * Overwrites the site menu with the option to not show the more menu
 *
 * @uses $vars['default'] true or false
 * @uses $vars['more']    true or false
 * @uses $vars['menu']['default'] default menu section
 * @uses $vars['menu']['more']    more menu section
 */


echo '<ul class="elgg-menu elgg-menu-site elgg-menu-site-default clearfix">';

/* make default menu visible by default */
if(!isset($vars['default'])) {
    $vars['default'] = true;
}

/*
 * if 'more' is not explicitly set from
 * outside the view, then check the plugin
 * settings value 'hide_menu_site_more'
 */
if(!isset($vars['more'])) {
    $vars['more'] = true;

    $hide_more_section =  elgg_get_plugin_setting('hide_menu_site_more_public', 'phloor_menuitem');
    if(elgg_is_logged_in()) {
        $hide_more_section =  elgg_get_plugin_setting('hide_menu_site_more_loggedin', 'phloor_menuitem');
    }

    // if empty or not false -> its true
    if(phloor_str_is_true($hide_more_section)) {
        $vars['more'] = false;
    }
}

if($vars['default'] == true) {
    foreach ($vars['menu']['default'] as $menu_item) {
        echo elgg_view('navigation/menu/elements/item', array('item' => $menu_item));
    }
}

if($vars['more'] == true) {
    if (isset($vars['menu']['more'])) {
        echo '<li class="elgg-more">';
        $more = elgg_echo('more');
        echo "<a title=\"$more\">$more</a>";

        echo elgg_view('navigation/menu/elements/section', array(
			'class' => 'elgg-menu elgg-menu-site elgg-menu-site-more',
			'items' => $vars['menu']['more'],
        ));

        echo '</li>';
    }
}
echo '</ul>';
