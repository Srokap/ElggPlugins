<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

// only admins are allowed to use this action
admin_gatekeeper();

// store errors to pass along
$error = FALSE;
$error_forward_url = REFERER;

// check if upload failed
if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] != 0) {
    register_error(elgg_echo('phloor_menuitem:error:cannotloadimage'));
    forward(REFERER);
}
$delete_files = array();

$menuitem = NULL;
$new_menuitem = TRUE;

// edit or create a new entity
$guid = get_input('guid');
if ($guid) {
    $menuitem = get_entity($guid);

    //register_error($entity->subtype . ' - ' . $entity->type);
    if (!phloor_menuitem_instanceof($menuitem) || !$menuitem->canEdit()) {
        register_error(elgg_echo('phloor_menuitem:error:menuitem_not_found'));
        forward(get_input('forward', REFERER));
        exit;
    }

    $new_menuitem = FALSE;

    // determine files to delete (old images and thumbnails)
    if (isset ($_FILES['image']['name']) &&
		!empty($_FILES['image']['name']) &&
		$_FILES['image']['error'] == 0 ) {
        $delete_files = array_merge(array('image' => $menuitem->image), $menuitem->getThumbnails());
    }
} else {
    $menuitem = new PhloorMenuitem();
    $new_menuitem = TRUE;
}

// get form inputs from POST var
$params = phloor_menuitem_get_input_vars();

// save settings and display success message
if (phloor_menuitem_save_vars($menuitem, $params)) {
    // remove sticky form entries
    elgg_clear_sticky_form('phloor_menuitem');
    system_message(elgg_echo('phloor_menuitem:message:saved'));

    // delete former image if new image was uploaded
    if (isset ($_FILES['image']['name']) &&
		!empty($_FILES['image']['name']) &&
		$_FILES['image']['error'] == 0 ) {
        foreach($delete_files as $file) {
            if(!empty($file) && file_exists($file) && is_file($file)) {
                // delete file
                if(@unlink($file)) {

                }
            }
        }
        // recreate thumbnails
        $menuitem->recreateThumbnails();
    }

    $context = get_input('context', '');
    // if context was admin.. redirect to the REFERER
    if(elgg_is_admin_logged_in() && $context == 'admin') {
        forward($_SERVER['HTTP_REFERER']);
    }
    else {
        forward($menuitem->getURL());
    }
}
// ... or display an error message on failures.
else {
    register_error(elgg_echo('phloor_menuitem:error:cannot_save'));
    forward($_SERVER['HTTP_REFERER']);
}
