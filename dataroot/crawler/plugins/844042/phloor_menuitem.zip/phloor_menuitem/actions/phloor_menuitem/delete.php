<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011 Alois Leitner                                          *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php

// only admins can delete menuitem entities
admin_gatekeeper();

$menuitem_guid = get_input('guid');
$menuitem = get_entity($menuitem_guid);

$menu_name = $menuitem->menu_name;
if(empty($menu_name)) {
    $menu_name = 'all';
}

if (phloor_menuitem_instanceof($menuitem) && $menuitem->canEdit()) {
    $container = get_entity($menuitem->container_guid);

    if ($menuitem->delete()) {
        system_message(elgg_echo('phloor_menuitem:message:deleted_menuitem'));

        // if DID NOT came from object site.. refere him back..
        $url = elgg_get_site_url() . 'admin';
        
        //if(elgg_http_url_is_identical($current_page_url, $href)) { }
            
        if(!phloor_str_starts_with(REFERER, $url)) {
            forward("menuitem/$menu_name");
        }

        
        forward($_SERVER['HTTP_REFERER']);

        exit();
    } else {
        register_error(elgg_echo('phloor_menuitem:error:cannot_delete_menuitem'));
    }
} else {
    register_error(elgg_echo('phloor_menuitem:error:menuitem_not_found'));
}

forward(REFERER);