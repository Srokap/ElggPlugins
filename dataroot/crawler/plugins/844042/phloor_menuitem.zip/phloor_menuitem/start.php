<?php
/*****************************************************************************
 * Phloor Menuitem                                                           *
 *                                                                           *
 * Copyright (C) 2011, 2012 Alois Leitner                                    *
 *                                                                           *
 * This program is free software: you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation, either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 *                                                                           *
 * "When code and comments disagree both are probably wrong." (Norm Schryer) *
 *****************************************************************************/
?>
<?php
/**
 * Phloor Menuitem
 */
elgg_register_event_handler('init', 'system', 'phloor_menuitem_init');
elgg_register_event_handler('init', 'system', 'phloor_menuitem_menu_setup', 999);

function phloor_menuitem_init() {
    /**
     * LIBRARY
     * register a library of helper functions
     */
    $lib_path = elgg_get_plugins_path() . 'phloor_menuitem/lib/';
    elgg_register_library('phloor-menuitem-lib', $lib_path . 'phloor_menuitem.lib.php');
    elgg_load_library('phloor-menuitem-lib'); // load it immediately

    /**
     * Page handler
     */
    //elgg_register_page_handler('phloor_menuitem', 'phloor_menuitem_page_handler');
    elgg_register_page_handler('menuitem',        'phloor_menuitem_page_handler');

    /**
     * Site Menu Item (just for admins)
     */
    if(elgg_is_admin_logged_in()) {
        $item = new ElggMenuItem('phloor_menuitem', elgg_echo('phloor_menuitem:menuitem'), 'menuitem/all');
        elgg_register_menu_item('site', $item);
    }

    /**
     * Url handler
     */
    elgg_register_entity_url_handler('object', 'phloor_menuitem', 'phloor_menuitem_url_handler');

    /**
     * CSS
     * for the background icons mostly
     */
    elgg_extend_view('css/admin', 'phloor_menuitem/css/admin');
    elgg_extend_view('css/elgg',  'phloor_menuitem/css/elgg', 501);
    elgg_extend_view('css/elgg',  'phloor_menuitem/css/menu_icons', 502);

    // append standard theme additions (submenus in site and topbar,..) if user uses the elgg standard theme
    $disable_modified_css =  elgg_get_plugin_setting('disable_modified_css', 'phloor_menuitem');
    if(!phloor_str_is_true($disable_modified_css)) {
        elgg_extend_view('css/elgg',  'phloor_menuitem/css/elgg_standard_theme_additions/site_menu',   501);
        //elgg_extend_view('css/elgg',  'phloor_menuitem/css/elgg_standard_theme_additions/topbar_menu', 501);
        elgg_extend_view('css/elgg',  'phloor_menuitem/css/elgg_standard_theme_additions/footer_menu', 501);
    }

    /**
     * Admin menu
     */
    // unregister the default elgg menu-item page
    elgg_unregister_menu_item('page', 'appearance:menu_items');
    elgg_register_admin_menu_item('configure', 'phloor_menuitem', 'appearance');

    /**
     * Plugin hooks
     */
    // replace default patterns like %wwwroot% and %username%
    elgg_register_plugin_hook_handler('phloor_menuitem_replace_special_pattern', 'all', 'phloor_menuitem_replace_default_sepcial_pattern_hook', 999);

    /**
     * Entity menu
     */
    elgg_register_plugin_hook_handler('register', 'menu:entity', 'phloor_menuitem_register_entity_menu_setup');
    //elgg_register_plugin_hook_handler('register', 'menu:title',  'phloor_menuitem_register_title_menu_setup');

    // unregister likes and likes_count for menuitems object entity menu
    elgg_register_plugin_hook_handler('prepare',  'menu:entity', 'phloor_menuitem_prepare_entity_menu_setup');

    /**
     * Actions
     */
    $action_path = elgg_get_plugins_path() . 'phloor_menuitem/actions/phloor_menuitem';
    elgg_register_action('phloor_menuitem/save',   "$action_path/save.php",      'admin');
    elgg_register_action('phloor_menuitem/delete', "$action_path/delete.php",    'admin');
    elgg_register_action('phloor_menuitem/sort',   "$action_path/ajax/sort.php", 'admin');

    // temporarily load set config
    //(attribute_name => input_view)
    elgg_set_config('phloor_menuitem', array(
		'menu_name'    => 'phloor_menuitem/input/menupicker',
		'title'        => 'input/text',
	    'href'         => 'input/url',
	    'target'       => 'phloor_menuitem/input/linktargetpicker',
	    'tooltip'      => 'input/text',
		'delete_image' => 'phloor/input/enable',
	    'image'        => 'input/file',
	    'priority'     => 'input/text',
	    'contexts'     => 'input/tags',
		'access_id'    => 'input/access',
		'guests_only'  => 'phloor/input/enable',
    ));
}

function phloor_menuitem_menu_setup() {
    /**
     * Menu Settings
     */
    global $CONFIG;

    // initialise all major menues
    $major_menues = array('site', 'footer', 'topbar', 'page', 'extras');
    foreach($major_menues as $menu_name) {
        // assign empty array if not set
        if(!isset($CONFIG->menus[$menu_name])) {
            $CONFIG->menus[$menu_name] = array();
        }
    }

    //foreach ($major_menues as $menu_name) {
    foreach ($CONFIG->menus as $menu_name => $_) {
        // get menuitems of the menu
        $count = phloor_menuitem_get_menuitems_top(array(
			'menu_name' => $menu_name,
            'count'     => true,
        	'limit'     => 1,
        ));
        // if at least one menu item exists,
        if($count >= 1) {
            // special treatment for site menu (because of standard core plugin hook)
            if(strcmp('site', $menu_name) == 0) {
                // unregister the elgg plugin hook for preparing the menu
                elgg_unregister_plugin_hook_handler('prepare', 'menu:site', 'elgg_site_menu_setup');
                // register own plugin for site (its the same as for the others any.. just pointing it out.
                elgg_register_plugin_hook_handler  ('prepare', 'menu:site', 'phloor_menuitem_menu_setup_hook', 999);
            }
            else {
                // register plugin hook for every menu in $CONFIG->menus
                elgg_register_plugin_hook_handler('prepare', 'menu:'.$menu_name, 'phloor_menuitem_menu_setup_hook', 999);
            }
        }
    }
}


/**
 *
 * @param string $hook
 * @param string $type
 * @param array $return Menu array
 * @param array $params
 * @return array
 */
function phloor_menuitem_menu_setup_hook($hook, $type, $return, $params) {
    if($hook == 'prepare' && substr($type, 0, 5) == 'menu:') {
        $menu_name = substr($type, 5, strlen($type));

        // do not add page items when in admin mode
        // this would screw up the admin menu section
        if(elgg_in_context('admin') && strcmp('page', $menu_name) == 0) {
            return $return;
        }

        // append the menu items as featured items
        $featured = array();
        phloor_menuitem_append_menuitems($featured, $menu_name);

        if(count($featured) > 0) {
            // shift the former menu on the 'more' section
            $return['more'] = $return['default'];
            $return['default'] = $featured;

            return $return;
        }
    }

    return $return;
}


function phloor_menuitem_page_handler($page) {
    admin_gatekeeper();

    elgg_load_js('jquery-ui');
    // js: enables sorting the menuitems
    elgg_extend_view('page/elements/foot', 'phloor_menuitem/js/sortable');

    // push 'all' menuitems breadcrumb
    elgg_push_breadcrumb(elgg_echo('phloor_menuitem:menuitems'), "menuitem/all");

    if (!isset($page[0])) {
        $page[0] = 'all';
    }

    $page_type = $page[0];
    switch ($page_type) {
        case 'owner':
            $user = get_user_by_username($page[1]);
            $params = phloor_menuitem_get_page_content_list($user->guid);
            break;
        case 'view':
            $params = phloor_menuitem_get_page_content_read($page[1]);
            break;
        case 'add':
            $params = phloor_menuitem_get_page_content_edit($page_type, $page[1]);
            break;
        case 'edit':
            $params = phloor_menuitem_get_page_content_edit($page_type, $page[1]);
            break;
        case 'all':
            $params = phloor_menuitem_get_page_content_list();
            break;
        default:
            global $CONFIG;
            // dont handle if the menu does not exists
            if(!array_key_exists($page_type, $CONFIG->menus)) {
                return false;
            }

            $params = phloor_menuitem_get_page_content_list(null, array(
				'menu_name' => $page_type,
            ));
    }

    if(!isset($params['sidebar'])) {
        $params['sidebar'] = '';
    }

    $params['sidebar'] .= elgg_view('phloor_menuitem/sidebar', array('page' => $page_type));

    $body = elgg_view_layout('content', $params);

    echo elgg_view_page($params['title'], $body);

    return true;
}

/**
 * Add/remove particular phloor_menuitem links/info to entity menu
 */
function phloor_menuitem_register_entity_menu_setup($hook, $type, $return, $params) {
    $menuitem = $params['entity'];
    $handler = elgg_extract('handler', $params, false);
    // break up if wrong handler or entity is not of class PhloorMenuitem
    if(!phloor_menuitem_instanceof($menuitem) ||
    $handler != 'phloor_menuitem') {
        return $return;
    }

    /**
     * Register items
     */
    // display menu name an top entries
    if(phloor_str_is_true($menuitem->guests_only)) {
        $menu_name_item = ElggMenuItem::factory(array(
			'name' => 'guests_only',
			'href' => false,
			'text' => elgg_echo('phloor_menuitem:guests_only'),
		    'priority' => 1,
        ));
        $return[] = $menu_name_item;
    }

    // view 'add submenu' button if write access
    if ($menuitem->canEdit()) {
        $user_guid = elgg_get_logged_in_user_guid();
        // display 'add submenuitem' if not in full view
        $add_submenuitem_item = ElggMenuItem::factory(array(
			'name' => 'add_submenuitem',
			'href' => "menuitem/add/{$user_guid}?parent_guid=$menuitem->guid",
			'text' => elgg_echo('phloor_menuitem:newchild'),
        ));

        $return[] = $add_submenuitem_item;

        // 'edit' button
        $options = array(
    		'name' => 'edit',
    		'text' => elgg_echo('edit'),
    		'href' => "menuitem/edit/{$menuitem->guid}",
        );
        $return[] = ElggMenuItem::factory($options);
    }

    return $return;
}

/**
 * prepare Menuitem object entity menu
 *
 * remove likes and likes_count
 *
 * @param unknown_type $hook
 * @param unknown_type $type
 * @param unknown_type $return
 * @param unknown_type $params
 */
function phloor_menuitem_prepare_entity_menu_setup($hook, $type, $return, $params) {
    $menuitem = elgg_extract('entity', $params, false);
    $handler = elgg_extract('handler', $params, false);
    // break up if wrong handler or entity is not of class PhloorMenuitem
    if(!phloor_menuitem_instanceof($menuitem) ||
    $handler != 'phloor_menuitem') {
        return $return;
    }
    /**
     * UNregister items
     * unregister like and likes_count
     */
    $unregister_items = array(
		'likes', 'likes_count',
    );

    foreach ($return as $index => $section) {
        if(is_array($section)) {
            foreach($section as $key => $item) {
                if(in_array($item->getName(), $unregister_items)) {
                    unset($return[$index][$key]);
                }
            }
        }
    }

    return $return;
}

/**
 * Format and return the URL for menuitems.
 *
 * @param PhloorMenuitem $entity menuitem object
 * @return string URL of menuitem.
 */
function phloor_menuitem_url_handler($entity) {
    if (!$entity->getOwnerEntity()) {
        // default to a standard view if no owner.
        return FALSE;
    }

    $friendly_title = elgg_get_friendly_title($entity->title);
    return "menuitem/view/{$entity->guid}/$friendly_title";
}


/**
 *
 * @param unknown_type $string
 * @param unknown_type $site_guid
 */
function phloor_menuitem_replace_sepcial_pattern($string, $type = 'all', $site_guid = 0) {
    if(!empty($string)) {
        $params = array(
			'site_guid' => $site_guid,
			'original_string' => $string,
        );
        $string = elgg_trigger_plugin_hook('phloor_menuitem_replace_special_pattern', $type, $params, $string);
    }

    return $string;
}

/**
 *
 *
 * @param unknown_type $string
 * @param unknown_type $site_guid
 */
function phloor_menuitem_replace_default_sepcial_pattern_hook($hook, $type, $return, $params) {
    if($hook == 'phloor_menuitem_replace_special_pattern') {
        $wwwroot = elgg_get_site_url($params['site_guid']);
        $return = str_replace('%wwwroot%', $wwwroot, $return);

        // only if user is logged in replace the username pattern
        if(elgg_is_logged_in()) {
            $username = elgg_get_logged_in_user_entity()->username;
            $return = str_replace('%username%', $username, $return);
        }
    }

    return $return;
}