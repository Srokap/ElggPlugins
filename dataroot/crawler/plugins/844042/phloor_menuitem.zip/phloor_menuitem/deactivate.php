<?php

update_subtype('object', 'phloor_menuitem');
