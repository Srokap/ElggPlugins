<?php

$english = array(
	'rnvpwidget:widget' => 'ReverbNation Video Player',
	'rnvpwidget:description' => 'Add a ReverbNation Video Player to your profile',
	'rnvpwidget:artist_id' => 'Artist ID',
);

add_translation("en", $english);

