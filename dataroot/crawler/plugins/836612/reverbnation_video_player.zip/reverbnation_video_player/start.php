<?php
/**
 * ReverbNation Video Player Widget Widget
 *
 * Add the ReverbNation Video Player Widget to your Profile page.
 */

elgg_register_event_handler('init', 'system', 'reverbnation_video_widget_init');       

function reverbnation_video_widget_init() {        
    elgg_register_widget_type(
			'rnvpwidget',
			elgg_echo('rnvpwidget:widget'),
			elgg_echo('rnvpwidget:description')
			);
}
 
?>
