<?php

$artistid = $vars['entity']->artistid;

if ($artistid) {

echo "<center><img style=\"visibility:hidden;width:0px;height:0px;\" border=0 width=0 height=0 src=\"http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzMjUyNTI*NjA4ODcmcHQ9MTMyNTI1MjY1MjM4NyZwPTI3MDgxJmQ9cHJvX3ZpZGVvX2ZpcnN*X2dlbiZnPTEmbz1j/NzBjOWM1YjRiY2M*MzA5ODE3ZjU3ODIwNmJmMmZiYSZvZj*w.gif\" /><object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" width=\"262\" height=\"200\"><param name=\"movie\" value=\"http://cache.reverbnation.com/widgets/swf/41/pro_widget.swf?id=artist_".$artistid."&posted_by=artist_".$artistid."&skin_id=PWVS2002&border_color=000000&auto_play=false&shuffle=false\"></param><param name=\"allowscriptaccess\" value=\"always\"></param><param name=\"allowNetworking\" value=\"all\"></param><param name=\"allowfullscreen\" value=\"true\"></param><param name=\"wmode\" value=\"opaque\"></param><param name=\"quality\" value=\"best\"></param><embed src=\"http://cache.reverbnation.com/widgets/swf/41/pro_widget.swf?id=artist_".$artistid."&posted_by=artist_".$artistid."&skin_id=PWVS2002&border_color=000000&auto_play=false&shuffle=false\" type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowNetworking=\"all\" allowfullscreen=\"true\" wmode=\"opaque\" quality=\"best\" width=\"262\" height=\"200\"></embed></object><br/><img style=\"visibility:hidden;width:0px;height:0px;\" border=0 width=0 height=0 src=\"http://www.reverbnation.com/widgets/trk/41/artist_321169/artist_321169/t.gif\" /><img src=\"http://b.scorecardresearch.com/p?c1=2&c2=10349858&cv=2.0&cj=1\" style=\"display: none\" border=\"0\" height=\"1\" width=\"1\" alt=\"ComScore\"/></center>";


}else{

echo "To load a ReverbNation Tune Widget click the Settings Gear above and enter an Artist ID.";

}