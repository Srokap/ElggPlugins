<?php
/**
* Elgg vwtemplate widget
* This plugin allows users to pull in their vwtemplate feed to display on their profile
* 
* @package Elggvwtemplate
*/

function vwtemplate_init() {
	global $CONFIG;
	elgg_extend_view('css/elgg', 'vwtemplate/css');
	register_plugin_hook('index','system','vw_index');
}


function vw_index($hook, $type, $return, $params) {
	if ($return == true) {
		// another hook has already replaced the front page
		return $return;
	}

	global $CONFIG;
	$ver=explode('.', get_version(true));	
	if ($ver[1]>7)
	{
		if (!include_once(dirname(__FILE__) . "/indexrooms.php")) {
			return false;
		}
		}
	else 
	{		if (!include_once(dirname(__FILE__) . "/indexrooms-old.php")) {
			return false;
		}
	}

	// return true to signify that we have handled the front page
	return true;
}

// register for the init, system event when our plugin start.php is loaded
register_elgg_event_handler('init', 'system', 'vwtemplate_init');

// Register actions
global $CONFIG;
$ver=explode('.', get_version(true));	
if ($ver[1]>7)
register_action('vwtemplate/create',true,$CONFIG->pluginspath . "vwtemplate/actions/vwtemplate/create.php");
else register_action('vwtemplate/create',true,$CONFIG->pluginspath . "vwtemplate/actions/create.php");

?>
