<?php

	/**
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 */

	global $CONFIG;	 

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) {
			register_error(elgg_echo("vwtemplate:notloggedin"));
			forward("register/");
    }

	// Get input data
		$zroom = get_input('zroomname');
		$roomtype = get_input('room_type');
 		switch ($roomtype) {
        case 'videoconference':
          forward("videoconference/createrooms?roomname=".$zroom);
          break;
        case 'videochat':
          forward("videochat/createrooms?roomname=".$zroom);
          break;
        case 'videoconsultation':
          forward("videoconsultation/createrooms?roomname=".$zroom);
          break;
        case 'livestreaming':
          forward("livestreaming/createrooms?roomname=".$zroom);
          break;
        default :
			    register_error(elgg_echo("vwtemplate:noroomtype"));
          forward();
          break;
      }
?>
