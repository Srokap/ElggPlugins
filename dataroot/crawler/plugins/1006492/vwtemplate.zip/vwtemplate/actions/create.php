<?php

	/**
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 */

	global $CONFIG;	 

	// Make sure we're logged in (send us to the front page if not)
		if (!isloggedin()) {
			register_error(elgg_echo("vwtemplate:notloggedin"));
			forward("pg/register/");
    }

	// Get input data
		$room = get_input('roomname');
		$roomtype = get_input('roomtype');
 		switch ($roomtype) {
        case 'videoconference':
          forward("mod/videoconference/create.php?roomname=".$room);
          break;
        case 'videochat':
          forward("mod/videochat/create.php?roomname=".$room);
          break;
        case 'videoconsultation':
          forward("mod/videoconsultation/create.php?roomname=".$room);
          break;
        case 'livestreaming':
          forward("mod/livestreaming/create.php?roomname=".$room);
          break;
      }
?>
