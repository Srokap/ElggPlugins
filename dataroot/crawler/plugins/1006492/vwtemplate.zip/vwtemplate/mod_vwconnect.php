<?php

    // is admin enable twitter and facebook ?
    $twitterEnable = datalist_get('vwconnect_twenable');
    $facebookEnable = datalist_get('vwconnect_fbenable');

    if (isloggedin()) {
      $isconnecttw = "";
      $isconnectfb = "";

    // twitter
    if ($twitterEnable) {
    $sctitle = "<br/><br/><div id=\"content_area_user_title\"><h3>Social Connectors</h3></div>";
    
    $twitter_ck = datalist_get('vwconnect_twitter_ck');
    $twitter_csk = datalist_get('vwconnect_twitter_csk');
    if ($twitter_ck && $twitter_csk) {
		session_start();
		require_once('mod/vwconnect/twitteroauth/twitteroauth.php');
		require_once('mod/vwconnect/config.php');
	  if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
		 $isconnecttw = "<div id=\"vwsocialconnect\" >".
											 "<a href=\"./vwconnect/connect?service=twitter\">".
											 "Connect Twitter Account</a></div>";
    } else {
		/* Get user access tokens out of the session. */
		$access_token = $_SESSION['access_token'];

		/* Create a TwitterOauth object with consumer/user tokens. */
		$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

		/* If method is set change API call made. Test is called by default. */
		$twitter = $connection->get('account/verify_credentials');
		// $connection->post('statuses/update', array('status' => date(DATE_RFC822)));
		$isconnecttw = "<div id=\"vwsocialconnect\" >Connected Twitter account <a href=\"http://twitter.com/".$twitter->screen_name."\">".$twitter->screen_name."</a>, <a href=\"".$CONFIG->url."vwconnect/clearsessions\">Disconnect</a></div>";

    }
    }
  }// end twitter

    // facebook
  if ($facebookEnable) {
	require 'mod/vwconnect/src/facebook.php';
  $sctitle = "<br/><br/><div id=\"content_area_user_title\"><h3>Social Connectors</h3></div>";
		
	// Create our Application instance (replace this with your appId and secret).
	$appId = datalist_get('vwconnect_facebook_appId');
	$secret = datalist_get('vwconnect_facebook_secret');
	if ($appId && $secret) {
	$facebook = new Facebook(array(
		'appId' => $appId,
		'secret' => $secret,
		'cookie' => false,
	));

	// Get User ID
	$fbuser = $facebook->getUser();

	// We may or may not have this data based on whether the user is logged in.
	//
	// If we have a $user id here, it means we know the user is logged into
	// Facebook, but we don't know if the access token is valid. An access
	// token is invalid if the user logged out of Facebook.
	$isconnectfb = "<div id=\"vwsocialconnect\"><a href=\"./vwconnect/connect?service=facebook\">Connect Facebook Account</a></div>";

	if ($fbuser) {
		try {
			// Proceed knowing you have a logged in user who's authenticated.
      $logoutUrl = $facebook->getLogoutUrl();
			$user_profile = $facebook->api('/me');
			$isconnectfb = "<div id=\"vwsocialconnect\" >Connected Facebook account: <a href=\"".$user_profile['link']."\">".$user_profile['username']."</a>, <a href=\"".$logoutUrl."\">Disconnect</a></div>";
    }
    catch (FacebookApiException $e) {
			error_log($e);
			$user = null;
			$isconnectfb = "<div id=\"vwsocialconnect\" ><a href=\"./vwconnect/connect?service=facebook\">Connect Facebook Account</a></div>";
		}
	 } // end fbuser
  }
  } // akhir fb
    
    } else { // if (!isloggedin)
    // for cek username in elgg_user
    $twittersn1 = $_COOKIE['twittersn1'];

    // registration page cek
    $regfb = $_COOKIE['regfb'];
    $regtw = $_COOKIE['regtw'];

    // twitter
  if ($twitterEnable) {
    $sctitle = "<br/><br/><div id=\"content_area_user_title\"><h3>Social Connectors</h3></div>";
	  $socialconnect2 = "<div id=\"vwsocialconnect\" ><a href=\"./vwconnect/connect?service=logintw\">Login with Twitter</a></div>";
    $socialreg2 = "<div id=\"vwsocialconnect\" ><a href=\"./vwconnect/connect?service=registertw\">Register with Twitter</a></div>";

    $twitter_ck = datalist_get('vwconnect_twitter_ck');
    $twitter_csk = datalist_get('vwconnect_twitter_csk');
    if ($twitter_ck && $twitter_csk) {
		session_start();
		require_once('mod/vwconnect/twitteroauth/twitteroauth.php');
		require_once('mod/vwconnect/config.php');
	  if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
	   $socialconnect2 = "<div id=\"vwsocialconnect\" ><a href=\"./vwconnect/connect?service=logintw\">Login with Twitter</a></div>";  
		 $isconnecttw = "<div id=\"vwsocialconnect\" >".
											 "<a href=\"./vwconnect/connect?service=twitter\">".
											 "Connect Twitter Account</a></div>";
    } else {
		/* Get user access tokens out of the session. */
		$access_token = $_SESSION['access_token'];

		/* Create a TwitterOauth object with consumer/user tokens. */
		$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

		/* If method is set change API call made. Test is called by default. */
		$twitter = $connection->get('account/verify_credentials');
		// $connection->post('statuses/update', array('status' => date(DATE_RFC822)));
		$isconnecttw = "<div id=\"vwsocialconnect\" >Connected Twitter account: <a href=\"http://twitter.com/".$twitter->screen_name."\">".$twitter->screen_name."</a>, <a href=\"".$CONFIG->url."mod/vwconnect/clearsessions.php\">Disconnect</a></div>";

    $twittersn = $twitter->screen_name;
    $twittern = $twitter->name;

    // cek account di objects_entity
    $sqltwitter = "SELECT ".$CONFIG->dbprefix."objects_entity.description ".
			 "FROM ( ".$CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entity_subtypes.id = ".$CONFIG->dbprefix."entities.subtype) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'vwsocialaccounttw' AND ".
			 $CONFIG->dbprefix."objects_entity.title = '".$twittersn."' LIMIT 1;";

      $hasiltw = mysql_query ($sqltwitter);
      $hasiltw2 = mysql_fetch_array ($hasiltw);
      if ($usernametw = $hasiltw2[0]) {
        $usertw = get_user_by_username($usernametw);
        if ($usertw != "") {
          login($usertw);
       		forward();
       	}
      } elseif (!isset ($registertw)) {
          // set cookie for register action
          setcookie("twittersn",$twittersn,time()+300,'/');
          setcookie("registertw",1,time()+10,'/');
		      if ($regtw != "1") register_error(elgg_echo("vwconnect:noaccount"));
          // go to registration page
		      $url = "vwconnect/connect?service=register&n=".$twittern."&u=".$twittersn;
		      forward($url);
        } else unset($_SESSION['access_token']);
      }
    } else register_error(elgg_echo("vwconnect:notfilleduser"));
  }// end twitter
    
    // facebook
  if ($facebookEnable) {
	require 'mod/vwconnect/src/facebook.php';
  $sctitle = "<br/><br/><div id=\"content_area_user_title\"><h3>Social Connectors</h3></div>";
  $socialconnect1 = "<div id=\"vwsocialconnect\"><a href=\"./vwconnect/connect?service=loginfb\">Login with Facebook</a></div>";
  $socialreg1 =  "<div id=\"vwsocialconnect\" ><a href=\"./vwconnect/connect?service=registerfb\">Register with Facebook</a></div>";
		
	// Create our Application instance (replace this with your appId and secret).
	$appId = datalist_get('vwconnect_facebook_appId');
	$secret = datalist_get('vwconnect_facebook_secret');
	if ($appId && $secret) {
	$facebook = new Facebook(array(
		'appId' => $appId,
		'secret' => $secret,
		'cookie' => false,
	));

	// Get User ID
	$fbuser = $facebook->getUser();

	// We may or may not have this data based on whether the user is logged in.
	//
	// If we have a $user id here, it means we know the user is logged into
	// Facebook, but we don't know if the access token is valid. An access
	// token is invalid if the user logged out of Facebook.

	if ($fbuser) {
		try {
			// Proceed knowing you have a logged in user who's authenticated.
      $logoutUrl = $facebook->getLogoutUrl();
			$user_profile = $facebook->api('/me');
			$isconnectfb = "<div id=\"vwsocialconnect\" >Connected Facebook account: <a href=\"".$user_profile['link']."\">".$user_profile['username']."</a>, <a href=\"".$logoutUrl."\">Disconnect</a></div>";
      $facebookemail = $user_profile['email'];
      $facebookusername = $user_profile['username'];
      $facebookname = $user_profile['name'];
      
    // cek account di objects_entity
    $sqlfacebook = "SELECT ".$CONFIG->dbprefix."objects_entity.description ".
			 "FROM ( ".$CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entity_subtypes.id = ".$CONFIG->dbprefix."entities.subtype) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'vwsocialaccountfb' AND ".
			 $CONFIG->dbprefix."objects_entity.title = '".$facebookemail."';";

      $hasilfb = mysql_query ($sqlfacebook);
      $hasilfb2 = mysql_fetch_array ($hasilfb);
      $registerfb = $_COOKIE['registerfb'];
      if ($usernamefb = $hasilfb2[0]) {
          $userfb = get_user_by_username($usernamefb);
        if ($userfb != "") {
          login($userfb);
       		forward();
       	}
      } elseif (!isset ($registerfb)) {
          // set cookie for register action
          setcookie("facebookemail",$facebookemail,time()+300,'/');
          setcookie("registerfb",1,time()+10,'/');
		      if ($regfb != "1") register_error(elgg_echo("vwconnect:noaccount"));
          // go to registration page
		      $url = "vwconnect/connect?service=register&n=".$facebookname."&u=".$facebookusername."&e=".$facebookemail;
		      forward($url);        
        } else $fbuser = $facebook->getLogoutUrl();
    }
    catch (FacebookApiException $e) {
			error_log($e);
			$user = null;
			$isconnectfb = "<div id=\"vwsocialconnect\" ><a href=\"./vwconnect/connect?service=facebook\">Connect Facebook Account</a></div>";
		}
	 } // end fbuser
	 } else register_error(elgg_echo("vwconnect:notfilleduser"));  // end ($appId && $secret)
  } // akhir fb
  } // end if (!isloggedin)

?>
