<?php

	/**
	 * Elgg custom index
	 * 
	 * @package ElggCustomIndex
	 */

	// Get the Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	global $CONFIG;
  
  // vw connect
  if (elgg_is_active_plugin(vwconnect,0)) {
    include ("mod_vwconnect.php");
  }

  // onlinescreenshot  
  if (elgg_is_active_plugin(onlinescreenshot,0)) {
    include ("mod_onlinescreenshot.php");
  }
	
	// open new video
  $open_new = elgg_view('vwtemplate/open_new');

	//Load the front page
  include ("most_active.php");

	if (elgg_is_logged_in()) {
    $params = array(
		  'content' => $vwtitle . $pagination.$content.$pagination.$vwtitle2.$pagination2.$content2.$pagination2,
		  'sidebar' => $open_new.$sctitle.$isconnecttw.$isconnectfb
    );
  }
	else {
//    $login_box = elgg_view('core/account/login_box');
    $params = array(
		  'content' => $vwtitle . $pagination.$content.$pagination.$vwtitle2.$pagination2.$content2.$pagination2,
		  'sidebar' => $open_new.$sctitle.$socialreg1.$socialreg2.$socialconnect1.$socialconnect2.$login_box
    );
	}
	$content = elgg_view_layout('one_sidebar', $params);
  echo elgg_view_page(elgg_echo('vwtemplate:title'), $content, 'default', array( 'sidebar' => "" ));
	
?>
