<?php

	$vwtitle = elgg_view_title(elgg_echo('vwtemplate:title'));
  $ver=explode('.', get_version(true));	
  if ($ver[1]>7) elgg_set_context('search');
	else set_context('search');
	$page = (int)get_input('page', 1);


	$sqlliveusercount = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.guid, ".
			 $CONFIG->dbprefix."objects_entity.title ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 "LEFT(".$CONFIG->dbprefix."objects_entity.description,3) IN
               ('1:1', '2:1', '3:1', '4:1', '5:1') ORDER BY title DESC;";

	$ztime = time();
	$exptime=$ztime-30;
  $arr1 = array ();
  $isNoRoomActive = true;
	
	if ($rows = get_data($sqlliveusercount)) {
		foreach($rows as $row) {
			$descriptionx = $row->description; 
			$guid = $row->guid;
			$title = $row->title;

			$nilai = explode(":", $descriptionx);
			$newdescription = "";
			if ($nilai[3] < $exptime) {	// if last access time < exptime
				for ($i = 0; $i <= 2; $i++) {
					if ($i == 1) 
						$newdescription .= "0:"; // set status as 0 ( logout )
					else
						$newdescription .= $nilai[$i].":";
				}
				$newdescription .= $nilai[3];
				$result = update_data("UPDATE {$CONFIG->dbprefix}objects_entity 
				set description='$newdescription' 
				where guid=$guid ;");
			} else {
        array_push ($arr1, $nilai[0].":".$title.":".$nilai[2]); // roomtype:roomname:liveuser
			}
			
		}
		array_push ($arr1, "end:end:end");
	}

// get most active rooms
	$arr2 = array ();
	if ($arr1) {
	   // inisial
	  $isi = explode(":", $arr1[0]);
	  $videotype = $isi[0];
    $judul = $isi[1];
	  $users = "";
	  $count = 0;
		foreach($arr1 as $arr) {
    $nilai = explode(":", $arr);
    if (($nilai[1]==$judul) && ($nilai[0]==$videotype)) { // sama dengan judul dan type sebelumnya
      if ($count<5) {
        if ($count==0) $users = $nilai[2]; 
        else $users .= ', '.$nilai[2];
      }
      $count ++;
    } else { // simpan data lama dan perbarui inisial
      array_push ($arr2, $count.":".$judul.":".$videotype.":".$users);
      $videotype = $nilai[0];
      $judul = $nilai[1];
      $users = $nilai[2];
	    $count = 1;
      }
    }
  }

// jika broadcast aktif, tambahkan liveuser dari watch dan video
$jml = count ($arr2);
if ($arr2) {
  for ($a=0; $a<$jml; $a++) {
    if ($arr2[$a]!= "") {
    $nilai = explode(":", $arr2[$a]);
      if (($nilai[2]=='5') || ($nilai[2]=='4')) { // broadcast or watch/video
        for ($b=$a+1; $b<$jml; $b++) {
          if ($arr2[$b]!= "") {
          $nilai2 = explode(":", $arr2[$b]);
          if ($nilai2[1]==$nilai[1]) { // nama room sama
            $nilai2[0]=$nilai[0]+1; // count
            $nilai2[3]=$nilai[3].", ".$nilai2[3]; // users
            array_push ($arr2, $nilai2[0].":".$nilai2[1].":4:".$nilai2[3]); // perbaharui data
            $arr2[$a]="";
            $arr2[$b]="";
          }
        }}
      }}
  }
}

// hapus yang kosong
sort ($arr2);
foreach ($arr2 as $arr) {
  if ($arr == "") array_shift ($arr2);
}

// sort most active
$arr3=array();
foreach ($arr2 as $arr) {
    $nilai = explode(":", $arr);
    $arr3 = array ($nilai[0]=>$arr)+$arr3;
}

krsort ($arr3);

$arr4=array();
foreach ($arr3 as $arr) {
  array_push ($arr4, $arr);
}
$jmlarr = count ($arr4);
for ($a=0; $a<$jmlarr; $a++) {
  if ($arr4[$a]!= "") {
    $nilai = explode(":", $arr4[$a]);
    $jmlkoma=substr_count($nilai[3], ",");
    if ($jmlkoma>3 && $nilai[0]>5) {
      if ($nilai[2]=='4') {
        if ($nilai[0]>6 && $jmlkoma=='5') $nilai[3]= $nilai[3].",+";
      } else $nilai[3]= $nilai[3].",+";
      $arr4[$a] = $nilai[0].":".$nilai[1].":".$nilai[2].":".$nilai[3];
    }
  }
}


	$roomcount = count ($arr4);
	$limit = 10;
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;								//halaman awal
	
	if ($page == 0) $page = 1;					//jika variabel kosong maka defaultnya halaman pertama.
	$prev = $page - 1;		//halaman sebelumnya
	$next = $page + 1;		//halaman berikutnya
	$lastpage = ceil($roomcount/$limit);		
	$adjacents = 3;
	$targetpage = "index.php";
	$lpm1 = $lastpage - 1;						
	$pagination = "";
// ==========
	if($lastpage > 1)	{	
		$pagination .= "<div class=\"pagination\">";
		//Link halaman sebelumnya
		if ($page > 1) 
			$pagination.= "<a class=\"pagination_previous\" href=\"$targetpage?page=$prev\">&#171; Previous</a>";
		else
			$pagination.= "&nbsp;"; //"<span class=\"disabled\">&#171; Previous</span>";	
 
		//halaman
		if ($lastpage < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
				else
					$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
 
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
			}
 
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
				$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
			}
 
			else
			{
				$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
				}
			}
		}
 
		//link halaman selanjutnya
		if ($page < $counter - 1) 
			$pagination.= "<a class=\"pagination_next\" href=\"$targetpage?page=$next\">Next &#187;</a>";
		else
			$pagination.= "&nbsp;"; //"<span class=\"disabled\">Next &#187;</span>";
		$pagination.= "<div class=\"clearfloat\"></div></div>\n";		
	}

// view arr2
  $content = "";

if ($arr4) {
	for ($no=$start; $no< $start+$limit; $no++) {
   $nilai = explode(":", $arr4[$no]);
	 if ($arr4[$no]!="" && $nilai[2]!='5') {
	$isNoRoomActive = false;
	 $content .=  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\">";

		if ($nilai[2] == '1') {
			$content .=  "<a href=\"$CONFIG->wwwroot"."videoconference/$nilai[1]\">$nilai[1]</a> video conference room active.<br /> 
			Live users : $nilai[0] ($nilai[3])";
		}
		elseif ($nilai[2] == '2') {
			$content .=  "<a href=\"$CONFIG->wwwroot"."videochat/$nilai[1]\">$nilai[1]</a> video chat room active.<br /> 
			Live users : $nilai[0] ($nilai[3])";
		}
		elseif ($nilai[2] == '3') {
			$content .=  "<a href=\"$CONFIG->wwwroot"."videoconsultation/$nilai[1]\">$nilai[1]</a> video consultation room active.<br /> 
			Live users : $nilai[0] ($nilai[3])";
		}
		elseif ($nilai[2] == '4') {
      // picture
      // get last modified picture
      $lstr_snapshotsTime = datalist_get('lstr_snapshotsTime');
    	$ztime = time();
      $exptime_lstr=$ztime-$lstr_snapshotsTime;

      $alamat = $CONFIG->pluginspath ."livestreaming/snapshots/".$nilai[1].".jpg";
      $lastmodif = date(filemtime($alamat));
      //echo $lastmodif;
      if ($lastmodif > $exptime_lstr) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
        $content .= "<div class=\"vwtemplate_picture\" > <img src=\"$CONFIG->wwwroot"."mod/livestreaming/snapshots/".$nilai[1].".jpg\" height=40px> </div>";
      }

// get ownerroom_username
$sql2 = "SELECT ".$CONFIG->dbprefix."users_entity.username ".
			 "FROM    ( (  ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
			 "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
			 "INNER JOIN ".
          $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
			 "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."users_entity ".$CONFIG->dbprefix."users_entity ".
			 "ON (".$CONFIG->dbprefix."entities.owner_guid = ".$CONFIG->dbprefix."users_entity.guid) ".
			 "WHERE ((".$CONFIG->dbprefix."objects_entity.title = '".$nilai[1]."') AND (".$CONFIG->dbprefix."entity_subtypes.subtype = 'livestreaming'))
 LIMIT 1;";
      $hasil = mysql_query ($sql2);
      $hasil2 = mysql_fetch_array ($hasil);
      // get username
      $ElggUser=get_loggedin_user();
      if (isset ($ElggUser)) $username=$ElggUser->get("username");
      if ($hasil2[0] == $username)
        $content .=  "<a href=\"$CONFIG->wwwroot"."livestreaming/$nilai[1]?live=1\">$nilai[1]</a> live channel active.<br />";
        else $content .=  $nilai[1]." live channel active. <a href=\"$CONFIG->wwwroot"."livestreaming/$nilai[1]?live=2\"> Watch and Chat</a> | <a href=\"$CONFIG->wwwroot"."livestreaming/$nilai[1]?live=3\"> Just Watch Video</a><br />";
        $content .=  "Live users : $nilai[0] ($nilai[3])";
      }

	$content .=  "</div> </div> </div>";
}}}
if ($isNoRoomActive) $content =  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\"> &nbsp; No room active. </div> </div> </div>";

?>
