<?php
/**
 * vwtemplate widget language file
 */

$english = array(

	'vwtemplate' => 'vwtemplate',
	'vwtemplate:title' => 'Most active Rooms',
	'vwtemplate:title2' => 'Screenshots of online users',
	'vwtemplate:createroom' => 'Create room',
	'vwtemplate:create' => 'Create',
	'vwtemplate:roomtype' => 'Room type :',
	'vwtemplate:roomname' => 'Room name :',
	
	'vwtemplate:error' => 'error !!',
	'vwtemplate:noroomtype' => 'Select a room type !',
	'vwtemplate:notloggedin' => 'You have not registered.',
	
);
					
add_translation("en", $english);
