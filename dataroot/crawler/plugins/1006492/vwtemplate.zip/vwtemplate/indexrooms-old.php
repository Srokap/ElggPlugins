<?php

	/**
	 * Elgg custom index
	 * 
	 * @package ElggCustomIndex
	 */

	// Get the Elgg engine
	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	global $CONFIG;
  
  // vw connect
  if (is_plugin_enabled (vwconnect)) {
    // is admin enable twitter and facebook ?
    $twitterEnable = datalist_get('vwconnect_twenable');
    $facebookEnable = datalist_get('vwconnect_fbenable');

    if (isloggedin()) {
      // Logged in users should also have that section to connect/disconnect their FB/TW accounts from their Elgg account
      $isconnecttw = "";
      $isconnectfb = "";

    // twitter
    if ($twitterEnable) {
    $sctitle = "<div id=\"content_area_user_title\"><h2>Social Connectors</h2></div>";
    
    $twitter_ck = datalist_get('vwconnect_twitter_ck');
    $twitter_csk = datalist_get('vwconnect_twitter_csk');
    if ($twitter_ck && $twitter_csk) {
		session_start();
		require_once('mod/vwconnect/twitteroauth/twitteroauth.php');
		require_once('mod/vwconnect/config.php');
	  if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
		 $isconnecttw = "<div id=\"vwsocialconnect\" >".
											 "<a href=\"./pg/vwconnect/connect?service=twitter\">".
											 "Connect to Twitter</a></div>";
    } else {
		/* Get user access tokens out of the session. */
		$access_token = $_SESSION['access_token'];

		/* Create a TwitterOauth object with consumer/user tokens. */
		$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

		/* If method is set change API call made. Test is called by default. */
		$twitter = $connection->get('account/verify_credentials');
		// $connection->post('statuses/update', array('status' => date(DATE_RFC822)));
		$isconnecttw = "<div id=\"vwsocialconnect\" >Connected on Twitter as: <a href=\"http://twitter.com/".$twitter->screen_name."\">".$twitter->screen_name."</a>, <a href=\"".$CONFIG->url."mod/vwconnect/clearsessions.php\">Disconnect</a></div>";

    }
    }
  }// end twitter

    // facebook
  if ($facebookEnable) {
	require 'mod/vwconnect/src/facebook.php';
  $sctitle = "<div id=\"content_area_user_title\"><h2>Social Connectors</h2></div>";
		
	// Create our Application instance (replace this with your appId and secret).
	$appId = datalist_get('vwconnect_facebook_appId');
	$secret = datalist_get('vwconnect_facebook_secret');
	if ($appId && $secret) {
	$facebook = new Facebook(array(
		'appId' => $appId,
		'secret' => $secret,
		'cookie' => false,
	));

	// Get User ID
	$fbuser = $facebook->getUser();

	// We may or may not have this data based on whether the user is logged in.
	//
	// If we have a $user id here, it means we know the user is logged into
	// Facebook, but we don't know if the access token is valid. An access
	// token is invalid if the user logged out of Facebook.
	$isconnectfb = "<div id=\"vwsocialconnect\"><a href=\"./pg/vwconnect/connect?service=facebook\">Connect to facebook</a></div>";

	if ($fbuser) {
		try {
			// Proceed knowing you have a logged in user who's authenticated.
      $logoutUrl = $facebook->getLogoutUrl();
			$user_profile = $facebook->api('/me');
			$isconnectfb = "<div id=\"vwsocialconnect\" >Connected on Facebook as: <a href=\"".$user_profile['link']."\">".$user_profile['username']."</a>, <a href=\"".$logoutUrl."\">Disconnect</a></div>";
    }
    catch (FacebookApiException $e) {
			error_log($e);
			$user = null;
			$isconnectfb = "<div id=\"vwsocialconnect\" ><a href=\"./pg/vwconnect/connect?service=facebook\">Connect to facebook</a></div>";
		}
	 } // end fbuser
  }
  } // akhir fb
    
    } else { // if (!isloggedin)
    // for cek username in elgg_user
    $twittersn1 = $_COOKIE['twittersn1'];

    // registration page cek
    $regfb = $_COOKIE['regfb'];
    $regtw = $_COOKIE['regtw'];

    // twitter
  if ($twitterEnable) {
    $sctitle = "<div id=\"content_area_user_title\"><h2>Social Connectors</h2></div>";
	  $socialconnect2 = "<div id=\"vwsocialconnect\" ><a href=\"./pg/vwconnect/connect?service=logintw\">Login with Twitter</a></div>";
    $socialreg2 = "<div id=\"vwsocialconnect\" ><a href=\"./pg/vwconnect/connect?service=registertw\">Register with Twitter</a></div>";

    $twitter_ck = datalist_get('vwconnect_twitter_ck');
    $twitter_csk = datalist_get('vwconnect_twitter_csk');
    if ($twitter_ck && $twitter_csk) {
		session_start();
		require_once('mod/vwconnect/twitteroauth/twitteroauth.php');
		require_once('mod/vwconnect/config.php');
	  if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
	   $socialconnect2 = "<div id=\"vwsocialconnect\" ><a href=\"./pg/vwconnect/connect?service=logintw\">Login with Twitter</a></div>";  
		 $isconnecttw = "<div id=\"vwsocialconnect\" >".
											 "<a href=\"./pg/vwconnect/connect?service=twitter\">".
											 "Connect to Twitter</a></div>";
    } else {
		/* Get user access tokens out of the session. */
		$access_token = $_SESSION['access_token'];

		/* Create a TwitterOauth object with consumer/user tokens. */
		$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

		/* If method is set change API call made. Test is called by default. */
		$twitter = $connection->get('account/verify_credentials');
		// $connection->post('statuses/update', array('status' => date(DATE_RFC822)));
		$isconnecttw = "<div id=\"vwsocialconnect\" >Connected on Twitter as: <a href=\"http://twitter.com/".$twitter->screen_name."\">".$twitter->screen_name."</a>, <a href=\"".$CONFIG->url."mod/vwconnect/clearsessions.php\">Disconnect</a></div>";

    $twittersn = $twitter->screen_name;
    $twittern = $twitter->name;

    // cek account di objects_entity
    $sqltwitter = "SELECT ".$CONFIG->dbprefix."objects_entity.description ".
			 "FROM ( ".$CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entity_subtypes.id = ".$CONFIG->dbprefix."entities.subtype) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'vwsocialaccounttw' AND ".
			 $CONFIG->dbprefix."objects_entity.title = '".$twittersn."' LIMIT 1;";

      $hasiltw = mysql_query ($sqltwitter);
      $hasiltw2 = mysql_fetch_array ($hasiltw);
      if ($usernametw = $hasiltw2[0]) {
        $usertw = get_user_by_username($usernametw);
        if ($usertw != "") {
          login($usertw);
       		forward("pg/dashboard/");
       	}
      } elseif (!isset ($registertw)) {
          // set cookie for register action
          setcookie("twittersn",$twittersn,time()+300,'/');
          setcookie("registertw",1,time()+10,'/');
		      if ($regtw != "1") register_error(elgg_echo("vwconnect:noaccount"));
          // go to registration page
		      $url = "pg/vwconnect/connect?service=register&n=".$twittern."&u=".$twittersn;
		      forward($url);
        } else unset($_SESSION['access_token']);
      }
    } else register_error(elgg_echo("vwconnect:notfilleduser"));
  }// end twitter
    
    // facebook
  if ($facebookEnable) {
	require 'mod/vwconnect/src/facebook.php';
  $sctitle = "<div id=\"content_area_user_title\"><h2>Social Connectors</h2></div>";
  $socialconnect1 = "<div id=\"vwsocialconnect\"><a href=\"./pg/vwconnect/connect?service=loginfb\">Login with Facebook</a></div>";
  $socialreg1 =  "<div id=\"vwsocialconnect\" ><a href=\"./pg/vwconnect/connect?service=registerfb\">Register with Facebook</a></div>";
		
	// Create our Application instance (replace this with your appId and secret).
	$appId = datalist_get('vwconnect_facebook_appId');
	$secret = datalist_get('vwconnect_facebook_secret');
	if ($appId && $secret) {
	$facebook = new Facebook(array(
		'appId' => $appId,
		'secret' => $secret,
		'cookie' => false,
	));

	// Get User ID
	$fbuser = $facebook->getUser();

	// We may or may not have this data based on whether the user is logged in.
	//
	// If we have a $user id here, it means we know the user is logged into
	// Facebook, but we don't know if the access token is valid. An access
	// token is invalid if the user logged out of Facebook.

	if ($fbuser) {
		try {
			// Proceed knowing you have a logged in user who's authenticated.
      $logoutUrl = $facebook->getLogoutUrl();
			$user_profile = $facebook->api('/me');
			$isconnectfb = "<div id=\"vwsocialconnect\" >Connected on Facebook as: <a href=\"".$user_profile['link']."\">".$user_profile['username']."</a>, <a href=\"".$logoutUrl."\">Disconnect</a></div>";
      $facebookemail = $user_profile['email'];
      $facebookusername = $user_profile['username'];
      $facebookname = $user_profile['name'];
      
    // cek account di objects_entity
    $sqlfacebook = "SELECT ".$CONFIG->dbprefix."objects_entity.description ".
			 "FROM ( ".$CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entity_subtypes.id = ".$CONFIG->dbprefix."entities.subtype) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'vwsocialaccountfb' AND ".
			 $CONFIG->dbprefix."objects_entity.title = '".$facebookemail."';";

      $hasilfb = mysql_query ($sqlfacebook);
      $hasilfb2 = mysql_fetch_array ($hasilfb);
      $registerfb = $_COOKIE['registerfb'];
      if ($usernamefb = $hasilfb2[0]) {
          $userfb = get_user_by_username($usernamefb);
        if ($userfb != "") {
          login($userfb);
       		forward("pg/dashboard/");
       	}
      } elseif (!isset ($registerfb)) {
          // set cookie for register action
          setcookie("facebookemail",$facebookemail,time()+300,'/');
          setcookie("registerfb",1,time()+10,'/');
		      if ($regfb != "1") register_error(elgg_echo("vwconnect:noaccount"));
          // go to registration page
		      $url = "pg/vwconnect/connect?service=register&n=".$facebookname."&u=".$facebookusername."&e=".$facebookemail;
		      forward($url);        
        } else $fbuser = $facebook->getLogoutUrl();
    }
    catch (FacebookApiException $e) {
			error_log($e);
			$user = null;
			$isconnectfb = "<div id=\"vwsocialconnect\" ><a href=\"./pg/vwconnect/connect?service=facebook\">Connect to facebook</a></div>";
		}
	 } // end fbuser
	 } else register_error(elgg_echo("vwconnect:notfilleduser"));  // end ($appId && $secret)
  } // akhir fb
  } // end if (!isloggedin)
  } // end vwconnect
	
	// open new video
	$generated =  base_convert((time()-1224000000).rand(0,15),10,36);
	$videos_actived = array ();
	if (is_plugin_enabled (videoconference)) array_push ($videos_actived, videoconference);
	if (is_plugin_enabled (videochat)) array_push ($videos_actived, videochat);
	if (is_plugin_enabled (videoconsultation)) array_push ($videos_actived, videoconsultation);
	if (is_plugin_enabled (livestreaming)) array_push ($videos_actived, livestreaming);
  $action1 = $CONFIG->wwwroot;
	$action1.= "action/vwtemplate/create";
  $action1 = elgg_add_action_tokens_to_url($action1);
	$optionvideo = "";
	foreach ($videos_actived as $video_actived) {
		$optionvideo.= "<option value=\"$video_actived\">$video_actived</option>";
	}

	$opennew =  <<< htmlEND
	<p> <div id="open-new">
	<form action=$action1 method="post">
	<label>Room Type : <label><br />
      <select name="roomtype"><option selected="selected" value="0">--</option>$optionvideo</select></label><br /><br />
<label>Room Name:<br />
	<input name='roomname' value='$generated' size="10"></label><br />
      <input type="submit" value="create" />
	</form>
</div></p>
htmlEND;


	//Load the front page

	$vwtitle = elgg_view_title(elgg_echo('vwtemplate:title'));
  set_context('search');
	$page = (int)get_input('page', 1);


	$sqlliveusercount = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.guid, ".
			 $CONFIG->dbprefix."objects_entity.title ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 "LEFT(".$CONFIG->dbprefix."objects_entity.description,3) IN
               ('1:1', '2:1', '3:1', '4:1', '5:1') ORDER BY title DESC;";

	$ztime = time();
	$exptime=$ztime-30;
  $arr1 = array ();
  $isNoRoomActive = true;
	
	if ($rows = get_data($sqlliveusercount)) {
		foreach($rows as $row) {
			$descriptionx = $row->description; 
			$guid = $row->guid;
			$title = $row->title;

			$nilai = explode(":", $descriptionx);
			$newdescription = "";
			if ($nilai[3] < $exptime) {	// if last access time < exptime
				for ($i = 0; $i <= 2; $i++) {
					if ($i == 1) 
						$newdescription .= "0:"; // set status as 0 ( logout )
					else
						$newdescription .= $nilai[$i].":";
				}
				$newdescription .= $nilai[3];
				$result = update_data("UPDATE {$CONFIG->dbprefix}objects_entity 
				set description='$newdescription' 
				where guid=$guid ;");
			} else {
        array_push ($arr1, $nilai[0].":".$title.":".$nilai[2]); // roomtype:roomname:liveuser
			}
			
		}
		array_push ($arr1, "end:end:end");
	}

// get most active rooms
	$arr2 = array ();
	if ($arr1) {
	   // inisial
	  $isi = explode(":", $arr1[0]);
	  $videotype = $isi[0];
    $judul = $isi[1];
	  $users = "";
	  $count = 0;
		foreach($arr1 as $arr) {
    $nilai = explode(":", $arr);
    if (($nilai[1]==$judul) && ($nilai[0]==$videotype)) { // sama dengan judul dan type sebelumnya
      if ($count<5) {
        if ($count==0) $users = $nilai[2]; 
        else $users .= ', '.$nilai[2];
      }
      $count ++;
    } else { // simpan data lama dan perbarui inisial
      array_push ($arr2, $count.":".$judul.":".$videotype.":".$users);
      $videotype = $nilai[0];
      $judul = $nilai[1];
      $users = $nilai[2];
	    $count = 1;
      }
    }
  }

// jika broadcast aktif, tambahkan liveuser dari watch dan video
$jml = count ($arr2);
if ($arr2) {
  for ($a=0; $a<$jml; $a++) {
    if ($arr2[$a]!= "") {
    $nilai = explode(":", $arr2[$a]);
      if (($nilai[2]=='5') || ($nilai[2]=='4')) { // broadcast or watch/video
        for ($b=$a+1; $b<$jml; $b++) {
          if ($arr2[$b]!= "") {
          $nilai2 = explode(":", $arr2[$b]);
          if ($nilai2[1]==$nilai[1]) { // nama room sama
            $nilai2[0]=$nilai[0]+1; // count
            $nilai2[3]=$nilai[3].", ".$nilai2[3]; // users
            array_push ($arr2, $nilai2[0].":".$nilai2[1].":4:".$nilai2[3]); // perbaharui data
            $arr2[$a]="";
            $arr2[$b]="";
          }
        }}
      }}
  }
}

// hapus yang kosong
sort ($arr2);
foreach ($arr2 as $arr) {
  if ($arr == "") array_shift ($arr2);
}

// sort most active
$arr3=array();
foreach ($arr2 as $arr) {
    $nilai = explode(":", $arr);
    $arr3 = array ($nilai[0]=>$arr)+$arr3;
}

krsort ($arr3);

$arr4=array();
foreach ($arr3 as $arr) {
  array_push ($arr4, $arr);
}
$jmlarr = count ($arr4);
for ($a=0; $a<$jmlarr; $a++) {
  if ($arr4[$a]!= "") {
    $nilai = explode(":", $arr4[$a]);
    $jmlkoma=substr_count($nilai[3], ",");
    if ($jmlkoma>3 && $nilai[0]>5) {
      if ($nilai[2]=='4') {
        if ($nilai[0]>6 && $jmlkoma=='5') $nilai[3]= $nilai[3].",+";
      } else $nilai[3]= $nilai[3].",+";
      $arr4[$a] = $nilai[0].":".$nilai[1].":".$nilai[2].":".$nilai[3];
    }
  }
}


	$roomcount = count ($arr4);
	$limit = 10;
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;								//halaman awal
	
	if ($page == 0) $page = 1;					//jika variabel kosong maka defaultnya halaman pertama.
	$prev = $page - 1;		//halaman sebelumnya
	$next = $page + 1;		//halaman berikutnya
	$lastpage = ceil($roomcount/$limit);		
	$adjacents = 3;
	$targetpage = "index.php";
	$lpm1 = $lastpage - 1;						
	$pagination = "";
// ==========
	if($lastpage > 1)	{	
		$pagination .= "<div class=\"pagination\">";
		//Link halaman sebelumnya
		if ($page > 1) 
			$pagination.= "<a class=\"pagination_previous\" href=\"$targetpage?page=$prev\">&#171; Previous</a>";
		else
			$pagination.= "&nbsp;"; //"<span class=\"disabled\">&#171; Previous</span>";	
 
		//halaman
		if ($lastpage < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
				else
					$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
 
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
			}
 
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
				$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
			}
 
			else
			{
				$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page=$counter\">$counter</a>";					
				}
			}
		}
 
		//link halaman selanjutnya
		if ($page < $counter - 1) 
			$pagination.= "<a class=\"pagination_next\" href=\"$targetpage?page=$next\">Next &#187;</a>";
		else
			$pagination.= "&nbsp;"; //"<span class=\"disabled\">Next &#187;</span>";
		$pagination.= "<div class=\"clearfloat\"></div></div>\n";		
	}

// view arr2
  $content = "";

if ($arr4) {
	for ($no=$start; $no< $start+$limit; $no++) {
   $nilai = explode(":", $arr4[$no]);
	 if ($arr4[$no]!="" && $nilai[2]!='5') {
	$isNoRoomActive = false;
	 $content .=  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\">";

		if ($nilai[2] == '1') {
			$content .=  "<a href=\"$CONFIG->wwwroot"."pg/videoconference/$nilai[1]\">$nilai[1]</a> video conference room active.<br /> 
			Live users : $nilai[0] ($nilai[3])";
		}
		elseif ($nilai[2] == '2') {
			$content .=  "<a href=\"$CONFIG->wwwroot"."pg/videochat/$nilai[1]\">$nilai[1]</a> video chat room active.<br /> 
			Live users : $nilai[0] ($nilai[3])";
		}
		elseif ($nilai[2] == '3') {
			$content .=  "<a href=\"$CONFIG->wwwroot"."pg/videoconsultation/$nilai[1]\">$nilai[1]</a> video consultation room active.<br /> 
			Live users : $nilai[0] ($nilai[3])";
		}
		elseif ($nilai[2] == '4') {
      // picture
      // get last modified picture
      $lstr_snapshotsTime = datalist_get('lstr_snapshotsTime');
    	$ztime = time();
      $exptime_lstr=$ztime-$lstr_snapshotsTime;

      $alamat = $CONFIG->pluginspath ."livestreaming/snapshots/".$nilai[1].".jpg";
      $lastmodif = date(filemtime($alamat));
      //echo $lastmodif;
      if ($lastmodif > $exptime_lstr) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
        $content .= "<div class=\"vwtemplate_picture\" > <img src=\"$CONFIG->wwwroot"."mod/livestreaming/snapshots/".$nilai[1].".jpg\" height=40px> </div>";
      }

// get ownerroom_username
$sql2 = "SELECT ".$CONFIG->dbprefix."users_entity.username ".
			 "FROM    ( (  ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
			 "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
			 "INNER JOIN ".
          $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
			 "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."users_entity ".$CONFIG->dbprefix."users_entity ".
			 "ON (".$CONFIG->dbprefix."entities.owner_guid = ".$CONFIG->dbprefix."users_entity.guid) ".
			 "WHERE ((".$CONFIG->dbprefix."objects_entity.title = '".$nilai[1]."') AND (".$CONFIG->dbprefix."entity_subtypes.subtype = 'livestreaming'))
 LIMIT 1;";
      $hasil = mysql_query ($sql2);
      $hasil2 = mysql_fetch_array ($hasil);
      // get username
      $ElggUser=get_loggedin_user();
      if (isset ($ElggUser)) $username=$ElggUser->get("username");
      if ($hasil2[0] == $username)
        $content .=  "<a href=\"$CONFIG->wwwroot"."pg/livestreaming/$nilai[1]?live=1\">$nilai[1]</a> live channel active.<br />";
        else $content .=  $nilai[1]." live channel active.<a href=\"$CONFIG->wwwroot"."pg/livestreaming/$nilai[1]?live=2\"> [watch and interact]</a> <a href=\"$CONFIG->wwwroot"."pg/livestreaming/$nilai[1]?live=3\">[just video]</a><br />";
        $content .=  "Live users : $nilai[0] ($nilai[3])";
      }

	$content .=  "</div> </div> </div>";
}}}
if ($isNoRoomActive) $content =  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\"> &nbsp No room active. </div> </div> </div>";


  // onlinescreenshot
  if (is_plugin_enabled (onlinescreenshot)){
	$vwtitle2 = elgg_view_title(elgg_echo('vwtemplate:title2'));
  // get_data from datalist to get last modified picture
  $vchat_snapshotsTime = datalist_get('vchat_snapshotsTime');
  $lstr_snapshotsTime = datalist_get('lstr_snapshotsTime');
  
  $sqlliveusercount = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.guid, ".
			 $CONFIG->dbprefix."objects_entity.title ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 "LEFT(".$CONFIG->dbprefix."objects_entity.description,3) IN
               ('2:1', '4:1', '5:1') ORDER BY guid DESC;";

	$ztime = time();
	$exptime=$ztime-30;
  $exptime_vchat=$exptime-($vchat_snapshotsTime/1000);
  $exptime_lstr=$exptime-($lstr_snapshotsTime/1000);
  $arr11 = array ();
  $isNoScreenShot = true;
  $name = "";	  //nama time untuk vchat screenshot terbaru
	if ($rows = get_data($sqlliveusercount)) {
		foreach($rows as $row) {
			$descriptionx = $row->description; 
			$guid = $row->guid;
			$title = $row->title;

			$nilai = explode(":", $descriptionx);
			$newdescription = "";
			if ($nilai[3] < $exptime) {	// if last access time < exptime
				for ($i = 0; $i <= 2; $i++) {
					if ($i == 1) 
						$newdescription .= "0:"; // set status as 0 ( logout )
					else
						$newdescription .= $nilai[$i].":";
				}
				$newdescription .= $nilai[3];
				$result = update_data("UPDATE {$CONFIG->dbprefix}objects_entity 
				set description='$newdescription' 
				where guid=$guid ;");
			} elseif ($nilai[0]==2) {
					$folder = $CONFIG->pluginspath ."videochat/uploads/".$title;
      		$handle = opendir($folder); 
		      $nama = "";
		      while(false !== ($file = readdir($handle))){
		      $file2 = str_replace ("$nilai[2]",".",$file);
		      $file3 = str_replace ("jpg","",$file2);
		      $fileAndExt = explode('.', $file3);
          if ($fileAndExt[2] > $nama) $nama = $fileAndExt[2];
          }
          if (($nama > $exptime_vchat )) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
            $filegambar = $CONFIG->pluginspath ."videochat/uploads/".$title."/".$nilai[2].".".$nama.".jpg";
            if (file_exists($filegambar)) {
             $isNoScreenShot = false;
             array_push ($arr11, "2:".$nilai[2].":".$title.":".$nama); // roomtype:liveuser:roomname:waktugambar
          }}
			} elseif ($nilai[0]==4) {
        $alamat = $CONFIG->pluginspath ."livestreaming/snapshots/".$title.".jpg";
        $lastmodif = date(filemtime($alamat));
        //echo $lastmodif;
        if ($lastmodif > $exptime_lstr) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
          $isNoScreenShot = false;
            array_push ($arr11, "4:".$nilai[2].":".$title); // roomtype:liveuser:roomname
        }
      }
		}
	}


$page2 = (int)get_input('page2', 1);

	$roomcount2 = count ($arr11);
	$limit2 = 10;
	if($page2) 
		$start2 = ($page2 - 1) * $limit2; 			
	else
		$start2 = 0;								//halaman awal
	
	if ($page2 == 0) $page2 = 1;					//jika variabel kosong maka defaultnya halaman pertama.
	$prev2 = $page2 - 1;		//halaman sebelumnya
	$next2 = $page2 + 1;		//halaman berikutnya
	$lastpage2 = ceil($roomcount2/$limit2);		
	$adjacents = 3;
	$targetpage = "index.php";
	$lpm12 = $lastpage2 - 1;						
	$pagination2 = "";
// ==========
	if($lastpage2 > 1)	{	
		$pagination2 .= "<div class=\"pagination\">";
		//Link halaman sebelumnya
		if ($page2 > 1) 
			$pagination2 .= "<a class=\"pagination_previous\" href=\"$targetpage?page2=$prev2\">&#171; Previous</a>";
		else
			$pagination2 .= "&nbsp;"; //"<span class=\"disabled\">&#171; Previous</span>";	
 
		//halaman
		if ($lastpage2 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage2; $counter++)
			{
				if ($counter == $page2)
					$pagination2.= "<span class=\"pagination_currentpage\">$counter</span>";
				else
					$pagination2.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage2 > 5 + ($adjacents * 2))	//enough pages to hide some
		{
 
			if($page2 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page2)
						$pagination2.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination2.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
				}
				$pagination2.= "...";
				$pagination2.= "<a href=\"$targetpage?page2=$lpm12\">$lpm12</a>";
				$pagination2.= "<a href=\"$targetpage?page2=$lastpage2\">$lastpage2</a>";		
			}
 
			elseif($lastpage2 - ($adjacents * 2) > $page2 && $page2 > ($adjacents * 2))
				{
				$pagination2.= "<a href=\"$targetpage?page2=1\">1</a>";
				$pagination2.= "<a href=\"$targetpage?page2=2\">2</a>";
				$pagination2.= "...";
				for ($counter = $page2 - $adjacents; $counter <= $page2 + $adjacents; $counter++)
				{
					if ($counter == $page2)
						$pagination2.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination2.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
				}
				$pagination2.= "...";
				$pagination2.= "<a href=\"$targetpage?page2=$lpm12\">$lpm12</a>";
				$pagination2.= "<a href=\"$targetpage?page2=$lastpage2\">$lastpage2</a>";		
			}
 
			else
			{
				$pagination2.= "<a href=\"$targetpage?page2=1\">1</a>";
				$pagination2.= "<a href=\"$targetpage?page2=2\">2</a>";
				$pagination2.= "...";
				for ($counter = $lastpage2 - (2 + ($adjacents * 2)); $counter <= $lastpage2; $counter++)
				{
					if ($counter == $page2)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
				}
			}
		}
 
		//link halaman selanjutnya
		if ($page2 < $counter - 1) 
			$pagination2.= "<a class=\"pagination_next\" href=\"$targetpage?page2=$next2\">Next &#187;</a>";
		else
			$pagination2.= "&nbsp;"; //"<span class=\"disabled\">Next &#187;</span>";
		$pagination2.= "<div class=\"clearfloat\"></div></div>\n";		
	}

// view arr1
  $content2 = "";
if ($arr11) {
	if ($start2+$limit2 > $roomcount2) $bts2 = $roomcount2; else $bts2 = $start2+$limit2;
	for ($no=$start2; $no< $bts2; $no++) {
    $nilai = explode(":", $arr11[$no]);
	 $content2 .=  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\">
    <div class=\"vwtemplate_picture\">";
    
    if ($nilai[0]==2)
      $content2 .= "<img src=".$CONFIG->wwwroot."mod/videochat/uploads/".$nilai[2]."/".$nilai[1].".".$nilai[3].".jpg height=40px>";
      else $content2 .= "<img src=".$CONFIG->wwwroot."mod/livestreaming/snapshots/".$nilai[2].".jpg height=40px>";

	 $content2 .=  "</div>";

		if ($nilai[0]==2) 
			$content2 .= $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'pg/videochat/'.$nilai[2].">".$nilai[2]."</a> video chat room.";
		  elseif ($nilai[0]==4) {

// get username
$ElggUser=get_loggedin_user();
if (isset ($ElggUser)) {
$username=$ElggUser->get("username");
}
// get livestreaming room owner_username
$sql2 = "SELECT ".$CONFIG->dbprefix."users_entity.username ".
			 "FROM    ( (  ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
			 "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
			 "INNER JOIN ".
          $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
			 "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."users_entity ".$CONFIG->dbprefix."users_entity ".
			 "ON (".$CONFIG->dbprefix."entities.owner_guid = ".$CONFIG->dbprefix."users_entity.guid) ".
			 "WHERE ((".$CONFIG->dbprefix."objects_entity.title = '".$title."') AND (".$CONFIG->dbprefix."entity_subtypes.subtype = 'livestreaming'))
 LIMIT 1;";
      $hasil = mysql_query ($sql2);
      $hasil2 = mysql_fetch_array ($hasil);
      if ($hasil2[0] == $username) 
        $content2 .= $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'pg/livestreaming/'.$nilai[2]."?live=1>".$nilai[2]."</a> live streaming room.<br />"; 
      else $content2 .= $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'pg/livestreaming/'.$nilai[2]."?live=2>".$nilai[2]."</a> live streaming room.<br />";
    }
$content2 .= "</div> </div> </div>";

}}
if ($isNoScreenShot) $content2 =  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\"> &nbsp No screenshot user active. </div> </div> </div>";
  }

	global $autofeed;
	$autofeed = FALSE;
	if (isloggedin()) {
		$content = elgg_view_layout('new_index', '', $vwtitle . $pagination.$content.$pagination.$vwtitle2.$pagination2.$content2.$pagination2, $sctitle.$isconnecttw.$isconnectfb."<div id=\"content_area_user_title\"><h2>Open New :</h2></div>".$opennew);
  }
	else
		$content = elgg_view_layout('new_index', '', $vwtitle . $pagination.$content.$pagination.$vwtitle2.$pagination2.$content2.$pagination2, $sctitle.$socialreg1.$socialreg2.$socialconnect1.$socialconnect2.elgg_view("account/forms/login")."<div id=\"content_area_user_title\"><h2>Open New :</h2></div>".$opennew);
	page_draw(null, $content);
	
?>
