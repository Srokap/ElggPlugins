<?php

	$vwtitle2 = elgg_view_title(elgg_echo('vwtemplate:title2'));
  // get_data from datalist to get last modified picture
  $vchat_snapshotsTime = datalist_get('vchat_snapshotsTime');
  $lstr_snapshotsTime = datalist_get('lstr_snapshotsTime');
  
  $sqlliveusercount = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.guid, ".
			 $CONFIG->dbprefix."objects_entity.title ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 "LEFT(".$CONFIG->dbprefix."objects_entity.description,3) IN
               ('2:1', '4:1', '5:1') ORDER BY guid DESC;";

	$ztime = time();
	$exptime=$ztime-30;
  $exptime_vchat=$exptime-($vchat_snapshotsTime/1000);
  $exptime_lstr=$exptime-($lstr_snapshotsTime/1000);
  $arr11 = array ();
  $isNoScreenShot = true;
  $name = "";	  //nama time untuk vchat screenshot terbaru
	if ($rows = get_data($sqlliveusercount)) {
		foreach($rows as $row) {
			$descriptionx = $row->description; 
			$guid = $row->guid;
			$title = $row->title;

			$nilai = explode(":", $descriptionx);
			$newdescription = "";
			if ($nilai[3] < $exptime) {	// if last access time < exptime
				for ($i = 0; $i <= 2; $i++) {
					if ($i == 1) 
						$newdescription .= "0:"; // set status as 0 ( logout )
					else
						$newdescription .= $nilai[$i].":";
				}
				$newdescription .= $nilai[3];
				$result = update_data("UPDATE {$CONFIG->dbprefix}objects_entity 
				set description='$newdescription' 
				where guid=$guid ;");
			} elseif ($nilai[0]==2) {
					$folder = $CONFIG->pluginspath ."videochat/uploads/".$title;
      		$handle = opendir($folder); 
		      $nama = "";
		      while(false !== ($file = readdir($handle))){
		      $file2 = str_replace ("$nilai[2]",".",$file);
		      $file3 = str_replace ("jpg","",$file2);
		      $fileAndExt = explode('.', $file3);
          if ($fileAndExt[2] > $nama) $nama = $fileAndExt[2];
          }
          if (($nama > $exptime_vchat )) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
            $filegambar = $CONFIG->pluginspath ."videochat/uploads/".$title."/".$nilai[2].".".$nama.".jpg";
            if (file_exists($filegambar)) {
             $isNoScreenShot = false;
             array_push ($arr11, "2:".$nilai[2].":".$title.":".$nama); // roomtype:liveuser:roomname:waktugambar
          }}
			} elseif ($nilai[0]==4) {
        $alamat = $CONFIG->pluginspath ."livestreaming/snapshots/".$title.".jpg";
        $lastmodif = date(filemtime($alamat));
        //echo $lastmodif;
        if ($lastmodif > $exptime_lstr) { // waktu pembuatan gambar yang ada > waktu minimal snapshot
          $isNoScreenShot = false;
            array_push ($arr11, "4:".$nilai[2].":".$title); // roomtype:liveuser:roomname
        }
      }
		}
	}


$page2 = (int)get_input('page2', 1);

	$roomcount2 = count ($arr11);
	$limit2 = 10;
	if($page2) 
		$start2 = ($page2 - 1) * $limit2; 			
	else
		$start2 = 0;								//halaman awal
	
	if ($page2 == 0) $page2 = 1;					//jika variabel kosong maka defaultnya halaman pertama.
	$prev2 = $page2 - 1;		//halaman sebelumnya
	$next2 = $page2 + 1;		//halaman berikutnya
	$lastpage2 = ceil($roomcount2/$limit2);		
	$adjacents = 3;
	$targetpage = "index.php";
	$lpm12 = $lastpage2 - 1;						
	$pagination2 = "";
// ==========
	if($lastpage2 > 1)	{	
		$pagination2 .= "<div class=\"pagination\">";
		//Link halaman sebelumnya
		if ($page2 > 1) 
			$pagination2 .= "<a class=\"pagination_previous\" href=\"$targetpage?page2=$prev2\">&#171; Previous</a>";
		else
			$pagination2 .= "&nbsp;"; //"<span class=\"disabled\">&#171; Previous</span>";	
 
		//halaman
		if ($lastpage2 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage2; $counter++)
			{
				if ($counter == $page2)
					$pagination2.= "<span class=\"pagination_currentpage\">$counter</span>";
				else
					$pagination2.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage2 > 5 + ($adjacents * 2))	//enough pages to hide some
		{
 
			if($page2 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page2)
						$pagination2.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination2.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
				}
				$pagination2.= "...";
				$pagination2.= "<a href=\"$targetpage?page2=$lpm12\">$lpm12</a>";
				$pagination2.= "<a href=\"$targetpage?page2=$lastpage2\">$lastpage2</a>";		
			}
 
			elseif($lastpage2 - ($adjacents * 2) > $page2 && $page2 > ($adjacents * 2))
				{
				$pagination2.= "<a href=\"$targetpage?page2=1\">1</a>";
				$pagination2.= "<a href=\"$targetpage?page2=2\">2</a>";
				$pagination2.= "...";
				for ($counter = $page2 - $adjacents; $counter <= $page2 + $adjacents; $counter++)
				{
					if ($counter == $page2)
						$pagination2.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination2.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
				}
				$pagination2.= "...";
				$pagination2.= "<a href=\"$targetpage?page2=$lpm12\">$lpm12</a>";
				$pagination2.= "<a href=\"$targetpage?page2=$lastpage2\">$lastpage2</a>";		
			}
 
			else
			{
				$pagination2.= "<a href=\"$targetpage?page2=1\">1</a>";
				$pagination2.= "<a href=\"$targetpage?page2=2\">2</a>";
				$pagination2.= "...";
				for ($counter = $lastpage2 - (2 + ($adjacents * 2)); $counter <= $lastpage2; $counter++)
				{
					if ($counter == $page2)
						$pagination.= "<span class=\"pagination_currentpage\">$counter</span>";
					else
						$pagination.= "<a class=\"pagination_number\" href=\"$targetpage?page2=$counter\">$counter</a>";					
				}
			}
		}
 
		//link halaman selanjutnya
		if ($page2 < $counter - 1) 
			$pagination2.= "<a class=\"pagination_next\" href=\"$targetpage?page2=$next2\">Next &#187;</a>";
		else
			$pagination2.= "&nbsp;"; //"<span class=\"disabled\">Next &#187;</span>";
		$pagination2.= "<div class=\"clearfloat\"></div></div>\n";		
	}

// view arr1
  $content2 = "";
if ($arr11) {
	if ($start2+$limit2 > $roomcount2) $bts2 = $roomcount2; else $bts2 = $start2+$limit2;
	for ($no=$start2; $no< $bts2; $no++) {
    $nilai = explode(":", $arr11[$no]);
	 $content2 .=  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\">
    <div class=\"vwtemplate_picture\">";
    
    if ($nilai[0]==2)
      $content2 .= "<img src=".$CONFIG->wwwroot."mod/videochat/uploads/".$nilai[2]."/".$nilai[1].".".$nilai[3].".jpg height=40px>";
      else $content2 .= "<img src=".$CONFIG->wwwroot."mod/livestreaming/snapshots/".$nilai[2].".jpg height=40px>";

	 $content2 .=  "</div>";

		if ($nilai[0]==2) 
			$content2 .= $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'videochat/'.$nilai[2].">".$nilai[2]."</a> video chat room.";
		  elseif ($nilai[0]==4) {

// get username
$ElggUser=get_loggedin_user();
if (isset ($ElggUser)) {
$username=$ElggUser->get("username");
}
// get livestreaming room owner_username
$sql2 = "SELECT ".$CONFIG->dbprefix."users_entity.username ".
			 "FROM    ( (  ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
			 "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
			 "INNER JOIN ".
          $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
			 "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."users_entity ".$CONFIG->dbprefix."users_entity ".
			 "ON (".$CONFIG->dbprefix."entities.owner_guid = ".$CONFIG->dbprefix."users_entity.guid) ".
			 "WHERE ((".$CONFIG->dbprefix."objects_entity.title = '".$title."') AND (".$CONFIG->dbprefix."entity_subtypes.subtype = 'livestreaming'))
 LIMIT 1;";
      $hasil = mysql_query ($sql2);
      $hasil2 = mysql_fetch_array ($hasil);
      if ($hasil2[0] == $username) 
        $content2 .= $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'livestreaming/'.$nilai[2]."?live=1>".$nilai[2]."</a> live streaming room.<br />"; 
      else $content2 .= $nilai[1]." active in :<a href=".$CONFIG->wwwroot.'livestreaming/'.$nilai[2]."?live=2>".$nilai[2]."</a> live streaming room.<br />";
    }
$content2 .= "</div> </div> </div>";

}}
if ($isNoScreenShot) $content2 =  "<div class=\"vwtemplate1\"> <div class=\"vwtemplate2\">
		<div class=\"room_body\"> &nbsp; No screenshot user active. </div> </div> </div>";

?>
