<?php

/**
 * Elgg vwtemplate view page
 *
 * @package Elggvwtemplate
 */
 
 global $CONFIG;
 
	$sqlliveusercount = "SELECT ".$CONFIG->dbprefix."objects_entity.description, ".
			 $CONFIG->dbprefix."objects_entity.guid, ".
			 $CONFIG->dbprefix."objects_entity.title ".
			 "FROM ( ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
       "INNER JOIN ".
       $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
       "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
       "INNER JOIN ".
       $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
       "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid) ".
			 "WHERE ".$CONFIG->dbprefix."entity_subtypes.subtype = 'videowhisper' AND ".
			 "LEFT(".$CONFIG->dbprefix."objects_entity.description,3) IN
               ('1:1', '2:1', '3:1', '4:1') ORDER BY title DESC;";

	$ztime = time();
	$exptime=$ztime-30;
  $arr1 = array ();
  $isNoRoomActive = true;
	
	if ($rows = get_data($sqlliveusercount)) {
		foreach($rows as $row) {
			$descriptionx = $row->description; 
			$guid = $row->guid;
			$title = $row->title;

			$nilai = explode(":", $descriptionx);
			$newdescription = "";
			if ($nilai[3] < $exptime) {	// if last access time < exptime
				for ($i = 0; $i <= 2; $i++) {
					if ($i == 1) 
						$newdescription .= "0:"; // set status as 0 ( logout )
					else
						$newdescription .= $nilai[$i].":";
				}
				$newdescription .= $nilai[3];
				$result = update_data("UPDATE {$CONFIG->dbprefix}objects_entity 
				set description='$newdescription' 
				where guid=$guid ;");
			} else {
			  $isNoRoomActive = false;
        array_push ($arr1, $nilai[0].":".$title.":".$nilai[2]); // roomtype:roomname:liveuser
			}
			
		}
		array_push ($arr1, "end:end:end");
	}

// get most active rooms
	$arr2 = array ();
	if ($arr1) {
	   // inisial
	  $isi = explode(":", $arr1[0]);
	  $videotype = $isi[0];
    $judul = $isi[1];
	  $users = "";
	  $count = 0;
		foreach($arr1 as $arr) {
    $nilai = explode(":", $arr);
    if ($nilai[1]==$judul) { // sama dengan judul sebelumnya
      if ($count<5) {
        if ($count==0) $users = $nilai[2]; 
        else $users .= ', '.$nilai[2];
      }
      $count ++;
    } else { // simpan data lama dan perbarui inisial
      array_push ($arr2, $count.":".$judul.":".$videotype.":".$users);
      $videotype = $nilai[0];
      $judul = $nilai[1];
      $users = $nilai[2];
	    $count = 1;
      }
    }
  }


// sort most active
sort ($arr2);


// view arr2
if ($arr2) {
  		foreach($arr2 as $arr) {
    $nilai = explode(":", $arr);

?>
<div class="vwtemplate-singlepage">
	    <!-- the actual shout -->
		<div class="room_body">

<?php  

		if ($nilai[2] == '1') {
			echo "<a href=".$CONFIG->wwwroot.'videoconference/'.$nilai[1].">".$nilai[1]."</a> video conference room active.<br />";
			echo "Live users : ".$nilai[0]." (".$nilai[3].")";
		}
		elseif ($nilai[2] == '2') {
			echo "<a href=".$CONFIG->wwwroot.'videochat/'.$nilai[1].">".$nilai[1]."</a> video chat room active.<br />";
			echo "Live users : ".$nilai[0]." (".$nilai[3].")";
		}
		elseif ($nilai[2] == '3') {
			echo "<a href=".$CONFIG->wwwroot.'videoconsultation/'.$nilai[1].">".$nilai[1]."</a> video consultation room active.<br />";
			echo "Live users : ".$nilai[0]." (".$nilai[3].")";
		}
		elseif ($nilai[2] == '4') {

// get username
$ElggUser=get_loggedin_user();
$username=$ElggUser->get("username");

// get ownerroom_username
$sql2 = "SELECT ".$CONFIG->dbprefix."users_entity.username ".
			 "FROM    ( (  ".$CONFIG->dbprefix."entities ".$CONFIG->dbprefix."entities ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."entity_subtypes ".$CONFIG->dbprefix."entity_subtypes ".
			 "ON (".$CONFIG->dbprefix."entities.subtype = ".$CONFIG->dbprefix."entity_subtypes.id)) ".
			 "INNER JOIN ".
          $CONFIG->dbprefix."objects_entity ".$CONFIG->dbprefix."objects_entity ".
			 "ON (".$CONFIG->dbprefix."objects_entity.guid = ".$CONFIG->dbprefix."entities.guid)) ".
			 "INNER JOIN ".
              $CONFIG->dbprefix."users_entity ".$CONFIG->dbprefix."users_entity ".
			 "ON (".$CONFIG->dbprefix."entities.owner_guid = ".$CONFIG->dbprefix."users_entity.guid) ".
			 "WHERE ((".$CONFIG->dbprefix."objects_entity.title = '".$nilai[1]."') AND (".$CONFIG->dbprefix."entity_subtypes.subtype = 'livestreaming'))
 LIMIT 1;";
      $hasil = mysql_query ($sql2);
      $hasil2 = mysql_fetch_array ($hasil);
      if ($hasil2[0] == $username)
			echo "<a href=".$CONFIG->wwwroot.'livestreaming/'.$nilai[1]."?live=1>".$nilai[1]."</a> live streaming room active.<br />";
      else echo "<a href=".$CONFIG->wwwroot.'livestreaming/'.$nilai[1]."?live=2>".$nilai[1]."</a> live watch room, and <a href=".$CONFIG->wwwroot.'livestreaming/'.$nilai[1]."?live=3>".$nilai[1]."</a> live video room actives.<br />";
			echo "Live users : ".$nilai[0]." (".$nilai[3].")";
    }

		?>
		</div>
</div>
<?php
}}
if ($isNoRoomActive) echo "&nbsp No room active.";
?>
