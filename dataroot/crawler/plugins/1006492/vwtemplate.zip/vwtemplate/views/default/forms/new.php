<?php

	$generated =  base_convert((time()-1224000000).rand(0,15),10,36);
	$videos_actived = array ();
  $ver=explode('.', get_version(true));	
  if ($ver[1]>7) {
  	if (elgg_is_active_plugin (videoconference,0)) array_push ($videos_actived, videoconference);
  	if (elgg_is_active_plugin (videochat,0)) array_push ($videos_actived, videochat);
  	if (elgg_is_active_plugin (videoconsultation,0)) array_push ($videos_actived, videoconsultation);
  	if (elgg_is_active_plugin (livestreaming,0)) array_push ($videos_actived, livestreaming);
  } 
  else 
  {
  	if (is_plugin_enabled (videoconference)) array_push ($videos_actived, videoconference);
  	if (is_plugin_enabled (videochat)) array_push ($videos_actived, videochat);
  	if (is_plugin_enabled (videoconsultation)) array_push ($videos_actived, videoconsultation);
  	if (is_plugin_enabled (livestreaming)) array_push ($videos_actived, livestreaming);
	}
  $video = array ('0' => '');
	foreach ($videos_actived as $a => $b) {
 		switch ($b) {
        case 'videoconference':
          $arr = array ('videoconference' => 'Video conference');
          $video = array_merge ($video, $arr);
          break;
        case 'videochat':
          $arr = array ('videochat' => 'Video chat');
          $video = array_merge ($video, $arr);
          break;
        case 'videoconsultation':
          $arr = array ('videoconsultation' => 'Video consultation');
          $video = array_merge ($video, $arr);
          break;
        case 'livestreaming':
          $arr = array ('livestreaming' => 'Live streaming');
          $video = array_merge ($video, $arr);
          break;
        default :
          $arr = array ('videochat' => 'Video chat');
          $video = array_merge ($video, $arr);
          break;          
      }
	}

?>

<div>
	<label><?php echo elgg_echo('vwtemplate:roomtype'); ?></label> <br />
	<?php $params = array(
	'name' => 'room_type',
	'class' => 'elgg-input-dropdown mdm',
	'options_values' => $video,
//	'options' => $videos_actived,
  );
  echo elgg_view('input/dropdown', $params);
	?>
</div>

<div>
	<label><?php echo elgg_echo('vwtemplate:roomname'); ?></label>
	<?php $params = array(
	'name' => 'zroomname',
	'id' => 'zroomname',
	'class' => 'elgg-input-text mdm',
	'value' => $generated,
	'onclick' => "if (this.value=='$generated') { this.value='' }",
  );
  echo elgg_view('input/text', $params);
	?>
</div>

<?php
echo elgg_view('input/submit', array('value' => elgg_echo('vwtemplate:create')));
