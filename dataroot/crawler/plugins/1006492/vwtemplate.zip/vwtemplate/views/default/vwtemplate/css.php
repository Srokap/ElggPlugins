<?php
 
    /**
	 * Elgg vwtemplate CSS
	 * 
	 * @package Elggvwtemplate
	 */
     
?>

#layout_canvas, #one_column
{
width: 100%;
}
.vwtemplate1 {
margin:0 10px 0 10px; -webkit-border-radius: 8px; -moz-border-radius: 8px; background: white; margin-bottom:5px;
}

.vwtemplate2 {
margin-bottom:10px;	-webkit-border-radius: 8px;	-moz-border-radius: 8px; border-bottom:1px solid #aaaaaa; border-right:1px solid #aaaaaa;	font-size:90%; color:#666666; padding:0;
}

#vwsocialconnect {
    -moz-border-radius: 8px 8px 8px 8px;
    background: none repeat scroll 0 0 #DEDEDE;
    margin: 0 0 10px;
    padding: 0 17px;
    text-align: left;
}

.vwtemplate-singlepage {
	margin:0 10px 0 10px; 	
	-webkit-border-radius: 8px;	
	-moz-border-radius: 8px; 
	margin-bottom:5px;
}

.vwtemplate-singlepage .room_body {
	background: white;	
	-webkit-border-radius: 8px;	
	-moz-border-radius: 8px;
}

.vwtemplate_picture {
	float:left;    
	margin:0 8px 4px 2px;
}

#open-new p.opennew {
	margin:0;
}
#open-new {
	margin:0 0 10px 0;
	padding:0 0 10px 0;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	text-align:left;
}
#open-new form {
	margin:0 10px 0 10px;
	padding:0 10px 4px 10px;
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
}

#open-new label {
	font-size: 1.2em;
	color:gray;
}
#open-new p {
	margin:0;
}
#open-new input[type="text"] {
	margin:0 0 10px 0;
}
#open-new h2 {
	color:#0054A7;
	font-size:1.35em;
	line-height:1.2em;
	margin:0pt 0pt 5px;
}
