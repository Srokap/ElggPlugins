<?php

    /**
	 * Elgg vwtemplate edit page
	 *
	 * @package Elggvwtemplate
	 */

?>
