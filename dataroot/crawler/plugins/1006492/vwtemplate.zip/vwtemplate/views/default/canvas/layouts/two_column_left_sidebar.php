<?php
/**
* Deprecated layout from 1.0-1.7
*
* Use one_sidebar instead
*/

$ver=explode('.', get_version(true));			
if ($ver[1]>7)
{		
	if (!isset($vars['content'])) {
		$vars['content'] = $vars['area2'];
	}
	if (!isset($vars['content'])) {
		$vars['sidebar'] = $vars['area1'] . $vars['area3'];
	}

	unset($vars['area1']);
	unset($vars['area2']);
	unset($vars['area3']);


	// backward compatability support for plugins that are not using the new approach
	// of routing through 'admin'

	if (elgg_get_context() == 'admin') {
		echo elgg_view('page/layouts/admin', $vars);
		return true;
	}
	echo elgg_view('page/layouts/one_sidebar', $vars);
}
else
{
	?>
	<!-- left sidebar -->
	<div id="two_column_left_sidebar">

	<?php

	echo elgg_view('page_elements/owner_block',array('content' => $vars['area1']));

	?>

	<?php if (isset($vars['area3'])) echo $vars['area3']; ?>

	</div><!-- /two_column_left_sidebar -->

	<!-- main content -->
	<div id="two_column_left_sidebar_maincontent">

	<?php if (isset($vars['area2'])) echo $vars['area2']; ?>

	</div><!-- /two_column_left_sidebar_maincontent -->

	<?
}

