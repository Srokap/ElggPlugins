<?php


global $CONFIG;
$ver=explode('.', get_version(true));	
if ($ver[1]>7) $url = elgg_get_site_url() . 'action/vwtemplate/create';
//return $url = $CONFIG->url . 'action/create'; 
else $url = $CONFIG->url . 'action/create'; 
	
$title = elgg_echo('vwtemplate:createroom');
$body = elgg_view_form('new', array('action' => $url));

echo elgg_view_module('popup', $title, $body);

?>
