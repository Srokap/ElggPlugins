<?php

/**
 * Chinese Elgg Community 
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to opensource@cosmocommerce.com so we can send you a copy immediately.
 *
 * @category	CosmoCommerce
 * @package 	CosmoCommerce_Elgg_Language
 * @copyright	Copyright (c) 2009 Elgg.Org.cn(http://www.elgg.org.cn)	CosmoCommerce,LLC. (http://www.cosmocommerce.com)
 * @version: 0.4
 * @contact :
 * Author: CosmoMao airforce.e@gmail.com
 * T: +86-021-66346672
 * L: Shanghai,China
 * M:sales@cosmocommerce.com
 * GIT:http://github.com/cosmocommerce/Elgg-Community-Chinese-Lanugage/
 */
$chinese = array( 
	 'groups'  =>  "用户组" , 
	 'groups:owned'  =>  "您建立的群组" , 
	 'groups:yours'  =>  "您加入的群组" , 
	 'groups:user'  =>  "%s 的群组" , 
	 'groups:all'  =>  "所有网站群组" , 
	 'groups:new'  =>  "创建群组" , 
	 'groups:edit'  =>  "编辑群组" , 
	 'groups:delete'  =>  "删除小组" , 
	 'groups:membershiprequests'  =>  "管理加入申请" , 
	 'groups:invitations' => '小组邀请',	 
	 
	 'groups:icon'  =>  "小组图标" , 
	 'groups:name'  =>  "小组名称" , 
	 'groups:username'  =>  "小组简称 (在URL中显示,只能输入英文字母)" , 
	 'groups:description'  =>  "详细描述" , 
	 'groups:briefdescription'  =>  "简介" , 
	 'groups:interests'  =>  "关键字" , 
	 'groups:website'  =>  "网站" , 
	 'groups:members'  =>  "小组成员" , 
	 'groups:membership'  =>  "群成员权限" , 
	 'groups:access'  =>  "访问权限" , 
	 'groups:owner'  =>  "所有者" , 
	 'groups:widget:num_display'  =>  "显示群组数目" , 
	 'groups:widget:membership'  =>  "小组成员" , 
	 'groups:widgets:description'  =>  "显示您所加入的群组" , 
	 'groups:noaccess'  =>  "无法访问小组" , 
	 'groups:cantedit'  =>  "无法编辑小组" , 
	 'groups:saved'  =>  "群组已保存" , 
	 'groups:featured'  =>  "特定群组" , 
	 'groups:makeunfeatured'  =>  "取消推荐" , 
	 'groups:makefeatured'  =>  "添加推荐" , 
	 'groups:featuredon'  =>  "您推荐了该群组" , 
	 'groups:unfeature'  =>  "您已经将该小组从推荐列表移除了" , 
	 'groups:joinrequest'  =>  "请求加入" , 
	 'groups:join'  =>  "加入该小组" , 
	 'groups:leave'  =>  "离开小组" , 
	 'groups:invite'  =>  "邀请好友" , 
	 'groups:inviteto'  =>  "邀请好友到 '%s'" , 
	 'groups:nofriends'  =>  "您的好友都加入这个小组了" , 
	 'groups:viagroups'  =>  "通过群组" , 
	 'groups:group'  =>  "群组" , 
	 'groups:search:tags' => "标签",
	 'groups:notfound'  =>  "未找到该小组" , 
	 'groups:notfound:details'  =>  "请求的小组不存在或者无权访问" , 
	 
	 'groups:requests:none'  =>  "目前没有成员申请" , 
	 
	 'groups:invitations:none' => '目前还没有邀请.',
	 
	 'item:object:groupforumtopic'  =>  "论坛主题" , 
	 
	 'groupforumtopic:new'  =>  "发帖讨论" , 
	 
	 'groups:count'  =>  "小组已创建" , 
	 'groups:open'  =>  "开放小组" , 
	 'groups:closed'  =>  "封闭小组" , 
	 'groups:member'  =>  "成员" , 
	 'groups:searchtag'  =>  "通过关键字搜索小组" , 
	 
	 'groups:access:private'  =>  "封闭 - 用户必须收到邀请" , 
	 'groups:access:public'  =>  "开放 - 任何用户都可以加入" , 
	 'groups:closedgroup'  =>  "本小组是封闭性质. 如需要申请加入,请点击\"申请加入\" 菜单" , 
	 'groups:visibility'  =>  "谁可以访问本群?" , 
	 
	 'groups:enablepages'  =>  "开启小组页面" , 
	 'groups:enableforum'  =>  "开启小组讨论" , 
	 'groups:enablefiles'  =>  "开启小组文件" , 
	 'groups:yes'  =>  "是" , 
	 'groups:no'  =>  "否" , 
	 
	 'group:created'  =>  "创建了 %s  拥有贴子 %d 篇" , 
	 'groups:lastupdated'  =>  "最后更新 %s  由 %s  " , 
	 'groups:pages'  =>  "小组页面" , 
	 'groups:files'  =>  "小组文件" , 
	 
	 'group:replies'  =>  "回复" , 
	 'groups:forum'  =>  "小组论坛" , 
	 'groups:addtopic'  =>  "添加主题" , 
	 'groups:forumlatest'  =>  "最新主题" , 
	 'groups:latestdiscussion'  =>  "最新话题" , 
	 'groups:newest'  =>  "最新" , 
	 'groups:popular'  =>  "热门" , 
	 'groupspost:success'  =>  "您的评论已经发布" , 
	 'groups:alldiscussion'  =>  "最新话题" , 
	 'groups:edittopic'  =>  "编辑话题" , 
	 'groups:topicmessage'  =>  "话题消息" , 
	 'groups:topicstatus'  =>  "话题状态" , 
	 'groups:reply'  =>  "发布评论" , 
	 
	 'groups:topic'  =>  "主题" , 
	 
	 'groups:posts'  =>  "发布" , 
	 'groups:lastperson'  =>  "最后回复者" , 
	 
	 'groups:when'  =>  "时间" , 
	 'grouptopic:notcreated'  =>  "没有主题创建。" , 
	 
	 'groups:topicopen'  =>  "开放" , 
	 'groups:topicclosed'  =>  "关闭" , 
	 'groups:topicresolved'  =>  "已解决" , 
	 'grouptopic:created'  =>  "您的话题已经创建了。" , 
	 'groupstopic:deleted'  =>  "这个话题已经删除了。" , 
	 'groups:topicsticky'  =>  "粘贴" , 
	 'groups:topicisclosed'  =>  "这个话题已经关闭。" , 
	 'groups:topiccloseddesc'  =>  "话题已经关闭并且不再接受新的评论了。" , 
	 'grouptopic:error'  =>  "您的小组话题无法创建.请再试一次或者联系系统管理员" , 
	 'groups:forumpost:edited'  =>  "您已经成功编辑了论坛帖子" , 
	 'groups:forumpost:error'  =>  "论坛帖子编辑遇到问题" , 
	 'groups:privategroup'  =>  "这个小组是非公开的，需要申请才能加入。" , 
	 'groups:notitle'  =>  "群组必须有标题" , 
	 'groups:cantjoin'  =>  "无法加入该群组" , 
	 'groups:cantleave'  =>  "无法退出该群组" , 
	 'groups:addedtogroup'  =>  "成功添加用户到群组里" , 
	 'groups:joinrequestnotmade'  =>  "无法申请加入" , 
	 'groups:joinrequestmade'  =>  "已发出请求" , 
	 'groups:joined'  =>  "成功加入该群组！" , 
	 'groups:left'  =>  "成功退出该群组" , 
	 'groups:notowner'  =>  "抱歉您不是该群组的所有者。" , 
	 'groups:notmember' => '抱歉您不是该群组的成员。',
	 'groups:alreadymember'  =>  "您已经是该小组的成员!" , 
	 'groups:userinvited'  =>  "用户已经被邀请。" , 
	 'groups:usernotinvited'  =>  "用户还未被邀请" , 
	 'groups:useralreadyinvited'  =>  "用户已经收到邀请" , 
	 'groups:updated'  =>  "最后评论" , 
	 'groups:invite:subject'  =>  "%s 您已经被邀请加入小组 %s!" , 
	 'groups:started'  =>  "始于" , 
	 'groups:joinrequest:remove:check'  =>  "确定要删除本次申请吗?" , 
	 'groups:invite:remove:check' => '确定要删除这次邀请吗?',
	 'groups:invite:body'  =>  " %s 您好,

您已经被邀请加入 '%s' 小组, 点击下方确认:

%s" , 
	 'groups:welcome:subject'  =>  "欢迎来到 %s 小组!" , 
	 'groups:welcome:body'  =>  " %s 您好!
		
您已经是 '%s' 小组的成员! 点击下方开始发帖!

%s" , 
	 'groups:request:subject'  =>  "%s 请求加入小组 %s" , 
	 'groups:request:body'  =>  " %s 您好,

%s 请求加入 '%s' 小组, 点击下方查看他们的信息:

%s

或者您可以点击下方确认请求:

%s" , 
	 'groups:river:member'  =>  "现在加入了" , 
	 'groupforum:river:updated'  =>  "%s  更新了" , 
	 'groupforum:river:update'  =>  "本话题" , 
	 'groupforum:river:created'  =>  "%s  创建了" , 
	 'groupforum:river:create'  =>  "新话题" , 
	 'groupforum:river:posted'  =>  "%s  发表了新评论" , 
	 'groupforum:river:annotate:create'  =>  "关于本话题" , 
	 'groupforum:river:postedtopic'  =>  "%s  发表了新的帖子" , 
	 'groups:river:member' => '%s 目前加入了',
	 'groups:river:togroup' => '对于该小组',

	 'groups:nowidgets'  =>  "该小组没有被构件定义过。" , 
	 'groups:widgets:members:title'  =>  "小组成员" , 
	 'groups:widgets:members:description'  =>  "列出小组的成员。" , 
	 'groups:widgets:members:label:displaynum'  =>  "列出小组的成员。" , 
	 'groups:widgets:members:label:pleaseedit'  =>  "请安装该构件。" , 
	 'groups:widgets:entities:title'  =>  "群组对象" , 
	 'groups:widgets:entities:description'  =>  "列出该小组保存的对象。" , 
	 'groups:widgets:entities:label:displaynum'  =>  "列出小组的成员。" , 
	 'groups:widgets:entities:label:pleaseedit'  =>  "请安装该构件。" , 
	 'groups:forumtopic:edited'  =>  "论坛帖子成功编辑" , 
	 'groups:allowhiddengroups'  =>  "您想允许私人小组(不可见)吗?" , 
	 'group:deleted'  =>  "该小组和小组内容都已删除" , 
	 'group:notdeleted'  =>  "该小组无法被删除" , 
	 'grouppost:deleted'  =>  "小组帖子已被删除" , 
	 'grouppost:notdeleted'  =>  "小组帖子无法删除" , 
	 'groupstopic:notdeleted'  =>  "话题已删除" , 
	 'grouptopic:blank'  =>  "无主题" , 
	 'grouptopic:notfound' => '无法找到主题',
	 'grouppost:nopost' => '空帖子',
			
	 'groups:deletewarning'  =>  "您确定要删除本群吗?删除后将无法还原!" , 
	 
	 'groups:invitekilled' => '已经删除邀请.',
	 
	 'groups:joinrequestkilled'  =>  "加入申请已经被删除.",
	 
	 'groups:info' => "Info",
			'groups:rules' => "规则",
			'groups:members' => "成员",
			'groups:river' => "活动",
			'groups:rules:none' => "这个群组暂时没有需要您跟随的规则",
			'groups:rules:add' => "添加/更新群组规则",
			'groups:new:rules:success' => "您的群组规则已经成功保存",
			
			'groups:announcements' => "公告",
			'groups:announcements:posted' => "已发布公告",
			'groups:announce:blank' => "您还没有填写完整!",
			'groups:announce:error' => "您的公告现在无法保存.请重试.",
			'groups:announce:posted' => "新公告已成功发布.",
			'groups:announcements:add' => "添加一个群组公告",
			'groups:post:count' => "帖子",
			'groups:new:status:success' => "用户标题已添加成功.",
			'groups:status:title:form' => "给此用户一个头衔",
			'groups:status:title' => "您有一个新的头衔",
			'groups:status:message' => "您的新头衔 %s 在这个群组里是%s",
			
			// Settings Page Expanded
			'groups:allowannouncements' => "允许群组公告",
			'groups:allowrules' => "允许群组规则",
			'groups:allowhotposts' => "允许热点话题功能",
			'groups:allowstatus' => "允许用户主题",
			'groups:allowpostcount' => "允许计算帖子数量",
			'groups:allowpostcountranks' => "允许帖子计算等级",
			'groups:post:ranks:instructions' => "您可以编辑这些在语言文件夹里和视图浏览/默认/论坛/话题_发布.个人网页在57-66行",
			'groups:allowblockgroups' => "限制非管理员创建新的群组?",
			'groups:postsperpage' => "每页讨论话题上显示多少个帖子?",
			'groups:admin:prof_manager:toolow' => "此插件需要放置在个人资料管理清单后",
			'groups:admin:prof_manager:right' => "跟个人资料管理相比这个插件被放置在正确的位置",
			'groups:admin:group_multiple_admin:toolow' => "此插件需要放置在群组多重管理清单上",
			'groups:admin:group_multiple_admin:right' => "与群组多重管理相比此插件被放置在正确的位置",
			'groups:admin:group_kick:toolow' => "此插件需要放置在群组购买插件清单上",
			'groups:admin:group_kick:right' => "与群组反冲相比此插件被放置在正确的位置",
			'groups:admin:groupriver:already' => "此插件使群组过时.您可以退出或删除它",
			'groups:admin:check' => "确认兼容",
			'groups:admin:forum' => "讨论",
			'groups:admin:groups' => "群组",
			'groups:admin:version:toolow' => "您的模式版本太旧，无法安全使用此插件",
			'groups:admin:version:right' => "您的模式版本可以使用此插件",
			'groups:allowsignatures' => "允许签名",
			
			'groups:postcount:rank' => "排名",
			'groups:rank:newbie' => "新人",
			'groups:rank:junior' => "年少的新人",
			'groups:rank:senior' => "年长的成员",
			'groups:rank:veteran' => "资深的成员",
			'groups:rank:squatter' => "蹲着的人",
			
			'groups:upgrade:success' => "您的群组已成功升级",
			'groups:upgrade:fail' => "目前您的系统里没有群组因此不需要运行升级",
			'groups:upgrade:instructions' => "看起来您已经有运行的群组了而且您已开启热门话题或者计算帖子功能. 您需要运行升级功能以确保所有目前的群组都已设置来处理新的功能. 点击下面的链接来完成吧. 警告:由于这个大型的社区所以这可能会花费一点时间 .",
			'groups:run:upgrade' => "运行插件升级",
			
			'groups:forum:close' => "关闭",
			'groups:forum:open' => "打开",
			'groups:forum:sticky:success' => "话题被卡住了",
			'groups:forum:unsticky:success' => "话题已松开",
			'groups:forum:close:success' => "话题已封闭Topic closed",
			'groups:forum:open:success' => "话题已重新打开",
			'groups:forum:stick:fail' => "无法完成这个请求,请重试.",
			
			'groups:signature:save' => "您在这个群组里的签名已更新",
			'groups:signature:fail' => "您在这个群组的签名现在无法保存，请重试.",
			'groups:signature:create' => "更新您的签名",
			
			'groups:search:result:count' => "您的搜寻已返回 %s 结果",
); 

add_translation('zh', $chinese); 

?>