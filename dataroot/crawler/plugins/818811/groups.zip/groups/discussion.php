<?php
	/**
	 * Elgg groups forum
	 * 
	 * @package ElggGroups
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$group_guid = (int)get_input('group_guid');
	set_page_owner($group_guid);
	if (!(page_owner_entity() instanceof ElggGroup)) {
		forward();
	}
	
	group_gatekeeper();

	$title = elgg_echo('item:object:groupforumtopic');
	$title1 = elgg_view_title($title);
	
	$area2 = "<h2>{$title}</h2><br>";

		
	//get any forum topics
	set_context('search');	
	$forums = elgg_list_entities(array("type" => "object", "subtype" => "group_forum", "limit" => "20", "container_guid" => $group_guid, "order_by" => "time_created asc", "full_view" => false, "pagination" => false));
	
	$area2 .= elgg_view("forum/forums", array('forums' => $forums, 'group_guid' => $group_guid));
	set_context('groups');
	$area3 = elgg_view('learning_tools/area3');

	$body = elgg_view_layout('two_column_right_sidebar',$area1, $area2,$area3);
	
	
	// Finally draw the page
	page_draw($title, $body);



?>