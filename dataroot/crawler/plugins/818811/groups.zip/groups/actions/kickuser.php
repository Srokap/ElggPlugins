<?php

	$user_guid = get_input('user_guid');
	$group_guid = get_input('group_guid');
	$group = get_entity($group_guid);

	// Make sure we have a user and group
	if(!empty($user_guid) && !empty($group_guid)){
	
		// Make sure we can edit the group
		if($group->canEdit()){
		
			// Make sure user is a member of the group
			if(is_group_member($group_guid,$user_guid) !== FALSE){
				
				// Kick the user from the group
				leave_group($group_guid,$user_guid);		
			
			}
	
		}
		
	}
	
$output = "The user was removed from your group";
echo $output;
die();

?>