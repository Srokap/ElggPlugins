<?php

/**
 * Elgg site message: add
 *
 * @package ElggRiverDash
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Curverider Ltd <info@elgg.com>
 * @copyright Curverider Ltd 2008-2010
 * @link http://elgg.org/
 **/

// Get input data
$message = get_input('group_announcement');
$container = get_input('container_guid');

// Make sure the message isn't blank
if (empty($message)) {
	//register_error(elgg_echo("groups:announce:blank"));
	//forward(REFERER);
}

// Initialise a new ElggObject
$announcement = new ElggObject();
// Tell the system it's a site wide message
$announcement->subtype = "group_announcement";
// Set its owner to the current user
$announcement->owner_guid = get_loggedin_userid();
$announcement->container_guid = $container;
// For now, set its access to logged in users
$announcement->access_id = ACCESS_LOGGED_IN; // this is for all logged in users
// Set description appropriately
$announcement->title = '';
$announcement->description = $message;
// Before we can set metadata, we need to save the message
if (!$announcement->save()) {
//	register_error(elgg_echo("groups:announce:error"));
//	forward(REFERER);
}
// Success message
//system_message(elgg_echo("groups:announce:posted"));

// add to river
//add_to_river('river/sitemessage/create', 'create', get_loggedin_userid(), $announcement->guid);

// Forward to the activity page
//forward(REFERER);

$output = $announcement->description;
echo $output;
die();

?>