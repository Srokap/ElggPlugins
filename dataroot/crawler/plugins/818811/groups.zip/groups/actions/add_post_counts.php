<?php

action_gatekeeper();
if(!isloggedin()){
	forward($vars['url']);
}
if(!isadminloggedin()){
	forward($vars['url']);
}
//
//Warning
//This code will go through the entire system and check all group discussion posts and annotate accordingly.
//It will take quite a long time on a large install.
//It should only be run once for installs that had posts made before this plugin was installed.
//
	$groups = elgg_get_entities(array('types' => 'group', 'owner_guid' => 0, 'limit' => 999999));
	if($groups){
		foreach($groups as $group){
			$topics = elgg_get_entities(array('type' => 'object', 'subtype' => 'groupforumtopic', 'owner_guid' => 0, 'container_guid' => $group->guid, 'limit' => 999999));	
			if($topics){
				foreach($topics as $topic){
					$posts = get_annotations($entity_guid = $topic->guid,$entity_type = "object",$entity_subtype = $topic->subtype,$name = "group_topic_post",$value = "",$owner_guid = 0,$limit = "999999",$entity_owner_guid = 0);
						if($posts){
							foreach($posts as $post){
								//Deal with post counts if the setting is on
								if (get_plugin_setting('postcount', 'groups') == 'yes'){
								$owner_guid = $post->owner_guid;
								$post_count = get_annotations($entity_guid = $group->guid,$entity_type = "group",$entity_subtype = "",$name = "post_count",$value = "",$owner_guid = $owner_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
								if($post_count){
									$count = $post_count[0]->value;
									$new_count = $post_count[0]->value +1;
									$id = $post_count[0]->id;
									delete_annotation($id);
									create_annotation($group->guid, 'post_count', $new_count, 'integer', $owner_guid, $access_id=ACCESS_LOGGEDIN);
								}else{
									$new_count = 1;
									create_annotation($group->guid, 'post_count', $new_count, 'integer', $owner_guid, $access_id=ACCESS_LOGGEDIN);
								}
								}//If postcount setting is on
								
								//Deal with hot topics if the setting is on
								if (get_plugin_setting('hotposts', 'groups') == 'yes'){
								$hot_topic = $topic->hot_topic;
								if((!$hot_topic) || ($hot_topic)){
									$post_count = $topic->countAnnotations('group_topic_post');
										if($post_count >= 15){
											elgg_set_ignore_access ($ignore=true);
											$topic->clearMetaData('hot_topic');
											create_metadata($topic->guid,'hot_topic','yes','text',$topic->guid,$access_id = ACCESS_LOGGEDIN,$allow_multiple = false);	
											elgg_set_ignore_access ($ignore=false);
										}else{
											elgg_set_ignore_access ($ignore=true);
											create_metadata($topic->guid,'hot_topic','no','text',$topic->guid,$access_id = ACCESS_LOGGEDIN,$allow_multiple = false);	
											elgg_set_ignore_access ($ignore=false);
									}
								}//If hot topics

							}//If hotposts setting is on
						}//foreach posts
				}//if posts
			}//for each topics
		}//if topics
	}
		set_plugin_setting("post_count_upgrade","done","groups");	
		system_message(elgg_echo('groups:upgrade:success'));
		forward($_SERVER['HTTP_REFERER']);
	}else{
		// no groups so do nothing
		register_error(elgg_echo('groups:upgrade:fail'));
		forward($_SERVER['HTTP_REFERER']);
	}
	
?>