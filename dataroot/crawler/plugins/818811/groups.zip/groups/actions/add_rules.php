<?php

	$group_guid = get_input('group_guid');
	$the_group = get_entity($group_guid);
	$rules = get_input('rules');

	$_SESSION['the_group'] = $group;
	$_SESSION['rules'] = $rules;

	
	if (empty($rules) || empty($group_guid)) {
		//	register_error(elgg_echo("groups:blank"));
		//	forward($_SERVER['HTTP_REFERER']);
	
	} else {
	
	
	$the_group->rules = $rules;
	
	if (!$the_group->save()) {
		//		register_error(elgg_echo("groups:error"));
		//	forward($_SERVER['HTTP_REFERER']);
			}
	
	//system_message(elgg_echo('groups:new:rules:success'));
	
	unset($_SESSION['the_group']); 
	unset($_SESSION['rules']);
	remove_metadata($_SESSION['user']->guid,'rules');
	remove_metadata($_SESSION['user']->guid,'the_group');
	
	//forward($_SERVER['HTTP_REFERER']);
	
	$output = $the_group->rules;
	echo $output;
	die();
	
	}
	
	
	
?>