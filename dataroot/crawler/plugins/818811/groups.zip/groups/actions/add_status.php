<?php

	$group_guid = get_input('group_guid');
	$user_guid = get_input('user_guid');
	$status = get_input('status_text');
	$group = get_entity($group_guid);

	$_SESSION['the_group'] = $group_guid;
	$_SESSION['status_text'] = $status;
	
	if (empty($group_guid) || empty($user_guid)) {
		//	register_error(elgg_echo("groups:status:blank"));
		//	forward($_SERVER['HTTP_REFERER']);
	
	} else {
	
	//Get all statuses
	$have_status = get_annotations($entity_guid = $user_guid,$entity_type = "user",$entity_subtype = "",$name = "group_status",$value = "",$owner_guid = $group_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
	if($have_status){
		$current = $have_status[0]->value;
		$id = $have_status[0]->id;
		delete_annotation($id);
		create_annotation($user_guid, 'group_status', $status, 'text', $group_guid, $access_id=ACCESS_LOGGEDIN);
	}else{
		create_annotation($user_guid, 'group_status', $status, 'text', $group_guid, $access_id=ACCESS_LOGGEDIN);
	}
	$sitename = $vars['config']->sitename;
	$subject = elgg_echo('groups:status:title');
	$new_status = "<strong>\"" . $status . "\"</strong>";
	$message = sprintf(elgg_echo("groups:status:message"),$new_status,$group->name);
	notify_user($user_guid,$group->owner_guid,$subject,$message);
	//system_message(elgg_echo('groups:new:status:success'));
	
	unset($_SESSION['the_group']); 
	unset($_SESSION['status_text']);
	remove_metadata($_SESSION['user']->guid,'status_text');
	remove_metadata($_SESSION['user']->guid,'the_group');
	
	$output = $status;
	echo $status;
	die();
	
	//forward($_SERVER['HTTP_REFERER']);
	
	}
	
	
	
?>