<?php

		$topic_guid = get_input('topic');
		$style = get_input('style');
		$topic = get_entity($topic_guid);
		
		if (groups_can_edit_discussion($topic, page_owner_entity()->owner_guid)) {
		
			if($style == "close"){
				create_metadata($topic_guid,'status','closed','text',$topic_guid,$access_id = ACCESS_DEFAULT,$allow_multiple = false);	
			}else{
				create_metadata($topic_guid,'status','open','text',$topic_guid,$access_id = ACCESS_DEFAULT,$allow_multiple = false);	
			}
		}
		
		 
		$new_topic = get_entity($topic_guid);
		$vars['entity'] = $new_topic;
		
		if($style == "close"){
			echo "<a class='submit_button' id='open_topic' onclick='open_close_topic();'>" . elgg_echo('groups:forum:open') . "</a>";
		}else{
			echo "<a class='submit_button' id='close_topic' onclick='open_close_topic();'>" . elgg_echo('groups:forum:close') . "</a>";
		}
   						
		die();
		
?>