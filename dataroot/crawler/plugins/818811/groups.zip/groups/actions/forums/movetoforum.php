<?php

	$topic_guid = get_input("topic_guid");
	$forum_guid = get_input("forum_guid");
	$old_forum = get_input('old_forum');
	
	$topic = get_entity($topic_guid);

	if($topic->canEdit()){
		$attached = check_entity_relationship($old_forum, "forum_topic", $topic->guid);
		if($attached !== FALSE){
			$remove = remove_entity_relationship($old_forum, "forum_topic", $topic->guid);
			$add_new = add_entity_relationship ($forum_guid, "forum_topic", $topic->guid);
		
		$new_forum = get_entity($forum_guid);
		$groups_forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "container_guid" => $topic->container_guid, "limit" => ""));
		
		echo "<div id='move_forum_box' style='display:none;'>";	
		echo elgg_echo('groups:forum:move:choice');
		echo "<select id='forum_chooser'>";
		foreach($groups_forums as $b_forum){
			if($b_forum->guid == $forum_guid){
			}else{
	   			echo "<option value='{$b_forum->guid}'>{$b_forum->title}</option>";
   			}
   		}
   		echo "</select>&nbsp;";
		echo "<input type='hidden' id='topic_guid' value='{$vars['entity']->guid}' />";
   		echo "<a class='submit_button' onclick='move_to_forum();'>Save</a>";
		echo "</div>"; 	
		
		die();	
		}
	}

?>