<?php

	/**
	 * Elgg Groups: delete topic comment action
	 * 
	 * @package ElggGroups
	 */

	// Ensure we're logged in
		if (!isloggedin()) forward();
		
  
	// Make sure we can get the comment in question
		$post_id = (int) get_input('post');
		$group_guid = (int) get_input('group');
		$topic_guid = (int) get_input('topic');
		$topic = get_entity($topic_guid);
		
		if ($post = get_annotation($post_id)) {
			
			//check that the user can edit as well as admin
			if ($post->canEdit() || ($post->owner_guid == $_SESSION['user']->guid)) {
    			
    			//delete forum comment
				$post->delete();
				
				//Deal with hot topic
				$allow_hotposts = get_plugin_setting ($hotposts, $plugin_name="groups");
				if($allow_hotposts !== "no"){
				$hot_topic = $topic->hot_topic;
				if((!$hot_topic) || ($hot_topic)){
				$post_count = $topic->countAnnotations('group_topic_post');
					$topic_count = $post_count++;
					if($topic_count < 15){
						elgg_set_ignore_access ($ignore=true);
						$topic->clearMetaData('hot_topic');
						create_metadata($topic_guid,'hot_topic','no','text',$topic_guid,$access_id = ACCESS_LOGGED_IN,$allow_multiple = false);	
						elgg_set_ignore_access ($ignore=false);
					}
				}
				}
				//Deal with post count
				 if (get_plugin_setting('postcount', 'groups') == 'yes'){
				$post_count = get_annotations($entity_guid = $group_guid,$entity_type = "group",$entity_subtype = "",$name = "post_count",$value = "",$owner_guid = $post->owner_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
				if($post_count){
					$count = $post_count[0]->value;
					$new_count = $post_count[0]->value -1;
					$id = $post_count[0]->id;
					delete_annotation($id);
					create_annotation($group_guid, 'post_count', $new_count, 'integer', $post->owner_guid, $access_id=ACCESS_LOGGED_IN);
				}
				}
				// remove river entry if it exists
				remove_from_river_by_annotation($post_id);

				//display confirmation message
			//	system_message(elgg_echo("grouppost:deleted"));
			}
			
		} else {
			$url = "";
		//	system_message(elgg_echo("grouppost:notdeleted"));
		}
    $post_counts = get_annotations($entity_guid = $group_guid,$entity_type = "group",$entity_subtype = "",$name = "post_count",$value = "",$owner_guid = $post->owner_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
	if($post_counts){
		$post_count = $post_counts[0]->value;
	}else{
		$post_count = 0;
	}
	$output = $post_count;
	echo $output;
	die();
?>