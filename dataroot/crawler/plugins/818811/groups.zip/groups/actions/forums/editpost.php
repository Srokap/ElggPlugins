<?php

    /**
	 * Elgg groups plugin edit post action.
	 * 
	 * @package ElggGroups
	 */

		
		$group_guid = get_input('group');
	    $group_entity =  get_entity($group_guid);
	    
	//get the required variables
		$post = get_input("post");
		$post_comment = get_input("postComment");
		$annotation = get_annotation($post);
		$commentOwner = $annotation->owner_guid;
		$access_id = $annotation->access_id;
		
		if ($annotation) {
			
			//can edit? Either the comment owner or admin can
			if (groups_can_edit_discussion($annotation, page_owner_entity()->owner_guid)) {
				
				update_annotation($post, "group_topic_post", $post_comment, "",$commentOwner, $access_id);
				
			 //   system_message(elgg_echo("groups:forumpost:edited"));
				   
			} else {
			//	system_message(elgg_echo("groups:forumpost:error"));
			}
			
		} else {
			
			//	system_message(elgg_echo("groups:forumpost:error"));
		}
		
		$new_post = get_annotation($post);
		$output = parse_urls(elgg_view("output/longtext",array("value" => $new_post->value)));
  		echo $output;
  		die();
	
		
?>