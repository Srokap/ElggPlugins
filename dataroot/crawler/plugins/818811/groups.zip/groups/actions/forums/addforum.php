<?php

	if(!isloggedin()){
		forward($vars['url']);
	}
	
	$user = get_loggedin_user();
	
	$group_guid = get_input('group_guid');
	$forum_name = get_input('forum_name');
	$description = get_input('forum_desc');
	$forum_access = get_input('forum_access');
	
	$group = get_entity($group_guid);
	
	if($group->canEdit()){
		
		if(empty($group_guid) || empty($forum_name)){
			
		}else{
			// Save the forum and its contents
			$forum = new ElggObject();
			$forum->subtype = "group_forum";
			$forum->title = $forum_name;
			$forum->description = $description;
			$forum->access = $group->access;
			$forum->owner_guid = $group->owner_guid;
			$forum->container_guid = $group_guid;
			$forum->view_access = $forum_access;
			
			$forum->save();
			
			// Create the relationship between the group and the forum
			add_entity_relationship($group_guid,'group_forum',$forum->guid);
			
			// Output the result for ajax call
			set_context("search");
			$output = elgg_view_entity($forum,false,true,false);
			echo $output;
			die();
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
?>