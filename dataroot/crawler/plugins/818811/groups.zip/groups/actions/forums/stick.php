<?php

		$topic_guid = get_input('topic');
		$style = get_input('style');
		$topic = get_entity($topic_guid);
		
		if (groups_can_edit_discussion($topic, page_owner_entity()->owner_guid)) {
		
			if($style == "stick"){
				create_metadata($topic_guid,'sticky','yes','text',$topic_guid,$access_id = ACCESS_DEFAULT,$allow_multiple = false);	
			}else{
				create_metadata($topic_guid,'sticky','no','text',$topic_guid,$access_id = ACCESS_DEFAULT,$allow_multiple = false);	
			}
		}
		
		 
		$new_topic = get_entity($topic_guid);
		$vars['entity'] = $new_topic;
		
		if($style == "stick"){
			echo " <a class='submit_button' id='unstick_topic' onclick='stick_topic();'>" . elgg_echo('groups:forum:unstick') . "</a>";
		}else{
			echo " <a class='submit_button' id='stick_topic' onclick='stick_topic();'>" . elgg_echo('groups:forum:stick') . "</a>";
		}
		
		die();
		
?>