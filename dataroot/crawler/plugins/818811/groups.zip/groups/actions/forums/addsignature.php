<?php


		if(!isloggedin()){
			forward($_SERVER['HTTP_REFERER']);
		}

		
		$user_id = get_input('user_guid');
		$group_guid = get_input('group_guid');
		$signature = get_input('signature');
		
		if(empty($signature) || empty($group_guid) || empty($user_id)){
			//register_error(elgg_echo('groups:signature:fail'));
			//forward($_SERVER['HTTP_REFERER']);
			
			
		} else {

		$group = get_entity($group_guid);
		$signatures = get_annotations($entity_guid = $group_guid, $entity_type = "", $entity_subtype = "", $name = "sigs", $value = "", $owner_guid = $user_id, $limit = 1);
			if($signatures){
				update_annotation($signatures[0]->id, 'sigs', $signature, 'text', $user_id, ACCESS_LOGGED_IN);
			//	system_message(elgg_echo('groups:signature:save'));
			//	forward($_SERVER['HTTP_REFERER']);
			}else{
				create_annotation($group_guid, 'sigs', $signature, 'text', $user_id, ACCESS_LOGGED_IN);
			//	system_message(elgg_echo('groups:signature:save'));
			//	forward($_SERVER['HTTP_REFERER']);
			}
		$newsignatures = get_annotations($entity_guid = $group_guid, $entity_type = "", $entity_subtype = "", $name = "sigs", $value = "", $owner_guid = $user_id, $limit = 1);
			$output = $newsignatures[0]->value;
			echo $output;
			die();
			
		}

?>