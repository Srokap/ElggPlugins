<?php

	if(!isloggedin()){
		forward($vars['url']);
	}
	
	$user = get_loggedin_user();
	
	$group_guid = get_input('group_guid');
	$forum_guid = get_input('forum_guid');
	$forum_name = get_input('forum_name');
	$description = get_input('forum_desc');
	$forum_access = get_input('forum_access');
	
	
	$group = get_entity($group_guid);
	$forum = get_entity($forum_guid);
	if(($group->canEdit()) && ($forum->canEdit())){
		
		if(empty($group_guid) || empty($forum_name)){
			
		}else{
			// Save the forum and its contents
			$forum->title = $forum_name;
			$forum->description = $description;
			$forum->view_access = $forum_access;
			$forum->save();
						
			// Output the result for ajax call
			set_context("search");
			$output = elgg_view_entity($forum,false,true,false);
			echo $output;
			die();
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
?>