<?php

	if(isadminloggedin()){
	
	$groups = elgg_get_entities(array("types" => "group", "owner_guid" => 0, "limit" => ""));
	
	foreach($groups as $group){
		
		// Get forums & topics for groups
		$forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "container_guid" => $group->guid, "limit" => "1"));
		$topics = elgg_get_entities(array("type" => "object", "subtype" => "groupforumtopic", "container_guid" => $group->guid, "limit" => ""));
		
		if((empty($forums)) || ($forums == FALSE)){
			
			// Add a default forum
			$new_forum = new ElggObject();
			$new_forum->subtype = "group_forum";
			$new_forum->title = "General Discussion";
			$new_forum->description = "A place to discuss general things";
			$new_forum->access = $group->access;
			$new_forum->owner_guid = $group->owner_guid;
			$new_forum->container_guid = $group->guid;
			
			if(!$new_forum->save()){
				register_error(elgg_echo('Some forums couldnt be created'));
				forward($_SERVER['HTTP_REFERER']);
			}
			
			add_entity_relationship($group->guid,'group_forum',$new_forum->guid);
			
			
			// Now move all topics in group to new default forum
			foreach($topics as $topic){
				$rels_out = elgg_get_entities_from_relationship(array("relationship" => "forum_topic", "relationship_guid" => $topic->guid, "inverse_relationship" => TRUE, "type" => "object", "subtype" => "group_forum", "limit" => 1));
				if((empty($rels_out)) || ($rels_out == FALSE)){
					add_entity_relationship ($new_forum->guid, "forum_topic", $topic->guid);
				}
			}
			
		}else{ // If group already has forums
			
			foreach($topics as $topic){
				$rels_out = elgg_get_entities_from_relationship(array("relationship" => "forum_topic", "relationship_guid" => $topic->guid, "inverse_relationship" => TRUE, "type" => "object", "subtype" => "group_forum", "limit" => 1));
				if((empty($rels_out)) || ($rels_out == FALSE)){
					add_entity_relationship ($forums[0]->guid, "forum_topic", $topic->guid);
				}
			}
		
		}
		
		
	} // End for each groups
	
} // End if is admin logged in
?>