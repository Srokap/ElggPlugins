<?php

	/**
	 * Elgg Groups: delete topic action
	 * 
	 * @package ElggGroups
	 */
		
	    $group_entity =  get_entity(get_input('group'));

	// Get input data
		$topic_guid = (int) get_input('topic');
		$group_guid = (int) get_input('group');
		
			
		$topic = get_entity($topic_guid);		
		if (($topic->getSubtype() == "groupforumtopic") && ($topic->canEdit())) {

		//Deal with post count
		 if (get_plugin_setting('postcount', 'groups') == 'yes'){
			$posts = get_annotations($entity_guid = $topic_guid,$entity_type = "object",$entity_subtype = $topic->subtype,$name = "group_topic_post",$value = "",$owner_guid = 0,$limit = "9999",$entity_owner_guid = 0);
			foreach($posts as $post){
					$owner_guid = $post->owner_guid;
					$post_count = get_annotations($entity_guid = $group_guid,$entity_type = "group",$entity_subtype = "",$name = "post_count",$value = "",$owner_guid = $owner_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
					if($post_count){
						$count = $post_count[0]->value;
						$new_count = $post_count[0]->value -1;
						$id = $post_count[0]->id;
						delete_annotation($id);
						create_annotation($group_guid, 'post_count', $new_count, 'integer', $owner_guid, $access_id=ACCESS_LOGGEDIN);
					}
			}
		}
		// Delete it!
				remove_from_river_by_object ($topic->guid);
				$rowsaffected = $topic->delete();
				if ($rowsaffected > 0) {
					
				} else {
				}
		
		die();
		}
		
?>