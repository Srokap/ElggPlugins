<?php

/**
 * Elgg groups: add post to a topic 
 *
 * @package ElggGroups
 */

// Make sure we're logged in and have a CSRF token
gatekeeper();

// Get input
$topic_guid = (int) get_input('topic_guid');
$group_guid = (int) get_input('group_guid');
$post = get_input('topic_post');


// make sure we have text in the post
if (!$post) {
	register_error(elgg_echo("grouppost:nopost"));
	forward($_SERVER['HTTP_REFERER']);
}


// Check that user is a group member
$group = get_entity($group_guid);
$user = get_loggedin_user();
if (!$group->isMember($user)) {
	register_error(elgg_echo("groups:notmember"));
	forward($_SERVER['HTTP_REFERER']);
}


// Let's see if we can get an form topic with the specified GUID, and that it's a group forum topic
$topic = get_entity($topic_guid);
if (!$topic || $topic->getSubtype() != "groupforumtopic") {
	register_error(elgg_echo("grouptopic:notfound"));
	forward($_SERVER['HTTP_REFERER']);
}


// add the post to the forum topic
$post_id = $topic->annotate('group_topic_post', $post, $topic->access_id, $user->guid);
if ($post_id == false) {
	register_error(elgg_echo("groupspost:failure"));
	forward($_SERVER['HTTP_REFERER']);
}
//Hot Topic Controls
 if (get_plugin_setting('hotposts', 'groups') == 'yes'){
$hot_topic = $topic->hot_topic;
if((!$hot_topic) || ($hot_topic)){
	$post_count = $topic->countAnnotations('group_topic_post');
		$topic_count = $post_count++;
		if($topic_count >= 15){
			elgg_set_ignore_access ($ignore=true);
			$topic->clearMetaData('hot_topic');
			create_metadata($topic_guid,'hot_topic','yes','text',$topic_guid,$access_id = ACCESS_LOGGEDIN,$allow_multiple = false);	
			elgg_set_ignore_access ($ignore=false);
		}else{
			elgg_set_ignore_access ($ignore=true);
			create_metadata($topic_guid,'hot_topic','no','text',$topic_guid,$access_id = ACCESS_LOGGEDIN,$allow_multiple = false);	
			elgg_set_ignore_access ($ignore=false);
	}
}
}//Allow hot posts

//Post Count Controls
 if (get_plugin_setting('postcount', 'groups') == 'yes'){
$post_count = get_annotations($entity_guid = $group_guid,$entity_type = "group",$entity_subtype = "",$name = "post_count",$value = "",$owner_guid = $user->guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
if($post_count){
	$count = $post_count[0]->value;
	$new_count = $post_count[0]->value +1;
	$id = $post_count[0]->id;
	delete_annotation($id);
	create_annotation($group_guid, 'post_count', $new_count, 'integer', $user->guid, $access_id=ACCESS_LOGGED_IN);
}else{
	create_annotation($group_guid, 'post_count', 1, 'integer', $user->guid, $access_id=ACCESS_LOGGED_IN);
}
}


// LiHai Awards System
	//
		$myposts = count_annotations ($entity_guid='', $entity_type="", $entity_subtype="", $name="group_topic_post", $value="", $owner_guid=$user->guid, $limit='', $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
		$awards = get_annotations ($entity_guid=$user->guid, $entity_type="user", $entity_subtype="", $name="award_faint", $value="", $owner_guid=$user->guid, $limit='', $offset=0, $order_by="asc", $timelower=0, $timeupper=0, $entity_owner_guid=0);
		if(!empty($awards)){
			system_message(elgg_echo("groupspost:success"));
		}elseif($myposts >= 40){
			create_annotation($_SESSION['user']->guid, "award_faint", "yes", "text", $_SESSION['user']->guid, $access_id=ACCESS_DEFAULT);
			system_message(elgg_echo("groupspost:success:award"));
		}
	//
	//




// add to river
add_to_river('river/forum/create', 'create', $user->guid, $topic_guid, "", 0, $post_id);


forward($topic->getURL());
?>