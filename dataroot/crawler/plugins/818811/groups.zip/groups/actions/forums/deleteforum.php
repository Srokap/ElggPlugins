<?php



// Make sure we're logged in (send us to the front page if not)
		gatekeeper();

	// Get input data
		$guid = (int) get_input('group_forum');
		
	// Make sure we actually have permission to edit
		$forum = get_entity($guid);
		if ($forum->getSubtype() == "group_forum" && $forum->canEdit()) {
	
		// Delete it!
				$rowsaffected = $forum->delete();
				
		
		// Forward to the main blog page
				forward($_SERVER['HTTP_REFERER']);
		
		}
		
?>