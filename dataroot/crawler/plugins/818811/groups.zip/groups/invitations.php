<?php
/**
 * Manage group invitation requests.
 *
 * @package ElggGroups
 */

require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
gatekeeper();

set_page_owner(get_loggedin_userid());

$user = get_loggedin_user();

$title = elgg_echo('groups:invitations');

$title1 = elgg_view_title($title);

$area2 = "<h2>" . $title . "</h2><br>";

if ($user) {
	// @todo temporary workaround for exts #287.
	$invitations = groups_get_invited_groups($user->getGUID());

	$area2 .= elgg_view('groups/invitationrequests',array('invitations' => $invitations));
	elgg_set_ignore_access($ia);
} else {
	$area2 .= elgg_echo("groups:noaccess");
}
	$area3 = elgg_view('learning_tools/area3');

$body = elgg_view_layout('two_column_right_sidebar', '', $area2,$area3);

page_draw($title, $body);