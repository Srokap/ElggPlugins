<?php
	/**
	 * Elgg groups forum
	 * 
	 * @package ElggGroups
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

	$group_guid = (int)get_input('group_guid');
	$forum_guid = (int)get_input('forum_guid');
	set_page_owner($group_guid);
	if (!(page_owner_entity() instanceof ElggGroup)) {
		forward();
	}
	
	group_gatekeeper();
	
	// Check if forum is for admins only and forward if wrong access
	$group = get_entity($group_guid);
	$forum = get_entity($forum_guid);
	$access = $forum->view_access;
	$denied = true;
	if(($_SESSION['user']->guid == $group->owner_guid)||(isadminloggedin())){
		$denied = false;
	}
	if(($access == "admins")&&($denied == true)){
		register_error(elgg_echo('groups:forum:access:denied'));
		forward($_SERVER['HTTP_REFERER']);
	}
	
	
	$title = $forum->title;
	$title1 = elgg_view_title($title);
	
	$area2 = "<h2>{$title}</h2><br>";

		
	//get any forum topics
	set_context('search');	
	$stickies = elgg_list_entities_from_relationship(array("relationship" => "forum_topic", "relationship_guid" => $forum_guid, "inverse_relationship" => FALSE, "metadata_name" => "sticky", "metadata_value" => "yes", "type" => "object", "subtype" => "groupforumtopic", "container_guid" => $group_guid, "limit" => 10, "full_view" => FALSE, "pagination" => FALSE));
	$topics = elgg_list_entities_from_relationship(array("relationship" => "forum_topic", "relationship_guid" => $forum_guid, "inverse_relationship" => FALSE, "metadata_name" => "sticky", "metadata_value" => "no", "type" => "object", "subtype" => "groupforumtopic", "container_guid" => $group_guid, "limit" => 10, "full_view" => FALSE, "pagination" => TRUE));
	$area2 .= elgg_view("forum/topics", array('stickies' => $stickies, 'topics' => $topics, 'forum_guid' => $forum_guid, 'group_guid' => $group_guid));
	set_context('groups');
	$area3 = elgg_view('learning_tools/area3');

	$body = elgg_view_layout('two_column_right_sidebar',$area1, $area2,$area3);
	
	
	// Finally draw the page
	page_draw($title, $body);



?>