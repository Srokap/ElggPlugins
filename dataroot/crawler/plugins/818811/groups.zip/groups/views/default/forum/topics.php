<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 */
	 
	 $group = get_entity($vars['group_guid']);
	 $forum = get_entity($vars['forum_guid']);
	 $ts = time();
	 $token = generate_action_token($ts);
	 
?>

<div class="contentWrapper">
<div id="pages_breadcrumbs"><b><a href="<?php echo $vars['url']; ?>pg/groups/<?php echo $vars['group_guid']; ?>"><?php echo $group->name; ?></a> > <a href="<?php echo $vars['url']; ?>pg/groups/discussion/<?php echo $vars['group_guid']; ?>"><?php echo elgg_echo('groups:forum'); ?></a></b> > <a href="<?php echo $forum->getURL();?>"><?php echo $forum->title; ?></a></div>

<?php
    //only show the add link if the user is a member
    if(page_owner_entity()->isMember($vars['user'])){
   		echo "<div class='scribe_correction_toggle' id='forum_options_bar' style='text-align:right;padding:8px;'>";
		$groups_forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "container_guid" => $vars['group_guid'], "limit" => ""));
   		?>
        <a href="<?php echo $vars['url']; ?>pg/discussion/new/<?php echo $vars['group_guid']; ?>" class="add_topic_button"><?php echo elgg_echo("groups:addtopic"); ?></a>
        
        <?php
        echo "<b>Go To:</b> <select id='forum_locater'>";
   		echo "<option value='null'>-Select-</option>";
   		foreach($groups_forums as $a_forum){
	   		echo "<option value='{$a_forum->getURL()}'>{$a_forum->title}</option>";
   		}
   		echo "</select>";
		echo "</div>";		   			
	}
	
	if(($vars['stickies']) || ($vars['topics'])){
		if(!empty($vars['stickies'])){
			echo $vars['stickies'];
			echo "<hr>";
		}
		echo $vars['topics'];
	}else{
		echo elgg_echo("grouptopic:notcreated");
	}
?>
</div>

<script>
$('#forum_locater').change(function(){
	var url = $(this).val();
    if(url){ 
      window.location = url; 
    }
    return false;
});

$.ajaxSetup ({
	cache: false
	});
	
	var group_guid = "<?php echo $vars['group_guid'];?>";
	var token = "<?php echo $token; ?>";
	var ts = "<?php echo $ts; ?>";
	var loader = "<img id='option_bar_loader' style='width:20px;height:20px;margin:5px 5px 5px 0;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";

	function delete_topic(id){
		datastr = "&topic=" + id;
		datastr += "&group=" + group_guid;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#forum_options_bar").append(loader);
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/deletetopic",
			data: datastr,
			success: function(msg){
					$("#forum_topic_"+id).slideToggle(function(){
						$("#forum_topic_"+id).remove();
						$("#option_bar_loader").remove();
					});
			}
		});	
	}

function move_to_forum(id){
	var new_forum = $("#forum_chooser"+id).attr('value');
	var old_forum = "<?php echo $vars['forum_guid'];?>";
	datastr = "&topic_guid=" + id;
	datastr += "&old_forum=" + old_forum;
	datastr += "&forum_guid=" + new_forum;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$("#forum_options_bar").append(loader);
	$("#move_forum_box").slideToggle();
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/groups/movetoforum",
		data: datastr,
		success: function(msg){
				$("#forum_topic_"+id).slideToggle(function(){
					$("#forum_topic_"+id).remove();
					$("#option_bar_loader").remove();
				});
		}
	});	
}	
</script>