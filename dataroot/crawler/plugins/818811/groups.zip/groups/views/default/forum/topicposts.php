<?php

	/**
	 * Elgg Topic individual post view. This is all the follow up posts on a particular topic
	 * 
	 * @package ElggGroups
	 * 
	 * @uses $vars['entity'] The posted comment to view
	 */
	 
	  //if the comment owner is looking at it, or admin, or group owner they can edit
		
			
		$close_icon = "<img style='float:right;cursor:pointer;' title='Close' src='{$vars['url']}mod/groups/graphics/refresh.jpg'>";
		$posts_icon = "<img style='width:15px;height:15px;' src='{$vars['url']}mod/groups/graphics/comment_add.png'>";
		$rank_icon = "<img style='width:15px;height:15px;' src='{$vars['url']}mod/groups/graphics/medal.png'>";
		$owner_icon = "<img style='width:15px;height:15px;' src='{$vars['url']}mod/groups/graphics/owner.png'>";
        $topic = get_entity($vars['entity']->entity_guid);
        $group_guid = $topic->container_guid;
        $group = get_entity($group_guid);
        $groupowner = get_entity($group->owner_guid);
        $ts = time();
		$token = generate_action_token($ts);
        $topic = get_input('topic');
        $topic_ent = get_entity($topic);
		$loggedin = get_loggedin_user();
		if($vars['entity']->canEdit()){
			$edit = "<a id='edit_box_link_{$vars['entity']->id}' style='cursor:pointer;'><img class='tipclass' title='Edit' style='width:12px;height:12px;' src='{$vars['url']}mod/groups/graphics/edit.png'></a>";
			$delete = "<a style='cursor:pointer;' onclick='delete_discussion_post({$vars['entity']->id})'><img class='tipclass' title='Delete' style='width:12px;height:12px;' src='{$vars['url']}mod/groups/graphics/cancel.png'></a>";
		}
		if($loggedin->guid == $group->owner_guid){
			if (get_plugin_setting('status', 'groups') == 'yes'){
				$statuses = get_annotations($entity_guid = $post_owner->guid,$entity_type = "user",$entity_subtype = "",$name = "group_status",$value = "",$owner_guid = $group_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
				$status = "<a id='edit_user_link_{$vars['entity']->id}' style='cursor:pointer;'><img class='tipclass' title='Edit User Title' style='width:13px;height:17px;vertical-align:text-bottom;' src='{$vars['url']}mod/groups/graphics/title.png'></a>";
			}
		}
        if(($loggedin->guid == $vars['entity']->owner_guid) || ($loggedin->guid == $groupowner->guid) || (isadminloggedin())){
			$sig_button = "<a id='sig_add_{$vars['entity']->id}' style='cursor:pointer;'><img class='tipclass' title='Edit User Signature' style='width:15px;height:15px;' src='{$vars['url']}mod/groups/graphics/posts.png'></a>";
		}
?>

	<div class="topic_post" id="topic_post_<?php echo $vars['entity']->id;?>"><!-- start the topic_post -->
	
	    <table width="100%">
	   
            <tr><td class='topic_post_stats'>
            	<div class='topic_post_stats_left'>
            		<?php
                        //get infomation about the owner of the comment
                        if ($post_owner = get_user($vars['entity']->owner_guid)) {
	                        
	                        //display the user icon
	                        echo "<div class=\"post_icon\">" . elgg_view("profile/icon",array('entity' => $post_owner, 'size' => 'small')) . "</div>";
	                        
	                        //display the user name
	                        echo "<p><b>" . $post_owner->name . "</b><br />";
	                        // If statuses are allowed echo user's status
	                        if (get_plugin_setting('status', 'groups') == 'yes'){
								$statuses = get_annotations($entity_guid = $post_owner->guid,$entity_type = "user",$entity_subtype = "",$name = "group_status",$value = "",$owner_guid = $group_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
		                        echo "<span class='the_status_{$vars['entity']->owner_guid}'>{$statuses[0]->value}</span><br>";
							}
	                        
                        } else {
                        	echo "<div class=\"post_icon\"><img src=\"" . elgg_view('icon/user/default/small') . "\" /></div>";
                        	echo "<p><b>" . elgg_echo('profile:deleteduser') . "</b><br />";
   			
                        }
                        if (groups_can_edit_discussion($vars['entity'], page_owner_entity()->owner_guid)) {
				   			echo "<small><small><span class='control_features'>{$sticky} | {$edit} | {$delete} | {$status} | {$sig_button}</span></small></small>";
			   			}
                        
                     ?>
            	</div>
            	
            	<div class='topic_post_stats_right'>
            		<?php
            			// Show the post number and time created
            			echo "<span style='float:right;'><small><small>Post: #{$vars['number']}</small></small></span><br>";
            			echo "<span style='float:right;line-height:0.5em;'><small><small>Posted: " . elgg_view_friendly_time($vars['entity']->time_created) . "</small></small></span><br>";
            			
            			// Show if owner is group owner
            			if($post_owner->guid == $group->owner_guid){
       	                    echo "<small><small><span style='float:right;margin-left:5px;' class='tipclass' title='Group Owner'>{$owner_icon}</span></small></small>";
            			}
            			
            			// Show user post count and rank
            			if (get_plugin_setting('postcount', 'groups') == 'yes'){
	                        $post_counts = get_annotations($entity_guid = $group_guid,$entity_type = "group",$entity_subtype = "",$name = "post_count",$value = "",$owner_guid = $vars['entity']->owner_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
			 				if($post_counts){
			 					$post_count = $post_counts[0]->value;
			 				}else{
			 					$post_count = 0;
			 				}
       	                    echo "<small><small><span style='float:right;margin-left:5px;' class='tipclass' title='Post Count'>{$posts_icon}: <span class='user_post_count_{$vars['entity']->owner_guid}'>{$post_count}</span></span></small></small>";
                    	}
            			
                    	if (get_plugin_setting('postcountranks', 'groups') == 'yes'){
	                    	echo "<small><small>";
                        	if($post_count < 10){
       	                        echo "<span style='float:right;' class='tipclass' title='Rank'>{$rank_icon}: ".elgg_echo('groups:rank:newbie')."</span>";
                    		}elseif($post_count < 50){
       	                        echo "<span style='float:right;' class='tipclass' title='Rank'>{$rank_icon}: ".elgg_echo('groups:rank:junior')."</span>";
                    		}elseif($post_count < 200){
       	                        echo "<span style='float:right;' class='tipclass' title='Rank'>{$rank_icon}: ".elgg_echo('groups:rank:senior')."</span>";
                    		}elseif($post_count < 500){
       	                        echo "<span style='float:right;' class='tipclass' title='Rank'>{$rank_icon}: ".elgg_echo('groups:rank:veteran')."</span>";
                    		}else{
       	                        echo "<span style='float:right;' class='tipclass' title='Rank'>{$rank_icon}: ".elgg_echo('groups:rank:squatter')."</span>";
                    		}
                    		echo "</small></small>";
                    	}
            		?>
            	</div>    	
            </td></tr><tr><td class='topic_post_content'>       
              	<?php
              		//display the actual message posted
              		   echo "<div id='post_holder_{$vars['entity']->id}'>";
                       echo parse_urls(elgg_view("output/longtext",array("value" => $vars['entity']->value)));
                       echo "</div>";
              	?>
            </td></tr><tr><td>
            	<?php
            		//Signatures feature
   					if (get_plugin_setting('signatures', 'groups') == 'yes'){
                        $signatures = get_annotations($entity_guid = $group_guid,$entity_type = "",$entity_subtype = "",$name = "sigs",$value = "",$owner_guid = $vars['entity']->owner_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
                       if($signatures){
	                       $group = get_entity($group_guid);
	                       $groupowner = get_entity($group->owner_guid);
	                       echo "<hr>";
	                       echo "<center><em><span class='the_sig_{$vars['entity']->owner_guid}'>" . $signatures[0]->value . "</span></em></center><br>";
                       }else{
	                       echo "<center><em><span class='the_sig_{$vars['entity']->owner_guid}'></span></em></center>";
                       }
                   }
	                
            	?>
            </td></tr>
        </table>
		<?php

		    //if the comment owner is looking at it, or admin, or group owner they can edit
		    if (groups_can_edit_discussion($vars['entity'], page_owner_entity()->owner_guid)) {
        ?>
		      
		        <?php
             				
						
					//display an edit area							
					echo "<div style='display:none;' id='edit_post_box_{$vars['entity']->id}'>";
					echo "<p class='longtext_editarea'>".elgg_view('input/longtext', array('internalname' => 'postComment'.$vars['entity']->id, 'internalid' => 'postComment'.$vars['entity']->id,'value' => $vars['entity']->value))."</p>";
						echo "<input type='hidden' id='post_{$vars['entity']->id}' value='{$vars['entity']->id}' />";
						echo "<input type='hidden' id='topic_{$vars['entity']->id}' value='{$topic->guid}' />";
						echo "<a class='submit_button' onclick='edit_this_post({$vars['entity']->id})'>Edit Post</a>";
					echo "</div>";
					 }

					if($loggedin->guid == $group->owner_guid){
						if (get_plugin_setting('status', 'groups') == 'yes'){
							if($statuses){
								$old_status = $statuses[0]->value;
							}else{
								$old_status = "";
							}
							echo "<div style='display:none;' id='edit_user_box_{$vars['entity']->id}'>";
								echo "<b>" . elgg_echo('groups:status:title:form') . "</b><br>";
								echo "<input type='text' id='status_text_{$vars['entity']->id}' value='{$old_status}' />";
								echo "<input type='hidden' id='group_guid' value='{$group_guid}' />";
								echo " <a class='submit_button' onclick='new_status({$vars['entity']->id});'>Edit User Title</a>";
							echo "</div>";
						}
					}
					
					echo "<div id='sig_edit_box_{$vars['entity']->id}' style='display:none;'>";
					echo "<input type='hidden' id='user_id_{$vars['entity']->id}' value='{$vars['entity']->owner_guid}' />";
					echo "<input type='text' size='60' id='new_sig_{$vars['entity']->id}' value='{$signatures[0]->value}' />";
					?>
					<a class='submit_button' onclick="new_sig(<?php echo $vars['entity']->id;?>);">Update Signature</a>
					<?php
					echo "</div>";
           
	    ?>
		<div id="edit_loader<?php echo $vars['entity']->id;?>" style="display:none;">
			<img style='width:30px; height:30px;margin:10px 0 -10px 300px;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>
		</div>	
	    
	    
	</div><!-- end the topic_post -->

<script type="text/javascript">
$("#edit_box_link_<?php echo $vars['entity']->id;?>").click(function(){
	if($("#edit_user_box_<?php echo $vars['entity']->id;?>").is(":visible")){
		$("#edit_user_box_<?php echo $vars['entity']->id;?>").slideToggle();
	}else if($("#sig_edit_box_<?php echo $vars['entity']->id;?>").is(":visible")){
		$("#sig_edit_box_<?php echo $vars['entity']->id;?>").slideToggle();
	}
	$("#edit_post_box_<?php echo $vars['entity']->id;?>").slideToggle();
});

$("#edit_user_link_<?php echo $vars['entity']->id;?>").click(function(){
	if($("#edit_post_box_<?php echo $vars['entity']->id;?>").is(":visible")){
		$("#edit_post_box_<?php echo $vars['entity']->id;?>").slideToggle();
	}else if($("#sig_edit_box_<?php echo $vars['entity']->id;?>").is(":visible")){
		$("#sig_edit_box_<?php echo $vars['entity']->id;?>").slideToggle();
	}
	$("#edit_user_box_<?php echo $vars['entity']->id;?>").slideToggle();
});


$("#sig_add_<?php echo $vars['entity']->id;?>").click(function(){
	if($("#edit_post_box_<?php echo $vars['entity']->id;?>").is(":visible")){
		$("#edit_post_box_<?php echo $vars['entity']->id;?>").slideToggle();
	}else if($("#edit_user_box_<?php echo $vars['entity']->id;?>").is(":visible")){
		$("#edit_user_box_<?php echo $vars['entity']->id;?>").slideToggle();
	}
	$("#sig_edit_box_<?php echo $vars['entity']->id;?>").slideToggle();
});



</script>	