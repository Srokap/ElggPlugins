<script src="<?php echo $vars['url'];?>mod/lexis/lib/jquery.tipTip.minified.js"></script>
<script>
$(function(){
$(".tipclass").tipTip({defaultPosition: "top", maxWidth: "200px"});
});
</script>

<?php
 	
	$add_tip = elgg_echo('groups:addtopic');
    // Latest forum discussion for the group home page

    //check to make sure this group forum has been activated
    if($vars['entity']->forum_enable != 'no'){
	$add_topic = "<a class='tipclass' title='{$add_tip}' href='{$vars['url']}pg/forum/new/{$vars['entity']->guid}'><img style='vertical-align:text-bottom;margin-left:5px;height:16px;width:16px;' src='{$vars['url']}mod/groups/graphics/add_topic.png'></a>";
?>

<div class="contentWrapper">
<h2><?php echo elgg_echo('groups:latestdiscussion') . $add_topic;?></h2>
<?php
	
    $forum = elgg_get_entities_from_annotations(array('types' => 'object', 'subtypes' => 'groupforumtopic', 'annotation_names' => 'group_topic_post', 'container_guid' => $vars['entity']->guid, 'limit' => 10, 'order_by' => 'maxtime desc'));
	
    if($forum){
	    if (get_plugin_setting('hotposts', 'groups') == 'yes'){
        foreach($forum as $f){
        	    
                $count_annotations = $f->countAnnotations("group_topic_post");
                if($f->hot_topic == "no"){
	                 echo "<div class=\"forum_latest\">";
        	   		 echo "<div class=\"topic_owner_icon\">" . elgg_view('profile/icon',array('entity' => $f->getOwnerEntity(), 'size' => 'tiny', 'override' => true)) . "</div>";
    	       		 echo "<div class=\"topic_title\"><p><a href=\"{$f->getURL()}\">" . $f->title . "</a></p> <p class=\"topic_replies\"><small>".elgg_echo('groups:posts').": " . $count_annotations . "</small></p></div>";
    	        	
    	       		 echo "</div>";
                }else{
	                $hot = "<img style='float:right;height:16px;width:16px;' src='{$vars['url']}mod/groups/graphics/hot.png'>";
               
        	    echo "<div class=\"forum_latest\">";
        	    echo "<div class=\"topic_owner_icon\">" . elgg_view('profile/icon',array('entity' => $f->getOwnerEntity(), 'size' => 'tiny', 'override' => true)) . "</div>";
    	        echo "<div class=\"topic_title\"><p><a href=\"{$f->getURL()}\">" . $f->title . "</a>{$hot}</p> <p class=\"topic_replies\"><small>".elgg_echo('groups:posts').": " . $count_annotations . "</small></p></div>";
    	        	
    	        echo "</div>";
    	         }
        }
    }else{
	     foreach($forum as $f){
        	    
                $count_annotations = $f->countAnnotations("group_topic_post");
               
        	    echo "<div class=\"forum_latest\">";
        	    echo "<div class=\"topic_owner_icon\">" . elgg_view('profile/icon',array('entity' => $f->getOwnerEntity(), 'size' => 'tiny', 'override' => true)) . "</div>";
    	        echo "<div class=\"topic_title\"><p><a href=\"{$f->getURL()}\">" . $f->title . "</a></p> <p class=\"topic_replies\"><small>".elgg_echo('groups:posts').": " . $count_annotations . "</small></p></div>";
    	        	
    	        echo "</div>";
    	       
        }
    }
    } else {
		echo "<div class=\"forum_latest\">";
		echo elgg_echo("grouptopic:notcreated");
		echo "</div>";
    }
?>
<div class="clearfloat" /></div><br>
&nbsp;<a class='submit_button' href='<?php echo $vars['url'];?>pg/groups/discussion/<?php echo $vars['entity']->guid;?>'><?php echo elgg_echo('more');?></a>
</div>
<?php
	}//end of forum active check
?>