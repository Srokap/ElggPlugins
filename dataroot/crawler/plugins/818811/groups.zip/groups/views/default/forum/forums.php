<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 */
	 
	$group = get_entity($vars['group_guid']);
	$ts = time();
	$token = generate_action_token($ts);
	 
?>

<div class="contentWrapper">
<div id="pages_breadcrumbs"><b><a href="<?php echo $vars['url']; ?>pg/groups/<?php echo $vars['group_guid']; ?>"><?php echo $group->name; ?></a></b> > <a href="<?php echo $vars['url']; ?>pg/groups/discussion/<?php echo $vars['group_guid']; ?>/"><?php echo elgg_echo("groups:forum"); ?></a></div>

<?php
    //only show the add link if the user is a member
    if(page_owner_entity()->isMember($vars['user'])){
   		echo "<div class='scribe_correction_toggle' id='forum_options_bar' style='text-align:right;padding:8px;'>";
		?>
        <a href="<?php echo $vars['url']; ?>pg/discussion/new/<?php echo $vars['group_guid']; ?>" class="add_topic_button"><?php echo elgg_echo("groups:addtopic"); ?></a>
		<?php
			//For group owners/admins/site admins
			if($group->canEdit()){ ?>
		        <a id='add_forum_link' class="add_topic_button"><?php echo elgg_echo("groups:addforum"); ?></a>
			<?php }
		echo "</div>";		   			
	}
	// New Forum Form
	echo "<div id='add_forum_form' style='display:none;'>";
	echo "<input type='text' size='40' id='forum_name' class='tipclass' title='Forum Name' value='Forum Name' onfocus=\"this.value='';\" /><br>";
	echo "<input type='text' size='85' id='forum_desc' class='tipclass' title='Description' value='Description' onfocus=\"this.value='';\" /><br>";
	echo "<b>Forum Access:</b> <select id='forum_access'><option value='all'>Group Members</option><option value='admins'>Group Managers</option></select><br>";
	echo "<input type='hidden' id='group_guid' value='{$vars['group_guid']}' />";
	echo "<a id='add_forum_link' class='submit_button' onclick='add_new_forum();'>".elgg_echo("save")."</a><br><br>";
	echo "</div>";
	
	echo "<div id='forum_list_holder'>";
	if($vars['forums']){
		echo $vars['forums'];
	}else{
		echo elgg_echo("group:forum:notcreated");
	}
	echo "</div>";
?>
</div>

<script>
	$.ajaxSetup ({
	cache: false
	});
	
	$('#add_forum_link').click(function(){
		$('#add_forum_form').slideToggle();	
	});
	
	var token = "<?php echo $token; ?>";
	var ts = "<?php echo $ts; ?>";
	var loader = "<img id='option_bar_loader' style='width:20px;height:20px;margin:5px 5px 5px 0;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";
	var default_name = "Forum Name";
	var default_desc = "Description";
	
	function add_new_forum(){
		var forum_name = $('#forum_name').attr('value');
		var forum_desc = $('#forum_desc').attr('value');
		var group_guid = $('#group_guid').attr('value');
		var forum_access = $('#forum_access').attr('value');
		datastr = "&forum_name=" + forum_name;
		datastr += "&forum_desc=" + forum_desc;
		datastr += "&group_guid=" + group_guid;
		datastr += "&forum_access=" + forum_access;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#forum_options_bar").append(loader);
		$("#add_forum_form").slideToggle();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/addforum",
			data: datastr,
			success: function(msg){
					$("#option_bar_loader").remove();
					$("#forum_list_holder").append(msg);
					$('#forum_name').val(default_name);
					$('#forum_desc').val(default_desc);
			}
		});	
	}
	
	function delete_forum(id){
		datastr = "&group_forum=" + id;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#forum_options_bar").append(loader);
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/deleteforum",
			data: datastr,
			success: function(msg){
					$("#group_form_list_"+id).slideToggle(function(){
						$("#group_form_list_"+id).remove();
						$("#option_bar_loader").remove();
					});
			}
		});	
	}
	
	function edit_forum(id){
		var new_name = $('#forum_name'+id).attr('value');
		var new_desc = $('#forum_desc'+id).attr('value');
		var group_guid = $('#group_guid').attr('value');
		var new_access = $('#forum_access'+id).attr('value');
		datastr = "&forum_name=" + new_name;
		datastr += "&forum_desc=" + new_desc;
		datastr += "&group_guid=" + group_guid;
		datastr += "&forum_guid=" + id;
		datastr += "&forum_access=" + new_access;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#forum_options_bar").append(loader);
		$("#edit_forum_form_"+id).slideToggle();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/editforum",
			data: datastr,
			success: function(msg){
					$("#option_bar_loader").remove();
					$("#group_form_list_"+id).replaceWith(msg);
			}
		});	
	}
	
</script>