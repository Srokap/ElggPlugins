<?php

	$group = $vars['entity'];
	$group_guid = $group->guid;
	$memcount = $group->getMembers(0, 0, TRUE);
	$ownericon = "<img style='width:15px;height:15px;' src='{$vars['url']}mod/groups/graphics/owner.png'>";
	$ts = time();
	$token = generate_action_token($ts);


?>

<div class='contentWrapper'>
	<?php

		echo "<div class='scribe_correction_toggle' id='loading_box_holder'>" . sprintf(elgg_echo('groups:members:count'),$memcount)."</div>";


		$members = get_entities_from_relationship('member', $group_guid, true, 'user', '', 0, 10, false);
		if($members){
			foreach($members as $member){
				$is_owner = false;
				if($member->guid == $group->owner_guid){ $is_owner = true; }
				//Get icon
				$member_icon = elgg_view("profile/icon", array('entity' => $member, 'size' => 'medium', 'override' => FALSE));
 				// Get user title
				$statuses = get_annotations($entity_guid = $member->guid,$entity_type = "user",$entity_subtype = "",$name = "group_status",$value = "",$owner_guid = $group_guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
                if($statuses){
	             	$member_status = $statuses[0]->value;   
                }else{
	             	$member_status = "";   
                }
 				// Get post count
 				$post_counts = get_annotations($entity_guid = $group_guid,$entity_type = "group",$entity_subtype = "",$name = "post_count",$value = "",$owner_guid = $member->guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
				if($post_counts){
 					$member_posts = elgg_echo('group:forum:posts') . $post_counts[0]->value;
 				}else{
 					$member_posts = elgg_echo('group:forum:posts') . 0;
 				}
				// Get signature
                $signatures = get_annotations($entity_guid = $group_guid,$entity_type = "",$entity_subtype = "",$name = "sigs",$value = "",$owner_guid = $member->guid,$limit = 1,$offset = 0,$order_by = "asc",$timelower = 0,$timeupper = 0,$entity_owner_guid = 0);	
				if($signatures){
					$member_signature = $signatures[0]->value;	
				}else{
					$member_signature = "";
				}
 				
				echo "<div class='group_member_listing' id='group_member_listing_{$member->guid}'>";
					echo "<div class='group_member_listing_icon'>";
					echo $member_icon;
					echo "</div>";
					
					echo "<div class='group_member_listing_content'>";
					echo "<h3><a href='{$member->getURL()}'>{$member->name}</a>"; if($is_owner == true){echo $ownericon;}else{}echo "</h3>";
					echo $member_status . "<br>";
					echo $member_posts . "<br>";
					echo "<em>" . $member_signature . "</em>";
					echo "</div>";
					if($group->canEdit()){
						echo "<span class='control_features' style='float:right;'>";
							echo "<a style='cursor:pointer' class='tipclass' title='Kick User From Group' onclick='kick_user({$member->guid});'><img style='width:12px;height:12px;' src='{$vars['url']}mod/groups/graphics/cancel.png'></a>";
							echo " <a style='cursor:pointer' class='tipclass' title='Edit User Title' id='user_title{$member->guid}'><img style='width:13px;height:17px;' src='{$vars['url']}mod/groups/graphics/title.png'></a>";
							echo " <a style='cursor:pointer' class='tipclass' title='Edit Signature' id='user_sig{$member->guid}'><img style='width:15px;height:15px;' src='{$vars['url']}mod/groups/graphics/posts.png'></a>";
							if($is_owner == false){
								echo " <a style='cursor:pointer' class='tipclass' title='Make Group Owner' onclick='set_group_owner({$member->guid});'>{$ownericon}</a>";
								echo " <a style='cursor:pointer' class='tipclass' title='Make Forum Moderator' id='make_moderator{$member->guid}'><img style='width:15px;height:15px;' src='{$vars['url']}mod/groups/graphics/moderator.png'></a>";
							}
						echo "</span>";	
					}
					echo "<div class='clearfloat'></div>";
				echo "</div>";
			}
		}

	?>
</div>

<script>
$.ajaxSetup ({
	cache: false
	});
	
	var token = "<?php echo $token; ?>";
	var ts = "<?php echo $ts; ?>";
	var loader = "<img id='ajax_loader' style='width:25px;height:25px;margin:5px 5px 5px 0;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";
	var group_guid = "<?php echo $group_guid;?>";

function kick_user(id){
	datastr = "&user_guid=" + id;
	datastr += "&group_guid=" + group_guid;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$("#loading_box_holder").append(loader);
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/groups/kickuser",
		data: datastr,
		success: function(msg){
				$("#ajax_loader").remove(function(){
					$("#group_member_listing_"+id).empty();
					$("#group_member_listing_"+id).append(msg, function(){
						$("#group_member_listing_"+id).delay(2000).slideToggle();
						$("#group_member_listing_"+id).remove();		
					});
				});
		}
	});	
}
</script>