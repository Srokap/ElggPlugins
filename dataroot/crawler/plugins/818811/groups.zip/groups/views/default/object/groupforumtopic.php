<?php

/**
 * Elgg Groups latest discussion listing
 *
 * @package ElggGroups
 */

//get the required variables
$title = htmlentities($vars['entity']->title, ENT_QUOTES, 'UTF-8');
$topic_owner = get_user($vars['entity']->owner_guid);
$group = get_entity($vars['entity']->container_guid);
$topic_created = elgg_view_friendly_time($vars['entity']->time_created);
$counter = $vars['entity']->countAnnotations("group_topic_post");
$last_post = $vars['entity']->getAnnotations("group_topic_post", 1, 0, "desc");
$groups_forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "container_guid" => $vars['entity']->container_guid, "limit" => ""));
$my_forum = false;	
foreach($groups_forums as $c_forum){
	$mine = check_entity_relationship($c_forum->guid, "forum_topic", $vars['entity']->guid);
	if($mine !== FALSE){
		$my_forum = $c_forum;
		break;
	}else{
		$my_forum = false;	
	}
}

if($vars['entity']->sticky == "yes"){
	$sticky = "<img style='margin-left:3px;' class='tipclass' title='Sticky' src='{$vars['url']}mod/groups/graphics/sticky.gif'>";
}

if (get_plugin_setting('hotposts', 'groups') == 'yes'){
	$hoticon = "<img clas='tipclass' title='Hot Topic' style='height:16px;width:16px;' src='{$vars['url']}mod/groups/graphics/hot.png'>";
	if(($vars['entity']->hot_topic == "no") || (!$vars['entity']->hot_topic)){
		$hot = "";
	}else{
		$hot = $hoticon;
	}
}
//get the time and user
if ($last_post) {
	foreach($last_post as $last) {
		$last_time = $last->time_created;
		$last_user = $last->owner_guid;
		$u = get_user($last_user);
		$commenter_link = "<a style='cursor:pointer;' href\"{$u->getURL()}\">$u->name</a>";
		$text = sprintf(elgg_echo('groups:lastcomment'), elgg_view_friendly_time($last_time), $commenter_link);
	}
}



$topic_icon = elgg_view("profile/icon", array('entity' => $topic_owner, 'size' => 'small', 'override' => TRUE));

//select the correct output depending on where you are
if (get_context() == "search") {
	
	echo "<div class='forum_topic_listing' id='forum_topic_{$vars['entity']->guid}'>";
		echo "<div class='forum_topic_listing_icon'>";
		echo $topic_icon;
		echo "</div>";
		
		echo "<div class='forum_topic_listing_content'>";
		echo "<a href='{$vars['entity']->getURL()}'>{$vars['entity']->title}</a>{$sticky} {$hot}<br>";
		if ($group instanceof ElggGroup) {
			echo elgg_echo('group') . ": <a href='{$group->getURL()}'>".htmlentities($group->name, ENT_QUOTES, 'UTF-8') ."</a><br>";
		}
		if($my_forum !== false){
			echo elgg_echo('groups:choose:forum') . ": <a href='{$my_forum->getURL()}'>{$my_forum->title}</a>";
		}
		echo "</div>";
		
		echo "<div class='forum_topic_listing_latest'>";
		echo sprintf(elgg_echo('group:created'), $topic_created, $counter) . "<br>";
		echo "<small><small>{$text}</small></small>";
		if (page_owner_entity() instanceof ElggGroup) {
			if($vars['entity']->canEdit()){
				echo "<span class='control_features' style='float:right;'>";
					echo "<a style='cursor:pointer' class='tipclass' title='Delete Topic' onclick='delete_topic({$vars['entity']->guid});'><img style='width:12px;height:12px;' src='{$vars['url']}mod/groups/graphics/cancel.png'></a>";
					echo " <a style='cursor:pointer' class='tipclass' title='Edit Topic' id='edit_topic{$vars['entity']->guid}'><img style='width:12px;height:12px;' src='{$vars['url']}mod/groups/graphics/edit.png'></a>";
					echo " <a style='cursor:pointer' class='tipclass' title='Move Topic' id='move_topic{$vars['entity']->guid}'><img style='width:12px;height:12px;' src='{$vars['url']}mod/groups/graphics/move_topic.png'></a>";
				echo "</span>";	
			}
		}
		echo "</div>";
		echo "<div class='clearfloat'></div>";

		// Move to forum box
				echo "<div id='move_forum_box{$vars['entity']->guid}' style='display:none;'>";	
				echo elgg_echo('groups:forum:move:choice');
				echo "<select id='forum_chooser{$vars['entity']->guid}'>";
				foreach($groups_forums as $b_forum){
					if($b_forum->guid == $my_forum){
					}else{
			   			echo "<option value='{$b_forum->guid}'>{$b_forum->title}</option>";
		   			}
		   		}
		   		echo "</select>&nbsp;";
				echo "<input type='hidden' id='topic_guid{$vars['entity']->guid}' value='{$vars['entity']->guid}' />";
		   		echo "<a class='submit_button' onclick='move_to_forum({$vars['entity']->guid});'>Save</a><br>";
				echo "</div>";
	echo "</div>";
	
}else{


}

?>

<script>

$("#move_topic<?php echo $vars['entity']->guid;?>").click(function(){
		$("#move_forum_box<?php echo $vars['entity']->guid;?>").slideToggle();	
	});

</script>