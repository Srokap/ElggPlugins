<?php
		if(is_plugin_enabled('profile_manager')){
			 
		        if ($vars['full'] == true) {
		            $group_fields = profile_manager_get_categorized_group_fields();
		            
		            if(count($group_fields["fields"]) > 0){
		                $group_fields = $group_fields["fields"];
		                
		                foreach($group_fields as $field) {
		                    $metadata_name = $field->metadata_name;
		                    $value = $vars['entity']->$metadata_name;
		                    if($value){            
		                        // make title
		                        $title = $field->getTitle();
		                        
		                        // adjust output type
		                        if($field->output_as_tags == "yes"){
		                            $output_type = "tags";
		                        } else {
		                            $output_type = $field->metadata_type;
		                        }
		                        
		                        if($field->metadata_type == "url"){
		                            $target = "_blank";
		                        } else {
		                            $target = null;
		                        }
		                        
		                        //This function controls the alternating class
		                        $even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
		                        
		                        echo "<p class=\"{$even_odd}\">";
		                        echo "<b>" . $title . ": </b>";
		                        echo elgg_view("output/" . $output_type, array('value' => $value, "target" => $target));
		                        echo "</p>";
		                    }
		                }
		            }
		        }
    
		}else{
			if ($vars['full'] == true) {
			if (is_array($vars['config']->group) && sizeof($vars['config']->group) > 0){

				foreach($vars['config']->group as $shortname => $valtype) {
					if ($shortname != "name") {
						$value = $vars['entity']->$shortname;

						if (!empty($value)) {
							//This function controls the alternating class
							$even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
						}

						echo "<p class=\"{$even_odd}\">";
						echo "<b>";
						echo elgg_echo("groups:{$shortname}");
						echo ": </b>";

						$options = array(
							'value' => $vars['entity']->$shortname
						);

						if ($valtype == 'tags') {
							$options['tag_names'] = $shortname;
						}

						echo elgg_view("output/{$valtype}", $options);

						echo "</p>";
					}
				}
			}
		}
	}
	?>