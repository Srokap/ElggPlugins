<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 */

	$group = $vars['entity'];
	$owner = get_entity($vars['entity']->owner_guid);
	$forward_url = $group->getURL();
	
	
?>
<div class="contentWrapper">
<?php

$icon = "<img style='width:200px;height:200px;' src='{$vars['url']}mod/groups/graphics/invite.jpg'>";

echo "<div class=\"contentWrapper\">";
echo "<center><div style='width:700px;'>";
echo "<div style='float:left;margin-right:20px;width:220px'>";
echo $icon;
echo "</div><div style='float:left;width:350px;padding:5px;'>";
echo elgg_echo('groups:invite:explain');
echo "</div></div>";
echo "<div class='clearfloat'></div>";
echo "<br><br></div>";

echo "<br><h3 class='sectiontitleheader'>" . elgg_echo('friends:invite') . "</h3>";
?>
<form action="<?php echo $vars['url']; ?>action/groups/invite" method="post">

	<?php
	echo elgg_view('input/securitytoken');

	if ($friends = get_loggedin_user()->getFriends('', 0)) {
	$suggested = array();
	foreach($friends as $friend){
		$in = check_entity_relationship($friend->guid, 'member', $vars['entity']->guid);
		if($in == FALSE){
			array_push($suggested,$friend);		
		}
	}

		echo elgg_view('friends/picker',array('entities' => $suggested, 'internalname' => 'user_guid', 'highlight' => 'all'));	

	}
	
	?>
	<input type="hidden" name="forward_url" value="<?php echo $forward_url; ?>" />
	<input type="hidden" name="group_guid" value="<?php echo $group->guid; ?>" />
	<input type="submit" value="<?php echo elgg_echo('invite'); ?>" />
</form>

<?php
echo "<br><h3 class='sectiontitleheader'>" . elgg_echo('groups:invite:waiting') . "</h3>";
set_context("search");
$invited = elgg_list_entities_from_relationship(array("relationship" => "invited", "relationship_guid" => $vars['entity']->guid, "type" => "user", "limit" => 0, "full_view" => FALSE, "pagination" => FALSE));
echo $invited;



?>
</div>
