<?php

	$action = "groups/add_rules";
	
	if (isset($vars['entity']->rules)) {
		$rules = $vars['entity']->rules;
		$access_id = $vars['entity']->access_id;
	}else{
		$rules = "";
		$access_id = "";
	}
		
?>

<form action="<?php echo $vars['url']; ?>action/<?php echo $action; ?>" enctype="multipart/form-data" method="post" name="RulesForm">
<?php echo elgg_view('input/securitytoken') ?>

	<p>
    		<label>
    				<?php
						echo elgg_view("input/longtext", array(
						"internalname" => "rules",
						"value" => $rules,
						));
					?>
			</label>
  	</p>
	
  	<?php
  		echo "<input type=\"hidden\" name=\"group_guid\" value=\"".$vars['entity']->guid."\" />";
  	?>
  	
  	<p>
			<input type="submit" name="submit" value="<?php echo elgg_echo('save'); ?>" />
		</p>
  	
</form>