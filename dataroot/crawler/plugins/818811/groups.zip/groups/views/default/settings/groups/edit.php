<?php
	$hidden_groups = $vars['entity']->hidden_groups;
	if (!$hidden_groups) $hidden_groups = 'no';
	$announcements = $vars['entity']->announcements;
	if (!$announcements) $announcements = 'no';
	$rules = $vars['entity']->rules;
	if (!$rules) $rules = 'no';
	$hotposts = $vars['entity']->hotposts;
	if (!$hotposts) $hotposts = 'no';
	$status = $vars['entity']->status;
	if (!$status) $status = 'no';
	$postcount = $vars['entity']->postcount;
	if (!$postcount) $postcount = 'no';
	$postcountranks = $vars['entity']->postcountranks;
	if (!$postcountranks) $postcountranks = 'no';
	$block_groups = $vars['entity']->block_groups;
	if (!$block_groups) $block_groups = 'no';
	$postsperpage = $vars['entity']->postsperpage;
	if (!$postsperpage) $postsperpage = '50';
	$signatures = $vars['entity']->signatures;
	if (!$signatures) $signatures = '50';

?>	

<div id="elgg_horizontal_tabbed_nav">
	<ul>
		<li><a class="selected" style="cursor:pointer;" id="load_checks"><?php echo elgg_echo('groups:admin:check'); ?></a></li>
		<li><a style="cursor:pointer;" id="load_groups"><?php echo elgg_echo('groups:admin:groups'); ?></a></li>
		<li><a style="cursor:pointer;" id="load_forum"><?php echo elgg_echo('groups:admin:forum'); ?></a></li>
	</ul>
</div>

<div id="admin_checks">
	<?php
		$version = get_version($humanreadable = true);
			if(($version == "1.7.7") || ($version !== "1.7.8") || ($version !== "1.7.9")){
				echo "<div id='admin_good'>" . elgg_echo('groups:admin:version:right') . "</div>";	
			}else{
				echo "<div id='admin_error'>" . elgg_echo('groups:admin:version:toolow') . "</div>";
			}
	/*	$plugins = get_plugin_list();
			if($plugins){
				
				 foreach($plugins as $key => $plugin)//****
                {
                    if($plugin == "groups")
                    {
                        $groups = $plugin;// save Group's Seq#
                    }
                    echo "<h2>DBG:: ($key) &lt;-- ? --> ($groups)</h2>";//**** DBG only
                    // compare each one's seq# with Group'saved s Seq#
                    if(($plugin == "logbrowser") && ($key > $groups)){
                        echo "<div id='admin_error'>" . elgg_echo('groups:admin:prof_manager:toolow') . "</div>";
                    }elseif(($plugin == "profile_manager") && ($key < $groups)){
                        echo "<div id='admin_good'>" . elgg_echo('groups:admin:prof_manager:right') . "</div>";    
                    }elseif(($plugin == "group_multiple_admin") && ($key < $groups)){
                        echo "<div id='admin_error'>" . elgg_echo('groups:admin:group_multiple_admin:toolow') . "</div>";
                    }elseif(($plugin == "group_multiple_admin") && ($key > $groups)){
                        echo "<div id='admin_good'>" . elgg_echo('groups:admin:group_multiple_admin:right') . "</div>";    
                    }elseif(($plugin == "group_kick") && ($key < $groups)){
                        echo "<div id='admin_error'>" . elgg_echo('groups:admin:group_kick:toolow') . "</div>";
                    }elseif(($plugin == "group_kick") && ($key > $groups)){
                        echo "<div id='admin_good'>" . elgg_echo('groups:admin:group_kick:right') . "</div>";    
                    }elseif($plugin == "groupriver"){
                        echo "<div id='admin_error'>" . elgg_echo('groups:admin:groupriver:already') . "</div>";
                    }
                }//foreach($plugins as $key =? $plugin)
				
				
				
			$number = 0;
			foreach($plugins as $plugin){
				$new_number = $number++;
				$plugin->key = $new_number;
			}
			foreach($plugins as $plugin){
				echo $plugin . " " . $plugin->key . "<br>";
			}
			
				foreach($plugins as $plugin){
					if($plugin == "groups"){
						$groups = $plugin;
						$groups_key = array_keys($plugins,$groups);
						echo $groups_key;
						echo "YES";
					}
					if(($plugin == "profile_manager") && ($plugin[key] > $groups[key])){
					echo "<div id='admin_error'>" . elgg_echo('groups:admin:prof_manager:toolow') . "</div>";
					}elseif(($plugin == "profile_manager") && ($plugin[key] < $groups[key])){
					echo "<div id='admin_good'>" . elgg_echo('groups:admin:prof_manager:right') . "</div>";	
					}elseif(($plugin == "group_multiple_admin") && ($plugin[key] < $groups[key])){
					echo "<div id='admin_error'>" . elgg_echo('groups:admin:group_multiple_admin:toolow') . "</div>";
					}elseif((($plugin == "group_multiple_admin") && ($plugin[key] > $groups[key]))){
					echo "<div id='admin_good'>" . elgg_echo('groups:admin:group_multiple_admin:right') . "</div>";	
					}elseif(($plugin == "group_kick") && ($plugin[key] < $groups[key])){
					echo "<div id='admin_error'>" . elgg_echo('groups:admin:group_kick:toolow') . "</div>";
					}elseif((($plugin == "group_kick") && ($plugin[key] > $groups[key]))){
					echo "<div id='admin_good'>" . elgg_echo('groups:admin:group_kick:right') . "</div>";	
					}elseif($plugin == "groupriver"){
					echo "<div id='admin_error'>" . elgg_echo('groups:admin:groupriver:already') . "</div>";
					}
				}
				
			} 
			*/
	?>
</div>

<div id="admin_groups" style="display:none;">
	<p>
		<?php echo elgg_echo('groups:allowhiddengroups'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[hidden_groups]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $hidden_groups
			));
		?>
	</p>
	
	<p>
		<?php echo elgg_echo('groups:allowannouncements'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[announcements]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $announcements
			));
		?>
	</p>
	
	<p>
		<?php echo elgg_echo('groups:allowrules'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[rules]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $rules
			));
		?>
	</p>
	
	<p>
		<?php echo elgg_echo('groups:allowstatus'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[status]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $status
			));
		?>
	</p>
	
	<p>
		<?php echo elgg_echo('groups:allowblockgroups'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[block_groups]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $block_groups
			));
		?>
	</p>
	
</div>

<div id="admin_forum" style="display:none;">
	
	<p>
		<?php echo elgg_echo('groups:postsperpage'); ?>
		
		<?php
			echo elgg_view('input/text', array(
				'internalname' => 'params[postsperpage]',
				'value' => $postsperpage
			));
		?>
	</p>
	
	<p>
		<?php echo elgg_echo('groups:allowhotposts'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[hotposts]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $hotposts
			));
		?>
	</p>
	
	<p>
		<?php echo elgg_echo('groups:allowpostcount'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[postcount]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $postcount
			));
		?>
	</p>
	
	<p>
		<?php echo elgg_echo('groups:allowsignatures'); ?>
		
		<?php
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[signatures]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $signatures
			));
		?>
	</p>
	
	<?php
		if (get_plugin_setting('postcount', 'groups') == 'yes') {
		echo "<p>";
		echo elgg_echo('groups:allowpostcountranks') . "<br>";
		echo "<small>" . elgg_echo('groups:post:ranks:instructions') . "</small>";
			echo elgg_view('input/pulldown', array(
				'internalname' => 'params[postcountranks]',
				'options_values' => array(
					'no' => elgg_echo('option:no'),
					'yes' => elgg_echo('option:yes')
				),
				'value' => $postcountranks
			));
		
		echo "</p>";
		
		}
		
		if ((get_plugin_setting('postcount', 'groups') == 'yes') || (get_plugin_setting('hotposts', 'groups') == 'yes')){
			if (get_plugin_setting('post_count_upgrade', 'groups') !== 'done'){
				$ts = time();
				$token = generate_action_token($ts);
				echo elgg_echo('groups:upgrade:instructions') . "<br>";
				echo "<a href='{$vars['url']}action/groups/add_post_counts?&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('groups:run:upgrade') . "</a><br><br>";
				
			}
		}
		
		$groups = elgg_get_entities(array("type" => "group", "limit" => ""));
		$forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "limit" => ""));
		$topics = elgg_get_entities(array("type" => "object", "subtype" => "groupforumtopic", "limit" => ""));
		
		$forum_upgrade = false;
		
		foreach($groups as $group){
			$forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "container_guid" => $group->guid, "limit" => "1"));
			$topics = elgg_get_entities(array("type" => "object", "subtype" => "groupforumtopic", "container_guid" => $group->guid, "limit" => ""));
			
			if($topics && empty($forums)){
				$forum_upgrade = true;
			}
		}
		if($forum_upgrade == true){
			$ts = time();
			$token = generate_action_token($ts);
			echo elgg_echo('groups:forum:upgrade:instructions') . "<br>";
			echo "<a href='{$vars['url']}action/groups/setupforums?&__elgg_token=$token&__elgg_ts=$ts'>" . elgg_echo('groups:forum:run:upgrade') . "</a>";
			
		}
		
	?>

</div>




<script>
$("#load_groups").click(function(){
$("#load_groups").addClass("selected");
$("#load_forum").removeClass("selected");
$("#load_checks").removeClass("selected");
$("#admin_checks").hide();
$("#admin_forum").hide();
$("#admin_groups").fadeIn();
});
$("#load_forum").click(function(){
$("#load_forum").addClass("selected");
$("#load_groups").removeClass("selected");
$("#load_checks").removeClass("selected");
$("#admin_groups").hide();
$("#admin_checks").hide();
$("#admin_forum").fadeIn();
});
$("#load_checks").click(function(){
$("#load_checks").addClass("selected");
$("#load_forum").removeClass("selected");
$("#load_groups").removeClass("selected");
$("#admin_groups").hide();
$("#admin_forum").hide();
$("#admin_checks").fadeIn();
});




</script>