<?php
	echo $vars['url'] . "mod/groups/graphics/defaultlarge.gif";
?>