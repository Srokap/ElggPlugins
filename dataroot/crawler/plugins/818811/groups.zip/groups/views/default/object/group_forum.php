<?php

$title = htmlentities($vars['entity']->title, ENT_QUOTES, 'UTF-8');
$group = get_entity($vars['entity']->container_guid);

// Deal with topics and posts
$topics = elgg_get_entities_from_relationship(array("relationship" => "forum_topic", "relationship_guid" => $vars['entity']->guid, "inverse_relationship" => false, "type" => "object", "subtype" => "groupforumtopic", "limit" => ""));
$topic_counter = count($topics);
if(empty($topics)){$topic_counter = 0;}
$post_counter = 0;
foreach($topics as $topic){
	$posts = $topic->countAnnotations('group_topic_post');
	$post_counter += $posts;
}

if(!empty($topics)){
	$last_post = $topics[0]->getAnnotations("group_topic_post", 1, 0, "desc");
	$last_poster = get_entity($last_post[0]->owner_guid);
	$friendlytime = elgg_view_friendly_time($last_post[0]->time_created);
}
// Deal with icon
if(!empty($topics)){
	if($last_post[0]->time_created > $user->last_login){
		$forum_icon = "<img style='width:35px;height:35px;' src='{$vars['url']}mod/groups/graphics/forum_new.png'>";
	}else{
		$forum_icon = "<img style='width:35px;height:35px;' src='{$vars['url']}mod/groups/graphics/forum_old.png'>";
	}
}else{
	$forum_icon = "<img style='width:35px;height:35px;' src='{$vars['url']}mod/groups/graphics/forum_old.png'>";
}




if (get_context() == "search") {
	// Listing section
	echo "<div class='group_forum_listing' id='group_form_list_{$vars['entity']->guid}'>";	
	// Show forum icon on left
	echo "<div class='forum_listing_icon'>{$forum_icon}</div>";
	// Show forum information on right
	echo "<div class='forum_listing_content'>";
		echo "<h3><a href='{$vars['entity']->getURL()}'>{$title}</a></h3><em>{$vars['entity']->description}</em><br>";
		echo elgg_echo('group:forum:topics') . "{$topic_counter}&nbsp;". elgg_echo('group:forum:posts') ."{$post_counter}";
		echo "</div>";
		echo "<div class='forum_listing_latest_holder'>";
			echo "<h4>" . elgg_echo('groups:forum:latest:post') . "</h4>";
			if($post_counter > 0){
				echo "<a href='{$topics[0]->getURL()}'>{$topics[0]->title}</a><br>";
				echo "by: <a href='{$last_poster->getURL()}'>{$last_poster->name}</a><br>";
				echo "<em>{$friendlytime}</em>";
			}
		echo "</div>";
		echo "<div class='clearfloat'></div>";
		echo "<span style='float:right;' class='control_features'>";
		echo "<a style='cursor:pointer;' onclick='delete_forum({$vars['entity']->guid});'>[Delete]</a>";
		echo "<a style='cursor:pointer;' id='forum_edit_link_{$vars['entity']->guid}'>[Edit]</a>";
		echo "</span><br>";
		echo "<div id='edit_forum_form_{$vars['entity']->guid}' style='display:none;'>";
			echo "<input type='text' size='40' id='forum_name{$vars['entity']->guid}' class='tipclass' title='Forum Name' value='{$title}' onfocus=\"this.value='';\" /><br>";
			echo "<input type='text' size='85' id='forum_desc{$vars['entity']->guid}' class='tipclass' title='Description' value='{$vars['entity']->description}' onfocus=\"this.value='';\" /><br>";
			echo "<b>Forum Access:</b> <select id='forum_access{$vars['entity']->guid}'><option value='all'>Group Members</option><option value='admins'>Group Managers</option></select><br>";
			echo "<input type='hidden' id='group_guid' value='{$vars['group_guid']}' />";
			echo "<a id='edit_forum_link' class='submit_button' onclick='edit_forum({$vars['entity']->guid});'>".elgg_echo("save")."</a><br><br>";
		echo "</div>";
	echo "</div>";
}else{
	echo "NOT THE LISTING VIEW";
	
	
}

?>

<script>
	$('#forum_edit_link_<?php echo $vars['entity']->guid;?>').click(function(){
		$('#edit_forum_form_<?php echo $vars['entity']->guid;?>').slideToggle();
	});
</script>