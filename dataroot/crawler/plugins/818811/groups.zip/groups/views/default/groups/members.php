<?php
	/**
	 * Elgg groups items view.
	 * This is the messageboard, members, pages and latest forums posts. Each plugin will extend the views
	 * 
	 * @package ElggGroups
	 */
	 
?>

<div id="group_members">
<?php

    $members = $vars['entity']->getMembers();
    foreach($members as $mem){
	    
	if(is_plugin_enabled('group_multiple_admin')){
		$is_admin = check_entity_relationship($mem->guid, 'group_admin', $vars['entity']->guid);
		if($is_admin){
			$icon =  elgg_view("profile/icon",array('entity' => $mem, 'size' => 'small'));
	        echo "<div class='groups_member_wrapper_owner'>";
			echo $icon;
			$name = elgg_get_excerpt($mem->name, 8);
			echo $name;
			echo "</div>";
		}else{
			$icon =  elgg_view("profile/icon",array('entity' => $mem, 'size' => 'small'));
			echo "<div class='groups_member_wrapper'>";
			echo $icon;
			$name = elgg_get_excerpt($mem->name, 8);
			echo $name;
			echo "</div>";
		}
	}else{
        if($mem->guid == $vars['entity']->owner_guid){
	        $icon =  elgg_view("profile/icon",array('entity' => $mem, 'size' => 'small'));
	        echo "<div class='groups_member_wrapper_owner'>";
			echo $icon;
			$name = elgg_get_excerpt($mem->name, 8);
			echo $name;
			echo "</div>";
        }else{
			$icon =  elgg_view("profile/icon",array('entity' => $mem, 'size' => 'small'));
			echo "<div class='groups_member_wrapper'>";
			echo $icon;
			$name = elgg_get_excerpt($mem->name, 8);
			echo $name;
			echo "</div>";
        }
		
           
    }
}

	echo "<div class=\"clearfloat\"></div>";
	$more_url = "{$vars['url']}pg/groups/memberlist/{$vars['entity']->guid}/";
	echo "<div id=\"groups_member_link\"><a href=\"{$more_url}\">" . elgg_echo('groups:members:more') . "</a></div>";

?>
<div class="clearfloat"></div>
</div>