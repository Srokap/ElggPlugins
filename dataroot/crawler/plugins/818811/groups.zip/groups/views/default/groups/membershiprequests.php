<div class="contentWrapper">

<?php
$icon = "<img style='width:200px;height:200px;' src='{$vars['url']}mod/groups/graphics/green_arrow_up.png'>";

echo "<div class=\"contentWrapper\">";
echo "<center><div style='width:700px;'>";
echo "<div style='float:left;margin-right:20px;width:220px'>";
echo $icon;
echo "</div><div style='float:left;width:350px;padding:5px;'>";
echo elgg_echo('groups:requests:explain');
echo "</div></div>";
echo "<div class='clearfloat'></div>";
echo "<br><br>";
echo "<a class='submit_button' href='{$vars['url']}pg/groups/invite/{$vars['entity']->guid}'>" . elgg_echo('friends:invite') . "</a></center>";	
echo "<br><br></div>";

	if (!empty($vars['requests']) && is_array($vars['requests'])) {

		foreach($vars['requests'] as $request)
			if ($request instanceof ElggUser) {

?>
	<div class="reportedcontent_content active_report">
		<div class="groups_membershiprequest_buttons">
			<?php
				echo "<div class=\"member_icon\"><a href=\"" . $request->getURL() . "\">";
				echo elgg_view("profile/icon", array(
					'entity' => $request,
					'size' => 'small',
					'override' => 'true'
				));
				echo "</a></div>{$request->name}<br />";

				echo str_replace('<a', '<a class="delete_report_button" ', elgg_view('output/confirmlink',array(
					'href' => $vars['url'] . 'action/groups/killrequest?user_guid='.$request->guid.'&group_guid=' . $vars['entity']->guid,
					'confirm' => elgg_echo('groups:joinrequest:remove:check'),
					'text' => elgg_echo('delete'),
				)));
			$url = elgg_add_action_tokens_to_url("{$vars['url']}action/groups/addtogroup?user_guid={$request->guid}&group_guid={$vars['entity']->guid}");
			?>
			<a href="<?php echo $url; ?>" class="archive_report_button"><?php echo elgg_echo('accept'); ?></a>
			<br /><br />
		</div>
	</div>
<?php

			}

	} else {

		echo "<p>" . elgg_echo('groups:requests:none') . "</p>";

	}

	
echo "<br><h3 class='sectiontitleheader'>" . elgg_echo('groups:friends:notin') . "</h3>";
$user = get_loggedin_user();
$friends = $user->getFriends('',0);
$members = $vars['entity']->getMembers();
$suggested = array();
$count = count($suggested);
foreach($friends as $friend){
	$in = check_entity_relationship($friend->guid, 'member', $vars['entity']->guid);
	if($in == FALSE){
		array_push($suggested,$friend);
		$count++;
		if($count > 9){
			break;
		}
	}
}
shuffle($friends);
set_context("search");
echo elgg_view_entity_list($suggested,0,0,10,FALSE,FALSE,FALSE);
	
?>
</div>
