<?php
	/**
	 * Elgg groups plugin full profile view.
	 *
	 * @package ElggGroups
	 */

	if ($vars['full'] == true) {
		$iconsize = "large";
	} else {
		$iconsize = "medium";
	}
	if ($vars['entity']->canEdit()){
	$edit = "<a id='group_edit_link' href='{$vars['url']}pg/groups/edit/{$vars['entity']->getGUID()}'><img title='Edit' style='width:12px;height:12px;' src='{$vars['url']}mod/toolbar/graphics/edit.png'></a>";
	}
	$user_id = get_loggedin_userid();
	$owner = get_entity($vars['entity']->owner_guid);
	$ts = time();
	$token = generate_action_token($ts);
?>
<div id="groups_profile_holder" style='padding:5px;'>

<?php
	if (get_plugin_setting('announcements', 'groups') == 'yes'){
		echo "<div class='scribe_correction_toggle' id='announcement_box' style='text-align:left;'>";
			$group_announcement = elgg_get_entities(array('types' => 'object', 'subtypes' => 'group_announcement', 'container_guid' => $vars['entity']->guid,'limit' => 1));
			if ($group_announcement) {
				$mes = $group_announcement[0];
				$message = $mes->description;
				$dateStamp = elgg_view_friendly_time($mes->time_created);
				echo "<span id='announcement_holder'>{$message}</span>";
			}
			if($user_id == $owner->guid){
				echo "<a id='new_announce_link' style='cursor:pointer;'>Update</a><br>";
				echo "<div id='add_announce_box' style='display:none;'>";
					echo elgg_view('input/longtext', array('internalname' => 'group_announcement', 'internalid' => 'group_announcement', 'value' => ''));
					echo "<a class='submit_button' onclick='update_announcement();'>Save</a><br>";
				echo "</div>";
			}
		echo "</div>";
	}
?>

<div id="groups_info_column_left" style="float:right;"><!-- start of groups_info_column_left -->



	<div id="elgg_horizontal_tabbed_nav">
		<ul>
	<li><a class="selected" style="cursor:pointer;" id="load_info"><?php echo elgg_echo('groups:info'); ?></a></li>
<?php 
	if (get_plugin_setting('rules', 'groups') == 'yes'){?>
	<li><a style="cursor:pointer;" id="load_rules"><?php echo elgg_echo('groups:rules'); ?></a></li>
	<?php } ?>
	<li><a style="cursor:pointer;" id="load_members"><?php echo elgg_echo('groups:members'); ?></a></li>
	<li><a style="cursor:pointer;" id="load_river"><?php echo elgg_echo('groups:river'); ?></a></li>
		</ul>
		
	</div>
	
<div id="groups_box">
	
	<div id="groups_info">
		<?php
		if(is_plugin_enabled('profile_manager')){
			 
		        if ($vars['full'] == true) {
		            $group_fields = profile_manager_get_categorized_group_fields();
		            
		            if(count($group_fields["fields"]) > 0){
		                $group_fields = $group_fields["fields"];
		                
		                foreach($group_fields as $field) {
		                    $metadata_name = $field->metadata_name;
		                    $value = $vars['entity']->$metadata_name;
		                    if($value){            
		                        // make title
		                        $title = $field->getTitle();
		                        
		                        // adjust output type
		                        if($field->output_as_tags == "yes"){
		                            $output_type = "tags";
		                        } else {
		                            $output_type = $field->metadata_type;
		                        }
		                        
		                        if($field->metadata_type == "url"){
		                            $target = "_blank";
		                        } else {
		                            $target = null;
		                        }
		                        
		                        //This function controls the alternating class
		                        $even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
		                        
		                        echo "<p class=\"{$even_odd}\">";
		                        echo "<b>" . $title . ": </b>";
		                        echo elgg_view("output/" . $output_type, array('value' => $value, "target" => $target));
		                        echo "</p>";
		                    }
		                }
		            }
		        }
    
		}else{
			if ($vars['full'] == true) {
			if (is_array($vars['config']->group) && sizeof($vars['config']->group) > 0){

				foreach($vars['config']->group as $shortname => $valtype) {
					if ($shortname != "name") {
						$value = $vars['entity']->$shortname;

						if (!empty($value)) {
							//This function controls the alternating class
							$even_odd = ( 'odd' != $even_odd ) ? 'odd' : 'even';
						}

						echo "<p class=\"{$even_odd}\">";
						echo "<b>";
						echo elgg_echo("groups:{$shortname}");
						echo ": </b>";

						$options = array(
							'value' => $vars['entity']->$shortname
						);

						if ($valtype == 'tags') {
							$options['tag_names'] = $shortname;
						}

						echo elgg_view("output/{$valtype}", $options);

						echo "</p>";
					}
				}
			}
		}
	}
		?>
	</div>
		
	<div class="hidden_groups_box" id="groups_rules">
	<?php
		echo "<div id='rules_holder'>";
		$rules = $vars['entity']->rules;
			echo $rules;
			echo "<br><br>";
		echo "</div>";
		if(($user_id = $vars['entity']->owner_guid) || (isadminloggedin())){
			echo "<a style='cursor:pointer;' id='rules_write'>" . elgg_echo('groups:rules:add') . "</a>";
			echo "<div style='display:none;' id='rules_adder'>";
				echo elgg_view('input/longtext', array('internalname' => 'rules', 'internalid' => 'rules', 'value' => ''));
				echo "<a class='submit_button' onclick='update_rules();'>Save</a><br>";
			echo "</div>";
		}
	
	?>
	</div>
	<div class="hidden_groups_box" id="groups_members">
		<?php
			echo elgg_view('groups/members', array('entity' => $vars['entity']));
		?>
	</div>
	<div class="hidden_groups_box" id="groups_river">
	<?php
		$pagination = false; // also should be customizable
		if ($pagination) { ?>
				<style type="text/css">
					.river_pagination { display: inline; }
				</style>
	?>
	<?php
		}
		
		$owner = page_owner_entity();
		$group_guid = $owner->guid;
		$limit = 10;  // TODO: make configurable

		$offset = (int) get_input('offset', 0);

		// Sanitise variables -- future proof in case they get sourced elsewhere
		$limit = (int) $limit;
		$offset = (int) $offset;
		$group_guid = (int) $group_guid;

		$sql = "SELECT {$CONFIG->dbprefix}river.id, {$CONFIG->dbprefix}river.type, {$CONFIG->dbprefix}river.subtype, {$CONFIG->dbprefix}river.action_type, {$CONFIG->dbprefix}river.access_id, {$CONFIG->dbprefix}river.view, {$CONFIG->dbprefix}river.subject_guid, {$CONFIG->dbprefix}river.object_guid, {$CONFIG->dbprefix}river.posted FROM {$CONFIG->dbprefix}river INNER JOIN {$CONFIG->dbprefix}entities AS entities1 ON {$CONFIG->dbprefix}river.object_guid = entities1.guid INNER JOIN {$CONFIG->dbprefix}entities AS entities2 ON entities1.container_guid = entities2.guid WHERE entities2.guid = $group_guid OR {$CONFIG->dbprefix}river.object_guid = $group_guid ORDER BY posted DESC limit {$offset},{$limit}";

		$items = get_data($sql);

        if (count($items) > 0) {
			if ($pagination) {
				$group_river = array_slice($items, $offset);
			}
			$river_items = elgg_view('river/item/list',array(
												'limit' => $limit,
												'offset' => $offset,
												'items' => $items,
												'pagination' => $pagination
											));
		}
		echo $river_items;
		?>
	</div>
	
	</div><!-- end of groups_box -->
</div><!-- end of groups_info_column_left -->

<div id="groups_info_column_right"><!-- start of groups_info_column_right -->
	<div id="groups_icon_wrapper"><!-- start of groups_icon_wrapper -->

		<?php
			echo elgg_view(
					"groups/icon", array(
												'entity' => $vars['entity'],
												//'align' => "left",
												'size' => $iconsize,
											)
					);
		?>

	</div><!-- end of groups_icon_wrapper -->
	<div id="group_stats"><!-- start of group_stats -->
		<?php

			echo "<p><b>" . elgg_echo("groups:owner") . ": </b><a href=\"" . get_user($vars['entity']->owner_guid)->getURL() . "\">" . get_user($vars['entity']->owner_guid)->name . "</a></p>";
			$forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "container_guid" => $vars['entity']->guid, "limit" => "", "count" => TRUE));
			$topics = elgg_get_entities(array("type" => "object", "subtype" => "groupforumtopic", "container_guid" => $vars['entity']->guid, "limit" => "", "count" => TRUE));
			$requests = elgg_get_entities_from_relationship(array('relationship' => 'membership_request', 'relationship_guid' => $vars['entity']->guid, 'inverse_relationship' => TRUE, 'limit' => 9999));
		?>
		<p><b><?php echo elgg_echo('groups:members') . ": </b>" . $vars['entity']->getMembers(0, 0, TRUE); 
			if(($user_id == $owner->guid) && ($requests !== FALSE)){
				$requestcount = count($requests);
				echo " (<a class='tipclass' title='Membership Requests' href='{$vars['url']}mod/groups/membershireq.php?group_guid={$vars['entity']->guid}'>{$requestcount}</a>)";
			}
		?></p>
		<p><?php echo elgg_echo('groups:forums') . $forums; ?></p>
		<p><?php echo elgg_echo('group:forum:topics') . $topics; ?></p>
		
	</div><!-- end of group_stats -->
</div><!-- end of groups_info_column_right -->

</div>
<div class="clearfloat"></div>


<script>
$("#load_rules").click(function(){
$("#load_rules").addClass("selected");
$("#load_members").removeClass("selected");
$("#load_river").removeClass("selected");
$("#load_info").removeClass("selected");
$("#groups_info").hide();
$("#groups_members").hide();
$("#groups_river").hide();
$("#groups_rules").fadeIn();
});
$("#load_members").click(function(){
$("#load_members").addClass("selected");
$("#load_rules").removeClass("selected");
$("#load_river").removeClass("selected");
$("#load_info").removeClass("selected");
$("#groups_info").hide();
$("#groups_rules").hide();
$("#groups_river").hide();
$("#groups_members").fadeIn();
});
$("#load_river").click(function(){
$("#load_river").addClass("selected");
$("#load_rules").removeClass("selected");
$("#load_members").removeClass("selected");
$("#load_info").removeClass("selected");	
$("#groups_info").hide();
$("#groups_members").hide();
$("#groups_rules").hide();
$("#groups_river").fadeIn();
});
$("#load_info").click(function(){
$("#load_info").addClass("selected");
$("#load_rules").removeClass("selected");
$("#load_members").removeClass("selected");
$("#load_river").removeClass("selected");	
$("#groups_rules").hide();
$("#groups_members").hide();
$("#groups_river").hide();
$("#groups_info").fadeIn();
});

$("#rules_write").click(function(){
$("#rules_adder").slideToggle();
$("#rules_holder").slideToggle();
});

$("#new_announce_link").click(function(){
	$("#add_announce_box").slideToggle();
});


$.ajaxSetup ({
	cache: false
});
	
var token = "<?php echo $token; ?>";
var ts = "<?php echo $ts; ?>";
var loader = "<img id='ajax_loader' style='width:25px;height:25px;margin:5px 5px 5px 0;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";


function update_announcement(){
	var announcement = tinyMCE.get('group_announcement').getContent();
	var container_guid = "<?php echo $vars['entity']->guid;?>";
	datastr = "&group_announcement=" + announcement;
	datastr += "&container_guid=" + container_guid;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$("#add_announce_box").slideToggle();
	$("#announcement_box").append(loader);
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/groups/add_group_announcement",
		data: datastr,
		success: function(msg){
			$("#ajax_loader").remove();
			$("#announcement_holder").empty();
			$("#announcement_holder").append(msg);
		}
	});
}

function update_rules(){
	var rules = tinyMCE.get('rules').getContent();
	var group_guid = "<?php echo $vars['entity']->guid;?>";
	datastr = "&rules=" + rules;
	datastr += "&group_guid=" + group_guid;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$("#rules_adder").slideToggle();
	$("#rules_holder").slideToggle();
	$("#rules_holder").append(loader);
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/groups/add_rules",
		data: datastr,
		success: function(msg){
			$("#ajax_loader").remove();
			$("#rules_holder").empty();
			$("#rules_holder").append(msg);
		}
	});
}

</script>