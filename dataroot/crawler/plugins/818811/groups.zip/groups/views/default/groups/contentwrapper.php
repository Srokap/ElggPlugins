<div class='contentWrapper groups'><?php

	echo $vars['body'];

?></div>