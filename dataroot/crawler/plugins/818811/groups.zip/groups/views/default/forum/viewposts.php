<?php

    /**
	 * Elgg groups plugin display topic posts
	 * 
	 * @package ElggGroups
	 */
	
	 $group = get_entity($vars['entity']->container_guid);
	 $group_name = $group->name;
	 $owner = $group->getOwnerEntity();
	 $loggedin = get_loggedin_user();
	 $forum = get_entity($vars['forum_guid']);
	 $groups_forums = elgg_get_entities(array("type" => "object", "subtype" => "group_forum", "container_guid" => $vars['entity']->container_guid, "limit" => ""));

?>

<div id="topic_posts"><!-- open the topic_posts div -->
<h2><?php echo $vars['entity']->title; ?></h2>
<div id="pages_breadcrumbs"><b><a href="<?php echo $vars['url']; ?>pg/groups/<?php echo $vars['entity']->container_guid; ?>/"><?php echo $group_name; ?></a> > <a href="<?php echo $vars['url']; ?>pg/groups/discussion/<?php echo $vars['entity']->container_guid; ?>/"><?php echo elgg_echo("groups:forum"); ?></a> > <a id='current_forum' value='<?php echo $forum->guid;?>' href="<?php echo $forum->getURL(); ?>/"><?php echo $forum->title; ?></a></b> > <?php echo $vars['entity']->title; ?></div>
   <!-- grab the topic title -->
        <div id="content_area_group_title">
        	<br>
        	<?php
        		$ts = time();
				$token = generate_action_token($ts);
			   		echo "<div class='scribe_correction_toggle' id='forum_options_bar' style='text-align:right;padding:8px;'>";
		   		if($loggedin->guid == $owner->guid){  		
			   		if($vars['entity']->status !== "closed"){
				   		$topic_status = "close";
				   		echo "<a class='submit_button' id='close_topic' onclick='open_close_topic();'>" . elgg_echo('groups:forum:close') . "</a>";
					}elseif($vars['entity']->status == "closed"){
						$topic_status = "open";
				   		echo "<a class='submit_button' id='open_topic' onclick='open_close_topic();'>" . elgg_echo('groups:forum:open') . "</a>";
					}
					if($vars['entity']->sticky !== "yes"){
						$sticky = "stick";
				   		echo " <a class='submit_button' id='stick_topic' onclick='stick_topic();'>" . elgg_echo('groups:forum:stick') . "</a>";
					}elseif($vars['entity']->sticky == "yes"){
						$sticky = "unstick";
				   		echo " <a class='submit_button' id='unstick_topic' onclick='stick_topic();'>" . elgg_echo('groups:forum:unstick') . "</a>";
					}
					// Move topic to a different forum
			   		echo " <a class='submit_button' id='move_forum_link'>" . elgg_echo('groups:forum:move') . "</a>";
				}
				echo " <b>Go To:</b> <select id='forum_locater'>";
		   		echo "<option value='null'>-Select-</option>";
   				foreach($groups_forums as $a_forum){
			   		echo "<option value='{$a_forum->getURL()}'>{$a_forum->title}</option>";
		   		}
		   		echo "</select>";
				echo "</div>";	
				
				// Move to forum box
				echo "<div id='move_forum_box' style='display:none;'>";	
				echo elgg_echo('groups:forum:move:choice');
				echo "<select id='forum_chooser'>";
				foreach($groups_forums as $b_forum){
					if($b_forum->guid == $vars['forum_guid']){
					}else{
			   			echo "<option value='{$b_forum->guid}'>{$b_forum->title}</option>";
		   			}
		   		}
		   		echo "</select>&nbsp;";
				echo "<input type='hidden' id='topic_guid' value='{$vars['entity']->guid}' />";
		   		echo "<a class='submit_button' onclick='move_to_forum();'>Save</a>";
				echo "</div><br>"; 			
		   	?>
		   
        </div>
<?php
    //display follow up comments
    $count = $vars['entity']->countAnnotations('group_topic_post');
    $offset = (int) get_input('offset',0);
    $limit = get_plugin_setting('postsperpage', 'groups');
    
    $baseurl = $vars['entity']->getURL();
    echo elgg_view('navigation/pagination',array(
    												'limit' => $limit,
    												'offset' => $offset,
    												'baseurl' => $baseurl,
    												'count' => $count,
    											));


    $count = 0;										
    foreach($vars['entity']->getAnnotations('group_topic_post', $limit, $offset, "asc") as $post) {
	    	$count++; 
	     echo elgg_view("forum/topicposts",array('entity' => $post,'number' => $count));
		
	}
	 echo "<div id='topic_post_holder_box'></div>";
	
	?>
	
	<?php
		
	echo elgg_view('navigation/pagination',array(
    												'limit' => $limit,
    												'offset' => $offset,
    												'baseurl' => $baseurl,
    												'count' => $count,
    											));
 	echo "<br>";
    											
    											
	// check to find out the status of the topic and act
    if($vars['entity']->status != "closed" && page_owner_entity()->isMember($vars['user'])){
        
        //display the add comment form, this will appear after all the existing comments
        echo "<div id='topic_comment_box'>";
	    echo elgg_view("forms/forums/addpost", array('entity' => $vars['entity']));
	    echo "</div>";
	    
	    echo "<div id='topic_comment_closed' style='display:none;'>";
        echo "<h2>" . elgg_echo("groups:topicisclosed") . "</h2>";
        echo "<p>" . elgg_echo("groups:topiccloseddesc") . "</p>";
        echo "</div>";
    } elseif($vars['entity']->status == "closed" && page_owner_entity()->isMember($vars['user'])) {
        
	    echo "<div id='topic_comment_box' style='display:none;'>";
	    echo elgg_view("forms/forums/addpost", array('entity' => $vars['entity']));
	    echo "</div>";
	    
        //this topic has been closed by the owner
        echo "<div id='topic_comment_closed'>";
        echo "<h2>" . elgg_echo("groups:topicisclosed") . "</h2>";
        echo "<p>" . elgg_echo("groups:topiccloseddesc") . "</p>";
        echo "</div>";
    } elseif($vars['entity']->status == "closed") {
	    
	    //this topic has been closed by the owner
        echo "<div id='topic_comment_closed'>";
        echo "<h2>" . elgg_echo("groups:topicisclosed") . "</h2>";
        echo "<p>" . elgg_echo("groups:topiccloseddesc") . "</p>";
        echo "</div>";
        
    } else {
    }

?>
</div>

<script type="text/javascript">

	$("#move_forum_link").click(function(){
		$("#move_forum_box").slideToggle();	
	});

$.ajaxSetup ({
	cache: false
	});
	
	var token = "<?php echo $token; ?>";
	var ts = "<?php echo $ts; ?>";
	var loader = "<img id='ajax_loader' style='width:25px;height:25px;margin:5px 5px 5px 0;' src='<?php echo $vars['url'];?>mod/embed/images/loading.gif'>";
	var this_user = "<?php echo $vars['entity']->owner_guid;?>";
	var topic = "<?php echo $vars['entity']->guid;?>";
	var topic_status = "<?php echo $topic_status;?>";
	var sticky = "<?php echo $sticky;?>";
	var group_guid = "<?php echo $vars['entity']->container_guid;?>";
	
function new_sig(id){
		var the_user_guid = $("#user_id_"+id).attr('value');
		var group_guid = $("#group_guid").attr('value');
		var signature = $("#new_sig_"+id).attr('value');
		datastr = "&user_guid=" + the_user_guid;
		datastr += "&group_guid=" + group_guid;
		datastr += "&signature=" + signature;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#edit_loader"+id).show();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/addsignature",
			data: datastr,
			success: function(msg){
				$("#edit_loader"+id).hide();
					$(".the_sig_"+the_user_guid).empty();
					$(".the_sig_"+the_user_guid).append(msg);
					$("#sig_edit_box_"+id).slideToggle();
					$("#new_sig_"+id).val(msg);
			}
		});
}

function new_status(id){
		var the_user_guid = $("#user_id_"+id).attr('value');
		var group_guid = $("#group_guid").attr('value');
		var newstatus = $("#status_text_"+id).attr('value');
		datastr = "&user_guid=" + the_user_guid;
		datastr += "&group_guid=" + group_guid;
		datastr += "&status_text=" + newstatus;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#edit_loader"+id).show();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/add_status",
			data: datastr,
			success: function(msg){
				$("#edit_loader"+id).hide();
					$(".the_status_"+the_user_guid).empty();
					$(".the_status_"+the_user_guid).append(msg);
					$("#edit_user_box_"+id).slideToggle();
					$("#status_text_"+id).val(msg);
			}
		});
}

function delete_discussion_post(id){
		var group_guid = $("#group_guid").attr('value');
		var topic = "<?php echo $vars['entity']->guid;?>";
		datastr = "&post=" + id;
		datastr += "&group=" + group_guid;
		datastr += "&topic=" + topic;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#edit_loader"+id).show();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/deletepost",
			data: datastr,
			success: function(msg){
				$("#edit_loader"+id).hide();
					$("#topic_post_"+id).slideToggle(function(){
						$("#topic_post_"+id).remove();
						$(".user_post_count_"+this_user).empty();
						$(".user_post_count_"+this_user).append(msg);
					});
			}
		});
}

function edit_this_post(id){
		var postComment = tinyMCE.get('postComment'+id).getContent();
		var group_guid = $("#group_guid").attr('value');
		datastr = "&post=" + id;
		datastr += "&group=" + group_guid;
		datastr += "&postComment=" + postComment;
		datastr += "&__elgg_token=" + token;
		datastr += "&__elgg_ts=" + ts;
		$("#edit_loader"+id).show();
		$.ajax({
			type: "POST",
			url: "<?php echo $vars['url']; ?>action/groups/editpost",
			data: datastr,
			success: function(msg){
				$("#edit_loader"+id).hide(function(){
					$("#post_holder_"+id).delay(1000).empty();
					$("#post_holder_"+id).append(msg);
					$("#edit_post_box_"+id).hide();
					
				});
					
			}
		});
}

function stick_topic(){
	datastr = "&topic=" + topic;
	datastr += "&style=" + sticky;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$("#forum_options_bar").append(loader);
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/groups/stick",
		data: datastr,
		success: function(msg){
				if(sticky == "stick"){
					$("#stick_topic").replaceWith(msg);
					sticky = "unstick";
				}else if(sticky == "unstick"){
					$("#unstick_topic").replaceWith(msg);
					sticky = "stick";
				}
			$("#ajax_loader").remove();
		}
	});	
}
function open_close_topic(){
	datastr = "&topic=" + topic;
	datastr += "&style=" + topic_status;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$("#forum_options_bar").append(loader);
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/groups/closetopic",
		data: datastr,
		success: function(msg){
				if(topic_status == "close"){
					$("#close_topic").replaceWith(msg);
					$("#topic_comment_box").hide();
					$("#topic_comment_closed").fadeIn();
					topic_status = "open";
				}else if(topic_status == "open"){
					$("#open_topic").replaceWith(msg);
					$("#topic_comment_closed").hide();
					$("#topic_comment_box").fadeIn();
					topic_status = "close";
				}
			$("#ajax_loader").remove();
		}
	});	
}

function move_to_forum(){
	var new_forum = $("#forum_chooser").attr('value');
	var old_forum = $("#current_forum").attr('value');
	datastr = "&topic_guid=" + topic;
	datastr += "&old_forum=" + old_forum;
	datastr += "&forum_guid=" + new_forum;
	datastr += "&__elgg_token=" + token;
	datastr += "&__elgg_ts=" + ts;
	$("#forum_options_bar").append(loader);
	$("#move_forum_box").slideToggle();
	$.ajax({
		type: "POST",
		url: "<?php echo $vars['url']; ?>action/groups/movetoforum",
		data: datastr,
		success: function(msg){
				$("#ajax_loader").remove();
				$("#move_forum_box").replaceWith(msg);
		}
	});	
}
</script>
