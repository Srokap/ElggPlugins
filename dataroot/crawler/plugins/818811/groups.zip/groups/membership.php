<?php

	/**
	 * Elgg groups 'member of' page
	 * 
	 * @package ElggGroups
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	
	gatekeeper();
	group_gatekeeper();
	
	$limit = get_input("limit", 10);
	$offset = get_input("offset", 0);
	
	if (page_owner() == $_SESSION['user']->guid) {
		$title = elgg_echo("groups:yours");
		$title1 = elgg_view_title($title);
	} else $title = sprintf(elgg_echo("groups:owned"),page_owner_entity()->name);
		$title1 = elgg_view_title($title);
	// Get objects
	$area2 = "<h2>" . $title . "</h2><br>";
	
	set_context('search');
	// offset is grabbed in the list_entities_from_relationship() function
	$objects = list_entities_from_relationship('member',page_owner(),false,'group','',0, $limit,false, false);
	set_context('groups');
	
	$area2 .= $objects;
	$body = elgg_view_layout('two_column_right_sidebar',$area1, $area2);
	
	// Finally draw the page
	page_draw($title, $body);
?>