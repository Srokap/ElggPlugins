<?php
	/**
	 * Invite users to groups
	 * 
	 * @package ElggGroups
	 */

	require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	gatekeeper();
	
	$group_guid = (int) get_input('group_guid');
	$group = get_entity($group_guid);
	set_page_owner($group_guid);

	$title = elgg_echo("groups:invite");

	$title1 = elgg_view_title($title);
	
	$area2 = "<h2>" . $title . "</h2><br>";
	
	if (($group) && ($group->canEdit()))
	{	
		$area2 .= elgg_view("forms/groups/invite", array('entity' => $group));
			 
	} else {
		$area2 .= elgg_echo("groups:noaccess");
	}
	$area3 = elgg_view('learning_tools/area3');
	$area4 = elgg_view('learning_tools/area4');
	$body = elgg_view_layout('two_column_right_sidebar', $area1, $area2,$area3,$area4);
	
	page_draw($title, $body);
?>