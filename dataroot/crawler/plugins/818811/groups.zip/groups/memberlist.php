<?php

include_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

$group_guid = (int) get_input('group_guid');
$group = get_entity($group_guid);
set_page_owner($group_guid);

$user = get_loggedin_user();

$title = sprintf(elgg_echo('groups:membersof'), $group->name);

$title1 = elgg_view_title(elgg_echo('groups:memberlist'));

$area2 = "<h2>" . $title . "</h2><br>";
$area2 .= elgg_view("groups/memberlist", array('entity' => $group));
$area3 = elgg_view('learning_tools/area3');
$body = elgg_view_layout('two_column_right_sidebar', '', $area2,$area3);

page_draw($title, $body);
