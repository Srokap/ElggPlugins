<?php
	/**
	 * Elgg groups plugin
	 * 
	 * @package ElggGroups
	 */

	gatekeeper();

	set_page_owner(get_loggedin_userid());

	// Render the file upload page
	$title = elgg_view_title(elgg_echo("groups:new"));
	$title1 = elgg_echo('groups:new');
	$area2 = "<h2>" . $title1 . "</h2><br>";
	$area2 .= elgg_view("forms/groups/edit");
	$area3 = elgg_view('learning_tools/area3');

	
	$body = elgg_view_layout('two_column_right_sidebar', $area1, $area2,$area3);
	
	page_draw($title, $body);
?>