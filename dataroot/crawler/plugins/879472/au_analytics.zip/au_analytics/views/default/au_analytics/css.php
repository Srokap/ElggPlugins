.au_analytics_formelement {
  display: inline-block;
  margin: 10px;
  vertical-align: top;
}

.au_analytics_formelement select {
  min-width: 120px;
}