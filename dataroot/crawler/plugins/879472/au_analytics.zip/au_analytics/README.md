au_analytics
============

Provides graphical analysis of Elgg content

Plugin should reside in mod/au_analytics