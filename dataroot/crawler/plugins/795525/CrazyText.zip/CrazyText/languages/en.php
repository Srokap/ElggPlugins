<?php

	$english = array(
	
		/**
		 * CrazyText widget
		 */
		
	        
	        'custom:title' => "CrazyText widget",
	        'custom:description' => "Change your title in language file if you like!"
	        
		
	);
					
	add_translation("en",$english);

?>