<?php
  function CrazyText_init() {        
    add_widget_type('CrazyText', elgg_echo("CrazyText"),elgg_echo("CrazyText:description"));
  }
 
  register_elgg_event_handler('init','system','CrazyText_init');       
?>