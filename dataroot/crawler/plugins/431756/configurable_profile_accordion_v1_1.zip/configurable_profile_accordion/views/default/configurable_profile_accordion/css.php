.ui-icon{
    float: left;
}

h3.ui-accordion-header
{
    -webkit-border-radius: 5px; 
    -moz-border-radius: 5px;

    background-color:#cccccc;
    cursor:pointer;   
    margin-top:5px;
    margin-bottom:5px;
    padding:5px; 
}

.ui-accordion-content {
    padding-left:5px;
    padding-right:5px;
}