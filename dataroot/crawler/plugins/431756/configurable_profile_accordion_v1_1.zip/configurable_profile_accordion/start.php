<?php

function configurable_profile_accordion_init()
{
    global $CONFIG;

    extend_view('css', 'configurable_profile_accordion/css');
}

register_elgg_event_handler('init','system','configurable_profile_accordion_init',2);

?>