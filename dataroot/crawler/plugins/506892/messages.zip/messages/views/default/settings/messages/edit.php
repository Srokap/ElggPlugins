<?php
?>
<p>
	<?php echo elgg_echo('messages:enable:privacy'); ?>
	
	<select name="params[enableprivacy]">
		<option value="yes" <?php if ($vars['entity']->enableprivacy == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->enableprivacy != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
	<br /><hr><br />

	<?php echo elgg_echo('messages:messages_refresh_rate'); ?>

      <select name="params[messages_refresh_rate]">
        <option value="10000" <?php if ($vars['entity']->messages_refresh_rate == 10000) echo "selected=\"yes\" "; ?>>10 <?php echo elgg_echo('messages:admin:seconds'); ?></option>
        <option value="20000" <?php if ($vars['entity']->messages_refresh_rate == 20000) echo "selected=\"yes\" "; ?>>20 <?php echo elgg_echo('messages:admin:seconds'); ?></option>
        <option value="30000" <?php if ($vars['entity']->messages_refresh_rate == 30000) echo "selected=\"yes\" "; ?>>30 <?php echo elgg_echo('messages:admin:seconds'); ?></option>
        <option value="45000" <?php if ($vars['entity']->messages_refresh_rate == 45000) echo "selected=\"yes\" "; ?>>45 <?php echo elgg_echo('messages:admin:seconds'); ?></option>
        <option value="60000" <?php if (!$vars['entity']->messages_refresh_rate || $vars['entity']->messages_refresh_rate == 60000) echo "selected=\"yes\" "; ?>>1 <?php echo elgg_echo('messages:admin:minute'); ?></option>
        <option value="120000" <?php if ($vars['entity']->messages_refresh_rate == 120000) echo "selected=\"yes\" "; ?>>2 <?php echo elgg_echo('messages:admin:minutes'); ?></option>
        <option value="180000" <?php if ($vars['entity']->messages_refresh_rate == 180000) echo "selected=\"yes\" "; ?>>3 <?php echo elgg_echo('messages:admin:minutes'); ?></option>
        <option value="240000" <?php if ($vars['entity']->messages_refresh_rate == 240000) echo "selected=\"yes\" "; ?>>4 <?php echo elgg_echo('messages:admin:minutes'); ?></option>
        <option value="300000" <?php if ($vars['entity']->messages_refresh_rate == 300000) echo "selected=\"yes\" "; ?>>5 <?php echo elgg_echo('messages:admin:minutes'); ?></option>
        <option value="600000" <?php if ($vars['entity']->messages_refresh_rate == 600000) echo "selected=\"yes\" "; ?>>10 <?php echo elgg_echo('messages:admin:minutes'); ?></option>
        <option value="1200000" <?php if ($vars['entity']->messages_refresh_rate == 1200000) echo "selected=\"yes\" "; ?>>20 <?php echo elgg_echo('messages:admin:minutes'); ?></option>
        <option value="1800000" <?php if ($vars['entity']->messages_refresh_rate == 1800000) echo "selected=\"yes\" "; ?>>30 <?php echo elgg_echo('messages:admin:minutes'); ?></option>
      </select>	
	
</p>
