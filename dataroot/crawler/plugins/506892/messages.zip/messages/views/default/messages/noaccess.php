<?php

	/**
	 * Elgg messages noaccess view
	 * 
	 * @package ElggMessages
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
	 *
	 */
?>
	<div class="contentWrapper">
		
            <p><label><?php echo elgg_echo("messages:noaccess"); ?></label></p>
	</div>
