<?php

	$refresh_time = get_plugin_setting("messages_refresh_rate", "messages");

	if ($refresh_time == '') {
		$refresh_time = '180000';
	}

?>

<script type="text/javascript">

var refreshId = setInterval(function(){
 $('#messages_topbar_container').load('/mod/messages/lib/refreshstart.php?callback=true');
}, <?php echo $refresh_time; ?>);

$(document).ready(function(){
	// initial load of messages
	$('#messages_topbar_container').load('/mod/messages/lib/refreshstart.php');
});

</script>



<div id="messages_topbar_container"></div>

