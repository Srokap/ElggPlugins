<?php if (get_plugin_setting('enableprivacy', 'messages') == 'yes') { ?>
<p>
	<?php echo elgg_echo('messages:friendsonly'); ?>
	
	<select name="params[friendsonly]">
		<option value="yes" <?php if ($vars['entity']->friendsonly == 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:yes'); ?></option>
		<option value="no" <?php if ($vars['entity']->friendsonly != 'yes') echo " selected=\"yes\" "; ?>><?php echo elgg_echo('option:no'); ?></option>
	</select>
	
</p>
<?php } ?>
