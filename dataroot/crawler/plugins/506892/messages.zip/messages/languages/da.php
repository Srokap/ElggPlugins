<?php

	$danish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messages' => "Beskeder",
            		'messages:back' => "tilbage til beskeder",
			'messages:user' => "Din indbakke",
			'messages:sentMessages' => "Sendte beskeder",
			'messages:posttitle' => "%ss beskeder: %s",
			'messages:inbox' => "Indbakke",
			'messages:send' => "Send en besked",
			'messages:sent' => "Sendte beskeder",
			'messages:message' => "Besked",
			'messages:title' => "Emne",
			'messages:to' => "Til",
            		'messages:from' => "Fra",
			'messages:fly' => "Send den",
			'messages:replying' => "Svar til",
			'messages:inbox' => "Indbakke",
			'messages:sendmessage' => "Send en besked",
			'messages:compose' => "Send en besked",
			'messages:sentmessages' => "Sendte beskeder",
			'messages:recent' => "Nyeste beskeder",
           		'messages:original' => "Oprindelig besked",
            		'messages:yours' => "Din besked",
            		'messages:answer' => "Besvar",
			'messages:toggle' => 'V&aelig;lg alle/ingen',
			'messages:markread' => 'Marker som l&aelig;st',
			'messages:new' => 'Ny besked',
			'notification:method:site' => 'Site',
			'messages:error' => 'Der opstod et problem da din besked skulle gemmes. Pr&oslash;v igen.',
			'item:object:messages' => 'Beskeder',

			'messages:choose:friend' => "Vælg modtager",
			'messages:choose:group' => "Vælg gruppe",
			'messages:choose:collection' => "Vælg vennesamling",
			'messages:to:friend' => "Til en ven",
			'messages:to:group' => "Til en gruppe",
			'messages:to:collection' => "Til en vennesamling",

	
		/**
		 * Settings
		 */
			'messages:enable:privacy' => 'Aktiver privatliv for brugere',
			'messages:friendsonly' => 'Angiv "Ja" hvis du kun &oslash;nsker post fra dine venner: ',
			'messages:noaccess' => 'Denne bruger &oslash;nsker kun at modtage beskeder fra venner!',
			'messages:messages_refresh_rate' => "Genopfriskningsinterval p&aring; topbar ikon",
			'messages:admin:seconds' => "sekunder",
			'messages:admin:minute' => "minut",
			'messages:admin:minutes' => "minutter",

		/**
		 * Status messages
		 */
	
			'messages:posted' => "Din besked blev sendt.",
			'messages:deleted' => "Din besked blev slettet.",
			'messages:markedread' => "Din(e) besked(er) blev markeret som l&aelig;st.",
	
		/**
		 * Email messages
		 */
	
			'messages:email:subject' => 'Du har en ny besked!',
			'messages:email:body' => "Du har en ny besked fra %s. Der står:

			
%s


Klik her for at læse dine beskeder:

	%s

Klik her for at sende %s en besked:

	%s

Du kan ikke besvare denne email.",
	
		/**
		 * Error messages
		 */
	
			'messages:blank' => "Du skal udfylde \"Emne\" og \"Besked\" felterne besked f&oslash;r vi kan sende den.",
			'messages:notfound' => "Desv&aelig;rre, kunne ikke finde denne besked.",
			'messages:notdeleted' => "Desv&aelig;rre, kunne ikke slette denne besked.",
			'messages:nopermission' => "Du har ikke lov til at slette denne besked.",
			'messages:nomessages' => "Der er ingen beskeder at vise.",
			'messages:user:nonexist' => "Kunne ikke finde modtageren i databasen.",
			'messages:user:blank' => "Du glemte at v&aelig;lge en modtager til din besked.",
	
		/**
		 * KFIX 21/5-2010 Tiger: Added translations
		 */
	
			'messages:written' => "Sendt",
			'messages:forward' => "Videresend",
			'messages:all:friends' => "Alle venner",
			'messages:forward:error' => "Du har ikke adgang til den valgte besked!",

	);
					
	add_translation("da",$danish);

?>
