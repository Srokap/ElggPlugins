<?php

add_metastring('views_counter');

