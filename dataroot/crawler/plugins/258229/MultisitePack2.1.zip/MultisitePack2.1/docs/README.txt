﻿Multisite Pack 2.1 Beta for elgg 1.6
This is the Multisite Pack, containing Patches to Elgg Core, Plugins and Documentation.
This software is still in beta, suitable only for skilled developers and can be used on production sites at your own risk!

2.1 Changes
some hacks hase been cleaned up and optimized
some hacks has been moved to plugin via hooks
added a setting to multisite to allow automatic subscription of new users to all sites
added an admin page to subscribe all users to a pre-existing site
persistent session roaming through sites, with single sign out

The Multisite Pack contains:
folder “docs”: with documentation for developers
folder “patches”: with patches to be applied to Elgg's core files
file “SRC.zip”: containing all Elgg's Core files already patched and plugins

IMPORTANT
This plugin allows the dynamic creation of subdomains.
So you have to :
- in your vhost : add an alias
- in your dns : add * A
If you are using wamp, you won't be able do create subdomains dynamically so you have to pre-declare you subdomains in your windows/system32/drivers/etc/hosts file

INSTALLATION
1)Unzip the Pack in a suitable place
2)Unzip the source file SRC.zip
3)Copy the mod/multisite folder in the mod of your Elgg installation
4)copy the file from engine/lib/multisite.php from the lib folder to your Elgg installation
5)Apply the patches to the corrispondent Elgg's core files (for example: engine-lib-elgglib.patch must be applied to engine/lib/elgglib.php)
6)Enable the multisite plugin
7)add a new row to your river table, call it site_guid (bigint)
8)add a new row to your system_log table, call it site_guid (bigint)
9)go to admin->communities menu -> init multisite and init the plugin with your default value
10)go to admin->communities menu -> Plugin setting and set your installed plugins as global, local, theme or hidden

Plugin multimsg :
This is an alternative of the standard messages plugin. 2 major features are implemented in this one :
the inbox contains all your messages, whatever the community where you have received them
You can select your friend from a choice of community

ALTERNATIVE INSTALLATION (EXPERIMENTAL)
1.Unzip the Pack in a suitable place
2.Unzip the source file SRC.zip in your Elgg root directory. It will overwrite modified core's files, add new core file (elgg/lib/multisite.php), add plugins (multisite and multimsg)
3.go to point 6 of standard installation 

