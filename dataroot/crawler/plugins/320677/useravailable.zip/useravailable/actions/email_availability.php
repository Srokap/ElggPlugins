<?php
//  Developed by Roshan Bhattarai 
//  Visit http://roshanbh.com.np for this script and more.
//  This notice MUST stay intact for legal use
global $CONFIG;
include $CONFIG->pluginspath . 'useravailable/classes/useravailableLib.php';
$allow_multiple_emails = false;

$email = get_input('email');
if(($result = ivalidate_email_address($email))!==true) {
	echo "no,$result";
}else{
	if ((!$allow_multiple_emails) && (get_user_by_email($email))) {
		echo "no,".elgg_echo('registration:dupeemail');
	}else
		echo "yes,e-mail address available to register";
}
exit;
?>