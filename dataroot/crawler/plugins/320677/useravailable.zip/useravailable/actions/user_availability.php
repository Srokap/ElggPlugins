<?php
//  Developed by Roshan Bhattarai 
//  Visit http://roshanbh.com.np for this script and more.
//  This notice MUST stay intact for legal use
global $CONFIG;
include $CONFIG->pluginspath . 'useravailable/classes/useravailableLib.php';

$username = get_input('user_name');
if(($result = ivalidate_username($username))!==true) {
	//system_message($result);
	echo "no,$result";
}else{
	if (get_user_by_username($username)) {
		//system_message('registration:userexists');
		echo "no,".elgg_echo('registration:userexists');
	}else
		echo "yes,Username available to register";
}
exit;
?>