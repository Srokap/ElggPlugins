<?php
function ivalidate_username($username) {
	global $CONFIG;
	
	// Basic, check length
	if (!isset($CONFIG->minusername)) {
		$CONFIG->minusername = 4;
	}
	if (strlen($username) < $CONFIG->minusername)
		return elgg_echo('registration:usernametooshort');
	
	// Blacklist for bad characters (partially nicked from mediawiki)
	
	$blacklist = '/[' .
		'\x{0080}-\x{009f}' . # iso-8859-1 control chars
		'\x{00a0}' .          # non-breaking space
		'\x{2000}-\x{200f}' . # various whitespace
		'\x{2028}-\x{202f}' . # breaks and control chars
		'\x{3000}' .          # ideographic space
		'\x{e000}-\x{f8ff}' . # private use
		'\x{0e00}-\x{0e7f}' . # thai language
		'\.' . # not allow dot
		']/u';
	
	if (
		preg_match($blacklist, $username) 
	)
		return elgg_echo('registration:invalidchars');
		
	// Belts and braces TODO: Tidy into main unicode
	$blacklist2 = '/\\"\'*& ?#%^(){}[]~?<>;|¬`@-+=';
	for ($n=0; $n < strlen($blacklist2); $n++)
		if (strpos($username, $blacklist2[$n])!==false)
			return elgg_echo('registration:invalidchars');
	return true;
}
function ivalidate_email_address($address) {
	if (!is_email_address($address)) return elgg_echo('registration:notemail');
	return true;
}
?>