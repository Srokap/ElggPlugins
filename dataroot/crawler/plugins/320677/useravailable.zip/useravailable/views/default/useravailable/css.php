.messagebox{
	width:auto;
	margin-left:0px;
	border:1px solid #c93;
	background:#ffc;
	padding:3px;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
}
.messageboxok{
	width:auto;
	margin-left:0px;
	border:1px solid #349534;
	background:#C9FFCA;
	padding:3px;
	font-weight:bold;
	color:#008000;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
}
.messageboxerror{
	width:auto;
	margin-left:0px;
	border:1px solid #CC0000;
	background:#F7CBCA;
	padding:3px;
	font-weight:bold;
	color:#CC0000;
	-webkit-border-radius: 3px; 
	-moz-border-radius: 3px;
}