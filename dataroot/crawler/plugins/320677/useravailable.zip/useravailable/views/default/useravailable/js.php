$(document).ready(function()
{
	$("#username").blur(function()
	{
		//remove all the class add the messagebox classes and start fading
		$("#msgbox_username").removeClass().addClass('messagebox').html('<img src="<?php echo $CONFIG->wwwroot;?>mod/useravailable/assets/images/loader.gif" /> Checking...').fadeIn("slow");
		//check the username exists or not from ajax
		$.post("<?php echo $vars['config']->url;?>action/useravailable/user_availability",{ user_name:$(this).val() } ,function(data)
		{
			myvar = data.split(",");
			result = myvar[myvar.length-2];
			result_str = myvar[myvar.length-1];
			if(result=='yes') //if username avaiable
			{
				$("#msgbox_username").fadeTo(200,0.1,function()  //start fading the messagebox
				{
				  //add message and change the class of the box and start fading
				  $(this).html('<img src="<?php echo $CONFIG->wwwroot;?>mod/useravailable/assets/images/accepted.png" /> ' + result_str).addClass('messageboxok').fadeTo(900,1);	
				});
			}else { //if username not avaiable
				$("#msgbox_username").fadeTo(200,0.1,function() //start fading the messagebox
				{
				  //add message and change the class of the box and start fading
				  $(this).html(result_str).addClass('messageboxerror').fadeTo(900,1);
				});
			}
		});
	});

	$("#email").blur(function()
	{
		//remove all the class add the messagebox classes and start fading
		$("#msgbox_email").removeClass().addClass('messagebox').html('<img src="<?php echo $CONFIG->wwwroot;?>mod/useravailable/assets/images/loader.gif" /> Checking...').fadeIn("slow");
		//check the email exists or not from ajax
		$.post("<?php echo $vars['config']->url;?>action/useravailable/email_availability",{ email:$(this).val() } ,function(data)
		{
			myvar = data.split(",");
			result = myvar[myvar.length-2];
			result_str = myvar[myvar.length-1];
			if(result=='yes') //if email avaiable
			{
				$("#msgbox_email").fadeTo(200,0.1,function()  //start fading the messagebox
				{
				  //add message and change the class of the box and start fading
				  $(this).html('<img src="<?php echo $CONFIG->wwwroot;?>mod/useravailable/assets/images/accepted.png" /> ' + result_str).addClass('messageboxok').fadeTo(900,1);	
				});
			}else {//if email not avaiable
				$("#msgbox_email").fadeTo(200,0.1,function() //start fading the messagebox
				{
				  //add message and change the class of the box and start fading
				  $(this).html(result_str).addClass('messageboxerror').fadeTo(900,1);
				});
			}
		});
	});
});