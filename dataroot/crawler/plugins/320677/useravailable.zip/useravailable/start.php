<?php
		function useravailable_init() {
			// Get config
			global $CONFIG;
			extend_view('css','useravailable/css');
			extend_view('js/initialise_elgg','useravailable/js');
			//register_page_handler('useravailable','useravailable_page_handler');
		}
		// Make sure the profile initialisation function is called on initialisation
		register_elgg_event_handler('init','system','useravailable_init',1);

		global $CONFIG;
		register_action("useravailable/user_availability",false,$CONFIG->pluginspath . "useravailable/actions/user_availability.php");
		register_action("useravailable/email_availability",false,$CONFIG->pluginspath . "useravailable/actions/email_availability.php");
		
		/*function useravailable_page_handler($page) {
			global $CONFIG;
			switch($page[0]) {
				case 'user_availability':
					include($CONFIG->pluginspath . "useravailable/user_availability.php");
				break;
			}
		}*/
?>