<?php

?>

.admin4adminsTable TH {
	font-weight:bold;
}

TABLE.admin4adminsTable {
	width:100%;
}