<?php

?>
<p><?php echo elgg_echo('admin4admins:intro:description'); ?></p>