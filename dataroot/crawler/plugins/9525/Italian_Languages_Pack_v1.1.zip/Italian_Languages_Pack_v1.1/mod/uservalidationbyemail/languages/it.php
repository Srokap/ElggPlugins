<?php
	/**
	 * Email user validation plugin language pack.
	 * 
	 * @package ElggUserValidationByEmail
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 * ****************************************
     * @Italian Language Pack
     * @Plugin: Email user validation
     * @version: 1.1 
     * english_revision: 2368
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

	$italian = array(
	
			'email:validate:subject' => "%s per favore conferma il tuo indirizzo email!",
			'email:validate:body' => "Ciao %s,



Per favore conferma il tuo indirizzo email cliccando sul link sottostante:

%s
",
			'email:validate:success:subject' => "Email validata %s!",
			'email:validate:success:body' => "Ciao %s,
			
Congratulazioni,hai validato con successo il tuo indirizzo email.",
	
	
	
		'uservalidationbyemail:registerok' => "Per attivare il tuo account, per favore conferma l'indirizzo della tua email cliccando sul link che ti abbiamo inviato."
	
	);
					
	add_translation("it",$italian);
?>