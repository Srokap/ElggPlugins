<?php

     /**
	 * Elgg Plugin language pack
	 * 
	 * @package Elgg Diagnostic
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 * ****************************************
     * @Italian Language Pack
     * @Core-Plugin: Diagnostic
     * @version: 1.1
     * english_revision: 2368
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

	$italian = array(
	
			'diagnostics' => 'Sistema di Diagnostica',
	
			'diagnostics:description' => 'Il seguente rapporto diagnostico è utile per una diagnosi di qualsiasi problema con Elgg, e potrebbe essere allegato e archiviato a qualsiasi rapporto sui bug di sistema.',
	
			'diagnostics:download' => 'Scarica .txt',
	
	
			'diagnostics:header' => '========================================================================
Rapporto di diagnostica di Elgg
Generato %s da %s
========================================================================
			
',
			'diagnostics:report:basic' => '
Elgg Release %s, versione %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
informazioni sul PHP:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
Installazione plugins and dettagli:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
Installazione files and checksums:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
Variabili globali:

%s
------------------------------------------------------------------------',
	
	);
					
	add_translation("it",$italian);
?>