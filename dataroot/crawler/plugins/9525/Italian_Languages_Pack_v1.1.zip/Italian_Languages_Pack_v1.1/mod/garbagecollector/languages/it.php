<?php
	/**
	 * Elgg garbage collector language pack.
	 * 
	 * @package ElggGarbageCollector
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 * ****************************************
     * @Italian Language Pack
     * @Core Plugin: Garbage Collector
     * @version: 1.1
     * english_revision: 2368
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

	$italian = array(
	
		/**
		 * Menu items and titles   ###Argomenti del menu e titoli###
		 */
	
			'garbagecollector:period' => 'Quanto spesso vorresti far funzionare il garbage collector di Elgg?',
	
			'garbagecollector:weekly' => 'Una volta ogni settimana',
			'garbagecollector:monthly' => 'Una volta ogni mese',
			'garbagecollector:yearly' => 'Una volta ogni anno',
	
			'garbagecollector' => "GARBAGE COLLECTOR\n",
			'garbagecollector:done' => "FATTO\n",
			'garbagecollector:optimize' => "Ottimizzando %s ",
	
			'garbagecollector:error' => "ERRORE",
			'garbagecollector:ok' => "OK",
	
			'garbagecollector:gc:metastrings' => 'Pulendo le Metastring non collegate: ',
	
	);
					
	add_translation("it",$italian);
?>