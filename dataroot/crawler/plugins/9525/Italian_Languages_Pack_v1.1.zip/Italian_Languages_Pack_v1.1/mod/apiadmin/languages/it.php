<?php
	/**
	 * @package ElggAPIAdmin
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 * ****************************************
     * @Italian Language Pack
     * @Core System: API Admin
     * @version: 1.1 
     * @english_revision: 2368
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

	$italian = array(
	
		/**
		 * Menu items and titles   ###Argomenti del Menu e titoli###
		 */
	
			'apiadmin' => 'Amministrazione API',
	
	
			'apiadmin:keyrevoked' => 'API Key revocata',
			'apiadmin:keynotrevoked' => 'API Key non può essere revocata',
			'apiadmin:generated' => 'API Key generata con successo',
	
			'apiadmin:yourref' => 'Il tuo riferimento',
			
			/*Keypair: non traducibile.
			 * vedi anche: http://en.wikipedia.org/wiki/Public-key_cryptography 
			 * Used in message security, a cryptographic key pair consists of a public key and a private key. 
			 * A public key is associated with a user through a certificate that is published to a location available to anyone.
			 * The corresponding private key is stored in a secure location on the user's client computer. */
			'apiadmin:generate' => 'Genera una nuova keypair',
	
			'apiadmin:noreference' => 'Devi fornire un riferimento per la tua nuova key.',
			'apiadmin:generationfail' => 'Deve esserci stato un problema nel generare la nuova keypair',
			'apiadmin:generated' => 'La nuova API keypair è stata generata con successo',
	
			'apiadmin:revoke' => 'Revoca la key',
			'apiadmin:public' => 'Pubblico',
			'apiadmin:private' => 'Privato',

	
			'item:object:api_key' => 'Le API-Key',
	);
					
	add_translation("it",$italian);
?>