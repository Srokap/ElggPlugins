<?php

     /**
	 * Elgg Plugin language pack
	 * 
	 * @package Elgg ReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 * ****************************************
     * @Italian Language Pack
     * @Plugin:  ReportedContent
     * @version: 1.1 
     * english_revision: 2368
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/


	$italian = array(
	
		/**
		 * Menu items and titles  ###Argomenti del menu e titoli###
		 */
	
			'item:object:reported_content' => 'Argomenti segnalati',
			'reportedcontent' => 'Segnalazioni',
			'reportedcontent:this' => 'Segnalazione',
			'reportedcontent:none' => 'Nessun contunuto è stato segnalato',
			'reportedcontent:report' => 'Segnalalo a un amministratore',
			'reportedcontent:title' => 'Titolo della Segnalazione',
			'reportedcontent:deleted' => 'La segnalazione è stata cancellata',
			'reportedcontent:notdeleted' => 'Non siamo stati abilitati a cancellare questa segnalazione',
			'reportedcontent:delete' => 'Cancellalo',
			'reportedcontent:areyousure' => 'Sei sicuro di volerlo cancellare?',
			'reportedcontent:archive' => 'Archivialo',
			'reportedcontent:archived' => 'La segnalazione è stata archiviata',
			'reportedcontent:visit' => 'Visita argomento segnalato',
			'reportedcontent:by' => 'Segnalato by',
			'reportedcontent:objecttitle' => 'Titolo di questo oggetto',
			'reportedcontent:objecturl' => 'Url di questo oggetto',
			'reportedcontent:reason' => 'Motivo della segnalazione',
			'reportedcontent:description' => 'Perchè ci stai segnalando questo?',
			'reportedcontent:address' => 'Localizzazione di questa segnalazione',
			'reportedcontent:success' => 'La tua segnalazione è stata inviata a un amministratore del sito',
			'reportedcontent:failing' => 'La tua segnalazione non può essere inviata',
			'reportedcontent:report' => 'Segnala', 
			
			'reportedcontent:failed' => 'Scusaci, la segnalazione di questo contenuto non è riuscita.',
	
	);
					
	add_translation("it",$italian);
?>