<?php
	/**
	 * Elgg log rotator language pack.
	 * 
	 * @package ElggLogRotate
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	  * ****************************************
     * @Italian Language Pack
     * @Core Plugin: LogRotate
     * @version: 1.1 
     * @english_revision: 2368
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/
     /**LogRotate: consente di controllare la dimensione dei files di log presenti nel nostro sistema.
      * Il logrotate, consente di salvaguardare l’occupazione dello spazio su disco eseguendo una rotazione dei file di log in maniera da evitare la loro crescita incontrollata.
     **/

	$italian = array(
		'logrotate:period' => 'Ogni quanto dovrebbe essere archiviato il system log?',
	
		'logrotate:weekly' => 'Una volta ogni settimana',
		'logrotate:monthly' => 'Una volta ogni mese',
		'logrotate:yearly' => 'Una volta ogni anno',
	
		'logrotate:logrotated' => "Logrotate\n",
		'logrotate:lognotrotated' => "Errore nel logrotate\n",
	);
					
	add_translation("it",$italian);
?>