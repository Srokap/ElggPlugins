<?php
     /**
	 * Elgg Core language pack
	 * 
	 * @package ElggCore
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 * ****************************************
     * @Italian Language Pack
     * @Core System
     * @version: 1.1
     * english_revision: 2368
     * @Italian Support Group: http://community.elgg.org/pg/groups/271/italian-support-group/
     * @translation by Lord55  <lord55@nobiltadeipari.com> 
     * @link http://www.nobilityofequals.com
     ****************************************/

	$italian = array(

		/**
		 * Sites   ###Siti###
		 */
	
			'item:site' => 'Siti',
	
		/**
		 * Sessions   ###Sessioni###  OK
		 */
		
			'login' => "Entra",
			'loginok' => "Sei entrato.",
			'loginerror' => "Non possiamo farti entrare. Questo può accadere perchè non hai ancora validato il tuo account, o i dati che hai fornito non erano corretti. Assicurati che i tuoi dati siano corretti e per favore riprova.",
	
			'logout' => "Esci",
			'logoutok' => "Sei uscito.",
			'logouterror' => "Non possiamo farti uscire. Per favore riprova.",
	
		/**
		 * Errors   ###Errori###
		 */
			'exception:title' => "Benvenuto in Elgg.",
	
			'InstallationException:CantCreateSite' => "Siamo inabilitati a creare un sito-Elgg principale con le seguenti credenziali: %s, Url: %s",
		
			'actionundefined' => "L'azione che è stata richiesta(%s) non è definita nel sistema.",
			'actionloggedout' => "Scusaci, non puoi compiere questa azione senza una previa identificazione sul sito.",
	
			'notfound' => "La risorsa richiesta non può essere trovata o non hai accesso ad essa.",
			
			'SecurityException:Codeblock' => "Denied access to execute privileged code block",
			'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials %s@%s (pw: %s).",
			'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
			'SecurityException:FunctionDenied' => "L'accesso alle funzione privilegiata '%s' è negato.",
			'DatabaseException:DBSetupIssues' => "Ci sono stati un numero di problemi: ",
			'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
			
			'IOException:FailedToLoadGUID' => "Non siamo riusciti a caricare il nuovo %s dal GUID:%d",
			'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
			'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",
			
			'InvalidClassException:NotValidElggStar' => "GUID:%d non è un valido %s",
			
			'PluginException:MisconfiguredPlugin' => "%s è un plugin non configurato.",
			
			'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",
			
			'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",
			
			'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",
	
			'IOException:UnableToSaveNew' => "Inabilitato a salvare il nuovo %s",
			
			'InvalidParameterException:GUIDNotForExport' => "Il GUID non è stato specificato durante l'esportazione, questo non dovrebbe accadere mai.",
			'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",
			
			'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
			'IOException:NotDirectory' => "%s non è una cartella.",
			
			'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
			'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
			'InvalidParameterException:EntityTypeNotSet' => "Il Tipo di Entità deve essere settato.",
			
			'ClassException:ClassnameNotClass' => "%s non è un %s.",
			'ClassNotFoundException:MissingClass' => "La classe '%s' non è stata trovata, il Plugin è mancante?",
			'InstallationException:TypeNotSupported' => "Il tipo %s non è sopportato. Questo significa che c'è un errore nella tua installazione, molto probabilmente causato da un aggiornamento incompleto.",

			'ImportException:ImportFailed' => "Non è possibile importare l'elemento %d",
			'ImportException:ProblemSaving' => "C'è stato un problema nell'importare %s",
			'ImportException:NoGUID' => "Una nuova entità è stata creata ma non ha un GUID, questo non dovrebbe accadere.",
			
			'ImportException:GUIDNotFound' => "L'entità '%d' non può essere trovata.",
			'ImportException:ProblemUpdatingMeta' => "C'è stato un problema nell'aggiornare '%s' sull'entità '%d'",
			
			'ExportException:NoSuchEntity' => "Nessuna entità GUID simile:%d", 
			
			'ImportException:NoODDElements' => "Nessun elemento OpenDD è stato trovato nell'importazione dei dati, l'importazione è fallita.",
			'ImportException:NotAllImported' => "Non tutti gli elementi sono stati importati.",
			
			'InvalidParameterException:UnrecognisedFileMode' => "Modalità file non riconosciuta '%s'",
			'InvalidParameterException:MissingOwner' => "Tutti i file devono avere un proprietario!",
			'IOException:CouldNotMake' => "Non si può fare %s",
			'IOException:MissingFileName' => "Devi specificare un nome prima di aprire un file.",
			'ClassNotFoundException:NotFoundNotSavedWithFile' => "La cartella per il deposito dei File non è stata trovata o la classe non è stata salvata con un file!",
			'NotificationException:NoNotificationMethod' => "Nessun metodo di notificazione è stato specificato.",
			'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
			'NotificationException:ErrorNotifyingGuid' => "C'è stato un errore nel notificare %d",
			'NotificationException:NoEmailAddress' => "Non posso ottenere l'indirizzo email per il GUID:%d",
			'NotificationException:MissingParameter' => "Manca un parametro richiesto, '%s'",
			
			'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
			'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
			'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
			'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
			'DatabaseException:NoACL' => "No access control was provided on query",
			
			'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",
			
			'InvalidParameterException:GUIDNotFound' => "GUID:%s non può essere trovato, o non puoi accedere ad esso.",
			'InvalidParameterException:IdNotExistForGUID' => "Scusaci, '%s' non esiste per il GUID:%d",
			'InvalidParameterException:CanNotExportType' => "Scusaci, non sappiamo come esportare '%s'",
			'InvalidParameterException:NoDataFound' => "Non è possibile trovare nessun dato.",
			'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
			'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
			'InvalidParameterException:MissingParameter' => "Parametro mancante, devi fornire un GUID.",
			
			'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
			'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
			'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.", 
			
			'ConfigurationException:NoSiteID' => "Nessun ID del sito è stato specificato.",
			'InvalidParameterException:UnrecognisedMethod' => "Il metodo di chiamata '%s' non è stato riconosciuto.",
			'APIException:MissingParameterInMethod' => "Il parametro %s è mancante nel metodo %s",
			'APIException:ParameterNotArray' => "%s non sembra essere un array.",
			'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
			'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
			'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
			'APIException:FunctionNoReturn' => "%s(%s) è ritornato senza valore.",
			'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
			'CallException:InvalidCallMethod' => "%s deve essere chiamato usando '%s'",
			'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
			'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
			'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
			'APIException:NotGetOrPost' => "Request method must be GET or POST",
			'APIException:MissingAPIKey' => "Missing X-Elgg-apikey HTTP header",
			'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
			'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
			'APIException:MissingTime' => "Missing X-Elgg-time header",
			'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
			'APIException:NoQueryString' => "No data on the query string",
			'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
			'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
			'APIException:MissingContentType' => "Missing content type for post data",
			'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
			'SecurityException:DupePacket' => "Packet signature already seen.",
			'SecurityException:InvalidAPIKey' => "API Key invalida o non trovata.",
			'NotImplementedException:CallMethodNotImplemented' => "Il metodo di chiamata '%s' non è al momento sopportata.",
	
			'NotImplementedException:XMLRPCMethodNotImplemented' => "Il metodo di chiamata XML-RPC '%s' non è stato implementato.",
			'InvalidParameterException:UnexpectedReturnFormat' => "La chiamata al metodo '%s' ha fatto ritornare un risultato inaspettato.",
			'CallException:NotRPCCall' => "La chiamata non sembra essere una valida chiamata XML-RPC",
	
			'PluginException:NoPluginName' => "Il nome del Plugin installato non può essere trovato",
	
			'ConfigurationException:BadDatabaseVersion' => "Il backend del database che hai installato non incontra le condizioni di base per far funzionare Elgg. Per favore consulta la tua documentazione.",
			'ConfigurationException:BadPHPVersion' => "Necessiti almeno della versione PHP version 5.2 per far funzionare Elgg.",
			
			'configurationwarning:phpversion' => "Elgg richiede almeno PHP versione 5.2, puoi installarlo sulla versione 5.1.6 ma alcune caratteristiche potrebbero non funzionare. L'utilizzo è a proprio rischio.",
	
	
	
			'InstallationException:DatarootNotWritable' => "La tua cartella dati %s non è scrivibile.",
			'InstallationException:DatarootUnderPath' => "La tua cartella dati %s deve stare fuori dal tuo percorso di installazione.",
			'InstallationException:DatarootBlank' => "Non hai specificato una cartella dati.",
			
			'SecurityException:authenticationfailed' => "L'utente non può essere autenticato",
			
			'CronException:unknownperiod' => '%s non è un periodo riconosciuto.',
		
		    
			'SecurityException:deletedisablecurrentsite' => 'Non puoi cancellare o disabilitare il sito che stai visualizzando ora!',
		
		/**
		 * API ###API### OK
		 */
			'system.api.list' => "Elenca tutte le chiamate di API disponibili sul sito.",
			'auth.gettoken' => "Questa chiamata dell'API permette il login dell'utente, facendo ritornare un token di  autenticazione il quale può essere usato in sostituzione di username e password per ulteriori chiamate di autenticazione.",
	
	
		/**
		 * User details   ###Identificazione utente###   OK
		 */

			'name' => "Nome pubblico",
			'email' => "Indirizzo Email",
			'username' => "Nome utente",
			'password' => "Password",
			'passwordagain' => "Ripeti la Password",
			'admin_option' => "Nomina questo utente Amministratore?",
	
		/**
		 * Access   ###Accesso###   OK
		 */
	
			'ACCESS_PRIVATE' => "Privato",
			'ACCESS_LOGGED_IN' => "Membri",
			'ACCESS_PUBLIC' => "Pubblico",
			'PRIVATE' => "Privato",
			'LOGGED_IN' => "Membri",
			'PUBLIC' => "Pubblico",
			'access' => "Accesso",
	
		/**
		 * Dashboard and widgets   ###Dashboard e widget###  OK
		 */
	
			'dashboard' => "Dashboard",
            'dashboard:configure' => "Modifica pagina",
			'dashboard:nowidgets' => "La Dashboard è la tua porta d'ingresso nel sito. Clicca su 'Modifica pagina' per aggiungere i Widget che ti permetteranno di tenere traccia di tutte le interazioni dentro il sistema.",

			'widgets:add' => 'Aggiungi i Widget alla tua pagina.',
			'widgets:add:description' => "Scegli le caratteristiche che vorresti aggiungere alla tua pagina personale spostando i Widget dalla <b>Galleria-Widget</b> (qui a destra), su una delle tre Aree-Widget qui sotto e posizionali dove vorresti farli apparire.

Per rimuovere un Widget, riportalo indietro nella <b>Galleria-Widget</b>.",
			'widgets:position:fixed' => '(Posizione bloccata sulla pagina)',
	
			'widgets' => "Widget",
			'widget' => "Widget",
			'item:object:widget' => "Widget",
			'layout:customise' => "Personalizza la grafica",
			'widgets:gallery' => "Galleria-Widget",
			'widgets:leftcolumn' => "Sinistra-Area Widget",
			'widgets:fixed' => "Posizione sistemata",
			'widgets:middlecolumn' => "Centro-Area Widget",
			'widgets:rightcolumn' => "Destra-Area Widget",
			'widgets:profilebox' => "Modulo profilo",
			'widgets:panel:save:success' => "Il tuo Widget è stato salvato con successo.",
			'widgets:panel:save:failure' => "C'è stato un problema nel salvare il tuo Widget. Per favore riprova.",
			'widgets:save:success' => "Il Widget è stato salvato con successo.",
			'widgets:save:failure' => "Non possiamo salvare il tuo widget. Per favore riprova.",
			
	     /**
		 * Groups   ###Gruppi###  OK
		 */
	
			'group' => "Gruppo", 
			'item:group' => "Gruppi",
	
		/**
		 * Profile   ###Profilo###  OK
		 */
	
			'profile' => "Profilo",
			'profile:edit:default' => 'Ripristina i campi del Profilo',
			'user' => "Utente",
			'item:user' => "Utenti",
			'riveritem:single:user' => 'a user',
			'riveritem:plural:user' => 'some users',


		/**
		 * Profile menu items and titles   ####Argomenti del menu profilo e titoli###   OK
		 */
	
			'profile:yours' => "Il tuo profilo",
			'profile:user' => "Profilo di %s",
	
			'profile:edit' => "Modifica profilo",
			'profile:profilepictureinstructions' => "La Foto-profilo è un'immagine che viene visualizzata sulla tua pagina-profilo. <br /> Potrai cambiarla quante volte vorrai. (Formati file accettati: GIF, JPG o PNG)",
			'profile:icon' => "Foto del profilo",
			'profile:createicon' => "Crea il tuo avatar",
			'profile:currentavatar' => "Avatar corrente",
			'profile:createicon:header' => "Foto del profilo",
			'profile:profilepicturecroppingtool' => "Strumento di ritaglio per la Foto-Profilo",
			'profile:createicon:instructions' => "Clicca e trascina un quadrato qui sotto per definire quanta immagine vuoi tagliare. Un'anteprima dell'immagina tagliata apparirà nel riquadro sulla destra. Quando sarai contento dell'anteprima, clicca 'Crea il tuo avatar'. Questa immagine tagliata sarà utilizzata in ogni parte del sito come il tuo avatar. ",
	
			'profile:editdetails' => "Modifica i dettagli",
			'profile:editicon' => "Modifica la Foto-Profilo",
	
			'profile:aboutme' => "Chi sono", 
			'profile:description' => "Chi sono",
			'profile:briefdescription' => "Descrizione breve",
			'profile:location' => "Località",
			'profile:skills' => "Attitudini",  
			'profile:interests' => "Interessi", 
			'profile:contactemail' => "Indirizzo email",
			'profile:phone' => "Telefono",
			'profile:mobile' => "Cellulare",
			'profile:website' => "Sito Web",

			'profile:river:update' => "%s ha aggiornato il suo profilo",
			'profile:river:iconupdate' => "%s ha aggiornato l'icona sul suo profilo",
	
	        'profile:label' => "Etichetta del Profilo",
			'profile:type' => "Tipo di Profilo",
	
			'profile:editdefault:fail' => 'Il Profilo predefinito non può essere salvato',
			'profile:editdefault:success' => 'Il dato è stato aggiunto con successo sul Profilo predefinito',
	
			
			'profile:editdefault:delete:fail' => 'La rimozione del campo-dato sul Profilo predefinito è fallito',
			'profile:editdefault:delete:success' => 'Il dato sul Profilo predefinito è stato cancellato!',
	
			'profile:defaultprofile:reset' => 'Il sistema di Profilo predefinito è stato ristabilito',
	
			'profile:resetdefault' => 'Ripristina il Profilo predefinito',
	
		/**
		 * Profile status messages   ###Messaggi sullo stato del profilo###  OK
		 */
	
			'profile:saved' => "Il tuo profilo è stato salvato con successo.",
			'profile:icon:uploaded' => "La foto sul tuo profilo è stata inviata con successo.",
	
		/**
		 * Profile error messages   ###Messaggio di errore sul profilo###   OK
		 */
	
			'profile:noaccess' => "Non hai il permesso di modificare questo profilo.",
			'profile:notfound' => "Scusaci; non possiamo trovare il profilo specificato.",
			'profile:cantedit' => "Scusaci; non hai il permesso di modificare questo profilo.",
			'profile:icon:notfound' => "Scusaci; c'è un problema nell'inviare la tua foto sul profilo.",
	
		/**
		 * Friends   ###Amici###   OK
		 */
	
			'friends' => "Amici",
			'friends:yours' => "I tuoi amici",
			'friends:owned' => "Amici di %s",
			'friend:add' => "Aggiungilo come amico",
			'friend:remove' => "Rimuovi amico",
	
			'friends:add:successful' => "Hai aggiunto con successo %s come un amico.",
			'friends:add:failure' => "Non possiamo aggiungere %s come un amico. Per favore riprova.",
	
			'friends:remove:successful' => "Hai rimosso con successo %s dai tuoi amici.",
			'friends:remove:failure' => "Non possiamo rimuovere %s dai tuoi amici. Per favore riprova.",
	
			'friends:none' => "Questo utente non ha ancora aggiunto nessuno come amico.",
			'friends:none:you' => "Non hai aggiunto nessuno come amico! Inizia a cercare in base ai tuoi interessi, gli amici da seguire.",
	
			'friends:none:found' => "Nessun amico è stato trovato.",
	
			'friends:of:none' => "Nessuno ancora ha aggiunto questo utente come amico.",
			'friends:of:none:you' => "Nessuno ti ha ancora aggiunto come amico. Inizia aggiungendo contenuti e a riempire il tuo profilo per permettere alle persone di preferirti!",
	
			'friends:of' => "Amico di",
			'friends:of:owned' => "Persone che hanno fatto di %s un amico",

			 'friends:num_display' => "Numero di amici da visualizzare",
			 'friends:icon_size' => "Dimensione icona",
			 'friends:tiny' => "minuscola",
			 'friends:small' => "piccola",
			 'friends' => "Amici",
			 'friends:of' => "Amico di",
			 'friends:collections' => "Collezioni di amici",
			 'friends:collections:add' => "Crea collezione di amici",
			 'friends:addfriends' => "Aggiungi amici",
			 'friends:collectionname' => "Nome della Collezione",
			 'friends:collectionfriends' => "Amici nella collezione",
			 'friends:collectionedit' => "Modifica questa collezione",
			 'friends:nocollections' => "Non hai ancora nessuna collezione.",
			 'friends:collectiondeleted' => "La tua collezione è stata cancellata.",
			 'friends:collectiondeletefailed' => "Non siamo abilitati a cancellare la collezione. We were unable to delete the collection. Nemmeno tu hai il permesso, o qualche altro problema è avvenuto.",
			 'friends:collectionadded' => "La tua collezione è stata creata con successo.",
			 'friends:nocollectionname' => "Devi dare alla tua collezione un nome prima di poterla salvare.",
		
	        'friends:river:created' => "%s ha aggiunto il widget Amici.",
	        'friends:river:updated' => "%s ha aggiornato il suo widget Amici.",
	        'friends:river:delete' => "%s ha rimosso il suo widget Amici.",
	        'friends:river:add' => "%s ha aggiunto qualcuno come amico.",
	
		/**
		 * Feeds   ###Feeds###  OK
		 */
			'feed:rss' => 'Sottoscriviti al feed',
			'feed:odd' => 'Sincronizza con OpenDD',
		
		/**
          * links
		 **/

			'link:view' => 'vedi Link',

	
		/**
		 * River   ###River###   OK
		 */
			'river' => "River",			
			'river:relationship:friend' => 'è ora amico con',

		/**
		 * Plugins   ###Plugin###    OK
		 */
			'plugins:settings:save:ok' => "I settaggi per il plugin %s sono stati salvati con successo.",
			'plugins:settings:save:fail' => "C'è stato un problema nel salvare i settaggi per il plugin %s.",
			'plugins:usersettings:save:ok' => "I settaggi-utente per il plugin %s sono stati salvati con successo.",
			'plugins:usersettings:save:fail' => "C'è stato un problema nel salvare i settaggi-utente per il plugin %s.",
			
			'item:object:plugin' => 'Settaggi di configurazione del Plugin',
		/**
		 * Notifications   ###Notifiche###  OK  
		 */
			'notifications:usersettings' => "Configurazione delle Notifiche",
			'notifications:methods' => "Per favore specifica il metodo che vuoi permettere.",
	
			'notifications:usersettings:save:ok' => "La configurazione-Notifiche è stata salvata con successo.",
			'notifications:usersettings:save:fail' => "C'è stato un problema nel salvare la tua configurazione-Notifiche.",
		
		    'user.notification.get' => 'Rimetti i settaggi di notifica per un dato utente.',
		    'user.notification.set' => 'Imposta i settaggi di notifica per un dato utente.',
		
		
		/**
		 * Search   ###Ricerca###   OK
		 */
	
			'search' => "Ricerca",
			'searchtitle' => "Ricerca: %s",
			'users:searchtitle' => "Ricercando per utenti: %s",
			'advancedsearchtitle' => "%s trovati coi risultati %s.",
			'notfound' => "Nessun risultato trovato.",
			'next' => "Avanti",
			'previous' => "Indietro",
	
			'viewtype:change' => "Cambia il tipo di visualizzazione",
			'viewtype:list' => "Elenco",
			'viewtype:gallery' => "Galleria",
	
			'tag:search:startblurb' => "Argomenti con tags '%s' trovati:",

			'user:search:startblurb' => "Utenti risultanti come '%s':",
			'user:search:finishblurb' => "Vedi altri, clicca qui.",
	
		/**
		 * Account  ###Account###  OK
		 */
	
			'account' => "Account",
			'settings' => "Settaggi",
            'tools' => "Strumenti",
            'tools:yours' => "I tuoi Strumenti",
	
			'register' => "Registrati",
			'registerok' => "Ti sei registrato con successo su %s. ",
			'registerbad' => "La tua registrazione non è avvenuta con successo. Il tuo nome-utente può essere già in uso, la tua password può non essere valida, o il tuo nome-utente o password possono essere troppo brevi.",
			'registerdisabled' => "La registrazione è stata disabilitata dall'amministratore del sistema.",
	
			'registration:notemail' => 'Un Indirizzo email fornito non sembra essere un valido indirizzo email.',
			'registration:userexists' => 'Quel nome-utente già esiste',
			'registration:usernametooshort' => 'Il tuo nome-utente deve avere una lunghezza di minimo 4 caratteri.',
			'registration:passwordtooshort' => 'La password deve avere una lunghezza di minimo 6 caratteri.',
			'registration:dupeemail' => 'Questo indirizzo email è già stato registrato.',
			'registration:invalidchars' => 'Scusaci, il tuo username contiene caratteri non validi.',
			'registration:emailnotvalid' => 'Scusaci,un indirizzo email che hai inserito non è valido su questo sistema',
			'registration:passwordnotvalid' => 'Scusaci, la password che hai inserito non è valida su questo sistema',
			'registration:usernamenotvalid' => 'Scusaci, il nome-utente che hai inserito non è valido su questo sistema',
	
			'adduser' => "Aggiugi utente",
			'adduser:ok' => "Hai aggiunto con successo un nuovo utente.",
			'adduser:bad' => "Il nuovo utente non può essere creato.",
			
			'item:object:reported_content' => "Riporta argomento",
	
			'user:set:name' => "Configurazione del Nome-Account",
			'user:name:label' => "Il tuo Nome pubblico",
			'user:name:success' => "Hai cambiato con successo il tuo nome su questo sistema.",
			'user:name:fail' => "Non puoi cambiare il tuo nome su questo sistema.",
	
			'user:set:password' => "Configurazione della Password-Account",
			'user:password:label' => "La tua nuova Password",
			'user:password2:label' => "Ripeti la Password per la verifica",
			'user:password:success' => "Password cambiata",
			'user:password:fail' => "Non puoi cambiare la password su questo sistema.",
			'user:password:fail:notsame' => "Le due passwords non sono identiche!",
			'user:password:fail:tooshort' => "La Password è troppo breve!",
	
			'user:set:language' => "Configurazione della Lingua",
			'user:language:label' => "La tua lingua",
			'user:language:success' => "La configurazione della tua lingua è stata aggiornata.",
			'user:language:fail' => "La configurazione della tua lingua non può essere salvata.",
	
			'user:username:notfound' => 'Nome-utente %s non trovato.',
	
			'user:password:lost' => 'Password dimenticata',
			'user:password:resetreq:success' => 'Richiesta nuova password avvenuta con successo, email inviata',
			'user:password:resetreq:fail' => 'Non puoi richiedere una nuova password.',
	
			'user:password:text' => 'Per generare una nuova Password, inserisci il tuo Nome-utente qui sotto. Ti invieremo per email un indirizzo di una pagina di verifica univoca, clicca sul link nel corpo del messaggio e una nuova password ti sarà inviata.',
	        
			'user:persistent' => 'Ricordami',
		
		/**
		 * Administration   ###Amministrazione###   OK
		 */

			'admin:configuration:success' => "I tuoi settaggi sono stati salvati.",
			'admin:configuration:fail' => "I tuoi settaggi non possono essere salvati.",
	
			'admin' => "Amministrazione",
			'admin:description' => "Il pannello amministrativo ti permette di controllare tutti gli aspetti del sistema, dall'amministrazione dell'utente a come far funzionare i plugin. Scegli un'opzione qui sotto per iniziare.",
			
			'admin:user' => "Amministrazione Utente",
			'admin:user:description' => "Questo pannello amministrativo ti permette di controllare i settaggi degli utenti per il tuo sito. Scegli un'opzione qui sotto per iniziare.",
			'admin:user:adduser:label' => "Clicca qui per aggiungere un nuovo utente...",
			'admin:user:opt:linktext' => "Configura gli utenti...",
			'admin:user:opt:description' => "Configura gli utenti e l'informazione sull'account. ",
			
			'admin:site' => "Amministrazione Sito",
			'admin:site:description' => "Questo pannello amministrativo ti permette di controllare i settaggi globali per il tuo sito. Scegli un'opzione qui sotto per iniziare.",
			'admin:site:opt:linktext' => "Configura il sito...",
			'admin:site:opt:description' => "Configura i settaggi tecnici e non-tecnici del sito. ",
			
			'admin:plugins' => "Amministrazione Strumenti",
			'admin:plugins:description' => "Questo pannello ammministrativo ti permette di controllare e configurara gli Strumenti installati sul tuo sito.",
			'admin:plugins:opt:linktext' => "Configura gli Strumenti...",
			'admin:plugins:opt:description' => "Configura gli Strumenti installati sul sito. ",
			'admin:plugins:label:author' => "Autore",
			'admin:plugins:label:copyright' => "Copyright",
			'admin:plugins:label:licence' => "Licenza",
			'admin:plugins:label:website' => "URL",
			"admin:plugins:label:moreinfo" => 'more info',
			'admin:plugins:reorder:yes' => "Il plugin %s è stato riordinato con successo.",
			'admin:plugins:reorder:no' => "Il plugin %s non può essere riordinato.",
			'admin:plugins:disable:yes' => "Il plugin %s è stato disabilitato con successo.",
			'admin:plugins:disable:no' => "Il plugin %s non può essere disabilitato.",
			'admin:plugins:enable:yes' => "Il plugin %s è stato abilitato con successo.",
			'admin:plugins:enable:no' => "Il plugin %s non può essere abilitato.",
	
			'admin:statistics' => "Statistiche",
			'admin:statistics:description' => "Questa è una visione d'insieme delle statistiche sul tuo sito. Se hai bisogno di statistiche più dettagliate, è disponibile un servizio amministrativo professionale.",
			'admin:statistics:opt:description' => "Visualizza i dati statistici riguardanti gli utenti e gli oggetti sul tuo sito.",
			'admin:statistics:opt:linktext' => "Visualizza le statistiche...",
			'admin:statistics:label:basic' => "Statistiche di base del sito",
			'admin:statistics:label:numentities' => "Entità sul sito",
			'admin:statistics:label:numusers' => "Numero di utenti",
			'admin:statistics:label:numonline' => "Numbero di utenti online",
			'admin:statistics:label:onlineusers' => "Utenti Online in questo momento",
			'admin:statistics:label:version' => "Versione di Elgg",
			'admin:statistics:label:version:release' => "Release",
			'admin:statistics:label:version:version' => "Versione",
	
			'admin:user:label:search' => "Cerca utenti:",
			'admin:user:label:seachbutton' => "Ricerca", 
	
			'admin:user:ban:no' => "Non puoi bandire l'utente.",
			'admin:user:ban:yes' => "Utente esiliato.",
			'admin:user:unban:no' => "Non puoi riattivare l'utente.",
			'admin:user:unban:yes' => "Utente riammesso.",
			'admin:user:delete:no' => "Non puoi cancellare l'utente.",
			'admin:user:delete:yes' => "Utente cancellato.",
	
			'admin:user:resetpassword:yes' => "Password cambiata, l'utente è stato avvertito.",
			'admin:user:resetpassword:no' => "La Password non può essere cambiata.",
	
			'admin:user:makeadmin:yes' => "L'utente è ora un amministratore.",
			'admin:user:makeadmin:no' => "Non possiamo nominare questo utente come amministratore.",
			
		/**
		 * User settings   ### Settaggi dell' utente ###  OK
		 */
			'usersettings:description' => "Il pannello dei settaggi utente ti permette di controllare tutti i tuoi settaggi personali: dall'amministrazione dell'utente a come i plugins si comportano. Scegli un'opzione qui sotto per iniziare.",
	
			'usersettings:statistics' => "Le tue statistiche",
			'usersettings:statistics:opt:description' => "Visualizza i dati statistici riguardo gli utenti e gli oggetti sul tuo sito.",
			'usersettings:statistics:opt:linktext' => "Statistiche dell'account",
	
			'usersettings:user' => "I tuoi settaggi",
			'usersettings:user:opt:description' => "Questo ti permette di controllare i settaggi dell'utente.",
			'usersettings:user:opt:linktext' => "Cambia i tuoi settaggi",
	
			'usersettings:plugins' => "Strumenti",
			'usersettings:plugins:opt:description' => "Configura i settaggi per i tuoi strumenti attivi.",
			'usersettings:plugins:opt:linktext' => "Configura i tuoi strumenti",
	
			'usersettings:plugins:description' => "Questo pannello ti permette di controllare e configurare i settaggi personali per gli Strumenti installati dal tuo amministratore di sistema.",
			'usersettings:statistics:label:numentities' => "Le tue entità",
	
			'usersettings:statistics:yourdetails' => "I tuoi dettagli",
			'usersettings:statistics:label:name' => "Nome completo",
			'usersettings:statistics:label:email' => "Email",
			'usersettings:statistics:label:membersince' => "Membro dal ",
			'usersettings:statistics:label:lastlogin' => "Ultima visita",
	
			
			
	
		/**
		 * Generic action words   ### Parole di azione generica ###  OK ---ma vedi note
		 */
	
			'save' => "Salva",
			'cancel' => "Cancella",
			'saving' => "Salvataggio ...",
			'update' => "Aggiornamento",
			'edit' => "Modifica",
			'delete' => "Cancella",
			'load' => "Carica",
			'upload' => "Invia",
			'ban' => "Bandisci",
			'unban' => "Riabilita",
			'enable' => "Attiva",
			'disable' => "Disattiva",
			'request' => "Richiedi",
			'complete' => "Completo",
			'open' => 'Apri',
			'close' => 'Chiudi',
			'reply' => "Rispondi",
			
			'up' => 'Sopra',
			'down' => 'Sotto',
			'top' => 'In alto',
			'bottom' => 'In basso',
	
			'invite' => "Invita",
	
			'resetpassword' => "Modifica password",
			'makeadmin' => "Nominalo amministratore",
	
			'option:yes' => "Si", 
			'option:no' => "No",  
	
			'unknown' => 'Sconosciuto',
	
			'active' => 'Attivi',
			'total' => 'Totali',
	
			'learnmore' => "Clicca qui per imparare di più.",
	
			'content' => "contenuto",
			'content:latest' => 'Attività recenti',
			'content:latest:blurb' => 'In alternativa,clicca qui per vedere le attività recenti del sito.',
			
			'link:text' => 'Vedi link',
	
		/**
		 * Generic data words  ### Parole di valore generico ###   OK
Metadata:"catalogare sotto un altro nome"
I metadata sono "dati sui dati", ovvero informazioni, generalmente strutturate e scandite in campi, relative a documenti primari "a testo pieno" (full-text), che ne permettono una più efficiente organizzazione e recupero. 
La loro funzione è permettere o comunque facilitare il raggiungimento dei seguenti obiettivi:
		 */
	
			'title' => "Titolo",
			'description' => "Descrizione",
			'tags' => "Tags",
			'spotlight' => "Riflettore",
			'all' => "Tutto",
	
			'by' => 'da',
	
			'annotations' => "Annotazioni",
			'relationships' => "Relazioni",
			'metadata' => "Metadati",
	
		/**
		 * Input / output strings  ### Input / output stringhe###  OK
		 */

			'deleteconfirm' => "Sei sicuro di voler cancellare questo articolo?",
			'fileexists' => "Un file è già stato inviato. Per rimpiazzarlo, selezionalo qui sotto:",
			
			
		 /**
         * System messages
         **/

			'systemmessages:dismiss' => "Chiudi",

	
		/**
		 * Import / export  ### Importa/Esporta###  OK
		 */
			'importsuccess' => "L'importazione del valore è stata fatta con successo",
			'importfail' => "L'importazione OpenDD del valore è fallita.",
	
		/**
		 * Time   ### Tempo ###  OK
		 */
	
			'friendlytime:justnow' => "proprio ora",
			'friendlytime:minutes' => "%s minuti fa",
			'friendlytime:minutes:singular' => "un minuto fa",
			'friendlytime:hours' => "%s ore fa",
			'friendlytime:hours:singular' => "un'ora fa",
			'friendlytime:days' => "%s giorni fa",
			'friendlytime:days:singular' => "ieri",
	
		/**
		 * Installation and system settings   ### Installazione e configurazioni del sistema ###   OK
		 */
	
			'installation:error:htaccess' => "Elgg richiede un file chiamato .htaccess per essere collocato nella cartella root della sua installazione. Abbiamo provato a creala per te, ma Elgg non ha il permesso per scrivere in quella cartella. 

La creazione di questo file è facile. Copia i contenuti del riquadro sottostante in un programma di testo e salvalo come .htaccess

",
			'installation:error:settings' => "Elgg non può trovare i propri file di configurazione. Molte settaggi di Elgg saranno configurati per te, ma è necessario che tu ci fornisca i dettagli del tuo database. Per fare questo: 

1. Rinomina engine/settings.example.php a settings.php nella tua installazione di Elgg.

2. Aprilo in un programma di testo e inserisci i dettagli del tuo database. Se non li conosci, chiedi aiuto al tuo amministratore di sistema o al supporto tecnico. 

In alternativa,puoi inserire la configurazione del tuo database qui sotto e noi proveremo e faremo questo per te...",
	
			'installation:error:configuration' => "Una volta corretto ogni richiesta di configurazione, premi riaggiorna per provare di nuovo.",
	
			'installation' => "Installazione",
			'installation:success' => "Il database di Elgg è stato installato con successo.",
			'installation:configuration:success' => "I settaggi della tua configurazione iniziale sono stati salvati. Ora registra il tuo utente iniziale; questo sarà il tuo primo amministratore di sistema.",
	
			'installation:settings' => "Settaggi di sistema",
			'installation:settings:description' => "Ora che il database di Elgg è stato installato con successo, devi inserire un alcune informazioni per avere il tuo sito pienamente funzionante. Noi proviamo a supporre dove possiamo,ma <b>tu dovresti controllare questi dettagli.</b>",
	
			'installation:settings:dbwizard:prompt' => "Inserisci i settaggi del tuo database qui sotto e schiaccia salva:",
			'installation:settings:dbwizard:label:user' => "Database user",
			'installation:settings:dbwizard:label:pass' => "Database password",
			'installation:settings:dbwizard:label:dbname' => "Elgg database",
			'installation:settings:dbwizard:label:host' => "Database hostname (di solito 'localhost')",
			'installation:settings:dbwizard:label:prefix' => "Database table prefix (di solito 'elgg')",
	
			'installation:settings:dbwizard:savefail' => "Non siamo abilitati a salvare il nuovo settings.php. Per favore salva il seguente file come engine/settings.php usando un programma di testo.",
	
			'installation:sitename' => "Il nome del tuo sito (es. \"Il mio sito di collaborazione sociale\"):",
			'installation:sitedescription' => "Breve descrizione del tuo sito(opzionale)",
			'installation:wwwroot' => "L'URL del sito, seguito da uno slash:",
			'installation:path' => "Il percorso completo alla root del tuo sito sul tuo disco,seguito da uno slash:",
			'installation:dataroot' => "Il percorso completo alla cartella dove hai inviato i files sarà memorizzato,seguito da uno slash:",
			'installation:dataroot:warning' => "Devi creare questa cartella manualmente. Potrebbe risiedere in una cartella differente rispetto alla tua installazione di Elgg.",
			'installation:language' => "La lingua principale per il tuo sito:",
			'installation:debug' => "La modalità debug fornisce informazioni extra che possono essere utilizzate per diagnosticare gli errori, però può rallentare il tuo sistema e per questo potrebbe essere utilizzata solo se avrai problemi:",
			'installation:debug:label' => "Attiva la modalità debug",
			'installation:usage' => "Questa opzione abilita Elgg a inviare l'uso delle statistiche anonime a Curverider.",
			'installation:usage:label' => "Invia l'uso di statistiche anonime",
			'installation:view' => "Inserisci la visualizzazione di base che sarà usata per il tuo sito o lascialo vuoto per la visualizzazione di default (se sei nel dubbio, lascialo in default):",
	        
			'installation:siteemail' => "Indirizzo email del sito (usuto quando invii le email del sistema)",
	
			'installation:disableapi' => "Il RESTful API è una flessibile ed estensibile interfaccia che abilita le applicazioni all'utilizzo di determinate caratteristiche di Elgg in remoto.",
			'installation:disableapi:label' => "Abilita il RESTful API",

			'upgrading' => 'In aggiornamento',
		    'upgrade:db' => 'Aggiornamento del database effettuato.',
			'upgrade:core' => 'La tua installazione di Elgg è stata aggiornata',
	
		/**
		 * Welcome  ###Benvenuto###  OK
		 */
	
			'welcome' => "Benvenuto %s",
			'welcome_message' => "Benvenuto a questa installazione di Elgg.",
	
		/**
		 * Emails   ### Posta Elettronica ###  OK
		 */
			'email:settings' => "Configurazione dell' Email",
			'email:address:label' => "Il tuo indirizzo email ",
			
			'email:save:success' => "Il nuovo indirizzo email è salvato, verifica la richiesta.",
			'email:save:fail' => "Il tuo nuovo indirizzo email non può essere salvato.",
	
			'email:confirm:success' => "Hai confermato il tuo indirizzo email!",
			'email:confirm:fail' => "Il tuo indirizzo email non può essere verificato...",
	
			'friend:newfriend:subject' => "%s ha fatto di te un amico!",
			'friend:newfriend:body' => "%s ha fatto di te un amico!

Per vedere il proprio profilo,clicca qui:

	%s

Non puoi replicare a questa email.",
	
	
			'email:validate:subject' => "%s per favore conferma il tuo indirizzo email!",
			'email:validate:body' => "Ciao %s,

Per favore conferma il tuo indirizzo email cliccando sul link sottostante:

%s
",
			'email:validate:success:subject' => "Email validata %s!",
			'email:validate:success:body' => "Ciao %s,
			
Congratulazioni,hai validato con successo il tuo indirizzo email.",
	
	
			'email:resetpassword:subject' => "Password ricambiata!",
			'email:resetpassword:body' => "Ciao %s,
			
La tua password è stata ricambiata: %s",
	
	
			'email:resetreq:subject' => "Richiesta per una nuova password.",
			'email:resetreq:body' => "Ciao %s,
			
Qualcuno (dall'indirizzo IP %s) ha richiesto una nuova password per il proprio account.

Se questa è stata richiesta da te, clicca sul link sottostante, altrimenti ignora questa email.

%s
",

	
		/**
		 * XML-RPC   OK
		 */
			'xmlrpc:noinputdata'	=>	"Valore immesso mancante",
	
		/**
		 * Comments   ###Commenti###  OK
		 */
	
			'comments:count' => "%s commenti",
			
			'riveraction:annotation:generic_comment' => '%s ha commentato su %s',
	
			'generic_comments:add' => "Aggiungi un commento",
			'generic_comments:text' => "Commento",
			'generic_comment:posted' => "Il tuo commento è stato inviato con successo.",
			'generic_comment:deleted' => "Il tuo commento è stato cancellato con successo.",
			'generic_comment:blank' => "Spiacente; è necessario che effettivamente venga scritto qualcosa nel tuo commento prima di poter essere salvato.",
			'generic_comment:notfound' => "Spiacente; Non è possibile trovare l'argomento specificato.",
			'generic_comment:notdeleted' => "Spiacente; Non è possibile cancellare questo commento.",
			'generic_comment:failure' => "E' accaduto un errore inaspettato nell'aggiungere il tuo commento. Per favore riprova.",
	
			'generic_comment:email:subject' => 'Hai un nuovo commento!',
			'generic_comment:email:body' => "Hai un nuovo commento sul tuo argomento \"%s\" da %s. Dice:

			
%s


Per rispondere o visualizzare l'argomento originale,clicca qui:

	%s

Per visualizzare il profilo di %s, clicca qui:

	%s

Non puoi rispondere a questa email.",
	
		/**
		 * Entities   ###Entità###  OK
		 */
			'entity:default:strapline' => 'Creati %s da %s',
			'entity:default:missingsupport:popup' => 'Questa entità non può essere visualizzata correttamente. Questo può accadere perchè è necessario il supporto fornito da un plugin che non è più installato.',
	
			'entity:delete:success' => 'Entità %s è stata cancellata',
			'entity:delete:fail' => 'Entità %s non è stata cancellata',
	
	
		/**
		 * Action gatekeeper   ###Intervento del controllore d’accesso###   OK
Token:
Letteralmente: segno, simbolo, emblema
Token si solito si lascia in inglese.
In generale un token è un oggetto che rappresenta qualcosaltro.
1) In una rete Token Ring, il token rappresenta la presenza nel pacchetto di un messaggio inviato da un computer e destinato ad un altro computer della rete.
2) Nella programmazione, il codice sorgente si può suddividere in 5 classi di tokens (costanti, identificatori, operatori, parole riservate e separatori), in accordo con le regole del linguaggio di programmazione.
3) Un token di sicurezza è un dispositivo fisico che, insieme a qualcosa in possesso dell'utente (come un codice), consente l'utilizzo di un servizio.
		 */
			'actiongatekeeper:missingfields' => 'Il Modulo è mancante di __token or __ts campi.',
			'actiongatekeeper:tokeninvalid' => "Abbiamo incontrato un errore (token mismatch). Questo significa probabilmente che la pagina in uso era scaduta. Per favore riprova.",
			'actiongatekeeper:timeerror' => 'La pagina che stavi usando è scaduta. Per favore riaggiorna e riprova.',
			'actiongatekeeper:pluginprevents' => 'Una estensione ha impedito a questo Modulo di poter essere inviato.',	
		
		/**
		 * Word blacklists  ?????????????????
		 */
			'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',
	
		/**
		 * Languages according to ISO 639-1 #### Lingue in base all' ISO 639-1 		 				
		 */
			"aa" => "Nord Etiope",
			"ab" => "Abcaso",
			"af" => "Africano",
			"am" => "Sud Etiope",
			"ar" => "Arabo",
			"as" => "Assamese",
			"ay" => "Andino",
			"az" => "Azero",
			"ba" => "Baschiri",
			"be" => "Bielorusso",
			"bg" => "Bulgaro",
			"bh" => "Bihari",
			"bi" => "Bislama",
			"bn" => "Bengalese",
			"bo" => "Tibetano",
			"br" => "Bretone",
			"ca" => "Catalano",
			"co" => "Corso",
			"cs" => "Ceco",
			"cy" => "Gallese",
			"da" => "Danese",
			"de" => "Tedesco",
			"dz" => "Bhutanese",
			"el" => "Greco moderno",
			"en" => "Inglese",
			"eo" => "Esperanto",
			"es" => "Spagnolo",
			"et" => "Estone",
			"eu" => "Basco",
			"fa" => "Persiano",
			"fi" => "Finlandese",
			"fj" => "Fijiano",
			"fo" => "Faroese",
			"fr" => "Francese",
			"fy" => "Fresone",
			"ga" => "Irlandese",
			"gd" => "Gaelico",
			"gl" => "Galiziano",
			"gn" => "Guarani",
			"gu" => "Gujarati",
			"he" => "Ebraico",
			"ha" => "Hausa",
			"hi" => "Indi",
			"hr" => "Croato",
			"hu" => "Ungherese",
			"hy" => "Armeno",
			"ia" => "Interlingua",
			"id" => "Indonesiano",
			"ie" => "Interlingue",
			"ik" => "Inupiak(Alaska)",
			"is" => "Islandese",
			"it" => "Italiano",
			"iu" => "Estone",
			"iw" => "Ebreo(obsoleto)",
			"ja" => "Giapponese",
			"ji" => "Yiddish (obsoleto)",
			"jw" => "Javanese",
			"ka" => "Georgiano",
			"kk" => "Kazako",
			"kl" => "Groenlandese",
			"km" => "Cambogiano",
			"kn" => "Canarese",
			"ko" => "Coreano",
			"ks" => "Kashmir",
			"ku" => "Curdo",
			"ky" => "Kirghiso",
			"la" => "Latino",
			"ln" => "Lingala",
			"lo" => "Laothian",
			"lt" => "Lituano",
			"lv" => "Lettone",
			"mg" => "Malgascio",
			"mi" => "Maori",
			"mk" => "Macedone",
			"ml" => "Malayalam",
			"mn" => "Mongolo",
			"mo" => "Moldavo",
			"mr" => "Marathi",
			"ms" => "Malese",
			"mt" => "Maltese",
			"my" => "Burmese",
			"na" => "Nauru",
			"ne" => "Nepalese",
			"nl" => "Olandese",
			"no" => "Norvegese",
			"oc" => "Provenzale / Occitano",
			"om" => "Oromo (Etiope)",
			"or" => "Oriya",
			"os" => "Osseto",
			"pa" => "Punjabi",
			"pl" => "Polacco",
			"ps" => "Pashtun",
			"pt" => "Portoghese",
			"qu" => "Quechua",
			"rm" => "Rhaeto-Romance",
			"rn" => "Kirundi",
			"ro" => "Rumeno",
			"ru" => "Russo",
			"rw" => "Ruandese",
			"sa" => "Sanscrito",
			"sd" => "Sindhi",
			"sg" => "Sangro",
			"sh" => "Serbo-Croato",
			"si" => "Singalese",
			"sk" => "Slovacco",
			"sl" => "Sloveno",
			"sm" => "Samoa",
			"sn" => "Shona",
			"so" => "Somalo ",
			"sq" => "Albanese",
			"sr" => "Serbo",
			"ss" => "Swazilandese",
			"st" => "Sesotho",
			"su" => "Sudanese",
			"sv" => "Svedese ",
			"sw" => "Swahili",
			"ta" => "Tamil",
			"te" => "Telugu (Indiano)",
			"tg" => "Persiano",
			"th" => "Thailandese",
			"ti" => "Tigrino",
			"tk" => "Turcomanno",
			"tl" => "Filippino",
			"tn" => "Nigeriano",
			"to" => "Polinesiano",
			"tr" => "Turco",
			"ts" => "Mozambicano",
			"tt" => "Tataro",
			"tw" => "Ghanese",
			"ug" => "Uigur",
			"uk" => "Ucraino",
			"ur" => "Urdu",
			"uz" => "Uzbeko ",
			"vi" => "Vietnamita",
			"vo" => "Volapuk",
			"wo" => "Wolof",
			"xh" => "Xhosa",
			"yi" => "Yiddish", 
			"yo" => "Yoruba",
			"za" => "Zuang",
			"zh" => "Cinese",
			"zu" => "Zulu",
	);
	
	add_translation("it",$italian);

?>
