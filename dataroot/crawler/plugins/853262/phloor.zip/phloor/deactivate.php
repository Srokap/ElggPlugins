<?php

// remove former admin notices
elgg_delete_admin_notice('phloor_min_required_php_vesion');
