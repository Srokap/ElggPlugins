<?php
	/**
	 * Elgg highslide
	 * 
	 */

	function highslide_init() 
	{
		global $CONFIG;
				
				
		// Extend CSS
		extend_view('css', 'highslide/css');
		
		// Highslide hook
		extend_view('metatags','highslide/metatags');
	}
		
	

	// Make sure highslide_init is called on initialisation
	register_elgg_event_handler('init','system','highslide_init');
	

?>