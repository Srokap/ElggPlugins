= Translation Editor =

Manage translations

== Contents ==

1. Features
2. Special thanks

== 1. Features ==
- Edit translations
- Assign multiple translators
- Add custom languages
- Add custom keys
- Caching of language files

== 2. Special thanks ==
Special thanks goes out to to following people:

Jean-Baptiste Duclos (http://community.elgg.org/pg/profile/Duclos) 
For providing a French translation of version 1.1