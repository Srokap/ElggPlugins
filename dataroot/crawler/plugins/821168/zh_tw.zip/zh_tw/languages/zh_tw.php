<?php
/**
 * Core English Language
 *
 * @package Elgg.Core
 * @subpackage Languages.English
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com 
 */

$traditionalChinese = array(
/**
 * Sites
 */

	'item:site' => '網站',

/**
 * Sessions
 */

	'login' => "登入",
	'loginok' => "您已經登入",
	'loginerror' => "無法登入系統. 請確認您的資料後再試一次.",
	'login:empty' => "使用者名稱與密碼是必要欄位.",
	'login:baduser' => "無法載入您的使用者帳號.",
	'auth:nopams' => "內部出現錯誤. 未安裝使用者驗證機制",

	'logout' => "登出",
	'logoutok' => "您已經登出",
	'logouterror' => "無法登出, 請再試一次.",

	'loggedinrequired' => "在瀏覽該頁面前, 您必須先登入.",
	'adminrequired' => "要瀏覽該頁面, 您必須是系統管理員.",
	'membershiprequired' => "要瀏覽該頁面, 您必須是該群組的成員.",


/**
 * Errors
 */
	'exception:title' => "嚴重錯誤",

	'actionundefined' => "您所要求的動作 (%s) 系統並未定義.",
	'actionloggedout' => "抱歉, 您無法在登出後執行這個動作.",
	'actionnotfound' => "找不到執行動作 %s 所需的檔案.",
	'actionunauthorized' => '您未被授權進行這個動作',

	'InstallationException:SiteNotInstalled' => '無法處理這個要求. 這個網站 '
		. ' 未被適當配置, 或者資料庫故障.',
	'InstallationException:MissingLibrary' => '無法載入 %s',
	'InstallationException:CannotLoadSettings' => 'Elgg無法載入設定檔. 檔案不存在或者是出現存取權受限的問題.',

	'SecurityException:Codeblock' => "拒絕執行私有的程式碼區塊",
	'DatabaseException:WrongCredentials' => "Elgg無法使用目前的證書連結到資料庫. 請檢查設定檔.",
	'DatabaseException:NoConnect' => "Elgg無法選取資料庫'%s', 請檢查該資料庫是否已經建立, 並且有權存取它.",
	'SecurityException:FunctionDenied' => "存取私有功能 '%s' 被拒.",
	'DatabaseException:DBSetupIssues' => "出現一些問題: ",
	'DatabaseException:ScriptNotFound' => "Elgg無法找到所需的資料程代碼, 位於%s.",
	'DatabaseException:InvalidQuery' => "不合法的查詢",

	'IOException:FailedToLoadGUID' => "無法從GUID:%d中載入新的%s",
	'InvalidParameterException:NonElggObject' => "傳遞一個非Elgg物件到一個Elgg物件的建構元!",
	'InvalidParameterException:UnrecognisedValue' => "傳遞到(物件)建構元的值無法辨識.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d 不是一個合法的 %s",

	'PluginException:MisconfiguredPlugin' => "%s (guid: %s) 是一個未經適當組態的插件(plugin). 它已經被停用. 請搜尋Elgg wiki以便找出可能原因(http://docs.elgg.org/wiki/).",
	'PluginException:CannotStart' => '%s (guid: %s) 無法啟動並被停止, 原因為: %s',
	'PluginException:InvalidID' => "%s 是一個不合法的插件ID.",
	'PluginException:InvalidPath' => "%s 是一個不合法的插件路徑.",
	'PluginException:InvalidManifest' => '插件 %s 的資訊清單(manifest)檔案不合法',
	'PluginException:InvalidPlugin' => '%s 不是一個合法的插件.',
	'PluginException:InvalidPlugin:Details' => '%s 不是一個合法的插件: %s',
	'PluginException:NullInstantiated' => 'Elgg插件不允許為空案例. 您必須傳遞一個GUID, 一個插件ID, 或者是完整的路徑.',

	'ElggPlugin:MissingID' => '找不到插件ID (guid %s)',
	'ElggPlugin:NoPluginPackagePackage' => '找不到插件ID為 %s (guid %s) 的ElggPluginPackage',

	'ElggPluginPackage:InvalidPlugin:MissingFile' => '在封包中找不到檔案 %s',
	'ElggPluginPackage:InvalidPlugin:InvalidDependency' => '不合法的相依型別 "%s"',
	'ElggPluginPackage:InvalidPlugin:InvalidProvides' => '不合法的給定型別 "%s"',
	'ElggPluginPackage:InvalidPlugin:CircularDep' => '不合法的 %s 相依檔 "%s" (在插件 %s中).  插件相互衝突, 或需提供更多資訊!',

	'ElggPlugin:Exception:CannotIncludeFile' => '無法引入 %s 到插件 %s (guid: %s) , 位於 %s.',
	'ElggPlugin:Exception:CannotRegisterViews' => '無法開啟檢視路徑, 插件為 %s (guid: %s), 位於 %s.',
	'ElggPlugin:Exception:CannotRegisterLanguages' => '無法註冊語言, 插件為 %s (guid: %s), 位於 %s.',
	'ElggPlugin:Exception:NoID' => '欠缺ID, 插件的guid為 %s!',

	'PluginException:ParserError' => '解析資訊清單錯誤, API版本為 %s, 位於插件: %s.',
	'PluginException:NoAvailableParser' => '無法找到資訊清單的解析器, API版本為 %s, 位於插件: %s.',
	'PluginException:ParserErrorMissingRequiredAttribute' => "資訊清單遺失必要的 '%s' 屬性(attribute), 插件為 %s.",

	'ElggPlugin:Dependencies:Requires' => '必要的',
	'ElggPlugin:Dependencies:Suggests' => '建議',
	'ElggPlugin:Dependencies:Conflicts' => '衝突',
	'ElggPlugin:Dependencies:Conflicted' => '已發生衝突',
	'ElggPlugin:Dependencies:Provides' => '提供',
	'ElggPlugin:Dependencies:Priority' => '優先',

	'ElggPlugin:Dependencies:Elgg' => 'Elgg版本',
	'ElggPlugin:Dependencies:PhpExtension' => 'PHP 擴充: %s',
	'ElggPlugin:Dependencies:PhpIni' => 'PHP ini 設定: %s',
	'ElggPlugin:Dependencies:Plugin' => '插件: %s',
	'ElggPlugin:Dependencies:Priority:After' => '在 %s 之後',
	'ElggPlugin:Dependencies:Priority:Before' => '在 %s 之前',
	'ElggPlugin:Dependencies:Priority:Uninstalled' => '%s 未安裝',
	'ElggPlugin:Dependencies:Suggests:Unsatisfied' => '遺失',

	'ElggPlugin:InvalidAndDeactivated' => '%s 是一個不合法的插件, 已經被停用.',

	'InvalidParameterException:NonElggUser' => "傳遞一個非ElggUser到ElggUser的建構元!",

	'InvalidParameterException:NonElggSite' => "傳遞一個非ElggSite到ElggSite的建構元!",

	'InvalidParameterException:NonElggGroup' => "傳遞一個非ElggGroup到ElggGroup的建構元!",

	'IOException:UnableToSaveNew' => "無法儲存新的 %s",

	'InvalidParameterException:GUIDNotForExport' => "在匯出的過程中未指定GUID, 這應該是不可能發生的.",
	'InvalidParameterException:NonArrayReturnValue' => "項目的序列化函式傳遞了一個非陣列的傳回值",

	'ConfigurationException:NoCachePath' => "快取的路徑被設定為nothing!",
	'IOException:NotDirectory' => "%s 不是一個目錄名稱.",

	'IOException:BaseEntitySaveFailed' => "無法儲存新物件的基底項目資訊!",
	'InvalidParameterException:UnexpectedODDClass' => "import() 傳遞一個未預期的ODD類別",
	'InvalidParameterException:EntityTypeNotSet' => "必須指定項目的型別.",

	'ClassException:ClassnameNotClass' => "%s 並非一個 %s.",
	'ClassNotFoundException:MissingClass' => "找不到類別 '%s' , 插件可能不存在",
	'InstallationException:TypeNotSupported' => "不支援型別 %s. 可能是在安裝的過程中出現錯誤, 最大的可能是升級時安裝不完全.",

	'ImportException:ImportFailed' => "無法匯入元表 %d",
	'ImportException:ProblemSaving' => "挽救了一個問題: %s",
	'ImportException:NoGUID' => "新項目被建立, 但沒有GUID, 這應該是不可能發生的.",

	'ImportException:GUIDNotFound' => "無法找到項目 '%d'.",
	'ImportException:ProblemUpdatingMeta' => "在更新 '%s' (項目 '%d')時發生問題",

	'ExportException:NoSuchEntity' => "不存在GUID:%d",

	'ImportException:NoODDElements' => "在匯入的資料中, 找不到OpenDD項目, 匯入失敗.",
	'ImportException:NotAllImported' => "部份項目未被匯入.",

	'InvalidParameterException:UnrecognisedFileMode' => "無法辨識的檔案模式 '%s'",
	'InvalidParameterException:MissingOwner' => "檔案 %s (檔案的 guid:%d) (所有者 guid:%d) 欠缺一個所有者!",
	'IOException:CouldNotMake' => "無法制作 %s",
	'IOException:MissingFileName' => "在開啟一個檔案之前, 您必須指定一個名稱.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "無法載入filestore類別 %s , 檔案為 %u",
	'NotificationException:NoNotificationMethod' => "未指定通知的方法.",
	'NotificationException:NoHandlerFound' => "無法找到 '%s' 的handler, 或者它無法被呼叫.",
	'NotificationException:ErrorNotifyingGuid' => "在通知 %d時發生錯誤",
	'NotificationException:NoEmailAddress' => "無法找到GUID:%d的電子郵件位址",
	'NotificationException:MissingParameter' => "遺失一個必要的參數, '%s'",

	'DatabaseException:WhereSetNonQuery' => "Where子句中, 包含了非Where查詢的內容",
	'DatabaseException:SelectFieldsMissing' => "在一個選取的型別查詢中, 遺漏欄位",
	'DatabaseException:UnspecifiedQueryType' => "無法辨識, 或未指定查詢的類別.",
	'DatabaseException:NoTablesSpecified' => "查詢中未指定資料表.",
	'DatabaseException:NoACL' => "在查詢中欠缺存取控制",

	'InvalidParameterException:NoEntityFound' => "未找到任何項目, 可能是不存在, 或者您未存取它.",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s無法找到, 或者您無法存取它.",
	'InvalidParameterException:IdNotExistForGUID' => "抱歉, '%s' 不存在於guid:%d中",
	'InvalidParameterException:CanNotExportType' => "抱歉, 我無法匯出'%s'",
	'InvalidParameterException:NoDataFound' => "無法找到任何資料.",
	'InvalidParameterException:DoesNotBelong' => "不屬於該項目.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "不屬於該項目, 或不參照於該項目.",
	'InvalidParameterException:MissingParameter' => "遺失參數, 您需要提供一個GUID.",
	'InvalidParameterException:LibraryNotRegistered' => '%s 不是一個已註冊的程式庫',

	'APIException:ApiResultUnknown' => "API Result是一個未知的型別, 這應該是不可能發生的.",
	'ConfigurationException:NoSiteID' => "未指定網站ID.",
	'SecurityException:APIAccessDenied' => "抱歉, 管理員已關閉API的存取.",
	'SecurityException:NoAuthMethods' => "未能找到可以驗證該API要求的驗證方法.",
	'SecurityException:ForwardFailedToRedirect' => '由於標頭資料已被傳送, 無法執行重新導向, 基於安全因素已停止執行. 請搜尋http://docs.elgg.org/以便取得更多資訊.',
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "在呼叫expose_method()時, 未設定所需方法或函式",
	'InvalidParameterException:APIParametersArrayStructure' => "在呼叫匯出方法'%s'時, 參數的陣列結構不正確",
	'InvalidParameterException:UnrecognisedHttpMethod' => "無法辨識的方法 %s (在api的方法 '%s'中)",
	'APIException:MissingParameterInMethod' => "遺失參數 %s (在方法 %s中)",
	'APIException:ParameterNotArray' => "%s 並不是一個陣列.",
	'APIException:UnrecognisedTypeCast' => "無法辨識的型別, 當強制轉換 %s時 (變數: '%s', 方法為: '%s')",
	'APIException:InvalidParameter' => "發現不合法的參數: '%s' (在方法 '%s'中).",
	'APIException:FunctionParseError' => "%s(%s) 出現解析錯誤.",
	'APIException:FunctionNoReturn' => "%s(%s) 未傳回值.",
	'APIException:APIAuthenticationFailed' => "由於API驗證的原因, 呼叫方法失敗",
	'APIException:UserAuthenticationFailed' => "由於使用者驗證的原因, 呼叫方法失敗",
	'SecurityException:AuthTokenExpired' => "驗證用的token不是遺失, 不合法, 就是過期了.",
	'CallException:InvalidCallMethod' => "%s 被呼叫時, 必須使用 '%s'",
	'APIException:MethodCallNotImplemented' => "'%s'方法的呼叫未被執行.",
	'APIException:FunctionDoesNotExist' => "函式或方法 '%s' 無法被呼叫",
	'APIException:AlgorithmNotSupported' => "演算法 '%s' 未被支援, 或者被停用.",
	'ConfigurationException:CacheDirNotSet' => "未設定 'cache_path' 快取目錄.",
	'APIException:NotGetOrPost' => "要求的方法, 必須是GET或POST",
	'APIException:MissingAPIKey' => "遺失API key",
	'APIException:BadAPIKey' => "損壞的API key",
	'APIException:MissingHmac' => "遺失X-Elgg-hmac標頭",
	'APIException:MissingHmacAlgo' => "遺失 X-Elgg-hmac-algo 的標頭",
	'APIException:MissingTime' => "遺失 X-Elgg-time 的標頭",
	'APIException:MissingNonce' => "遺失 X-Elgg-nonce 的標頭",
	'APIException:TemporalDrift' => "X-Elgg-time的時間遠超過過去或未來. Epoch.",
	'APIException:NoQueryString' => "在查詢的字串中沒有資料",
	'APIException:MissingPOSTHash' => "遺失 X-Elgg-posthash 的標頭",
	'APIException:MissingPOSTAlgo' => "遺失 X-Elgg-posthash_algo 的標頭",
	'APIException:MissingContentType' => "遺失張貼資料的內容型別",
	'SecurityException:InvalidPostHash' => "張貼的資料hash不合法 - 預期為 %s 但實際為 %s.",
	'SecurityException:DupePacket' => "Packet的簽署已經存在.",
	'SecurityException:InvalidAPIKey' => "不合法或遺漏的API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "呼叫的方法 '%s' 目前未被支援.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC 方法呼叫 call '%s' 未被執行.",
	'InvalidParameterException:UnexpectedReturnFormat' => "呼叫方法 '%s' 傳回不被預期的結果.",
	'CallException:NotRPCCall' => "呼叫看起來不是合法的 XML-RPC call",
	
	'PluginException:NoPluginName' => "無法找到該插件的名稱",

	'SecurityException:authenticationfailed' => "使用者無法被驗證",

	'CronException:unknownperiod' => '%s 不是一個可辨識的週期.',

	'SecurityException:deletedisablecurrentsite' => '您無法刪除或停用正在瀏覽的網站!',

	'RegistrationException:EmptyPassword' => '密碼欄位不能為空',
	'RegistrationException:PasswordMismatch' => '兩個密碼必須完全相符',
	'LoginException:BannedUser' => '您的帳號已被凍結, 無法登入',
	'LoginException:UsernameFailure' => '無法登入. 請檢查您的使用者名稱與密碼.',
	'LoginException:PasswordFailure' => '無法登入. 請檢查您的使用者名稱與密碼.',
	'LoginException:AccountLocked' => '由於多次登入失敗, 您的帳號已經被鎖定.',
	'LoginException:ChangePasswordFailure' => '密碼驗證失敗.',

	'memcache:notinstalled' => 'PHP memcache模組未安裝, 您必須先安裝php5-memcache',
	'memcache:noservers' => '未定義memcache服務器, 請指定$CONFIG->memcache_servers 變數',
	'memcache:versiontoolow' => 'Memcache 至少需要版本 %s , 您目前執行的版本為 %s',
	'memcache:noaddserver' => '多重伺服器的支援已經被停止, 您或許需要更新您的PECL memcache 程式庫',

	'deprecatedfunction' => '警告: 這段程使碼使用了不支援的函式 \'%s\' , 且不相容於目前版本的Elgg',

	'pageownerunavailable' => '警告: 本頁的所有者 %d 無法存取!',
	'viewfailure' => '在檢視 %s中存在內部錯誤',
	'changebookmark' => '請變更本頁的書籤',
	'noaccess' => '該頁的內容已被移除, 不合法, 或者您未被授權瀏覽.',

/**
 * API
 */
	'system.api.list' => "列出系統中所有可用的API calls.",
	'auth.gettoken' => "叫用這個API, 會讓使用者取得驗證的權仗(token), 可以被用來驗證之後的API叫用. 傳遞時請使用參數auth_token.",	

/**
 * User details
 */

	'name' => "顯示的名稱",
	'email' => "電子郵件位址",
	'username' => "使用者名稱",
	'loginusername' => "使用者名稱或電子郵件",
	'password' => "密碼",
	'passwordagain' => "密碼 (請再輸入一次以便驗證)",
	'admin_option' => "將這個使用者設為管理員?",

/**
 * Access
 */

 	'PRIVATE' => "私人",
	'LOGGED_IN' => "登入使用者",
	'PUBLIC' => "公開",
	'access:friends:label' => "朋友",
	'access' => "權限",

/**
 * Dashboard and widgets 儀表板與小工具
 */

	'dashboard' => "儀表板",
	'dashboard:nowidgets' => "儀表板可以用來追蹤本站中,與您相關或感興趣的活動與內容.",

	'widgets:add' => '添加小工具',
	'widgets:add:description' => "點擊底下小工具的按鈕, 以便將它添加到本頁中.",
	'widgets:position:fixed' => '(調整在本頁中的位置)',
	'widget:unavailable' => '您已經添加過這個小工具',
	'widget:numbertodisplay' => '顯示的項目數量',

	'widget:delete' => '移除 %s',
	'widget:edit' => '自訂小工具',

	'widgets' => "小工具",
	'widget' => "小工具",
	'item:object:widget' => "小工具",
	'widgets:save:success' => "這個小工具已保存.",
	'widgets:save:failure' => "無法保存這個小工具, 請再試一次.",
	'widgets:add:success' => "成功添加這個小工具.",
	'widgets:add:failure' => "無法加入這個小工具.",
	'widgets:move:failure' => "無法保存這個小工具的位置.",
	'widgets:remove:failure' => "無法移除這個小工具",

/**
 * Groups
 */

	'group' => "群組",
	'item:group' => "群組",

/**
 * Users
 */

	'user' => "使用者",
	'item:user' => "使用者",

/**
 * Friends
 */

	'friends' => "好友",
	'friends:yours' => "我的好友",
	'friends:owned' => "%s的好友",
	'friend:add' => "加為好友",
	'friend:remove' => "移除好友",

	'friends:add:successful' => "您已經成功將 %s 添加為好友.",
	'friends:add:failure' => "無法將 %s 添加為好友. 請再試一次.",

	'friends:remove:successful' => "您已經成功將 %s 從好友中移除.",
	'friends:remove:failure' => "無法將 %s 從您的好友中移除. 請再試一次.",

	'friends:none' => "這位使用者尚未添加任何好友.",
	'friends:none:you' => "您目前尚未添加任何好友.",

	'friends:none:found' => "未發現任何好友.",

	'friends:of:none' => "目前尚無任何人將這位使用者添加為好友.",
	'friends:of:none:you' => "目前尚無任何人將您添加為好友. 請試著分享一些資訊, 並完善您的個人檔案, 以便更多人能找到您!",

	'friends:of:owned' => "將 %s 添加為好友的使用者",

	'friends:of' => "我是...的好友",
	'friends:collections' => "好友集團",
	'collections:add' => "新增集團",
	'friends:collections:add' => "添加好友集團",
	'friends:addfriends' => "選取好友",
	'friends:collectionname' => "集團名稱",
	'friends:collectionfriends' => "在集團中的好友",
	'friends:collectionedit' => "編輯這個集團",
	'friends:nocollections' => "您目前尚未擁有任何集團.",
	'friends:collectiondeleted' => "您的集團已將被刪除.",
	'friends:collectiondeletefailed' => "無法刪除這個集團. 可能是您未擁有足夠的權限, 或者發生了其他問題.",
	'friends:collectionadded' => "已經成功建立該集團",
	'friends:nocollectionname' => "在正式建立之前, 您必須給該集團指定一個名稱.",
	'friends:collections:members' => "集團的成員",
	'friends:collections:edit' => "編輯集團",
	'friends:collections:edited' => "已被保存的集團",
	'friends:collection:edit_failed' => '無法保存集團.',

	'friendspicker:chararray' => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',

	'avatar' => '個人頭像',
	'avatar:create' => '建立您的個人頭像',
	'avatar:edit' => '編輯您的個人頭像',
	'avatar:preview' => '預覽',
	'avatar:upload' => '上傳新的個人頭像',
	'avatar:current' => '目前的個人頭像',
	'avatar:crop:title' => '個人頭像裁剪工具',
	'avatar:upload:instructions' => "您的個人頭像將會顯示在整個網站中. 只要您高興, 您可以隨時變更個人頭像. (接受的檔案格式: GIF, JPG or PNG)",
	'avatar:create:instructions' => '單擊並拖放底下的方框, 以便適當地裁剪您的個人頭像. 預覽效果會顯示在右方的方塊中. 一旦您滿意後, 請單擊\'建立您的個人頭像\'. 這個裁剪的版本即會成為本站中, 代表您形象的個人頭像.',
	'avatar:upload:success' => '個人頭像已成功上傳',
	'avatar:upload:fail' => '個人頭像上傳失敗',
	'avatar:resize:fail' => '調整個人頭像的大小失敗',
	'avatar:crop:success' => '裁剪個人頭像成功',
	'avatar:crop:fail' => '裁剪個人頭像失敗',

	'profile:edit' => '編輯個人檔案',
	'profile:aboutme' => "關於我",
	'profile:description' => "關於我",
	'profile:briefdescription' => "簡述",
	'profile:location' => "所處位置",
	'profile:skills' => "技能",
	'profile:interests' => "興趣",
	'profile:contactemail' => "聯繫的電子郵件",
	'profile:phone' => "電話",
	'profile:mobile' => "手機",
	'profile:website' => "個人網站",
	'profile:twitter' => "Twitter使用者名稱",
	'profile:saved' => "您的個人檔案已成功儲存.",

	'profile:field:text' => '簡短的文字',
	'profile:field:longtext' => '大文字區塊',
	'profile:field:tags' => '標籤',
	'profile:field:url' => '網站位址',
	'profile:field:email' => '電子郵件',
	'profile:field:location' => '位置',
	'profile:field:date' => '日期',

	'admin:appearance:profile_fields' => '編輯個人檔案的欄位',
	'profile:edit:default' => '編輯個人檔案的欄位',
	'profile:label' => "個人檔案的標題",
	'profile:type' => "個人檔案的資料型別",
	'profile:editdefault:delete:fail' => '移除預設的個人檔案項目欄位失敗',
	'profile:editdefault:delete:success' => '個人檔案的欄位已刪除',
	'profile:defaultprofile:reset' => '個人檔案重設為系統預設值',
	'profile:resetdefault' => '重設為預設的個人檔案',
	'profile:explainchangefields' => "您可以使用底下的表單, 以自訂的欄位取代現存的個人檔案欄位 \n\n 請指定新的個人檔案欄位的標題, 例如, '最喜歡的名稱', 然後選取欄位的資料型別 (如: 文字, url, 標籤), 然後單擊'新增'按鈕. 若想重新排列欄位順序, 請直接拖放欄位標題後面的標誌. 若要編輯欄位的標題 - 請點擊標題上的文字. \n\n 任何時候, 您可以回覆到系統的預設值, 但您所做的變更將會遺失.",
	'profile:editdefault:success' => '新的個人檔案欄位已添加',
	'profile:editdefault:fail' => '預設的個人檔案無法被儲存',


/**
 * Feeds
 */
	'feed:rss' => '訂閱本頁RSS',
/**
 * Links
 */
	'link:view' => '查看連結',
	'link:view:all' => '查看所有',


/**
 * River最新動態
 */
	'river' => "最新動態",
	'river:friend:user:default' => "%s 現在是 %s的好友",
	'river:update:user:avatar' => '%s 建立一個新的個人頭像',
	'river:update:user:profile' => '%s 已更新他的個人檔案',
	'river:noaccess' => '您沒有查看這個項目的授權.',
	'river:posted:generic' => '%s 張貼',
	'riveritem:single:user' => '一位使用者',
	'riveritem:plural:user' => '一些使用者',
	'river:ingroup' => '在群組 %s中',
	'river:none' => '沒有新的動態',
	'river:update' => '更新了 %s',

	'river:widget:title' => "動態",
	'river:widget:description' => "顯示最新的動態",
	'river:widget:type' => "動態的類別",
	'river:widgets:friends' => '好友動態',
	'river:widgets:all' => '所有網站的動態',

/**
 * Notifications
 */
	'notifications:usersettings' => "通知的設定",
	'notifications:methods' => "請指定您想使用的方式.",
	'notification:method:email' => '電子郵件',

	'notifications:usersettings:save:ok' => "通知的設定已經成功儲存.",
	'notifications:usersettings:save:fail' => "儲存通知的設定時發生問題.",

	'user.notification.get' => '傳回某特定使用者的通知設定.',
	'user.notification.set' => '設定某特定使用者的通知設定.',
/**
 * Search
 */

	'search' => "搜尋",
	'searchtitle' => "搜尋: %s",
	'users:searchtitle' => "搜尋使用者: %s",
	'groups:searchtitle' => "搜尋群組: %s",
	'advancedsearchtitle' => "%s 符合條件的結果為 %s",
	'notfound' => "未找到符合條件的搜尋結果.",
	'next' => "下一個",
	'previous' => "前一個",

	'viewtype:change' => "變更清單的類別",
	'viewtype:list' => "清單檢視",
	'viewtype:gallery' => "相薄檢視",

	'tag:search:startblurb' => "符合標籤的項目 '%s':",

	'user:search:startblurb' => "符合的使用者 '%s':",
	'user:search:finishblurb' => "要查看更多的項目, 請點擊.",

	'group:search:startblurb' => "符合的群組 '%s':",
	'group:search:finishblurb' => "要查看更多的項目, 請點擊.",
	'search:go' => '執行',
	'userpicker:only_friends' => '只包含好友',

/**
 * Account
 */

	'account' => "帳號",
	'settings' => "設定",
	'tools' => "工具",

	'register' => "註冊",
	'registerok' => "您已經成功的註冊為 %s.",
	'registerbad' => "由於不名原因註冊失敗.",
	'registerdisabled' => "系統管理員關閉註冊功能",
	'register:fields' => '所有的欄位都是必要的',

	'registration:notemail' => '您提供的電子郵件信箱位址格式不正確.',
	'registration:userexists' => '使用者名稱已存在',
	'registration:usernametooshort' => '使用者名稱至少需 %u 個字元.',
	'registration:passwordtooshort' => '密碼至少需 %u 個字元.',
	'registration:dupeemail' => '這個電子郵件位址已經被註冊.',
	'registration:invalidchars' => '抱歉, 使用者名稱中包含不合法的字元. 以下字元為不合法者: %s',
	'registration:emailnotvalid' => '抱歉, 您輸入的電子郵件不合法',
	'registration:passwordnotvalid' => '抱歉, 您輸入的密碼格式不合法',
	'registration:usernamenotvalid' => '抱歉, 您輸入的使用者名稱不合法',

	'adduser' => "添加使用者",
	'adduser:ok' => "您已成功地添加一位新的使用者.",
	'adduser:bad' => "新的使用者無法被添加.",

	'user:set:name' => "帳戶名稱設定",
	'user:name:label' => "顯示的名稱",
	'user:name:success' => "成功變功您的名稱.",
	'user:name:fail' => "無法變更名稱, 請確認您的名稱長度符合規定, 然後再試一次.",

	'user:set:password' => "帳戶密碼",
	'user:current_password:label' => '目前的密碼',
	'user:password:label' => "新的密碼",
	'user:password2:label' => "新的密碼",
	'user:password:success' => "密碼已變更",
	'user:password:fail' => "無法變更密碼.",
	'user:password:fail:notsame' => "兩次輸入的密碼不同!",
	'user:password:fail:tooshort' => "密碼太短!",
	'user:password:fail:incorrect_current_password' => '輸入的舊密碼不正確.',
	'user:resetpassword:unknown_user' => '不合法的使用者.',
	'user:resetpassword:reset_password_confirm' => '重設您的密碼, 系統會發一封郵件將新密碼傳送到您註冊的郵件信箱.',

	'user:set:language' => "語言設定",
	'user:language:label' => "選擇的語言",
	'user:language:success' => "語言設定已更新.",
	'user:language:fail' => "語言設定無法儲存.",

	'user:username:notfound' => '找不到使用者名稱: %s .',

	'user:password:lost' => '忘記密碼',
	'user:password:resetreq:success' => '索取新密碼的電子郵件已發至您的信箱',
	'user:password:resetreq:fail' => '無法索取新密碼.',

	'user:password:text' => '要索取一個新的密碼, 請輸入您的使用者名稱, 並按下索取按鈕.',

	'user:persistent' => '記住我',

	'walled_garden:welcome' => '歡迎',

/**
 * Administration
 */
	'menu:page:header:administer' => '管理',
	'menu:page:header:configure' => '組態',
	'menu:page:header:develop' => '開發',
	'menu:page:header:default' => '其他',

	'admin:view_site' => '瀏覽網站',
	'admin:loggedin' => '以 %s登入',
	'admin:menu' => '功能表',

	'admin:configuration:success' => "您的設定已經儲存.",
	'admin:configuration:fail' => "您的設定無法儲存.",

	'admin:unknown_section' => '不合法的管理區塊.',

	'admin' => "管理",
	'admin:description' => "管理面板用來協助您控制系統的所有功能, 從使用者管理到插件的行為. 選取下面的選項開始進行管理.",

	'admin:statistics' => "統計",
	'admin:statistics:overview' => '概觀',

	'admin:appearance' => '外觀',
//	'admin:administer_utilities' => '公用程式',
// GGYY.COM修改
// 原程式有問題
	'admin:utilities' => '公用程式',
	'admin:utilities:reportedcontent' => '舉報的內容',
	'admin:utilities:logbrowser' => '記錄瀏覽器相關資料',
//	'admin:administor_utilities:' => '公用程式',	
	'admin:develop_utilities' => '公用程式',

	'admin:users' => "使用者",
	'admin:users:online' => '在線人員',
	'admin:users:newest' => '最新加入的使用者',
	'admin:users:add' => '添加新的使用者',
	'admin:users:description' => "管理面板用來協助您控制使用者的設定. 選取下面的選項開始進行管理.",
	'admin:users:adduser:label' => "點擊這裡以便添加一位新的使用者...",
	'admin:users:opt:linktext' => "使用者組態...",
	'admin:users:opt:description' => "使用者與帳號資訊組態. ",
	'admin:users:find' => '尋找',

	'admin:settings' => '設定',
	'admin:settings:basic' => '基本設定',
	'admin:settings:advanced' => '進階設定',
// GGYY.COM更正原系統錯誤
	'admin:settings:plugin_settings:garbagecollector' => '自動垃圾回收',
	'admin:settings:plugin_settings:groups' => '群組',
	'admin:settings:plugin_settings:logrotate' => '封存系統記錄檔',
	
	'admin:site:description' => "管理面板用來協助您控制整體的設定. 選取下面的選項開始進行管理.",
	'admin:site:opt:linktext' => "網站組態...",
	'admin:site:access:warning' => "變更存取設定, 只會影響未來建立內容的權限.",

	'admin:dashboard' => '儀表板',
	'admin:widget:online_users' => '在線人員',
	'admin:widget:online_users:help' => '列出目前在線人員清單',
	'admin:widget:new_users' => '新使用者',
	'admin:widget:new_users:help' => '列出最新的使用者',
	'admin:widget:content_stats' => '內容統計',
	'admin:widget:content_stats:help' => '保持使用者建立內容的追蹤',
	'widget:content_stats:type' => '內容的類別',
	'widget:content_stats:number' => '數量',

	'admin:widget:admin_welcome' => '歡迎',
	'admin:widget:admin_welcome:help' => "Elgg管理區域的簡短介紹",
	'admin:widget:admin_welcome:intro' =>
'歡迎使用Elgg! 目前您正在使用管理儀表板. 可以用來追蹤網站的最新動態時.',

	'admin:widget:admin_welcome:admin_overview' =>
"右方的功能表提供了相關的管理機制, 由上至下分別為"
. " 三個區塊:
	<dl>
		<dt>管理</dt><dd>與管理有關的所有工作, 像是報表中心, 檢查哪些使用者在線, 以及查看統計報表等.</dd>
		<dt>組態</dt><dd>相對偶發性的工作, 像是設定網站名稱, 或者啟用一個插件等.</dd>
		<dt>開發</dt><dd>針對開發人員, 像是建立插件或設計網站主題等. (需要一個開發人員的插件.)</dd>
	</dl>
	",

	// argh, this is ugly
	'admin:widget:admin_welcome:outro' => '<br />拜訪底下連結提供的各種資源, 可以獲得最新資訊, 感謝您使用Elgg!',

	'admin:footer:faq' => '管理FAQ',
	'admin:footer:manual' => '管理說明書',
	'admin:footer:community_forums' => 'Elgg社群論壇',
	'admin:footer:blog' => 'Elgg部落格',

	'admin:plugins:category:all' => '所有的插件',
	'admin:plugins:category:active' => '啟用的插件',
	'admin:plugins:category:inactive' => '停用的插件',
	'admin:plugins:category:admin' => '管理',
	'admin:plugins:category:bundled' => '捆綁的',
	'admin:plugins:category:nonbundled' => '非捆綁的',
	'admin:plugins:category:content' => '內容',
	'admin:plugins:category:development' => '開發',
	'admin:plugins:category:enhancement' => '強化',
	'admin:plugins:category:api' => 'Service/API',
	'admin:plugins:category:communication' => '通訊',
	'admin:plugins:category:security' => '安全與Spam',
	'admin:plugins:category:social' => '社群',
	'admin:plugins:category:multimedia' => '多媒體',
	'admin:plugins:category:theme' => '主題',
	'admin:plugins:category:widget' => '小工具',
	'admin:plugins:category:utility' => '公用程式',

	'admin:plugins:sort:priority' => '按熱門排列',
	'admin:plugins:sort:alpha' => '按字母排列',
	'admin:plugins:sort:date' => '最新',

	'admin:plugins:markdown:unknown_plugin' => '不知名的插件.',
	'admin:plugins:markdown:unknown_file' => '不知名的檔案.',


	'admin:notices:could_not_delete' => '無法刪除通知.',

	'admin:options' => '管理選項',


/**
 * Plugins
 */
	'plugins:settings:save:ok' => "針對插件 %s 的設定已經儲存.",
	'plugins:settings:save:fail' => "儲存 %s 插件的設定時發生錯誤.",
	'plugins:usersettings:save:ok' => "使用者針對插件 %s 的設定已經儲存.",
	'plugins:usersettings:save:fail' => "儲存 %s 插件的使用者設定時發生錯誤.",
	'item:object:plugin' => '插件',

	'admin:plugins' => "插件",
	'admin:plugins:activate_all' => '啟用全部',
	'admin:plugins:deactivate_all' => '停用全部',
	'admin:plugins:activate' => '啟用',
	'admin:plugins:deactivate' => '停用',
	'admin:plugins:description' => "管理面板用來協助您控制與組態安裝在網站上的工具.",
	'admin:plugins:opt:linktext' => "組態工具...",
	'admin:plugins:opt:description' => "組態安裝在本站的工具. ",
	'admin:plugins:label:author' => "作者",
	'admin:plugins:label:copyright' => "著作權",
	'admin:plugins:label:categories' => '分類',
	'admin:plugins:label:licence' => "授權許可",
	'admin:plugins:label:website' => "URL",
	'admin:plugins:label:moreinfo' => '更多資訊',
	'admin:plugins:label:version' => '版本',
	'admin:plugins:label:location' => '位置',
	'admin:plugins:label:dependencies' => '附屬',

	'admin:plugins:warning:elgg_version_unknown' => '這個插件使用一個專用的資訊清單檔, 且未指定相容的Elgg版本. 這個插件可能無法正確運作!',
	'admin:plugins:warning:unmet_dependencies' => '這個插件的附屬檔不符合且無法啟用. 請在更多資訊中檢查進一步訊息.',
	'admin:plugins:warning:invalid' => '%s 不是一個合法的Elgg插件.  請檢查 <a href="http://docs.elgg.org/Invalid_Plugin">Elgg文件</a> 以取得進一步訊息.',
	'admin:plugins:cannot_activate' => '無法啟用',

	'admin:plugins:set_priority:yes' => "重新排列 %s.",
	'admin:plugins:set_priority:no' => "無法重新排列 %s.",
	'admin:plugins:set_priority:no_with_msg' => "無法重新排列 %s. 錯誤: %s",
	'admin:plugins:deactivate:yes' => "停用 %s.",
	'admin:plugins:deactivate:no' => "無法停用 %s.",
	'admin:plugins:deactivate:no_with_msg' => "無法停用 %s. 錯誤: %s",
	'admin:plugins:activate:yes' => "啟用 %s.",
	'admin:plugins:activate:no' => "無法啟用 %s.",
	'admin:plugins:activate:no_with_msg' => "無法啟用 %s. 錯誤: %s",
	'admin:plugins:categories:all' => '所有分類',
	'admin:plugins:plugin_website' => '插件網站',
	'admin:plugins:author' => '%s',
	'admin:plugins:version' => '版本 %s',
	'admin:plugin_settings' => '插件設定',
	'admin:plugins:warning:unmet_dependencies_active' => '這個插件已經啟用, 但附屬檔不符合. 您可能碰到一些問題. 請參考底下的 "更多資訊" 以取得進一步訊息.',

	'admin:plugins:dependencies:type' => '類別',
	'admin:plugins:dependencies:name' => '名稱',
	'admin:plugins:dependencies:expected_value' => '期望值',
	'admin:plugins:dependencies:local_value' => '實際值',
	'admin:plugins:dependencies:comment' => '評論',

	'admin:statistics:description' => "這是網站統計的整體概觀. 如果您需要更詳細的統計資料, 亦可取得更專業的管理功能.",
	'admin:statistics:opt:description' => "查看使用者與物件的統計資料.",
	'admin:statistics:opt:linktext' => "查看統計資料...",
	'admin:statistics:label:basic' => "基本的網站統計資料",
	'admin:statistics:label:numentities' => "網站的項目",
	'admin:statistics:label:numusers' => "使用者數",
	'admin:statistics:label:numonline' => "在線使用者數",
	'admin:statistics:label:onlineusers' => "當前在線使用者",
	'admin:statistics:label:version' => "Elgg版本",
	'admin:statistics:label:version:release' => "發行",
	'admin:statistics:label:version:version' => "版本",

	'admin:user:label:search' => "尋找使用者:",
	'admin:user:label:searchbutton' => "搜尋",

	'admin:user:ban:no' => "無法將使用者查封",
	'admin:user:ban:yes' => "使用者已被查封.",
	'admin:user:self:ban:no' => "您無法將自己查封",
	'admin:user:unban:no' => "無法取消查封使用者",
	'admin:user:unban:yes' => "使用者已被取消查封.",
	'admin:user:delete:no' => "無法刪除使用者",
	'admin:user:delete:yes' => "使用者 %s 已被刪除",
	'admin:user:self:delete:no' => "您無法刪除自己",

	'admin:user:resetpassword:yes' => "密碼重設, 已通知使用者.",
	'admin:user:resetpassword:no' => "密碼無法被重設.",

	'admin:user:makeadmin:yes' => "使用者現在已成為管理員.",
	'admin:user:makeadmin:no' => "無法將該名使用者設定為管理員.",

	'admin:user:removeadmin:yes' => "使用者不再是管理員了.",
	'admin:user:removeadmin:no' => "無法將這位使用者的管理權限移除.",
	'admin:user:self:removeadmin:no' => "您無法移除自己的管理權限.",

	'admin:appearance:menu_items' => '功能表項目',
	'admin:menu_items:configure' => '組態主功能表項目',
	'admin:menu_items:description' => '選取您想要顯示為主要連結的功能表項目.  未使用的項目將會被加到清單末尾"更多"之後.',
	'admin:menu_items:hide_toolbar_entries' => '要將連結從工具列的功能表中移除嗎?',
	'admin:menu_items:saved' => '功能表項目已儲存.',
	'admin:add_menu_item' => '添加一個自訂的功能表項目',
	'admin:add_menu_item:description' => '填入顯示的名稱與URL, 以便將自訂項目加到領航功能表中.',

	'admin:appearance:default_widgets' => '預設的小工具',
	'admin:default_widgets:unknown_type' => '不知名的小工具類型',
	'admin:default_widgets:instructions' => '在選取的小工具頁面, 新增, 移除, 定位, 與組態預設的小工具.'
		. '  這些變更不用影響新的使用者.',

/**
 * User settings
 */
	'usersettings:description' => "使用者設定面板用來協助您控制所有的個人設定, 從使用者管理到插件如何運作. 選取下面的選項開始進行管理.",

	'usersettings:statistics' => "您的統計資料",
	'usersettings:statistics:opt:description' => "查看有關使用者與物件的統計資訊.",
	'usersettings:statistics:opt:linktext' => "帳號統計資料",

	'usersettings:user' => "您的設定值",
	'usersettings:user:opt:description' => "這邊可以用來控制使用者設定.",
	'usersettings:user:opt:linktext' => "變更您的設定",

	'usersettings:plugins' => "工具",
	'usersettings:plugins:opt:description' => "組態已啟用工具的設定(如果有的話).",
	'usersettings:plugins:opt:linktext' => "組態您的工具",

	'usersettings:plugins:description' => "這個面板用來協助您控制與組態系統管理員安裝工具的設定.",
	'usersettings:statistics:label:numentities' => "您的內容",

	'usersettings:statistics:yourdetails' => "您的詳細資料",
	'usersettings:statistics:label:name' => "完整名稱",
	'usersettings:statistics:label:email' => "電子郵件",
	'usersettings:statistics:label:membersince' => "成為會員的日期/時間",
	'usersettings:statistics:label:lastlogin' => "最後登入",

/**
 * Activity river
 */
	'river:all' => '所有網站的動態',
	'river:mine' => '我的動態',
	'river:friends' => '好友的動態',
	'river:select' => '顯示 %s',
	'river:comments:more' => '+%u 更多',
	'river:generic_comment' => '評論 %s %s',

	'friends:widget:description' => "顯示一些您的好友.",
	'friends:num_display' => "顯示的好友數",
	'friends:icon_size' => "圖標大小",
	'friends:tiny' => "極小",
	'friends:small' => "小",

/**
 * Generic action words
 */

	'save' => "儲存",
	'reset' => '重設',
	'publish' => "發佈",
	'cancel' => "取消",
	'saving' => "儲存中 ...",
	'update' => "更新",
	'preview' => "預覽",
	'edit' => "編輯",
	'delete' => "刪除",
	'accept' => "接受",
	'load' => "載入",
	'upload' => "上傳",
	'ban' => "查封",
	'unban' => "取消查封",
	'banned' => "已查封",
	'enable' => "啟用",
	'disable' => "禁用",
	'request' => "要求",
	'complete' => "完成",
	'open' => '開啟',
	'close' => '關閉',
	'reply' => "回覆",
	'more' => '更多',
	'comments' => '評論',
	'import' => '匯入',
	'export' => '匯出',
	'untitled' => '無標題',
	'help' => '說明',
	'send' => '傳送',
	'post' => '張貼',
	'submit' => '遞交',
	'comment' => '評論',
	'upgrade' => '更新版本',
	'sort' => '排序',
	'filter' => '過濾',
	'new' => '新增',
	'add' => '添加',
	'create' => '建立',

	'site' => '網站',
	'activity' => '動態',
	'members' => '成員',

	'up' => '往上',
	'down' => '往下',
	'top' => '頂端',
	'bottom' => '底端',

	'invite' => "邀請",

	'resetpassword' => "重設密碼",
	'makeadmin' => "設為管理員",
	'removeadmin' => "移除管理員",

	'option:yes' => "是",
	'option:no' => "否",

	'unknown' => '未知',

	'active' => '啟用',
	'total' => '總共',

	'learnmore' => "點擊這裡以取得更多資訊.",

	'content' => "內容",
	'content:latest' => '最近的動態',
	'content:latest:blurb' => '您也可以點擊這裡, 以查看最近的內容.',

	'link:text' => '查看連結',
/**
 * Generic questions
 */

	'question:areyousure' => '您確定嗎?',

/**
 * Generic data words
 */

	'title' => "標題",
	'description' => "描述",
	'tags' => "標籤",
	'spotlight' => "熱點",
	'all' => "全部",
	'mine' => "我的",

	'by' => '由',
	'none' => '無',

	'annotations' => "便箋",
	'relationships' => "關係",
	'metadata' => "詮釋資料",
	'tagcloud' => "標籤雲",
	'tagcloud:allsitetags' => "所有網站的標籤",

	'on' => '開啟',
	'off' => '關閉',

/**
 * Entity actions
 */
	'edit:this' => '編輯',
	'delete:this' => '刪除',
	'comment:this' => '評論',

/**
 * Input / output strings
 */

	'deleteconfirm' => "您確定要刪除這個項目嗎?",
	'fileexists' => "檔案已上傳. 要取代它, 請選取底下:",

/**
 * User add
 */

	'useradd:subject' => '使用者帳號已建立',
	'useradd:body' => '
%s,

使用者帳號 %s已為您建立完成. 要登入, 請訪問:

%s

並按以下資訊登入:

使用者名稱: %s
密碼: %s

一旦您登入後, 我們強烈建議您變更密碼.
',

/**
 * System messages
 **/

	'systemmessages:dismiss' => "點擊以駁回",


/**
 * Import / export
 */
	'importsuccess' => "匯入資料成功",
	'importfail' => "OpenDD 匯入資料失敗.",

/**
 * Time
 */

	'friendlytime:justnow' => "剛才",
	'friendlytime:minutes' => "%s 分鐘前",
	'friendlytime:minutes:singular' => "一分鐘前",
	'friendlytime:hours' => "%s 小時前",
	'friendlytime:hours:singular' => "一小時前",
	'friendlytime:days' => "%s 天前",
	'friendlytime:days:singular' => "昨天",
	'friendlytime:date_format' => 'j F Y @ g:ia',

	'date:month:01' => '一月 %s',
	'date:month:02' => '二月 %s',
	'date:month:03' => '三月 %s',
	'date:month:04' => '四月 %s',
	'date:month:05' => '五月 %s',
	'date:month:06' => '六月 %s',
	'date:month:07' => '七月 %s',
	'date:month:08' => '八月 %s',
	'date:month:09' => '九月 %s',
	'date:month:10' => '十月 %s',
	'date:month:11' => '十一月 %s',
	'date:month:12' => '十二月 %s',


/**
 * System settings
 */

	'installation:sitename' => "網站名稱:",
	'installation:sitedescription' => "網站的簡短描述 (選擇性的):",
	'installation:wwwroot' => "網站的URL:",
	'installation:path' => "Elgg安裝的完整路徑:",
	'installation:dataroot' => "資料目錄的完整路徑:",
	'installation:dataroot:warning' => "您必須手動建立這個目錄. 它應該與Elgg安裝目錄不同.",
	'installation:sitepermissions' => "預設的存取權限:",
	'installation:language' => "網站的預設語言:",
	'installation:debug' => "偵錯模式可以提供額外的資料, 以便用來診斷錯誤. 然而, 這樣也會造成系統效能低下, 所以, 建議您只在發生問題時才使用:",
	'installation:debug:none' => '關閉偵錯模式 (建議值)',
	'installation:debug:error' => '只顯示嚴重錯誤',
	'installation:debug:warning' => '顯示錯誤與警告訊息',
	'installation:debug:notice' => '記錄所有的錯誤, 警告與提示',

	// Walled Garden support
	'installation:registration:description' => '在預設情況下, 使用者註冊是啟用的. 如果您不希望新的使用者自行註冊, 請關閉它.',
	'installation:registration:label' => '允許新的使用者註冊',
	'installation:walled_garden:description' => '將這個網站開啟為私人網路. 如此一來, 未登入的使用者將無法查看任何網頁, 除非特別標示為公開的部份.',
	'installation:walled_garden:label' => '限制只有登入的使用者可以查看',

	'installation:httpslogin' => "啟用使用者透過HTTPS安全連線登入的功能. 您必須啟用伺服器的https功能才能正常運作.",
	'installation:httpslogin:label' => "啟用HTTPS登入",
	'installation:view' => "輸入使用者預設的檢視模式, 或者留白以便使用系統的預設檢視(如果您不確定, 請使用預設值):",

	'installation:siteemail' => "網站的電子郵件位址(用來傳送系統郵件):",

	'installation:disableapi' => "Elgg提供API, 以建立web services, 讓遠端的應用程式可以與您的網站互動.",
	'installation:disableapi:label' => "啟用Elgg的web services API",

	'installation:allow_user_default_access:description' => "如果核取, 個別的使用者可以設定自己的預設存取層級.",
	'installation:allow_user_default_access:label' => "允許使用者的預設存取",

	'installation:simplecache:description' => "簡單快取模式, 可以透過快取靜態內容(包括CSS與JavaScript檔案)來增加效能. 一般來說, 您最好將它開啟.",
	'installation:simplecache:label' => "使用簡單快取模式(建議值)",

	'installation:viewpathcache:description' => "檢視檔案路徑快取, 可以透過快取插件的檢視路徑, 減少載入的時間.",
	'installation:viewpathcache:label' => "使用檢視檔案路徑快取(建議值)",

	'upgrading' => '升級中...',
	'upgrade:db' => '您的資料庫已升級.',
	'upgrade:core' => '您安裝的elgg已升級.',
	'upgrade:unable_to_upgrade' => '無法升級.',
	'upgrade:unable_to_upgrade_info' =>
		'此安裝無法升級, 因為我們偵測到Elgg的核心檢視目錄中包含專屬檢視.
		這些檢視已被忽視且需要被移除, 以便Elgg能正確運作.
		如果您未變更Elgg的核心功能, 您可以簡單地刪除檢視目錄, 
		並從最新的Elgg封包中加以取代.<a href="http://elgg.org">elgg.org</a>.<br /><br />

		如果您需要詳細的指令, 請訪問 <a href="http://docs.elgg.org/wiki/Upgrading_Elgg">
		升級Elgg的文件</a>.  如果您需要協助, 可以在
		<a href="http://community.elgg.org/pg/groups/discussion/">社群支援論壇</a>發佈問題.',

	'update:twitter_api:deactivated' => 'Twitter API ( 過去稱為Twitter Service) 在升級過程中被停用. 如果需要, 請手動啟動.',
	'update:oauth_api:deactivated' => 'OAuth API ( 過去稱為OAuth Lib) 在升級中被停用. 如果需要, 請手動啟動.',

	'deprecated:function' => '%s() 被 %s() 忽視',

/**
 * Welcome
 */

	'welcome' => "歡迎",
	'welcome:user' => '歡迎 %s',

/**
 * Emails
 */
	'email:settings' => "電子郵件設定",
	'email:address:label' => "電子郵件位址",

	'email:save:success' => "新的電子郵件住址已儲存, 需要驗證.",
	'email:save:fail' => "新的電子郵件住址無法被儲存.",

	'friend:newfriend:subject' => "%s 已經將您設為好友!",
	'friend:newfriend:body' => "%s 已經將您設為好友!

要查看他們的個人檔案, 請點擊:

%s

請勿回覆這封郵件.",



	'email:resetpassword:subject' => "密碼重設!",
	'email:resetpassword:body' => "Hi %s,

您的密碼已經被重設為: %s",


	'email:resetreq:subject' => "由請新的密碼.",
	'email:resetreq:body' => "Hi %s,

某人 (其IP位址為 %s) 要求重設新的密碼.

如果確實是您要求的, 請點擊底下的連結, 否則請直接忽略這封郵件.

%s
",

/**
 * user default access
 */

	'default_access:settings' => "您預設的存取層級",
	'default_access:label' => "預設存取",
	'user:default_access:success' => "新的預設存取層級已儲存.",
	'user:default_access:failure' => "新的預設存取層級無法被儲存.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"輸入的資料遺漏",

/**
 * Comments
 */

	'comments:count' => "%s 評論",

	'riveraction:annotation:generic_comment' => '%s 對 %s 發表評論',

	'generic_comments:add' => "留下評論",
	'generic_comments:post' => "張貼評論",
	'generic_comments:text' => "評論",
	'generic_comments:latest' => "最近的評論",
	'generic_comment:posted' => "您的評論已發佈.",
	'generic_comment:deleted' => "這個評論已刪除.",
	'generic_comment:blank' => "抱歉, 在儲存之前, 您必須確實輸入一些評論.",
	'generic_comment:notfound' => "抱歉, 無法找到特定的項目.",
	'generic_comment:notdeleted' => "抱歉, 無法刪除這個評論.",
	'generic_comment:failure' => "在添加您的評論時, 發生了無法預期的錯誤. 請再試一次.",
	'generic_comment:none' => '沒有評論',
	'generic_comment:title' => '由 %s 評論',

	'generic_comment:email:subject' => '您有一個新的評論!',
	'generic_comment:email:body' => "您有一個新的評論, 項目為: \"%s\" 來自: %s. 它的內容為:


%s


要回覆或檢視原始的項目, 請點擊這裡:

%s

要查看 %s 的個人檔案, 請點擊這裡:

%s

您無法回覆這封郵件.",

/**
 * Entities
 */
	'byline' => '由 %s',
	'entity:default:strapline' => ' %s 是由 %s 建立的',
	'entity:default:missingsupport:popup' => '這個項目無法正確地顯示. 可能的原因是: 它需要某個插件的支持, 而這個插件已不存在.',

	'entity:delete:success' => '項目 %s 已被刪除',
	'entity:delete:fail' => '項目 %s 無法被刪除',


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => '表單遺漏 __token 或 __ts 欄位',
	'actiongatekeeper:tokeninvalid' => "我們碰到一個問題 (token不符合). 這可能意味著您使用的網頁已經過期了. 請再試一次.",
	'actiongatekeeper:timeerror' => '您使用的網頁已過期了, 請重新顯示然後再試一次.',
	'actiongatekeeper:pluginprevents' => '一個擴充項目使得表單無法被傳送.',


/**
 * Word blacklists 黑名單? 為何需要? http://ggyy.com
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => '標籤',
	'tags:site_cloud' => '網站標籤雲',

/**
 * Javascript
 */

	'js:security:token_refresh_failed' => '無法連接 %s. 儲存內容時碰到問題.',
	'js:security:token_refreshed' => '對 %s 的連接已回復!',

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "Hebrew",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zh_tw" => "正體中文",
	"zu" => "Zulu",
);

add_translation("zh_tw",$traditionalChinese);

