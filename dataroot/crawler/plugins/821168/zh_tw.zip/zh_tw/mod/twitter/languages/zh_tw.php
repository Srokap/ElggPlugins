<?php
/**
 * Twitter widget language file
 */

$traditionalChinese = array(

	'twitter:title' => 'Twitter',
	'twitter:info' => '顯示您最近的tweets',
	'twitter:username' => '輸入的在twitter上的使用者名稱.',
	'twitter:num' => '顯示的tweets數.',
	'twitter:visit' => '訪問我的twitter',
	'twitter:notset' => 'Twitter小工具尚未被設定完善. 要顯示您最近的tweets, 請點擊 - 編輯 - 並填入詳細資訊',
);

add_translation("zh_tw", $traditionalChinese);
