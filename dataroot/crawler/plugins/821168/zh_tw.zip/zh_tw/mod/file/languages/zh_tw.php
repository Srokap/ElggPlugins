<?php
/**
 * Elgg file plugin language pack
 *
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 * @package ElggFile
 */

$traditionalChinese = array(

	/**
	 * Menu items and titles
	 */
	'file' => "檔案",
	'file:user' => "%s的檔案",
	'file:friends' => "好友的檔案",
	'file:all' => "所有檔案",
	'file:edit' => "編輯檔案",
	'file:more' => "更多檔案",
	'file:list' => "清單檢視",
	'file:group' => "群組檔案",
	'file:gallery' => "相簿檢視",
	'file:gallery_list' => "相簿或清單檢視",
	'file:num_files' => "顯示的檔案數",
	'file:user:gallery'=>'查看 %s 相簿',
	'file:via' => '經由檔案',
	'file:upload' => "上傳一個檔案",
	'file:replace' => '取代檔案的原始內容 (留下空白代表不變更檔案)',
	'file:list:title' => "%s's %s %s",
	'file:title:friends' => "好友'",

	'file:add' => '上傳一個檔案',

	'file:file' => "檔案",
	'file:title' => "標題",
	'file:desc' => "描述",
	'file:tags' => "標籤",

	'file:list:list' => '切換到清單檢視',
	'file:list:gallery' => '切換到相簿檢視',

	'file:types' => "上傳的檔案類型",

	'file:type:' => '檔案',
	'file:type:all' => "所有檔案",
	'file:type:video' => "視頻",
	'file:type:document' => "文件",
	'file:type:audio' => "語音",
	'file:type:image' => "圖片",
	'file:type:general' => "一般",

	'file:user:type:video' => "%s的視頻",
	'file:user:type:document' => "%s的文件",
	'file:user:type:audio' => "%s的語音",
	'file:user:type:image' => "%s的圖片",
	'file:user:type:general' => "%s的一般檔案",

	'file:friends:type:video' => "好友的視頻",
	'file:friends:type:document' => "好友的文件",
	'file:friends:type:audio' => "好友的語音",
	'file:friends:type:image' => "好友的圖片",
	'file:friends:type:general' => "好友的一般檔案",

	'file:widget' => "檔案小工具",
	'file:widget:description' => "最近的檔案櫃",

	'groups:enablefiles' => '啟用群組檔案',

	'file:download' => "下載",

	'file:delete:confirm' => "您確定要刪除這個檔案嗎?",

	'file:tagcloud' => "標籤雲",

	'file:display:number' => "顯示的檔案數",

	'river:create:object:file' => '%s 上傳了檔案: %s',
	'river:comment:object:file' => '%s 評論了這個檔案: %s',

	'item:object:file' => '檔案',

	'file:newupload' => '已上傳一個新的檔案',

	/**
	 * Embed media
	 **/

		'file:embed' => "嵌入的媒體",
		'file:embedall' => "全部",

	/**
	 * Status messages
	 */

		'file:saved' => "檔案已儲存.",
		'file:deleted' => "檔案已刪除.",

	/**
	 * Error messages
	 */

		'file:none' => "沒有任何檔案.",
		'file:uploadfailed' => "抱歉, 無法儲存檔案.",
		'file:downloadfailed' => "抱歉, 目前無法存取這個檔案.",
		'file:deletefailed' => "無法刪除檔案.",
		'file:noaccess' => "沒有變更這個檔案的權限",
		'file:cannotload' => "上傳檔案時發生錯誤",
		'file:nofile' => "請先選取一個檔案",
);

add_translation("zh_tw", $traditionalChinese);