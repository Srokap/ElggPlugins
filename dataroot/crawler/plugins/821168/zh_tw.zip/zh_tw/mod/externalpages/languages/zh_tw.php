<?php
/**
 * External pages English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 */

$traditionalChinese = array(

	/**
	 * Menu items and titles
	 */
	'expages' => "網站資訊頁",
	'admin:appearance:expages' => "網站資訊頁",
	'expages:about' => "關於",
	'expages:terms' => "服務條款",
	'expages:privacy' => "隱私權政策",
	'expages:contact' => "聯繫",

	'expages:notset' => "這個頁面尚未完成.",

	/**
	 * Status messages
	 */
	'expages:posted' => "網頁已更新.",
	'expages:error' => "無法儲存網頁.",
);

add_translation("zh_tw", $traditionalChinese);
