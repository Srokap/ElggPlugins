<?php
/**
 * Email user validation plugin language pack.
 *
 * @package Elgg.Core.Plugin
 * @subpackage ElggUserValidationByEmail
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com  

 */

$traditionalChinese = array(
	'admin:users:unvalidated' => '尚未驗證的使用者',
	
	'email:validate:subject' => "%s 請確認您的電子郵件地址, %s!",
	'email:validate:body' => "%s,

在您開始使用 %s帳號前, 您必須確認您的電子郵件地址是正確的.

請點擊底下的連結以便進行確認:

%s

如果您無法直接點擊, 請手動複製底下的連結並貼到瀏覽器的位址列.

%s
%s
",
	'email:confirm:success' => "您已經確認電子郵件地址!",
	'email:confirm:fail' => "電子郵件地址無法被驗證...",

	'uservalidationbyemail:registerok' => "要啟用您的帳號, 請點擊我們剛發出郵件中提供的連結.",
	'uservalidationbyemail:login:fail' => "由於您尚未進行電子郵件認證, 所以無法登入. 另一封驗證用郵件已傳送到您的信箱.",

	'uservalidationbyemail:admin:no_unvalidated_users' => '沒有任何尚未驗證的使用者.',

	'uservalidationbyemail:admin:unvalidated' => '尚未驗證',
	'uservalidationbyemail:admin:user_created' => '註冊 %s',
	'uservalidationbyemail:admin:resend_validation' => '重新寄發驗證函',
	'uservalidationbyemail:admin:validate' => '驗證',
	'uservalidationbyemail:admin:delete' => '刪除',
	'uservalidationbyemail:confirm_validate_user' => '將 %s設為已驗證?',
	'uservalidationbyemail:confirm_resend_validation' => '重新寄發驗證信函給 %s?',
	'uservalidationbyemail:confirm_delete' => 'Delete %s?',
	'uservalidationbyemail:confirm_validate_checked' => '將核取的使用者設為已驗證?',
	'uservalidationbyemail:confirm_resend_validation_checked' => '重新傳送驗證信函給核取的使用者?',
	'uservalidationbyemail:confirm_delete_checked' => '刪除核取的使用者?',
	'uservalidationbyemail:check_all' => '全部',

	'uservalidationbyemail:errors:unknown_users' => '未知的使用者',
	'uservalidationbyemail:errors:could_not_validate_user' => '無法將使用者設為已驗證.',
	'uservalidationbyemail:errors:could_not_validate_users' => '無法將所有核取的使用者設為已驗證.',
	'uservalidationbyemail:errors:could_not_delete_user' => '無法刪除使用者.',
	'uservalidationbyemail:errors:could_not_delete_users' => '無法刪除所有核取的使用者.',
	'uservalidationbyemail:errors:could_not_resend_validation' => '無法重新傳送驗證函.',
	'uservalidationbyemail:errors:could_not_resend_validations' => '無法重新傳送驗證函給所有核取的使用者.',

	'uservalidationbyemail:messages:validated_user' => '使用者已設為通過驗證.',
	'uservalidationbyemail:messages:validated_users' => '所有核取的使用者均已設為通過驗證.',
	'uservalidationbyemail:messages:deleted_user' => '使用者已刪除.',
	'uservalidationbyemail:messages:deleted_users' => '所有核取的使用者均已刪除.',
	'uservalidationbyemail:messages:resent_validation' => '已重寄驗證函.',
	'uservalidationbyemail:messages:resent_validations' => '核取的使用者已重寄驗證函.'

);

add_translation("zh_tw", $traditionalChinese);