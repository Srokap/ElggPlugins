<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$traditionalChinese = array(
	'tinymce:remove' => "移除編輯器",
	'tinymce:add' => "添加編輯器",
	'tinymce:word_count' => '字數計算: ',
);

add_translation("zh_tw", $traditionalChinese);