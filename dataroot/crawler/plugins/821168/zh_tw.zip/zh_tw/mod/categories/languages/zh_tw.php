<?php
/**
 * Custom Index English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com  
 */

$traditionalChinese = array(	
	'custom:bookmarks' => "最近的書籤",
	'custom:groups' => "最近的群組",
	'custom:files' => "最近的檔案",
	'custom:blogs' => "最近的部落格文章",
	'custom:members' => "最新的成員",
);
					
add_translation("zh_tw", $traditionalChinese);
