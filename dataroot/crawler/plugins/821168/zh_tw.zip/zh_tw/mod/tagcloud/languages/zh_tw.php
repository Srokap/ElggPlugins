<?php
/**
 * Tag cloud English language file
 */

$traditionalChinese = array(
	'tagcloud:widget:title' => '標籤雲',
	'tagcloud:widget:description' => '標籤雲',
	'tagcloud:widget:numtags' => '顯示的標籤數',
);

add_translation('zh_tw', $traditionalChinese);
