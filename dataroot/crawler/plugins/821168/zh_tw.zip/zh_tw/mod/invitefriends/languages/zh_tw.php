<?php

/**
 * Elgg invite language file
 * 
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 * @package ElggInviteFriends
 */

$traditionalChinese = array(

	'friends:invite' => '邀請朋友加入這個社群',
	
	'invitefriends:registration_disabled' => '新使用者注冊的功能, 目前被關閉中; 您無邀請新的使用者.',
	
	'invitefriends:introduction' => '想要邀請朋友加入這個社群, 請在下方輸入他們的電子郵件地址(每行一個):',
	'invitefriends:message' => '請輸入邀請函中的訊息與內容:',
	'invitefriends:subject' => '邀請您加入 %s',

	'invitefriends:success' => '您的朋友已被邀請.',
	'invitefriends:invitations_sent' => '邀請函已被傳送: %s. 但出現以下問題:',
	'invitefriends:email_error' => '以下的電子郵件地址不合法: %s',
	'invitefriends:already_members' => '以下幾位已經是會員了: %s',
	'invitefriends:noemails' => '未輸入電子郵件地址.',
	
	'invitefriends:message:default' => '
嗨,

我發現一個有趣的社群網站, 想要邀請您加入 %s.',

	'invitefriends:email' => '
邀請您加入 %s , 邀請人: %s. 邀請函內容:

%s

如果您同意加入, 請點擊底下的連結:

%s

當您在本站註冊完成後, 將自動成為他的好友.',
	
	);
					
add_translation("zh_tw", $traditionalChinese);
