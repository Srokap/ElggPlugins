<?php
/**
 * An english language definition file
 */

$traditionalChinese = array(
	'twitter_api' => 'Twitter服務',

	'twitter_api:requires_oauth' => 'Twitter服務需要OAuth程式庫插件才能啟用.',

	'twitter_api:consumer_key' => '客戶Key',
	'twitter_api:consumer_secret' => '客戶Secret',

	'twitter_api:settings:instructions' => '您必須取得客戶的key與secret, 位址為:<a href="https://dev.twitter.com/apps/new" target="_blank">Twitter</a>. 填寫新的應用表單, 在應用程式的類別中, 選取"瀏覽(Browser)", 並在存取類別中, 選取"讀寫(Read & Write)". 回呼的位址是 %stwitter_api/authorize',

	'twitter_api:usersettings:description' => "將 %s 帳號連結到Twitter.",
	'twitter_api:usersettings:request' => "首先, 您必須<a href=\"%s\">授權</a> %s 存取您的Twitter帳號.",
	'twitter_api:usersettings:cannot_revoke' => "無法中斷您帳號與Twitter的連結, 由於您並未提供電子郵件位址或密碼. <a href=\"%s\">現在提供這些資料</a>.",
	'twitter_api:authorize:error' => '無法取得Twitter授權.',
	'twitter_api:authorize:success' => '已取得Twitter的存取授權.',

	'twitter_api:usersettings:authorized' => "您已授權 %s 存取您的Twitter帳號: @%s.",
	'twitter_api:usersettings:revoke' => '點擊 <a href="%s">這裡</a> 以便撤消存取權.',
	'twitter_api:usersettings:site_not_configured' => '在使用者, 系統管理員必須先組態Twitter.',

	'twitter_api:revoke:success' => 'Twitter的存取權已被撤消.',

	'twitter_api:login' => '要允許現有已連結到他們Twitter帳號的使用者登入到Twitter嗎?',
	'twitter_api:new_users' => '即使使用者註冊已停用, 但仍允許新的使用者透過他們的Twitter帳號登入嗎?',
	'twitter_api:login:success' => '您已登入.',
	'twitter_api:login:error' => '無法透過Twitter帳號登入.',
	'twitter_api:login:email' => "對於新帳號%s,您必須輸入合法的電子郵件位址.",

	'twitter_api:invalid_page' => '不合法的頁面',

	'twitter_api:deprecated_callback_url' => '針對Twitter API的回呼連結已被變更到 %s. 請系統管理員協助變更.',

	'twitter_api:interstitial:settings' => '組態您的設定',
	'twitter_api:interstitial:description' => '您就差不多可以開始使用 %s了! 在繼續前, 我們還需要一點點資料. 這些是選擇性的, 但這麼做, 可以讓您在Twitter故障或撤消連結時, 仍能登入到您的帳號.',

	'twitter_api:interstitial:username' => '這是您的使用者名稱. 它無法被變更. 如果您已設定密碼, 您可以利用使用者名稱或電子郵件地址來登入.',

	'twitter_api:interstitial:name' => '這是別人與您互動時他們看到的名稱.',

	'twitter_api:interstitial:email' => '您的電子郵件地址, 在預設情況下, 別人看不到您的電子郵件地址.',

	'twitter_api:interstitial:password' => '當Twitter故障或您決定撤消連結時, 使用來登入本站的密碼.',
	'twitter_api:interstitial:password2' => '請再輸入一次密碼.',

	'twitter_api:interstitial:no_thanks' => '不, 謝了',

	'twitter_api:interstitial:no_display_name' => '您必須設定顯示的名稱.',
	'twitter_api:interstitial:invalid_email' => '您必須輸入合法的電子郵件地址.',
	'twitter_api:interstitial:existing_email' => '該郵箱地址已被註冊過了.',
	'twitter_api:interstitial:password_mismatch' => '兩次輸入的密碼不相符.',
	'twitter_api:interstitial:cannot_save' => '無法儲存.',
	'twitter_api:interstitial:saved' => '已儲存!',
);

add_translation('zh_tw', $traditionalChinese);
