<?php
/**
 * Elgg developer tools English language file.
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 *
 */

$traditionalChinese = array(
	// menu
	'admin:develop_tools' => '工具',
	'admin:develop_tools:preview' => 'Theming沙盒',
	'admin:develop_tools:inspect' => '檢查',
	'admin:developers' => '開發人員',
	'admin:developers:settings' => '設定',

	// settings
	'elgg_dev_tools:settings:explanation' => '在底下區域控制您的開發與偵錯. 有些設定在其他的管理頁面中也可以找到.',
	'developers:label:simple_cache' => '使用簡單快取',
	'developers:help:simple_cache' => '在開發時請關閉檔案快取. 否則, 檢視的變更(包含css)將被忽略.',
	'developers:label:view_path_cache' => '使用檢視路徑快取',
	'developers:help:view_path_cache' => '在開發時請關閉. 否則, 插件的檢視將無法被註冊.',
	'developers:label:debug_level' => "追蹤的層級",
	'developers:help:debug_level' => "這個用來控制記錄資訊的數量. 請參考elgg_log()以便取得更多資訊.",
	'developers:label:display_errors' => '顯示嚴重的PHP錯誤',
	'developers:help:display_errors' => "在預設情況下, Elgg的.htaccess檔案會壓抑嚴重錯誤的顯示.",
	'developers:label:screen_log' => "記錄顯示在螢幕上",
	'developers:help:screen_log' => "這個會顯示輸出到網頁的elgg_log()與elgg_dump().",
	'developers:label:show_strings' => "顯示原始轉譯的字串",
	'developers:help:show_strings' => "這個會顯示elgg_echo()所使用的轉譯字串.",
	'developers:label:wrap_views' => "重疊檢視",
	'developers:help:wrap_views' => "這個會以HTML的注解方式重疊展現所有的檢視. 當您想要尋找特定HTML建立的檢視時特別有用.",
	'developers:label:log_events' => "記錄事件與插件的hooks",
	'developers:help:log_events' => "將事件與插件的hooks寫入記錄檔. 請注意: 每一頁都將包含許多內容.",

	'developers:debug:off' => '關閉',
	'developers:debug:error' => '錯誤',
	'developers:debug:warning' => '警告',
	'developers:debug:notice' => '注意',
	
	// inspection
	'developers:inspect:help' => '檢查Elgg平台的組態.',

	// event logging
	'developers:event_log_msg' => "%s: '%s, %s' 於 %s",

	// theme preview
	'theme_preview:general' => '介紹',
	'theme_preview:breakout' => '突然發生iframe',
	'theme_preview:buttons' => '按鈕',
	'theme_preview:components' => '元件',
	'theme_preview:forms' => '表單',
	'theme_preview:grid' => '方格',
	'theme_preview:icons' => '圖示',
	'theme_preview:modules' => '模組',
	'theme_preview:navigation' => '導航',
	'theme_preview:typography' => '排版',

	// status messages
	'developers:settings:success' => '設定已儲存',
);

add_translation('zh_tw', $traditionalChinese);
