<?php
/**
 * User dashboard languages
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 */

$traditionalChinese = array(
	'dashboard:widget:group:title' => '群組動態',
	'dashboard:widget:group:desc' => '查看一個您的群組的動態',
	'dashboard:widget:group:select' => '請選取一個群組',
	'dashboard:widget:group:noactivity' => '您的群組中沒有新的動態',
	'dashboard:widget:group:noselect' => '編輯這個小工具以選取一個群組',
);

add_translation("zh_tw", $traditionalChinese);
