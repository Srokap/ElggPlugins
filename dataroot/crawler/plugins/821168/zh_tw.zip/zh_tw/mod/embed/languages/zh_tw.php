<?php
/**
 * Embed English language strings
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com  	  
 *
 */

$traditionalChinese = array(
	'embed:embed' => '嵌入',
	'embed:media' => '嵌入的內容',
	'embed:instructions' => '單擊任何檔案, 以便將它嵌入到您的內容.',
	'embed:upload' => '上傳媒體',
	'embed:upload_type' => '上傳的類型: ',

	// messages
	'embed:no_upload_content' => '沒有上傳的內容!',
	'embed:no_section_content' => '未發現項目.',

	'embed:no_sections' => '未找到支援的嵌入插件. 請網站管理員啟用支援該嵌入媒體的插件.',
);

add_translation("zh_tw", $traditionalChinese);