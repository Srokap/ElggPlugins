<?php
/**
 * Elgg log browser plugin language pack
 *
 * @package ElggLogBrowser
 */

$traditionalChinese = array(
	'admin:administer_utilities:logbrowser' => '記錄瀏覽器相關資料',
	'logbrowser' => '記錄瀏覽器相關資料',
	'logbrowser:browse' => '檢視系統記錄檔',
	'logbrowser:search' => '進一步縮小結果',
	'logbrowser:user' => '要搜尋的使用者名稱',
	'logbrowser:starttime' => '開始時間 (例如 "上個月", "一小時前")',
	'logbrowser:endtime' => '結束時間',

	'logbrowser:explore' => '瀏覽記錄檔',

	'logbrowser:date' => '日期與時間',
	'logbrowser:user:name' => '使用者',
	'logbrowser:user:guid' => '使用者GUID',
	'logbrowser:object' => '物件的型別',
	'logbrowser:object:guid' => '物件GUID',
	'logbrowser:action' => '動作',
);

add_translation("zh_tw", $traditionalChinese);