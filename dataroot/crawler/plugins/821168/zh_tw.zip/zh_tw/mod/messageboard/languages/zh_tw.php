<?php
/**
 * Custom Index English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com  
 */
 
$traditionalChinese = array(

	/**
	 * Menu items and titles
	 */

	'messageboard:board' => "佈告欄",
	'messageboard:messageboard' => "佈告欄",
	'messageboard:viewall' => "查看全部",
	'messageboard:postit' => "文件",
	'messageboard:history:title' => "歷史",
	'messageboard:none' => "目前佈告欄沒有新的訊息",
	'messageboard:num_display' => "顯示的佈告欄訊息數",
	'messageboard:desc' => "您可以將佈告欄的訊息放在自己的個人資料檔中, 其他人可以加以評論.",

	'messageboard:user' => "%s的佈告欄",

	'messageboard:replyon' => '依靠於',
	'messageboard:history' => "歷史",

	'messageboard:owner' => '%s的佈告欄',
	'messageboard:owner_history' => '%s的文件發佈在 %s的佈告欄',

	/**
	 * Message board widget river
	 */
	'river:messageboard:user:default' => "%s 將文章張貼在 %s的佈告欄",

	/**
	 * Status messages
	 */

	'messageboard:posted' => "您已經成功地將文章張貼在佈告欄.",
	'messageboard:deleted' => "您已經成功地刪除這條訊息.",

	/**
	 * Email messages
	 */

	'messageboard:email:subject' => '您的佈告欄中有一條新的評論!',
	'messageboard:email:body' => "來自於 %s的新佈造欄評論. 內容為:


%s


要查看佈告欄的評論, 請點擊:

	%s

要查看 %s的個人檔案, 請點擊:

	%s

請不要直接回覆本郵件, 謝謝.",

	/**
	 * Error messages
	 */

	'messageboard:blank' => "抱歉; 在儲存前, 請在訊息區塊輸入一些內容.",
	'messageboard:notfound' => "抱歉; 找不到指定的項目.",
	'messageboard:notdeleted' => "抱歉; 無法刪除這條訊息.",
	'messageboard:somethingwentwrong' => "儲存訊息時發生錯誤, 請確認您的訊息內容無誤.",

	'messageboard:failure' => "添加訊息時出現一個不被預期的錯誤, 請再試一次.",

);

add_translation("zh_tw", $traditionalChinese);
