<?php
/**
 * Likes English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com , like this翻我"我挺"
 */

$traditionalChinese = array(
	'likes:this' => '我挺',
	'likes:deleted' => '您的相挺已被移除',
	'likes:see' => '看看誰挺過這個',
	'likes:remove' => '我不挺',
	'likes:notdeleted' => '移除您的\'相挺\'時出現問題',
	'likes:likes' => '現在您挺了這個項目',
	'likes:failure' => '相挺時出現問題',
	'likes:alreadyliked' => '您已經挺過了',
	'likes:notfound' => '找不到您想要相挺的項目',
	'likes:likethis' => '我挺它',
	'likes:userlikedthis' => '%s 挺它',
	'likes:userslikedthis' => '%s 挺它',
	'likes:river:annotate' => '挺它',

	'river:likes' => '挺 %s %s',

	// notifications. yikes.
	'likes:notifications:subject' => '%s 挺了您的文章 "%s"',
	'likes:notifications:body' =>
'嗨 %1$s,

%2$s 挺了您的文章 "%3$s" ,位於 %4$s

看看您原始的文章內容:

%5$s

或者查看 %2$s的個人檔案:

%6$s

祝時祺,
%4$s
',
	
);

add_translation('zh_tw', $traditionalChinese);
