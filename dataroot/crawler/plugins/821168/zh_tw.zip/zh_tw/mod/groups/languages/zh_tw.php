<?php
/**
 * Elgg groups plugin language pack
 *
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 * @package ElggGroups
 */

$traditionalChinese = array(

	/**
	 * Menu items and titles
	 */
	'groups' => "群組",
	'groups:owned' => "我擁有的群組",
	'groups:yours' => "我的群組",
	'groups:user' => "%s的群組",
	'groups:all' => "所有群組",
	'groups:add' => "建立一個新群組",
	'groups:edit' => "編輯群組",
	'groups:delete' => '刪除群組',
	'groups:membershiprequests' => '管理加入的請求',
	'groups:invitations' => '群組的邀請',

	'groups:icon' => '群組的圖示(如果不變更, 請保留空白)',
	'groups:name' => '群組的名稱',
	'groups:username' => '群組的短名(顯示在URLs中, 只能使用英文字元)',
	'groups:description' => '描述',
	'groups:briefdescription' => '簡單描述',
	'groups:interests' => '標籤',
	'groups:website' => '網站',
	'groups:members' => '群組的成',
	'groups:members:title' => '%s的成員',
	'groups:members:more' => "查看所有成員",
	'groups:membership' => "群組成員的權限",
	'groups:access' => "存取權限",
	'groups:owner' => "所有者",
	'groups:widget:num_display' => '顯示的群組數',
	'groups:widget:membership' => '群組的成員',
	'groups:widgets:description' => '在您的個人資料中, 顯示您加入的群組',
	'groups:noaccess' => '對群組無存取權限',
	'groups:permissions:error' => '您沒有權限',
	'groups:ingroup' => '在此群組',
	'groups:cantedit' => '無法編輯這個群組',
	'groups:saved' => '群組已儲存',
	'groups:featured' => '主要群組',
	'groups:makeunfeatured' => '非主要',
	'groups:makefeatured' => '設為主要',
	'groups:featuredon' => '%s 現成已成為主要群組.',
	'groups:unfeatured' => '%s 已從主要群組中移除.',
	'groups:featured_error' => '不合法的群組.',
	'groups:joinrequest' => '由請成為群組成員',
	'groups:join' => '加入群組',
	'groups:leave' => '退出群組',
	'groups:invite' => '邀請好友',
	'groups:invite:title' => '邀請好友加入這個群組',
	'groups:inviteto' => "邀請好友加入%s'",
	'groups:nofriends' => "已無尚未被邀請加入這個群組的好友.",
	'groups:nofriendsatall' => '沒有能邀請的好友!',
	'groups:viagroups' => "經由群組",
	'groups:group' => "群組",
	'groups:search:tags' => "標籤",
	'groups:search:title' => "搜尋具有'%s'的群組標籤",
	'groups:search:none' => "未找到符合條件的群組",

	'groups:activity' => "群組動態",
	'groups:enableactivity' => '啟用群組動態功能',
	'groups:activity:none' => "尚無群組動態",

	'groups:notfound' => "未找到群組",
	'groups:notfound:details' => "要求的群組不存在, 或者您無權存取",

	'groups:requests:none' => '目前沒有申請成為會員的要求.',

	'groups:invitations:none' => '目前沒有邀請.',

	'item:object:groupforumtopic' => "討論主題",

	'groupforumtopic:new' => "添加討論文章",

	'groups:count' => "群組已建立",
	'groups:open' => "開放群組",
	'groups:closed' => "封閉群組",
	'groups:member' => "成員",
	'groups:searchtag' => "按標籤搜尋群組",

	'groups:more' => '更多群組',
	'groups:none' => '沒有群組',


	/*
	 * Access
	 */
	'groups:access:private' => '封閉 - 使用者只能被邀請加入',
	'groups:access:public' => '開放 - 任何使用者均可加入',
	'groups:access:group' => '只限群組的成員',
	'groups:closedgroup' => '這個群組只限成員使用.',
	'groups:closedgroup:request' => '若想加入, 請點擊"申請成為會員"的功能表連結.',
	'groups:visibility' => '誰能看到這個群組?',

	/*
	Group tools
	*/
	'groups:enableforum' => '啟用群組討論功能',
	'groups:yes' => '是',
	'groups:no' => '否',
	'groups:lastupdated' => '最近的更新: %s 由: %s',
	'groups:lastcomment' => '最近的評論: %s 由: %s',

	/*
	Group discussion
	*/
	'discussion' => '討論',
	'discussion:add' => '添加討論主題',
	'discussion:latest' => '最近的討論',
	'discussion:group' => '群組討論',
	'discussion:none' => '無討論',
	'discussion:reply:title' => '由 %s 回覆',

	'discussion:topic:created' => '討論的主題已建立.',
	'discussion:topic:updated' => '討論的主題已更新.',
	'discussion:topic:deleted' => '討論的主題已刪除.',

	'discussion:topic:notfound' => '未發現討論的主題',
	'discussion:error:notsaved' => '無法儲存該主題',
	'discussion:error:missing' => '標題與訊息均為必要欄位',
	'discussion:error:permissions' => '您沒有執行這個動作的權限',
	'discussion:error:notdeleted' => '無法刪除該討論主題',

	'discussion:reply:deleted' => '討論的回覆已經刪除.',
	'discussion:reply:error:notdeleted' => '無法刪除這個討論的回覆',

	'reply:this' => '回覆',

	'group:replies' => '回覆',
	'groups:forum:created' => '建立了 %s ,評論為: %d',
	'groups:forum:created:single' => '建立了 %s ,回覆為%d',
	'groups:forum' => '討論',
	'groups:addtopic' => '添加一個主題',
	'groups:forumlatest' => '最近的討論',
	'groups:latestdiscussion' => '最近的討論',
	'groups:newest' => '最近的',
	'groups:popular' => '最熱門的',
	'groupspost:success' => '您的回覆已發表',
	'groups:alldiscussion' => '取近的討論',
	'groups:edittopic' => '編輯討論',
	'groups:topicmessage' => '標題的訊息',
	'groups:topicstatus' => '標題的狀態',
	'groups:reply' => '發表評論',
	'groups:topic' => '主題',
	'groups:posts' => '發表',
	'groups:lastperson' => '最後一位',
	'groups:when' => '何时',
	'grouptopic:notcreated' => '沒有任何標題.',
	'groups:topicopen' => '開放中',
	'groups:topicclosed' => '已關閉',
	'groups:topicresolved' => '已解決',
	'grouptopic:created' => '標題已建立.',
	'groupstopic:deleted' => '標題已刪除.',
	'groups:topicsticky' => '附著',
	'groups:topicisclosed' => '該討論已被關閉.',
	'groups:topiccloseddesc' => '該討論已關閉,不再接受新的評論.',
	'grouptopic:error' => '群組標題無法建立, 請再試一次, 或洽系統管理員.',
	'groups:forumpost:edited' => "成功編輯論壇文章.",
	'groups:forumpost:error' => "編輯論壇文章時發生問題.",


	'groups:privategroup' => '這個群組已封閉. 您可以申請成為會員.',
	'groups:notitle' => '群組必須具備一個標題',
	'groups:cantjoin' => '無法加入群組',
	'groups:cantleave' => '無法退出群組',
	'groups:removeuser' => '從群組中移除',
	'groups:cantremove' => '無法將使用者從群組中移除',
	'groups:removed' => '已將 %s 從群組中移除',
	'groups:addedtogroup' => '已將使用者加入這個群組',
	'groups:joinrequestnotmade' => '無法申請成為會員',
	'groups:joinrequestmade' => '申請加入群組',
	'groups:joined' => '成功加入該群組!',
	'groups:left' => '成功退出該群組',
	'groups:notowner' => '抱歉, 您不是這個群組的擁有者.',
	'groups:notmember' => '抱歉, 您還不是這個群組的成員.',
	'groups:alreadymember' => '您已經是這個群組的成員了!',
	'groups:userinvited' => '使用者已經被邀請.',
	'groups:usernotinvited' => '使用者無法被邀請.',
	'groups:useralreadyinvited' => '使用者已經被邀請過了',
	'groups:invite:subject' => "%s , 您已經被邀請加入群組: %s!",
	'groups:updated' => "最後的回覆, 由 %s %s",
	'groups:started' => "由%s啟動",
	'groups:joinrequest:remove:check' => '您確定要移除這個加入的請求嗎?',
	'groups:invite:remove:check' => '您確定要移除這個邀請嗎?',
	'groups:invite:body' => "嗨 %s,

%s 邀請您加入 '%s' 群組. 如果您同意的話, 請點擊以下的連結, 查看這個邀請:

%s",

	'groups:welcome:subject' => "歡迎來到 %s 群組!",
	'groups:welcome:body' => "嗨 %s!

您現在已經成為群組 '%s' 的成員了! 點擊底下的連結, 開始分享您的經驗與文章!

%s",

	'groups:request:subject' => "%s 申請加入 %s",
	'groups:request:body' => "嗨 %s,

%s 申請加入群組 '%s' . 單擊以下的連結, 來查看他們的個人檔案:

%s

或單擊底下的連結, 查看群組的加入申請:

%s",

	/*
		Forum river items
	*/

	'river:create:group:default' => '%s 成立了群組 %s',
	'river:join:group:default' => '%s 剛加入群組 %s',
	'river:create:object:groupforumtopic' => '%s 剛添加一個新的討論主題 %s',
	'river:reply:object:groupforumtopic' => '%s 剛回應了討論主題: %s',
	
	'groups:nowidgets' => '這個群組尚未定義任何小工具.',


	'groups:widgets:members:title' => '群組成員',
	'groups:widgets:members:description' => '群組成員清單.',
	'groups:widgets:members:label:displaynum' => '列出該群組的成員.',
	'groups:widgets:members:label:pleaseedit' => '請設定這個小工具的組態.',

	'groups:widgets:entities:title' => "群組中的物件",
	'groups:widgets:entities:description' => "儲存在這個群組的物件清單",
	'groups:widgets:entities:label:displaynum' => '列出該群組中的物件.',
	'groups:widgets:entities:label:pleaseedit' => '請設定這個小工具的組態.',

	'groups:forumtopic:edited' => '討論主題已經被成功地編輯.',

	'groups:allowhiddengroups' => '是否允許建立私人(其他人看不到)的群組?',

	/**
	 * Action messages
	 */
	'group:deleted' => '已刪除群組與群組的內容',
	'group:notdeleted' => '無法刪除群組',

	'group:notfound' => '無法找到該群組',
	'grouppost:deleted' => '已刪除群組的文章',
	'grouppost:notdeleted' => '無法刪除群組的文章',
	'groupstopic:deleted' => '標題已刪除',
	'groupstopic:notdeleted' => '標題未被刪除',
	'grouptopic:blank' => '沒有任何主題',
	'grouptopic:notfound' => '無法找到這個主題',
	'grouppost:nopost' => '空的文章',
	'groups:deletewarning' => "您確定要刪除這個群組嗎? 這個操作無法回復!",

	'groups:invitekilled' => '邀請已被刪除.',
	'groups:joinrequestkilled' => '加入的申請已被刪除.',

	// ecml
	'groups:ecml:discussion' => '群組的討論',
	'groups:ecml:groupprofile' => '群組的小檔案',

);

add_translation("zh_tw", $traditionalChinese);