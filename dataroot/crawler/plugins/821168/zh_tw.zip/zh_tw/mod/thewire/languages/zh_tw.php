<?php
/**
 * The Wire English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com  
 */

$traditionalChinese = array(

	/**
	 * Menu items and titles
	 */
	'thewire' => "碎碎念",
	'thewire:everyone' => "所有發佈的碎碎念",
	'thewire:user' => "%s發佈的碎碎念",
	'thewire:friends' => "好友發佈的碎碎念",
	'thewire:reply' => "回覆",
	'thewire:replying' => "回覆給 %s (@%s)",
	'thewire:thread' => "線程",
	'thewire:charleft' => "剩下的字數",
	'thewire:tags' => "包含標籤 '%s'的碎碎念",
	'thewire:noposts' => "沒有任何碎碎念",
	'item:object:thewire' => "碎碎念發佈",
	'thewire:update' => '更新',
	'thewire:by' => '%s發佈的碎碎念',

	'thewire:previous' => "前一個",
	'thewire:hide' => "隱藏",
	'thewire:previous:help' => "查看前一個碎碎念",
	'thewire:hide:help' => "隱藏前一個碎碎念",

	/**
	 * The wire river
	 */
	'river:create:object:thewire' => "%s 發佈到 %s",
	'thewire:wire' => '碎碎念',

	/**
	 * Wire widget
	 */
	'thewire:widget:desc' => '顯示您最近發佈的碎碎念',
	'thewire:num' => '顯示的碎碎念數',
	'thewire:moreposts' => '更多發佈的碎碎念',

	/**
	 * Status messages
	 */
	'thewire:posted' => "已成功將訊息發佈在碎碎念中.",
	'thewire:deleted' => "已成功刪除碎碎念中的訊息.",
	'thewire:blank' => "抱歉, 在發佈前, 請輸入一些內容.",
	'thewire:notfound' => "抱歉, 找不到指定的碎碎念內容.",
	'thewire:notdeleted' => "抱歉, 無法刪除這條發佈的碎碎念.",

	/**
	 * Notifications
	 */
	'thewire:notify:subject' => "新的碎碎念已發佈",
	'thewire:notify:reply' => '%s 在碎碎念中回應 %s:',
	'thewire:notify:post' => '%s 在碎碎念中發佈:',

);

add_translation("zh_tw", $traditionalChinese);
