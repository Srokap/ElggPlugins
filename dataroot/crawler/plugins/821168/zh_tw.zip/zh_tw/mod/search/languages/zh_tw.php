<?php
/**
 * Custom Index English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com  
 */
 
$traditionalChinese = array(
	'search:enter_term' => '輸入搜尋的詞彙:',
	'search:no_results' => '無相符的結果.',
	'search:matched' => '符合的項目: ',
	'search:results' => '搜尋 %s的結果',
	'search:no_query' => '請輸入查詢的內容.',
	'search:search_error' => '錯誤',

	'search:more' => '+%s 更多 %s',

	'search_types:tags' => '標籤',

	'search_types:comments' => '評論',
	'search:comment_on' => '針對 "%s"發表的評論',
	'search:comment_by' => '由',
	'search:unavailable_entity' => '不可用的項目',
);

add_translation('zh_tw', $traditionalChinese);
