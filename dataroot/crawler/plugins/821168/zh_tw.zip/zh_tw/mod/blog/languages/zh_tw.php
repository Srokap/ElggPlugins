<?php
/**
 * Blog English language file.
 * @正體中文 by http://myggyy.com 
 *
 */

$traditionalChinese = array(
	'blog' => '部落格',
	'blog:blogs' => '部落格',
	'blog:revisions' => '修訂',
	'blog:archives' => '歸檔',
	'blog:blog' => '部落格',
	'item:object:blog' => '部落格',

	'blog:title:user_blogs' => '%s 的部落格',
	'blog:title:all_blogs' => '全部部落格',
	'blog:title:friends' => '好友的部落格',

	'blog:group' => '群組部落格',
	'blog:enableblog' => '啟用群組部落格',
	'blog:write' => '撰寫部落格文章',

	// Editing
	'blog:add' => '新增部落格文章',
	'blog:edit' => '編輯部落格文章',
	'blog:excerpt' => '節錄',
	'blog:body' => '主體',
	'blog:save_status' => '最後儲存: ',
	'blog:never' => '永遠不',

	// Statuses
	'blog:status' => '狀態',
	'blog:status:draft' => '草稿',
	'blog:status:published' => '已發佈',
	'blog:status:unsaved_draft' => '尚未儲存的草稿',

	'blog:revision' => '修訂',
	'blog:auto_saved_revision' => '自動儲存修訂部份',

	// messages
	'blog:message:saved' => '部落格文章已儲存.',
	'blog:error:cannot_save' => '無法儲存部落格文章.',
	'blog:error:cannot_write_to_container' => '要將部落格儲存到群組的權限不足.',
	'blog:error:post_not_found' => '這篇文章已被移除, 無法取得, 或者您沒有查看的權限.',
	'blog:messages:warning:draft' => '本章有尚未儲存的草稿There is an unsaved draft of this post!',
	'blog:edit_revision_notice' => '(舊版本)',
	'blog:message:deleted_post' => '部落格文章已被刪除.',
	'blog:error:cannot_delete_post' => '無法刪除部落格文章.',
	'blog:none' => '沒有部落格文章',
	'blog:error:missing:title' => '請輸入部落格的標題!',
	'blog:error:missing:description' => '請輸入部落格的主體!',
	'blog:error:cannot_edit_post' => '這篇文章不存在, 或者是您沒有編輯的權限.',
	'blog:error:revision_not_found' => '無法找到修定版.',

	// river
	'river:create:object:blog' => '%s 發佈了部落格文章 %s',
	'river:comment:object:blog' => '%s 對部落格 %s 發表了評論',

	// notifications
	'blog:newpost' => '一篇新的部落格文章',

	// widget
	'blog:widget:description' => '顯示您最近的部落格卜章',
	'blog:moreblogs' => '更多部落格文章',
	'blog:numbertodisplay' => '顯示的部落格文章數',
	'blog:noblogs' => '沒有任何部落格文章'
);

add_translation("zh_tw",$traditionalChinese);
