<?php
/**
 * Pages languages
 *
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 * @package ElggPages
 */

$traditionalChinese = array(

	/**
	 * Menu items and titles
	 */

	'pages' => "頁面",
	'pages:owner' => "%s的頁面",
	'pages:friends' => "好友的頁面",
	'pages:all' => "所有網站的頁面",
	'pages:add' => "添加頁面",

	'pages:group' => "群組頁面",
	'groups:enablepages' => '啟用群組頁面',

	'pages:edit' => "編輯此頁面",
	'pages:delete' => "刪除此頁面",
	'pages:history' => "歷史",
	'pages:view' => "查看頁面",
	'pages:revision' => "修訂",

	'pages:navigation' => "導覽",
	'pages:via' => "經由頁面",
	'item:object:page_top' => '最上層頁面',
	'item:object:page' => '頁面',
	'pages:nogroup' => '這個群組尚未建立任何頁面',
	'pages:more' => '更多頁面',
	'pages:none' => '尚未建立任何頁面',

	/**
	* River
	**/

	'river:create:object:page' => '%s 建立了一個新的頁面 %s',
	'river:create:object:page_top' => '%s 建立了一個新的頁面 %s',
	'river:update:object:page' => '%s 更新了一個頁面 %s',
	'river:update:object:page_top' => '%s 更新了一個頁面 %s',
	'river:comment:object:page' => '%s 評論了標題為 %s的頁面',
	'river:comment:object:page_top' => '%s 評論了標題為 %s的頁面',

	/**
	 * Form fields
	 */

	'pages:title' => '頁面的標題',
	'pages:description' => '頁面的文字',
	'pages:tags' => '標籤',
	'pages:access_id' => '閱讀權限',
	'pages:write_access_id' => '寫入權限',

	/**
	 * Status and error messages
	 */
	'pages:noaccess' => '無法存取頁面',
	'pages:cantedit' => '您無法編輯這個頁面',
	'pages:saved' => '頁面已儲存',
	'pages:notsaved' => '無法儲存頁面',
	'pages:error:no_title' => '您必須設定一個標題.',
	'pages:delete:success' => '此頁面已成功刪除.',
	'pages:delete:failure' => '此頁面無法被刪除.',

	/**
	 * Page
	 */
	'pages:strapline' => '最後更新: %s 由: %s',

	/**
	 * History
	 */
	'pages:revision:subtitle' => '修訂版本建立: %s 由: %s',

	/**
	 * Widget
	 **/

	'pages:num' => '顯示的頁面數',
	'pages:widget:description' => "這是您的頁面清單.",

	/**
	 * Submenu items
	 */
	'pages:label:view' => "查看頁面",
	'pages:label:edit' => "編輯頁面",
	'pages:label:history' => "頁面歷史",

	/**
	 * Sidebar items
	 */
	'pages:sidebar:this' => "本頁",
	'pages:sidebar:children' => "子頁面",
	'pages:sidebar:parent' => "母頁面",

	'pages:newchild' => "建立一個子頁面",
	'pages:backtoparent' => "回到 '%s'",
);

add_translation("zh_tw", $traditionalChinese);