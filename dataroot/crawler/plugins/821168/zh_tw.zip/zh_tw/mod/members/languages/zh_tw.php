<?php
/**
 * Members English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 */

$traditionalChinese = array(
	'members:label:newest' => '最新',
	'members:label:popular' => '最受歡迎',
	'members:label:online' => '在線上',
	'members:searchname' => '按名字搜尋會員',
	'members:searchtag' => '按標籤搜尋會員Search members by tag',
	'members:title:searchname' => '依 %s找到的會員',
	'members:title:searchtag' => '具有 %s標籤的會員',
);

add_translation('zh_tw', $traditionalChinese);
