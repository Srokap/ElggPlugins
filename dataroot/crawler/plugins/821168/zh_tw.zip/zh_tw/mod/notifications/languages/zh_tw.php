<?php
/**
 * Custom Index English language file
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com  
 */
 
$traditionalChinese = array(

	'friends:all' => '全部好友',

	'notifications:subscriptions:personal:description' => '當對您的內容執行任何操作時, 取得通知',
	'notifications:subscriptions:personal:title' => '個人的通知',

	'notifications:subscriptions:friends:title' => '好友',
	'notifications:subscriptions:friends:description' => '以下部份是從您的好友清單中自動收集而來. 要取得更新, 請選取低下的部份. 這樣做會影響到底部主要的通知設定版塊中列出的相關使用者. ',
	'notifications:subscriptions:collections:edit' => '想要編輯您的共享存取通知, 請點擊這邊.',

	'notifications:subscriptions:changesettings' => '通知',
	'notifications:subscriptions:changesettings:groups' => '群組通知',

	'notifications:subscriptions:title' => '每一位使用者的通知',
	'notifications:subscriptions:description' => '當您的好友建立新內容時, 如果想要從您的好友處取得通知 (基於個別設定的基礎), 請在底下找到他們並選取想要使用的通知方式.',

	'notifications:subscriptions:groups:description' => '當您隸屬的群組添加新內容時, 如果想要取得通知, 請在底下找到該群組並選取想要使用的通知方式.',

	'notifications:subscriptions:success' => '通知的設定已儲存.',

);

	add_translation("zh_tw", $traditionalChinese);
