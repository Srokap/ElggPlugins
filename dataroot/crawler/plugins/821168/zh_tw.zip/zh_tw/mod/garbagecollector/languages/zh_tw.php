<?php
/**
 * Elgg garbage collector language pack.
 *
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 * @package ElggGarbageCollector
 */

$traditionalChinese = array(
	'garbagecollector:period' => 'Elgg自動垃圾回收的執行頻率?',

	'garbagecollector:weekly' => '每星期一次',
	'garbagecollector:monthly' => '每月一次',
	'garbagecollector:yearly' => '每年一次',

	'garbagecollector' => "自動垃圾回收\n",
	'garbagecollector:done' => "已完成\n",
	'garbagecollector:optimize' => "最佳化 %s ",

	'garbagecollector:error' => "錯誤",
	'garbagecollector:ok' => "確定",

	'garbagecollector:gc:metastrings' => '清除無用的中介字串: ',
);

add_translation("zh_tw", $traditionalChinese);