<?php
	/**
	 * Elgg diagnostics language pack.
	 *
	 * @package ElggDiagnostics
	 * @正體中文 by http://myggyy.com
	 * @正體中文 by http://ggyy.com  	 
	 */

	$traditionalChinese = array(

			'admin:develop_utilities:diagnostics' => '系統診斷',
			'diagnostics' => '系統診斷',
			'diagnostics:report' => '診斷報告',
			'diagnostics:unittester' => '單元測試',

			'diagnostics:description' => '以下的診斷報告, 在確認Elgg的任何問題時非常有用, 且應該貼附在任何錯誤報告的檔案中.',
			'diagnostics:unittester:description' => '以下為診斷測試, 是由插件所註冊與執行, 以便對Elgg平台進行偵錯.',

			'diagnostics:unittester:description' => '單元測試會針對損壞與一堆臭蟲的APIs, 檢查Elgg的核心部份.',
			'diagnostics:unittester:debug' => '在執行單元測試時, 網站必須在偵錯模式下.',
			'diagnostics:unittester:warning' => '警告: 這些測試會在您的資料庫中留下偵錯物件.<br />請勿在實際運作的網站中使用!',

			'diagnostics:test:executetest' => '執行測試',
			'diagnostics:test:executeall' => '執行全部',
			'diagnostics:unittester:notests' => '抱歉, 目前未安裝單元測試模組.',
			'diagnostics:unittester:testnotfound' => '抱歉, 由於該測試未發現, 故不會產生報告',

			'diagnostics:unittester:testresult:nottestclass' => '失敗 - 不是一個測試類別的結果',
			'diagnostics:unittester:testresult:fail' => '失敗',
			'diagnostics:unittester:testresult:success' => '成功',

			'diagnostics:unittest:example' => '單元測試範例, 只能在偵錯模式下使用.',

			'diagnostics:unittester:report' => '%s 的測試報告',

			'diagnostics:download' => '下載',


			'diagnostics:header' => '========================================================================
Elgg診斷報告
產生的 %s , 由 %s 產生
========================================================================

',
			'diagnostics:report:basic' => '
Elgg 發行 %s, 版本為 %s

------------------------------------------------------------------------',
			'diagnostics:report:php' => '
PHP 資訊:
%s
------------------------------------------------------------------------',
			'diagnostics:report:plugins' => '
安裝的插件與細節:

%s
------------------------------------------------------------------------',
			'diagnostics:report:md5' => '
安裝的檔案與查核資料:

%s
------------------------------------------------------------------------',
			'diagnostics:report:globals' => '
全域變數:

%s
------------------------------------------------------------------------',

	);

	add_translation("zh_tw",$traditionalChinese);
?>