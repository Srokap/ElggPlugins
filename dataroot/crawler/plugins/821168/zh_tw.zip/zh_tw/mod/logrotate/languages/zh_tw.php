<?php
/**
 * Elgg log rotator language pack.
 *
 * @package ElggLogRotate
 */

$traditionalChinese = array(
	'logrotate:period' => '系統記錄檔封存的頻率為何?',

	'logrotate:weekly' => '每週一次',
	'logrotate:monthly' => '每月一次',
	'logrotate:yearly' => '每年一次',

	'logrotate:logrotated' => "記錄檔已循環Log rotated\n",
	'logrotate:lognotrotated' => "循環記錄檔時發生錯誤\n",
	
	'logrotate:date' => '刪除晚於一...的封存記錄',

	'logrotate:week' => '週',
	'logrotate:month' => '月',
	'logrotate:year' => '年',
		
	'logrotate:logdeleted' => "記錄檔已被刪除\n",
	'logrotate:lognotdeleted' => "刪除記錄檔發生錯誤\n",
);

add_translation("zh_tw", $traditionalChinese);
