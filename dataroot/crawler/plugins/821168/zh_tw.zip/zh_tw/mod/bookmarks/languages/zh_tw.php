<?php
/**
 * Bookmarks English language file
 * @正體中文 by http://myggyy.com
 */

$traditionalChinese = array(

	/**
	 * Menu items and titles
	 */
	'bookmarks' => "書簽",
	'bookmarks:add' => "新增書簽",
	'bookmarks:edit' => "編輯書簽",
	'bookmarks:owner' => "%s 的書簽",
	'bookmarks:friends' => "好友的書簽",
	'bookmarks:everyone' => "所有書簽",
	'bookmarks:this' => "將本頁加入書簽",
	'bookmarks:this:group' => "%s 的書簽",
	'bookmarks:bookmarklet' => "取得書簽工具",
	'bookmarks:bookmarklet:group' => "取得群組的書簽工具",
	'bookmarks:inbox' => "書簽收件箱",
	'bookmarks:morebookmarks' => "更多書簽",
	'bookmarks:more' => "更多",
	'bookmarks:with' => "分享給",
	'bookmarks:new' => "一個新的書簽",
	'bookmarks:via' => "經過書簽",
	'bookmarks:address' => "書簽的位址",
	'bookmarks:none' => '沒有書簽',

	'bookmarks:delete:confirm' => "您確定要刪除這個資源嗎?",

	'bookmarks:numbertodisplay' => '顯示的書簽書',

	'bookmarks:shared' => "已被加入書簽",
	'bookmarks:visit' => "訪問資源",
	'bookmarks:recent' => "最近的書簽",

	'river:create:object:bookmarks' => '%s 將 %s 加入書簽',
	'river:comment:object:bookmarks' => '%s 對於書簽 %s 發表評論',
	'bookmarks:river:annotate' => '這個書簽的評論',
	'bookmarks:river:item' => '一個項目',

	'item:object:bookmarks' => '書簽',

	'bookmarks:group' => '群組書簽',
	'bookmarks:enablebookmarks' => '啟用群組書簽',
	'bookmarks:nogroup' => '這個群組尚無任何書簽',
	'bookmarks:more' => '更多書簽',

	'bookmarks:no_title' => '無標題',

	/**
	 * Widget and bookmarklet
	 */
	'bookmarks:widget:description' => "顯示您最近的書簽.",

	'bookmarks:bookmarklet:description' =>
			"書簽的書簽工具(bookmarklet)允許您將找到的任何資源, 分享給好友, 或者只是留下來自己使用. 要使用它, 只要將底下的按鈕拖放到瀏覽器的'我的最愛列'即可:",

	'bookmarks:bookmarklet:descriptionie' =>
			"如果您使用Internet Explorer, 您需要在書簽工具的圖示上按下滑鼠右鏈, 選取 '加到我的取愛', 然後選擇'我的最愛列'.",

	'bookmarks:bookmarklet:description:conclusion' =>
			"之後, 您就可以在任何時候, 點擊它以保存任何您訪問過的網頁.",

	/**
	 * Status messages
	 */

	'bookmarks:save:success' => "您的項目已經加入到書簽了.",
	'bookmarks:delete:success' => "您的書簽已被刪除.",

	/**
	 * Error messages
	 */

	'bookmarks:save:failed' => "無法儲存書簽. 請確定您輸入正確的標題與位址, 然後再試一次.",
	'bookmarks:save:invalid' => "書簽的位址不合法, 無法儲存.",
	'bookmarks:delete:failed' => "書簽無法刪除, 請再試一次.",
);

add_translation('zh_tw', $traditionalChinese);