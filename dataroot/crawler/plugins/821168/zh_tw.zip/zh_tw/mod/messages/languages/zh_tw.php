<?php
/**
* Elgg send a message action page
* 
* @正體中文 by http://myggyy.com
* @正體中文 by http://ggyy.com  
* @package ElggMessages
*/

$traditionalChinese = array(
	/**
	* Menu items and titles
	*/

	'messages' => "訊息",
	'messages:back' => "回到訊息",
	'messages:user' => "%s的收件箱",
	'messages:posttitle' => "%s的訊息: %s",
	'messages:inbox' => "收件箱",
	'messages:send' => "傳送",
	'messages:sent' => "已傳送",
	'messages:message' => "訊息",
	'messages:title' => "主題",
	'messages:to' => "收件人",
	'messages:from' => "寄件人",
	'messages:fly' => "傳送",
	'messages:replying' => "回覆訊息給",
	'messages:inbox' => "收件箱",
	'messages:sendmessage' => "傳送訊息",
	'messages:compose' => "撰寫新訊息",
	'messages:add' => "撰寫新訊息",
	'messages:sentmessages' => "已傳送的訊息",
	'messages:recent' => "最近的訊息",
	'messages:original' => "原始訊息",
	'messages:yours' => "您的訊息",
	'messages:answer' => "回覆",
	'messages:toggle' => '選取全部',
	'messages:markread' => '標示為已閱',
	'messages:recipient' => '選取一位收到人;',
	'messages:to_user' => '傳送給: %s',

	'messages:new' => '新的訊息',

	'notification:method:site' => '網站',

	'messages:error' => '儲存訊息時發生錯誤, 請再試一次.',

	'item:object:messages' => '訊息',

	/**
	* Status messages
	*/

	'messages:posted' => "訊息已成功傳送.",
	'messages:success:delete:single' => '訊息已刪除',
	'messages:success:delete' => '訊息刪除',
	'messages:success:read' => '標示為已讀的訊息',
	'messages:error:messages_not_selected' => '未選取任何訊息',
	'messages:error:delete:single' => '無法刪除這條訊息',

	/**
	* Email messages
	*/

	'messages:email:subject' => '您有一條新的訊息!',
	'messages:email:body' => "您有一條來自於 %s的訊息. 內容:


	%s


	要查看訊息, 請點擊:

	%s

	要傳送一條訊息給 %s, 請點擊:

	%s

	請勿直接回覆本郵件, 謝謝.",

	/**
	* Error messages
	*/

	'messages:blank' => "抱歉; 訊息的主體不能為空白.",
	'messages:notfound' => "抱歉; 無法找到指定的訊息.",
	'messages:notdeleted' => "抱歉; 無法刪除這條訊息.",
	'messages:nopermission' => "您沒有改變該訊息的權限.",
	'messages:nomessages' => "沒有任何訊息.",
	'messages:user:nonexist' => "無法找到收件人.",
	'messages:user:blank' => "未選取任何訊息的傳送對象.",

	'messages:deleted_sender' => '刪除的使用者',

);
		
add_translation("zh_tw", $traditionalChinese);