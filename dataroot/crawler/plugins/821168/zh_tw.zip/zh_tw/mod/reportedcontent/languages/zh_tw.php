<?php
/**
 * Elgg reported content plugin language pack
 *
 * @正體中文 by http://myggyy.com
 * @正體中文 by http://ggyy.com   
 * @package ElggReportedContent
 */

$traditionalChinese = array(
	'item:object:reported_content' => '舉報的項目',
	'admin:administer_utilities:reportedcontent' => "舉報的內容",
	'reportedcontent' => '舉報的內容',
	'reportedcontent:this' => '舉報',
	'reportedcontent:this:tooltip' => '將此頁舉報給系統管理員',
	'reportedcontent:none' => '沒有舉報的內容',
	'reportedcontent:report' => '舉報給系統管理員',
	'reportedcontent:title' => '頁面標題',
	'reportedcontent:deleted' => '舉報的內容已刪除',
	'reportedcontent:notdeleted' => '無法刪除該項舉報',
	'reportedcontent:delete' => '刪除舉報',
	'reportedcontent:areyousure' => '您確定要刪除嗎?',
	'reportedcontent:archive' => '封存舉報',
	'reportedcontent:archived' => '這個舉報已被封存',
	'reportedcontent:visit' => '查看舉報的項目',
	'reportedcontent:by' => '舉報人',
	'reportedcontent:objecttitle' => '頁面的標題',
	'reportedcontent:objecturl' => '頁面的車結',
	'reportedcontent:reason' => '舉報的理由',
	'reportedcontent:description' => '您為何舉報?',
	'reportedcontent:address' => '這個項目的位置',
	'reportedcontent:success' => '您的舉報已被傳送給網站管理員',
	'reportedcontent:failing' => '您的舉報無法被傳送',
	'reportedcontent:report' => '舉報',
	'reportedcontent:moreinfo' => '更多資訊',
	'reportedcontent:instructions' => '這項舉報會被傳送給系統管理員, 以便進一步查核.',
	'reportedcontent:numbertodisplay' => '顯示的舉報數',
	'reportedcontent:widget:description' => '顯示舉報的內容',
	'reportedcontent:user' => '舉報人',

	'reportedcontent:failed' => '抱歉, 舉報失敗.',
	'reportedcontent:notarchived' => '無法將舉報封存',
);

add_translation("zh_tw", $traditionalChinese);
