<?php
/**
 * Elgg profile plugin language pack
 */

$traditionalChinese = array(
	'profile' => '個人資訊',
	'profile:notfound' => '抱歉. 找不到要求的個人資料.',

);

add_translation('zh_tw', $traditionalChinese);