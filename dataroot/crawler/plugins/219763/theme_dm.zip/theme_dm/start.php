<?php

    /**
     * BlackTech theme
     **/
     
     /**
	 * Initialise the theme 
	 *
	 */
	function blacktech_init(){
	
    }
	
	// Initialise log browser
	register_elgg_event_handler('init','system','blacktech_init');
	
?>