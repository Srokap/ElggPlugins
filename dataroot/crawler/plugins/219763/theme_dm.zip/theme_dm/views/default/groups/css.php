<?php

	/**
	 * Elgg Groups 
	 * 
	 * @package ElggForums
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd <info@elgg.com>
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

?>

#content_area_group_title h2 {
	background: black url(<?php echo $vars['url']; ?>mod/theme_blacktech/graphics/box_header_dark.gif) repeat-x left top;
	padding:5px;
	margin:0 0 10px 0;
	color: #ffffff;
	font-size:1.35em;
	line-height:1.2em;
}

#two_column_left_sidebar_maincontent #owner_block_content {
	margin:0 0 10px 0 !important;
        background:#000000;
}

#groups_info_column_left {
	float:left:
	width:435px;
	margin-left:230px;
	margin-right:10px;
        background:#000000;
}

#groups_info_column_left .odd {
	background:black;
}
#groups_info_column_left .even {
	background:#000000;
}
#groups_info_column_left p {
	margin:0 0 7px 0;
	padding:2px 4px;
}

#groups_info_column_right {
	float:left;
	width:230px;
	margin:0 0 0 10px;
}
#groups_info_wide p {
	text-align: right;
	padding-right:10px;
        background:#000000;
}
#group_stats {
	width:180px;
	background: #000000;
	padding:10px;
	margin:10px 0 20px 0;
}
#group_stats p {
	margin:0;
}
#group_members {
	margin-bottom:10px;
        background:#000000;
}

.right_column {
	clear:left;
	float:right;
	width:348px;
	margin:0 10px 0 0;
        background:#000000;
}
#left_column {
	width:348px;
	float:left;
	margin:0 0 0 10px;
        background:#000000;

}
/* IE 6 fixes */
* html #left_column { 
	width:328px;
}
* html .right_column { 
	width:328px;
}

#group_members h2,
.right_column h2,
#left_column h2 {
	background: black url(<?php echo $vars['url']; ?>mod/zhedgehogstheme/graphics/box_header_dark.gif) repeat-x left top;
	border:1px solid black;
	margin:0 0 5px 0;
	padding:5px;
	color:red;
	font-size:1.25em;
	line-height:1.2em;
}

#left_column #mb_input_wrapper {
	/* background:#000000; */
	border:none;
	padding:0px;
	margin:0 !important;
}
#left_column #mb_input_wrapper #testing.input_textarea {
	width:334px;
	color:black;
	margin:6px 0 0 0;
}
#left_column #mb_input_wrapper #postit {
	margin:10px 0 0 0;
}
#left_column #messageboard_wrapper {
	padding:0 !important;
}
#left_column #mb_input_wrapper #messageboard_widget_menu {
	text-align: right;
}
.member_icon {
	margin:6px 0 0px 6px;
	float:left;
}


/* group forums overview page */
.forums_table_head {
    background: black;
    color:#cc0000;
    padding:4px;
}
.forums_table_topics {
    padding:4px;
    border-bottom:1px solid black;
        background:#000000;
}
.forums_table_topics h3 a {
	font-size: 1.3em;
	color:#990000; /* red */
}
.forums_table_topics h3 a:hover {
	color:white;
}
.forum_access {
	font-size: small;	
}
.forums_table_topics p {
	margin:0px 0px 5px 0;
}
.forums_table_topics a {
	color:#666666;
}
.forums_table_topics a:hover {
	color:#990000; /* red */
}
.forums_table_topics p.forum_tags a {
	color:#990000; /* red */
}


/* topics overview page */
#topic_titles {
    background: black;
    color:#ffffff;
    padding:4px;
    margin:20px 0 0 0;
}

/* topic posts pages */
.post_icon {
    float:left;
    margin:0 8px 4px 0;
}

.topic_post {
    border-bottom:1px solid black;
    margin:10px;
}

.topic_post h2 {
    margin-bottom:20px;
}

.topic_post table, td {
    border:none;
}

.topic_title {
	font-size: 1.2em;
	line-height: 1.1em;
	margin:0;
	padding:0 0 4px 0;
}

.forum_topics {
    padding:0;
    margin:0;
    /* border:1px solid #ddd; */
    border-top:0;
}

/* alternating bckgnd on topics */
.forum_topics .odd {
	background-color:#666666;
	padding: 4px;
	border-bottom:1px solid black;
}
.forum_topics .even {
	/* background-color:black; */
	padding: 4px;
	border-bottom:1px solid black;
}
.forum_topics .even a,
.forum_topics .odd a {
	color:#666666;
}
.forum_topics .even a:hover,
.forum_topics .odd a:hover {
	color:#990000; /* red */
}
.forum_topics .even p.topic_title a,
.forum_topics .odd p.topic_title a {
	color:#990000; /* red */
}

/* group latest discussions widget */
#latest_discussion_widget {
	margin:0 0 20px 0;
}
.forum_latest {
	margin:0 0 10px 0;
	border-bottom:1px solid black;
}
.forum_latest .topic_owner_icon {
	float:left;
}
.forum_latest .topic_title {
	margin-left:35px;
}
.forum_latest .topic_title p {
	font-size: 0.8em;
	line-height: 1.0em;
    padding:0;
    margin:0;
}

.forum_latest p.topic_replies {
	color:#999999;
    padding:3px 0 0 0;
    margin:0;
}

a.add_topic_button {
	font: 12px/100% Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #ffffff;
	background:#990000; /* red */
	border: 2px solid #990000; /* red */
	-webkit-border-radius: 4px; 
	-moz-border-radius: 4px;
	/*
	width: auto;
	height: 25px;
	*/
	padding: 4px 6px 4px 6px;
	margin:0 0 0 10px;
	cursor: pointer;
	display:table;
}
a.add_topic_button:hover {
	background: black;
	color:#990000; /* red */
	border: 2px solid #990000; /* red */
	text-decoration: none;
}

/* group files widget */
#filerepo_widget_layout {
	margin:0 0 20px 0;
}
/* group pages widget */
#group_pages_widget {
	margin:0 0 20px 0;
}

/* latest discussion listing */
p.latest_discussion_info {
	float:right;
	width:220px;
}

span.timestamp {
	color:#666666;
	font-size: 90%;
}
