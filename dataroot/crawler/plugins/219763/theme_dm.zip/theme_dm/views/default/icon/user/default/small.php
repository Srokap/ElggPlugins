<?php
	echo $vars['url'] . "mod/theme_blacktech/graphics/user_icons/defaultsmall.gif";
?>