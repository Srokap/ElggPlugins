<?php

	if ($vars['size'] == 'large') {
		$ext = '_lrg';
	} else {
		$ext = '';
	}
	echo "<img src=\"{$CONFIG->wwwroot}mod/theme_blacktech/graphics/file_icons/vcard{$ext}.gif\" border=\"0\" />";

?>