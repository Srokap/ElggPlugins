<?php
function snow_init() {	
	elgg_register_js('snowstorm-min.js', 'mod/snow/js/snowstorm-min.js', 'head');
    elgg_load_js('snowstorm-min.js');
}
elgg_register_event_handler('init','system','snow_init');
?>