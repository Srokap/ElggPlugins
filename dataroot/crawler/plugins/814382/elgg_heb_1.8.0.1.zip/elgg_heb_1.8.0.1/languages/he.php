<?php
/**
 * Core Hebrew Language
 *
 * @package Elgg.Core
 * @subpackage Languages.Hebrew
 */

$hebrew = array(
/**
 * Sites
 */

	'item:site' => "אתרים",

/**
 * Sessions
 */

	'login' => "כניסה למערכת",
	'loginok' => "כניסה למערכת בוצעה בהצלחה.",
	'loginerror' => "כניסה למערכת נכשלה. אנא בדוק/בדקי את פרטיך ונסה/י שוב.",
	'login:empty' => "יש להזין שם משתמש וסיסמא.",
	'login:baduser' => "לא הצלחנו למצוא את חשבון המשתמש שלך.",
	'auth:nopams' => "שגיאה פנימית. לא מותקן שיטת אימות משתמשים.",

	'logout' => "יציאה מהמערכת",
	'logoutok' => "יציאה מהמערכת בוצעה בהצלחה.",
	'logouterror' => "יציאה מהמערכת נכשלה. אנא נסה/י שוב.",

	'loggedinrequired' => "הצפייה בדף זה לחברי הרשת בלבד.",
	'adminrequired' => "הצפייה בדף זה למנהלי הרשת בלבד.",
	'membershiprequired' => "הצפייה בדף זה לחברי הקבוצה בלבד.",


/**
 * Errors
 */
	'exception:title' => "Fatal Error.",

	'actionundefined' => "The requested action (%s) was not defined in the system.",
	'actionnotfound' => "The action file for %s was not found.",
	'actionloggedout' => "Sorry, you cannot perform this action while logged out.",
	'actionunauthorized' => 'You are unauthorized to perform this action',

	'InstallationException:SiteNotInstalled' => 'Unable to handle this request. This site '
		. ' is not configured or the database is down.',
	'InstallationException:MissingLibrary' => 'Could not load %s',
	'InstallationException:CannotLoadSettings' => 'Elgg could not load the settings file. It does not exist or there is a file permissions issue.',

	'SecurityException:Codeblock' => "Denied access to execute privileged code block",
	'DatabaseException:WrongCredentials' => "Elgg couldn't connect to the database using the given credentials. Check the settings file.",
	'DatabaseException:NoConnect' => "Elgg couldn't select the database '%s', please check that the database is created and you have access to it.",
	'SecurityException:FunctionDenied' => "Access to privileged function '%s' is denied.",
	'DatabaseException:DBSetupIssues' => "There were a number of issues: ",
	'DatabaseException:ScriptNotFound' => "Elgg couldn't find the requested database script at %s.",
	'DatabaseException:InvalidQuery' => "Invalid query",

	'IOException:FailedToLoadGUID' => "Failed to load new %s from GUID:%d",
	'InvalidParameterException:NonElggObject' => "Passing a non-ElggObject to an ElggObject constructor!",
	'InvalidParameterException:UnrecognisedValue' => "Unrecognised value passed to constuctor.",

	'InvalidClassException:NotValidElggStar' => "GUID:%d is not a valid %s",

	'PluginException:MisconfiguredPlugin' => "%s (guid: %s) is a misconfigured plugin. It has been disabled. Please search the Elgg wiki for possible causes (http://docs.elgg.org/wiki/).",
	'PluginException:CannotStart' => '%s (guid: %s) cannot start.  Reason: %s',
	'PluginException:InvalidID' => "%s is an invalid plugin ID.",
	'PluginException:InvalidPath' => "%s is an invalid plugin path.",
	'PluginException:InvalidManifest' => 'Invalid manifest file for plugin %s',
	'PluginException:InvalidPlugin' => '%s is not a valid plugin.',
	'PluginException:InvalidPlugin:Details' => '%s is not a valid plugin: %s',

	'ElggPlugin:MissingID' => 'Missing plugin ID (guid %s)',
	'ElggPlugin:NoPluginPackagePackage' => 'Missing ElggPluginPackage for plugin ID %s (guid %s)',

	'ElggPluginPackage:InvalidPlugin:MissingFile' => 'Missing file %s in package',
	'ElggPluginPackage:InvalidPlugin:InvalidDependency' => 'Invalid dependency type "%s"',
	'ElggPluginPackage:InvalidPlugin:InvalidProvides' => 'Invalid provides type "%s"',
	'ElggPluginPackage:InvalidPlugin:CircularDep' => 'Invalid %s dependency "%s" in plugin %s.  Plugins cannot conflict with or require something they provide!',

	'ElggPlugin:Exception:CannotIncludeFile' => 'Cannot include %s for plugin %s (guid: %s) at %s.  Check permissions!',
	'ElggPlugin:Exception:CannotRegisterViews' => 'Cannot open views dir for plugin %s (guid: %s) at %s.  Check permissions!',
	'ElggPlugin:Exception:CannotRegisterLanguages' => 'Cannot register languages for plugin %s (guid: %s) at %s.  Check permissions!',
	'ElggPlugin:Exception:CannotRegisterClasses' => 'Cannot register classes for plugin %s (guid: %s) at %s.  Check permissions!',
	'ElggPlugin:Exception:NoID' => 'No ID for plugin guid %s!',

	'PluginException:ParserError' => 'Error parsing manifest with API version %s in plugin %s.',
	'PluginException:NoAvailableParser' => 'Cannot find a parser for manifest API version %s in plugin %s.',
	'PluginException:ParserErrorMissingRequiredAttribute' => "Missing required '%s' attribute in manifest for plugin %s.",

	'ElggPlugin:Dependencies:Requires' => 'Requires',
	'ElggPlugin:Dependencies:Suggests' => 'Suggests',
	'ElggPlugin:Dependencies:Conflicts' => 'Conflicts',
	'ElggPlugin:Dependencies:Conflicted' => 'Conflicted',
	'ElggPlugin:Dependencies:Provides' => 'Provides',
	'ElggPlugin:Dependencies:Priority' => 'Priority',

	'ElggPlugin:Dependencies:Elgg' => 'Elgg version',
	'ElggPlugin:Dependencies:PhpExtension' => 'PHP extension: %s',
	'ElggPlugin:Dependencies:PhpIni' => 'PHP ini setting: %s',
	'ElggPlugin:Dependencies:Plugin' => 'Plugin: %s',
	'ElggPlugin:Dependencies:Priority:After' => 'After %s',
	'ElggPlugin:Dependencies:Priority:Before' => 'Before %s',
	'ElggPlugin:Dependencies:Priority:Uninstalled' => '%s is not installed',
	'ElggPlugin:Dependencies:Suggests:Unsatisfied' => 'Missing',


	'InvalidParameterException:NonElggUser' => "Passing a non-ElggUser to an ElggUser constructor!",

	'InvalidParameterException:NonElggSite' => "Passing a non-ElggSite to an ElggSite constructor!",

	'InvalidParameterException:NonElggGroup' => "Passing a non-ElggGroup to an ElggGroup constructor!",

	'IOException:UnableToSaveNew' => "Unable to save new %s",

	'InvalidParameterException:GUIDNotForExport' => "GUID has not been specified during export, this should never happen.",
	'InvalidParameterException:NonArrayReturnValue' => "Entity serialisation function passed a non-array returnvalue parameter",

	'ConfigurationException:NoCachePath' => "Cache path set to nothing!",
	'IOException:NotDirectory' => "%s is not a directory.",

	'IOException:BaseEntitySaveFailed' => "Unable to save new object's base entity information!",
	'InvalidParameterException:UnexpectedODDClass' => "import() passed an unexpected ODD class",
	'InvalidParameterException:EntityTypeNotSet' => "Entity type must be set.",

	'ClassException:ClassnameNotClass' => "%s is not a %s.",
	'ClassNotFoundException:MissingClass' => "Class '%s' was not found, missing plugin?",
	'InstallationException:TypeNotSupported' => "Type %s is not supported. This indicates an error in your installation, most likely caused by an incomplete upgrade.",

	'ImportException:ImportFailed' => "Could not import element %d",
	'ImportException:ProblemSaving' => "There was a problem saving %s",
	'ImportException:NoGUID' => "New entity created but has no GUID, this should not happen.",

	'ImportException:GUIDNotFound' => "Entity '%d' could not be found.",
	'ImportException:ProblemUpdatingMeta' => "There was a problem updating '%s' on entity '%d'",

	'ExportException:NoSuchEntity' => "No such entity GUID:%d",

	'ImportException:NoODDElements' => "No OpenDD elements found in import data, import failed.",
	'ImportException:NotAllImported' => "Not all elements were imported.",

	'InvalidParameterException:UnrecognisedFileMode' => "Unrecognised file mode '%s'",
	'InvalidParameterException:MissingOwner' => "File %s (file guid:%d) (owner guid:%d) is missing an owner!",
	'IOException:CouldNotMake' => "Could not make %s",
	'IOException:MissingFileName' => "You must specify a name before opening a file.",
	'ClassNotFoundException:NotFoundNotSavedWithFile' => "Unable to load filestore class %s for file %u",
	'NotificationException:NoNotificationMethod' => "No notification method specified.",
	'NotificationException:NoHandlerFound' => "No handler found for '%s' or it was not callable.",
	'NotificationException:ErrorNotifyingGuid' => "There was an error while notifying %d",
	'NotificationException:NoEmailAddress' => "Could not get the email address for GUID:%d",
	'NotificationException:MissingParameter' => "Missing a required parameter, '%s'",

	'DatabaseException:WhereSetNonQuery' => "Where set contains non WhereQueryComponent",
	'DatabaseException:SelectFieldsMissing' => "Fields missing on a select style query",
	'DatabaseException:UnspecifiedQueryType' => "Unrecognised or unspecified query type.",
	'DatabaseException:NoTablesSpecified' => "No tables specified for query.",
	'DatabaseException:NoACL' => "No access control was provided on query",

	'InvalidParameterException:NoEntityFound' => "No entity found, it either doesn't exist or you don't have access to it.",

	'InvalidParameterException:GUIDNotFound' => "GUID:%s could not be found, or you can not access it.",
	'InvalidParameterException:IdNotExistForGUID' => "Sorry, '%s' does not exist for guid:%d",
	'InvalidParameterException:CanNotExportType' => "Sorry, I don't know how to export '%s'",
	'InvalidParameterException:NoDataFound' => "Could not find any data.",
	'InvalidParameterException:DoesNotBelong' => "Does not belong to entity.",
	'InvalidParameterException:DoesNotBelongOrRefer' => "Does not belong to entity or refer to entity.",
	'InvalidParameterException:MissingParameter' => "Missing parameter, you need to provide a GUID.",
	'InvalidParameterException:LibraryNotRegistered' => '%s is not a registered library',

	'APIException:ApiResultUnknown' => "API Result is of an unknown type, this should never happen.",
	'ConfigurationException:NoSiteID' => "No site ID has been specified.",
	'SecurityException:APIAccessDenied' => "Sorry, API access has been disabled by the administrator.",
	'SecurityException:NoAuthMethods' => "No authentication methods were found that could authenticate this API request.",
	'InvalidParameterException:APIMethodOrFunctionNotSet' => "Method or function not set in call in expose_method()",
	'InvalidParameterException:APIParametersArrayStructure' => "Parameters array structure is incorrect for call to expose method '%s'",
	'InvalidParameterException:UnrecognisedHttpMethod' => "Unrecognised http method %s for api method '%s'",
	'APIException:MissingParameterInMethod' => "Missing parameter %s in method %s",
	'APIException:ParameterNotArray' => "%s does not appear to be an array.",
	'APIException:UnrecognisedTypeCast' => "Unrecognised type in cast %s for variable '%s' in method '%s'",
	'APIException:InvalidParameter' => "Invalid parameter found for '%s' in method '%s'.",
	'APIException:FunctionParseError' => "%s(%s) has a parsing error.",
	'APIException:FunctionNoReturn' => "%s(%s) returned no value.",
	'APIException:APIAuthenticationFailed' => "Method call failed the API Authentication",
	'APIException:UserAuthenticationFailed' => "Method call failed the User Authentication",
	'SecurityException:AuthTokenExpired' => "Authentication token either missing, invalid or expired.",
	'CallException:InvalidCallMethod' => "%s must be called using '%s'",
	'APIException:MethodCallNotImplemented' => "Method call '%s' has not been implemented.",
	'APIException:FunctionDoesNotExist' => "Function for method '%s' is not callable",
	'APIException:AlgorithmNotSupported' => "Algorithm '%s' is not supported or has been disabled.",
	'ConfigurationException:CacheDirNotSet' => "Cache directory 'cache_path' not set.",
	'APIException:NotGetOrPost' => "Request method must be GET or POST",
	'APIException:MissingAPIKey' => "Missing API key",
	'APIException:BadAPIKey' => "Bad API key",
	'APIException:MissingHmac' => "Missing X-Elgg-hmac header",
	'APIException:MissingHmacAlgo' => "Missing X-Elgg-hmac-algo header",
	'APIException:MissingTime' => "Missing X-Elgg-time header",
	'APIException:MissingNonce' => "Missing X-Elgg-nonce header",
	'APIException:TemporalDrift' => "X-Elgg-time is too far in the past or future. Epoch fail.",
	'APIException:NoQueryString' => "No data on the query string",
	'APIException:MissingPOSTHash' => "Missing X-Elgg-posthash header",
	'APIException:MissingPOSTAlgo' => "Missing X-Elgg-posthash_algo header",
	'APIException:MissingContentType' => "Missing content type for post data",
	'SecurityException:InvalidPostHash' => "POST data hash is invalid - Expected %s but got %s.",
	'SecurityException:DupePacket' => "Packet signature already seen.",
	'SecurityException:InvalidAPIKey' => "Invalid or missing API Key.",
	'NotImplementedException:CallMethodNotImplemented' => "Call method '%s' is currently not supported.",

	'NotImplementedException:XMLRPCMethodNotImplemented' => "XML-RPC method call '%s' not implemented.",
	'InvalidParameterException:UnexpectedReturnFormat' => "Call to method '%s' returned an unexpected result.",
	'CallException:NotRPCCall' => "Call does not appear to be a valid XML-RPC call",

	'PluginException:NoPluginName' => "The plugin name could not be found",

	'SecurityException:authenticationfailed' => "לא ניתן היה לאמת את המשתמש",

	'CronException:unknownperiod' => "%s אינה תקופה הניתנת לזיהוי.",

	'SecurityException:deletedisablecurrentsite' => "לא ניתן למחוק או להפוך ללא פעיל, אתשר בו הינך צופה ברגע זה!",

	'RegistrationException:EmptyPassword' => "יש לזהין סיסמא",
	'RegistrationException:PasswordMismatch' => "הסיסמאות אינן זהות אחת לשנייה",
	'LoginException:BannedUser' => "נחסמת מאתר זה ואינך יכול/ה להכנס למערכת",
	'LoginException:UsernameFailure' => "הכניסה למערכת נכשלה. אנא בדוק/בדקי שם משתמש וסיסמא.",
	'LoginException:PasswordFailure' => "הכניסה למערכת נכשלה. אנא בדוק/בדקי שם משתמש וסיסמא.",
	'LoginException:AccountLocked' => "חשבונך ננעל עקב נסיונות כניסה למערכת רבים מדי.",

	'memcache:notinstalled' => 'PHP memcache module not installed, you must install php5-memcache',
	'memcache:noservers' => 'No memcache servers defined, please populate the $CONFIG->memcache_servers variable',
	'memcache:versiontoolow' => 'Memcache needs at least version %s to run, you are running %s',
	'memcache:noaddserver' => 'Multiple server support disabled, you may need to upgrade your PECL memcache library',

	'deprecatedfunction' => 'Warning: This code uses the deprecated function \'%s\' and is not compatible with this version of Elgg',

	'pageownerunavailable' => 'Warning: The page owner %d is not accessible!',
	'viewfailure' => 'There was an internal failure in the view %s',
	'changebookmark' => "אנא שנה את הקישור עבור דף זה",
/**
 * API
 */
	'system.api.list' => "List all available API calls on the system.",
	'auth.gettoken' => "This API call lets a user obtain a user authentication token which can be used for authenticating future API calls. Pass it as the parameter auth_token",

/**
 * User details
 */

	'name' => "שם בעברית",
	'email' => "כתובת מייל",
	'username' => "שם משתמש",
	'loginusername' => "שם משתמש או כתבות מייל",
	'password' => "סיסמא",
	'passwordagain' => "סיסמא (שוב לצורך אימות)",
	'admin_option' => "הפוך משתמש זה למנהל?",

/**
 * Access
 */

	'PRIVATE' => "פרטי",
	'LOGGED_IN' => "חברי רשת",
	'PUBLIC' => "ציבורי",
	'access:friends:label' => "חברים",
	'access' => "הרשאת גישה",

/**
 * Dashboard and widgets
 */

	'dashboard' => "פנל",
	'dashboard:nowidgets' => "בפנל ניתן לעקוב אחר פעילות ותכנים באתר אשר חשובים לך.",

	'widgets:add' => "הוספת ווידג'טים",
	'widgets:add:description' => "לחץ/י על הווידג'טים אשר ברצונכך להוסיף לדף.",
	'widgets:position:fixed' => "(מקום קבוע בדף)",
	'widget:unavailable' => "כבר הוספת ווידג'ט זה",
	'widget:numbertodisplay' => "כמה פריטים להציג?",

	'widget:delete' => "הסרת %s",
	'widget:edit' => "התאמה אישית",

	'widgets' => "ווידג'טים",
	'widget' => "ווידג'ט",
	'item:object:widget' => "ווידג'טים",
	'widgets:save:success' => "הווידג'ט נשמר בהצלחה.",
	'widgets:save:failure' => "לא הצלחנו לשמור את הווידג'ט. אנא נסה/י שוב.",
	'widgets:add:success' => "הווידג'ט נוסף בהצלחה.",
	'widgets:add:failure' => "לא הצלחנו להוסיף את הווידג'ט.",
	'widgets:move:failure' => "לא הצלחנו לשמור את המיקום החדש של הווידג'ט.",
	'widgets:remove:failure' => "לא ניתן להסיר ווידג'ט זה",

/**
 * Groups
 */

	'group' => "קבוצה",
	'item:group' => "קבוצות",

/**
 * Users
 */

	'user' => "משתמש",
	'item:user' => "משתמשים",

/**
 * Friends
 */

	'friends' => "חברים",
	'friends:yours' => "חבריי",
	'friends:owned' => "חברי %s",
	'friend:add' => "הוספת חבר",
	'friend:remove' => "הסרת חבר",

	'friends:add:successful' => "הוספת את %s כחבר/ה.",
	'friends:add:failure' => "לא הצלחנו להוסיף את %s כחבר/ה. אנא נסה/י שוב.",

	'friends:remove:successful' => "הסרת את %s מרשימת החברים שלך.",
	'friends:remove:failure' => "לא הצלחנו להסיר את %s מרשימת החברים שלך. אנא נסה/י שוב.",

	'friends:none' => "המשתמש/ת טרם הוסיף/ה חברים כלשם.",
	'friends:none:you' => "אין לך בינתיים חברים.",

	'friends:none:found' => "לא נמצאו חברים.",

	'friends:of:none' => "טרם הוסיפו את המשתמש/ת כחברה.",
	'friends:of:none:you' => "טרם הוסיפו אותך כחבר/ה. אנשים יוכלו למצוא אותך אם תתחיל/י להוסיף תכנים ומידע בדף הפרופיל!",

	'friends:of:owned' => "אנשים אשר הוסיפו את %s כחבר/ה",

	'friends:of' => "חברים של",
	'friends:collections' => "רשימות חברים",
	'collections:add' => "רשימה חדשה",
	'friends:collections:add' => "רשימת חברים חדשה",
	'friends:addfriends' => "בחר/י חברים",
	'friends:collectionname' => "שם הרשימה",
	'friends:collectionfriends' => "חברים ברשימה זו",
	'friends:collectionedit' => "עריכת הרשימה",
	'friends:nocollections' => "טרם יצרת רשימות.",
	'friends:collectiondeleted' => "הרשימה נמחקה.",
	'friends:collectiondeletefailed' => "לא הצלחנו למחוק את הרשימה. או שאינך בעל/ת הרשאות, או שאירע בעיה אחרת.",
	'friends:collectionadded' => "הרשימה נוצרה בהצלחה",
	'friends:nocollectionname' => "יש לתת שם לרשימה.",
	'friends:collections:members' => "חברי הרשימה",
	'friends:collections:edit' => "עריכת רשימה",

	'friends:river:add' => "כעת חבר/ה של %s",

	'friendspicker:chararray' => "אבגדהוזחטיכלמנסעפצקרשת",

	'avatar' => "אווטאר",
	'avatar:create' => "צור את האווטאר שלי",
	'avatar:edit' => "עריכת האווטאר",
	'avatar:preview' => "תצוגה מוקדמת",
	'avatar:upload' => "העלאת אווטאר חדש",
	'avatar:current' => "האווטאר הנוכחי",
	'avatar:crop:title' => "כלי לגזירת האווטאר",
	'avatar:upload:instructions' => "האווטאר הינו התמונה אשר מוצגת בדף הפרופיל שלך.
ניתן לשנותה כמה פעמים שרוצים. (סוגי קובץ הנתמכים על ידי המערכת הם: GIF, JPG or PNG)",
	'avatar:create:instructions' => "לחץ למטה וגרור ריבוע כדי לקבוע את גבולות האווטאר שלך. תצוגה מקדימה של התמונה המעודכנת תופיע בצד. לסיום לחץ/י על 'צור את האווטאר שלי'.  ",
	'avatar:upload:success' => "האווטאר הועלה בהצלחה",
	'avatar:upload:fail' => "העלאת האווטאר נכשלה",
	'avatar:resize:fail' => "שינוי גודל האווטאר נכשל",
	'avatar:crop:success' => "האווטאר נגזר בהצלחה",
	'avatar:crop:fail' => "לא הצלחנו לגזור את האווטאר",

	'profile:edit' => "עריכת פרופיל",
	'profile:aboutme' => "אודותיי",
	'profile:description' => "אודותיי",
	'profile:briefdescription' => "תיאור קצר",
	'profile:location' => "מקום",
	'profile:skills' => "כישורים",
	'profile:interests' => "תחומי עניין",
	'profile:contactemail' => "מייל ליצירת קשר",
	'profile:phone' => "טלפון",
	'profile:mobile' => "נייד",
	'profile:website' => "אתר",
	'profile:twitter' => "שם משתמש בטוויטר",
	'profile:saved' => "הפרופיל נשמר בהצלחה.",

	'admin:appearance:profile_fields' => "עריכת שדות פרופיל",
	'profile:edit:default' => "עריכת שדות פרופיל",
	'profile:label' => "תווית",
	'profile:type' => "סוג פרופיל",
	'profile:editdefault:delete:fail' => "לא הצלחנו להסיר את פריט הפרופיל ברירת המחדל",
	'profile:editdefault:delete:success' => "מחיקת פריט הפרופיל ברירת המחדל בוצעה בהצלחה!",
	'profile:defaultprofile:reset' => "שוחזר פרופיל ברירת המחדל של המערכת",
	'profile:resetdefault' => "שחזר פרופיל ברירת המחדל",
	'profile:explainchangefields' => "ניתן להחליף את שדות הפרופיל הקיימות בשדות פרופיל מותאמות אישית, בעזרת הטופס למטה. \n\n תן לשדה הפרופיל החדש תווית, לדוגמא, 'קבוצה מועדפת', אחר כך בחר סוג שדא (טקסט, כתובות, תגים), ולחץ על כפתור 'הוספה'. כדי לשנות את סדר השדות העזר בידיות הגרירה. כדי לערוך שדא - לחץ על התווית. \n\n תמיד אפשר לשחזר את פרופיל ברירת המחדל, אבל המידע אשר נוסף באמצעות הפרופיל המותאם אישית יאבד.",
	'profile:editdefault:success' => "הפריט נוסף בהצלחה לפרופיל ברירת המחדל",
	'profile:editdefault:fail' => "לא הצלחנו לשמור את הפרופיל ברירת המחדל",


/**
 * Feeds
 */
	'feed:rss' => "RSS של דף זה",
/**
 * Links
 */
	'link:view' => "גש לקישור",
	'link:view:all' => "צפייה בכל",


/**
 * River
 */
	'river' => "מה חדש",
	'river:relationship:friend' => "כעת חבר/ה של",
	'river:noaccess' => "אינך בעל/ת הרשאות צפייה בפריט זה.",
	'river:posted:generic' => "%s פרסם/ה",
	'riveritem:single:user' => "משתמש",
	'riveritem:plural:user' => "משתמשים",
	'river:ingroup' => "לקבוצה %s",
	'river:none' => "לא נרשם כל פעילות",

	'river:widget:title' => "פעילות",
	'river:widget:description' => "הצגת הפעילות באתר",
	'river:widget:type' => "סוג הפעילות",
	'river:widgets:friends' => "פעילות חבריי",
	'river:widgets:all' => "כל הפעילות באתר",

/**
 * Notifications
 */
	'notifications:usersettings' => "הגדרת התראות",
	'notifications:methods' => "אנא ציין/י באיזה שיטה/ות להשתמש.",

	'notifications:usersettings:save:ok' => "ההגדרות נשמרו בהצלחה.",
	'notifications:usersettings:save:fail' => "הייתה בעיה בשמירת ההגדרות.",

	'user.notification.get' => "הצג את הגדרות ההתראות עבור משתמש ספציפי.",
	'user.notification.set' => "קבע הגדרת התראות עבור משתמש נתון.",
/**
 * Search
 */

	'search' => "חיפוש",
	'searchtitle' => "חיפוש: %s",
	'users:searchtitle' => "מחפש משתמשים: %s",
	'groups:searchtitle' => "מחפש קבוצות: %s",
	'advancedsearchtitle' => "%s אם תוצאות עבור %s",
	'notfound' => "לא מצאנו תוצאות.",
	'next' => "הבא",
	'previous' => "הקודם",

	'viewtype:change' => "שנה תצוגה",
	'viewtype:list' => "תצוגת רשימה",
	'viewtype:gallery' => "גלריה",

	'tag:search:startblurb' => "פריטים עם התג '%s':",

	'user:search:startblurb' => "משתמשים '%s':",
	'user:search:finishblurb' => "צפייה בעוד",

	'group:search:startblurb' => "קבוצות '%s':",
	'group:search:finishblurb' => "צפייה בעוד.",
	'search:go' => "חפש",
	'userpicker:only_friends' => "חברים בלבד",

/**
 * Account
 */

	'account' => "חשבון",
	'settings' => "הגדרות",
	'tools' => "כלים",

	'register' => "הרשמה",
	'registerok' => "הרשמתך ל%s בוצעה בהצלחה.",
	'registerbad' => "הרשמתך נכשלה הסיבה לא ידוע.",
	'registerdisabled' => "מנהל אתר זה חסם את אפשרות ההרשמה",

	'registration:notemail' => "כתובת המייל אינו תקין.",
	'registration:userexists' => "שם משתמש זה כבר רשום במערכת",
	'registration:usernametooshort' => "שם המשתמש צריך להכיל לפחות %u תווים.",
	'registration:passwordtooshort' => "הסיסמא צריך להכיל לפחות %u תווים.",
	'registration:dupeemail' => "כתבות מייל זו כבר רשומה במערכת.",
	'registration:invalidchars' => "מצטערים, שם המשתמש מכיל את התווים הבאים אשר אינם תקינים: %s.  תווים אלה אינם תקינים: %s",
	'registration:emailnotvalid' => "כתובת מייל זה אינה קבילה במערכת זו",
	'registration:passwordnotvalid' => "סיסמא זה אינו קביל במערכת זו",
	'registration:usernamenotvalid' => "שם מתשמש זה אינו קביל במערכת זו",

	'adduser' => "הוספת משתמש",
	'adduser:ok' => "יצרת משתמש חדש בהצלחה.",
	'adduser:bad' => "לא ניתן היה ליצור את המשתמש החדש.",

	'user:set:name' => "הגדרות שמות החשבון",
	'user:name:label' => "שם בעברית",
	'user:name:success' => "שינוי השם בוצע בהצלחה.",
	'user:name:fail' => "לא הצלחנו לשנות את השם.  אנא בדוק/בדקי שהשם אינו ארוך מדי ונסה/י שוב.",

	'user:set:password' => "סיסמא",
	'user:current_password:label' => "סיסמא נוכחית",
	'user:password:label' => "סיסמא חדשה",
	'user:password2:label' => "סיסמא חדשה שוב",
	'user:password:success' => "הסיסמא שונתה",
	'user:password:fail' => "לא הצלחנו לשנות את הסיסמא.",
	'user:password:fail:notsame' => "2 הסיסמאות אינן זהות!",
	'user:password:fail:tooshort' => "הסיסמא קצרה מדי!",
	'user:password:fail:incorrect_current_password' => "הסיסמא הנוכחית אשר הזנת אינה נכונה.",
	'user:resetpassword:unknown_user' => "משתמש לא תקין.",
	'user:resetpassword:reset_password_confirm' => "לאחר איפוס סיסמא אנו נשלח סיסמא חדשה לדואר האלקטרוני הרשומה במערכת.",

	'user:set:language' => "הגדרות שפה",
	'user:language:label' => "השפה שלך",
	'user:language:success' => "נשמרו הגדרות השפה.",
	'user:language:fail' => "לא הצלחנו לשמור את הגדרות השפה.",

	'user:username:notfound' => "שם המשתמש %s לא נמצא.",

	'user:password:lost' => "שכחתי סיסמא",
	'user:password:resetreq:success' => "בקשת סיסמא חדשה בוצעה בהצלחה, הודעה נשלחה לדואר האלקטרוני",
	'user:password:resetreq:fail' => "בקשת סיסמא חדשה לא הצליחה.",

	'user:password:text' => "כדי לבקש סיסמא חדשה, יש להוסיף את שם המשתמש למטה וללחוץ על כפתור הבקשה.",

	'user:persistent' => "זכור אותי",

	'walled_garden:welcome' => "ברוך בואך ל",

/**
 * Administration
 */
	'menu:page:header:administer' => "ניהול",
	'menu:page:header:configure' => "הגדרות",
	'menu:page:header:develop' => "פיתוח",

	'admin:view_site' => "צפייה באתר",
	'admin:loggedin' => "מזוהה במערכת כ%s",
	'admin:menu' => "תפריט",

	'admin:configuration:success' => "הגדרותיך נשמרו.",
	'admin:configuration:fail' => "לא ניתן היה לשמור את הגדרותיך",

	'admin:unknown_section' => "אזור ניהול לא בתוקף.",

	'admin' => "ניהול",
	'admin:description' => "פנל הניהול נותן שליטה בכל היבטי המערכת, החל מניהול משתמשים ועד להגדרת רכיבים. בחר מתוך האפשרויות למטה.",

	'admin:statistics' => "סטטיסטיקה",
	'admin:statistics:overview' => "סקירה",

	'admin:appearance' => "מראה",
	'admin:utilities' => "כלי עזר",

	'admin:users' => "משתמשים",
	'admin:users:online' => "עכשיו ברשת",
	'admin:users:newest' => "חדשים",
	'admin:users:add' => "הוספת משתמש חדש",
	'admin:users:description' => "פנל זה נותן שליטה בהגדרות המשתמשים באתר שלך. בחר מתוך האפשרויות למטה.",
	'admin:users:adduser:label' => "להוספת משתמש חדש, לחץ כאן...",
	'admin:users:opt:linktext' => "הגדרת משתמשים...",
	'admin:users:opt:description' => "הגדר משתמשים ומידע. ",
	'admin:users:find' => "חפש",

	'admin:settings' => "הגדרות",
	'admin:settings:basic' => "הגדרות בסיסיות",
	'admin:settings:advanced' => "הגדרות מתקדמות",
	'admin:site:description' => "פנל זה נותן שליטה על הגדרות גלובליות באתר שלך. בחר מתוך האפשרויות למטה.",
	'admin:site:opt:linktext' => "הגדרת האתר...",
	'admin:site:access:warning' => "שינוי הרשאות גישה משפיע רק על תכנים אשר נוצרו לאחר השינוי.",

	'admin:dashboard' => "פנל",
	'admin:widget:online_users' => "עכשיו ברשת",
	'admin:widget:online_users:help' => "מציג את המשתמשים אשר נמצאים עכשיו ברשת",
	'admin:widget:new_users' => "משתמשים חדשים",
	'admin:widget:new_users:help' => "הצגת המשתמשים החדשים",
	'admin:widget:content_stats' => "סטטיסטיקת תכנים",
	'admin:widget:content_stats:help' => "עקוב אחר התכנים שיוצרים משתמשי האתר",
	'widget:content_stats:type' => "סוג תוכן",
	'widget:content_stats:number' => "מספר",

	'admin:widget:admin_welcome' => "ברוך בואך",
	'admin:widget:admin_welcome:help' => "מבוא קצר לאזור הניהול",
	'admin:widget:admin_welcome:intro' =>
"ברוך בואך לאזור הניהול שלך! כעת הינך נמצא בפנל הניהול. פנל הניהול שימושי לצורך מעקב אחר הנעשה באתר.",

	'admin:widget:admin_welcome:admin_overview' =>
"הניווט באזור הניהול מתבצעת באמצעות התפריט הצדדי. התפריט מחולקת "
. " ל3 גזרות:
	<dl>
		<dt>ניהול</dt><dd>משימות יוםיום כגון מעקב אחר תוכן מדווח, בדיקת מי ברשת וצפייה בסטטיסטיקה.</dd>
		<dt>הגדרות</dt><dd>משימות ארעיות כגון הפעלת תוסף או הגדרת שם האתר.</dd>
		<dt>פיתוח</dt><dd>עבור מפתחים אשר בונים תוספים או מעצבים תבניות סגנון. (דורש תוסף מתאים.)</dd>
	</dl>
	",

	// argh, this is ugly
	'admin:widget:admin_welcome:outro' => "<br />אל תשכח לבקר במשאבים המקושרים בתחתית העמוד, תודה שבחרת בELGG!",

	'admin:footer:faq' => "שאלות נפוצות ניהול",
	'admin:footer:manual' => "מדריך למנהלים",
	'admin:footer:community_forums' => "קהילת ELGG",
	'admin:footer:blog' => "הבלוג של ELGG",

	'admin:plugins:category:all' => "כל התוספים",
	'admin:plugins:category:admin' => "ניהול",
	'admin:plugins:category:bundled' => "ארוזות",
	'admin:plugins:category:content' => "תוכן",
	'admin:plugins:category:development' => "פיתוח",
	'admin:plugins:category:extension' => "הרחבות",
	'admin:plugins:category:service' => "שרות/API",

	'admin:plugins:markdown:unknown_plugin' => "תוסף לא מוכר.",
	'admin:plugins:markdown:unknown_file' => "קובץ לא מוכר.",


	'admin:notices:could_not_delete' => "לא ניתן היה למחוק את ההתראה.",

	'admin:options' => "אפשרויות ניהול",


/**
 * Plugins
 */
	'plugins:settings:save:ok' => "הגדרות התוסף %s נשמרו בהצלחה.",
	'plugins:settings:save:fail' => "אירע שגיאה בשמירת הגדרות התוסף %s.",
	'plugins:usersettings:save:ok' => "הגדרות משתמש עבור התוסף %s נשמרו בהצלחה.",
	'plugins:usersettings:save:fail' => "הייתה בעיה בשמירת הגדרות משתמש עבור התוסף %s.",
	'item:object:plugin' => "תוספים",

	'admin:plugins' => "תוספים",
	'admin:plugins:activate_all' => "הפעלת הכל",
	'admin:plugins:deactivate_all' => "כיבוי הכל",
	'admin:plugins:description' => "בפנל זה ניתן להגדיר ולשלוט על התוספים המותקנים באתר שלך.",
	'admin:plugins:opt:linktext' => "הגדרת כלים...",
	'admin:plugins:opt:description' => "הגדרת הכלים המותקנים באתר ",
	'admin:plugins:label:author' => "מחבר",
	'admin:plugins:label:copyright' => "זכויות יוצרים",
	'admin:plugins:label:categories' => "קטגוריות",
	'admin:plugins:label:licence' => "רשיון",
	'admin:plugins:label:website' => "כתבות אינטרנט",
	'admin:plugins:label:moreinfo' => "מידע נוסף",
	'admin:plugins:label:version' => "גרסה",
	'admin:plugins:label:location' => "מיקום",
	'admin:plugins:label:dependencies' => "תלות",

	'admin:plugins:warning:elgg_version_unknown' => "תוסף זה משתמש בlegacy manifest file ואינו מציין גרסת ELGG מתאים. יש סבירות גבוהה שזה לא יעבוד!",
	'admin:plugins:warning:unmet_dependencies' => "לא ניתן להפעיל תוסף זה. בדוק תלות תחת מידע נוסף.",
	'admin:plugins:warning:invalid' => "%s אינו תוסף ELGG בר תוקף.  בדוק <a href=\"http://docs.elgg.org/Invalid_Plugin\">את הדוקומנטציה</a> לטיפים עבור תקלות.",
	'admin:plugins:cannot_activate' => "לא ניתן להפעיל",

	'admin:plugins:set_priority:yes' => "%s סודר מחדש.",
	'admin:plugins:set_priority:no' => "לא ניתן היה לסדר מחדש את %s.",
	'admin:plugins:deactivate:yes' => "%s נוטרל.",
	'admin:plugins:deactivate:no' => "לא הצלחנו לנטרל את %s.",
	'admin:plugins:activate:yes' => "%s הופעל.",
	'admin:plugins:activate:no' => "לא ניתן היה להפעיל את %s.",
	'admin:plugins:categories:all' => "כל הקטגוריות",
	'admin:plugins:plugin_website' => "אתר התוסף",
	'admin:plugins:author' => '%s',
	'admin:plugins:version' => "גרסה %s",
	'admin:plugins:simple' => "פשוט",
	'admin:plugins:advanced' => "מתקדם",
	'admin:plugin_settings' => "הגדרות התוסף",
	'admin:plugins:simple_simple_fail' => "לא הצלחנו לשמור את ההגדרות.",
	'admin:plugins:simple_simple_success' => "ההגדרות נשמרו",
	'admin:plugins:simple:cannot_activate' => "לא הצלחנו להפעיל את התוסף. בדוק באזור ניהול תוספים מתקדם למידע נוסף.",

	'admin:plugins:dependencies:type' => "סוג",
	'admin:plugins:dependencies:name' => "שם",
	'admin:plugins:dependencies:expected_value' => "הערך שנבדק",
	'admin:plugins:dependencies:local_value' => "הערך האמיתי",
	'admin:plugins:dependencies:comment' => "הערה",

	'admin:statistics:description' => "להלן סקירה של הסטטיסטיקה באתר שלך. אם הינך צריך סטטיסטיקה מפורטת יותר, קיים רכיב ניהול מקצועי.",
	'admin:statistics:opt:description' => "צפייה במידע סטטיסטית אודות משתמשים ופריטי תוכן באתר שלך.",
	'admin:statistics:opt:linktext' => "צפייה בסטטיסטיקה...",
	'admin:statistics:label:basic' => "סטטיסטיקה בסיסית",
	'admin:statistics:label:numentities' => "פריטים באתר",
	'admin:statistics:label:numusers' => "מספר משתמשים",
	'admin:statistics:label:numonline' => "מספר משתמשים ברשת עכשיו",
	'admin:statistics:label:onlineusers' => "משתמשים ברשת עכשיו",
	'admin:statistics:label:version' => "גרסת Elgg",
	'admin:statistics:label:version:release' => "שחרור",
	'admin:statistics:label:version:version' => "גרסה",

	'admin:user:label:search' => "חפש משתמשיםFind users:",
	'admin:user:label:searchbutton' => "חפש",

	'admin:user:ban:no' => "לא ניתן לחסום משתמש זה",
	'admin:user:ban:yes' => "המשתמש נחסם.",
	'admin:user:self:ban:no' => "לא ניתן לחסום את עצמך",
	'admin:user:unban:no' => "לא ניתן להסיר חסימה ממשתמש זה",
	'admin:user:unban:yes' => "הוסר החסימה ממשתמש זה",
	'admin:user:delete:no' => "לא ניתן למחוק משתמש זה",
	'admin:user:delete:yes' => "המשתמש %s נמחק",
	'admin:user:self:delete:no' => "לא ניתן למחוק את עצמך",

	'admin:user:resetpassword:yes' => "סיסמא אופסה ונשלחה הודעת מייל.",
	'admin:user:resetpassword:no' => "לא ניתן היה לאפס את הסיסמא.",

	'admin:user:makeadmin:yes' => "משתמש זה עכשיו מנהל",
	'admin:user:makeadmin:no' => "לא ניתן היה להפוך משתמש זה למנהל.",

	'admin:user:removeadmin:yes' => "משתמש זה כבר לא מנהל.",
	'admin:user:removeadmin:no' => "לא הצלחנו להסיר הרשאת ניהול ממשתמש זה.",
	'admin:user:self:removeadmin:no' => "לא ניתן להסיר הרשאות ניהול של עצמך.",

	'admin:appearance:menu_items' => "פריטי תפריט",
	'admin:menu_items:configure' => "הגדרת פריטי התפריט הראשיים",
	'admin:menu_items:description' => "בחר את הפרטים להציג בתפריט. פריטים אשר לא נבחרו יתווספו בלשונית 'עוד' בסוף הרשימה.",
	'admin:menu_items:hide_toolbar_entries' => "להסיר קישורים מתפריט כלים?",
	'admin:menu_items:saved' => "פריטי התפריט נשמרו.",
	'admin:add_menu_item' => "הוספת פריט תפריט מותאם אישי",
	'admin:add_menu_item:description' => "הזן מילת קישור וכתובת אינטרנט כדי להוסיף פריטים מותאמים אישית לתפריט הניווט.",

	'admin:appearance:default_widgets' => "ווידג'טים ברירת מחדל",
	'admin:default_widgets:unknown_type' => "סוג ווידג'ט לא מוכר",
	'admin:default_widgets:instructions' => "הוסף, הסר, מקם והגדר ווידג'טים ברירת מחדלעבור דף הווידג'טים הנבחר."
		. "  שינויים אלה ישפיעו רק על תכנים חדשים באתר.",

/**
 * User settings
 */
	'usersettings:description' => "פנל הגדרות משתמש נותן שליטה בכל ההגדרות האישיות, החל מניהול משתמשים ועד לביצועי התוספים. בחר מתוך האפשרויות למטה.",

	'usersettings:statistics' => "הסטטיסטיקה שלי",
	'usersettings:statistics:opt:description' => "צפייה במידע סטטיסטית אודות משתמשים ופריטי תוכן באתר שלך.",
	'usersettings:statistics:opt:linktext' => "סטטיסטיקת חשבון",

	'usersettings:user' => "ההגדרות שלי",
	'usersettings:user:opt:description' => "שליטה בהגדות משתמש.",
	'usersettings:user:opt:linktext' => "שנה את הגדרותיך",

	'usersettings:plugins' => "כלים",
	'usersettings:plugins:opt:description' => "קביעת הגדרות (אם יש) עבור הכלים הפעילים שלך.",
	'usersettings:plugins:opt:linktext' => "הגדרת כלים",

	'usersettings:plugins:description' => "פנל זה נותן שליטה על הגדרות אישיותעבור הכלים המותקנים במערכת.",
	'usersettings:statistics:label:numentities' => "התכנים שלך",

	'usersettings:statistics:yourdetails' => "הפרטים שלי",
	'usersettings:statistics:label:name' => "שם מלא",
	'usersettings:statistics:label:email' => "מייל",
	'usersettings:statistics:label:membersince' => "חבר מאז",
	'usersettings:statistics:label:lastlogin' => "נראה לאחרונה ברשת",

/**
 * Activity river
 */
	'river:all' => "כל הפעילות באתר",
	'river:mine' => "פעילות שלי",
	'river:friends' => "פעילות חבריי",
	'river:select' => "הצג %s",
	'river:comments:more' => "+%u עוד",
	'river:generic_comment' => "הגיב/ה ל%s %s",

	'friends:widget:description' => "מציג את חבריך.",
	'friends:num_display' => "כמה חברים להציג?",
	'friends:icon_size' => "גודל האייקון",
	'friends:tiny' => "מזערי",
	'friends:small' => "קטן",

/**
 * Generic action words
 */

	'save' => "שמור",
	'reset' => "אפס",
	'publish' => "פרסם",
	'cancel' => "בטל",
	'saving' => "שומר ...",
	'update' => "עדכן",
	'edit' => "ערוך",
	'delete' => "מחק",
	'accept' => "קבל",
	'load' => "טען",
	'upload' => "העלאה",
	'ban' => "חסום",
	'unban' => "הסר חסימה",
	'banned' => "נחסם",
	'enable' => "הפעל",
	'disable' => "אל תפעיל",
	'request' => "בקש",
	'complete' => "הושלם",
	'open' => "פתח",
	'close' => "סגור",
	'reply' => "הגב",
	'more' => "עוד",
	'comments' => "תגובות",
	'import' => "ייבא",
	'export' => "ייצא",
	'untitled' => "ללא כותרת",
	'help' => "עזרה",
	'send' => "שלח",
	'post' => "פרסם",
	'submit' => "שלח",
	'comment' => "תגובה",
	'upgrade' => "שדרג",

	'site' => "אתר",
	'activity' => "פעילות",
	'members' => "חברים",

	'up' => "כלפי מעלה",
	'down' => "כלפי מטה",
	'top' => "למעלה",
	'bottom' => "למטה",

	'invite' => "הזמן",

	'resetpassword' => "אפס סיסמא",
	'makeadmin' => "הפוך למנהל",
	'removeadmin' => "הסר הרשאות ניהול",

	'option:yes' => "כן",
	'option:no' => "לא",

	'unknown' => "לא מזוהה",

	'active' => "פעיל",
	'total' => "סך הכל",

	'learnmore' => "לחץ כאן למידע נוסף.",

	'content' => "תוכן",
	'content:latest' => "פעילות",
	'content:latest:blurb' => "או לחץ כאן כדי לצפות בתכנים החדשים ביותר באתר.",

	'link:text' => "גש לקישור",
/**
 * Generic questions
 */

	'question:areyousure' => "בטוח?",

/**
 * Generic data words
 */

	'title' => "כותרת",
	'description' => "תיאור",
	'tags' => "תגים",
	'spotlight' => "זרקור",
	'all' => "הכל",
	'mine' => "שלי",

	'by' => "מאת",

	'annotations' => "ביאורים",
	'relationships' => "יחסים",
	'metadata' => "מטה-דאטה",
	'tagcloud' => "ענן תגים",
	'tagcloud:allsitetags' => "כל התגים באתר",

/**
 * Entity actions
 */
	'edit:this' => "עריכה",
	'delete:this' => "מחיקה",
	'comment:this' => "תגובה",

/**
 * Input / output strings
 */

	'deleteconfirm' => "למחוק פריט זה?",
	'fileexists' => "כבר הועלה קובץ.  כדי להחליפו יש לסמנו למטה:",

/**
 * User add
 */

	'useradd:subject' => "חשבון המשתמש נוצר",
	'useradd:body' => "
%s,

נוצר חשבון משתמש עבורך ב%s. כדי להכנס למערכת גש ל:

%s

להלן פרטיך:

Username: %s
Password: %s

לאחר הכניסה למערכת אנו ממליצים לשנות את הסיסמא.
",

/**
 * System messages
 **/

	'systemmessages:dismiss' => "לחץ/י כאן כדי לסגור הודעת מערכת זו",


/**
 * Import / export
 */
	'importsuccess' => "ייבוא הנתונים בוצע בהצלחה",
	'importfail' => "OpenDD ייבוא הנתונים נכשל.",

/**
 * Time
 */

	'friendlytime:justnow' => "כרגע",
	'friendlytime:minutes' => "לפני %sדקות",
	'friendlytime:minutes:singular' => "לפני דקה",
	'friendlytime:hours' => "לפני %s שעות",
	'friendlytime:hours:singular' => "לפני שעה",
	'friendlytime:days' => "לפני %s ימים",
	'friendlytime:days:singular' => "אתמול",
	'friendlytime:date_format' => "j F Y @ g:ia",

	'date:month:01' => "ינואר %s",
	'date:month:02' => "פברואר %s",
	'date:month:03' => "מרץ %s",
	'date:month:04' => "אפריל %s",
	'date:month:05' => "מאי %s",
	'date:month:06' => "יוני %s",
	'date:month:07' => "יולי %s",
	'date:month:08' => "אוגוסט %s",
	'date:month:09' => "ספטמבר %s",
	'date:month:10' => "אוקטובר %s",
	'date:month:11' => "נובמבר %s",
	'date:month:12' => "דצמבר %s",


/**
 * System settings
 */

	'installation:sitename' => "שם האתר:",
	'installation:sitedescription' => "תיאור קצר (לא חובה):",
	'installation:wwwroot' => "כתובת האתר:",
	'installation:path' => "הנתיב המלא להתקנת הELGG:",
	'installation:dataroot' => "הנתיב המלא לספריית הדאטה",
	'installation:dataroot:warning' => "יש ליצור את ספריית הדאטה באופן ידני, בספרייה שונה מספריית הELGG.",
	'installation:sitepermissions' => "הרשאות גישה ברירת מחדל:",
	'installation:language' => "שפה ברירת המחדל:",
	'installation:debug' => "Debug mode מספק מידע נוסף לצורף אבחון שגיאות. זה יכול להאט את המערכת לכן השתמש בו רק אם יש בעיות:",
	'installation:debug:none' => "סגור debug mode (מומלץ)",
	'installation:debug:error' => "הצג רק שגיאות קריטיים",
	'installation:debug:warning' => "הצג שגיאות והזהרות",
	'installation:debug:notice' => "רשום כל השגיאות, הזהרות והתראות",

	// Walled Garden support
	'installation:registration:description' => "כברירת מחדל משתמשים חדשים יכולים להרשם לאתר. כבא זאת אם אין ברצונך לאפשר למשתמשים חדשים להרשם לבד.",
	'installation:registration:label' => "התר למשתמשים חדשים להרשם לאתר",
	'installation:walled_garden:description' => "הפעל את האתר כרשת פרטית. גולשים אקראיים לא יוכלו לצפות בדפים אלה אם דפים אלה צוינו כציבוריים.",
	'installation:walled_garden:label' => "הגבלת דפים למשתמשים המזוהים במערכת",

	'installation:httpslogin' => "הפעל כדי שמשתמשים יכנסו למערכת דרך HTTPS. יש להפעיל https בשרת שלך כדי שזה יעבוד.",
	'installation:httpslogin:label' => "התר כניסה דרך HTTPS",
	'installation:view' => "איזה view יהיה בשימוש כברירת מחדל באתראם אינך יודע השאר ריק:",

	'installation:siteemail' => "כתובת דואר אלקטרוני של האתר (לשליחת דואר מערכת):",

	'installation:disableapi' => "Elgg מספק API לבניית שרותי וובכדי לאפשר לאפליקציות מרוחקות אינטראקציה עם האתר",
	'installation:disableapi:label' => "הפעלת web services API של ELGG",

	'installation:allow_user_default_access:description' => "סמן כאן כדי לאפשר למשתמשים לבחור את הרשאות הגישה לתכנים שלהם ללא קשר להרשאות ברירת המחדל של האתר.",
	'installation:allow_user_default_access:label' => "התר בחירת הרשאות גישה",

	'installation:simplecache:description' => "simple cache משפר ביצוע על ידי שמירת תוכן סטטי כולל חלק מה CSS וJavaScript. לרוב תרצה להפעיל.",
	'installation:simplecache:label' => "הפעלת simple cache (מומלץ)",

	'installation:viewpathcache:description' => "view filepath cache מפחית את זמן טעינת התוספים על ידי שמירת מיקום הviews שלהם.",
	'installation:viewpathcache:label' => "הפעלת view filepath cache (מומלץ)",

	'upgrading' => "משדרג...",
	'upgrade:db' => "בסיס הנתונים שודרג.",
	'upgrade:core' => "ההתקנה שלך שודרגה.",
	'upgrade:unable_to_upgrade' => "לא ניתן היה לבצע שדרוג.",
	'upgrade:unable_to_upgrade_info' =>
		"This installation cannot be upgraded because legacy views
		were detected in the Elgg core views directory. These views have been deprecated and need to be
		removed for Elgg to function correctly. If you have not made changes to Elgg core, you can
		simply delete the views directory and replace it with the one from the latest
		package of Elgg downloaded from <a href=\"http://elgg.org\">elgg.org</a>.<br /><br />

		If you need detailed instructions, please visit the <a href=\"http://docs.elgg.org/wiki/Upgrading_Elgg\">
		Upgrading Elgg documentation</a>.  If you require assistance, please post to the
		<a href=\"http://community.elgg.org/pg/groups/discussion/\">Community Support Forums</a>.",

	'update:twitter_api:deactivated' => "Twitter API (Twitter Service) נוטרל בזמן השדרוג. ניתן להפעיל מחדש.",
	'update:oauth_api:deactivated' => "OAuth API (OAuth Lib) נוטרל בזמן השדרוג. ניתן להפעיל מחדש.",

	'deprecated:function' => '%s() was deprecated by %s()',

/**
 * Welcome
 */

	'welcome' => "ברוך בואך",
	'welcome:user' => "ברוך בואך %s",

/**
 * Emails
 */
	'email:settings' => "הגדרות מייל",
	'email:address:label' => "כתובת המייל שלך",

	'email:save:success' => "הכתובת החדשה נשמרה, נשלחה בקשת אישור.",
	'email:save:fail' => "לא ניתן היה לשמור את כתובת המייל החדשה.",

	'friend:newfriend:subject' => "%s הוסיף/ה אותך כחבר/ה!",
	'friend:newfriend:body' => "%s הוסיף/ה אותך כחבר/ה!

כדי לצפות בפרופיל שלהם, לחץ/י כאן:

%s

תגובות באמצעות הדואר האלקטרוני אינן אפשריות.",



	'email:resetpassword:subject' => "איפוס סיסמא!",
	'email:resetpassword:body' => "שלום %s,

הסיסמא שלך אופסה ל: %s",


	'email:resetreq:subject' => "בקשת סיסמא חדשה.",
	'email:resetreq:body' => "שלום %s,

מישהו (מכתובת הIP  %s) ביקש סיסמא חדשה לחשבון שלהם.

אם אכן ביקשת זאת אנא לחץ/י על הקישור למטה, אם לא, אנא התעלם מהודעה זו.

%s
",

/**
 * user default access
 */

'default_access:settings' => "הרשאות גישה ברירת מחדל",
'default_access:label' => "הרשאות גישה ברירת מחדל",
'user:default_access:success' => "הרשאות הגישה החדשות נשמרו.",
'user:default_access:failure' => "הרשאות הגישה החדשות לא נשמרו.",

/**
 * XML-RPC
 */
	'xmlrpc:noinputdata'	=>	"נתוני קלט חסרים",

/**
 * Comments
 */

	'comments:count' => "%s תגובות",

	'riveraction:annotation:generic_comment' => "%s הגיב/ה ל%s",

	'generic_comments:add' => "כתיבת תגובה",
	'generic_comments:post' => "פרסום תגובה",
	'generic_comments:text' => "תגובה",
	'generic_comments:latest' => "תגובות חדשות",
	'generic_comment:posted' => "התגובה פורסמה בהצלחה.",
	'generic_comment:deleted' => "התגובה נמחקה בהצלחה.",
	'generic_comment:blank' => "יש לכתוב תוכן כלשהו בתגובה טרם אפשר לשמור.",
	'generic_comment:notfound' => "לא מצאנו את הפריט שחיפשת.",
	'generic_comment:notdeleted' => "לא הצלחנו למחוק את התגובה.",
	'generic_comment:failure' => "אירע שגיאה בלתי צפויה בהוספת התגובה שלך.  אנא נסה/י שוב.",
	'generic_comment:none' => "ללא תגובות",

	'generic_comment:email:subject' => "יש לך תגובה חדשה!",
	'generic_comment:email:body' => "יש תגובה חדשה ל\"%s\" מ%s. להלן תוכן התגובה:


%s


לחץ/י כאן כדי להגיב או לצפות בהודעה המקורית:

%s

כדי לצפות בפרופיל של %s, לחץ/י כאן:

%s

תגובות באמצעות הדואר האלקטרוני אינן אפשריות.",

/**
 * Entities
 */
	'byline' => "על ידי %s",
	'entity:default:strapline' => "נוצר %s על ידי %s",
	'entity:default:missingsupport:popup' => "לא ניתן להציג פריט זה. יתכן שנדרש רכיב אשר אינו קיים במערכת.",

	'entity:delete:success' => "הפריט %s נמחק",
	'entity:delete:fail' => "לא ניתן היה למחוק את הפריט %s",


/**
 * Action gatekeeper
 */
	'actiongatekeeper:missingfields' => 'Form is missing __token or __ts fields',
	'actiongatekeeper:tokeninvalid' => "אירע שגיאה (token mismatch). יתכן כי פג תוקף הדף. אנא נסה/י שוב.",
	'actiongatekeeper:timeerror' => "פג תוקפו של הדף בו השתמשת. אנא רענן ונסה/י שוב.",
	'actiongatekeeper:pluginprevents' => "אחד הרכיבים מנע את שליחת הטופס.",


/**
 * Word blacklists
 */
	'word:blacklist' => 'and, the, then, but, she, his, her, him, one, not, also, about, now, hence, however, still, likewise, otherwise, therefore, conversely, rather, consequently, furthermore, nevertheless, instead, meanwhile, accordingly, this, seems, what, whom, whose, whoever, whomever',

/**
 * Tag labels
 */

	'tag_names:tags' => "תגים",
	'tags:site_cloud' => "ענן התגים של האתר",

/**
 * Javascript
 */

	'js:security:token_refresh_failed' => "לא ניתן להתחבר ל%s. יתכן כי תחווה בעיות בשמירת תכנים.",
	'js:security:token_refreshed' => "החיבור ל%s שוחזר!",

/**
 * Languages according to ISO 639-1
 */
	"aa" => "Afar",
	"ab" => "Abkhazian",
	"af" => "Afrikaans",
	"am" => "Amharic",
	"ar" => "Arabic",
	"as" => "Assamese",
	"ay" => "Aymara",
	"az" => "Azerbaijani",
	"ba" => "Bashkir",
	"be" => "Byelorussian",
	"bg" => "Bulgarian",
	"bh" => "Bihari",
	"bi" => "Bislama",
	"bn" => "Bengali; Bangla",
	"bo" => "Tibetan",
	"br" => "Breton",
	"ca" => "Catalan",
	"co" => "Corsican",
	"cs" => "Czech",
	"cy" => "Welsh",
	"da" => "Danish",
	"de" => "German",
	"dz" => "Bhutani",
	"el" => "Greek",
	"en" => "English",
	"eo" => "Esperanto",
	"es" => "Spanish",
	"et" => "Estonian",
	"eu" => "Basque",
	"fa" => "Persian",
	"fi" => "Finnish",
	"fj" => "Fiji",
	"fo" => "Faeroese",
	"fr" => "French",
	"fy" => "Frisian",
	"ga" => "Irish",
	"gd" => "Scots / Gaelic",
	"gl" => "Galician",
	"gn" => "Guarani",
	"gu" => "Gujarati",
	"he" => "עברית",
	"ha" => "Hausa",
	"hi" => "Hindi",
	"hr" => "Croatian",
	"hu" => "Hungarian",
	"hy" => "Armenian",
	"ia" => "Interlingua",
	"id" => "Indonesian",
	"ie" => "Interlingue",
	"ik" => "Inupiak",
	//"in" => "Indonesian",
	"is" => "Icelandic",
	"it" => "Italian",
	"iu" => "Inuktitut",
	"iw" => "Hebrew (obsolete)",
	"ja" => "Japanese",
	"ji" => "Yiddish (obsolete)",
	"jw" => "Javanese",
	"ka" => "Georgian",
	"kk" => "Kazakh",
	"kl" => "Greenlandic",
	"km" => "Cambodian",
	"kn" => "Kannada",
	"ko" => "Korean",
	"ks" => "Kashmiri",
	"ku" => "Kurdish",
	"ky" => "Kirghiz",
	"la" => "Latin",
	"ln" => "Lingala",
	"lo" => "Laothian",
	"lt" => "Lithuanian",
	"lv" => "Latvian/Lettish",
	"mg" => "Malagasy",
	"mi" => "Maori",
	"mk" => "Macedonian",
	"ml" => "Malayalam",
	"mn" => "Mongolian",
	"mo" => "Moldavian",
	"mr" => "Marathi",
	"ms" => "Malay",
	"mt" => "Maltese",
	"my" => "Burmese",
	"na" => "Nauru",
	"ne" => "Nepali",
	"nl" => "Dutch",
	"no" => "Norwegian",
	"oc" => "Occitan",
	"om" => "(Afan) Oromo",
	"or" => "Oriya",
	"pa" => "Punjabi",
	"pl" => "Polish",
	"ps" => "Pashto / Pushto",
	"pt" => "Portuguese",
	"qu" => "Quechua",
	"rm" => "Rhaeto-Romance",
	"rn" => "Kirundi",
	"ro" => "Romanian",
	"ru" => "Russian",
	"rw" => "Kinyarwanda",
	"sa" => "Sanskrit",
	"sd" => "Sindhi",
	"sg" => "Sangro",
	"sh" => "Serbo-Croatian",
	"si" => "Singhalese",
	"sk" => "Slovak",
	"sl" => "Slovenian",
	"sm" => "Samoan",
	"sn" => "Shona",
	"so" => "Somali",
	"sq" => "Albanian",
	"sr" => "Serbian",
	"ss" => "Siswati",
	"st" => "Sesotho",
	"su" => "Sundanese",
	"sv" => "Swedish",
	"sw" => "Swahili",
	"ta" => "Tamil",
	"te" => "Tegulu",
	"tg" => "Tajik",
	"th" => "Thai",
	"ti" => "Tigrinya",
	"tk" => "Turkmen",
	"tl" => "Tagalog",
	"tn" => "Setswana",
	"to" => "Tonga",
	"tr" => "Turkish",
	"ts" => "Tsonga",
	"tt" => "Tatar",
	"tw" => "Twi",
	"ug" => "Uigur",
	"uk" => "Ukrainian",
	"ur" => "Urdu",
	"uz" => "Uzbek",
	"vi" => "Vietnamese",
	"vo" => "Volapuk",
	"wo" => "Wolof",
	"xh" => "Xhosa",
	//"y" => "Yiddish",
	"yi" => "Yiddish",
	"yo" => "Yoruba",
	"za" => "Zuang",
	"zh" => "Chinese",
	"zu" => "Zulu",
);

add_translation("he",$hebrew);
