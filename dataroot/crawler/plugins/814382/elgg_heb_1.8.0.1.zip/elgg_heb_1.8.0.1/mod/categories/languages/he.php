<?php
/**
 * Categories Hebrew language file
 */

$hebrew = array(
	'categories' => "קטגוריות",
	'categories:settings' => "קבע קטגוריות",
	'categories:explanation' => "לקביעת קטגוריות עבור אתר זהת הזן אותן למטה, והפרד ביניהם באמצעות פסיק. הקטגוריות ייוצגו בכלים מתאימים כאשר המשתמשים יוצרים או עורכים תכנים.",
	'categories:save:success' => "הקטגוריות נשמרו בהצלחה.",
	'categories:results' => "תוצאות עבור הקטגוריה: %s",
	'categories:on_enable_reminder' => "טרם הוספת קטגוריות!  <a href=\"%s\">הוסף קטגוריות עכשיו.</a>",
);

add_translation("he", $hebrew);