<?php
/**
 * External pages Hebrew language file
 */

$hebrew = array(

	/**
	 * Menu items and titles
	 */
	'expages' => "דפי האתר",
	'admin:appearance:expages' => "דפי האתר",
	'expages:about' => "אודות",
	'expages:terms' => "תנאים",
	'expages:privacy' => "פרטיות",
	'expages:contact' => "יצירת קשר",

	'expages:notset' => "דף זה בבנייה.",

	/**
	 * Status messages
	 */
	'expages:posted' => "הדף עודכן בהצלחה.",
	'expages:error' => "לא ניתן היה לשמור דף זה.",
);

add_translation("he", $hebrew);
