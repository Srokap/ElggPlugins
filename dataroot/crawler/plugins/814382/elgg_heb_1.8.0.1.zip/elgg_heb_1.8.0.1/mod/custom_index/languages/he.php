<?php
/**
 * Custom Index Hebrew language file
 */

$hebrew = array(	
	'custom:bookmarks' => "קישורים חדשים",
	'custom:groups' => "קבוצות חדשות",
	'custom:files' => "קבצים חדשים",
	'custom:blogs' => "פוסטים חדשים",
	'custom:members' => "חברים חדשים",
);
					
add_translation("he", $hebrew);
