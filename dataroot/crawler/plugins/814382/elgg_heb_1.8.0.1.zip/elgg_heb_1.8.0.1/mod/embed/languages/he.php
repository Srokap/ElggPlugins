<?php
/**
 * Embed Hebrew language strings - Susan Tsairi
 *
 */

$hebrew = array(
	'media:insert' => "העלאת ושיבוץ קבצים",
	'embed:embed' => "שבץ",
	'embed:media' => "העלאת קובץ",
	'embed:instructions' => "לחץ/י על קבוץ כדי לשבצו בתוכן.",
	'embed:upload' => "העלאת מדיה",
	'embed:upload_type' => "סוג : ",

	// messages
	'embed:no_upload_content' => "לא נמצא תוכן להעלות!",
	'embed:no_section_content' => "לא נמצאו פריטים כלשהם.",

	'embed:no_sections' => "לא נמצא רכיב העלה ושיבוץ מתאים. בקש ממנהלי האתר להפעיל רכיב התומך בהעלאת ושיבוץ קבצים.",
);

add_translation("he", $hebrew);