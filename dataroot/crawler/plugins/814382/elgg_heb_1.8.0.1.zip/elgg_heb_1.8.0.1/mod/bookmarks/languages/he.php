<?php
/**
 * Bookmarks Hebrew language file
 */

$hebrew = array(

	/**
	 * Menu items and titles
	 */
	'bookmarks' => "קישורים",
	'bookmarks:add' => "הוספת קישור",
	'bookmarks:edit' => "עריכת קישור",
	'bookmarks:owner' => "קישורים של חברי %s",
	'bookmarks:friends' => "קישורי חברים",
	'bookmarks:everyone' => "כל הקישורים",
	'bookmarks:this' => "הוסף לקישורים שלי",
	'bookmarks:this:group' => "קישור ב%s",
	'bookmarks:bookmarklet' => "הוספת כפתור קישורים לדפדפן",
	'bookmarks:bookmarklet:group' => "כפתור קישורים של הקבוצה",
	'bookmarks:inbox' => "קישורים ששלחו לי חבריי",
	'bookmarks:morebookmarks' => "צפייה בעוד",
	'bookmarks:more' => "עוד",
	'bookmarks:with' => "שלח ל",
	'bookmarks:new' => "קישור חדש",
	'bookmarks:via' => "מתוך קישורים",
	'bookmarks:address' => "כתובת אינטרנט של המשאב",
	'bookmarks:none' => "טרם נוספו קישורים כלשהם",

	'bookmarks:delete:confirm' => "למחוק קישור זה?",

	'bookmarks:numbertodisplay' => "כמה קישורים להציג",

	'bookmarks:shared' => "הוסיף/ה קישור",
	'bookmarks:visit' => "גש לקישור",
	'bookmarks:recent' => "קישורים אחרונים",

	'bookmarks:river:created' => "הוסיף/ה קישור %s",
	'bookmarks:river:annotate' => "תגובה לקישור",
	'bookmarks:river:item' => "פריט",
	'river:commented:object:bookmarks' => "קישור",
	'river:create:object:bookmarks' => '%s הוסיף/ה קישור %s',
	'river:comment:object:bookmarks' => '%s הגיב/ה לקישור %s',
	
	'item:object:bookmarks' => "קישורים",

	'bookmarks:group' => "קישורי הקבוצה",
	'bookmarks:enablebookmarks' => "התר קישורים קבוצתיים",
	'bookmarks:nogroup' => "טרם נוספו קישורים כלשהם בקבוצהזו",
	'bookmarks:more' => "צפייה בעוד",

	'bookmarks:no_title' => "ללא כותרת",

	/**
	 * Widget and bookmarklet
	 */
	'bookmarks:widget:description' => "הצגת הקישרוים האחרונים שלך.",

	'bookmarks:bookmarklet:description' =>
			"כפתור הדפדפן מאפשר לשמור קישורים לרשת בזמן הגלישה באינטרנט.  בפיירפוקס יש לגרור את הכפתור לסרגל הקישורים:",

	'bookmarks:bookmarklet:descriptionie' =>
			"באינטרנט אקספלורר יש ללחוץ קליק ימין על הכפתור, לבחור באפשרות הוסף למועדפים, ואחר כך תפרית קישורים.",

	'bookmarks:bookmarklet:description:conclusion' =>
			"לאחר מכן ניתן לשמור כל דף אינטנרט על ידי לחיצה על הכפתור בדפדפן. ",

	/**
	 * Status messages
	 */

	'bookmarks:save:success' => "הקישור נוסף בהצלחה.",
	'bookmarks:delete:success' => "הקישור נמחק בהצלחה.",

	/**
	 * Error messages
	 */

	'bookmarks:save:failed' => "לא ניתן היה לשמור את הקישור. אנא הוסף/הוסיפי כותרת וכתובת כדי לנסות שוב.",
	'bookmarks:delete:failed' => "לא ניתן היה למחוק את הקישור.  אנא נסה/נסי שוב.",
);

add_translation('he', $hebrew);