<?php
/**
 * Elgg file Hebrew plugin language pack
 *
 * @package ElggFile
 */

$hebrew = array(

	/**
	 * Menu items and titles
	 */
	'file' => "קבצים",
	'files' => "קבצים שלי",
	'file:yours' => "קבצים שלי",
	'file:yours:friends' => "קבצי חבריך",
	'file:user' => "קבצי %s",
	'file:friends' => "קבצי חברי %s",
	'file:all' => "כל הקבצים באתר",
	'file:edit' => "עריכת קובץ",
	'file:more' => "צפייה בעוד",
	'file:list' => "תצוגת רשימה",
	'file:group' => "קבצי הקבוצה",
	'file:gallery' => "תצוגת גלריה",
	'file:gallery_list' => "תצוגת גלריה או רשימה",
	'file:num_files' => "כמה קבצים להציג",
	'file:user:gallery'=>"צפייה בגלריה של %s",
	'file:via' => "מתוך קישורים",
	'file:upload' => "טען קובץ",
	'file:replace' => "החלפת קובץ (השאר ריק כדי לא להחליף את הקובץ)",
	'file:list:title' => "%s's %s %s",
	'file:title:friends' => "קבצי חברים",

	'file:add' => "העלאת קובץ",

	'file:file' => "קובץ",
	'file:title' => "כותרת",
	'file:desc' => "תיאור",
	'file:tags' => "תגים",

	'file:types' => "סוגי קבצים שהועלו",

	'file:type:' => "קבצים",
	'file:type:all' => "כל הקבצים",
	'file:type:video' => "וידאו",
	'file:type:document' => "מסמכים",
	'file:type:audio' => "אודיו",
	'file:type:image' => "תמונות",
	'file:type:general' => "כללי-מצגות",

	'file:user:type:video' => "וידאו של %s",
	'file:user:type:document' => "מסמכים של %s",
	'file:user:type:audio' => "אודיו של %s",
	'file:user:type:image' => "תמונות של %s",
	'file:user:type:general' => "מצגות של %s",

	'file:friends:type:video' => "וידאו של חבריך",
	'file:friends:type:document' => "מסמכים של חבריך",
	'file:friends:type:audio' => "אודיו של חבריך",
	'file:friends:type:image' => "תמונות של חבריך",
	'file:friends:type:general' => "מצגות של חבריך",

	'file:widget' => "ווידג'ט קבצים",
	'file:widget:description' => "הצגת הקבצים האחרונים שלך",

	'groups:enablefiles' => "התר קבצים קבוצתיים",

	'file:download' => "שמירה במחשב",

	'file:delete:confirm' => "למחוק קובץ זה?",

	'file:tagcloud' => "ענן תגים",

	'file:display:number' => "כמה קבצים להציג?",
'river:create:object:file' => '%s הוסיף/ה קובץ %s',
	'river:comment:object:file' => '%s הגיב/ה לקובץ %s',
	'file:river:create' => "הוסיף/ה את הקובץ",
	'river:commented:object:file' => "הקובץ",

	'item:object:file' => "קבצים",

	/**
	 * Embed media
	 **/

		'file:embed' => "שיבוץ מדי",
		'file:embedall' => "הכל",

	/**
	 * Status messages
	 */

		'file:saved' => "הקובץ נשמר בהצלחה.",
		'file:deleted' => "הקובץ נמחק בהצלחה.",

	/**
	 * Error messages
	 */

		'file:none' => "לא הועלו קבצים כלשהם.",
		'file:uploadfailed' => "מצטערים, לא הצלחנו לשמור את הקובץ.",
		'file:downloadfailed' => "מצטערים, הקובץ אינו זמין כרגע.",
		'file:deletefailed' => "לא הצלחנו למחוק את הקובץ.",
		'file:noaccess' => "אינך בעל/ת הרשאות לשנות קובץ זה",
		'file:cannotload' => "אירע שגיאה בטעינת הקובץ",
		'file:nofile' => "יש לבחור קובץ",
);

add_translation("he", $hebrew);