<?php
/**
 * Diagnostics download form
 */
echo elgg_view('input/submit', array('value' => elgg_echo('diagnostics:download')));