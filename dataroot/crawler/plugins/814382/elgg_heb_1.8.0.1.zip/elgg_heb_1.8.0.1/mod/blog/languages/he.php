<?php
/**
 * Blog Hebrew language file.
 *
 */

$hebrew = array(
	'blog' => "בלוג",
	'blog:blogs' => "בלוג",
	'blog:revisions' => "גרסאות",
	'blog:archives' => "ארכיון",
	'blog:blog' => "בלוג",
	'item:object:blog' => "בלוג",

	'blog:title:user_blogs' => "הבלוג של %s",
	'blog:title:all_blogs' => "כל הבלוגים באתר",
	'blog:title:friends' => "בלוגים של חברים",

	'blog:group' => "בלוג הקבוצה",
	'blog:enableblog' => "התר בלוג קבוצתי",
	'blog:write' => "כתוב/כתבי פוסט",

	// Editing
	'blog:add' => "הוספת פוסט",
	'blog:edit' => "עריכת פוסט",
	'blog:excerpt' => "תקציר",
	'blog:body' => "תוכן",
	'blog:save_status' => "נשמר בפעם האחרונה: ",
	'blog:never' => "אף פעם",

	// Statuses
	'blog:status' => "מצב",
	'blog:status:draft' => "טיוטה",
	'blog:status:published' => "פורסם",
	'blog:status:unsaved_draft' => "טיוטה אשר טרם נשמרה",

	'blog:revision' => "גרסא",
	'blog:auto_saved_revision' => "גרסא משמירה אוטומטית",

	// messages
	'blog:message:saved' => "הפוסט נשמר.",
	'blog:error:cannot_save' => "לא ניתן לשמור את הפוסט.",
	'blog:error:cannot_write_to_container' => "אינך בעל/ת הרשאות לשמירת פוסט בבלוג הקבוצת.",
	'blog:error:post_not_found' => "יתכן כי פוסט זה הוסר, לא תקין או שאינך בעל/ת הרשאות צפייה.",
	'blog:messages:warning:draft' => "קיים טיוטה אשר טרם נשמר!",
	'blog:edit_revision_notice' => "(גרסא ישנה)",
	'blog:message:deleted_post' => "הפוסט נמחק.",
	'blog:error:cannot_delete_post' => "לא ניתן למחוק את הפוסט.",
	'blog:none' => "אין פוסטים בבלוג זה",
	'blog:error:missing:title' => "יש להוסיף כותרת!",
	'blog:error:missing:description' => "יש להוסיף תוכן!",
	'blog:error:cannot_edit_post' => "יתכן כי פוסט זה אינו קיים או שאינך בעל/ת הרשאות צפייה.",
	'blog:error:revision_not_found' => "לא מצאנו גרסא זו.",

	// river
	'blog:river:create' => "פרסם/ה פוסט בבלוג",
	'river:commented:object:blog' => "הבלוג",
     'river:create:object:blog' => "%s פרסם/ה פוסט בבלוג %s",
	'river:comment:object:blog' => "%s הגיב/ה לבלוג %s",
	
	// notifications
	'blog:newpost' => "פוסט חדש בבלוג",
	
	// widget
	'blog:widget:description' => "הצגת הפוסטים האחרונים מהבלוג שלך",
	'blog:moreblogs' => "צפייה בעוד",
	'blog:numbertodisplay' => "מספר הפוסטים לתצוגה",
	'blog:noblogs' => "אין פוסטים בבלוג זה"
);

add_translation('he', $hebrew);
