<?php
/**
 * Blog CSS
 *
 * @package Blog
*/
?>

/* Blog Plugin */

/* force tinymce input height for a more useful editing / blog creation area */
form#blog-post-edit #description_parent #description_ifr {
	height:400px !important;
}
