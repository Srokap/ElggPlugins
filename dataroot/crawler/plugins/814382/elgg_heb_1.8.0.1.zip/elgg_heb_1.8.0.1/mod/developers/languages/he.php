<?php
/**
 * Elgg developer tools Hebrew language file.
 *
 */

$hebrew = array(
	// menu
	'admin:developers' => "מפתחים",
	'admin:developers:settings' => "הגדרות פיתוח",
	'admin:developers:preview' => "צפייה מקדימה בסגנונות",

	// settings
	'developers:label:simple_cache' => "השתמש בsimple cache",
	'developers:help:simple_cache' => "סגור file cache בזמן פיתוח. אחרת, שינויים לviews (כולל css) לא יקלטו.",
	'developers:label:view_path_cache' => "הפעלת view path cache",
	'developers:help:view_path_cache' => "סגור את זה בזמן פיתוח. אחרת, views חדשים בפלאגינים לא יירשמו.",
	'developers:label:debug_level' => "Trace level",
	'developers:help:debug_level' => "זה שולט בכמות המידה אשר במעקב. ראה elgg_log() עבור מידע נוסף.",
	'developers:label:display_errors' => "הצג fatal PHP errors",
	'developers:help:display_errors' => "כברירת מחדל, קובץ ה.htaccess של ELGG עוצר הצגת  fatal errors.",

	'developers:debug:off' => "סגור",
	'developers:debug:error' => "שגיאה",
	'developers:debug:warning' => "הזהרה",
	'developers:debug:notice' => "התראה",

	// theme preview
	'theme_preview:buttons' => "כפתורים",
	'theme_preview:components' => "רכיבים",
	'theme_preview:forms' => "טפסים",
	'theme_preview:grid' => "גריד",
	'theme_preview:icons' => "אייקונים",
	'theme_preview:modules' => "מודולות",
	'theme_preview:navigation' => "ניווט",
	'theme_preview:typography' => "טיפוגרפיה",
);

add_translation('he', $hebrew);
