<ul>
	<li class="elgg-message elgg-state-success mas">Success message (.elgg-state-success)</li>
	<li class="elgg-message elgg-state-error mas">Error message (.elgg-state-error)</li>
	<li class="elgg-message elgg-state-notice mas">Notice message (.elgg-state-notice)</li>
</ul>
