<?php
/*

User xboxgamertag widget edit view

*/

// set default card style
if (!isset($vars['entity']->style)) {
	$vars['entity']->style = squares;
}

$params = array(
	'name' => 'params[style]',
	'value' => $vars['entity']->style,
	'options' => array(deluxe, slick, squares, original, robo), // lime, mondo, xfl, xfl2
);
$dropdown = elgg_view('input/dropdown', $params);

?>


<p>
	<?php echo elgg_echo("xboxgamertag:gamertag"); ?>
    <input type="text" name="params[gamertag]" value="<?php echo htmlentities($vars['entity']->gamertag); ?>" />
</p>
<p>
    <?php echo elgg_echo('xboxgamertag:style'); ?>:
    <?php echo $dropdown; ?>
</p>