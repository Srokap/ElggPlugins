<?php

        $spanish = array(
               
        'xboxgamertag:title' => "Gamertag",
		'xboxgamertag:description' => "Muestra el perfil de Xbox y Windows Live en un widget",
        'xboxgamertag:gamertag' => "Inserta tu gamertag",
        'xboxgamertag:style' => "Selecciona un estilo",
        'xboxgamertag:no_gamertag' => "Inserta tu gamertag en las opciones y recarga el navegador",

        );
          
        add_translation("es",$spanish);

?>
