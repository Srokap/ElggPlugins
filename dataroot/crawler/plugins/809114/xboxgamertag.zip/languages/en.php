<?php

        $english = array(
               
        'xboxgamertag:title' => "Gamertag",
		'xboxgamertag:description' => "Shows the user's Xbox and Windows Live profile in a widget",
        'xboxgamertag:gamertag' => "Insert your gamertag",
        'xboxgamertag:style' => "Select a style",
        'xboxgamertag:no_gamertag' => "Insert your gamertag in the options and refresh the browser",

        );
          
        add_translation("en",$english);

?>
