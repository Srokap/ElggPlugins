<?php 

	$english = array(
		'commentpermissions:publicwarning' => "<strong>PLEASE NOTE: all comments on this post are visible to the public</strong>",
		'commentpermissions:permissions' => "Comments made on this post will only be visible to - ",		
		
		'commentpermissions:friends' => "<strong>Comments made on this post will be visible to people the author is following</strong> ",

		'commentpermissions:thisgroup' => "<strong>Comments made on this post will be visible to only this group</strong> ",
				

		'commentpermissions:invisible' => "<strong>Comments made on this post will be visible one of the author's personal collections</strong> ",
		
		'commentpermissions:invisibleadmin' => "<strong>Comments made on this post will be visible one of the author's personal collections or a group you don't belong to</strong> ",


	
	);
	
	add_translation("en", $english);

?>