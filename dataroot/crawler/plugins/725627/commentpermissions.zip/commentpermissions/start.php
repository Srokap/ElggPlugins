<?php 
/*
 ** show comment permissions when posting
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Jon Dron <jond@athabascau.ca>
 * @copyright Jon Dron 2010


*/

	function commentpermissions_init(){
		
		// extend comments
		elgg_extend_view("comments/forms/edit", "commentpermissions/perms", 505);
		
	}
	// register default elgg events
	register_elgg_event_handler("init", "system", "commentpermissions_init");
	

?>