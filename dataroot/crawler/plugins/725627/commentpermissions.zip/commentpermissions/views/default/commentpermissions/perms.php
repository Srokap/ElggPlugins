<div class="clearfloat">
</div>
<div class="generic_comment">
<?php
//debug print_r($vars['entity']);
$loggedin_user = get_loggedin_user();
if (isloggedin()){
	$accessid=$vars['entity']->access_id;
	$accesslevel=get_readable_access_level	(	$vars['entity']->access_id);
	$permtext="<strong>".elgg_echo('commentpermissions:permissions')."</strong> <em>".$accesslevel."</em>";
	//no readable access level - implies either private collection or, if admin, group of which one is not a member
	if ($accesslevel=="") $permtext=elgg_echo('commentpermissions:invisible'); 
	if ($accesslevel=="" && $loggedin_user->isAdmin()) $permtext=elgg_echo('commentpermissions:invisibleadmin'); 
	//access level is friends 
	if ($accessid==-2) $permtext=elgg_echo('commentpermissions:friends');
	// set for current group (not working yet)
	if($accessid==$group->acl) $permtext=elgg_echo('commentpermissions:thisgroup');
	//access level is public
	if ($accessid==2) $permtext=elgg_echo('commentpermissions:publicwarning');
	
	//show it
	echo $permtext;
	
}
?>
</div>
<div class="clearfloat">
</div>