<?php

	function logslide_init(){
		global $CONFIG;
		extend_view('metatags','pageshells/metatags');
		extend_view('css', 'pageshells/css');

	}

	// Initialise log browser
	register_elgg_event_handler('init','system','logslide_init');

	//page_draw(elgg_echo('thewire:everyone'), $body);

?>