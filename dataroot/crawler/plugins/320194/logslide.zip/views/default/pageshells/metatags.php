<?php

	// extend js links to header
	// user should replace key for there site
	//echo "<script type='text/javascript' src='" . $vars['url'] . "mod/logslide/js/jquery-1.3.2.min.js' ></script>";

	echo "<script type='text/javascript' src='" . $vars['url'] . "mod/logslide/js/slide.js'></script>";

?>

