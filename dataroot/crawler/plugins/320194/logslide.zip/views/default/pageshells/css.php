/*
Name: Sliding Login Panel with jQuery 1.3.2
Author: Jeremie Tisseau
Author URI: http://web-kreation.com/
Script URI: http://web-kreation.com/index.php/tutorials/nice-clean-sliding-login-panel-built-with-jquery/
Date: March 26, 2009
Version: 1.0

	The CSS, XHTML and design is released under Creative Common License 3.0:
	http://creativecommons.org/licenses/by-sa/3.0/

*/

/***** clearfix *****/
.clear {clear: both;height: 0;line-height: 0;}
.clearfix:after {content: ".";display: block;height: 0;clear: both;visibility: hidden;}
.clearfix {display: inline-block;}
/* Hides from IE-mac \*/
* html .clearfix {height: 1%;}
.clearfix {display: block;}
/* End hide from IE-mac */
.clearfix {height: 1%;}
.clearfix {display: block;}

/* Panel Tab/button */
.tab {
  	background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/tab_b.png) repeat-x 0 0;
	height: 42px;
	position: relative;
    top: 0;
    z-index: 999;
}

.tab ul.login {
	display: block;
	position: relative;
  	float: right;
  	clear: right;
  	height: 42px;
	width: auto;
  	font-weight: bold;
	line-height: 42px;
	margin: 0;
	right: 150px;
  	color: white;
  	font-size: 80%;
	text-align: center;
}

.tab ul.login li.left {
  	background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/tab_l.png) no-repeat left 0;
  	height: 42px;
	width: 30px;
	padding: 0;
	margin: 0;
  	display: block;
	float: left;
}

.tab ul.login li.right {
  	background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/tab_r.png) no-repeat left 0;
  	height: 42px;
	width: 30px;
	padding: 0;
	margin: 0;
  	display: block;
	float: left;
}

.tab ul.login li {
 	text-align: left;
  	padding: 0 6px;
	display: block;
	float: left;
	height: 42px;
  	background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/tab_m.png) repeat-x 0 0;
}

.tab ul.login li a {
	color: #15ADFF;
}

.tab ul.login li a:hover {
	color: white;
}

.tab .sep {color:#414141}

.tab a.open, .tab a.close {
	height: 20px;
	line-height: 20px !important;
	padding-left: 30px !important;
	cursor: pointer;
	display: block;
	width: 100px;
	position: relative;
	top: 11px;
}

.tab a.open {background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/bt_open.png) no-repeat left 0;}
.tab a.close {background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/bt_close.png) no-repeat left 0;}
.tab a:hover.open {background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/bt_open.png) no-repeat left -19px;}
.tab a:hover.close {background: url(<?php echo $vars['url']; ?>mod/logslide/graphics/bt_close.png) no-repeat left -19px;}

/* sliding panel */
#toppanel {
    position: absolute;   /*Panel will overlap  content */
    /*position: relative;*/   /*Panel will "push" the content down */
    top: 0;
    width: 100%;
    z-index: 999;
    text-align: center;
    margin-left: auto;
    margin-right: auto;
}

#panel {
	width: 100%;
	height: 120px;
	color: #999999;
	background: #272727;
	overflow: hidden;
	position: relative;
	z-index: 3;
	display: none;
}

#panel h1 {
	font-size: 1.6em;
	padding: 5px 0 10px;
	margin: 0;
	color: white;
}

#panel h2{
	font-size: 1.2em;
	padding: 10px 0 5px;
	margin: 0;
	color: white;
}

#panel p {
	margin: 5px 0;
	padding: 0;
}

#panel a {
	text-decoration: none;
	color: #15ADFF;
}

#panel a:hover {
	color: white;
}


#panel .content {
	width: 960px;
	margin: 0 auto;
	padding-top: 15px;
	text-align: left;
	font-size: 0.85em;
}

#panel .content form {
	margin: 0 0 10px 0;
}

#panel .content label {
	float: left;
	padding-top: 8px;
	clear: both;
	width: 280px;
	display: block;
	color: grey;
}

#panel .content input.field {
	border: 1px #1A1A1A solid;
	background: #414141;
	margin-right: 5px;
	margin-top: 4px;
	width: 180px;
	color: white;
	height: 16px;
}

#panel .content input:focus.field {
	background: #545454;
}

.loginContent {
	width: 550px;
	height: 80px;
	margin: 0 auto;
	text-align: left;
}
.loginContent .hor-left {
	margin-top: 3px;
	width: 110px;
	float: left;
	padding-left: 65px;
	font-size: 0.95em;
}
.loginContent .hor-right {
	width: 110px;
	float: left;
	padding-left: 90px;
	font-size: 0.95em;

}
.loginContent .hor-botton {
	width: 20px;
	float: right;
	padding-left: 20px;
	font-size: 0.95em;

}

.loginContent #persistent_login {
width: 300px;
float: right;
font-size: 0.95em;
}

