<?php
	header("Content-type: text/html; charset=UTF-8");	// Set title
		if (empty($vars['title'])) {
			$title = $vars['config']->sitename;
		} else if (empty($vars['config']->sitename)) {
			$title = $vars['title'];
		} else {
			$title = $vars['config']->sitename . ": " . $vars['title'];
		}?>
<?php echo elgg_view('page_elements/header', $vars); ?>
<?php
	if(isloggedin()){
	 	echo elgg_view('page_elements/elgg_topbar', $vars);
	}
	else{
		echo elgg_view('pageshells/logslide', $vars);
	}

?>
<?php/* echo elgg_view('page_elements/elgg_topbar', $vars); */?>
<?php echo elgg_view('page_elements/header_contents', $vars); ?><!-- main contents -->

<!-- display any system messages -->
<?php echo elgg_view('messages/list', array('object' => $vars['sysmessages'])); ?>


<!-- logSlide -->
<?php/* echo elgg_view('pageshells/logslide', $vars); */?>

<!-- canvas -->
<div id="layout_canvas">

<?php  echo $vars['body']; ?>

<div class="clearfloat"></div>
</div><!-- /#layout_canvas -->

<?php
	if(isloggedin()){
?>
		<!-- spotlight -->
		<?php echo elgg_view('page_elements/spotlight', $vars); ?>
<?php
	}
?>

<!-- footer -->
<?php echo elgg_view('page_elements/footer', $vars); ?>
