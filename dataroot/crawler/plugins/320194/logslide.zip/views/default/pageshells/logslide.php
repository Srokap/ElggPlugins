
<div id="toppanel">
	<div id="panel">
		<div class="content clearfix">
<?php
	// form of user login (elgg)
	global $CONFIG;
	$form_body  = "<div class=\"hor-left\"><label >" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'field')) . "</label></div>";
	$form_body .= "<div class=\"hor-right\"><label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'field')) . elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</label></div><div class=\"content clearfix\"></div>";
	$form_body .= (!isset($CONFIG->disable_registration) || !($CONFIG->disable_registration)) ? "<div id=\"persistent_login\"><label><a href=\"{$vars['url']}account/register.php\">" . elgg_echo('register') . "</a> | " : "";
	$form_body .= "<a href=\"{$vars['url']}account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a> | <input type=\"checkbox\" name=\"persistent\" value=\"true\" />".elgg_echo('user:persistent') . "</label></div>";
	$login_url = $vars['url'];
	if ((isset($CONFIG->https_login)) && ($CONFIG->https_login))
		$login_url = str_replace("http", "https", $vars['url']);
?>
<div class="loginContent">	
				<!-- Login Form -->

					<?php
						echo elgg_view('input/form', array('body' => $form_body, 'action' => "{$login_url}action/login"));
					?>
			</div>
		</div>
	</div> <!-- /login -->	

	<div class="tab">
		<ul class="login">
	    	<li class="left">&nbsp;</li>
	        <li>Hello Guest!</li>
			<li class="sep">|</li>
			<li id="toggle">
				<a id="open" class="open" href="#">Log In | Register</a>
				<a id="close" style="display: none;" class="close" href="#">Close Panel</a>
			</li>
	    	<li class="right">&nbsp;</li>
		</ul>
	</div>
</div>