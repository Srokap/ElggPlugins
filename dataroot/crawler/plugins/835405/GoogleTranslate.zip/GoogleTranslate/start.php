<?php
function gtranslate_init() {        
    elgg_register_widget_type('gtranslate', 'Google Translate', 'The Google translation widget');
}
 
elgg_register_event_handler('init', 'system', 'gtranslate_init');       
?>