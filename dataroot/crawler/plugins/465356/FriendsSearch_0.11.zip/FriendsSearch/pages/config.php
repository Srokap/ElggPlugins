<?php 
// Get your own key here: http://api.centroidmedia.com/apply-for-an-api-key.html
$private_key = "1a54d44d159d5086";
$public_key = "40fb6c6f54734bf0e88a85d92bc543c3";

// Autoload class
function __autoload($class_name) {
    if(file_exists(dirname(__FILE__).'/class/'.$class_name . '.php')) {
        require_once(dirname(__FILE__).'/class/'.$class_name . '.php');
        return;
    }    
} 
?>