<form method="post" name="Psearch" action="psearch.php"><p>People Search </p><table ><tr><td>Firstname</td><td ><input name="firstname" type="text" /></td>	</tr><tr><td>Lastname</td><td>&nbsp;<input name="lastname" type="text" /></td></tr><tr><td >Country</td><td ><select name="country"><option value="be">belgium</option>
<option value="dk">denmark</option><option value="fr">france</option><option value="gb">great britain</option><option value="it">italia</option><option value="nl">nederlands</option> <option value="pl">poland</option><option value="ru">russia</option><option value="es">spain</option>
<option value="se">sweden</option><option value="us">usa</option></select></td></tr><tr><td ></td><td>  <input name="Submit1" type="submit" value="submit" /></td><td></td></tr>	</table></form>
<?php

require_once('config.php');
if (isset($_POST['firstname'] ))
try {
	$wow = new WOW_Client($public_key,$private_key);
	// Set `search` as method
	$wow->setMethod('search');
	// Build an array with parameters
	$parameters = array('format' => 'json',
						'lang' => 'en',
						'country' => $_POST['country'], 
						'firstname' => $_POST['firstname'] ,
						'lastname' => $_POST['lastname'],
						'categories' => 'searchengines,socialnetworks' 
						// OR 'sources' => 'hyves,twitter,hi5' 
						// OR 'set' => 'popular'
						); 
	// Set the parameters...
	$wow->setParameters($parameters);
	// Get the output from the API
	$output = $wow->getOutput();
	// Loop through the available sources, in this case all search engines and social networks
	foreach($output->sources as $nr => $source) {
		// print the source and the results
		print $source->name.' (Results: '.$source->found.')<br />';
		// Person found?
		if($source->found > 0) {
			// Loop through the results
			foreach($source->results as $nr => $result) {
				// Please check the class WOW_Information
				// Each source has a different output values
				print WOW_View_Helper::getInformation($result,$source->id);
				print '<br />';
			}
		}
		print '<br />';
	}
} catch (WOW_Exception $e) {
	print 'Error: #'.$e->getCode().' > '.$e->getMessage();
}

?>
