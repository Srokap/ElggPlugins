<?php

	// include the Elgg engine
	include_once dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php"; 

	// maybe logged in users only?
	//gatekeeper();
	
	// get any input
	//$param = get_input('param');
	
	// if username or owner_guid was not set as input variable, we need to set page owner
	// Get the current page's owner
	$page_owner = page_owner_entity();
	if (!$page_owner) {
		$page_owner_guid = get_loggedin_userid();
		if ($page_owner_guid)
			set_page_owner($page_owner_guid);
	}	

	$title = elgg_echo('FriendsSearch:pagetitle');
	
	// create content for main column
	$content = elgg_view_title($title);
	$content .= "<div>";
	$content .= include('psearch.php');
$content .=	"</div>";
	
	// layout the sidebar and main column using the default sidebar
	$body = elgg_view_layout('two_column_left_sidebar', '', $content);

	// create the complete html page and send to browser
	page_draw($title, $body);
?>
<?php

require_once('config.php');
if (isset($_POST['firstname'] ))
try {
	$wow = new WOW_Client($public_key,$private_key);
	// Set `search` as method
	$wow->setMethod('search');
	// Build an array with parameters
	$parameters = array('format' => 'json',
						'lang' => 'en',
						'country' => $_POST['country'], 
						'firstname' => $_POST['firstname'] ,
						'lastname' => $_POST['lastname'],
						'categories' => 'searchengines,socialnetworks' 
						// OR 'sources' => 'hyves,twitter,hi5' 
						// OR 'set' => 'popular'
						); 
	// Set the parameters...
	$wow->setParameters($parameters);
	// Get the output from the API
	$output = $wow->getOutput();
	// Loop through the available sources, in this case all search engines and social networks
	foreach($output->sources as $nr => $source) {
		// print the source and the results
		print $source->name.' (Results: '.$source->found.')<br />';
		// Person found?
		if($source->found > 0) {
			// Loop through the results
			foreach($source->results as $nr => $result) {
				// Please check the class WOW_Information
				// Each source has a different output values
				print WOW_View_Helper::getInformation($result,$source->id);
				print '<br />';
			}
		}
		print '<br />';
	}
} catch (WOW_Exception $e) {
	print 'Error: #'.$e->getCode().' > '.$e->getMessage();
}

?>