<?php
$english = array(
	'FriendsSearch:pagetitle'	=> 'Search friends on other networks',
	'FriendsSearch:param_label'	=> 'My Parameter',
	'FriendsSearch:success'	=> 'Your search was successful',
	'FriendsSearch:failure'	=> 'No search result',

);

add_translation("en",$english);
?>