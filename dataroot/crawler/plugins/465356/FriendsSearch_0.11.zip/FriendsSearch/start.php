<?php
/*******************************************************************************
 * FriendsSearch
 *
 * @author Georges Gillard
 ******************************************************************************/

	function FriendsSearch_init()
	{
		global $CONFIG;





		register_page_handler('people','FriendsSearch_page_handler');


		add_menu(FriendsSearch, $CONFIG->wwwroot . 'pg/people/index/');


		register_elgg_event_handler('pagesetup','system','FriendsSearch_submenus');


		register_action('FriendsSearch/PeopleSearch', false, '/mod/FriendsSearch/actions/PeopleSearch.php');
		
		
		return true;
	}


	function FriendsSearch_page_handler($page)
	{
		global $CONFIG;

		
		switch ($page[0])
		{
			case 'index':
				include $CONFIG->pluginspath . 'FriendsSearch/pages/index.php';
				break;
		
		}
		
		return true;
	}


	function FriendsSearch_submenus()
	{
		global $CONFIG;

		
		if (get_context() == 'people')
		{
			add_submenu_item('index', $CONFIG->wwwroot . 'pg/people/index/');
		}
		
	}


	
	register_elgg_event_handler('init', 'system', 'FriendsSearch_init');
?>