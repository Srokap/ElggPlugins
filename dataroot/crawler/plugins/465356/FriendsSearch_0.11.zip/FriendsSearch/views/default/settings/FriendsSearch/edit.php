<p>
<?php 

	// set default value if user hasn't set it
	$param = $vars['entity']->param;
	if (!isset($param)) $param = 10;

	echo elgg_echo('FriendsSearch:param_label'); 
	
	echo elgg_view('input/pulldown', array(
			'internalname' => 'params[param]',
			'options_values' => array(	'10' => '10',
										'20' => '20',
										'30' => '30',
										'50' => '50',
										'100' => '100',
									),
			'value' => $param
		));
?>
</p>