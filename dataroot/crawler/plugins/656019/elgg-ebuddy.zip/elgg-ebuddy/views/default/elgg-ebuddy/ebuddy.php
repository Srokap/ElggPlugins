<div class="contentWrapper" style="height:500px">
<iframe src="http://web.ebuddy.com"
align="center" width="100%" height="100%">
</iframe>
</div>