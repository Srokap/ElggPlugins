<?

function elgg_ebuddy_init() {

  global $CONFIG;

// Set up menu for logged in users
	
         if (isloggedin()) {
              add_menu('Ebuddy', $CONFIG->wwwroot ."pg/ebuddy");
         }
	register_page_handler('ebuddy','elgg_ebuddy_page_handler');
}

                function elgg_ebuddy_page_handler($page) {
                                @include(dirname(__FILE__) . "/index.php");
                                return true;
                }

register_elgg_event_handler('init','system','elgg_ebuddy_init');
?>
