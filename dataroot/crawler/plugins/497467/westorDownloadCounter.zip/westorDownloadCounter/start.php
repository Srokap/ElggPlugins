<?php

	function westorDownloadCounter_init(){
		global $CONFIG;
		if (get_context() == "file") {
				add_submenu_item(elgg_echo('file:mostDownloads'), $CONFIG->wwwroot . "mod/westorDownloadCounter/pages/lists/mostDownloads.php", 'b');
		}
		register_plugin_hook('permissions_check', 'object', 'westorDownloadCounter_access_permissions_overwrite');
	}


	// Default event handlers for plugin functionality
	register_elgg_event_handler('init', 'system', 'westorDownloadCounter_init');

	/**
	 * Overrides default permissions for the myaccess context
	 */

	function westorDownloadCounter_access_permissions_overwrite($hook_name, $entity_type, $return_value, $parameters) {
		if (get_context() == 'westorDownloadCounter') {
			return true;
		}
		return null;
	}
?>
