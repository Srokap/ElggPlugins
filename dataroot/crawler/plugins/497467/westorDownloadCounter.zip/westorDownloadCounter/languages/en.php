<?php

	$english = array(
		'file:mostDownloads' => 'Most downloaded files',
	);
					
	add_translation("en",$english);
?>