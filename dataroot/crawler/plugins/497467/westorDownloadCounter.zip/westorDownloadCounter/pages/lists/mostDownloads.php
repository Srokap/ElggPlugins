<?php
	/**
	 * Elgg file browser
	 *
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008-2009 - 2009
	 * @link http://elgg.com/
	 */

	include_once (dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/engine/start.php");

	global $CONFIG;
	$prefix = $CONFIG->dbprefix;

	$area2 = elgg_view_title($title = elgg_echo('file:mostDownloads'));

	get_filetype_cloud(); // the filter

	$page_owner = $_SESSION["user"];

	// like in the file plugin
	// Group submenu option
	if ($page_owner instanceof ElggGroup && get_context() == "groups") {
		if($page_owner->files_enable != "no"){
		    add_submenu_item(sprintf(elgg_echo("file:group"),$page_owner->name), $CONFIG->wwwroot . "pg/file/" . $page_owner->username);
	    }
	}
	// General submenu options
	if ((page_owner() == $_SESSION['guid'] || !page_owner()) && isloggedin()) {
		add_submenu_item(sprintf(elgg_echo("file:yours"),$page_owner->name), $CONFIG->wwwroot . "pg/file/" . $page_owner->username);
		add_submenu_item(sprintf(elgg_echo('file:yours:friends'),$page_owner->name), $CONFIG->wwwroot . "pg/file/". $page_owner->username . "/friends/");
	} else if (page_owner()) {
		add_submenu_item(sprintf(elgg_echo("file:user"),$page_owner->name), $CONFIG->wwwroot . "pg/file/" . $page_owner->username);
		if ($page_owner instanceof ElggUser) // This one's for users, not groups
			add_submenu_item(sprintf(elgg_echo('file:friends'),$page_owner->name), $CONFIG->wwwroot . "pg/file/". $page_owner->username . "/friends/");
	}
	add_submenu_item(elgg_echo('file:all'), $CONFIG->wwwroot . "mod/file/world.php");
	if (can_write_to_container($_SESSION['guid'], page_owner()))
		add_submenu_item(elgg_echo('file:upload'), $CONFIG->wwwroot . "pg/file/". $page_owner->username . "/new/");


	add_submenu_item(elgg_echo('file:mostDownloads'), $CONFIG->wwwroot . "mod/westorDownloadCounter/pages/lists/mostDownloads.php", 'b');

	$max = 10;
	$sql = "SELECT {$prefix}metadata.entity_guid
	FROM {$prefix}metastrings INNER JOIN {$prefix}metadata ON {$prefix}metastrings.id = {$prefix}metadata.name_id
	INNER JOIN {$prefix}metastrings AS {$prefix}metastrings_1 ON {$prefix}metadata.value_id = {$prefix}metastrings_1.id
	WHERE {$prefix}metastrings.string = 'downloadCounter'
	ORDER BY CAST({$prefix}metastrings_1.string AS UNSIGNED INTEGER) DESC
	LIMIT $max";

	$result = get_data($sql);

	$entities = array();
	foreach($result as $row) {
		$entities[] = get_entity($row->entity_guid);
	}

	set_context('search');
	$area2 .= elgg_view_entity_list($entities);

	$body = elgg_view_layout('two_column_left_sidebar', '', $area2);

	// Finally draw the page
	page_draw(sprintf(elgg_echo("file:mostDownloads"),$_SESSION['user']->name), $body);
?>