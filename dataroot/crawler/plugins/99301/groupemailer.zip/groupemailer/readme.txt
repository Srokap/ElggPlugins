/**
	 * Group Emailer
	 * 
	 * @package groupemailer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex oy
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
*/

This plugin sends an email to all group's members when a new message, comment etc is posted to a group. 
The idea of the plugin is to provide information about different activities of a group directly to members' 
emails so that each member of a group doesn't have to login and browse to group to see if there is something new. 

At the moment an email is sent to everyone when:
- a new message is created on group's messageboard
- a new message is posted on group's discussion forum
- a new page is created to group
- a new comment is posted to group

What's new in version 0.8:
* Fixed a bug with where email from forum posts were sent to all people (not just group members) or wasn't sent at all. 
* Tested with Elgg 1.5 


Install: Just drop it into the mod directory.


