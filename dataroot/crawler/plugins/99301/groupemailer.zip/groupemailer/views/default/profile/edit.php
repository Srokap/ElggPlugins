<?php

	/**
	 * xTune profile
	 * 
	 * @package xtune_profile
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jaakko Naakka / Intunex 
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
	 *
	 * 
	 * @uses $vars['entity'] The user entity
	 * @uses $vars['profile'] Profile items from $CONFIG->profile, defined in profile/start.php for now 
	 */


	$user = $vars['entity'];

?>

<form action="<?php echo $vars['url']; ?>action/profile/edit" method="post">

<?php

	$tasks = array(
						'Rehtori', 
						'Opinto-ohjaaja', 
						'Muu'
					);
					
	$allowEmail = array('' => 'Sallittu');

	$allowMail = array('' => 'Sallittu');
	
	$institutions = array(
						'esiopetus',
						'alakoulu', 
						'yläkoulu',
						'yhtenäiskoulu',
						'lukio',
						'2. asteen ammatillinen',
						'AMK',
						'korkeakoulu'
					);

					$interests = array(
						'Koulutus- ja uravalinnat',
						'Yrittäjyys',
						'Taloustieto',
						'Teknologian opetus',
						'Luonnontiede',
						'Taito- ja taideaineet'
					);
					
					
//	echo elgg_view('input/checkboxes', array('options' => $tasks, 'value' => array('rehtori', 'muu')));


	//var_export($vars['profile']);
	if (is_array($vars['config']->profile) && sizeof($vars['config']->profile) > 0)
		//print_r($vars['config']->profile);
		foreach($vars['config']->profile as $shortname => $valtype) {
			if ($metadata = get_metadata_byname($vars['entity']->guid, $shortname)) {
				//echo 'Metadata ' . $shortname . '<br>';
				//print_r($metadata);
				if (is_array($metadata)) {
					$value = array();
					foreach($metadata as $md){
						$value[] = $md->value;	
					}
					//print_r($value);

//					$value = '';
//					foreach($metadata as $md) {
//						if (!empty($value)) $value .= ', ';
//						$value .= $md->value;
//						$access_id = $md->access_id;
//					}
				} else {
					$value = $metadata->value;
					$access_id = $metadata->access_id;
				}
			} else {
				$value = '';
				$access_id = 1;
			}

?>

	<p>
		<label>
			<?php 
			if(elgg_echo("profile:{$shortname}") != ''){
				echo elgg_echo("profile:{$shortname}") . '<br />';
			}
			
			if($shortname == 'task'){
				$options = $tasks;				
			}else if($shortname == 'allowEmail'){
				$options = $allowEmail;
			}else if($shortname == 'allowMail'){
				$options = $allowMail;	
			}else if($shortname == 'institutionType'){
				$options = $institutions;
			}else if($shortname == 'interests'){
				$options = $interests;
			}else if($shortname == 'name'){
				$value = $user->name;	
			}else if($shortname == 'email'){
				$value = $user->email;	
			}
			echo elgg_view("input/{$valtype}",array(
													'options' => $options,
													'internalname' => $shortname,
													'value' => $value,
													));
			 
			/// Set the access level to 0 (private)										
			$access_id = 0;
			echo elgg_view('input/hidden',array('internalname' => 'accesslevel['.$shortname.']', 'value' => $access_id));
			?>
		</label>
			<?php //echo elgg_view('input/access',array('internalname' => 'accesslevel['.$shortname.']', 'value' => $access_id)); ?>
	</p>

<?php

		}

?>


	<p>
		<input type="hidden" name="username" value="<?php echo page_owner_entity()->username; ?>" />
		<input type="submit" class="submit_button" value="<?php echo elgg_echo("save"); ?>" />
	</p>




</form>