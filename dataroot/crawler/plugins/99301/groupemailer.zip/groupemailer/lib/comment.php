<?php

	/**
	 * Group Emailer
	 * Functions for comment post handler
	 * 
	 * @package groupemailer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex 
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
	 */
	
	 
	 function groupemailer_handle_comment($object) {
	 
	 		global $CONFIG;
			
			// Comment that user wrote
			$commented_entity = get_entity($object->entity_guid);
		
			$entity = get_entity($commented_entity->container_guid);
			
			// Only post if this is a comment that is posted on a group
			if ($entity->type == 'group') {
 	
				// URL to group. This is send to user as a part of the email
				$item_url = $commented_entity->getURL(); 
			
				// Construct email that is sent to each suser
				$subject = sprintf(elgg_echo('groupemailer:email:comment:subject'), $entity->name);
				$body =  sprintf(
							elgg_echo('groupemailer:email:comment:body'),
							$_SESSION['user']->name,
							$entity->name, 
							$object->value,
							$item_url);
		
				// Find group memberns
				$group_members = get_group_members($commented_entity->container_guid);					
				
				// Build final result
				$result->body = $body;
				$result->subject = $subject;
				$result->group_members = $group_members;
				
				return $result;
				
			} else {
			
				return null;
			}
	 }
	 
	 
?>