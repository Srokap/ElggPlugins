<?php

	/**
	 * Group Emailer
	 * Functions for Page post handler
	 * 
	 * @package groupemailer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex 
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
	 */
	
	 
	 function groupemailer_handle_page($group, $object) {
	 
	 		global $CONFIG;
			
			// Page that user wrote
			$page = get_entity($object->entity_guid);
	 	
			// URL to group. This is send to user as a part of the email
			$page_url = $CONFIG->wwwroot . "pg/pages/view/$page->guid/"; 
		
			// Construct email that is sent to each suser
			$subject = sprintf(elgg_echo('groupemailer:email:page:subject'), $group->name);
			$body =  sprintf(
						elgg_echo('groupemailer:email:page:body'),
						$_SESSION['user']->name,
						$page->title,
						$page_url);
	
			// Find group memberns
			$group_members = get_group_members($group->container_guid);			
			
			// Build final result
			$result->body = $body;
			$result->subject = $subject;
			$result->group_members = $group_members;
			
			return $result;
	 }
	 
	 
?>