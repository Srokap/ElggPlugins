<?php

	/**
	 * Group Emailer
	 * Functions for MessageBoard posts handler
	 * 
	 * @package groupemailer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex 
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
	 */
	
	 
	 function groupemailer_handle_forum_post($group, $object) {
	 
	 		global $CONFIG;
	 	
			// URL to group. This is send to user as a part of the email
			$group_url = $CONFIG->wwwroot . "mod/groups/topicposts.php?topic=" . $object->entity_guid . "&group_guid=" . $group->container_guid; 
		
			// Construct email that is sent to each suser
			$subject = sprintf(elgg_echo('groupemailer:email:forum:subject'), $group->name);
			$body =  sprintf(
						elgg_echo('groupemailer:email:forum:body'),
						$_SESSION['user']->name,
						$object->value,
						$group_url);
	
			// Find group memberns
			$group_members = get_group_members($group->container_guid);			
			
			$result->body = $body;
			$result->subject = $subject;
			$result->group_members = $group_members;
			
			return $result;
	 }
	 
	 
?>