<?php

	$english = array(
	

		/**
		 * Email messages
		 */
		 
		 	//
		 	// Messageboard
			//
	
			'groupemailer:email:messageboard:subject' => 'A new message to group %s',
			'groupemailer:email:messageboard:body' => "%s wrote a new message to group's messageboard. It reads:

			
%s


To view group, click here:

	%s


You cannot reply to this email.",

			//
			// Forum
			//
			'groupemailer:email:forum:subject' => 'A new message to group %s',
						'groupemailer:email:forum:body' => "%s wrote a new message to group's discussion forum. It reads:
			
						
%s
			
			
To view or reply to message, click here:
			
	%s
			
			
You cannot reply to this email.",
			
			//
			// Page
			// 
			'groupemailer:email:page:subject' => 'A new page to group %s',
			'groupemailer:email:page:body' => "%s wrote a new page called %s.
			
			
To read the page, click here:
			
	%s
			
			
You cannot reply to this email.",
			
			//
			// Comment
			// 
			'groupemailer:email:comment:subject' => 'A new comment to group %s',
			'groupemailer:email:comment:body' => "%s wrote a new comment to group %s. It reads:
			
						
%s
			
			
To read the commented item and the comment, click here:
			
	%s
			
			
You cannot reply to this email.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Sorry; you need to actually put something in the message area before we can save it.",
			'messageboard:notfound' => "Sorry; we could not find the specified item.",
			'messageboard:notdeleted' => "Sorry; we could not delete this message.",
	     
			'messageboard:failure' => "An unexpected error occurred when adding your message. Please try again.",
	
	);
					
	add_translation("en",$english);

?>