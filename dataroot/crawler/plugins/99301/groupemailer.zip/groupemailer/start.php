<?php

	/**
	 * Group Emailer
	 * 
	 * @package groupemailer
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jussi Ahtikari / Intunex 
	 * @copyright Intunex 2009
	 * @link http://www.intunex.fi/
	 */
	 
 	 require_once("lib/messageboard.php");
  	 require_once("lib/forum.php");
	 require_once("lib/page.php");
	 require_once("lib/comment.php");
	 
	 global $CONFIG;


	/**
	 * Profile init function; sets up the profile functions
	 *
	 */
		function groupemailer_init() {
			// Load the language file 
			// Not needed at the moment
			//register_translations($CONFIG->pluginspath . "xtune_profile/languages/");
		}
		
	/**
	 * This function loads a set of default fields into the profile
	 *
	 */
		function groupemailer_email($event, $object_type, $object = null)
		{
			global $CONFIG;
			
			//print_r($object);
			//$entity = get_entity($object->entity_guid);
			//print_r($entity);
			//echo "url: ".  $entity->getURL();
			//echo "guid: $object->entity_guid";
			//$message = get_entity($object->entity_guid);
			//print_r($message);
			//die;
			
			// Check if object is some of the objects that this plugin supports
			if (isset($object) &&
				($object->name == 'messageboard'
				 || $object->name == 'group_topic_post'
				 || $object->name == 'page'
				 || $object->name == 'generic_comment')) {
			
				// $object-variable contains all information about the object 
				// created to system. 
		
				// Find all users who belong to given group
				$group = get_entity($object->entity_guid);
			
			
				// Email is sent for the following group objects
				// 1. Messages on message board
				// 2. Pages (modified or new)
				// 3. Discussion messages
				$result = null;
				if ($object->name == 'messageboard') {				
					$result = groupemailer_handle_messageboard($group, $object);
				} else if ($object->name == 'group_topic_post') {				
					$result = groupemailer_handle_forum_post($group, $object);
					$group_members = get_group_members($object->container_guid);
				} else if ($object->name == 'page') {				
					$result = groupemailer_handle_page($group, $object);
				} else if ($object->name == 'generic_comment') {	
					$result = groupemailer_handle_comment($object);
				}			
				
				// Send email to each group member
				if (isset($result)) {
					foreach ($result->group_members as $member) {
							groupemailer_notify_user($result->subject, $result->body, $member, $group);	
					}
				}				
			} 			

			return true;
		}
		
		/**
		 * Sends an email notification to given group member of the given object
		 */
		function groupemailer_notify_user($subject, $body, $user, $group) {
		
			// Do net send email to person who did the thing other
			// persons will be notifed (for example person who wrote
			// a message won't get his/her own message as email)
			//if ($user->guid != $_SESSION['user']->getGUID()) {

					//echo "<p>$user->email<p>$subject<p>$body"; // for debug purposes
					//die;
					
					notify_user($user->guid, $group->owner_guid, $subject, $body, NULL, 'email');
			//} 
		}



	// Make sure the profile initialisation function is called on initialisation
		register_elgg_event_handler('init','system','groupemailer_init',1);

	/// Register our plugin hook to setup our profile fields
		register_elgg_event_handler('create', 'annotation', 'groupemailer_email', 900);
		

?>