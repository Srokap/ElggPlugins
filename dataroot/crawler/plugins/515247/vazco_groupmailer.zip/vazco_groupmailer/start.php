<?php

  /**
   * vazco_groupmailer plugin
   * @license Lesser General Public License (LGPL)
   * @author Michal Zacher [www.elggdev.com]
   * @copyright Michal Zacher 2009
   **/
  
  
  /** THe vazco_groupmailer is using:
   * PHPMailer Plugin
   * @package PHPMailer
   * @license Lesser General Public License (LGPL)
   * @author Cash Costello
   * @copyright Cash Costello 2008-2009
   **/   

  
    /**
     * initialize the plugin
     */    
    function vazco_groupmailer_init() 
    {
    	global $CONFIG;

		register_page_handler('vazco_groupmailer','vazco_groupmailer_page_handler');
      	register_elgg_event_handler('pagesetup','system','vazco_gmailer_submenus');
      	
      	register_action("vazco_groupmailer/send",false,$CONFIG->pluginspath . "vazco_groupmailer/actions/send.php");
      	
    	// include phpmailer wrapper for other plugins to use if it's not already included
		if (!function_exists("phpmailer_send")){
			require_once $CONFIG->pluginspath . 'vazco_groupmailer/mail.php';
		}
		
   		register_notification_handler('email', 'vazco_groupmailer_notify_handler');
    }
    
    function vazco_gmailer_submenus(){
        global $CONFIG;
    	$page_owner = page_owner_entity();
    	if (isadminloggedin() && $page_owner instanceof ElggGroup && get_context() == 'groups'){
      		add_submenu_item(elgg_echo('vazco_groupmailer:send:menu'),$CONFIG->wwwroot."pg/vazco_groupmailer/send/".$page_owner->guid,'0groupedit');
    	}    	
    }
    
    function vazco_groupmailer_page_handler($page) {
    	global $CONFIG;
		if (isset($page[0])) 
		{
			switch($page[0]) 
			{
				case "send":  //view list of albums owned by container
					set_context('groups');
					if (isset($page[1])){
						set_page_owner($page[1]);
						require_once($CONFIG->pluginspath."vazco_groupmailer/send.php");
					}
					break;
			}
		}
    }
    /**
     * Send a notification via email using phpmailer
     *
     * @param ElggEntity $from The from user/site/object
     * @param ElggUser $to To which user?
     * @param string $subject The subject of the message.
     * @param string $message The message body
     * @param array $params Optional parameters (not used)
     * @return bool
     */
    function vazco_groupmailer_notify_handler(ElggEntity $from, ElggUser $to, $subject, $message, array $params = NULL) 
    {
      global $CONFIG;

      if (!$from)
        throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'from'));
       
      if (!$to)
        throw new NotificationException(sprintf(elgg_echo('NotificationException:MissingParameter'), 'to'));
    
      if ($to->email=="")
        throw new NotificationException(sprintf(elgg_echo('NotificationException:NoEmailAddress'), $to->guid));      
      
      $from_email = vazco_groupmailer_extract_from_email();

      $site = get_entity($CONFIG->site_guid);
      $from_name = $site->name;
	  $html = false;
	  if (isset($_REQUEST['vazco_groupmailer_html']))
		$html = $_REQUEST['vazco_groupmailer_html'];
      return phpmailer_send($from_email, $from_name, $to->email, '', $subject, $message, null, $html);
    }

    /**
     * Determine the best from email address
     *
     * @return string with email address
     */
    function vazco_groupmailer_extract_from_email()
    {
      global $CONFIG;
      
      $from_email = '';
      $site = get_entity($CONFIG->site_guid);
      // If there's an email address, use it - but only if its not from a user.
      if ((isset($from->email)) && (!($from instanceof ElggUser))) 
        $from_email = $from->email;
      // Has the current site got a from email address?
      else if (($site) && (isset($site->email))) 
        $from_email = $site->email;
      // If we have a url then try and use that.
      else if (isset($from->url)) 
      {
        $breakdown = parse_url($from->url);
        $from_email = 'noreply@' . $breakdown['host']; // Handle anything with a url
      }
      // If all else fails, use the domain of the site.
      else 
        $from_email = 'noreply@' . get_site_domain($CONFIG->site_guid); 

      return $from_email;      
    }
     
    register_elgg_event_handler('init','system','vazco_groupmailer_init');       
?>
