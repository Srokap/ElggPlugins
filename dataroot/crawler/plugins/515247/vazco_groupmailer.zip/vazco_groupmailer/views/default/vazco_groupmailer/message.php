<?php

/**
   * vazco_groupmailer plugin
   * @license Lesser General Public License (LGPL)
   * @author Michal Zacher [www.elggdev.com]
   * @copyright Michal Zacher 2009
   **/
	 
	$msg_title = $_SESSION['msg_title'];
	$msg_content = $_SESSION['msg_contents'];
	
	// clear sticky form cache in case user browses away from page and comes back 
	unset($_SESSION['msg_title']);
	unset($_SESSION['msg_contents']);
		
	
	 
?>
	<div class="contentWrapper">
	<form action="<?php echo $vars['url']; ?>action/vazco_groupmailer/send" method="post" name="messageForm">
		<?php echo elgg_view('input/securitytoken');?>
	    <p><?php echo elgg_echo('vazco_groupmailer:description')?></p>
		<p><label><?php echo elgg_echo("vazco_groupmailer:title"); ?>: <br /><input type='text' name='title' value='<?php echo $msg_title; ?>' class="input-text" /></label></p>
		<p class="longtext_editarea"><label><?php echo elgg_echo("vazco_groupmailer:message"); ?>: <br />
		<?php

				    echo elgg_view("input/longtext", array(
									"internalname" => "message",
									"value" => $msg_content,
													));
			
		?>
		</label></p>
		<p>&nbsp;</p>
		<input type="hidden" value="<?php echo $vars['group_guid'];?>" name="group_guid">
		<p><input type="checkbox" name="template"/> <?php echo elgg_echo('vazco_groupmailer:template');?> </p>
		<p><input type="submit" class="submit_button" value="<?php echo elgg_echo("vazco_groupmailer:fly"); ?>" /></p>
	
	</form>
	</div>