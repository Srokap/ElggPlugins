<?php

	$english = array(	
      	'phpmailer:smtp' => 'Use SMTP',	
      	'phpmailer:host' => 'SMTP Host',
      	'phpmailer:smtp_auth' => 'Use SMTP Authorization',
      	'phpmailer:username' => 'Username',
      	'phpmailer:password' => 'Password',
	 	'phpmailer:nonstd_mta' => 'Using Nonstandard MTA (end of line = \n)',
		'vazco_groupmailer:send' => 'Send group e-mail',
		'vazco_groupmailer:send:menu' => 'Send group e-mail',
		
		'vazco_groupmailer:nogroup' => 'No group was chosen',
		'vazco_groupmailer:norights' => 'You have no rights to send mass e-mail to this group',
		'vazco_groupmailer:fly' => 'Send',
		'vazco_groupmailer:message' => 'Message body',
		'vazco_groupmailer:title' => 'Title',
		'vazco_groupmailer:description' => 'This form allows you to send e-mails to all the group members.<br/>
		<br/>You can use the following special markers:<br/>
		{$message_receiver} - the receiver of the message',
	
		'vazco_groupmailer:template' => 'Use template (you can set it in plugin\'s settings)',
		'vazco_groupmailer:sent' => 'Messages have been sent to %s user(s)',
		'vazco_groupmailer:nomessage' => 'You have to fill in a message body',
		'vazco_groupmailer:notitle' => 'You have to fill in a message title',
		'vazco_groupmailer:message:notsent' => 'The message to the %s was not sent',
		
		'phpmailer:template:settings' => 'Set template for the messages sent to groups. You can use the following markers:<br/><br/>
		{$message_body} - the context of the message<br/>
		{$message_title} - the title of the message<br/>
		{$message_sender} - the name of the sender of the message<br/>
		{$message_receiver} - the name of the receiver of the message',
		'vazco_groupmailer:template:nomessage' => 'There is no {$message_body} marker in the template. Message can\'t be sent.',
		
	);
					
	add_translation("en",$english);

?>
