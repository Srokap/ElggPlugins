This plugin is using Cash's PHPMailer plugin. You can view his site under this address: http://www.cashcostello.com/

INSTALLATION
==========================
Put into mod and enable in the admin panel. There will be a new link added to the group menus for admin.


SMTP AUTHENTICATION
===========================
By default, this plugin will turn on smtp authentication if smtp is turned on.
If your server does not require authentication, you'll want to edit mail.php
and turn off authentication.


TROUBLESHOOTING
===========================
If there are errors, they should be written to your server error log.


HOW TO USE THIS FROM ANOTHER PLUGIN
=============================
See the function phpmailer_send() in mail.php.


PHPMailer can be found at http://phpmailer.codeworxtech.com/
