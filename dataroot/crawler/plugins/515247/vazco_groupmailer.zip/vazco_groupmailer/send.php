<?php

/**
   * vazco_groupmailer plugin
   * @license Lesser General Public License (LGPL)
   * @author Michal Zacher [www.elggdev.com]
   * @copyright Michal Zacher 2009
   **/

  /** THe vazco_groupmailer is using:
   * PHPMailer Plugin
   * @package PHPMailer
   * @license Lesser General Public License (LGPL)
   * @author Cash Costello
   * @copyright Cash Costello 2008-2009
   **/   
   
	// Load Elgg engine
		require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
	// If we're not logged in, forward to the front page
		gatekeeper(); 
	// If not admin, forward to the front page
		if (!isadminloggedin()) {
			register_error(elgg_echo('vazco_groupmailer:norights'));
			forward();
		}
	//If not group ID passed, report error and return to the previous page
		$group = page_owner_entity();
		if (! ($group instanceof ElggGroup)){
			register_error(elgg_echo('vazco_groupmailer:nogroup'));
			forward();
		}
		
    // Get the current page's owner
		$page_owner = page_owner_entity();
		if ($page_owner === false || is_null($page_owner)) {
			$page_owner = $_SESSION['user'];
			set_page_owner($page_owner->getGUID());
		}
         
    // Set the page title
	    $area2 = elgg_view_title(elgg_echo("vazco_groupmailer:send"));

	    $group_guid = page_owner();
    // Get the send form
		$area2 .= elgg_view("vazco_groupmailer/message", array('group_guid' => $group_guid));

	// Format
		$body = elgg_view_layout("two_column_left_sidebar", '', $area2);
		
	// Draw page
		page_draw(sprintf(elgg_echo('messages:send'),$page_owner->name),$body);
		
?>