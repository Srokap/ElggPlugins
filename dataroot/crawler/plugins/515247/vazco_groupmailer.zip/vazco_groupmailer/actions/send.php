<?php 

  /**
   * vazco_groupmailer plugin
   * @license Lesser General Public License (LGPL)
   * @author Michal Zacher [www.elggdev.com]
   * @copyright Michal Zacher 2009
   **/

	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");
	
	global $CONFIG;
	
	// validate user is an admin
	admin_gatekeeper ();
	
	$message_body = get_input('message');
	$message_title = get_input('title');
	$group_guid = get_input('group_guid');
	
	$postback_url = $CONFIG->wwwroot.'pg/vazco_groupmailer/send/'.$group_guid;
	$success_url = $CONFIG->wwwroot.'pg/groups/'.$group_guid;

	$_SESSION['msg_title'] = $message_title;
	$_SESSION['msg_contents'] = $message_body;
	
	if (!$message_body){
		register_error(elgg_echo('vazco_groupmailer:nomessage'));
		forward($postback_url);
	}
	
	if (!$message_title){
		register_error(elgg_echo('vazco_groupmailer:notitle'));
		forward($postback_url);
	}
	
	$group = get_entity($group_guid);
	if (!($group instanceof ElggGroup)){
		register_error(elgg_echo('vazco_groupmailer:nogroup'));
		forward($postback_url);	
	}

	unset($_SESSION['msg_title']);
	unset($_SESSION['msg_contents']);
		
	//get template for the message
	$template = get_input('template',0);

	if ($template){
		$template = get_plugin_setting('phpmailer_template','vazco_groupmailer');
		if (strstr($template, '{$message_body}')){
			$message_sender = get_loggedin_user()->name; 
			$template = str_replace ( '{$message_body}', $message_body, $template);
			$template = str_replace ( '{$message_title}', $message_title, $template);
			$template = str_replace ( '{$message_sender}', $message_sender, $template);
			//set message body as in template
			$message_body = $template;
		}else{
			register_error(elgg_echo('vazco_groupmailer:template:nomessage'));
		}
	}

	//send e-mails to all the members
	$members = $group->getMembers(99999999);
	$_REQUEST['vazco_groupmailer_html'] = true;
	foreach ($members as $member){
			//set receiver's name
			$message_receiver = $member->name;
			$message_body_updated = str_replace ( '{$message_receiver}', $message_receiver, $message_body);
		try{
			notify_user($member->guid, get_loggedin_userid(), $message_title, $message_body_updated, NULL, 'email');
		}catch(exception $e){
			register_error(sprintf(elgg_echo('vazco_groupmailer:message:notsent'),$member->name));
			//send other messages
		}
	
	}

	system_message(sprintf(elgg_echo("vazco_groupmailer:sent"),sizeof($members)));
	forward($success_url);
?>