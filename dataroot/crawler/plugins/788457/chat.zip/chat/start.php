<?php
		function chat_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('PaixChat'), $CONFIG->wwwroot . "mod/chat");
		}
		
	register_elgg_event_handler('init','system','chat_init');

?>