<?php
// Load Elgg engine 
		include_once(dirname(dirname(dirname(dirname(__FILE__)))) . "/engine/start.php");

		//  nur f�r eingeloggte user Das ist die Gatekeeper funktion 
		gatekeeper();
		      global $CONFIG;
		
		
function afficher()
{
        $reponse = new xajaxResponse();
        $chat = '';
        $fichier_texte = fopen('./chat.txt', 'r');
        $chat = fread($fichier_texte, filesize('./chat.txt'));
        fclose($fichier_texte);
        $reponse->assign('block', 'innerHTML', $chat);
        return $reponse;
}

function envoyer($donnees_formulaire)
{
        $reponse = new xajaxResponse();
        $fichier_texte = fopen('./chat.txt', 'a');
        fwrite($fichier_texte, addslashes('<font color="red" style="text-decoration:underline; font-weight:bold;">' . htmlentities(utf8_decode($donnees_formulaire['posteur'])) . ':</font>&nbsp;&nbsp;&nbsp;' . htmlentities(utf8_decode($donnees_formulaire['message'])) . '<br />'));
        fclose($fichier_texte);
        $reponse->clear('message', 'value');
        $reponse->call('xajax_afficher');
        return $reponse;
}

require_once('./xajax_core/xajax.inc.php');
$xajax = new xajax(); 
$xajax->setCharEncoding('iso-8859-1');
$xajax->register(XAJAX_FUNCTION, 'afficher');
$xajax->register(XAJAX_FUNCTION, 'envoyer');
$xajax->processRequest();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
        <head>
                <title>PaixLand: Chat !!!!</title>
                <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				<link rel="stylesheet" href="paix.css" type="text/css" />
                <?php $xajax->printJavascript(); ?>
                <script type="text/javascript">
                function refresh()
                {
                        xajax_afficher();
                        setTimeout(refresh, 5000);
                }
                </script>	
        </head>
        <body>
				<div id="block"></div>
				<script type="text/javascript">
     window.onclick=function(){
	document.getElementById('block').scrollTop = document.getElementById('block').scrollHeight;
                             };
</script>
<style type="text/css"> 
    #block { 
        background-color: #eeeeee;color: purple;border: 1px dashed red; overflow-x: hidden;overflow-y: auto; height: 250px; padding-bottom: 36px;padding-left: 10px; 
		   } 
</style>
                <form action="">
                        <fieldset>
                         <legend>message :</legend>
                         <div>
						<label> 
						
			    <input type="hidden" id="posteur" name="posteur" value="<?php echo $_SESSION['username']; ?>" />
			 </label><br />
                          <label>Message : <input type="text" size="50" id="message" name="message" /></label>
                          <input type="submit" value="Envoyer" onclick="xajax_envoyer(xajax.getFormValues(this.form)); return false;" />
                         </div>
                        </fieldset>
                </form>
				
                <script type="text/javascript">
                        refresh();
                </script>
        </body>
</html>