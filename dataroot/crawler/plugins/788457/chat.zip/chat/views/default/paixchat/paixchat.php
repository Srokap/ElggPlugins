<div class="contentWrapper">
<div align="left">

<?php
echo "<iframe src='$CONFIG->wwwroot/mod/chat/lib/paixchat.php"."' width='900' height='466' frameborder='0' ></iframe>";
?>


</div>
</div>