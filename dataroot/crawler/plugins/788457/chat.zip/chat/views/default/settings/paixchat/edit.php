<p>
<?php 

// get user set value or use default
$param = 10;
if (isset($vars['entity']->param)) {
	$param = $vars['entity']->param;
}

echo elgg_echo('paixchat:param_label'); 

$options = array(
	'10' => '10',
	'20' => '20',
	'30' => '30',
	'50' => '50',
	'100' => '100',
);

echo elgg_view(	'input/pulldown',
				array(
					'internalname' => 'params[param]',
					'options_values' => $options,
					'value' => $param
				)
);
?>
</p>