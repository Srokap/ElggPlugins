/* CSS for paixchat begin */

.paixchat_div {
	color: #000000;
	background-color: red;
}

/* CSS for paixchat end */
