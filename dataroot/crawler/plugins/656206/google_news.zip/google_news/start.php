<?php
  function google_news_init() {        
    add_widget_type('google_news', 'Google News Widget', 'Google News Widget');
  }
 
  register_elgg_event_handler('init','system','google_news_init');       
?>