
.speak_freely_warning {
	width: 300px;
	float: right;
	margin: 15px;
	padding: 10px;
	border: 2px solid red;
	background-color: #EFACAC;
	color: black;
	font-weight: bold;	
}

#speak_freely_name_field {
	width: 200px;	
}
