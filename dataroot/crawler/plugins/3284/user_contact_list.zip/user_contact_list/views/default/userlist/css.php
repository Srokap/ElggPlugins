<?php

	/**
	 * User Contact List - Plugin
	 * 
	 * @package User Contact List
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Michael T Jones
	 * @copyright Michael T Jones 2008
	 * @link http://www.facebake.com/
	 */
?>

/* tables still need cellspacing="0" (for ie6) */
.uv_list {
	margin-top: 10px;
	border-spacing: 5px;
}
