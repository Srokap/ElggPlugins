<?php
if (isloggedin()) forward('pg/dashboard/');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en-US" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
	<title>Elgg Site</title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="mod/nebulosa/css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="mod/nebulosa/css/jquery.jcarousel.css" type="text/css" media="all" />
	<link rel="stylesheet" href="mod/nebulosa/css/skin.css" type="text/css" media="all" />
	<!--[if IE 6]>
		<link rel="stylesheet" href="css/ie6.css" type="text/css" media="all" />
	<![endif]-->
	<link rel="shortcut icon" type="image/x-icon" href="mod/nebulosa/css/images/favicon.ico" />
	
	<script src="mod/nebulosa/js/jquery-1.4.2.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="mod/nebulosa/js/jquery.jcarousel.js" type="text/javascript" charset="utf-8"></script>
	<script src="mod/nebulosa/js/png-fix.js" type="text/javascript" charset="utf-8"></script>
	<script src="mod/nebulosa/js/fn.js" type="text/javascript" charset="utf-8"></script>
	
	<title>LIGHTBOX EXAMPLE</title>
		<style>
		.black_overlay{
			display: none;
			position: absolute;
			top: 0%;
			left: 0%;
			width: 300%;
			height: 300%;
			background-color: black;
			z-index:1001;
			-moz-opacity: 0.8;
			opacity:.60;
			filter: alpha(opacity=80);
		}
		.white_content {
			display: none;
			position: absolute;
			top: 25%;
			left: 32%;
			width: 30%;
			height: 25%;
			padding: 16px;
			border: 16px solid black;
			background-color: black;
			z-index:1002;
			overflow: auto;
			body: white;
			}
			
			.register_content {
			display: none;
			position: absolute;
			top: 25%;
			left: 32%;
			width: 30%;
			height: 45%;
			padding: 16px;
			border: 16px solid black;
			background-color: black;
			z-index:1002;
			overflow: auto;
			body: white;
			}
	</style>
	
</head>
	<body>
	
	
	
		
	<style>
.messages {
	background:#ccffcc;
	color:#000000;
	padding:3px 10px 3px 10px;
	z-index: 8000;
	margin:0;
	position:fixed;
	top:30px;
	width:969px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border:4px solid #00CC00;
	cursor: pointer;
}
.messages_error {
	border:4px solid #D3322A;
	background:#F7DAD8;
	color:#000000;
	padding:3px 10px 3px 10px;
	z-index: 8000;
	margin:0;
	position:fixed;
	top:30px;
	width:969px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	cursor: pointer;
}
.closeMessages {
	float:right;
	margin-top:17px;
}
.closeMessages a {
	color:#666666;
	cursor: pointer;
	text-decoration: none;
	font-size: 80%;
}
.closeMessages a:hover {
	color:black;
}
</style>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').animate({opacity: 1.0}, 1000);
	$('.messages').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
<script type="text/javascript">
$(document).ready(function () {
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').animate({opacity: 1.0}, 1000);
	$('.messages_error').fadeOut('slow');

	$('span.closeMessages a').click(function () {
		$(".messages_error").stop();
		$('.messages_error').fadeOut('slow');
	return false;
	});

	$('div.messages').click(function () {
		$(".messages").stop();
		$('.messages').fadeOut('slow');
	return false;
	});
});
</script>
	
	

<?php $messages = system_messages();	
	$message = $messages['messages'];
	
	if(count($message) > 0){ 
		echo '<div class="messages">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($message as $message1)
					{
					echo '<p>';
					echo $message1;
					echo '</p>';
					}
		echo '</div>';
	}

	$errors = register_error();
	$error = $errors['errors'];
	if(count($error) > 0){ 
		echo '<div class="messages_error">';
		echo '<span class="closeMessages"><a href="#">click to dismiss</a></span>';
			foreach($error as $error1)
					{
					echo '<p>';
					echo $error1;
					echo '</p>';
					}
		echo '</div>';
	}


////////////////////////////////////////////////////////////////////////////////////////////////
?>
	
	
	
	
	
	
	
	
	
	
	
		<div id="header">
			<div class="shell">
				<h1 id="logo"><a href="http://www.milocker.com/shop" title="Social Web Free Themes"><span>SocialWeb Theme</span></a></h1>
				<div id="nav">
					<ul>
					    <li><a href="#" class="active"><strong>Home<span>xD</span></strong></a></li>
					    <li><a href="javascript:void(0)" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'"><strong>Login<span>Click here to login</span></strong></a><div id="light" class="white_content"><center>
							<div id="welcome-box">
								<div id="login-box">
								
									<?php
									$form_body = 
									"
										<p>
										<label>"
										.elgg_echo('username')
										."<br />"
										.elgg_view
										(
											'input/text'
											,array
											(
												'internalname' => 'username'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										"<label>"
										.elgg_echo('password')
										."<br />" 
										.elgg_view
										(
											'input/password'
											,array
											(
												'internalname' => 'password'
												,'class' => 'login-textarea'
											)
										)
										."</label><br />
									";
									$form_body .=
										elgg_view
										(
											 'input/submit'
											,array
											(
												'value' => elgg_echo('login')
											)
										)
										."</p>
									";
									echo elgg_view
									(
										'input/form'
										,array
										(
											 'body' => $form_body
											,'action' => ""
											.$vars['url']
											."action/login"
										)
									);
									?>
									<a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">Close</a></div>
								</div><!-- div id="login-box" -->
							</div><!-- div id="welcome-box" -->
							</center> 
							
		<div id="fade" class="black_overlay"></div></li>
		
					    <li><a href="javascript:void(0)" onclick = "document.getElementById('register').style.display='block';document.getElementById('fade').style.display='block'"><strong>Register<span>Open an Account here!</span></strong></a><div id="register" class="register_content">
						
						<center>
							<div id="register-box">
								<div id="register-box">
								<?php
								////////////////////////////////////////////////////////////////
								$form_body  = "<p><label>................<br>" . elgg_echo('name') . "<br />" . elgg_view('input/text' , array('internalname' => 'name', 'class' => "general-textarea", 'value' => $name)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('email') . "<br />" . elgg_view('input/text' , array('internalname' => 'email', 'class' => "general-textarea", 'value' => $email)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('username') . "<br />" . elgg_view('input/text' , array('internalname' => 'username', 'class' => "general-textarea", 'value' => $username)) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password' , array('internalname' => 'password', 'class' => "general-textarea")) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('passwordagain') . "<br />" . elgg_view('input/password' , array('internalname' => 'password2', 'class' => "general-textarea")) . "</label><br />";
								$form_body .= elgg_view('register/extend');
								$form_body .= elgg_view('input/captcha');
								if ($admin_option) {
									$form_body .= elgg_view('input/checkboxes', array('internalname' => "admin", 'options' => array(elgg_echo('admin_option'))));
								}
								$form_body .= elgg_view('input/hidden', array('internalname' => 'friend_guid', 'value' => $vars['friend_guid']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'invitecode', 'value' => $vars['invitecode']));
								$form_body .= elgg_view('input/hidden', array('internalname' => 'action', 'value' => 'register'));
								$form_body .= elgg_view('input/submit', array('internalname' => 'submit', 'value' => elgg_echo('register'))) . "</p>";
								?>
								<div id="register-box">
								<h2>
								<?php
								//echo elgg_echo('register');
								?>
								</h2>
								<?php
								////////////////////////////////////////////////////////////////
								echo elgg_view
								(
									'input/form'
									,array
									(
										'body' => $form_body
										,'action' => "{$vars['url']}action/register"
									)
								);
								?>
								<a href = "javascript:void(0)" onclick = "document.getElementById('register').style.display='none';document.getElementById('fade').style.display='none'">Close</a></div>
								</div><!-- div id="login-box" -->
							</div><!-- div id="welcome-box" -->
							<div id="fade" class="black_overlay"></div>
							</center>
						
						
						
						</li>
					    <li><a href="<?php echo $vars['url']; ?>pg/expages/read/Terms/"><strong>Terms<span>Read our Terms and Conditions</span></strong></a></li>
					    <li><a href="<?php echo $vars['url']; ?>pg/expages/read/Privacy/"><strong>Privacy<span>Our Privacy</span></strong></a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="slide-area">
			<div class="shell">		
				<div class="slider">
					<ul id="mycarousel" class="jcarousel-skin-tango">
					    <li>
					    	<div class="image">
					    		<img src="mod/nebulosa/css/images/iphone.png" alt="" />
					    	</div>
					    	<div class="info">
					    		<h2>slide 1</h2>
					    		<p><a href="#">Lorem ipsum dolor sit amet</a>, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		<p>Lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		
					    	</div>
					    </li>
					    <li>
					    	<div class="image">
					    		<img src="mod/nebulosa/css/images/iphone.png" alt="" />
					    	</div>
					    	<div class="info">
					    		<h2>slide 2</h2>
					    		<p><a href="#">Lorem ipsum dolor sit amet</a>, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		<p>Lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		
					    	</div>
					    </li>
					    <li>
					    	<div class="image">
					    		<img src="mod/nebulosa/css/images/iphone.png" alt="" />
					    	</div>
					    	<div class="info">
					    		<h2>slide 3</h2>
					    		<p><a href="#">Lorem ipsum dolor sit amet</a>, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		<p>Lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		
					    	</div>
					    </li>
					    <li>
					    	<div class="image">
					    		<img src="mod/nebulosa/css/images/iphone.png" alt="" />
					    	</div>
					    	<div class="info">
					    		<h2>slide 4</h2>
					    		<p><a href="#">Lorem ipsum dolor sit amet</a>, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		<p>Lorem ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum ipsum dolor sit amet, tconsectetur adipiscing elit.  Website css templates Nunc ornare consequat tortor dolor ispum. </p>
					    		
					    	</div>
					    </li>
					</ul>
				</div>
			</div>
		</div>
		<div id="content">
			<div class="shell">
				<div class="triple">
					<ul>
					    <li>
					    	<h3>Left Optional Column</h3>
							<ul>
							    Example Content 1
							</ul>
					    	
					    </li>
					    <li>
					    	<h3>Center Optional Column</h3>
							<ul>
							    Example Content 2
							</ul>
					    </li>
					    <li class="last">
					    	<h3>Right Optional Column</h3>
					    	<ul>
							    Example Content 3
							</ul>
					    </li>
					    
					<div class="cl">&nbsp;</div>
				</div>
			</div>
		</div>
		<div id="footer">
			<div class="shell">
				<div class="social">
					<a href="#"><img src="mod/nebulosa/css/images/soc1.gif" alt="" /></a>
					<a href="#"><img src="mod/nebulosa/css/images/soc2.gif" alt="" /></a>
					<a href="#"><img src="mod/nebulosa/css/images/soc3.gif" alt="" /></a>
					<a href="#"><img src="mod/nebulosa/css/images/soc4.gif" alt="" /></a>
				</div>
				<p class="ftr-nav"><a href='<?php echo $vars['url']; ?>pg/expages/read/About/'>About</a>  |  <a href="<?php echo $vars['url']; ?>pg/expages/read/Terms/">Terms</a>  |  <a href="<?php echo $vars['url']; ?>pg/expages/read/Privacy/">Privacy</a>  |</a></p>
				<p class="copy">Copyright 2010 | Sitename. Re-Designed by <a href="http://www.milocker.com/socialweb">SocialWeb</a></p>
			</div>
			

		</div>
	</body>
</html>

