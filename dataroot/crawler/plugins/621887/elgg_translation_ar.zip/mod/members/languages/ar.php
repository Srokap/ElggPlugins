<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'members:members'  =>  "أعضاء الموقع" , 
	 'members:online'  =>  "الأعضاء الفعّالين الأن" , 
	 'members:active'  =>  "أعضاء الموقع" , 
	 'members:searchtag'  =>  "البحث عن عضو بالأشارات" , 
	 'members:searchname'  =>  "البحث عن عضو بالإسم" , 
	 'members:label:newest'  =>  "الأحدث" , 
	 'members:label:popular'  =>  "الأكثر شهرة" , 
	 'members:label:active'  =>  "الأنشط" , 
	 'members:search:name'  =>  "أسماء الأعضاء" , 
	 'members:search:tags'  =>  "الإشارات"
); 

add_translation('ar', $arabic); 

?>