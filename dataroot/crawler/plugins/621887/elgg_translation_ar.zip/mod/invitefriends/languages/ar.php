<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'friends:invite'  =>  "إدعو أصدقائك" , 
	 'invitefriends:introduction'  =>  "لتدعو اصدقائك لينضمو إليك بمجتمع بناة , إكنب بريدهم الإلكترونى هنا (بريد إلكترونى واحد لكل سطر):" , 
	 'invitefriends:message'  =>  "إدخل الرسالة التى تريد أن يتلقوها مع دعوتك:" , 
	 'invitefriends:subject'  =>  "دعوة للإنضمام إلى %s" , 
	 'invitefriends:success'  =>  "لقد تمت دعوت أصدقائك." , 
	 'invitefriends:failure'  =>  "لم يتم التمكن من إرسال دعوة لإصدقائك." , 
	 'invitefriends:message:default'  =>  "
مرحباً,

أريد أن أدعوكم للإنضمام لهذا المجتمع الذى إنضممت إليه هنا فى %s." , 
	 'invitefriends:email'  =>  "
لقد تمت دعوتك للإنضمام إلى %s بواسطة %s. و الذى أرفق لك الرسالة التالية:

%s

للإنضمام, إضغط على الرابط التالى:

	%s

سيتم إضافته أتوماتيكاً إلى لائحة أصدقائك فى حال إنضمامك." , 
	 'invitefriends:email_error'  =>  "تم إرسال الدعوات , ولكن هذا العنوان غير صحيح : %s"
); 

add_translation('ar', $arabic); 

?>