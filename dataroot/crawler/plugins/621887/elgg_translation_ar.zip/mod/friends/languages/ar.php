<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'friends:widget:description'  =>  "يتم عرض بعضاً من أصدقائك." , 
	 'friends:num_display'  =>  "عدد الأصدقاء الذى سيتم عرضه" , 
	 'friends:icon_size'  =>  "حجم الصورة" , 
	 'friends:tiny'  =>  "صغيرة" , 
	 'friends:small'  =>  "متوسطة"
); 

add_translation('ar', $arabic); 

?>