<?php

	$arabic = array(
	
		/**
		 * Menu items and titles
		 */
	
			'expages' => "صفحات خارجية",
			'expages:frontpage' => "الصفحو الأولى",
			'expages:about' => "عنـّـا",
			'expages:terms' => "شروط الإستخدام",
			'expages:privacy' => "الخصوصية",
			'expages:analytics' => "التحليلات",
			'expages:contact' => "إتصل بنا",
			'expages:nopreview' => "لا توجد مادة للعرض بعد",
			'expages:preview' => "عرض مسبق",
			'expages:notset' => "لم يتم إعداد هذه الصفحة بعد.",
			'expages:lefthand' => "The lefthand information pane",
			'expages:righthand' => "The righthand information pane",
			'expages:addcontent' => "You can add content here via your admin tools. Look for the external pages link under admin.",
			'item:object:front' => 'عناصر الصفحة الأولى',
	
		/**
		 * Status messages
		 */
	
			'expages:posted' => "Your page post was successfully posted.",
			'expages:deleted' => "Your page post was successfully deleted.",
	
		/**
		 * Error messages
		 */
	
			'expages:deleteerror' => "There was a problem deleting the old page",
			'expages:error' => "There has been an error, please try again and if the problem persists, contact the administrator",
	
	);
					
	add_translation("ar",$arabic);

?>