<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'subscribe:owner_block_menu'  =>  "إشترك بتنبيهات هذا العضو" , 
	 'subscribe:owner_block_menu:unsubscribe'  =>  "إلغاء الإشتراك" , 
	 'subscribe:owner_block_menu:group'  =>  "إشترك بتنبيهات هذه المجموعة" , 
	 'subscribe:owner_block_menu:unsubscribe:group'  =>  "إلغاء الإشتراك" , 
	 'subscribe:notifications:single:subscriptions:description'  =>  "إذا قمت بالإشتراك بالتنبيهات الخاصة بــ %s, فسيتم تنبيهك كل مرة يقوم فيها بنشر محتويات جديدة. إختار بأى طريقة تحب أن يتم تبيهك:" , 
	 'subscribe:notifications:single:subscriptions:description:group'  =>  "إذا قمت بالإشتراك بالتنبيهات الخاصة بــمجموعة %s, فسيتم تنبيهك كل مرة يتم فيها نشر محتويات جديدة بالمجموعة. إختار بأى طريقة تحب أن يتم تبيهك:" , 
	 'subscribe:subscribers:widget:title'  =>  "المشتركون بالتنبيهات" , 
	 'subscribe:num_display'  =>  "العدد الذى سيتم عرضه" , 
	 'subscribe:icon_size'  =>  "حجم الأيقونة" , 
	 'subscribe:subscribed:widget:title'  =>  "قام بالإشتراك فى" , 
	 'subscribe:subscribers:widget:description'  =>  "أعرض الأعضاء الذين قاموا بالإشتراك بتنبيهات عن محتوياتك" , 
	 'subscribe:subscribed:widget:description'  =>  "أعرض الأعضاء الذين قمت بالإشتراك بتنبيهات عنهم" , 
	 'subscribe:notify:subject'  =>  "%s طلب تنبيهه عند نشرك محتويات جديدة" , 
	 'subscribe:notify:message'  =>  "%s قام بالإشتراك بالتنبيهات الخاصة بك. سيتم تنبيهه عند نشرك أى محتوبات جديدة بحسابك بمجتمع بناة.

يمكنك مشاهدة ملفه الشخصى عبر هذا الرابط :

%s"
); 

add_translation('ar', $arabic); 

?>