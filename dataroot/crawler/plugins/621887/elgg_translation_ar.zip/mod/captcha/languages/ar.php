<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'captcha:captchafail'  =>  "عذراً , الكتابة التى أدخلتها تختلف عن الموجودة بالصورة" , 
	 'captcha:entercaptcha'  =>  "إدخل الكتابة الموجودة بالصورة"
); 

add_translation('ar', $arabic); 

?>