<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'search:no_results'  =>  "لا توجد نتائج" , 
	 'search:matched'  =>  "متطابق :" , 
	 'search:results'  =>  "نتائج البحث عن :  %s" , 
	 'search:no_query'  =>  "من فضلك إدخل كلمة المراد الإستعلام عنها :" , 
	 'search:search_error'  =>  "خطأ" , 
	 'search:more'  =>  "+%s المزيد %s" , 
	 'search_types:tags'  =>  "الإشارات" , 
	 'search_types:comments'  =>  "التعليقات" , 
	 'search:comment_on'  =>  "تعليق على  \"%s\"" , 
	 'search:unavailable_entity'  =>  "عنصر غير متوفر" , 
	 'search:enter_term'  =>  "أدخل كلمات البحث:" , 
	 'search:comment_by'  =>  "بواسطة"
); 

add_translation('ar', $arabic); 

?>