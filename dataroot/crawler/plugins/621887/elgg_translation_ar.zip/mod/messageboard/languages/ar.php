<?php

	$arabic = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "لوحة الرسائل",
			'messageboard:messageboard' => "لوحة الرسائل",
			'messageboard:viewall' => "مشاهدة الكل",
			'messageboard:postit' => "إنشرها",
			'messageboard:history' => "الأرشيف",
			'messageboard:none' => "لا يوجد رسائل بهذه اللوحة بعد",
			'messageboard:num_display' => "عدد الرسائل التى سيتم عرضها.",
			'messageboard:desc' => "لوحة الرسائل التى يمكن أن تضعها بملفك الشخصى ليتمكن باقى المستخدمين بالكتابة لك بها.",
			'messageboard:user' => "لوحة رسائل %s",
			'messageboard:history' => "رسائل سابقة",
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s كتب تعليق جديد بلوحة الرسائل الخاصة به.",
	        'messageboard:river:create' => "%s أضاف مربع لوحة الرسائل.",
	        'messageboard:river:update' => "%s قام بتحديث مربع الرسائل الخاص به.",
			'messageboard:river:added' => "%s قام بالكتابة ل",
		    'messageboard:river:messageboard' => "على لوحة رسائله",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "لقد قمت بالكتابة بلوحة الرسائل بنجاح.",
			'messageboard:deleted' => "لقد قمت بحذف الرسالة بنجاح.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'لديك تعليق جديد بلوحة الرسائل!',
			'messageboard:email:body' => "لديك رسالة جديدة بلوحة الرسائل قام بكتابته %s. و نصها كما يلى:

			
%s


لمشاهدة التعليقات بلوحة الرسائل الخاصة بك, إضغط هنا:

	%s

لمشاهدة الملف الشخصى لــ %s, إضغط هنا:

	%s

هذه الرسالة أتوماتيكية لا يمكنك الرد عليها.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "عفواً: يجب عليك كتابة شئ ما بنص الرسالة قبل أن نتمكن من حفظها.",
			'messageboard:notfound' => "عفواً: لم نتمكن من العثور على العنصر المحدد",
			'messageboard:notdeleted' => "عفواً: لم نتمكن من حذف هذه الرسالة",
			'messageboard:somethingwentwrong' => "هناك خطب ما حد عند محاولة إرسال رسالتك, تأكد من إنك قد كتبت رسالة بالفعل.",	     
			'messageboard:failure' => "حدث خطأ غير متوقع أثناء عملية حفظ رسالتك, الرجاء المحاولة مرة أخرى.",
			
	);
					
	add_translation("ar",$arabic);

?>