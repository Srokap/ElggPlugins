<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'river_comments:comment'  =>  "تعليق" , 
	 'river_comments:writeacomment'  =>  "أكتب تعليق" , 
	 'river_comments:viewallcomments'  =>  "مشاهدة كل تعليقات %s" , 
	 'river_comments:allcommentsof'  =>  "كل التعليقات من  \"%s\"" , 
	 'river_comments:notloginerror'  =>  "أنت غير مسجل للدخول, رجاءاً قم بإعادة تحميل الصفحة."
); 

add_translation('ar', $arabic); 

?>