<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'headermenu:members'  =>  "الأعضاء" , 
	 'headermenu:photos'  =>  "الصور" , 
	 'headermenu:groups'  =>  "المجموعات" , 
	 'headermenu:videos'  =>  "الفيديوهات" , 
	 'headermenu:current'  =>  "لديه الأن:" , 
	 'headermenu:andmore'  =>  "و المزيد ..." , 
	 'headermenu:home'  =>  "الرئيسية" , 
	 'headermenu:blogs'  =>  "المدونات" , 
	 'headermenu:ads'  =>  "السوق" , 
	 'headermenu:discussions'  =>  "المناقشات" , 
	 'headermenu:events'  =>  "أجندة الأحداث" , 
	 'headermenu:wire'  =>  "الأفكار" , 
	 'headermenu:public'  =>  "متوفر للعامة." , 
	 'headermenu:register'  =>  "سجل حسابك الأن" , 
	 'headermenu:access'  =>  "لمشاهدة المزيد." , 
	 'headermenu:homep'  =>  "الصفحة الرئيسية" , 
	 'headermenu:about'  =>  "عن الموقع" , 
	 'headermenu:allblogs'  =>  "كل المدونات" , 
	 'headermenu:myblogs'  =>  "مدونتى" , 
	 'headermenu:fblogs'  =>  "مدونات الأصدقاء" , 
	 'headermenu:addblogs'  =>  "أضف مقالة للمدونة" , 
	 'headermenu:terms'  =>  "شروط الإستخدام" , 
	 'headermenu:privacy'  =>  "الخصوصية" , 
	 'headermenu:invite'  =>  "إدعوا أصدقائك" , 
	 'headermenu:dashboard'  =>  "أنشطة الموقع" , 
	 'headermenu:settings'  =>  "الإعدادات" , 
	 'headermenu:mysettings'  =>  "تغيير إسمك و كلمة المرور" , 
	 'headermenu:editicon'  =>  "تغيير صورتك" , 
	 'headermenu:myprofile'  =>  "مشاهدة صفحتك الشخصية" , 
	 'headermenu:editprofile'  =>  "تعديل صفحتك الشخصية" , 
	 'headermenu:notifications'  =>  "التنبيهات" , 
	 'headermenu:groupnotifications'  =>  "تنبيهات المجموعات" , 
	 'headermenu:logedmembers'  =>  "الموجود الأن" , 
	 'headermenu:friends'  =>  "أصدقائى" , 
	 'headermenu:allphotos'  =>  "كل الصور" , 
	 'headermenu:myphotos'  =>  "صورى" , 
	 'headermenu:newphotos'  =>  "الأحدث" , 
	 'headermenu:mostviewedphotos'  =>  "الأكثر مشاهدة" , 
	 'headermenu:createalbum'  =>  "إنشئ ألبوم صور جديد" , 
	 'headermenu:allgroups'  =>  "كل المجموعات" , 
	 'headermenu:mygroups'  =>  "مجموعاتى" , 
	 'headermenu:popgroups'  =>  "أشهر المجموعات" , 
	 'headermenu:allvideos'  =>  "كل الفيديوهات" , 
	 'headermenu:myvideos'  =>  "فيديوهاتى" , 
	 'headermenu:friendsvideos'  =>  "فيديوهات الأصدقاء" , 
	 'headermenu:addvideos'  =>  "أضف فيديو" , 
	 'headermenu:bookmarks'  =>  "التفضيلات" , 
	 'headermenu:latestdiscussion'  =>  "أحدث المناقشات" , 
	 'headermenu:newmembers'  =>  "أحدث الأعضاء"
); 

add_translation('ar', $arabic); 

?>