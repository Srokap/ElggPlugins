<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'status'  =>  "الحالة" , 
	 'status:user'  =>  "حالة %s  " , 
	 'status:current'  =>  "الحالة الحالية" , 
	 'status:desc'  =>  "مربع الحالة يعرض حالتك الأن" , 
	 'status:posttitle'  =>  "حالة %s: %s" , 
	 'status:everyone'  =>  "كل الحالات بالموقع" , 
	 'status:strapline'  =>  "%s" , 
	 'status:addstatus'  =>  "إكتب حالتك" , 
	 'status:messages'  =>  "نص الحالة" , 
	 'status:text'  =>  "الحالة:" , 
	 'status:set'  =>  "نشرت" , 
	 'status:clear'  =>  "إلغاء الحالة" , 
	 'status:delete'  =>  "حذف الحالة" , 
	 'status:nostatus'  =>  "لم يتم تحديد حالة بعد" , 
	 'status:viewhistory'  =>  "مشاهدة السابق" , 
	 'item:object:status'  =>  "نص الحالة" , 
	 'status:river:created'  =>  "%s قام بتحديث" , 
	 'status:river:create'  =>  "حالته" , 
	 'status:posted'  =>  "تم نشر حالتك بنجاح" , 
	 'status:deleted'  =>  "تم حذف حالتك بنجاح" , 
	 'status:blank'  =>  "عفواً . عليك قبلاً كتابة حالتك قبل أن ننشرها" , 
	 'status:notfound'  =>  "عفواً , لم نستطع العثور على نص الحالة التى حددها" , 
	 'status:notdeleted'  =>  "عفواً , لم نستطع حذف هذه الرسالة" , 
	 'status:notsaved'  =>  "يوجد مشكلة بالحفظ , حاول مرة أخرى ." , 
	 'status:problem'  =>  "توجد مشكلة , يبدو أنه لا يمكنك تعديل نص الحالة هذه."
); 

add_translation('ar', $arabic); 

?>