<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'custom:bookmarks'  =>  "أحدث الإعلانات" , 
	 'custom:groups'  =>  "أحدث المجموعات" , 
	 'custom:files'  =>  "أحدث الملفات" , 
	 'custom:blogs'  =>  "أحدث المدونات" , 
	 'custom:members'  =>  "أحدث الأعضاء" , 
	 'custom:nofiles'  =>  "لا يوجد ملفات بعد" , 
	 'custom:nogroups'  =>  "لا توجد مجموعات بعد" , 
	 'custom:artfolio'  =>  "أحدث سابقات الأعمال" , 
	 'custom:noartfolio'  =>  "لا يوجد ملفات بعد"
); 

add_translation('ar', $arabic); 

?>