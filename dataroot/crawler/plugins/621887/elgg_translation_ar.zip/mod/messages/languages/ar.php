<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'messages'  =>  "الرسائل" , 
	 'messages:back'  =>  "العودة للرسائل" , 
	 'messages:user'  =>  "صندوق وارداتك" , 
	 'messages:sentMessages'  =>  "الرسائل المرسلة" , 
	 'messages:posttitle'  =>  "رسائل %s: %s" , 
	 'messages:inbox'  =>  "الواردات" , 
	 'messages:send'  =>  "إرسل رسالة" , 
	 'messages:sent'  =>  "الرسائل المرسلة" , 
	 'messages:message'  =>  "الرسالة" , 
	 'messages:title'  =>  "العنوان" , 
	 'messages:to'  =>  "إلى" , 
	 'messages:from'  =>  "من" , 
	 'messages:fly'  =>  "قم بإرسالها" , 
	 'messages:replying'  =>  "رسالة رداً على" , 
	 'messages:sendmessage'  =>  "أرسل رسالة" , 
	 'messages:compose'  =>  "إرسل رسالة" , 
	 'messages:sentmessages'  =>  "الرسائل المرسلة" , 
	 'messages:recent'  =>  "أحدث الرسائل" , 
	 'messages:original'  =>  "الرسالة الأصلية" , 
	 'messages:yours'  =>  "رسالتك" , 
	 'messages:answer'  =>  "رد" , 
	 'item:object:messages'  =>  "الرسائل" , 
	 'messages:posted'  =>  "تم إرسال رسالتك بنجاح" , 
	 'messages:deleted'  =>  "تم حذف رسالتك بنجاح." , 
	 'messages:email:subject'  =>  "لديك رسالة جديدة!" , 
	 'messages:email:body'  =>  "لديك رسالة خاصة جديدة أرسلها لك %s. و نصها كما يلى:

			
%s


لمشاهدة رسائلك , إضغط هنا:

	%s

لإرسال رسالة إلى %s, إضغط هنا:

	%s

هذه الرسالة أتوماتيكية و لا يمكنك الرد عليها" , 
	 'messages:blank'  =>  "عفواً: يجب عليك كتابة شئ ما بنص الرسالة قبل أن نتمكن من حفظها." , 
	 'messages:notfound'  =>  "عفواً: لم يتم التمكن من العثور على الرسالة المحددة." , 
	 'messages:notdeleted'  =>  "عفواً: لم نتمكن من حذف هذه الرسالة" , 
	 'messages:nopermission'  =>  "ليس لديك الصلاحيات لحذف هذه الرسالة." , 
	 'messages:nomessages'  =>  "لا يوجد رسائل لمشاهدتها." , 
	 'messages:user:nonexist'  =>  "لم يتم التمكن من العثور على المرسل إليه فى قاعدة بيانات المستخدمين." , 
	 'messages:toggle'  =>  "تغيير الكل" , 
	 'messages:markread'  =>  "علامة قراءة" , 
	 'messages:new'  =>  "رسالة جديدة" , 
	 'notification:method:site'  =>  "موقع" , 
	 'messages:error'  =>  "توجد مشكلة فى حفظ رسالتك , رجاءاً حاول ثانيةً" , 
	 'messages:markedread'  =>  "تم وضع علامة قراءة على رسالتك بنجاح"
); 

add_translation('ar', $arabic); 

?>