<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'file:mostDownloads'  =>  "الملفات الأكثر تحميلاً"
); 

add_translation('ar', $arabic); 

?>