<?php

	$arabic = array(
	
		'friends:all' => 'كل الأصدقاء',
	
		'notifications:subscriptions:personal:description' => 'إرسال تبنيهات لبريدك عندما يقوم أحد بعمل نشاط ما على نشاطاتك.',
		'notifications:subscriptions:personal:title' => 'التنبيهات الشخصية',
	
		'notifications:subscriptions:collections:title' => 'التنقل بين مجموعات الأصدقاء',
		'notifications:subscriptions:collections:description' => 'للتنقل بين الإعدادات لمجموعات أصدقائك, إستخدم الأيقونة التالية. هذا الإجراء سيؤثر على إعدادات التبيهات الرئيسية بأدنى هذه الصفحة.. ',
		'notifications:subscriptions:collections:edit' => 'لتعديل مجموعات أصدقائك إضغط هنا.',
	
		'notifications:subscriptions:changesettings' => 'التبيهات',
		'notifications:subscriptions:changesettings:groups' => 'تنبيهات المجموعات',
		'notification:method:email' => 'البريد الإلكترونى',	
	
		'notifications:subscriptions:title' => 'التنبيهات للمستخدم الواحد',
		'notifications:subscriptions:description' => 'لإستقبال نتبيهات عندما يقوم أصدقائك بإضافة محتويات, إختارهم من الأسفل ثم إختار طريقة التنبيه التى تريدها لهم.',
	
		'notifications:subscriptions:groups:description' => 'لإستقبال تنبيهات عند إضافة محتويات بمجموعة أنت عضو بها, إختارها بالأسفل ثم إختار طريقة التنبيه التى تريدها لها.',
	
		'notifications:subscriptions:success' => 'تم حفظ إعدادات التبيهات الخاصة بك بنجاح',
	
	);
					
	add_translation("ar",$arabic);

?>