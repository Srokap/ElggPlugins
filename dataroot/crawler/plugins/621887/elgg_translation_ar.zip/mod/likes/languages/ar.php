<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'like'  =>  "أعجبنى" , 
	 'unlike'  =>  "لا يعجبنى" , 
	 'like:youlikethis'  =>  "أنت معجب بهذا." , 
	 'like:otherlikesthis'  =>  "%s معجب بهذا." , 
	 'like:otherandyoulikethis'  =>  "أنت و  %s معجبون بهذا." , 
	 'like:others2likethis'  =>  "%s و  %s معجبون بهذا." , 
	 'like:others'  =>  "%s أخرون" , 
	 'like:lotofpeoplelikethis'  =>  "%s شخص معجب بهذا." , 
	 'like:youandalotofpeoplelikethis'  =>  "أنت و  %s معجبون بهذا" , 
	 'dislike'  =>  "غير معجب" , 
	 'undislike'  =>  "إلغاء عدم الإعجاب" , 
	 'dislike:youdislikethis'  =>  "أنت غير معجب بهذا." , 
	 'dislike:otherdislikesthis'  =>  "%s غير معجب بهذا." , 
	 'dislike:otherandyoudislikethis'  =>  "أنت و %s غير معجبون بهذا." , 
	 'dislike:others2dislikethis'  =>  "%s و %s غير معجبون بهذا." , 
	 'dislike:others'  =>  "%s أخرون" , 
	 'dislike:lotofpeopledislikethis'  =>  "%s شخص غير معجبون بهذا." , 
	 'dislike:youandalotofpeopledislikethis'  =>  "أنت و %s غير معجبون بهذا." , 
	 'dislike:posted'  =>  "تم نشر \"عدم إعجابك \" بنجاح" , 
	 'dislike:failure'  =>  "خطأ غير متوقع حدث أثناء نشر \"عدم إعجابك\". فضلاً حاول ثانياً." , 
	 'dislike:deleted'  =>  "تم حذف \"عدم إعجابك\" بنجاح." , 
	 'dislike:notdeleted'  =>  "عفواً, لم نتمكن من حذف عدم إعجابك." , 
	 'like:posted'  =>  "تم نشر \"إعجابك\" بنجاح." , 
	 'like:failure'  =>  "خطأ غير متوقع حدث أثناء نشر \"إعجابك\". فضلاً حاول ثانياً." , 
	 'like:deleted'  =>  "تم حذف \"إعجابك\" بنجاح." , 
	 'like:notdeleted'  =>  "عفواً, لم نتمكن من حذف إعجابك."
); 

add_translation('ar', $arabic); 

?>