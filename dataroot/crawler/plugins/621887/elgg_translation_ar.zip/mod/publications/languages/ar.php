<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'publication:keywords'  =>  "الكلمات المفتاحبة" , 
	 'publication:exauthors'  =>  "مؤلفون أخرون ( غير مسجلين )" , 
	 'publication:authors'  =>  "المؤلفون" , 
	 'publication:source'  =>  "المصدر (مثال: مجلة ، أعمال المؤتمر ، كتاب ، أطروحة)" , 
	 'publication:attachment'  =>  "إرفاق ملف" , 
	 'publication:attachment:instruction'  =>  "إضغط على أى ملف لإرفاقه مع عملك المنشور" , 
	 'publication:file'  =>  "الملفات" , 
	 'publication:upload'  =>  "رفع الملفات" , 
	 'publication:attachment:title'  =>  "أرفاق ملف" , 
	 'publication:widget:num_display'  =>  "عدد المنشورات التى ستعرض" , 
	 'publication:source:ref'  =>  "المصدر" , 
	 'publication:inviteinfomsg'  =>  "%s ليس عضو مسجلاُ.
إرسل دعوة لــ %s لينضم لمجتمع بناة." , 
	 'publication:invitemsg'  =>  "السلام عليكم  %s,

لقد قمت بإضافة كمؤلف لعمل منشور بعنوان : '%s' بمجتمع بــــُنــاة. و أنا أدعوك للإنضمام لمجتمع بناة لتتواصل مع القراء.

%s
" , 
	 'publication:additionalmsg'  =>  "\"GeoChronos is an on-line environment for members of the Earth Observation Science community that is aimed at enabling scientists to share data and scientific applications and to collaborate more effectively" , 
	 'publication:volume'  =>  "الجزء" , 
	 'publication:issue'  =>  "العدد" , 
	 'publication:pages'  =>  "الصفحات" , 
	 'publication:year'  =>  "السنة" , 
	 'publication'  =>  "العمل المنشور" , 
	 'publications'  =>  "المنشورات" , 
	 'publication:your'  =>  "كتاباتك و منشوراتك" , 
	 'publication:authored:your'  =>  "الأعمال التى ألفتها" , 
	 'publication:everyone'  =>  "كل منشورات الموقع" , 
	 'publication:new'  =>  "عمل جديد" , 
	 'publication:newpost'  =>  "المنشورات العلمية الجديدة بمجتمع بناة" , 
	 'publication:via'  =>  "أضاف منشور جديد بعنوان " , 
	 'publication:read'  =>  "أفرأ المنشور" , 
	 'publication:add'  =>  "أضف عمل" , 
	 'publication:edit'  =>  "تعديل المنشور" , 
	 'publication:abstract'  =>  "الملخص" , 
	 'publication:strapline'  =>  "%s" , 
	 'item:object:publication'  =>  "الكتابات والمنشورات" , 
	 'publication:never'  =>  "أبداُ" , 
	 'publication:draft:save'  =>  "حفظ أولى" , 
	 'publication:draft:saved'  =>  "أخر حفظ أولى" , 
	 'publication:comments:allow'  =>  "السماح بالتعليقات" , 
	 'publication:enablepublication'  =>  "تفعيل منشورات المجموعة" , 
	 'publication:group'  =>  "كتابات ومنشورات المجموعة" , 
	 'publication:search'  =>  "البحث بالمشورات" , 
	 'publication:river:created'  =>  "%s  كتب" , 
	 'publication:river:updated'  =>  "%s قام بتحديث" , 
	 'publication:river:posted'  =>  "%s نشر" , 
	 'publications:widget'  =>  "المنشورات" , 
	 'publications:widget:description'  =>  "أضف قائمة بالمنشورات بصفحتك الشخصية" , 
	 'publication:river:create'  =>  "منشور علمى جديد بعنوان" , 
	 'publication:river:update'  =>  "منشور علمى بعنوان" , 
	 'publication:river:annotate'  =>  "تعليقاُ على هذا المنشور" , 
	 'publication:posted'  =>  "تم نشر عملك بنجاح"
); 

add_translation('ar', $arabic); 

?>