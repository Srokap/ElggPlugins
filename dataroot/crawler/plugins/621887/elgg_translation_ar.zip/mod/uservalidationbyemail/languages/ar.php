<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'email:validate:subject'  =>  "%s فضلاً قم بتأكيد بريدك الإلكترونى!" , 
	 'email:validate:body'  =>  "مرحباً %s,

قبل أن تتمكن من إستخدام حسابك على %s, يجب أن تقوم بتأكيد أنك المالك الحقيقى لهذا البريد الإلكترونى

رجاءاً قم بتأكيد صحة بريدك الإلكترونى و ذلك بالضغط على الرابط التالى:

%s

إذا لم تتمكن من الضغط على الرابط السابق , فضلاً قم بنسخ الرابط ولصقه فى متصفحك مباشرة.

%s
%s" , 
	 'email:validate:success:subject'  =>  "تم التأكد من البريد الإلكترونى %s!" , 
	 'email:validate:success:body'  =>  "مرحباً %s,
			
تهانينا, لقد قمت بتأكيد صحة بريدك الإلكترونى بنجاح." , 
	 'email:confirm:success'  =>  "لقد قمت بتأكيد صحة بريدك الإلكترونى!" , 
	 'email:confirm:fail'  =>  "لم يتم التعرف على بريدك الإلكترونى..." , 
	 'uservalidationbyemail:registerok'  =>  "لتفعيل حسابكم, رجاءاً قم بتأكيد صحة بريدك الإلكترونى و ذلك بالضغط على الرابط الذى قمنا بإرساله إليك." , 
	 'uservalidationbyemail:admin:user_created'  =>  "قام بالتسجيل "
); 

add_translation('ar', $arabic); 

?>