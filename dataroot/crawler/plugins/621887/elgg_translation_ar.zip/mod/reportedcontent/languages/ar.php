<?php
	/**
	 * Elgg reported content plugin language pack
	 * 
	 * @package ElggReportedContent
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$arabic = array(
	
		/**
		 * Menu items and titles
		 */
	
			'item:object:reported_content' => 'المواد المبلغ عنها.',
			'reportedcontent' => 'المحتويات المبلغ عنها',
			'reportedcontent:this' => 'قم بالإبلاغ على هذا',
			'reportedcontent:none' => 'لا يوجد محتويات تم الإبلاغ عنها.',
			'reportedcontent:report' => 'إبلاغ مشرفى الموقع',
			'reportedcontent:title' => 'عنوان الصفحة',
			'reportedcontent:deleted' => 'تم حذف المحتوى المبلغ عنه.',
			'reportedcontent:notdeleted' => 'لم نتمكن من حذف هذا البلاغ',
			'reportedcontent:delete' => 'إحذفها.',
			'reportedcontent:areyousure' => 'هل أنت متأكد من حذفها؟',
			'reportedcontent:archive' => 'ضعها بالأرشيف',
			'reportedcontent:archived' => 'تم وضع البلاغ بالأرشيف.',
			'reportedcontent:visit' => 'زيارة العنصر المبلغ عنه.',
			'reportedcontent:by' => 'قام بالبلاغ',
			'reportedcontent:objecttitle' => 'عنوان العنصر',
			'reportedcontent:objecturl' => 'رابط العنصر',
			'reportedcontent:reason' => 'سبب البلاغ',
			'reportedcontent:description' => 'لماذا تريد الإبلاغ عن هذا العنصر؟',
			'reportedcontent:address' => 'مكان العنصر',
			'reportedcontent:success' => 'تم إرسال بلاغك لمدير الموقع.',
			'reportedcontent:failing' => 'لم يتم التمكن من إرسال بلاغك.',
			'reportedcontent:report' => 'قم بالإبلاغ عن هذا.', 
	
			'reportedcontent:failed' => 'عفواً: محاولتك للإبلاغ عن هذا المحتوى قد فشلت.',
	);
					
	add_translation("ar",$arabic);
?>