<?php

	$arabic = array(

		'mine' => 'خاص بى',
		'filter' => 'فلتر',
		'riverdashboard:useasdashboard' => "إستبدال الصفحة الرئيسية للعضو بموجز النشاطات هذا ؟",
		'activity' => 'الأنشطة',
	
	    /**
	     * Site messages
           **/

		'sitemessages:announcements' => "تصريحات المجتمع",
		'sitemessages:posted' => "نشر",
		'sitemessages:river:created' => "مشرف الموقع, %s,",
		'sitemessages:river:create' => "نشر رسالة لكل أعضاء الموقع",
		'sitemessages:add' => "أضف رسالة لكل أعضاء الموقع عبر صفحة موجز الأنشطة.",
		'sitemessage:deleted' => "تم حذف التصريح",
		
		'river:widget:noactivity' => 'لم نتمكن من العثور على أى نشاط.',
		'river:widget:title' => "النشاط",
		'river:widget:description' => "تعرض أحدث أنشطتك بالموقع.",
		'river:widget:title:friends' => "أنشطة الأصدقاء",
		'river:widget:description:friends' => "عرض ما يفعله أصدقائك بالموقع.",
		'river:widgets:friends' => "الأصدقاء",
		'river:widgets:mine' => "خاص بى",
		'river:widget:label:displaynum' => "عدد المدخلات التى ستعرض:",
		'river:widget:type' => "أى نشاط تريده أن يعرض؟? الذى يعرض أنشطتك أم الذى يعرض أنشطة أصدقائك?",
		'item:object:sitemessage' => "رسائل الموقع",
	);
					
	add_translation("ar",$arabic);

?>