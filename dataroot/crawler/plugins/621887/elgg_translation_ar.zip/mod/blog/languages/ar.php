<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'blog'  =>  "المدونة" , 
	 'blogs'  =>  "المدونات" , 
	 'blog:user'  =>  "مدونة %s" , 
	 'blog:user:friends'  =>  "مدونات أصدقاء %s" , 
	 'blog:your'  =>  "مدونتك" , 
	 'blog:posttitle'  =>  "مدونة %s: %s" , 
	 'blog:friends'  =>  "مدونات الأصدقاء" , 
	 'blog:yourfriends'  =>  "أحدث مدونات أصدقائك" , 
	 'blog:everyone'  =>  "جميع مدونات الموقع" , 
	 'blog:newpost'  =>  "كتابة مدونة جديدة" , 
	 'blog:via'  =>  "عبر مدونة" , 
	 'blog:read'  =>  "إقرأ المدونة" , 
	 'blog:addpost'  =>  "أكتب مقالة بالمدونة" , 
	 'blog:editpost'  =>  "تعديل مقالة بالمدونة" , 
	 'blog:text'  =>  "نص المدونة" , 
	 'blog:strapline'  =>  "%s" , 
	 'item:object:blog'  =>  "مقالات المدونة" , 
	 'blog:never'  =>  "أبداً" , 
	 'blog:preview'  =>  "معاينة" , 
	 'blog:draft:save'  =>  "الحفظ كمرحلة أولية" , 
	 'blog:draft:saved'  =>  "أخر مرحلة أولية تم حفظها." , 
	 'blog:comments:allow'  =>  "السماح بالتعليقات" , 
	 'blog:preview:description'  =>  "هذه معاينة لم يتم حفظها من كتاباتك بالمدونة." , 
	 'blog:preview:description:link'  =>  "لمتابعة التحرير أو لحفظ كتاباتك, إضغط هنا." , 
	 'blog:river:created'  =>  "%s كتب" , 
	 'blog:river:updated'  =>  "%s قام بتحديث" , 
	 'blog:river:posted'  =>  "%s نشر" , 
	 'blog:river:create'  =>  "مقالة جديدة بالمدونة." , 
	 'blog:river:update'  =>  "مقالة بالمدونة." , 
	 'blog:river:annotate:create'  =>  "تعليق على مقالة بمدونة." , 
	 'blog:river:annotate'  =>  "تعليق على هذه الكتابة بالمدونة." , 
	 'blog:posted'  =>  "تم نشر مقالتك بالمدونة بنجاح" , 
	 'blog:deleted'  =>  "تم حذف مقالتك بالمدونة بنجاح" , 
	 'blog:error'  =>  "حدث خطأ ما, رجاءاً حاول مرة أخرى" , 
	 'blog:save:failure'  =>  "لم يتم التمكن من حفظ مقالتك, رجاءاً حاول مرة أخرى" , 
	 'blog:blank'  =>  "عفواً: يجب عليك ملء كلاً من عنوان و نص المقالة قبل أن يتم حفظ المقالة" , 
	 'blog:notfound'  =>  "عفواً: لم نتمكن من العثور على المقالة المحددة." , 
	 'blog:notdeleted'  =>  "عفواً: لم نتمكن من حذف هذه المقالة." , 
	 'blog:enableblog'  =>  "تفعيل مدونة المجموعة" , 
	 'blog:group'  =>  "مدونة المجموعة" , 
	 'groups:enableblog'  =>  "تفعيل مدونة للمجموعة" , 
	 'blog:nogroup'  =>  "هذه المجموعة لا يوجد بها أى كتابة بالمدونة الخاصة بها بعد." , 
	 'blog:more'  =>  "المزيد من التدوينات" , 
	 'blog:read_more'  =>  "إقرأ كامل التدوينة" , 
	 'blog:widget:description'  =>  "هذا المربع يعرض أحدث كتاباتك بالمدونة" , 
	 'blog:moreblogs'  =>  "المزيد من التدوينات" , 
	 'blog:numbertodisplay'  =>  "عدد التدوينات التى سيتم عرضها"
); 

add_translation('ar', $arabic); 

?>