<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'profile_manager:show_full_profile'  =>  "الصفحة الشخصية الكاملة" , 
	 'profile_manager:register:mandatory'  =>  "الخانات التى عليها علامة * ضرورية" , 
	 'profile_manager:register:profile_icon'  =>  "برجاء رفع صورة شخصية" , 
	 'profile_manager:simple_access_control'  =>  "إختار من يستطيع أن يشاهد بيانات صفحتك الشخصية" , 
	 'profile_manager:register_pre_check:missing'  =>  "يجب ملئ الخانة التالية : %s" , 
	 'profile_manager:register_pre_check:profile_icon:error'  =>  "خطأ فى رفع صورتك الشخصية (فى الأغلب بسبب حجم الصورة)" , 
	 'profile_manager:register_pre_check:profile_icon:nosupportedimage'  =>  "الصورة المرفوعة ليست بالإمتداد الصحيح (jpg, gif, png)" , 
	 'profile_manager:categories:list:default'  =>  "أختار نوع حسابك بـ \"بــنـاة\"" , 
	 'profile_manager:members:menu'  =>  "الأعضاء" , 
	 'profile_manager:members:submenu'  =>  "البحث بالأعضاء" , 
	 'profile_manager:members:searchform:title'  =>  "البحث عن الأعضاء" , 
	 'profile_manager:members:searchform:simple:title'  =>  "بحث بسيط" , 
	 'profile_manager:members:searchform:advanced:title'  =>  "بحث متطور" , 
	 'profile_manager:members:searchform:sorting'  =>  "الترتيب" , 
	 'profile_manager:members:searchform:date:from'  =>  "من" , 
	 'profile_manager:members:searchform:date:to'  =>  "إلى" , 
	 'profile_manager:members:searchresults:title'  =>  "نتائج البحث" , 
	 'profile_manager:members:searchresults:query'  =>  "إستعلام" , 
	 'profile_manager:members:searchresults:noresults'  =>  "بحثك لم يتطابق مع أى من الأعضاء" , 
	 'profile_manager:admin:adduser:notify'  =>  "تنبيه العضو" , 
	 'profile_manager:admin:mandatory'  =>  "ضرورى" , 
	 'profile_manager:profile_types:list:title'  =>  "نوع الملف الشخصى" , 
	 'profile_manager:profile:edit:custom_profile_type:label'  =>  "إختار نوع حسابك" , 
	 'profile_manager:profile:edit:custom_profile_type:description'  =>  "وصف نوع الحساب" , 
	 'profile_manager:profile:edit:custom_profile_type:default'  =>  "أختار نوع حسابك بـ \"بــنـاة\"" , 
	 'profile_manager'  =>  "إدارة الملف الشخصى" , 
	 'profile_manager:admin:metadata_name'  =>  "الأسم" , 
	 'profile_manager:admin:metadata_label'  =>  "العنوان" , 
	 'profile_manager:admin:metadata_hint'  =>  "ملحوظة" , 
	 'profile_manager:admin:metadata_description'  =>  "الوصف" , 
	 'profile_manager:actions:reset'  =>  "إفراغ الخانات" , 
	 'profile_manager:categories:list:title'  =>  "التصنيفات"
); 

add_translation('ar', $arabic); 

?>