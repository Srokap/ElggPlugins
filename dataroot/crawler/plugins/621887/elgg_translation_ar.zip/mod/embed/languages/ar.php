<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'media:insert'  =>  "تضمين / رفع الملفات" , 
	 'embed:instructions'  =>  "إضغط على أى ملف لتضمينه ضمن محتواك" , 
	 'embed:media'  =>  "الميديا المضمّنه" , 
	 'upload:media'  =>  "رفع الملف" , 
	 'embed:file:required'  =>  "لا يوجد داعم لرفع للملفات"
); 

add_translation('ar', $arabic); 

?>