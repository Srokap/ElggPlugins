<?php

	$arabic = array(
	
		/**
		 * Manifest
		 */
		
	
		'river:widget:noactivity' => 'لا يوجد أى نشاط بعد',
		'river:widget:title' => "النشاطات",
		'river:widget:description' => "عرض أحدث نشاطاتك.",
		'river:widget:title:friends' => "نشاطات الإصدقاء",
		'river:widget:description:friends' => "عرض ماذا يفعل أصدقائك حالياً.",
	
		'river:widget:label:displaynum' => "عدد النشاطات التى ستعرض:",
	);
					
	add_translation("ar",$arabic);

?>