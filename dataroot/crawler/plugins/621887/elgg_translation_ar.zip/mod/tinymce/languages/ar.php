<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'tinymce:remove'  =>  "أضافة / إزالة أدوات التنسيق"
); 

add_translation('ar', $arabic); 

?>