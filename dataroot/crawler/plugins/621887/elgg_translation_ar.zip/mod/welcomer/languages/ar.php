<?php

	$arabic = array(
	
		'media:insert' => 'Embed / upload media',
	
		'embed:instructions' => 'إختار إى ملف لتضمينه مع محتوى النص.',
	
		'welcomer:message:edit' => 'Edit message for next login',
		'welcomer:welcome:edit' => 'Edit message for first login',
		'welcomer:switcher' => 'Welcomer control page',
		'welcomer:validate:message' => 'Check the message',
		'welcomer:validate:select_check' => "Add a mandatory validation box",
		'welcomer:message:editmessage' => 'Edit the next login message',
		'welcomer:submit' => 'Go',
		'welcomer:welcome:editmessage' => 'Edit the first login message',
		'welcomer:message:switchmessage' => 'Activate / Desactivate login messages',
		'welcomer:message:on' => 'Next login message status is ON',
		'welcomer:message:desactivate' => 'Desactivate',
		'welcomer:message:off' => 'Next login message status is OFF',
		'welcomer:message:activate' => 'Activate',
		'welcomer:welcome:on' => 'First login message status is ON',
		'welcomer:desactivate' => 'Desactivate',
		'welcomer:welcome:off' => 'First login message status is OFF',
		'welcomer:activate' => 'Activate',
		'welcomer:message:check_message' => 'شكراً , لقد قرأت الرسالة',
		'welcomer:validate:message:ok' => 'The new next login message has been activated',
		'welcomer:validate:welcome:ok' => 'The new first login message has been activated',
		'welcomer:message:save_ok' => 'The draft message has been saved, you need to activate it',
		'welcomer:welcome:save_ok' => 'The draft message has been saved, you need to activate it',
		'welcomer:message:desactivate_ok' => 'The next login message function has been desactivated',
		'welcomer:message:activate_ok' => 'The next login message function has been activated',
		'welcomer:welcome:desactivate_ok' => 'The first login message function has been desactivated',
		'welcomer:welcome:activate_ok' => 'The first login message function has been activated',
		'welcomer:mandatory:message' => 'You must validate the validation box',
		'welcomer:menu:welcome:switch' => 'Control page',
		'welcomer:menu:welcome:edit' => 'First login -> Edit',
		'welcomer:menu:welcome:activate' => 'First login -> Activate',
		'welcomer:menu:welcome:view' => 'First login -> View',
		'welcomer:menu:message:edit' => 'Next login -> Edit',
		'welcomer:menu:message:activate' => 'Next login -> Activate',
		'welcomer:menu:message:view' => 'Next login -> View',
		'welcomer:modifier' => 'modify',
		'welcomer:valider' => 'validate',
		'welcomer:admin:menu' => 'Manage welcomer',
	
	);
					
	add_translation("ar",$arabic);

?>