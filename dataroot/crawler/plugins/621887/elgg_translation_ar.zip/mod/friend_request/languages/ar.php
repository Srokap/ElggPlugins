<?php

// Generate By translationbrowser. 

$arabic = array( 
	 'friend_request'  =>  "طلب صداقة" , 
	 'friend_request:menu'  =>  "طلبات الصداقة" , 
	 'friend_request:title'  =>  "طلبات الصداقة" , 
	 'friend_request:new'  =>  "طلبات الصداقة جديدة" , 
	 'friend_request:newfriend:subject'  =>  "%s يريد أن يكون صديقك!" , 
	 'friend_request:newfriend:body'  =>  "%s يريد أن يكون صديقك! ولكنه ينتظرك لأن تقبل طلب صداقته ...لذا من فضلك قم بتسجيل الدخول لتتمكن من تفعيل أو رفض طلبه!

يمكنك مشاهدة طلبات الصداقة إليك عبر (تأكد من إنك قمت بتسجيل الدخول قبل الضغط على الرابط وإلا سيتم إعادة توجيهك للصفحة الرئيسية.) :

%s

(هذا الرسالة أتوماتيكية لايمكنك الرد عليها.)" , 
	 'friend_request:add:failure'  =>  "عفواً, بسبب خطأ فى التظام لا يمكننا إكمال طلبك, حاول مرة أخرى لاحقاً." , 
	 'friend_request:add:successful'  =>  "لقد طلبت أن تكون صديقاً إلى %s. يجب أن يتم الموافقة على طلبك قبل أن يظهروا بصفحة أصدقائك." , 
	 'friend_request:add:exists'  =>  "لقد طلبت بالفعل أن تكون صديقاً إلى %s." , 
	 'friend_request:approve'  =>  "موافقة" , 
	 'friend_request:approve:successful'  =>  "%s هو الأن صديقك." , 
	 'friend_request:approve:fail'  =>  "خطأ فى تكوين رابطة الصداقة مع  %s" , 
	 'friend_request:decline'  =>  "رفض" , 
	 'friend_request:decline:subject'  =>  "%s قام برفض طلب صداقتك." , 
	 'friend_request:decline:message'  =>  "عزيزى %s,

%s قام برفض طلب صداقتك." , 
	 'friend_request:decline:success'  =>  "تم رفض طلب الصداقة." , 
	 'friend_request:decline:fail'  =>  "لم تتم عماية رفض طلب الصداقة بنجاح." , 
	 'friend_request:revoke'  =>  "إبطال" , 
	 'friend_request:revoke:success'  =>  "تم إبطال طلب الصداقة بنجاح." , 
	 'friend_request:revoke:fail'  =>  "خطأ أثناء عملية إبطال طلب الصداقة." , 
	 'friend_request:received:title'  =>  "طلبات صداقة لك" , 
	 'friend_request:received:none'  =>  "لا توجد طلبات صداقة تحتاج موافقتك." , 
	 'friend_request:sent:title'  =>  "طلبات صداقة منك" , 
	 'friend_request:sent:none'  =>  "لا توجد طلبات صداقة قمت بإرسالها وتنتظر الموافقة."
); 

add_translation('ar', $arabic); 

?>