<?php

	/**
	 * Elgg HTMLWidget Plugin
	 * 
	 * @package HTMLWidget
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Mistress RavenGoth
	 * @copyright Demented Mind Productions 2012
	 * @link http://dementedmindproductions.com/
	 * 
	 */
	
		function htmlwidget_init() {
    		
    		
			
    		//add a widget
               elgg_register_widget_type('htmlwidget', 'Customizable HTML Widget', 'Customizable HTML display widget');
			
		}
		
		elgg_register_event_handler('init','system','htmlwidget_init');

?>