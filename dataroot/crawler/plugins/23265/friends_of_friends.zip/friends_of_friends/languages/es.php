<?php

// Generado por translationbrowser 

$spanish = array( 
	 'friends_of_friends'  =>  "Amigos de amigos" , 
	 'friendsoffriends'  =>  "Amigos de amigos" , 
	 'friends_of_friends:setting:hidefriendsof'  =>  "Ocultar Amigos de" , 
	 'friends_of_friends:setting:showfriendsof'  =>  "Mostrar amigos de"
); 

add_translation('es', $spanish); 

?>