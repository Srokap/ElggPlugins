<?php
	$english = array(
			'friends_of_friends' => 'Friends of friends',
			'friendsoffriends' => 'Friends of friends',
			'friends_of_friends:setting:hidefriendsof' => "Hide friends of",
			'friends_of_friends:setting:showfriendsof' => "Show friends of",
	);
					
	add_translation("en",$english);
?>