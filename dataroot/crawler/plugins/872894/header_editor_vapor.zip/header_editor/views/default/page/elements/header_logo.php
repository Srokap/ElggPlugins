<style type="text/css" media="screen">
.elgg-page-default .elgg-page-header > .elgg-inner {
width: 990px;
margin: 0 auto;
height:  auto;
}
</style>
<?php
$headercontents = elgg_get_plugin_setting('headercontents', 'header_editor');
echo $headercontents;
?><br>
<br><br></br>