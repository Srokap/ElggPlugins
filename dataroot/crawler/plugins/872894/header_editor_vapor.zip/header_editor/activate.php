<meta http-equiv="refresh" content="0; url=<?php
echo elgg_get_site_url(); ?>mod/header_editor/thankyou.php">