<?php
/*
┏━━━┓╋╋╋╋╋╋┏┓╋╋╋╋╋┏┓╋╋╋╋╋╋╋╋╋╋╋┏━┓┏━┓
┃┏━┓┃╋╋╋╋╋╋┃┃╋╋╋╋┏┛┗┓╋╋╋╋╋╋╋╋╋╋┗┓┗┛┏┛
┃┗━┛┣━┳━━┳━┛┣┓┏┳━┻┓┏╋┳━━┳━┓┏━━┓╋┗┓┏┛
┃┏━━┫┏┫┏┓┃┏┓┃┃┃┃┏━┫┃┣┫┏┓┃┏┓┫━━┫╋┏┛┗┓
┃┃╋╋┃┃┃┗┛┃┗┛┃┗┛┃┗━┫┗┫┃┗┛┃┃┃┣━━┃┏┛┏┓┗┓
┗┛╋╋┗┛┗━━┻━━┻━━┻━━┻━┻┻━━┻┛┗┻━━┛┗━┛┗━┛
This elgg plugin was developed by Bluedime and Speedysnail6. They both are members of Productions X.
http://productionsx.tk
*/
?>