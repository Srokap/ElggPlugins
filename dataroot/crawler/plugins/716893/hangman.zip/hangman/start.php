<?php
		function hangman_init() 
		{
		global $CONFIG;
		add_menu(elgg_echo('hangman'), $CONFIG->wwwroot . "mod/hangman");
		}
		
	register_elgg_event_handler('init','system','hangman_init');

?>