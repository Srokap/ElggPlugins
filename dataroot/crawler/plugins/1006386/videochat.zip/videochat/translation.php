<translations>
<t text="Successfully connected to RTMFP server." translation="Successfully connected to RTMFP server."/>
<t text="External Encoder" translation="External Encoder"/>
<t text="Toggle Sound Effects" translation="Toggle Sound Effects"/>
<t text="Buzz!" translation="Buzz!"/>
<t text="Swap Panels" translation="Swap Panels"/>
<t text="LogOut" translation="LogOut"/>
<t text="Sound Effects" translation="Sound Effects"/>
<t text="Toggle Audio" translation="Toggle Audio"/>
<t text="Camera" translation="Camera"/>
<t text="Toggle Video" translation="Toggle Video"/>
<t text="Next!" translation="Next!"/>
<t text="Server Connection" translation="Server Connection"/>
<t text="Microphone" translation="Microphone"/>
<t text="Server / P2P" translation="Server / P2P"/>
<t text="Entering room" translation="Entering room"/>
<t text="Successfully connected to RTMP server." translation="Successfully connected to RTMP server."/>
<t text="Connecting to RTMFP server." translation="Connecting to RTMFP server."/>
<t text="FullScreen" translation="FullScreen"/>
<t text="Toggle Microphone" translation="Toggle Microphone"/>
<t text="Toggle Webcam" translation="Toggle Webcam"/>
<t text="joined" translation="joined"/>
<t text="Save Photo in Logs" translation="Save Photo in Logs"/>
<t text="Translation XML was copied to clipboard. Just paste it in a text editor." translation="Translation XML was copied to clipboard. Just paste it in a text editor."/>
<t text="Snapshot" translation="Snapshot"/>
<t text="No Connection" translation="No Connection"/>
<t text="Webcam / External Encoder" translation="Webcam / External Encoder"/>
</translations>