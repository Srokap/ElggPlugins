au_random_content_widget
========================

A widget for all contexts that shows random content that the user has permissions to see