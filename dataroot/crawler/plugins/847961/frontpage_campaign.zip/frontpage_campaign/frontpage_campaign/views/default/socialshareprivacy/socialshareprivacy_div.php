
<?php

$content =  <<<____HTML
<div id="socialshareprivacy"></div>
____HTML;

echo $content;

