.elgg-layout-one-sidebar {
	background: transparent url(<?php echo elgg_get_site_url(); ?>mod/frontpage_campaign/_graphics/sidebar_background.gif) repeat-y right top;
}
.elgg-layout-two-sidebar {
	background: transparent url(<?php echo elgg_get_site_url(); ?>mod/frontpage_campaign/_graphics/two_sidebar_background.gif) repeat-y right top;
}
.elgg-sidebar {
    float: right;
    margin: 0 2px 2px 10px;
    padding: 20px 10px 10px 5px;
    position: relative;
    width: 220px;
}

.file-photo .elgg-photo {
 background-color: white;
    border: 1px solid #CCCCCC;
    padding: 3px 3px 3px 3px;
    margin:50px 0px 0px 0px;
}
.frontpage_campaign-wrapper {
padding-right:4px;
}
.frontpage_image_block_wrapper {
padding-left:8px; padding-right:8px;
padding-bottom:3px;
}
.frontpage_campaign-bar { margin-bottom:10px; margin-top:5px;
padding-left:0px; padding-right:0px; background:#D9E5F4; }
}
.donationWrapper {
width:300px;

}
.elgg-image-block clearfix {
padding-right:3px;
}
.donationButton {
width:150px;

}
.frontpage_campaign-bar img{
margin-left:5px;
height:80px;
 }
 .elgg-inner .elgg-heading-site:hover {
    margin: 0 0 0 13px;
}
.frontpage_campaign-events .elgg-module {
    margin-bottom: 0px;
    overflow: hidden;
}
.c_i_c_subcomments {
margin-top:3px; 
font-size:11px;
line-height:13px;
}
.c_i_c_bar {
padding:1px 0px 1px 3px; 
margin:3px 0px 5px 0px; 
background: red; 
text-shadow: 0px 1px 1px #4d4d4d; 
color: white; 
font: 8px;
}
.c_i_c_bar_category {
padding:1px 0px 1px 3px; 
margin:3px 0px 5px 0px; 
background: grey; 
text-shadow: 0px 1px 1px #1d1d1d; 
color: white; 
font: 8px;
}
.c_i_c_bar_category_content {
padding:1px 0px 1px 3px; 
margin:3px 0px 5px 0px; 
background: blue; 
text-shadow: 0px 1px 1px #1d1d1d; 
color: white; 
font: 8px;
}
.c_i_c_more {
padding-bottom:4px;
}
 .elgg-page-default .elgg-page-body > .elgg-inner { 
 margin: 0 auto;
width: 970px; } 
.elgg-page-default .elgg-page-footer .elgg-inner {
margin: 0 auto; width: 950px; } 
.elgg-page-default .elgg-page-header
.elgg-inner {
 margin: 0 auto; width: 970px; }
  .elgg-inner
.elgg-heading-site { 
margin:0 0 0 13px; }
 .elgg-button-dropdown {
border:0px; }
 .elgg-page-default .elgg-page-footer.elgg-inner {
padding-left:20px; } .c_i_c_title {
 font-size:11px; line-height:14px;
font-weight:bold; }
 .c_i_c_subtitle { 
 margin-top:3px; font-size:11px;
line-height:13px; 
} 
.c_i_c_subtitle p { margin-top:3px;
margin-bottom:3px; } 






p { margin-bottom:10px; } a { color:#4077AA; }
a:hover { color:#FF3300; text-decoration:none; }
.elgg-menu-site-default>li>a { color:#4690D6; } .elgg-page-header {
background:#CFDBEC; } .elgg-page-footer { color:#999999;
background:#F0F0F0; } .elgg-main { min-height:none; padding:10px; }

.sidebarBox .donationWrapper { background: white; -webkit-border-radius:
8px; -moz-border-radius: 8px; padding:5px; } .sidebarBox
.donationWrapper .recentDonator { margin:2px; float:left; } .sidebarBox
.donationWrapper .recentDonator .usericon img { /*width:25px;*/
/*height:25px;*/ padding:0px; } /* br necessary for ie6 & 7 */
.sidebarBox .donationWrapper br { height:0; line-height:0; }
.profile_donation { padding:0 0 0 21px; line-height:1.3em;
min-height:17px; margin:2px; background: url(
<?php echo $vars['url']; ?>
mod/donation/graphics/river_icon_donation.png) no-repeat left -1px; }

.list_donation { float:right; padding:0 0 0 21px; line-height:1.3em;
min-height:17px; margin-top: -20px; background: url(
<?php echo $vars['url']; ?>
mod/donation/graphics/river_icon_donation.png) no-repeat left -1px; } /*
*************************************** ALL DONATORS
*************************************** */ .contentWrapper
.donationWrapper { background: white; -webkit-border-radius: 8px;
-moz-border-radius: 8px; } .contentWrapper .donationWrapper
.recentDonator { margin:2px; float:left; padding:4px; } .contentWrapper
.recentDonator .usericon img { width:100px; height:100px; } .elgg-search
input[type="text"] {
background:
<?php echo $vars['url']; ?>
/_graphics/elgg_sprites.png")
no-repeatscroll 2px -934px #4690D6; background-color:#4690D6; border:
0px ; color:#4690D6; font-size:12px; font-weight:bold; padding:2px 4px
2px 26px; border-radius:1px 1px 1px 1px; margin: 0px 10px 0px 0px; }

.elgg-heading-site,.elgg-heading-site:hover { color:#5D5F5E;
font-family:Arial,sanserif; font-size:1.3em; font-style:normal;
font-weight:bold; line-height:1.8em; text-decoration:none;
text-shadow:none; margin-left:3px; } .custom-index { padding:10px 0; }
.elgg-module-highlight { -webkit-box-shadow:1px 1px 5px #CCC;
-moz-box-shadow:1px 1px 5px #CCC; box-shadow:1px 1px 5px #CCC; }
.elgg-module-highlight:hover { -webkit-box-shadow:1px 1px 6px #AAA;
-moz-box-shadow:1px 1px 6px #AAA; box-shadow:1px 1px 6px #AAA; }
.frontpage_campaign-events { margin-bottom:10px; margin-top:5px;
padding-left:8px; padding-right:8px; background:#D9E5F4; }
.videolist-gallery-item .elgg-body { padding-left:5px; }
