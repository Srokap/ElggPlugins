 Frontpage Campaign

 @package frontpage_campaign
 @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 @author manfred salomon <manfred@toodle-pip.net>
 @copyright manfred salomon
 @link http://www.toodle-pip.net/

 
Version: 1.8-12.02.12
Requires: Elgg 1.8 or higher


Description:

Frontpage for a Campaign with flip-pics and save sharing with facebook, google and twitter.
 
Watch frontpage campain trailer: http://youtu.be/wEZsPgE1sNU

Make sure that the plugin is at the bottom of all plugins!

Required plugin: File (File upload und file embeding is only available for Admin)

Sugguested plugins: 

cash's "Elgg-Following"
iionly's "Elgg 1.8: German Language Pack"
jeroen's "Profile Manager"
ManUtopiK's "Brainstorm your elgg 1.8"
sem's "Threads"


Many thanks to 13, sem and slyne. (i use the code from "phloor_flipwall", "phloor_socialshareprivacy", "videolist", "donate")

NEW: Donating via Papal
NEW: The 'Quick and Dirty #number#-System' ;-) is canceled. Now you control the visible of the content with file and site-settings.
NEW: Optional Picture and Grouping to category for "Recources".


How to make the frontpage campaign:

copy frontpage campaign to your mod folder

Watch the quick guide video: http://youtu.be/tY5m5R90XWI

Go to the frontpage campaign plugin settings and edit (like in the setting described) and save.

That's all.



Languages:

English
German
(other languages welcomed)

Suggestions and additional features welcomed
