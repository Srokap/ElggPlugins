<?php

	$english = array(
	
		/**
		 * My HTML details
		 */
		
	        
	        'Popup:title' => "Popup",
	        'Popup:description' => "Popup widget"
	        
		
	);
					
	add_translation("en",$english);

?>