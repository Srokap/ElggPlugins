<?php

	/**
	 * Elgg Popup Plugin
	 * 
	 * @package Popup
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Marek Lompart
	 * @copyright mlmedia.sk
	 * @link http://dslive.sk/
	 * 
	 */
	
		function Popup_init() {
    		
    		
			
    		//add a widget
			    add_widget_type('Popup',elgg_echo("Popup:title"),elgg_echo("Popup:description"));
			
		}
		
		register_elgg_event_handler('init','system','Popup_init');

?>