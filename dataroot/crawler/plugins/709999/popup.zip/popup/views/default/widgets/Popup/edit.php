<?php

	/**
	 * Elgg Popup plugin
	 * 
	 * @package Popup
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Marek Lompart
	 * @copyright mlmedia.sk
	 * @link http://dslive.sk/
	 * 
	 */

?>
 

<h6><a href="http://funradio.sk" title="Funrádio" target="_blank"><span style="text-decoration:none;color:#400000;">Funrádio</span></a><br></h6>

