<?php
    
	/**
	 * Elgg Popup Plugin
	 * 
	 * @package Popup
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Marek Lompart
	 * @copyright mlmedia.sk
	 * @link http://dslive.sk
	 * <A HREF="javascript:void(window.close('http://funradio.sk/play?select=1'))">close radio</A><BR>
	 */
	 

?>

<SCRIPT LANGUAGE="JavaScript">

function gopopup() {

TheNewWin =window.open("http://www.funradio.sk/play?select=1",'TheNewpop','toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=400, height=300' ); 

TheNewWin.blur();

}
</SCRIPT> 
<center>

<FORM>
<input type="image" src="<?php echo $vars['url']; ?>mod/popup/image/button.png"alt="Fun Radio" border="0" width="264" height="44"onClick="gopopup()">
</FORM>


</center>
