<?php

	$german = array(
		'vazco_mainpage:edit' => "Hier editieren Sie die Hauptseiten-widgets",
		'vazco_mainpage:menu' => "Hauptseiten widgets",
		'vazco_mainpage:title'=> "Definieren Sie hier die Hauptseiten-Widgets",
		'vazco_mainpage:description'=> "Hier k&ouml;nnen Sie die widgets f&uuml;r die Hauptseite setzten. Ausserdem k&ouml;nnen Sie auch eigenen HTML-Code verwenden. Ziehen Sie hierzu einfach eine HTML-Box an die Stelle, wo Ihr HTML-Code stehen soll.",
		'vazco_mainpage:gallery'=> "Hauptseiten widgets",
		'custom:bookmarks' => "Die neusten bookmarks",
		'custom:groups' => "Die neusten Gruppen",
		'custom:files' => "Neuste Dateien",
		'custom:blogs' => "Die neusten blog posts",
		'custom:members' => "Die neusten Mitglieder",
		'vazco_mainpage:html' => "HTML-Element",
		'vazco_mainpage:html:desc' => "Durch dieses Element k&ouml;nnen Sie jegliche Art von HTML-Code hinzuf�gen. Beachten Sie bitte, dass fehlerhafter HTML-Code in diesem Elemt Ihr Layout zerst&ouml;ren kann.",
	
		'custom:bookmarks:desc' => "Zeige die letzten bookmarks",
		'custom:groups:desc' => "Zeige die letzten Gruppen",
		'custom:files:desc' => "Zeige die letzten Dateien",
		'custom:blogs:desc' => "Zeige die letzten blog posts",
		'custom:members:desc' => "Zeige die neusten Mitglieder",
	
		'vazco_widgets:nowidget' => "Das Hauptseiten widget '%s' enth�lt keinen HTML-Code.",
		'vazco_mainpage:update:success' => "Die Einstellungen wurden erfolgreich gespeichert.",
		'vazco_mainpage:update:failed' => "Es ist ein Fehler beim Speichern aufgetreten.",
	);
					
	add_translation("de",$german);
?>