<?php
if (isloggedin()) forward('pg/dashboard/');
?>
</center>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Social Web Theme</title>
<script type="text/javascript" src="mod/swProtheme/highslide/highslide-with-html.js"></script>
<script type="text/javascript" src="mod/swProtheme/highslide/highslide.config.js" charset="utf-8"></script>
<link rel="stylesheet" type="text/css" href="mod/swProtheme/highslide/highslide.css" />
<link href="mod/swProtheme/style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="mod/swProtheme/js/jquery.js"></script>
		<script type="text/javascript" src="mod/swProtheme/js/jquery.innerfade.js"></script>

<link href="mod/swProtheme/css/jq_fade.css" rel="stylesheet" type="text/css" />
</head>

<body>



<div id="wrap">
<div id="ribbon">
<h1 id="logo"> <a href="http://milockerteam.limewebs.com/elgg171/">SocialWeb <span class="black">team</span></a>
<span class="desc">desarrollo web</span>
</h1>
<div class="bracket-end"></div>
<div id="intro">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>lorem ipsum seclorum e pluribus unimlorem ipsum seclorum e pluribus unimlorem ipsum seclorum e pluribus unimlorem ipsum seclorum e pluribus unimlorem ipsum seclorum</p>
  </div>

</div>
<div id="nav">
<ul>

<li class="current"><a href="http://milockerteam.limewebs.com/elgg171/"><span>Home</span></a></li>


</ul>

</div>
<div id="homeheader">
<div id="left-column">
<h2>Welcome!</h2>
<p>We offer web services, and we work alongside with you to get the best results for your needs. We use latest web technologies in .</p>

<p><span class="learnmore"><a href="mod/swProtheme/highslide/texto/include-bienvenida.htm" onclick="return hs.htmlExpand(this, { 
			objectType: 'ajax', width: 400, 
			creditsPosition: 'bottom left', headingText: 'Bienvenida', 
			wrapperClassName: 'titlebar' } )">Read more...</a> </span></p>
</div>
<div id="right-column">
<h2>Login</h2>
<ul id="portfolio">					
					<li><div class="imgholder" style="color:white;">
                      <img src="mod/swProtheme/images/elgg.jpg" width="172" height="155" alt="Elgg" /></div>
                      <div class="txtholder">

					  <?php
								$form_body = "<p><label>" . elgg_echo('username') . "<br />" . elgg_view('input/text', array('internalname' => 'username', 'class' => 'login-textarea')) . "</label><br />";
								$form_body .= "<label>" . elgg_echo('password') . "<br />" . elgg_view('input/password', array('internalname' => 'password', 'class' => 'login-textarea')) . "</label><br />";
								$form_body .= elgg_view('input/submit', array('value' => elgg_echo('login'))) . "</p>";
								$form_body .= "<p><a href=\"". $vars['url'] ."account/register.php\">" . elgg_echo('register') . "</a> | <a href=\"". $vars['url'] ."account/forgotten_password.php\">" . elgg_echo('user:password:lost') . "</a></p>";

								echo elgg_view('input/form', array('body' => $form_body, 'action' => "". $vars['url'] ."action/login"));

					  ?>
                      
                      </div>
        </li>
					
							
									
	  </ul>
</div>
</div>
<div id="contents">

<div id="col1">
<h2>Benefits of a website?</h2>
<p>The internet is an excellent channel for promoting your business to potential clients anywhere, anytime. All they need is your website address, whether from a business card, an advert, letterhead, email or search engines.</p>

</div>

<div id="col2">
<h2>Market your business online</h2>
<p>
Reinforce corporate and brand identity. Make your existing investment in marketing go further,
Advertise services and products,
Collect e-mail addresses and other information through your website,
Conduct market research through your website,
Promotion through targeted direct e-mail campaigns,
Build customer relations through personalised service, and
Deliver targeted prospects to your mailbox!</p>
</div>

<div id="col3">

<h2>Middle Title</h2>
<p>lorem ipsum seclorum e pluribus unim lorem ipsum seclorum e pluribus unim lorem ipsum seclorum e pluribus unim lorem ipsum seclorum e pluribus unim lorem ipsum seclorum e pluribus unim lorem ipsum seclorum e pluribus unim</p>
</div>
<div class="clear"></div>
</div>
</div>

<p>&nbsp;</p>



</div><!-- /#page_wrapper -->
</div><!-- /#page_container -->
<br />
<br />

<br />
<br />
</div>
</div>
<div class="clear"></div>
</div>
</div>
<div id="footer">
<div id="container">
<div class="left">
<p>2009 - 2010 &copy; Milocker  | Copyright <br />
Derechos Reservador - milocker.com</p>
</div>
<div class="clear"></div>
</div>

</div>

</body>
</html>