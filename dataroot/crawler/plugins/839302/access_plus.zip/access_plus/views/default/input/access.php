<?php
/**
 * Elgg access level input
 * Displays a pulldown input field
 *
 * @package Elgg
 * @subpackage Core


 *
 * @uses $vars['value'] The current value, if any
 * @uses $vars['js'] Any Javascript to enter into the input tag
 * @uses $vars['internalname'] The name of the input field
 *
 *	//use context to select when to replace the default view
 *	blog - blog
 *	dashboard - widgets
 *	profile - widgets
 */
global $access_view_count;
//count the number of times the view has been called - keeps ids unique
//and used to generate the token
if(!is_numeric($access_view_count)){
	$access_view_count = 0;
}
else{
	$access_view_count++;
}


// use the access view count to set the default value of the default field
// this will be passed to the event handler and we'll be able to tell what the new value should be
//
// create empty access collections to use as placeholders for counts
// sounds complicated...
// but here's what's happening
//
// if this is the first time the view is called then $access_view_count = 1
// so we'll set a hidden input with this value
// a plugin setting called 'field_count1' will be retrieved, if it doesn't exist we'll create it
// the plugin setting will hold the id of an empty collection, and this will be set as the
// default value for the $vars['internalname']
//
// so when the form is submitted, we can get the set access_id, which will be equal to our
// field_count value, from that we can tell which $_POST value to use to reset the access
//
// simple... right? right.

// so to start, we're going to get our system flag for the current view_count
$flag = elgg_get_plugin_setting('field_count'.$access_view_count, 'access_plus');

if(!$flag){
	//if we have no flag for this count we're creating one
	$flag = access_plus_create_field_count_flag($access_view_count);
}

// get our token and see if this view has been blacklisted
$token = access_plus_generate_token($vars['name']);
//var_dump($token);

// check to see if our token has been blacklisted
if(access_plus_is_blacklisted($token)){
	// it's been blacklisted, show the regular access control
	include "access_original.php";
}
else{
	// not blacklisted - show the cool controls
	
	$class = "input-access";
	if (isset($vars['class'])) {
		$class = $vars['class'];
	}

	$disabled = false;
	if (isset($vars['disabled'])) {
		$disabled = $vars['disabled'];
	}

	if (!array_key_exists('value', $vars) || $vars['value'] == ACCESS_DEFAULT) {
		$vars['value'] = get_default_access();
	}

	// check to see if the value is a metacollection
	$metacollection_id = elgg_get_plugin_user_setting($vars['value'], elgg_get_logged_in_user_guid(), 'access_plus');

	$collectionarray = array($vars['value']);
	if(!empty($metacollection_id)){
		$collectionarray = explode(":", $metacollection_id);
	}


	if ((!isset($vars['options'])) || (!is_array($vars['options']))) {
		$vars['options'] = array();
		$vars['options'] = get_write_access_array();
	}

	if (is_array($vars['options']) && sizeof($vars['options']) > 0) {

		echo "<br>";

		// sort $vars['options'], if there are elgg default site-wide options put them first
		// everything else do alphabetical afterwards
		$tmpoptions = array();

		if(array_key_exists(ACCESS_PRIVATE, $vars['options'])){
			$tmpoptions[][ACCESS_PRIVATE] = $vars['options'][ACCESS_PRIVATE];
			unset($vars['options'][ACCESS_PRIVATE]);
		}

		if(array_key_exists(ACCESS_FRIENDS, $vars['options'])){
			$tmpoptions[][ACCESS_FRIENDS] = $vars['options'][ACCESS_FRIENDS];
			unset($vars['options'][ACCESS_FRIENDS]);
		}

		if(array_key_exists(ACCESS_LOGGED_IN, $vars['options'])){
			$tmpoptions[][ACCESS_LOGGED_IN] = $vars['options'][ACCESS_LOGGED_IN];
			unset($vars['options'][ACCESS_LOGGED_IN]);
		}

		if(array_key_exists(ACCESS_PUBLIC, $vars['options'])){
			$tmpoptions[][ACCESS_PUBLIC] = $vars['options'][ACCESS_PUBLIC];
			unset($vars['options'][ACCESS_PUBLIC]);
		}

		// sort the remaining options alphabetically
		if(is_array($vars['options']) && count($vars['options']) > 0){
			asort($vars['options']);
		}

		foreach($vars['options'] as $key => $value){
			$tmpoptions[][$key] = $value;
		}

		$elgg_access = array(
		ACCESS_PRIVATE,
		ACCESS_FRIENDS,
		ACCESS_LOGGED_IN,
		ACCESS_PUBLIC,
		);
		?>
<div class="access_plus_wrapper">
<?php
/*
 * Set as private for now, the plugin will figure out the access on the create/update hook
 */
?>
	<input type="hidden"
		name="<?php echo $vars['name']; ?>"
		value="<?php echo $flag; ?>">
		<?php
		$name = $vars['name'];
		$oddeven = 0;
		for($i=0; $i<count($tmpoptions); $i++){
			$keys = array_keys($tmpoptions[$i]);
			$key = $keys[0];
			// set up odd/even class name for zebra striping css
			$oddeven++;
			if($oddeven % 2){ $zebra = "zebra_odd"; }else{ $zebra = "zebra_even"; }
			if(in_array($key, $elgg_access)){ $zebra = "site-wide-options"; }
			echo "<div class=\"access_plus_$zebra\">";
			if(in_array($key, $collectionarray)){
				echo "<input name=\"access_plus{$access_view_count}[]\" id=\"access_plus_{$access_view_count}_{$key}\" class=\"{$vars['class']}\" type=\"checkbox\" value=\"{$key}\" checked=\"checked\"><label for=\"access_plus_{$access_view_count}_{$key}\">". htmlentities($tmpoptions[$i][$key], ENT_QUOTES, 'UTF-8') ."</label>";
			} else {
				echo "<input name=\"access_plus{$access_view_count}[]\" id=\"access_plus_{$access_view_count}_{$key}\" class=\"{$vars['class']}\" type=\"checkbox\" value=\"{$key}\"><label for=\"access_plus_{$access_view_count}_{$key}\">". htmlentities($tmpoptions[$i][$key], ENT_QUOTES, 'UTF-8') ."</label>";
			}

			echo "</div>"; // access_plus_$zebra
	}

	?>
</div>
<?php
	} //is_array
} // end of cool controls


//
// add the link to toggle the access view if admin
if(elgg_is_admin_logged_in()){
	$url = elgg_get_site_url() . "action/access_plus/toggle?token=" . $token;
	$url = elgg_add_action_tokens_to_url($url);
	
	$linktext = elgg_echo('access_plus:toggle:off');
	if(access_plus_is_blacklisted($token)){
		$linktext = elgg_echo('access_plus:toggle:on');
	}
	
	echo "<div><a href=\"$url\">" . $linktext . "</a></div>";
}