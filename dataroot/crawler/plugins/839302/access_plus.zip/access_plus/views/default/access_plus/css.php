.access_plus_wrapper{
	height: 150px;
	border: 1px solid #cccccc;
	background-color: #fcfcfc;
	overflow-x: hidden;
	overflow-y: auto;
}

.access_plus_site-wide-options{
	background-color: #BBDAF7;
	padding: 3px;
}

.access_plus_zebra_even{
	padding: 3px;
	background-color: #ffffff;
}

.access_plus_zebra_odd{
	padding: 3px;
	background-color: #ececec;
}