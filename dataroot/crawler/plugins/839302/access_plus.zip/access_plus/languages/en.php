<?php

	$english = array(
		'access_plus' => "Access Plus",
		'access_plus:add_user_to_metacollection:error' => "There was an issue adding a user to the metacollection",
		'access_plus:collections' => "Friend Collections",
		'access_plus:invalid:token' => "Invalid Access View ID",
		'access_plus:metacollection:creation:error' => "There was an issue creating the permissions, content set to private access.",
		'access_plus:toggle:disabled' => "Multi-Access has been disabled.",
		'access_plus:toggle:enabled' => "Multi-Access has been enabled.",
		'access_plus:toggle:off' => "Turn off multi-access",
		'access_plus:toggle:on' => "Turn on multi-access",
	);
					
	add_translation("en",$english);

?>