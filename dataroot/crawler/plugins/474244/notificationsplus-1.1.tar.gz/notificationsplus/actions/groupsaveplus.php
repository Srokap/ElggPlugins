<?php

	
    require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
	  // Restrict to logged in users
		gatekeeper();
		
	// Load important global vars
		global $SESSION;
		global $NOTIFICATION_HANDLERS;
	
		
		$group_guid = get_input('group');
		$group_entity = get_entity($group_guid);
		
		foreach($NOTIFICATION_HANDLERS as $method => $foo) {
			$subscriptions[$method] = get_input($method.'subscriptions');
			$personal[$method] = get_input($method.'personal');
			$collections[$method] = get_input($method.'collections');
			
					if (in_array($group_guid,$subscriptions[$method])) {
						add_entity_relationship($SESSION['user']->guid,'notify'.$method,$group_guid);
					} else {
						remove_entity_relationship($SESSION['user']->guid,'notify'.$method,$group_guid);
					}				
		}
				
		system_message(elgg_echo('notifications:subscriptions:success'));
    	
	forward($group_entity->getURL());

?>
