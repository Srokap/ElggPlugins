<?php

	/**
	 * Elgg notificationsplus plugin
	 * 
	 * @package notificationsplus adapted from curverider notifications
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Fabrice Collette <fabrice.Collette@free.fr>
	 * @copyright Fabrice Collette 2009
	 * @link http://www.meleze-conseil.com/
	 */

	// Load Elgg framework
		require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');
		
		$group_guid = get_input('group');
		
	// Ensure only logged-in users can see this page
		gatekeeper();
		
	// Set the context to settings
		set_context('settings');
		
	// Get the form
		global $SESSION, $CONFIG;
		$people = array();
		
		$groupmemberships = array();
    $groupmemberships[0] = get_entity($group_guid);
		
		$body = elgg_view('input/form',array(
			'body' => elgg_view('notificationsplus/setgroupnotification',array(
							'groups' => $groupmemberships
						)),
			'method' => 'post',
			'action' => $CONFIG->wwwroot . 'mod/notificationsplus/actions/groupsaveplus.php?group='.$group_guid
		));
		
	// Insert it into the correct canvas layout
		$body = elgg_view_layout('two_column_left_sidebar','',$body);
		
	// Draw the page
		page_draw(elgg_echo('notifications:subscriptions:changesettings:groups'),$body);
		
?>