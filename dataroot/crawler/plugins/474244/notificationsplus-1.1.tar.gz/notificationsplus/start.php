<?php
/**
 * Elgg notificationsplus plugin
 * 
 * @package notificationsplus adapted from curverider notifications
 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
 * @author Fabrice Collette <fabrice.Collette@free.fr>, Liran Tal <liran.tal@gmail.com>
 * @copyright Fabrice Collette 2009, Liran Tal 2010
 * @link http://www.meleze-conseil.com/ http://www.enginx.com
 */

	
function notificationsplus_plugin_init() {
      
	global $CONFIG;
	
	// ACtivate event handlers
	//register_elgg_event_handler('create','member','notificationsplus_create_member',917);
	//removed event handler on group create and added it on member's group join
	register_plugin_hook('action', 'groups/join', 'notificationsplus_create_member');
	
}

register_elgg_event_handler('init','system','notificationsplus_plugin_init');


function notificationsplus_create_member($hook, $entity_type, $returnvalue, $params) {
	
	global $CONFIG;
	
	$group_guid = get_input('group_guid');
	$user_guid = get_input('user_guid', get_loggedin_userid());
	
	$user = get_entity($user_guid);
	$group = get_entity($group_guid);
	
	
	
	if (isloggedin()) {
  		if (($user instanceof ElggUser) && ($group instanceof ElggGroup)) {  			
			set_input('group',$group_guid);
			@include(dirname(__FILE__) . "/setgroupnotification.php");
		}
	}
	
	return true;
}

		



