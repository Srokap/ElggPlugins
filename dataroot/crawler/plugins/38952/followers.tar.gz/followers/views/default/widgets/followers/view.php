<?php
  //the page owner
$owner = get_user($vars['entity']->owner_guid);

//the number of files to display
$num = (int) $vars['entity']->num_display;
if (!$num)
  $num = 8;

//get the correct size
$size = (int) $vars['entity']->icon_size;
if (!$size || $size == 1){
  $size_value = "small";
 }else{
  $size_value = "tiny";
 }

// Get the users friends
$friends = $owner->getFriendsOf("", $num, $offset = 0);

// If there are any $friend to view, view them
if (is_array($friends) && sizeof($friends) > 0) {
  
  echo "<div id=\"widget_friends_list\">";
  
  foreach($friends as $friend) {
    echo "<div class=\"widget_friends_singlefriend\" >";
    echo elgg_view("profile/icon",array('entity' => get_user($friend->guid), 'size' => $size_value));
    echo "</div>";
  }
  
  echo "</div>";
  
 }
	
?>