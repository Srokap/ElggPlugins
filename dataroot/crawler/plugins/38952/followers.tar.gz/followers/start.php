<?php
  /**
   * Elgg Follower widget
   * This plugin allows users to put a list of their followers, on their profile
   * 
   * @package ElggFollowers
   * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
   * @author Jean-Baptiste Perriot <jb@perriot.fr>
   */
	
function followers_init() {
  
  // Load system configuration
  global $CONFIG;
  
  //add a widget
  add_widget_type('followers',elgg_echo("Followers"),elgg_echo('followers:widget:description'));
  
  }

register_elgg_event_handler('init','system','followers_init');
        
?>