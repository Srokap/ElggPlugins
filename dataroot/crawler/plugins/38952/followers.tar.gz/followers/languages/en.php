<?php

	$english = array(
			 'followers:widget:description' => "Displays some of your followers.",
			 'followers:num_display' => "Number of followers to display",
			 'followers:icon_size' => "Size of the icons of followers"
	);
					
	add_translation("en",$english);
?>