<?php

    /**
     * TinyMCE wysiwyg editor
     * @package ElggTinyMCE
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.org/
     **/

    function tinymce_init() {

	    // Load system configuration
		    global $CONFIG;

         // Add our CSS
				extend_view('css','tinymce/css');

        $CONFIG->allowedtags['object'] = array( 'width'=>array(), 'height'=>array(), 'codebase'=>array());
        $CONFIG->allowedtags['param'] = array( 'name'=>array(), 'value'=>array());
        $CONFIG->allowedtags['embed'] = array( 'src'=>array(), 'type'=>array(), 'wmode'=>array(), 'width'=>array(), 'height'=>array());
        $CONFIG->allowedtags['style'] = array( 'lang'=>array(), 'type'=>array(), 'title'=>array(), 'media'=>array());

    }

     // Make sure the status initialisation function is called on initialisation
		register_elgg_event_handler('init','system','tinymce_init');

?>