Yet Another Full Featured TinyMCE
1.03

This version includes all differential upgrades published for v1.01 and some minor bugfixes.

What does it do?

Tinymce gives you the power of wysiwyg text-editing on fields of type 'longtext' in elgg. Currently enabled features of tinymce in this version are:

Text attributes: bold,italic,underline,strikethrough,foregroundcolor,backgroundcolor
Text styles: select style,select format,select font,select font size
Text alignment: justify left,justify center,justify right,justify full

Other features: inserting bullet lists or numbered lists, inserting and editing tables, direct editing of html-code, outdent or indent text blocks, inserting of smilies, inserting media files with uploading possibility by integrated tinybrowser, elgg language support. Inline-scripting should work, too.

The tinybrowser needs a directory '/assets' under your $_SERVER['DOCUMENT_ROOT'], so that you have to create this first and chmod it to '777'. When a user uploads a file, additional subdirectorys based on the loginname of the user will be created in the following form:

/assets
   /loginname
      /img        //store for images
         /_thumbs //store for automatic created thumbnails
      /media      //store for 'swf' files
      
If you want to upload and embed flash videos, you first have to put the *.flv together with a flashplayer into an *.swf. You can do this with a flash toolbox. Otherwise you can embed flash videos from youtube simply by inserting the url of the video.
I've NOT tested inserting media of other formats than flash.

Installation:
Make a backup copy of your existing /mod/tinymce folder and delete it. Insert the tinymce folder from this archive in /mod.
Create a folder '/assets' under your $_SERVER['DOCUMENT_ROOT'] and chmod it to '777' (or chown it according to the account of your webserver e.g 'www', 'wwwrun' and give permissions to write - this should work, too).

Although i've tested this plugin on my various systems, there's no warranty. Use it on your own risk.

You will find additional information on the website of the tinymce developers: http://www.moxiecode.com.

enjoy it!
Karsten Schulze (2009)
