<?php
/**
 * Idea popup
 *
 * @package Brainstorm
 */

echo elgg_view('input/button', array('name' => 'rate-0', 'value' => '0', 'class' => 'rate-0'));
echo elgg_view('input/button', array('name' => 'rate-1', 'value' => '1', 'class' => 'rate-1'));
echo elgg_view('input/button', array('name' => 'rate-2', 'value' => '2', 'class' => 'rate-2'));
echo elgg_view('input/button', array('name' => 'rate-3', 'value' => '3', 'class' => 'rate-3'));