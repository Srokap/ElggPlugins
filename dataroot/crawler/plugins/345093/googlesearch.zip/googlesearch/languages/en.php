<?php

	$english = array(
		'googlesearch' => 'Google search',
	
		'googlesearch:poweredby' => 'Powered by Google',
		'googlesearch:cached' => 'Cached',
	);
					
	add_translation("en",$english);

?>