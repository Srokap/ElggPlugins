.search_result {
	padding-bottom: 5px;
}