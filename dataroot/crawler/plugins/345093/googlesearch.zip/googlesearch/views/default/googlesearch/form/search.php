<?php

	$results = $vars['results'];
	$google_results = array();
	if ($results)
	{
		
		$num_results = $results->responseData->cursor->estimatedResultCount;
		
		foreach ($results->responseData->results as $result)
		{
			$tmp = new ElggObject();
			$tmp->subtype = 'searchresult';
			foreach ($result as $key => $value)
				$tmp->$key = $value;
				
			$google_results[] = $tmp;
		}
		
		
		echo elgg_view_entity_list($google_results, $num_results, get_input('offset'), 8, true, false);

	}
?>
<div id="poweredby"><p><?php echo elgg_echo('googlesearch:poweredby'); ?></p></div>