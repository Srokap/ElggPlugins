<?php
	$entity = $vars['entity'];
?>
<div class="search_result">
	<div class="google_search_result">
	
		<div class="google_search_result_title"><?php echo $entity->title; ?> - <?php echo elgg_view('output/url', array('value' => $entity->url, 'text' => $entity->visibleUrl)); ?></div>
		<div class="google_search_result_content"><?php echo $entity->content; ?></div>
		<div class="google_search_result_tools"><?php echo elgg_view('output/url', array('value' => $entity->cacheUrl, 'text' => elgg_echo('googlesearch:cached'))); ?></div>
	</div>
</div>