<?php
	require_once(dirname(dirname(dirname(__FILE__))) . '/engine/start.php');

	global $CONFIG;
	
	$host = parse_url($CONFIG->wwwroot);
	$domain = $host['host'];
	$start = "";
	if (get_input('offset'))
		$start = "&start=" . get_input('offset');
	
	$tag = get_input('tag');
	$results = file_get_contents('http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=' . urlencode("site:$domain $tag"). $start);
	$results = json_decode($results);
	
	$body = elgg_view('googlesearch/form/search', array('results' => $results));
	
	page_draw(elgg_echo('googlesearch'), elgg_view_layout("one_column", $body));
?>