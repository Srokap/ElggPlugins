<?php
	/**
	 * Override normal search with a site specific google search.
	 *
	 * @author Marcus Povey <marcus@dushka.co.uk>
	 * @copyright Marcus Povey 2009-2010 
	 * @license GNU Public License version 2
	 */
	

	function googlesearch_init()
	{
    	global $CONFIG;
    
    	// Handle some specific pages
		register_page_handler('search','googlesearch_pagehandler');		

		// Extend css
		extend_view('css','googlesearch/css');
	}
	
	function googlesearch_pagehandler($page)
	{
		global $CONFIG;
		
		include($CONFIG->pluginspath . "googlesearch/index.php"); 
	}
	
		
	register_elgg_event_handler('init','system','googlesearch_init');

?>