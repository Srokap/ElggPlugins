#page_export_form label
{
	font-size: 100%;
	font-weight: normal;
}