Install:

Unzip the 'feeds' module directory in to 'elgg/mod/'.

You will then need to apply a google API key to make this module work. Once you have it, insert it into 'settings' under the 'feeds' plugin on the 'Administration tools' menu.

Get an API key here http://code.google.com/apis/ajaxfeeds/
it should be something like this : JKJKShsjhsjhuhhwhHSJHUSShsduOKXJjhkefefbciHnjUHSWUSUIJIIJXZ

If upgrading from existing version, just delete mod/feeds/ directory and unzip
this into your mods/ dir.

This plugin can now delete your unwanted feeds, and include the v1.5 look and feel. 
