<?php
	/**
	 * @file engine/handlers/action_handler.php
	 * @brief Just change the action() for ajax_action()
	 */

	define('externalpage',true);
	require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))).'/engine/start.php');
	
	$action = get_input("action");

	// The only diference is that the forward at end of action() function was removed into ajax_action() 
	ajax_action($action);
?>