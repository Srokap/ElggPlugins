<?php
	/**
	 * @file automatic_doc_for_doxygen.php
	 * @brief Provides some information for doxygen
	 */

	/**
	 * @mainpage Ajax form input
	 * 
	 * Provides a ajax form input view for elgg system very similar to the default elgg form input view provided by elgg
	 * and It is compatible with elgg action system
	 * <br />
	 * <br />
	 * 
	 * <b>Author: </b>José Gomes; email: juniordesiron@gmail.com
	 * <br />
	 * <b>Elgg Version: </b>1.7.3
	 * <br />
	 * <b>Published: </b>20/10/2010
	 * <br />
	 * <b>Last update: </b>20/10/2010
	 * <br />
	 * <b>Functionality: </b><br />
	 * (version 1.00)<br />
	 * 1 - Provides a ajax form view according to elgg view system and very similar to "input/form" elgg default view
	 * 2 - Provides a demo of how to use the ajax_form_input plugin
	 * <br />
	 */
?>