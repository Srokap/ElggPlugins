<?php
	/**
	 * @file languages/pt-br.php
	 * @brief Include the ajax_form_input brazilian portuguese translation into the elgg system
	 */

	$portuguese = array(
		'ajax_form_input:ajax_output_message'=>'Os dados preenchidos no formulário foram enviados via ajax e salvos na $_SESSION criada pela função system_message() do elgg, para ver os valores enviados pressione F5',
		'ajax_form_input:demo'=>'Ajax form demo',
		'ajax_form_input:doc'=>'Ajax form doc',
		'ajax_form_input:display_errors'=>'Mostrar erros',
		'ajax_form_input:long_text'=>'Long text',
		'ajax_form_input:no'=>'Não',
		'ajax_form_input:pulldown'=>'Pulldown',
		'ajax_form_input:yes'=>'Sim',
		'ajax_form_input:send'=>'Enviar',
		'ajax_form_input:radio'=>'Radio',
		'ajax_form_input:remove_message'=>'(Você pode remover esta messagem modificando as configurações do plugin)',
		'ajax_form_input:text'=>'Text',

		'ajax_form_input:errors:invalid_action'=>'A ação: "%s" não é uma ação válida do elgg',
		);
		
	add_translation('pt-br',$english);
?>