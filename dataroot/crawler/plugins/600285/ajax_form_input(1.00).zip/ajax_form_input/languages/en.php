<?php
	/**
	 * @file languages/en.php
	 * @brief Include the ajax_form_input english translation into the elgg system
	 */
	
	$english = array(
		'ajax_form_input:ajax_output_message'=>'The data filled in the form was sended via ajax and It was saved into the $_SESSION created by the system_message() function, so press F5 to see the sended values :)',
		'ajax_form_input:demo'=>'Ajax form demo',
		'ajax_form_input:doc'=>'Ajax form doc',
		'ajax_form_input:display_errors'=>'Display errors',
		'ajax_form_input:long_text'=>'Long text',
		'ajax_form_input:no'=>'No',
		'ajax_form_input:pulldown'=>'Pulldown',
		'ajax_form_input:yes'=>'Yes',
		'ajax_form_input:send'=>'Send',
		'ajax_form_input:radio'=>'Radio',
		'ajax_form_input:remove_message'=>'(You may remove this message by changing the plugin settings)',
		'ajax_form_input:text'=>'Text',

		'ajax_form_input:errors:invalid_action'=>'The action "%s" is not a valid elgg action',
		);
		
	add_translation('en',$english);
?>