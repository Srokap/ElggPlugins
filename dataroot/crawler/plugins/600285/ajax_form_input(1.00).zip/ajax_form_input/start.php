<?php
	/**
	 * @file start.php
	 * @brief Starts ajax_form_input plugin on elgg system 
	 */

	/**
	 * Set ajax_form_input basic configuration on elgg system
	 */
	function ajax_form_input_init()
	{
		global $CONFIG;
		
		register_translations($CONFIG->pluginspath.'ajax_form_input/languages',true);
		
		register_page_handler('ajax_form_input','ajax_form_input_page_handler');
	}
	
	require_once('lib/actions.php');
	require_once('lib/ajax_form_input.php');
	
	/**
	 * Handle the ajax_form_input plugin pages
	 * 
	 * @param $page
	 */
	function ajax_form_input_page_handler($page)
	{
		if(isset($page[0]))
		{
			global $CONFIG;
			
			switch($page[0])
			{
				case 'demo':
					include($CONFIG->pluginspath.'ajax_form_input/ajax_form_demo.php');
					break;
			}
		}
	}
	
	/**
	 * Set ajax_form_input plugin submenu links on elgg system
	 */
	function ajax_form_input_pagesetup()
	{
		if(get_context()=='admin' && isadminloggedin())
		{
			global $CONFIG;
			
			add_submenu_item(elgg_echo('ajax_form_input:demo'),$CONFIG->wwwroot.'pg/ajax_form_input/demo','ajax_form_input');
			add_submenu_item(elgg_echo('ajax_form_input:doc'),$CONFIG->wwwroot.'mod/ajax_form_input/doc/index.html','ajax_form_input');
		}
	}
	
	global $CONFIG;

	register_elgg_event_handler('init','system','ajax_form_input_init');
	register_elgg_event_handler('pagesetup','system','ajax_form_input_pagesetup');
	
	register_action('ajax_form_input/demo',false,$CONFIG->pluginspath.'ajax_form_input/actions/demo.php');
?>