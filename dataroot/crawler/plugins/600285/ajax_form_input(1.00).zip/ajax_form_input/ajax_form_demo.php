<?php
	/**
	 * @file ajax_form_demo.php
	 * @brief Displays a demo utilization of ajax_form_input plugin
	 */

	require_once(dirname(dirname(dirname(__FILE__))).'/engine/start.php');
	
	$title = elgg_echo('ajax_form_input:demo');
	
	$area2 = elgg_view_title($title);
	$area2 .= elgg_view('ajax_form_input/sample_demo');
	
	$page_body = elgg_view_layout('two_column_left_sidebar',$area1,$area2);
	
	page_draw($title,$page_body);
?>