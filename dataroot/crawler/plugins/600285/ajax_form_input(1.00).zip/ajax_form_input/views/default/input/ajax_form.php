<?php
	/**
	 * @file views/default/input/ajax_form.php
	 * @brief Ajax input according to elgg views system
	 */

	$action = $vars['action'];
	
	// Some javascript function or code for ready state event of ajax request
	$ready_state_js = $vars['ready_state_js'];
	
	$js = $vars['js'];
	$id = (isset($vars['internalid'])) ? ($vars['internalid']) : '';

	// For now only by method POST
	$method = 'POST';
	// $method = (isset($vars['method'])) ? ($vars['method']) : 'POST';

	// test
	$action = $vars['url'].'action/ajax_form_input/demo';
	
	$action = handle_ajax_form_action($action);
	
	// The javascript functions required for ajax_form_input elgg plugin
	echo elgg_view('js/ajax_form_input',array('action'=>$action,'ready_state_js'=>$ready_state_js));
	
	$formAttributes = '';
	$formAttributes .= ($id) ? (' id="'.$id.'" ') : '';
	$formAttributes .= $js;
?>
 
<form name='ajax_form' action='javascript: ajax_submit(document.ajax_form);' <?php echo $formAttributes; ?> >
	<?php 
		//Generate the elgg token for the "input/form" view
		echo elgg_view('ajax_form_input/elgg_form_token',$vars);

		echo $vars['body'];
	?>
</form>