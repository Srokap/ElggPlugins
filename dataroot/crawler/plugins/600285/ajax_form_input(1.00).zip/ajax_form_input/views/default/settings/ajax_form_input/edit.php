<?php
	/**
	 * @file views/default/settings/ajax_form_input/edit.php
	 * @brief Display the settings for ajax_form_input plugin
	 */

	$opt = array(elgg_echo('ajax_form_input:yes')=>true,elgg_echo('ajax_form_input:no')=>false);
	$form_body = '';

	$value = get_plugin_setting('display_errors','ajax_form_input');
	$form_body .= '<label>';
	$form_body .= elgg_echo('ajax_form_input:display_errors');
	$form_body .= '<br />';
	$form_body .= elgg_view('input/radio',array('internalname'=>'params[display_errors]','value'=>$value,'options'=>$opt));
	$form_body .= '</label>';
	$form_body .= '<br />';
	
	echo $form_body;
?>