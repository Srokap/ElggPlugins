<?php
	/**
	 * @file views/default/ajax_form_input/elgg_form_token.php
	 * @brief Generate the elgg token for the "input/form" view
	 */

	// Generate a security header
	$security_header = "";
	if (!isset($vars['disable_security']) || $vars['disable_security'] != true) {
		$security_header = elgg_view('input/securitytoken');
	}
	
	echo $security_header;
?>