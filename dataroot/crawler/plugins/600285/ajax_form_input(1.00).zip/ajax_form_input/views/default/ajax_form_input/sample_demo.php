<?php
	/**
	 * @file views/default/ajax_form_input/sample_demo.php
	 * @brief Displays a sample example of how to use the ajax_form_input plugin
	 */

	$action = $vars['url'].'action/ajax_form_input/demo';
	$form_body = '';
	
	$form_body .= '<label>';
	$form_body .= elgg_echo('ajax_form_input:text');
	$form_body .= elgg_view('input/text',array('internalname'=>'text'));
	$form_body .= '</label>';
	$form_body .= '<br /><br />';
	
	$form_body .= '<label>';
	$form_body .= elgg_echo('ajax_form_input:long_text');
	$form_body .= elgg_view('input/longtext',array('internalname'=>'long_text'));
	$form_body .= '</label>';
	$form_body .= '<br /><br />';
	
	$checkbox_options = array(
		'Checkbox label1'=>'checkbox_value1',
		'Checkbox label2'=>'checkbox_value2',
		'Checkbox label3'=>'checkbox_value3',
		);
	$form_body .= elgg_view('input/checkboxes',array('internalname'=>'checkbox','options'=>$checkbox_options));
	
	$options_values = array(
		'pulldown_value1'=>'Pulldown label1',
		'pulldown_value2'=>'Pulldown label2',
		'pulldown_value3'=>'Pulldown label3'
		);
	$form_body .= '<label>';
	$form_body .= elgg_echo('ajax_form_input:pulldown');
	$form_body .= '<br />';
	$form_body .= elgg_view('input/pulldown',array('internalname'=>'pulldown','options_values'=>$options_values));
	$form_body .= '</label>';
	$form_body .= '<br /><br />';
	
	$options = array(
		'Radio label1'=>'radio_value1',
		'Radio label2'=>'radio_value2',
		'Radio label3'=>'radio_value3'
		);
	$form_body .= '<label>';
	$form_body .= elgg_echo('ajax_form_input:radio');
	$form_body .= '<br />';
	$form_body .= elgg_view('input/radio',array('internalname'=>'radio','options'=>$options));
	$form_body .= '</label>';
	$form_body .= '<br />';
	
	$form_body .= elgg_view('input/submit',array('value'=>elgg_echo('ajax_form_input:send')));
	
	// Javascript function for warn the user about the ajax output
	$ready_state_js = ' display_div_message(); ';
	
	$form = elgg_view('input/ajax_form',array(
		'action'=>$action,
		'body'=>$form_body,
		'ready_state_js'=>$ready_state_js
		));
?>

<script type="text/javascript">
	function display_div_message() {
		var div = document.getElementById('ajax_output_message');

		div.innerHTML = "<?php echo elgg_echo('ajax_form_input:ajax_output_message'); ?>";
	}
		
</script>

<?php
	echo $form;
?>

<style type="text/css">
	#ajax_output_message {
		background-color: #FFFFCC;
		-moz-border-radius: 8px;
	};
</style>

<div id="ajax_output_message"></div>