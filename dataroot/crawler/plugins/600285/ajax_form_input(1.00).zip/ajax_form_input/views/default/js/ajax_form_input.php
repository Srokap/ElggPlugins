<?php
	/**
	 * @file views/default/js/ajax_form_input.php
	 * @brief The javascript for ajax_form_input plugin
	 */

	// Elgg action for the ajax request or a direct link to some file
	$action = $vars['action'];
	
	// Some javascript function or code for ready state event of ajax request
	$ready_state_js = $vars['ready_state_js'];
?>


<script type="text/javascript">
	function ajax_submit(form) {
		var form_inputs = get_form_inputs(form);

		ajax_connection(form_inputs);
  }

	function get_form_inputs(form) {
		var str = "";		
		for(var i = 0;i < form.elements.length;i++) {			
			if(form.elements[i].name) {
				switch(form.elements[i].type) {
					case "checkbox":
					case "radio":
						if(form.elements[i].checked) {
							if(str) {
								str += "&";
							}
							str += form.elements[i].name + '=' + escape(form.elements[i].value);
						}
						break;
					default:
						if(str) {
							str += "&";
						}
						str += form.elements[i].name + '=' + escape(form.elements[i].value);
						break;
				}
			}
     }
	   return str;
	}

	function ajax_connection(inputs) {
		if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		  xmlhttp=new XMLHttpRequest();
		} else {// code for IE6, IE5
	  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
		  
		xmlhttp.onreadystatechange=function() {
		  if (xmlhttp.readyState==4) {
			  <?php 
			  	echo $ready_state_js;
			  ?>
		   }
		 }
		xmlhttp.open("POST","<?php echo $action; ?>",true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send(inputs);
	}
</script>