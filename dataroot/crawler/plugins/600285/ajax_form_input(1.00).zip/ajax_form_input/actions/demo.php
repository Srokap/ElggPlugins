<?php
	/**
	 * @file actions/demo.php
	 * @brief Just a demo actions using the ajax form input 
	 */


	action_gatekeeper();
	
	if($text = get_input('text'))
	{
		system_message('Text: '.$text.'<hr />');
	}
	
	if($longtext = get_input('long_text'))
	{
		system_message('Long text: '.$longtext.'<hr />');
	}
	
	if($checkbox = get_input('checkbox'))
	{
		$checkbox_values = '';
		foreach($checkbox as $value)
		{
			if($checkbox_values)
			{
				$checkbox_values .= ', ';
			}
			
			$checkbox_values .= $value;
		}
		
		system_message('Checkbox: '.$checkbox_values.'<hr />');
	}
	
	if($pulldown = get_input('pulldown'))
	{
		system_message('Pulldown: '.$pulldown.'<hr />');
	}
	
	if($radio = get_input('radio'))
	{
		system_message('Radio: '.$radio.'<hr />');
	}
?>