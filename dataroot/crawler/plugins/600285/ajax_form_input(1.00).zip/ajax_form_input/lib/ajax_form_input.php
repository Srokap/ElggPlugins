<?php
	/**
	 * @file lib/ajax_form_input.php
	 * @brief The lib required for ajax_form_input plugin
	 */

	/**
	 * Get the pattern made by elgg into the .htaccess file for recognize action URLs
	 */
	function get_htaccess_action_pattern()
	{
		global $CONFIG;
		
		// Removing the '/' from the url for be possible use It into the pattern
		$url = str_replace('/','\/',$CONFIG->wwwroot);
		
		// The same rule as in .htaccess file from elgg, if the elgg changes the .htaccess rule please update this rule too
		$pattern = '/^'.$url.'action\/([A-Za-z0-9\_\-\/]+)$/';
		
		return $pattern;
	}

	/**
	 * Get the dir of action handler file that works fine for ajax requests
	 * 
	 * @param $action
	 */
	function get_action_handler_file($elgg_action)
	{
		global $CONFIG;
		
		$action_handler_file = $CONFIG->wwwroot.'mod/ajax_form_input/engine/handlers/action_handler.php';

		if($elgg_action)
		{
			$action_handler_file .= '?action='.$elgg_action;
		}
		
		return $action_handler_file;
	}
	
	/**
	 * Handles the action passed for ajax_form view for the correct ajax action url
	 * 
	 * @param $action
	 */
	function handle_ajax_form_action($action)
	{
		// Get the pattern made by elgg into the .htaccess file for recognize action URLs
		$pattern = get_htaccess_action_pattern();
		
		if(!preg_match($pattern,$action,$matches))
		{
			if(get_plugin_setting('display_errors','ajax_form_input'))
			{
				$message = sprintf(elgg_echo('ajax_form_input:errors:invalid_action'),$action);
				$message .= '<br /><br />';
				$message .= elgg_echo('ajax_form_input:remove_message');
				
				// Warn the user that he used a invalid elgg action
				system_messages($message,'errors');
			}
		}
		else {
			// If the action is a valid elgg action than change the URL for request the ajax_form_input "your_elgg/mod/ajax_form_input/engine/handlers/action_handler.php" instead "your_elgg/engine/handlers/action_handler.php"
			
			$action = $matches[1];
			$action = get_action_handler_file($action);
		}
		
		return $action;
	}
?>