<?php
	/**
	 * @file lib/actions.php
	 * @brief Declare the ajax_action() like ajax_action just because the default action() function provided
	 * by elgg core lib doesn't provide anyway to remove the forward() at the end of the function 
	 */

	/**
	* Loads an action script, if it exists, then forwards elsewhere
	*
	* @param string $action The requested action
	* @param string $forwarder Optionally, the location to forward to
	*/
	function ajax_action($action, $forwarder = "") {
		global $CONFIG;
	
		$action = rtrim($action, '/');
	
		// @todo REMOVE THESE ONCE #1509 IS IN PLACE.
		// Allow users to disable plugins without a token in order to
		// remove plugins that are incompatible.
		// Installation cannot use tokens because it requires site secret to be
		// working. (#1462)
		// Login and logout are for convenience.
		// file/download (see #2010)
		$exceptions = array(
			'systemsettings/install',
			'admin/plugins/disable',
			'logout',
			'login',
			'file/download',
		);
	
		if (!in_array($action, $exceptions)) {
			// All actions require a token.
			action_gatekeeper();
		}
	
		$forwarder = str_replace($CONFIG->url, "", $forwarder);
		$forwarder = str_replace("http://", "", $forwarder);
		$forwarder = str_replace("@", "", $forwarder);
	
		if (substr($forwarder, 0, 1) == "/") {
			$forwarder = substr($forwarder, 1);
		}
	
		if (isset($CONFIG->actions[$action])) {
			if ((isadminloggedin()) || (!$CONFIG->actions[$action]['admin'])) {
				if ($CONFIG->actions[$action]['public'] || get_loggedin_userid()) {
	
					// Trigger action event
					// @todo This is only called before the primary action is called. We need to rethink actions for 1.5
					$event_result = true;
					$event_result = trigger_plugin_hook('action', $action, null, $event_result);
	
					// Include action
					// Event_result being false doesn't produce an error -
					// since i assume this will be handled in the hook itself.
					// @todo make this better!
					if ($event_result) {
						if (!include($CONFIG->actions[$action]['file'])) {
							register_error(sprintf(elgg_echo('actionundefined'),$action));
						}
					}
				} else {
					register_error(elgg_echo('actionloggedout'));
				}
			} else {
				register_error(elgg_echo('actionunauthorized'));
			}
		} else {
			register_error(sprintf(elgg_echo('actionundefined'),$action));
		}
	
		//forward($CONFIG->url . $forwarder);
	}
?>