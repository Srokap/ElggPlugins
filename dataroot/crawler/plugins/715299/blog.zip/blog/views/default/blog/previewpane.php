<div class="blog_previewpane">
	<p>
		<?php echo elgg_echo("blog:preview:description"); ?>
		<a href="javascript:history.go(-1);"><?php echo elgg_echo("blog:preview:description:link"); ?></a>
	</p>
</div>
