<?php

$vars['rel'] = 'stylesheet';
$vars['type'] = 'text/css';
echo elgg_view('link', $vars);