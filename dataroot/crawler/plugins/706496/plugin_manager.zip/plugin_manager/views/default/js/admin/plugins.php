<?php
global $CONFIG;
include $CONFIG->pluginspath.'plugin_manager/js/admin/plugins.js';