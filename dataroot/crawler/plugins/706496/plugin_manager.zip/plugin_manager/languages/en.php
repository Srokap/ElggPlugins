<?php
$english = array(
	'admin:plugins:reorder:yes'			=> 'Plugins were successfully reordered',
	'admin:plugins:reorder:no'			=> 'Failed to reorder plugins!',
	'admin:plugins:extension'       	=> 'Extension',
	'admin:plugins:plugins_name_list' 	=> 'List of plugins (a comma separated list with currently enabled plugins)',
	'admin:plugins:apply' 				=> 'Apply',
	'admin:plugins:clear_list'      	=> 'Clear List',
	'admin:plugins:reset_list'      	=> 'Reset List',
	'admin:plugins:select_list'     	=> 'Select List',
);

add_translation("en", $english);
