Extract elgg_qik-*.zip to your mod/ folder.

Each user will need to register their own userid with qik.com and 
enter the information into the widget settings.

~mk
