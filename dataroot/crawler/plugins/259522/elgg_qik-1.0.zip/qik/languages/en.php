<?php

        $english = array(
        
                
                'qik:title' => "My Qik cam",
		'qik:description' => "Qik.com live mobile phone widget",
                'qik:username' => "Enter your Qik userid and Save",
                'qik:error' => "Click <strong>EDIT</strong> in the top right of this box to <strong>enter your Qik username</strong> to use this widget.<br/><br/><strong>Qik.com</strong> allows you to stream and save your camera on your mobile phone to your profile<br/>.",
                'qik:signup' => "Create a Qik account now",
        );
                                        
        add_translation("en",$english);

?>
