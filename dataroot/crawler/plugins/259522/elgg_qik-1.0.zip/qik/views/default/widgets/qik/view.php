<div class="contentWrapper user_settings" style="height:195px;">

<!-- qik start -->

<?php // if username is not set, display the message box instead of video
if($vars['entity']->username == "") { 
	$error = elgg_echo('qik:error'); 
	$signup = elgg_echo('qik:signup'); 
	echo "$error<br/><a target='_blank' href='http://qik.com/sign_up'>$signup</a>"; } else {

// display video ?>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,115,0" width="260" height="195" id="qikPlayer" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="allowFullScreen" value="true" /><param name="movie" value="http://qik.com/swfs/qikPlayer4.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#333333" /><param name="FlashVars" value="rssURL=http://qik.com/<?php echo $vars['entity']->username; ?>/latest-videos&autoPlay=false&pollingUrl=http://qik.com/videos/latest/<?php echo $vars['entity']->username; ?>&polling=true"><embed src="http://qik.com/swfs/qikPlayer4.swf" quality="high" bgcolor="#333333" width="260" height="195" name="qikPlayer" align="middle" allowScriptAccess="sameDomain" allowFullScreen="true" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" FlashVars="rssURL=http://qik.com/<?php echo $vars['entity']->username; ?>/latest-videos&autoPlay=false&pollingUrl=http://qik.com/videos/latest/<?php echo $vars['entity']->username; ?>&polling=true"/></object>

<!-- qik end -->

</div>

<?php } ?>
