<?php

                function qik_init() {
                    
                    
                        
                    //add a widget
                            add_widget_type('qik',elgg_echo("qik:title"),elgg_echo("qik:description"));
                        
                }
                
                register_elgg_event_handler('init','system','qik_init');

?>
