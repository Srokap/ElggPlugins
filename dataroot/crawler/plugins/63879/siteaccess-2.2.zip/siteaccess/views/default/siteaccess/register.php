<?php
//extend this view in your plugin to add additional registration fields here

?>
