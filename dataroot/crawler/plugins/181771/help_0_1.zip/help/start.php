<?php

	function help_plugin_init() 
	{
		extend_view('css', 'help/css');
		
		register_page_handler('help','help_page_handler');
	}


	function help_page_handler($page) 
	{
		
		if ($page[0])
		{
			switch ($page[0])
			{
				case "overview":
					include(dirname(__FILE__) . "/overview.php");
					break;
				case "faq":
					include(dirname(__FILE__) . "/faq.php");
					break;
				default: 
					break;
			}
		}
	}

	register_elgg_event_handler('init','system','help_plugin_init');
?>