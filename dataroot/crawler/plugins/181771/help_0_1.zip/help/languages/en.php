<?php

	$english = array(
	
		'help' => "Help",
		
		'help:faq' => "Frequenty Asked Questions",
		'help:overview' => "Overview",
	);

	add_translation("en",$english);

?>
