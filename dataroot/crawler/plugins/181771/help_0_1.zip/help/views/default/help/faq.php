<?php

?>
<div class="contentWrapper">
Frequently asked questions here
</div>