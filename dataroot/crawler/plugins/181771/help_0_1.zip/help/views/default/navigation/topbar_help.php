<?php

	$help_menu['Overview'] = $vars['url'] . 'pg/help/overview';
	$help_menu['FAQ'] = $vars['url'] . 'pg/help/faq';
	
?>
<ul class="topbardropdownmenu" id="helpmenu">
	<li class="drop"><a href="#" class="menuitemtools"><?php echo(elgg_echo('help')); ?></a>
		<ul>
<?php
			foreach($help_menu as $key=>$value) {
				echo "<li><a href=\"{$value}\">" . $key . "</a></li>";
			} 
?>
		</ul>
	</li>
</ul>