<?php

?>
<div id="owner_block">
<div id="owner_block_submenu">
<div class="submenu_group">
<div class="submenu_group_a">
	<ul>
		<li ><a href="" >General FAQs</a></li>
		<li ><a href="" >Settings FAQs</a></li>
		<li ><a href="" >Permissions FAQs</a></li>
	</ul>
</div>
</div>
</div>
</div>