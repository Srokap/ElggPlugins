#helpmenu {
margin-left:20px;
}
