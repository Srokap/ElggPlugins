<?php

?>
<div class="contentWrapper">
<div class="overview_tool" id="activity">
<h2>Activity</h2>
<p>Describe the activity tool here</p>
</div>
<div class="overview_tool" id="blog">
<h2>Blogs</h2>
<p>Describe the blog tool here</p>
</div>
<div class="overview_tool" id="notifications">
<h2>Notifications</h2>
<p>Describe notifications here</p>
</div>
<div class="overview_tool" id="pages">
<h2>Pages</h2>
<p>Describe the pages tool here</p>
</div>
<div class="overview_tool" id="bookmarks">
<h2>Bookmarks</h2>
<p>Describe the bookmark tool here</p>
</div>
</div>