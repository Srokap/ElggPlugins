<?php
/**
 * Elgg authentication backend
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Christian Heckelmann <christian@heckelmann.info>
 */

define('DOKU_AUTH', dirname(__FILE__));
require_once(DOKU_AUTH.'/basic.class.php');

// Your Elgg Installation path....
require_once('/path/to/elgg/engine/start.php');

class auth_elgg extends auth_basic {

    var $users = null;
    var $_pattern = array();

    /**
     * Constructor
     *
     * Carry out sanity checks to ensure the object is
     * able to operate. Set capabilities.
     *
     * @author  Christian Heckelmann
     */
    function auth_elgg() {
          $this->cando['addUser']      = false;
          $this->cando['delUser']      = false;
          $this->cando['modLogin']     = false;
          $this->cando['modPass']      = false;
          $this->cando['modName']      = false;
          $this->cando['modMail']      = false;
          $this->cando['modGroups']    = false;
          $this->cando['getUsers']     = false;
          $this->cando['getUserCount'] = false;
          $this->cando['external']     = false;
    }

    /**
     * Check user+password [required auth function]
     *
     * Checks if the given user exists and the given
     * plaintext password is correct
     *
     * @author  Christian Heckelmann
     * @return  bool
     */
    function checkPass($user,$pass){
        $result = false;          
        if ($userobject = authenticate($user,$pass)) {
                $result = login($userobject, false);
        }
        if($result) {
            return true;
        } else {
            return false;
        }      
    }
   
    //Get user data [OVERRIDEN]
    function getUserData($user)
    {
        // Returns the Usergroup...
        if(isadminloggedin()) {
            $retn = array('name' => "$user", 'mail' => $r['email'], 'grps' => array("admin","user"));
        } else {
            $retn = array('name' => $user, 'mail' => $r['email'], 'grps' => array("user"));
        }
        return $retn;
    }

}
// END OFF elgg.class.php
