Simple gravatar integration for Elgg.
Scratching an itch! (+ a good example of icon overloading)

