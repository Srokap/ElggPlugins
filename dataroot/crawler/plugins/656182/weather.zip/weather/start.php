<?php
  function weather_init() {        
    add_widget_type('weather', 'Weather', 'Widget shows the recent weather');
  }
 
  register_elgg_event_handler('init','system','weather_init');       
?>