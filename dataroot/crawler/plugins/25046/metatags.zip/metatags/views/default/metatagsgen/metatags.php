<?php
	/**
	 * Elgg customspotlight plugin
	 * This plugin substitutes the spotlight with a custom one
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Miguel Montes
	 */

	// Put some extra scripts below if needed
?>

<meta name="keywords" content="<?php echo $CONFIG->tagsg; ?>" />