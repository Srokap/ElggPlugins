<?php
	/**
	 * Elgg Metatags generator plugin
	 * This plugin make the metatags for content.
	 * 
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Jonathan Rico www.peesco.com
	 */


	function metatagsgen_init() {
		extend_view('metatags','metatagsgen/metatags');

	}

	register_elgg_event_handler('init','system','metatagsgen_init');
?>
