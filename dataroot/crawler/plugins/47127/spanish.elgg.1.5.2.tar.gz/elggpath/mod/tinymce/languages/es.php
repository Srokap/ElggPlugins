<?php

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
		'tinymce:remove' => "Mostrar/Ocultar editor",
	
	);
					
	add_translation("es",$spanish);

?>
