<?php
	/**
	 * Elgg tidypics plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
			
		// Menu items and titles
			 
			'image' => "Imagen",
			'images' => "Imagenes",
			'caption' => "T&iacute;tulo",		
			'photos' => "Fotos",
			'images:upload' => "Subir im&aacute;genes",
			'album' => "Albums de fotos",
			'albums' => "Albums de fotos",
			'album:yours' => "Su album de fotos",
			'album:yours:friends' => "Las fotos de sus amig@s",
			'album:user' => "Album de fotos de %s",
			'album:friends' => "Albums de fotos de los amig@s de %s",
			'album:all' => "Albums de fotos",
			'album:group' => "Grupos de Albums",
	
		//actions
		
			'album:create' => "Nuevo Album",
			'album:add' => "A&ntilde;adir foto al album",
			'album:addpix' => "A&ntilde;adir fotos",		
			'album:edit' => "Editar album",			
			'album:delete' => "Borrar album",		

			'image:edit' => "Editar imagen",
			'image:delete' => "Borrar imagen",
		
		//forms
		
			'album:title' => "Titulo",
			'album:desc' => "Descripci&oacute;n",
			'album:tags' => "Etiquetas",
			'album:cover' => "Hacer esta imagen la cubierta del album?",
			'image:access:note' => "(ver accesos para el album)",
			
		//views 
		
			'image:total' => "Im&aacute;genes del album:",
			'image:by' => "Imagen a&ntilde;adida por",
			'album:by' => "Album creado por",
			'image:none' => "NO se ha incorporado aun im&aacute;genes.",
			'image:back' => "Atr&aacute;s",
			'image:next' => "Siguiente",
		
		//widgets
		
			'album:widget' => "Album de fotos",
			'album:more' => "Ver todos los albums",
			'album:widget:description' => "Mostrar las &uacute;ltimas fotos",
			'album:display:number' => "N&uacute;mero de albums a mostrar",
			'album:num_albums' => "N&uacute;mero de albums a mostrar",
			
		//  river
		
			//images
			'image:river:created' => "%s actualizada",
			'image:river:item' => "una imagen",
			'image:river:annotate' => "%s comentado en",	
		
			//albums
			'album:river:created' => "%s creado",
			'album:river:item' => "un album",
			'album:river:annotate' => "%s comentado en",				
				
		//  Status messages
			
			'images:saved' => "Su imagen ah sido guardada.",
			'images:saved' => "Todas las imagenes fueron guardadas.",
			'image:deleted' => "Su imagen ha sido borrada.",			
			'image:delete:confirm' => "Est&aacute; seguro que quiere borrar esta imagen?",
			
			'images:edited' => "Sus im&aacute;genes han sido actualizadas.",
			'album:edited' => "Su album ha sido actualizado.",
			'album:saved' => "Su album ha sido guardado.",
			'album:deleted' => "Su album ha sido borrado.",	
			'album:delete:confirm' => "Est&aacute; seguro de eliminar este album?",
				
		//Error messages
				 
			'image:none' => "No puedo encontrar im&aacute;genes en este momento.",
			'image:uploadfailed' => "Archivos no subidos:",
			'image:deletefailed' => "Su imagen no puede ser borrada en este momento.",
			
			'image:notimage' => 'S&oacute;lo se acepta formatos de im&aacute;genes jpeg, gif, o png.',
			'images:notedited' => 'No todas las im&aacute;genes han sido actualizadas',
		 
			'album:none' => "No podemos encontrar ningun algum por el momento.",
			'album:uploadfailed' => "Lo lamento, no podemos guardar su album.",
			'album:deletefailed' => "Su algum no puede ser borrado por el momento.",
	
	);
					
	add_translation("es",$spanish);
?>
