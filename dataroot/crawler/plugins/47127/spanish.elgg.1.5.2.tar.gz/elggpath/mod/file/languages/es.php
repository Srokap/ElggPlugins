<?php
	/**
	 * Elgg file plugin language pack
	 * 
	 * @package ElggFile
	 * @author Curverider Ltd
	 * @copyright Curverider Ltd 2008
	 * @link http://elgg.com/
	 */

	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'file' => "Ficheros",
			'files' => "Ficheros",
			'file:yours' => "Sus Ficheros",
			'file:yours:friends' => "Los ficheros de sus amig@s",
			'file:user' => "Ficheros de %s",
			'file:friends' => "Ficheros de amigos de %s",
			'file:all' => "Todos los ficheros",
			'file:edit' => "Editar fichero",
			'file:more' => "mas ficheros",
			'file:list' => "Vista en lista",
			'file:group' => "Grupo de ficheros",
			'file:gallery' => "Vista de galer&iacute;a",
			'file:gallery_list' => "Galer&iacute; o lista de vista",
			'file:num_files' => "N&uacute;mero de ficheros a mostrar",
			'file:user:gallery'=>'Ver la galeria de %s', 
	
			'file:upload' => "Subir un fichero",
			
			'file:file' => "Fichero",
			'file:title' => "Ti&iacute;tulo",
			'file:desc' => "Descripci&oacute;n",
			'file:tags' => "Estiquetas",
	
			'file:types' => "Tipo de fichoeros subidos",
	
			'file:type:all' => "Todos los ficheros",
			'file:type:video' => "Videos",
			'file:type:document' => "Documentos",
			'file:type:audio' => "Audios",
			'file:type:image' => "Im&aacute;genes",
			'file:type:general' => "General",
	
			'file:user:type:video' => "videos de %s",
			'file:user:type:document' => "documentos de %s",
			'file:user:type:audio' => "audios de %s",
			'file:user:type:image' => "im&aacute;genes de %s",
			'file:user:type:general' => "ficheros generales de %s",
	
			'file:friends:type:video' => "V&iacute;deos de sus amigos",
			'file:friends:type:document' => "Documentos de sus amigos",
			'file:friends:type:audio' => "Audios de sus amigos",
			'file:friends:type:image' => "Im&aacute;genes de sus amigos",
			'file:friends:type:general' => "Ficheros de sus amigos",
	
			'file:widget' => "Componente Fichero",
			'file:widget:description' => "Mostrar los &uacute;ltimos ficheros",
	
			'file:download' => "Bajarse esto",
	
			'file:delete:confirm' => "Est&aacute; seguro que quiere eliminar este fichero?",
			
			'file:tagcloud' => "Nube de etiquetas",
	
			'file:display:number' => "N&uacute;mero de ficheros a mostrarber of files to display",
	
			'file:river:created' => "%s subido",
			'file:river:item' => "un fichero",
			'file:river:annotate' => "%s comentado en",

			'item:object:file' => 'Ficheros',
			
	    /**
		 * Embed media
		 **/
		 
		    'file:embed' => "Multimedia ",
		    'file:embedall' => "Todos",
	
		/**
		 * Status messages
		 */
	
			'file:saved' => "Su fichero ha sido guardado correctamente.",
			'file:deleted' => "Su fichero ha sido eliminado correctamente..",
	
		/**
		 * Error messages
		 */
	
			'file:none' => "No puedo encontrar ficheros en este momento.",
			'file:uploadfailed' => "Lo lamento, no podemos guardar el fichero.",
			'file:downloadfailed' => "Lo lamento, el fichero no est&aacute; disponisble por el momento.",
			'file:deletefailed' => "Su fichero no puede ser eliminado en este momento.",
	
	);
//////////////////////////////////////////////////
	add_translation("es",$spanish);
?>
