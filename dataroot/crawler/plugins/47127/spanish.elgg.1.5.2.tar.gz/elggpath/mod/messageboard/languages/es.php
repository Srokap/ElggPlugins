<?php



	$spanish = array(
	
		/**
		 * Menu items and titles
		 */
	
			'messageboard:board' => "Bandeja de mensajes",
			'messageboard:messageboard' => "bandeja de mensajes",
			'messageboard:viewall' => "Ver todos",
			'messageboard:postit' => "Enviar",
			'messageboard:history' => "historial",
			'messageboard:none' => "No hay ningun mensaje en la bandeja aun",
			'messageboard:num_display' => "N$uacute;mero de mensajes a mostrar",
			'messageboard:desc' => "Este es la bandeja de mensajes que puede ponerlo en su perfil donde otros usuari@s pudieran comentar.",
			
         /**
	     * Message board widget river
	     **/
	        
	        'messageboard:river:annotate' => "%s ha tenido un nuevo comentario en su bandeja de mensajes.",
	        'messageboard:river:create' => "%s a&ntilde;adido componente de bandeja de mensajes.",
	        'messageboard:river:update' => "%s actualizado el componente de bandeja de mensajes.",
			
		/**
		 * Status messages
		 */
	
			'messageboard:posted' => "Ha enviado el mensaje a la bandeja correctamente.",
			'messageboard:deleted' => "Ha eliminado el mensaje correctamente.",
	
		/**
		 * Email messages
		 */
	
			'messageboard:email:subject' => 'Tiene nuevos mensajes en su bandeja!',
			'messageboard:email:body' => "Tiene un nuevo mensaje en su bandeja, comentado por %s:

			
%s


Para ver el mensaje de la bandeja, pulse aqu&iacute;:

	%s

Para ver el perfil de %s, pulse aqu&iacute;:

	%s

Por favor no responda a este correo.",
	
		/**
		 * Error messages
		 */
	
			'messageboard:blank' => "Sorry; you need to actually put something in the message area before we can save it.",
			'messageboard:notfound' => "Sorry; we could not find the specified item.",
			'messageboard:notdeleted' => "Sorry; we could not delete this message.",
	     
			'messageboard:failure' => "An unexpected error occurred when adding your message. Please try again.",
	
	);

	add_translation("es",$spanish);

?>
