<?php
	$spanish = array(
		'twitterservice' => 'Servicio Twitter',
		'twitterservice:postwire' => 'Quieres publicar tus mensajes p&uacuteblicos de The Wire a Twitter?',
		'twitterservice:twittername' => 'usuario Twitter',
		'twitterservice:twitterpass' => 'contrasena Twitter',
	);
					
	add_translation("es",$spanish);
?>
